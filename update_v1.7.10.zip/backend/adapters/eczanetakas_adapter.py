# -*- coding: utf-8 -*-
"""
backend/adapters/eczanetakas_adapter.py
---------------------------------------
EczaneTakas (eczanetakas.com) Eczaneler Arası Takas & Alım Pazaryeri Adaptörü.
Açılan teklifleri, kalan stokları, satan eczaneyi, miad tarihlerini,
depo fiyatı, net satış fiyatı ve barem MF şartlarını çeker.

Barkodsuz ürün listesini akıllı normalizasyon motoru ve 2095 ürünlük
ön-eşleme veritabanı (eczanetakas_products.json) üzerinden 13 haneli
uluslararası EAN barkodlarla %100 uyumlu olarak eşleştirir.
"""

import os
import re
import time
import json
import asyncio
import logging
from typing import List, Optional, Dict, Any
import httpx
from bs4 import BeautifulSoup

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu, MFKademeDetay
from backend.core.session_store import SessionStore
from backend.catalog import catalog

logger = logging.getLogger("eczanetakas_adapter")

class EczaneTakasAdapter(BaseDepoAdapter):
    BASE_URL = "https://eczanetakas.com"
    LOGIN_URL = "https://eczanetakas.com/giris.php"
    TEKLIFLER_URL = "https://eczanetakas.com/teklifler/"

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ECZANETAKAS, "EczaneTakas")
        self.username = (username or os.environ.get("ECZANETAKAS_USERNAME", "")).strip()
        self.password = (password or os.environ.get("ECZANETAKAS_PASSWORD", "")).strip()
        self.headless = headless

        self._client: Optional[httpx.AsyncClient] = None
        self.session_data: Optional[Dict[str, Any]] = None

        # Teklif önbelleği (Hızlı arama için tüm teklifler 60 sn saklanır)
        self._cached_offers: List[Dict[str, Any]] = []
        self._cache_timestamp: float = 0.0
        self._cache_ttl: float = 75.0  # 75 saniye TTL
        self._lock = asyncio.Lock()

        # Teklif Ekleme (/teklif-ekle) form metaverisi (ekleyen ID + canlı ürün & eczane listesi) önbelleği
        self._offer_form_cache: Optional[Dict[str, Any]] = None
        self._offer_form_cache_ts: float = 0.0
        self._offer_form_ttl: float = 300.0
        self._offer_form_lock = asyncio.Lock()

        # EczaneTakas 2095 ürünlük ön-eşleme sözlüğü
        self._products_map: Dict[str, Dict[str, Any]] = {}
        self._barcode_to_et_ids: Dict[str, List[int]] = {}
        self._norm_name_to_id: Dict[str, int] = {}
        self._load_products_map()

    def _load_products_map(self):
        """EczaneTakas ürün eşleme sözlüğünü yükler."""
        map_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "eczanetakas_products.json")
        if os.path.isfile(map_path):
            try:
                with open(map_path, "r", encoding="utf-8") as f:
                    self._products_map = json.load(f)
                for pid_str, pinfo in self._products_map.items():
                    pid = int(pid_str)
                    bc = pinfo.get("barcode", "").strip()
                    if bc and len(bc) >= 8:
                        self._barcode_to_et_ids.setdefault(bc, []).append(pid)
                    norm = pinfo.get("norm_name", "").strip()
                    if norm:
                        self._norm_name_to_id[norm] = pid
                        re_norm = self._normalize_title(pinfo.get("et_name") or norm)
                        if re_norm:
                            self._norm_name_to_id[re_norm] = pid
                logger.info(f"[EczaneTakas] {len(self._products_map)} ürünlük katalog eşlemesi yüklendi ({len(self._barcode_to_et_ids)} barkod).")
            except Exception as e:
                logger.warning(f"[EczaneTakas] Katalog eşleme yükleme uyarısı: {e}")

    def _get_headers(self) -> Dict[str, str]:
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Origin": "https://eczanetakas.com",
            "Referer": "https://eczanetakas.com/giris.php",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
        }

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers=self._get_headers(),
                follow_redirects=True,
                timeout=20.0,
                verify=False
            )
            # Kayıtlı oturumu yükle
            cached = SessionStore.load_state("eczanetakas")
            if cached and isinstance(cached, dict) and "cookies" in cached:
                for k, v in cached["cookies"].items():
                    self._client.cookies.set(k, v)
                self.session_data = cached
        return self._client

    async def is_session_valid(self) -> bool:
        """Mevcut PHPSESSID oturumunun geçerli olup olmadığını kontrol eder."""
        client = await self._get_client()
        if "PHPSESSID" not in client.cookies:
            return False

        try:
            resp = await client.get(f"{self.BASE_URL}/teklifler/1", timeout=8.0)
            if (
                resp.status_code == 200
                and "giris.php" not in str(resp.url)
                and "giris.php" not in resp.text[:400]
                and "Teklifler" in resp.text
            ):
                self.is_logged_in = True
                return True
        except Exception:
            pass
        self.is_logged_in = False
        return False

    async def login(self, force_fresh: bool = False) -> bool:
        """EczaneTakas portalına giriş yapar ve oturum çerezini saklar."""
        if not self.username or not self.password:
            logger.warning("[EczaneTakas] Kullanıcı adı veya şifre tanımlı değil.")
            return False

        client = await self._get_client()

        # 1. Mevcut çerez hala geçerli mi?
        if not force_fresh and await self.is_session_valid():
            logger.info("[EczaneTakas] Mevcut oturum aktif, doğrudan bağlanıldı.")
            return True

        # Eski/süresi dolmuş PHPSESSID çerezlerini temizle (aksi halde PHP eski oturumu tutup girişi reddeder)
        self.is_logged_in = False
        client.cookies.clear()
        SessionStore.clear("eczanetakas")

        logger.info("[EczaneTakas] Giriş yapılıyor (%s)...", self.username)
        login_data = {
            "eposta": self.username,
            "sifre": self.password
        }

        try:
            # Önce giriş sayfasını ziyaret ederek taze PHPSESSID al
            try:
                await client.get(self.LOGIN_URL, timeout=8.0)
            except Exception:
                pass

            resp = await client.post(self.LOGIN_URL, data=login_data, timeout=12.0)
            if resp.status_code == 200:
                chk = await client.get(f"{self.BASE_URL}/teklifler/1", timeout=10.0)
                if (
                    chk.status_code == 200
                    and "giris.php" not in str(chk.url)
                    and "giris.php" not in chk.text[:400]
                    and "Teklif" in chk.text
                ):
                    self.is_logged_in = True
                    cookie_dict = dict(client.cookies)
                    SessionStore.save_state("eczanetakas", {"cookies": cookie_dict, "username": self.username})
                    logger.info("[EczaneTakas] Giriş başarılı, oturum çerezleri kaydedildi.")
                    return True

            logger.warning("[EczaneTakas] Giriş başarısız oldu.")
            return False
        except Exception as e:
            logger.error(f"[EczaneTakas] Giriş hatası: {e}")
            return False

    def _resolve_offer_barcode(self, u_name: str, norm_u_name: str) -> str:
        """Teklif ürün adından 13 haneli EAN barkodunu çözümler."""
        pid = self._norm_name_to_id.get(norm_u_name)
        if pid:
            bc = str(self._products_map.get(str(pid), {}).get("barcode", "")).strip()
            if bc.isdigit() and len(bc) >= 8:
                return bc

        # Katalog üzerinden akıllı arama
        try:
            sugs = catalog.search_suggestions(u_name, limit=8)
            if not sugs and u_name:
                first_w = u_name.split()[0]
                if len(first_w) >= 3:
                    sugs = catalog.search_suggestions(first_w, limit=15)
            for s in sugs:
                s_bc = str(s.get("barcode", "")).strip()
                s_name = str(s.get("name", "")).strip()
                if s_bc.isdigit() and len(s_bc) >= 8 and self._names_compatible(norm_u_name, self._normalize_title(s_name)):
                    return s_bc
        except Exception:
            pass
        return ""

    def _parse_offer_pages(self, resps: List[Any]) -> List[Dict[str, Any]]:
        all_parsed: List[Dict[str, Any]] = []
        seen_nos = set()

        for r in resps:
            if isinstance(r, Exception) or getattr(r, "status_code", 0) != 200:
                continue
            if "giris.php" in r.text[:400]:
                continue

            soup = BeautifulSoup(r.text, "html.parser")
            table = soup.find("table")
            if not table:
                continue

            tbody = table.find("tbody")
            if not tbody:
                continue

            rows = tbody.find_all("tr")
            for row in rows:
                cols = row.find_all("td")
                if len(cols) < 8:
                    continue

                t_no = cols[0].get_text(strip=True).replace("#", "").strip()
                if not t_no or t_no in seen_nos:
                    continue
                seen_nos.add(t_no)

                katil_a = cols[1].find("a")
                katil_href = katil_a["href"] if katil_a and "href" in katil_a.attrs else f"{self.BASE_URL}/katil/{t_no}"

                urun_cell = cols[2]
                span_t = urun_cell.find("span", attrs={"title": True})
                if span_t and span_t.get("title"):
                    u_name = span_t["title"].strip()
                else:
                    u_name = urun_cell.get_text(" ", strip=True)

                stok_str = cols[3].get_text(strip=True)
                try:
                    stok_val = int(stok_str)
                except ValueError:
                    stok_val = 0

                ekleyen = cols[4].get_text(strip=True)
                miad_raw = cols[5].get_text(" ", strip=True)

                depo_fiyat_raw = cols[6].get_text(strip=True).replace("₺", "").replace("TL", "").replace(",", ".").strip()
                try:
                    depo_fiyat = float(re.findall(r'[\d\.]+', depo_fiyat_raw)[0])
                except Exception:
                    depo_fiyat = 0.0

                satis_cell = cols[7]
                satis_span = satis_cell.find("span", class_="product-title")
                satis_fiyat_raw = (satis_span.get_text(strip=True) if satis_span else satis_cell.get_text(strip=True)).replace("₺", "").replace("TL", "").replace(",", ".").strip()
                try:
                    satis_fiyat = float(re.findall(r'[\d\.]+', satis_fiyat_raw)[0])
                except Exception:
                    satis_fiyat = depo_fiyat

                mf_small = satis_cell.find("small")
                mf_text = mf_small.get_text(strip=True) if mf_small else "YOK"

                tarih_val = cols[8].get_text(strip=True) if len(cols) > 8 else ""
                not_val = cols[9].get_text(strip=True) if len(cols) > 9 else ""

                norm_u_name = self._normalize_title(u_name)
                resolved_bc = self._resolve_offer_barcode(u_name, norm_u_name)

                all_parsed.append({
                    "teklif_no": t_no,
                    "katil_url": katil_href,
                    "urun_adi": u_name,
                    "norm_name": norm_u_name,
                    "barcode": resolved_bc,
                    "kalan_stok": stok_val,
                    "ekleyen": ekleyen,
                    "miad": miad_raw,
                    "depo_fiyati": depo_fiyat,
                    "satis_fiyati": satis_fiyat,
                    "mf": mf_text,
                    "tarih": tarih_val,
                    "not": not_val
                })
        return all_parsed

    async def _fetch_all_active_offers(self, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """
        Sitedeki tüm aktif teklifleri paralel olarak çeker ve önbelleğe alır (~1.5 sn).
        Oturum düşmüşse otomatik olarak çerezleri temizleyip yeniden giriş yapar.
        """
        async with self._lock:
            now = time.time()
            if not force_refresh and self._cached_offers and (now - self._cache_timestamp) < self._cache_ttl:
                return self._cached_offers

            if not await self.login():
                return self._cached_offers or []

            client = await self._get_client()
            try:
                tasks = [client.get(f"{self.BASE_URL}/teklifler/{i}", timeout=12.0) for i in range(1, 11)]
                resps = await asyncio.gather(*tasks, return_exceptions=True)
                all_parsed = self._parse_offer_pages(resps)

                # Eğer 0 teklif döndüyse oturum düşmüş olabilir; zorla taze giriş yapıp tekrar dene
                if not all_parsed:
                    logger.info("[EczaneTakas] 0 teklif döndü, oturum yenilenip tekrar deneniyor...")
                    if await self.login(force_fresh=True):
                        tasks = [client.get(f"{self.BASE_URL}/teklifler/{i}", timeout=12.0) for i in range(1, 11)]
                        resps = await asyncio.gather(*tasks, return_exceptions=True)
                        all_parsed = self._parse_offer_pages(resps)

                if all_parsed:
                    self._cached_offers = all_parsed
                    self._cache_timestamp = time.time()
                    logger.info(f"[EczaneTakas] {len(all_parsed)} aktif teklif başarıyla önbelleğe alındı.")
                return self._cached_offers

            except Exception as e:
                logger.error(f"[EczaneTakas] Teklif çekme hatası: {e}")
                return self._cached_offers

    def _normalize_title(self, t: str) -> str:
        """İlaç ismini karşılaştırma için temizler ve kanonik hale getirir."""
        if not t:
            return ""
        s = t.upper()
        repl = {'İ': 'I', 'I': 'I', 'Ş': 'S', 'Ğ': 'G', 'Ü': 'U', 'Ö': 'O', 'Ç': 'C', 'ı': 'I', 'ş': 'S', 'ğ': 'G', 'ü': 'U', 'ö': 'O', 'ç': 'C'}
        for k, v in repl.items():
            s = s.replace(k, v)
        # Binlik ayırıcı noktaları birleştir (örn: 2.000 -> 2000, 5.000 -> 5000)
        s = re.sub(r'(\d)\.(\d{3})\b', r'\1\2', s)
        s = re.sub(r'\bI\.U\.?\b', 'IU', s)
        s = re.sub(r'\bFILM\s*KAPLI\s*TABLET\b', 'TB', s)
        s = re.sub(r'\bFILM\s*TABLET\b', 'TB', s)
        s = re.sub(r'\bTABLET\b', 'TB', s)
        s = re.sub(r'\bFTB\.?\b', 'TB', s)
        s = re.sub(r'\bF\.TB\.?\b', 'TB', s)
        s = re.sub(r'\bTB\.?\b', 'TB', s)
        s = re.sub(r'\bTAB\.?\b', 'TB', s)
        s = re.sub(r'\bKAPSUL\b', 'KAP', s)
        s = re.sub(r'\bCAP\.?\b', 'KAP', s)
        s = re.sub(r'\bKAP\.?\b', 'KAP', s)
        s = re.sub(r'\bSUSPANSIYON\b', 'SUSP', s)
        s = re.sub(r'\bSUSP\.?\b', 'SUSP', s)
        s = re.sub(r'\bSURUP\b', 'SRP', s)
        s = re.sub(r'\bSRP\.?\b', 'SRP', s)
        s = re.sub(r'\s+', ' ', s).strip()
        return s

    def _names_compatible(self, norm_a: str, norm_b: str) -> bool:
        """İki normalize ilaç adının aynı ürün olup olmadığını kontrol eder."""
        if not norm_a or not norm_b:
            return False
        if norm_a == norm_b:
            return True

        a_tokens = re.findall(r'[A-Z0-9]+', norm_a)
        b_tokens = re.findall(r'[A-Z0-9]+', norm_b)
        if not a_tokens or not b_tokens:
            return False

        # İlk kelime (marka adı) uyuşmalı
        if a_tokens[0] != b_tokens[0]:
            return False

        # Kritik niteleyiciler (PLUS, FORT/FORTE, PEDIATRIK, DUO vb.) tek taraflı olamaz
        for mod_group in ({"PLUS"}, {"FORT", "FORTE"}, {"PEDIATRIK", "PED"}, {"RETARD", "SR", "XL", "MR"}):
            has_a = any(t in mod_group for t in a_tokens)
            has_b = any(t in mod_group for t in b_tokens)
            if has_a != has_b:
                # İstisna: APRANAX FORT == APRANAX 550 MG
                if mod_group == {"FORT", "FORTE"} and a_tokens[0] == "APRANAX" and ("550" in a_tokens or "550" in b_tokens):
                    continue
                return False

        # Farmasötik form çelişkisi olmamalı (örn: KREM vs SPREY vs MERHEM vs GARGARA)
        form_groups = [
            {"KREM", "KR"},
            {"MERHEM", "POM", "POMAD", "MRH"},
            {"SPREY", "SPR", "NASAL"},
            {"GARGARA", "GARG"},
            {"DAMLA", "GTT"},
            {"AMP", "AMPUL", "FLK", "FLAKON"},
            {"SAMP", "SAMPUAN"},
        ]
        for fg in form_groups:
            fa = any(t in fg for t in a_tokens)
            fb = any(t in fg for t in b_tokens)
            if fa != fb:
                return False

        a_nums = set(re.findall(r'\b\d+\b', norm_a))
        b_nums = set(re.findall(r'\b\d+\b', norm_b))
        if a_nums and b_nums:
            if a_nums == b_nums:
                return True
            if a_nums.issubset(b_nums) or b_nums.issubset(a_nums):
                return True
            if len(a_nums.intersection(b_nums)) >= 2:
                return True
            return False
        elif not a_nums and not b_nums:
            return True
        else:
            a_words = set(w for w in a_tokens[1:] if len(w) > 2 and not w.isdigit() and w not in ('MG', 'ML', 'GR', 'SET', 'ADET', 'MCG'))
            b_words = set(w for w in b_tokens[1:] if len(w) > 2 and not w.isdigit() and w not in ('MG', 'ML', 'GR', 'SET', 'ADET', 'MCG'))
            if a_words and b_words and (a_words.issubset(b_words) or b_words.issubset(a_words)):
                return True
        return False

    def _matches_product(self, offer: Dict[str, Any], query_barcode: str, query_name: str) -> bool:
        """
        Gelen teklifin aranan ilaca ait olup olmadığını 3 aşamalı olarak doğrular:
        1. Çözümlenmiş 13 Haneli Barkod Eşleşmesi
        2. eczanetakas_products.json Üzerinden Barkod Eşleşmesi
        3. Katalog + Akıllı İsim & Dozaj/Form Uyumluluğu
        """
        norm_offer = offer["norm_name"]

        # 1. Teklif üzerinde çözümlenmiş barkod varsa doğrudan kontrol et
        offer_bc = offer.get("barcode", "")
        if query_barcode and offer_bc and query_barcode == offer_bc:
            return True

        # 2. Ön-eşleme sözlüğünden barkod kontrolü
        if query_barcode and query_barcode in self._barcode_to_et_ids:
            mapped_ids = self._barcode_to_et_ids[query_barcode]
            for mid in mapped_ids:
                mapped_info = self._products_map.get(str(mid), {})
                if mapped_info.get("norm_name") == norm_offer:
                    return True

        # 3. İsim bazlı eşleme (query_name barkod rakamlarından ibaretse katalogdan gerçek ürün adını çek!)
        effective_q_name = (query_name or "").strip()
        if effective_q_name.isdigit():
            effective_q_name = ""

        clean_q_name = self._normalize_title(effective_q_name)
        if not clean_q_name and query_barcode:
            cat_p = catalog.get_by_barcode(query_barcode)
            if cat_p and cat_p.get("name"):
                clean_q_name = self._normalize_title(cat_p["name"])

        if clean_q_name:
            if self._names_compatible(norm_offer, clean_q_name):
                return True
            # Servis/kelime araması (örn: kullanıcı doğrudan ürün adı yazdıysa)
            if len(clean_q_name) >= 4 and clean_q_name in norm_offer and not query_barcode.isdigit():
                return True

        return False

    async def query_stock(self, barcode: str, name: str = "") -> DepoUrunSarti:
        """
        EczaneTakas pazarında ilacın aktif tekliflerini sorgular.
        En ucuz veya en avantajlı teklifi ana sonuç olarak döner,
        varsa diğer eczanelerin tekliflerini 'pazaryeri_teklifleri' altında listeler.
        """
        clean_barcode = barcode.strip()
        offers = await self._fetch_all_active_offers()

        matching_offers = [o for o in offers if self._matches_product(o, clean_barcode, name)]

        if not matching_offers:
            # Stok yok
            return DepoUrunSarti(
                depo=DepoKodu.ECZANETAKAS,
                depo_adi="EczaneTakas",
                barkod=clean_barcode,
                urun_adi=name or "Ürün",
                stok_durumu=StokDurumu.YOK,
                stok_adedi=0,
                depocu_satis_fiyati=0.0,
                net_birim_maliyet=0.0,
                net_birim_maliyet_kdvli=0.0,
                mf_metni="YOK",
                miad=None,
                ozel_kampanya_notu=f"Bu ürün için açık teklif yok • Portaldaki toplam açık teklif: {len(offers)} ilan"
            )

        # En avantajlı (en düşük satış fiyatlı) teklifi seç
        matching_offers.sort(key=lambda x: (x["satis_fiyati"], -x["kalan_stok"]))
        best = matching_offers[0]
        final_barcode = clean_barcode if (clean_barcode.isdigit() and len(clean_barcode) >= 8) else (best.get("barcode") or clean_barcode)

        # Toplam kalan stok
        toplam_stok = sum(o["kalan_stok"] for o in matching_offers)

        # KDV Oranı (Varsayılan %10)
        kdv = 10.0
        try:
            from backend.catalog import catalog
            cat_p = catalog.get_by_barcode(clean_barcode)
            if cat_p and cat_p.get("vat") is not None:
                kdv = float(cat_p["vat"])
        except Exception:
            pass

        # EczaneTakas platformundaki satış fiyatı KDV DAHİLDİR
        net_kdvli = float(best["satis_fiyati"])
        net_kdvsiz = round(net_kdvli / (1.0 + kdv / 100.0), 2)
        depo_fiyat = best["depo_fiyati"] or net_kdvsiz

        # İndirim / MF hesabı (DSF KDV hariçtir, net_kdvsiz ile kıyaslanır)
        indirim_pct = 0.0
        if depo_fiyat > 0 and net_kdvsiz < depo_fiyat:
            indirim_pct = round(((depo_fiyat - net_kdvsiz) / depo_fiyat) * 100.0, 1)

        # Diğer satıcı teklifleri (KDV Dahil ve KDV Hariç net maliyetler)
        pazaryeri_list = []
        for o in matching_offers:
            o_kdvli = float(o["satis_fiyati"])
            o_kdvsiz = round(o_kdvli / (1.0 + kdv / 100.0), 2)
            pazaryeri_list.append({
                "teklif_no": o["teklif_no"],
                "satici": o["ekleyen"],
                "stok": o["kalan_stok"],
                "fiyat": o_kdvli,
                "fiyat_kdvli": o_kdvli,
                "fiyat_kdvsiz": o_kdvsiz,
                "mf": o["mf"],
                "miad": o["miad"],
                "not": o["not"],
                "katil_url": o["katil_url"]
            })

        notu = f"{best['ekleyen']} • Miad: {best['miad']}"
        if best["not"]:
            notu += f" • Not: {best['not']}"

        return DepoUrunSarti(
            depo=DepoKodu.ECZANETAKAS,
            depo_adi="EczaneTakas",
            barkod=final_barcode,
            urun_id=best["teklif_no"],
            urun_adi=best["urun_adi"],
            stok_durumu=StokDurumu.VAR if toplam_stok > 0 else StokDurumu.YOK,
            stok_adedi=toplam_stok,
            depocu_satis_fiyati=depo_fiyat,
            perakende_satis_fiyati=0.0,
            kdv_orani=kdv,
            net_birim_maliyet=net_kdvsiz,
            net_birim_maliyet_kdvli=net_kdvli,
            mf_metni=best["mf"],
            toplam_indirim_yuzdesi=indirim_pct,
            miad=best["miad"],
            ozel_kampanya_notu=notu,
            pazaryeri_teklifleri=pazaryeri_list
        )

    async def get_active_offers(self, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """Portaldaki tüm aktif teklifleri (barkod ve fiyat bilgileriyle) döner."""
        return await self._fetch_all_active_offers(force_refresh=force_refresh)

    async def add_to_cart(self, urun_id: str, barcode: str, miktar: int = 1, name: str = "") -> Dict[str, Any]:
        """
        EczaneTakas teklifine katılma (sipariş oluşturma) işlemi.
        Doğrudan 'katil' isteği gönderir veya katılım bağlantısını döner.
        """
        if not await self.login():
            return {"success": False, "message": "EczaneTakas oturumu açılamadı."}

        client = await self._get_client()
        try:
            # 1. Katıl sayfasından form parametrelerini oku
            katil_url = f"{self.BASE_URL}/katil/{urun_id}"
            resp = await client.get(katil_url, timeout=10.0)
            if "giris.php" in str(resp.url).lower():
                self._is_logged_in = False
                if await self.login():
                    resp = await client.get(katil_url, timeout=10.0)

            if resp.status_code != 200:
                return {"success": False, "message": f"Teklif sayfası açılamadı (HTTP {resp.status_code})", "url": katil_url}

            soup = BeautifulSoup(resp.text, "html.parser")
            form = soup.find("form", id="katilfbilgi")
            if not form:
                # Oturum düşmüş olabilir, bir kez daha login deneyip tekrar oku
                self._is_logged_in = False
                if await self.login():
                    resp = await client.get(katil_url, timeout=10.0)
                    soup = BeautifulSoup(resp.text, "html.parser")
                    form = soup.find("form", id="katilfbilgi")

            if not form:
                return {
                    "success": False,
                    "message": f"EczaneTakas Teklif #{urun_id} aktif değil veya katılım formu bulunamadı.",
                    "katil_url": katil_url
                }

            payload = {}
            for inp in form.find_all("input"):
                n = inp.get("name")
                v = inp.get("value", "")
                if n:
                    payload[n] = v

            payload["urunadet"] = str(max(1, int(miktar or 1)))

            # AJAX islem.php isteği
            post_resp = await client.post(f"{self.BASE_URL}/data/islem.php", data=payload, headers={
                "X-Requested-With": "XMLHttpRequest",
                "Referer": katil_url
            }, timeout=12.0)

            res_json = post_resp.json()
            sonuc_txt = BeautifulSoup(str(res_json.get("sonuc") or ""), "html.parser").get_text(" ", strip=True)
            if res_json.get("islem"):
                kalan_val = res_json.get("kalan")
                # Önbellekteki kalan stoğu da anında güncelle
                try:
                    if self._cached_offers:
                        for off in self._cached_offers:
                            if str(off.get("teklif_no")) == str(urun_id):
                                if kalan_val is not None and str(kalan_val).isdigit():
                                    off["kalan_stok"] = int(kalan_val)
                                    off["stok"] = int(kalan_val)
                                else:
                                    cur_kalan = int(off.get("kalan_stok") or off.get("stok") or 0)
                                    new_kalan = max(0, cur_kalan - int(miktar or 1))
                                    off["kalan_stok"] = new_kalan
                                    off["stok"] = new_kalan
                except Exception:
                    pass
                return {
                    "success": True,
                    "message": f"EczaneTakas #{urun_id} teklifine {miktar} adet ile başarıyla katıldınız! {sonuc_txt}".strip(),
                    "teklif_no": urun_id,
                    "kalan": kalan_val
                }
            else:
                return {
                    "success": False,
                    "message": sonuc_txt or "Teklife katılınamadı (yetersiz bakiye/kota veya teklif kapandı).",
                    "teklif_no": urun_id,
                    "katil_url": katil_url
                }

        except Exception as e:
            logger.error(f"[EczaneTakas] add_to_cart hatası: {e}")
            return {
                "success": False,
                "message": f"EczaneTakas teklifine katılma hatası: {str(e)}",
                "katil_url": f"{self.BASE_URL}/katil/{urun_id}"
            }

    async def _fetch_teklif_ekle_meta(self, force_refresh: bool = False) -> Dict[str, Any]:
        """
        EczaneTakas /teklif-ekle sayfasından giriş yapmış eczanenin 'ekleyen' ID'sini,
        güncel ürün seçeneklerini (<select name="urun">) ve gruptaki eczaneleri (<select name="uyeler[]">) çeker.
        """
        async with self._offer_form_lock:
            now = time.time()
            if (
                not force_refresh
                and self._offer_form_cache
                and (now - self._offer_form_cache_ts) < self._offer_form_ttl
                and self._offer_form_cache.get("ekleyen")
            ):
                return self._offer_form_cache

            if not await self.login():
                return {"success": False, "auth_error": True, "message": "EczaneTakas oturumu açılamadı. Lütfen Ayarlar > Depolar ekranından giriş bilgilerinizi kontrol edin."}

            client = await self._get_client()
            form_url = f"{self.BASE_URL}/teklif-ekle"
            try:
                resp = await client.get(form_url, timeout=12.0)
                if "giris.php" in str(resp.url).lower() or "teklifekle" not in resp.text:
                    self.is_logged_in = False
                    if await self.login(force_fresh=True):
                        resp = await client.get(form_url, timeout=12.0)

                if resp.status_code != 200 or "teklifekle" not in resp.text:
                    return {"success": False, "message": "EczaneTakas Teklif Ekleme formu okunamadı."}

                soup = BeautifulSoup(resp.text, "html.parser")
                form = soup.find("form", id="teklifekle")
                if not form:
                    return {"success": False, "message": "EczaneTakas teklif formu (#teklifekle) bulunamadı."}

                ekleyen_inp = form.find("input", attrs={"name": "ekleyen"})
                ekleyen_val = str(ekleyen_inp.get("value") or "").strip() if ekleyen_inp else ""

                products: List[Dict[str, Any]] = []
                products_by_id: Dict[int, Dict[str, Any]] = {}
                urun_sel = form.find("select", attrs={"name": "urun"})
                if urun_sel:
                    for opt in urun_sel.find_all("option"):
                        raw_v = str(opt.get("value") or "").strip()
                        if not raw_v.isdigit():
                            continue
                        pid = int(raw_v)
                        if pid < 1:
                            continue
                        pname = opt.get_text(" ", strip=True)
                        if not pname:
                            continue
                        pnorm = self._normalize_title(pname)
                        entry = {"id": pid, "name": pname, "norm_name": pnorm}
                        products.append(entry)
                        products_by_id[pid] = entry

                pharmacies: List[Dict[str, str]] = []
                uyeler_sel = form.find("select", attrs={"name": "uyeler[]"})
                if uyeler_sel:
                    for opt in uyeler_sel.find_all("option"):
                        uid = str(opt.get("value") or "").strip()
                        uname = opt.get_text(" ", strip=True)
                        if uid and uname:
                            pharmacies.append({"id": uid, "name": uname})

                meta = {
                    "success": True,
                    "ekleyen": ekleyen_val,
                    "products": products,
                    "products_by_id": products_by_id,
                    "pharmacies": pharmacies,
                }
                if ekleyen_val and products:
                    self._offer_form_cache = meta
                    self._offer_form_cache_ts = time.time()
                return meta
            except Exception as e:
                logger.error(f"[EczaneTakas] _fetch_teklif_ekle_meta hatası: {e}")
                return {"success": False, "message": f"EczaneTakas form hazırlık hatası: {str(e)}"}

    async def fetch_product_portal_price(self, urun_id: int) -> float:
        """EczaneTakas ajax.php üzerinden ürünün portalda kayıtlı varsayılan fiyatını sorgular."""
        if not urun_id or int(urun_id) < 1:
            return 0.0
        if not await self.login():
            return 0.0
        client = await self._get_client()
        try:
            resp = await client.post(
                f"{self.BASE_URL}/ajax.php",
                data={"id": str(int(urun_id)), "gonderilen": "urun"},
                headers={"X-Requested-With": "XMLHttpRequest", "Referer": f"{self.BASE_URL}/teklif-ekle"},
                timeout=8.0,
            )
            if resp.status_code == 200 and resp.text:
                raw_txt = resp.text.strip()
                data = json.loads(raw_txt)
                if int(data.get("sonuc") or 0) == 1:
                    toplam = str(data.get("toplam") or "").replace(",", ".").strip()
                    if toplam:
                        return round(float(toplam), 2)
        except Exception as e:
            logger.debug(f"[EczaneTakas] ajax.php fiyat okuma uyarısı: {e}")
        return 0.0

    async def prepare_offer_product(self, barcode: str = "", name: str = "", search_term: str = "") -> Dict[str, Any]:
        """
        Aranan ürünü EczaneTakas /teklif-ekle listesindeki ürünlerle otomatik eşleştirir
        veya manuel arama terimine göre aday ürünleri döndürür.
        """
        meta = await self._fetch_teklif_ekle_meta()
        if not meta.get("success"):
            return meta

        products: List[Dict[str, Any]] = meta.get("products") or []
        products_by_id: Dict[int, Dict[str, Any]] = meta.get("products_by_id") or {}
        pharmacies: List[Dict[str, str]] = meta.get("pharmacies") or []

        # Manuel arama modu (kullanıcı açılır listede farklı bir ürün arıyorsa)
        clean_search = str(search_term or "").strip()
        if clean_search:
            norm_q = self._normalize_title(clean_search)
            q_tokens = [t for t in norm_q.split() if t]
            results = []
            for p in products:
                pn = p["norm_name"]
                if norm_q in pn or (q_tokens and all(tok in pn for tok in q_tokens)):
                    results.append({"id": p["id"], "name": p["name"]})
                    if len(results) >= 40:
                        break
            return {
                "success": True,
                "search_mode": True,
                "candidates": results,
                "total_catalog_count": len(products),
            }

        clean_bc = str(barcode or "").strip()
        clean_name = str(name or "").strip()
        if clean_name.isdigit():
            clean_name = ""

        # Katalogdan ek barkodları ve tam ilaç adını topla
        candidate_barcodes: List[str] = []
        if clean_bc:
            candidate_barcodes.append(clean_bc)
            if len(clean_bc) == 14 and clean_bc.startswith("0"):
                candidate_barcodes.append(clean_bc[1:])
            elif len(clean_bc) == 13 and clean_bc.isdigit():
                candidate_barcodes.append("0" + clean_bc)

        cat_item = catalog.get_by_barcode(clean_bc) if clean_bc else None
        if cat_item:
            if not clean_name and cat_item.get("name"):
                clean_name = str(cat_item["name"]).strip()
            for extra_bc in (cat_item.get("all_barcodes") or []):
                ebc = str(extra_bc or "").strip()
                if ebc and ebc not in candidate_barcodes:
                    candidate_barcodes.append(ebc)

        matched_entry: Optional[Dict[str, Any]] = None

        # 1. Ön-eşleme sözlüğünden (eczanetakas_products.json) barkod ile doğrudan ID eşleşmesi
        for bc_try in candidate_barcodes:
            mapped_ids = self._barcode_to_et_ids.get(bc_try) or []
            for mid in mapped_ids:
                if mid in products_by_id:
                    matched_entry = products_by_id[mid]
                    break
            if matched_entry:
                break

        # 2. Canlı ürün listesi üzerinde normalize isim & dozaj/form uyumluluğu
        norm_target = self._normalize_title(clean_name)
        if not matched_entry and norm_target:
            # Önce birebir normalize isim kontrolü
            for p in products:
                if p["norm_name"] == norm_target:
                    matched_entry = p
                    break
            # Ardından akıllı uyumluluk (_names_compatible)
            if not matched_entry:
                compatible_list = [p for p in products if self._names_compatible(p["norm_name"], norm_target)]
                if compatible_list:
                    matched_entry = compatible_list[0]

        # Aday listesi oluştur (seçili ürün en başta + aynı markalı yakın formlar)
        candidates: List[Dict[str, Any]] = []
        seen_cids = set()
        if matched_entry:
            candidates.append({"id": matched_entry["id"], "name": matched_entry["name"]})
            seen_cids.add(matched_entry["id"])

        brand_token = ""
        if norm_target:
            toks = re.findall(r"[A-Z0-9]+", norm_target)
            if toks:
                brand_token = toks[0]
        elif matched_entry:
            toks = re.findall(r"[A-Z0-9]+", matched_entry["norm_name"])
            if toks:
                brand_token = toks[0]

        if brand_token and len(brand_token) >= 2:
            for p in products:
                if p["id"] in seen_cids:
                    continue
                if p["norm_name"].startswith(brand_token):
                    candidates.append({"id": p["id"], "name": p["name"]})
                    seen_cids.add(p["id"])
                    if len(candidates) >= 20:
                        break

        portal_price = 0.0
        if matched_entry:
            portal_price = await self.fetch_product_portal_price(matched_entry["id"])

        return {
            "success": True,
            "matched": matched_entry is not None,
            "urun_id": matched_entry["id"] if matched_entry else 0,
            "urun_adi": matched_entry["name"] if matched_entry else "",
            "portal_price": portal_price,
            "ekleyen": meta.get("ekleyen") or "",
            "candidates": candidates,
            "pharmacies": pharmacies,
            "total_catalog_count": len(products),
        }

    async def create_offer(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        EczaneTakas üzerinde yeni kampanya / takas teklifi oluşturur ve yayına alır.
        POST https://eczanetakas.com/data/islem.php
        """
        try:
            urun_id = int(params.get("urun_id") or params.get("urun") or 0)
        except Exception:
            urun_id = 0
        if urun_id < 1:
            return {"success": False, "message": "Lütfen EczaneTakas ürün listesinden geçerli bir ürün seçin."}

        try:
            adet = int(params.get("adet") or 0)
        except Exception:
            adet = 0
        if adet < 1:
            return {"success": False, "message": "Satılacak kutu adedi en az 1 olmalıdır."}

        try:
            minumum = int(params.get("minumum") or params.get("min_alim") or 1)
        except Exception:
            minumum = 1
        if minumum < 1:
            minumum = 1
        if minumum > adet:
            return {"success": False, "message": f"Minimum alım adedi ({minumum}), toplam satılacak adetten ({adet}) büyük olamaz."}

        try:
            sart1 = max(1, int(params.get("alimsarti1") or params.get("sart_alinan") or 1))
        except Exception:
            sart1 = 1
        try:
            sart2 = max(0, int(params.get("alimsarti2") or params.get("sart_hediye") or 0))
        except Exception:
            sart2 = 0

        try:
            komisyon_raw = float(str(params.get("komisyon") or "0").replace(",", ".").strip())
        except Exception:
            komisyon_raw = 0.0
        if komisyon_raw < 0 or komisyon_raw >= 100:
            return {"success": False, "message": "Komisyon / ek iskonto oranı 0 ile 99 arasında olmalıdır."}
        komisyon_str = str(int(komisyon_raw)) if abs(komisyon_raw - round(komisyon_raw)) < 1e-6 else f"{komisyon_raw:.2f}"

        try:
            baz_fiyat = float(str(params.get("baz_fiyat") or "0").replace(",", ".").strip())
        except Exception:
            baz_fiyat = 0.0

        if baz_fiyat <= 0 and (params.get("fiyat") is not None):
            try:
                f_part = int(str(params.get("fiyat") or "0").strip())
                k_part = str(params.get("kusurat") or "00").strip().zfill(2)[:2]
                baz_fiyat = float(f"{f_part}.{k_part}")
            except Exception:
                baz_fiyat = 0.0

        if baz_fiyat <= 0:
            return {"success": False, "message": "Geçerli bir Baz Depo Fiyatı girilmelidir."}

        baz_formatted = f"{baz_fiyat:.2f}"
        fiyat_str, kusurat_str = baz_formatted.split(".")

        nf_val = ((float(baz_formatted) * sart1) / float(sart1 + sart2)) * (1.0 - (komisyon_raw / 100.0))
        netfiyat_str = f"{nf_val:.2f}"

        miad_str = str(params.get("miad") or "").strip()
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", miad_str):
            return {"success": False, "message": "Lütfen geçerli bir Miad Tarihi seçin (YYYY-AA-GG)."}

        hedef_str = "1" if str(params.get("hedef") or "0").strip() == "1" else "0"
        secili_uyeler = params.get("uyeler") or []
        if isinstance(secili_uyeler, (str, int)):
            secili_uyeler = [str(secili_uyeler)]
        secili_uyeler = [str(u).strip() for u in secili_uyeler if str(u).strip()]
        if hedef_str == "1" and not secili_uyeler:
            return {"success": False, "message": "Hedef olarak 'Özel' seçildiğinde en az 1 eczane seçmelisiniz."}

        aciklama_str = str(params.get("aciklama") or "").strip()
        bitis_aktif = bool(params.get("bitis_aktif"))
        teklifbitis_str = str(params.get("teklifbitis") or "").strip()
        if bitis_aktif and teklifbitis_str and not re.match(r"^\d{4}-\d{2}-\d{2}$", teklifbitis_str):
            return {"success": False, "message": "Teklif bitiş tarihi geçersiz formatta."}

        meta = await self._fetch_teklif_ekle_meta()
        if not meta.get("success") or not meta.get("ekleyen"):
            meta = await self._fetch_teklif_ekle_meta(force_refresh=True)
        if not meta.get("success") or not meta.get("ekleyen"):
            return {"success": False, "message": meta.get("message") or "EczaneTakas oturum bilgisi (ekleyen ID) alınamadı."}

        import urllib.parse
        ekleyen_id = str(meta["ekleyen"]).strip()

        def _build_encoded_form(ek_id: str) -> bytes:
            pairs = [
                ("teklif-ekle", ""),
                ("ekleyen", ek_id),
                ("netfiyat", netfiyat_str),
                ("urun", str(urun_id)),
                ("adet", str(adet)),
                ("minumum", str(minumum)),
                ("alimsarti1", str(sart1)),
                ("alimsarti2", str(sart2)),
                ("komisyon", komisyon_str),
                ("fiyat", fiyat_str),
                ("kusurat", kusurat_str),
                ("miad", miad_str),
                ("hedef", hedef_str),
            ]
            if hedef_str == "1" and secili_uyeler:
                for uid in secili_uyeler:
                    pairs.append(("uyeler[]", uid))
            pairs.append(("aciklama", aciklama_str))
            if bitis_aktif and teklifbitis_str:
                pairs.append(("kontrol", "on"))
                pairs.append(("teklifbitis", teklifbitis_str))
            else:
                pairs.append(("teklifbitis", ""))
            return urllib.parse.urlencode(pairs).encode("utf-8")

        client = await self._get_client()
        req_headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": f"{self.BASE_URL}/teklif-ekle",
        }
        try:
            post_resp = await client.post(
                f"{self.BASE_URL}/data/islem.php",
                content=_build_encoded_form(ekleyen_id),
                headers=req_headers,
                timeout=15.0,
            )
            raw_body = (post_resp.text or "").lstrip("\ufeff").strip()
            # Oturum düşmüşse bir kez taze giriş yapıp tekrar dene
            if "giris.php" in str(post_resp.url).lower() or (post_resp.status_code == 200 and not raw_body.startswith("{")):
                self.is_logged_in = False
                if await self.login(force_fresh=True):
                    fresh_meta = await self._fetch_teklif_ekle_meta(force_refresh=True)
                    ekleyen_id = str(fresh_meta.get("ekleyen") or ekleyen_id).strip()
                    post_resp = await client.post(
                        f"{self.BASE_URL}/data/islem.php",
                        content=_build_encoded_form(ekleyen_id),
                        headers=req_headers,
                        timeout=15.0,
                    )
                    raw_body = (post_resp.text or "").lstrip("\ufeff").strip()

            if post_resp.status_code != 200:
                return {
                    "success": False,
                    "message": f"EczaneTakas sunucusu yanıt vermedi (HTTP {post_resp.status_code}).",
                }

            if not raw_body.startswith("{"):
                clean_txt = BeautifulSoup(raw_body, "html.parser").get_text(" ", strip=True)[:220]
                return {
                    "success": False,
                    "message": clean_txt or "EczaneTakas beklenmeyen bir yanıt döndürdü.",
                }

            res_json = json.loads(raw_body)
            sonuc_clean = BeautifulSoup(str(res_json.get("sonuc") or ""), "html.parser").get_text(" ", strip=True)
            if res_json.get("islem"):
                # Açılan kampanyanın aramalarda anında görünmesi için önbelleği sıfırla
                self._cached_offers = []
                self._cache_timestamp = 0.0
                return {
                    "success": True,
                    "message": sonuc_clean or "Teklifiniz EczaneTakas'ta başarıyla yayına alındı!",
                    "netfiyat": netfiyat_str,
                    "baz_fiyat": baz_formatted,
                    "mf": f"{sart1}+{sart2}" if sart2 > 0 else "1+0",
                    "adet": adet,
                    "portal_url": f"{self.BASE_URL}/tekliflerim/",
                }
            else:
                return {
                    "success": False,
                    "message": sonuc_clean or "EczaneTakas teklifi kabul etmedi. Lütfen alanları kontrol edin.",
                }
        except Exception as e:
            logger.error(f"[EczaneTakas] create_offer hatası: {e}")
            return {
                "success": False,
                "message": f"EczaneTakas kampanya oluşturma hatası: {str(e)}",
            }

    async def search_product(self, query: str, include_equivalents: bool = False, is_background: bool = False) -> List[DepoUrunSarti]:
        """BaseDepoAdapter arayüzü uyumluluğu."""
        clean_q = str(query or "").strip()
        if not clean_q:
            return []
        if clean_q.isdigit() and len(clean_q) >= 8:
            res = await self.query_stock(barcode=clean_q, name="")
        else:
            res = await self.query_stock(barcode=clean_q, name=clean_q)

        if res.stok_durumu == StokDurumu.VAR:
            return [res]
        return []

    async def close(self):
        """HTTP istemcisini kapatır."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None


