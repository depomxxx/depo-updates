# -*- coding: utf-8 -*-
"""
backend/tria_client.py
-----------------------
Tria Eczane Otomasyon Sistemi (Oracle 11g/12c/19c) Veri Erişim & Analiz Modülü.
Eczane raf stoğu, aylık nakit fişli ve SGK reçeteli satış hareketlerini (ÇIKIŞ),
depolardan gelen alış faturalarını (GİRİŞ) ve günün kritik/azalan stok çıkışlarını sorgular.
"""

import os
import sys
import time
import datetime
from typing import Dict, Any, List, Optional, Tuple

try:
    import oracledb
except ImportError:
    oracledb = None

LATIN1_TR_TRANS = str.maketrans({
    '\xdd': 'İ', '\xfd': 'ı', '\xde': 'Ş', '\xfe': 'ş', '\xd0': 'Ğ', '\xf0': 'ğ',
    'Ý': 'İ', 'ý': 'ı', 'Þ': 'Ş', 'þ': 'ş', 'Ð': 'Ğ', 'ð': 'ğ'
})

EXCLUDE_MAL_KODLARI = {
    '0020934', '0026445', '0042923', '0042925', '0042926', '0111629', '0272017', '0272050'
}

def fix_tria_str(val: Any) -> str:
    """TRIA Oracle veritabanından gelen Türkçe karakterleri standartlaştırır."""
    if val is None:
        return ""
    if isinstance(val, (bytes, bytearray)):
        for enc in ('iso-8859-9', 'windows-1254', 'utf-8', 'cp857'):
            try:
                decoded = val.decode(enc)
                if decoded and all(c.isprintable() or c.isspace() for c in decoded):
                    val = decoded
                    break
            except Exception:
                continue
        if isinstance(val, (bytes, bytearray)):
            val = val.decode('iso-8859-9', errors='replace')
    s = str(val).strip()
    return s.translate(LATIN1_TR_TRANS).rstrip('*').strip()


def to_short_path(path: str) -> str:
    """Windows'ta Türkçe/özel karakter içeren yolları 8.3 kısa dosya adına dönüştürür (Oracle ODPI-C UTF-8 fix)."""
    if not path or not os.path.exists(path):
        return path
    if os.name == 'nt':
        try:
            import ctypes
            buf = ctypes.create_unicode_buffer(1024)
            res = ctypes.windll.kernel32.GetShortPathNameW(path, buf, 1024)
            if res > 0 and buf.value:
                return buf.value
        except Exception:
            pass
    return path

class TriaOracleClient:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.oracle_client_initialized = False
        self._init_oracle_client()

    def _init_oracle_client(self):
        """Oracle Client (Thick Mode) ve network_admin ayarlarını hazırlar."""
        if oracledb is None or self.oracle_client_initialized:
            return

        client_dir = os.path.join(self.base_dir, "oracle_client", "instantclient_19_23")
        net_admin = os.path.join(self.base_dir, "oracle_client", "network_admin")
        
        # Eğer paket içindeki oracle_client bulunamazsa tipik konumlardan dene
        if not os.path.exists(client_dir):
            user_profile = os.environ.get("USERPROFILE", "")
            candidate_dirs = [
                os.path.join(user_profile, "OneDrive", "Masaüstü", "betaprim", "EdaPrim", "instantclient_19_23"),
                os.path.join(user_profile, "Desktop", "betaprim", "EdaPrim", "instantclient_19_23"),
                r"C:\instantclient_19_23",
                r"C:\oracle\instantclient_19_23"
            ]
            for c_dir in candidate_dirs:
                if os.path.exists(c_dir):
                    client_dir = c_dir
                    break

        try:
            os.makedirs(net_admin, exist_ok=True)
            sqlnet_path = os.path.join(net_admin, "sqlnet.ora")
            if not os.path.exists(sqlnet_path):
                with open(sqlnet_path, "w", encoding="utf-8") as f:
                    f.write("SQLNET.AUTHENTICATION_SERVICES = (NONE)\n")
        except Exception as e:
            print(f"[TriaClient] sqlnet.ora oluşturma uyarısı: {e}")

        try:
            if os.path.exists(client_dir):
                os.environ["PATH"] = client_dir + os.pathsep + os.environ.get("PATH", "")
                if hasattr(os, "add_dll_directory"):
                    try:
                        os.add_dll_directory(client_dir)
                    except Exception:
                        pass
            short_lib = to_short_path(client_dir) if os.path.exists(client_dir) else None
            short_cfg = to_short_path(net_admin) if os.path.exists(net_admin) else None

            # Eğer Windows 10/11'de 8.3 kısa yol kapalıysa ve yolda Türkçe karakter (Masaüstü vb.) varsa
            # geçici olarak client_dir dizinine geçip '.' ile başlatarak DPI-1047 hatasını tamamen önle:
            orig_cwd = os.getcwd()
            try:
                if short_lib and any(ord(c) > 127 for c in short_lib):
                    os.chdir(client_dir)
                    oracledb.init_oracle_client(lib_dir=".")
                else:
                    kwargs = {}
                    if short_lib:
                        kwargs["lib_dir"] = short_lib
                    if short_cfg and not any(ord(c) > 127 for c in short_cfg):
                        kwargs["config_dir"] = short_cfg
                    oracledb.init_oracle_client(**kwargs)
            finally:
                try:
                    os.chdir(orig_cwd)
                except Exception:
                    pass

            self.oracle_client_initialized = True
            print(f"[TriaClient] Oracle Instant Client Thick Mode aktif: {client_dir}")
        except Exception as e:
            if "already been initialized" in str(e):
                self.oracle_client_initialized = True
            else:
                print(f"[TriaClient] Oracle Client başlatma hatası: {e}")

    def _persist_env_settings(self, host: str, port: str, sid: str, user: str, password: str):
        """Başarılı Tria bağlantı bilgilerini .env dosyasına ve ortam değişkenlerine kalıcı olarak yazar."""
        clean_host = (host or "").strip()
        os.environ["TRIA_DB_HOST"] = clean_host
        os.environ["TRIA_DB_PORT"] = str(port).strip()
        os.environ["TRIA_DB_SID"] = (sid or "ORCL").strip()
        os.environ["TRIA_DB_USER"] = (user or "EDA").strip()
        os.environ["TRIA_DB_PASSWORD"] = (password or "EDA").strip()
        # Yerel test/yedek (127.0.0.1 / localhost veya 1522/XEPDB1 test yedek DB) bağlantılarını .env dosyasına kalıcı yazma
        if clean_host.lower() in ("127.0.0.1", "localhost", "::1") or str(port).strip() == "1522" or (sid or "").strip().upper() == "XEPDB1":
            return
        try:
            env_path = os.path.join(self.base_dir, ".env")
            if os.path.exists(env_path):
                with open(env_path, "r", encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()
                updates = {
                    "TRIA_DB_HOST": clean_host,
                    "TRIA_DB_PORT": str(port).strip(),
                    "TRIA_DB_SID": (sid or "ORCL").strip(),
                    "TRIA_DB_USER": (user or "EDA").strip(),
                    "TRIA_DB_PASSWORD": (password or "EDA").strip(),
                }
                seen = set()
                new_lines = []
                for line in lines:
                    s = line.strip()
                    if s and not s.startswith("#") and "=" in s:
                        k = s.split("=", 1)[0].strip()
                        if k in updates:
                            new_lines.append(f"{k}={updates[k]}\n")
                            seen.add(k)
                            continue
                    new_lines.append(line)
                for k, v in updates.items():
                    if k not in seen:
                        new_lines.append(f"{k}={v}\n")
                with open(env_path, "w", encoding="utf-8") as f:
                    f.writelines(new_lines)
        except Exception:
            pass

    def get_config(self) -> Dict[str, str]:
        """Güncel bağlantı ayarlarını döndürür."""
        return {
            "user": os.environ.get("TRIA_DB_USER", "EDA") or "EDA",
            "password": os.environ.get("TRIA_DB_PASSWORD", "EDA") or "EDA",
            "host": os.environ.get("TRIA_DB_HOST", "192.168.1.57") or "192.168.1.57",
            "port": os.environ.get("TRIA_DB_PORT", "1521") or "1521",
            "sid": os.environ.get("TRIA_DB_SID", "ORCL") or "ORCL",
        }

    def _open_and_verify_conn(self, host: str, port: str, sid: str, user: str, password: str, timeout: float = 3.0):
        """Oracle bağlantısını açar, Tria servisi uyumluluk bilgilerini ayarlar ve canlı sorgu ile doğrular."""
        dsn = f"{host}:{port}/{sid}"
        last_err = None
        for attempt in range(2):
            conn = None
            try:
                conn = oracledb.connect(user=user, password=password, dsn=dsn, tcp_connect_timeout=timeout)
                try:
                    conn.module = "Tria.exe"
                    conn.action = "Tria"
                except Exception:
                    pass
                cur = conn.cursor()
                cur.execute("SELECT 1 FROM TBL_MAL_TANIM WHERE ROWNUM = 1")
                cur.fetchone()
                cur.close()
                return conn
            except Exception as err:
                last_err = err
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass
                err_str = str(err)
                # DPY-4011 / ORA-00028 / ORA-03113 anlık ağ/oturum kopmalarında 1 kez hızlı tekrar dene
                if attempt == 0 and any(k in err_str for k in ("DPY-4011", "ORA-00028", "ORA-03113", "ORA-03135", "DPI-1080")):
                    time.sleep(0.15)
                    continue
                break
        raise last_err

    def get_connection(self, host: Optional[str] = None, port: Optional[str] = None,
                       sid: Optional[str] = None, user: Optional[str] = None,
                       password: Optional[str] = None):
        """Oracle bağlantısını açar (otomatik port, SID, şema ve ağ sunucusu düzeltme destekli - DPY-6005 & DPY-4011 korumalı)."""
        if oracledb is None:
            raise RuntimeError("oracledb kütüphanesi yüklü değil. 'pip install oracledb' gereklidir.")

        import socket
        self._init_oracle_client()
        cfg = self.get_config()
        active_host = (host or cfg.get("host") or "192.168.1.57").strip()
        active_port = str(port or cfg.get("port") or "1521").strip()
        active_sid = (sid or cfg.get("sid") or "ORCL").strip()
        active_user = (user or cfg.get("user") or "EDA").strip()
        active_pwd = (password or cfg.get("password") or "EDA").strip()

        # Bilinen eczane sunucu profilleri (IP -> varsayılan şema/şifre)
        host_default_creds = {
            "192.168.1.155": ("ARASTIRMA", "ARASTIRMA", "ORCL"),
            "192.168.1.57": ("EDA", "EDA", "ORCL"),
            "SERVER": ("EDA", "EDA", "ORCL"),
        }

        def _is_tcp_open(h: str, p: str, t: float = 0.45) -> bool:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(t)
                    return s.connect_ex((h, int(p))) == 0
            except Exception:
                return False

        last_error = None
        is_backup_target = (
            active_host.lower() in ("127.0.0.1", "localhost")
            or active_port == "1522"
            or active_sid.upper() == "XEPDB1"
        )
        # 1) Eğer mevcut host canlı bir eczane sunucusuysa (1521/ORCL) ve TCP portu açıksa hemen dene
        if not is_backup_target and _is_tcp_open(active_host, active_port, 0.45):
            # Eğer IP bilinen bir eczane sunucusuysa ve kullanıcı açıkça parametre vermediyse o eczanenin şemasını da adaylara ekle
            try_creds = [(active_user, active_pwd, active_sid)]
            if active_host in host_default_creds and not user:
                def_u, def_p, def_s = host_default_creds[active_host]
                if (def_u, def_p, def_s) not in try_creds:
                    try_creds.append((def_u, def_p, def_s))
            for u_try, p_try, s_try in try_creds:
                try:
                    conn = self._open_and_verify_conn(active_host, active_port, s_try, u_try, p_try, timeout=3.0)
                    if (u_try, p_try, s_try) != (active_user, active_pwd, active_sid):
                        self._persist_env_settings(active_host, active_port, s_try, u_try, p_try)
                    return conn
                except Exception as e:
                    last_error = e

        # 2) Canlı eczane sunucularını (Araştırma 192.168.1.155, Eda 192.168.1.57, SERVER) 1521/ORCL öncelikli tara
        lan_hosts = list(dict.fromkeys(["192.168.1.155", "192.168.1.57", "SERVER", active_host]))
        lan_hosts = [h for h in lan_hosts if h and h.lower() not in ("127.0.0.1", "localhost")]
        cand_ports = list(dict.fromkeys(["1521", active_port, "1522"]))
        cand_sids = list(dict.fromkeys(["ORCL", active_sid, "XEPDB1", "XE"]))

        for cp_port in cand_ports:
            for ch in lan_hosts:
                if not _is_tcp_open(ch, cp_port, 0.45):
                    continue
                # Bu IP için en uygun şema/şifre sırasını oluştur
                creds_order = []
                if ch in host_default_creds:
                    du, dp, _ = host_default_creds[ch]
                    creds_order.append((du, dp))
                for c_pair in [(active_user, active_pwd), ("ARASTIRMA", "ARASTIRMA"), ("EDA", "EDA")]:
                    if c_pair not in creds_order:
                        creds_order.append(c_pair)

                for cs in cand_sids:
                    for cu, cp_pwd in creds_order:
                        try:
                            conn = self._open_and_verify_conn(ch, str(cp_port), cs, cu, cp_pwd, timeout=2.5)
                            self._persist_env_settings(ch, str(cp_port), cs, cu, cp_pwd)
                            return conn
                        except Exception as e:
                            last_error = e

        # 3) Hala bağlanamadıysa tüm yerel ağda (192.168.x.1..254) otomatik keşif yap
        disc = self.discover_tria_host()
        if disc.get("found") and disc.get("host"):
            dh = disc["host"]
            dp = str(disc.get("port", "1521"))
            ds = disc.get("sid", "ORCL")
            du = disc.get("user", "EDA")
            dpw = disc.get("password", "EDA")
            try:
                conn = self._open_and_verify_conn(dh, dp, ds, du, dpw, timeout=3.0)
                self._persist_env_settings(dh, dp, ds, du, dpw)
                return conn
            except Exception as e:
                last_error = e

        # 4) En son çare olarak yerel (127.0.0.1) veritabanını dene (.env dosyasını bozmadan)
        for cp_port in cand_ports:
            if _is_tcp_open("127.0.0.1", cp_port, 0.3):
                for cs in ("XEPDB1", "ORCL", "XE"):
                    for cu, cp_pwd in [("EDA", "EDA"), ("ARASTIRMA", "ARASTIRMA"), (active_user, active_pwd)]:
                        try:
                            return self._open_and_verify_conn("127.0.0.1", str(cp_port), cs, cu, cp_pwd, timeout=2.0)
                        except Exception as e:
                            last_error = e

        if last_error:
            raise last_error
        raise RuntimeError(f"Tria Oracle sunucusuna ({active_host}:{active_port}/{active_sid}) bağlanılamadı.")

    def ping(self, host: Optional[str] = None, port: Optional[str] = None,
             sid: Optional[str] = None, user: Optional[str] = None,
             password: Optional[str] = None) -> Dict[str, Any]:
        """Tria Oracle veritabanına ping atar ve bağlantı durumunu test eder."""
        cfg = self.get_config()
        active_host = host or cfg.get("host") or "192.168.1.57"
        active_port = str(port or cfg.get("port") or "1521")
        active_sid = sid or cfg.get("sid") or "ORCL"
        active_user = user or cfg.get("user") or "EDA"
        active_pwd = password or cfg.get("password") or "EDA"
        t0 = time.time()
        try:
            with self.get_connection(host=active_host, port=active_port, sid=active_sid, user=active_user, password=active_pwd) as conn:
                cfg_now = self.get_config()
                active_host = cfg_now.get("host", active_host)
                active_port = cfg_now.get("port", active_port)
                active_sid = cfg_now.get("sid", active_sid)
                active_user = cfg_now.get("user", active_user)
                latency_ms = round((time.time() - t0) * 1000, 2)
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM TBL_RECETE")
                recete_count = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM TBL_MAL_TANIM")
                mal_count = cur.fetchone()[0]

                # Bugün kesilen reçete sayısı
                cur.execute("SELECT COUNT(*) FROM TBL_RECETE WHERE RECETE_TARIHI >= TRUNC(SYSDATE)")
                today_recete = cur.fetchone()[0]

                # Toplam alış faturası sayısı
                cur.execute("SELECT COUNT(*) FROM TBL_BELGE WHERE TIP_NO IN ('AAF', 'KAF', 'TGF')")
                fatura_count = cur.fetchone()[0]

                return {
                    "success": True,
                    "connected": True,
                    "message": f"Tria Oracle bağlantısı başarılı ({latency_ms} ms)",
                    "latency_ms": latency_ms,
                    "version": conn.version,
                    "host": active_host,
                    "port": active_port,
                    "sid": active_sid,
                    "user": active_user,
                    "stats": {
                        "recete_sayisi": recete_count,
                        "kayitli_urun_sayisi": mal_count,
                        "bugun_recete_sayisi": today_recete,
                        "fatura_sayisi": fatura_count
                    }
                }
        except Exception as e:
            latency_ms = round((time.time() - t0) * 1000, 2)
            err_msg = str(e)
            user_friendly = err_msg
            if "12541" in err_msg:
                user_friendly = f"Oracle Dinleyici Bulunamadı (ORA-12541). '{active_host}' makinesinde {active_port} portunda Oracle listener çalışmıyor veya farklı bir ağdasınız."
            elif "12514" in err_msg:
                user_friendly = f"Veritabanı Servisi Bulunamadı (ORA-12514). '{active_sid}' SID/Servis adı geçersiz."
            elif "01017" in err_msg:
                user_friendly = f"Kullanıcı adı veya şifre hatalı (ORA-01017). '{active_user}' şeması için şifreyi kontrol ediniz."
            return {
                "success": False,
                "connected": False,
                "message": user_friendly,
                "latency_ms": latency_ms,
                "host": active_host,
                "port": active_port,
                "sid": active_sid,
                "user": active_user,
                "error": err_msg
            }

    def get_product_analysis(self, query: str, barcode: str = "") -> Dict[str, Any]:
        """
        Belirtilen barkod veya ilaç adı için Tria veritabanından:
        1. Anlık raf/mevcut stok (Golden Formula: İade/Emanet düzeltmeli)
        2. Son 6 takvim ayı Nakit ve Reçeteli çıkış adetleri (ÇIKIŞ)
        3. Son depolardan gelen alış faturaları (GİRİŞ)
        4. Aylık ortalama çıkış hızı ve kalan gün tahmini
        5. Akıllı sipariş önerisi
        döndürür.
        """
        clean_q = (barcode or query or "").strip()
        if not clean_q:
            return {"found": False, "message": "Barkod veya ürün belirtilmedi."}

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                # 1. Ürünü bul (Öncelik: Barkod, sonra Mal Adı / Kodu)
                product_row = None
                
                # A) Eğer doğrudan barkod verilmişse veya clean_q barkod ise
                target_barcodes = set()
                if barcode and barcode.strip().isdigit() and len(barcode.strip()) >= 8:
                    target_barcodes.add(barcode.strip())
                if clean_q and clean_q.isdigit() and len(clean_q) >= 8:
                    target_barcodes.add(clean_q)

                if target_barcodes:
                    # Kanonik EAN ve alternatif barkodları ekle
                    try:
                        from backend.catalog import catalog
                        for b in list(target_barcodes):
                            can = catalog.resolve_canonical_barcode(b)
                            if can:
                                target_barcodes.add(can)
                            cat_p = catalog.get_by_barcode(b)
                            if cat_p:
                                for ab in cat_p.get("all_barcodes", []):
                                    if str(ab).strip():
                                        target_barcodes.add(str(ab).strip())
                    except Exception:
                        pass

                    bc_list = list(target_barcodes)
                    for bc in bc_list:
                        cur.execute("""
                            SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(b.BARKOD, :b) as BARKOD
                            FROM TBL_MAL_TANIM t
                            LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                            WHERE (b.BARKOD = :b OR t.MAL_KODU = :b)
                              AND (t.PASIF IS NULL OR t.PASIF = 0)
                              AND ROWNUM <= 1
                        """, {"b": bc})
                        product_row = cur.fetchone()
                        if product_row:
                            break

                # B) Sayısal Kod araması
                if not product_row and clean_q.isdigit():
                    cur.execute("""
                        SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(b.BARKOD, '') as BARKOD
                        FROM TBL_MAL_TANIM t
                        LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                        WHERE (t.MAL_KODU = :raw_q OR TO_CHAR(t.ID) = :raw_q)
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                          AND ROWNUM <= 1
                    """, {"raw_q": clean_q})
                    product_row = cur.fetchone()

                # C) İsim araması
                if not product_row:
                    tr_query = clean_q.upper().replace("I", "İ").replace("ı", "I")
                    cur.execute("""
                        SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(b.BARKOD, '') as BARKOD
                        FROM TBL_MAL_TANIM t
                        LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                        WHERE (UPPER(t.MAL_ADI) LIKE :q OR UPPER(t.MAL_ADI) LIKE :raw_q)
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                          AND ROWNUM <= 1
                    """, {"q": f"%{tr_query}%", "raw_q": f"%{clean_q.upper()}%"})
                    product_row = cur.fetchone()

                if not product_row:
                    return {
                        "found": False,
                        "connected": True,
                        "kaynak": "TRIA",
                        "message": f"'{clean_q}' Tria kayıtlarında bulunamadı."
                    }

                mal_id, mal_kodu, mal_adi, found_barkod = product_row
                final_barcode = barcode or found_barkod or clean_q
                try:
                    from backend.catalog import catalog
                    can_final = catalog.resolve_canonical_barcode(final_barcode)
                    if can_final:
                        final_barcode = can_final
                except Exception:
                    pass

                # 2. Anlık Altın Stok (Golden Formula)
                cur.execute("""
                    SELECT NVL(
                        SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) - 
                        SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END), 
                        0
                    ) 
                    FROM TBL_MAL_MIKTARLAR m 
                    WHERE m.MAL_ID = :mid
                """, {"mid": mal_id})
                stok_val = cur.fetchone()[0] or 0.0
                stok = int(round(stok_val)) if stok_val == int(stok_val) else round(stok_val, 1)

                # 3. Son 6 Aylık Satış / Çıkış Trendi (Nakit vs Reçeteli)
                cur.execute("""
                    SELECT 
                        TO_CHAR(BELGE_TARIHI, 'YYYY-MM') as AY,
                        SUM(CASE WHEN UPPER(TRIM(BELGE_TURU)) = 'FIS' AND BELGE_TIP_NO IN ('01', '06') THEN MIKTAR ELSE 0 END) as NAKIT,
                        SUM(CASE WHEN UPPER(TRIM(BELGE_TURU)) = 'RECETE' THEN MIKTAR ELSE 0 END) as RECETELI,
                        SUM(CASE 
                            WHEN UPPER(TRIM(BELGE_TURU)) = 'FIS' AND BELGE_TIP_NO IN ('01', '06') THEN MIKTAR 
                            WHEN UPPER(TRIM(BELGE_TURU)) = 'RECETE' THEN MIKTAR 
                            ELSE 0 
                        END) as TOPLAM
                    FROM TBL_MAL_HAREKET
                    WHERE MAL_KODU = :pcode
                      AND BELGE_TARIHI >= ADD_MONTHS(TRUNC(SYSDATE, 'MM'), -6)
                      AND BELGE_TARIHI <= SYSDATE + 1
                    GROUP BY TO_CHAR(BELGE_TARIHI, 'YYYY-MM')
                    ORDER BY AY ASC
                """, {"pcode": mal_kodu})
                
                rows = cur.fetchall()

                ay_isimleri = {
                    "01": "Ocak", "02": "Şubat", "03": "Mart", "04": "Nisan",
                    "05": "Mayıs", "06": "Haziran", "07": "Temmuz", "08": "Ağustos",
                    "09": "Eylül", "10": "Ekim", "11": "Kasım", "12": "Aralık"
                }

                activity_by_month = {}
                for r in rows:
                    ay_str = str(r[0])
                    activity_by_month[ay_str] = {
                        "nakit": int(r[1] or 0),
                        "receteli": int(r[2] or 0),
                        "toplam": int(r[3] or 0)
                    }

                # Kesintisiz son 6 takvim ayını oluştur
                today = datetime.date.today()
                aylik_cikislar = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    m_str = f"{m_calc:02d}"
                    ym_key = f"{y_calc}-{m_str}"
                    is_current_month = (i == 0)
                    suffix = " (Bu Ay)" if is_current_month else ""
                    ay_label = f"{ay_isimleri.get(m_str, m_str)} '{str(y_calc)[-2:]}{suffix}"
                    
                    act = activity_by_month.get(ym_key, {"nakit": 0, "receteli": 0, "toplam": 0})
                    aylik_cikislar.append({
                        "ay": ym_key,
                        "label": ay_label,
                        "is_current": is_current_month,
                        "nakit": act["nakit"],
                        "receteli": act["receteli"],
                        "toplam": act["toplam"]
                    })

                # Ortalama aylık ve günlük çıkış hesabı
                gecmis_aylar = aylik_cikislar[:-1] if len(aylik_cikislar) > 1 else aylik_cikislar
                gecmis_sum = sum(x["toplam"] for x in gecmis_aylar)
                if gecmis_sum > 0:
                    ort_aylik = round(gecmis_sum / max(1, len(gecmis_aylar)), 1)
                else:
                    ort_aylik = round(sum(x["toplam"] for x in aylik_cikislar) / max(1, len(aylik_cikislar)), 1)
                
                ort_gunluk = round(ort_aylik / 30.0, 2)

                # Kalan gün ve stok durumu
                if ort_gunluk > 0:
                    kalan_gun = int(round(stok / ort_gunluk))
                else:
                    kalan_gun = 999 if stok > 0 else 0

                toplam_6_aylik_cikis = sum(x["toplam"] for x in aylik_cikislar)
                is_hareketsiz = (stok <= 0 and toplam_6_aylik_cikis == 0)

                if is_hareketsiz:
                    stok_status = "HAREKET YOK"
                    stok_status_color = "slate"
                    onerilen_siparis = 1
                elif stok <= 0:
                    stok_status = "TÜKENDİ"
                    stok_status_color = "red"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(1, hedef_stok - stok)
                elif kalan_gun < 10:
                    stok_status = "KRİTİK AZ"
                    stok_status_color = "amber"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                elif kalan_gun <= 30:
                    stok_status = "YETERLİ"
                    stok_status_color = "emerald"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                else:
                    stok_status = "YÜKSEK STOK"
                    stok_status_color = "sky"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)

                # 4. Son Alış Faturaları / Depo Girişleri (GİRİŞ)
                cur.execute("""
                    SELECT 
                        TO_CHAR(b.BELGE_TARIHI, 'YYYY-MM-DD') as TARIH,
                        NVL(UTL_RAW.CAST_TO_RAW(b.CARI_ADI), UTL_RAW.CAST_TO_RAW('DIGER DEPO')) as DEPO,
                        NVL(d.MIKTAR, 0) as ADET,
                        NVL(d.MF_MIKTAR, 0) as MF,
                        ROUND(NVL(d.BIRIM_FIYAT, 0), 2) as BIRIM_FIYAT,
                        ROUND(NVL(d.NET_FIYAT, 0), 2) as MALIYET,
                        NVL(b.BELGE_NO, NVL(b.D_FATURA_NO, '')) as FATURA_NO
                    FROM TBL_BELGE_DETAY d
                    JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                    WHERE d.MAL_KODU = :pcode 
                      AND b.TIP_NO IN ('AAF', 'KAF', 'TGF')
                    ORDER BY b.BELGE_TARIHI DESC, b.ID DESC
                """, {"pcode": mal_kodu})
                giris_rows = cur.fetchmany(6)

                son_girisler = []
                toplam_giren_kutu = 0
                for gr in giris_rows:
                    g_adet = int(gr[2] or 0)
                    g_mf = int(gr[3] or 0)
                    g_maliyet = round(float(gr[5] or 0.0), 2)
                    g_birim = round(float(gr[4] or 0.0), 2)
                    top_satir = g_adet + g_mf
                    toplam_giren_kutu += top_satir
                    son_girisler.append({
                        "tarih": str(gr[0]),
                        "depo": fix_tria_str(gr[1]),
                        "adet": g_adet,
                        "mf": g_mf,
                        "toplam_adet": top_satir,
                        "birim_fiyat": g_birim,
                        "maliyet": g_maliyet,
                        "fatura_no": str(gr[6])
                    })

                return {
                    "found": True,
                    "connected": True,
                    "kaynak": "TRIA",
                    "otomasyon_adi": "Tria Eczane",
                    "urun_id": mal_id,
                    "mal_id": mal_id,
                    "mal_kodu": str(mal_kodu),
                    "mal_adi": fix_tria_str(mal_adi),
                    "barkod": final_barcode,
                    "stok": stok,
                    "stok_depo": 0,
                    "stok_raf": stok,
                    "stok_acik": 0,
                    "kalan_gun": kalan_gun,
                    "stok_status": stok_status,
                    "stok_status_color": stok_status_color,
                    "ort_aylik_cikis": ort_aylik,
                    "ort_gunluk_cikis": ort_gunluk,
                    "onerilen_siparis": onerilen_siparis,
                    "aylik_cikislar": aylik_cikislar,
                    "son_girisler": son_girisler,
                    "toplam_giren_kutu": toplam_giren_kutu,
                    "hareketsiz_kart": is_hareketsiz,
                    "hareketsiz_aciklama": "Eczanenizde bu ürün için son 6 aydır çıkış hareketi bulunmuyor. Depo ve piyasa koşulları doğrudan üretici EAN barkodu üzerinden sunulmaktadır."
                }

        except Exception as e:
            return {
                "found": False,
                "connected": False,
                "kaynak": "TRIA",
                "error": str(e),
                "message": f"Tria stok ve hareket sorgusu hatası: {str(e)}"
            }

    def get_critical_stock_sales(self, limit: int = 0, max_stock_threshold: int = 5, max_stock_days: int = 21) -> List[Dict[str, Any]]:
        """
        Bugün eczaneden çıkışı olan (reçeteli veya nakit) ve stoğu azalan (veya kritik seviyedeki)
        ürünleri listeler. 21 günden fazla stok olan ürünleri mantıken sipariş listesine dahil etmez.
        """
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                
                # 1. Adım: Bugün çıkışı olan ürünleri ve adetlerini çek (~10-15 ms)
                cur.execute("""
                    SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as BUGUN_ADET
                    FROM TBL_MAL_HAREKET mh
                    WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE)
                      AND (
                          UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE' 
                          OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                      )
                    GROUP BY mh.MAL_KODU
                    HAVING SUM(ABS(mh.MIKTAR)) > 0
                """)
                today_rows = cur.fetchall()
                if not today_rows:
                    return []
                
                today_map = {
                    r[0]: int(r[1] or 0) for r in today_rows 
                    if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI
                }
                prod_codes = list(today_map.keys())
                if not prod_codes:
                    return []

                # 2. Adım: Sadece bugün satılan ürünler için son 30 günün çıkışlarını çek (900'lük chunk)
                month_map = {}
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i+900]
                    params = {f'k{idx}': c for idx, c in enumerate(chunk)}
                    binds = ','.join(f':{k}' for k in params.keys())
                    cur.execute(f"""
                        SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as AY_ADET
                        FROM TBL_MAL_HAREKET mh
                        WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 30
                          AND (
                              UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE' 
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                          )
                          AND mh.MAL_KODU IN ({binds})
                        GROUP BY mh.MAL_KODU
                    """, params)
                    for r in cur.fetchall():
                        month_map[r[0]] = int(r[1] or 0)

                # 3. Adım: Geçmişte MF'li Alım Kontrolü (TBL_BELGE_DETAY)
                mf_history_map = {}
                try:
                    for i in range(0, len(prod_codes), 900):
                        chunk = prod_codes[i:i+900]
                        params = {f'k{idx}': c for idx, c in enumerate(chunk)}
                        binds = ','.join(f':{k}' for k in params.keys())
                        cur.execute(f"""
                            SELECT MAL_KODU, MIKTAR, MF_MIKTAR, TO_CHAR(BELGE_TARIHI, 'YYYY-MM-DD'), ALIM_COUNT
                            FROM (
                                SELECT 
                                    d.MAL_KODU,
                                    d.MIKTAR,
                                    d.MF_MIKTAR,
                                    b.BELGE_TARIHI,
                                    COUNT(*) OVER (PARTITION BY d.MAL_KODU) as ALIM_COUNT,
                                    ROW_NUMBER() OVER (PARTITION BY d.MAL_KODU ORDER BY b.BELGE_TARIHI DESC, b.ID DESC) as RN
                                FROM TBL_BELGE_DETAY d
                                JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                                WHERE d.MAL_KODU IN ({binds})
                                  AND b.TIP_NO IN ('AAF', 'KAF', 'TGF')
                                  AND NVL(d.MF_MIKTAR, 0) > 0
                            ) WHERE RN = 1
                        """, params)
                        for r in cur.fetchall():
                            m_k = str(r[0])
                            m_adet = int(r[1] or 0)
                            m_mf = int(r[2] or 0)
                            raw_date = str(r[3] or '')
                            if raw_date and '-' in raw_date:
                                parts = raw_date.split('-')
                                fmt_date = f"{parts[2]}.{parts[1]}.{parts[0]}" if len(parts) == 3 else raw_date
                            else:
                                fmt_date = raw_date
                            alim_count = int(r[4] or 1)

                            mf_kisa = f"Son: {m_adet}+{m_mf} MF" if m_adet > 0 else f"Son: +{m_mf} MF"
                            mf_bilgi = f"Geçmişte {alim_count} kez MF ile alındı (Son Alım: {m_adet}+{m_mf} MF, {fmt_date})"

                            mf_history_map[m_k] = {
                                "var": True,
                                "sayisi": alim_count,
                                "son_adet": m_adet,
                                "son_mf": m_mf,
                                "son_tarih": fmt_date,
                                "kisa": mf_kisa,
                                "bilgi": mf_bilgi
                            }
                except Exception as e_mf:
                    print(f"[Tria] Geçmiş MF sorgu uyarısı: {e_mf}")

                # 4. Adım: İlgili ürünlerin temel tanım, fiyat, gerçek altın stok ve barkodlarını çek
                candidate_items = []
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i+900]
                    params = {f'k{idx}': c for idx, c in enumerate(chunk)}
                    binds = ','.join(f':{k}' for k in params.keys())
                    cur.execute(f"""
                        SELECT 
                            t.ID, 
                            t.MAL_KODU, 
                            UTL_RAW.CAST_TO_RAW(t.MAL_ADI), 
                            NVL(t.SATIS_FIYATI_1, 0) as PSF,
                            NVL((
                                SELECT SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) - 
                                       SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END)
                                FROM TBL_MAL_MIKTARLAR m WHERE m.MAL_ID = t.ID
                            ), 0) as STOK,
                            NVL((
                                SELECT MAX(b.BARKOD) FROM TBL_MAL_BARKOD_TANIM b 
                                WHERE b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                            ), '') as BARKOD
                        FROM TBL_MAL_TANIM t
                        WHERE t.MAL_KODU IN ({binds})
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                    """, params)
                    for r in cur.fetchall():
                        m_id, m_kodu, m_adi, psf, stok_val, barkod = r
                        stok = int(round(float(stok_val or 0)))
                        bugun = today_map.get(m_kodu, 0)
                        aylik = month_map.get(m_kodu, bugun)
                        psf_val = round(float(psf or 0.0), 2)
                        barkod_val = str(barkod or m_kodu).strip()

                        # Kanonik EAN çözümleme
                        try:
                            from backend.catalog import catalog
                            canonical_bc = catalog.resolve_canonical_barcode(barkod_val)
                            if canonical_bc:
                                barkod_val = canonical_bc
                        except Exception:
                            pass

                        # Kalan stok gün hesabı ve 21 gün kuralı
                        effective_aylik = max(int(aylik or 0), int(bugun or 1))
                        gunluk_ort = max(0.1, round(effective_aylik / 30.0, 2))
                        stok_gun = round((stok * 30.0) / effective_aylik, 1) if stok > 0 else 0.0

                        # 21 Günden fazla stok varsa mantıken sipariş listesine dahil etme
                        if max_stock_days > 0 and stok > 0 and stok_gun > max_stock_days:
                            continue

                        # Günlük ortalama ve ihtiyaç tahmini
                        onerilen = max(bugun, int(gunluk_ort * 7) - max(0, stok))
                        if onerilen <= 0:
                            onerilen = max(1, bugun)

                        mf_hist = mf_history_map.get(str(m_kodu), {})
                        has_past_mf = bool(mf_hist.get("var", False))

                        candidate_items.append({
                            "urun_id": m_id,
                            "mal_kodu": m_kodu,
                            "urun_adi": fix_tria_str(m_adi),
                            "barkod": barkod_val,
                            "stok": stok,
                            "stok_gun": stok_gun,
                            "bugun_cikis": bugun,
                            "aylik_cikis": aylik,
                            "psf": psf_val,
                            "onerilen_siparis": max(1, onerilen),
                            "gecmis_mf_var": has_past_mf,
                            "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                            "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                            "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                            "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                            "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                            "gecmis_mf_bilgi": mf_hist.get("bilgi", "")
                        })

                # Akıllı Sıralama: Önce eksiye düşenler (stok < 0), sonra tükenenler (stok == 0), sonra kalan stok gününe göre artan
                candidate_items.sort(key=lambda x: (
                    0 if x["stok"] < 0 else (1 if x["stok"] == 0 else 2),
                    x["stok"] if x["stok"] < 0 else x["stok_gun"],
                    -x["bugun_cikis"]
                ))

                if limit and limit > 0:
                    return candidate_items[:limit]
                return candidate_items
        except Exception as e:
            print(f"[Tria] get_critical_stock_sales hatası: {e}")
            return []

    def get_product_vat(self, barcode_or_code: str) -> Optional[float]:
        """Ürünün Tria veritabanındaki resmi KDV oranını döner (örn: 1.0, 10.0, 20.0)."""
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                cur.execute("""
                    SELECT k.KDV
                    FROM TBL_MAL_TANIM t
                    LEFT JOIN TBL_MAL_BARKOD_TANIM b ON t.ID = b.MAL_TANIM_ID
                    LEFT JOIN TBL_KDV_TANIM k ON t.SATIS_KDV_ID = k.ID
                    WHERE (b.BARKOD = :q OR t.MAL_KODU = :q) AND (t.PASIF IS NULL OR t.PASIF = 0)
                      AND ROWNUM = 1
                """, {"q": str(barcode_or_code).strip()})
                row = cur.fetchone()
                if row and row[0] is not None:
                    return float(row[0])
        except Exception as e:
            print(f"[Tria] get_product_vat hatası: {e}")
        return None

    def get_product_equivalents(self, barcode_or_code: str) -> Dict[str, Any]:
        """
        Belirtilen barkod veya mal koduna ait SGK Eşdeğer Grubunu (ESDEGER_GRUP_KODU) tespit eder.
        Gruptaki tüm muadilleri anlık raf stoğu, son 30 gün çıkışları ve geçmiş MF alımlarıyla döndürür.
        """
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                q = str(barcode_or_code).strip()
                cur.execute("""
                    SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), t.ESDEGER_GRUP_KODU
                    FROM TBL_MAL_TANIM t
                    LEFT JOIN TBL_MAL_BARKOD_TANIM b ON t.ID = b.MAL_TANIM_ID
                    WHERE (b.BARKOD = :q OR t.MAL_KODU = :q) AND (t.PASIF IS NULL OR t.PASIF = 0)
                      AND ROWNUM = 1
                """, {"q": q})
                r = cur.fetchone()

                # Barkod veya mal kodu ile bulunamadıysa (örn: ilaç adı girildiyse) katalogdan barkodunu bul
                if not r or not r[3]:
                    can_bc = None
                    try:
                        from backend.catalog import catalog
                        if not (q.isdigit() and len(q) >= 8):
                            suggs = catalog.search_suggestions(q, limit=1)
                            if suggs and suggs[0].get("barcode"):
                                can_bc = suggs[0]["barcode"]
                        else:
                            can_bc = catalog.resolve_canonical_barcode(q)
                    except Exception:
                        pass

                    if can_bc and can_bc.isdigit() and len(can_bc) >= 8:
                        cur.execute("""
                            SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), t.ESDEGER_GRUP_KODU
                            FROM TBL_MAL_TANIM t
                            LEFT JOIN TBL_MAL_BARKOD_TANIM b ON t.ID = b.MAL_TANIM_ID
                            WHERE (b.BARKOD = :b OR t.MAL_KODU = :b) AND (t.PASIF IS NULL OR t.PASIF = 0)
                              AND ROWNUM = 1
                        """, {"b": can_bc})
                        r = cur.fetchone()

                # Hala bulunamadıysa TBL_MAL_TANIM içinde ilaç adıyla eşleştir
                if not r or not r[3]:
                    try:
                        clean_w = [w for w in re.findall(r'[a-zA-Z0-9]+', q) if len(w) >= 3]
                        if clean_w:
                            kw = clean_w[0].upper()
                            cur.execute("""
                                SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), t.ESDEGER_GRUP_KODU
                                FROM TBL_MAL_TANIM t
                                WHERE UPPER(t.MAL_ADI) LIKE :kw || '%'
                                  AND (t.PASIF IS NULL OR t.PASIF = 0)
                                  AND t.ESDEGER_GRUP_KODU IS NOT NULL
                                  AND ROWNUM = 1
                            """, {"kw": kw})
                            r = cur.fetchone()
                    except Exception:
                        pass

                if not r or not r[3]:
                    return {"found": False, "esdeger_kodu": None, "muadiller": [], "message": "SGK eşdeğer grubu bulunamadı."}

                m_id, m_kodu, m_adi, grup_kodu = r
                grup_str = str(grup_kodu).strip()

                cur.execute("""
                    SELECT 
                        t.MAL_KODU,
                        UTL_RAW.CAST_TO_RAW(t.MAL_ADI),
                        NVL(
                            (SELECT MAX(b.BARKOD) FROM TBL_MAL_BARKOD_TANIM b WHERE b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0) AND LENGTH(b.BARKOD) = 13),
                            NVL((SELECT MAX(b.BARKOD) FROM TBL_MAL_BARKOD_TANIM b WHERE b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)), t.MAL_KODU)
                        ) as BARKOD,
                        NVL(t.SATIS_FIYATI_1, 0) as PSF,
                        NVL((
                            SELECT SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) - 
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END)
                            FROM TBL_MAL_MIKTARLAR m WHERE m.MAL_ID = t.ID
                        ), 0) as STOK,
                        NVL((
                            SELECT SUM(ABS(mh.MIKTAR)) FROM TBL_MAL_HAREKET mh 
                            WHERE (mh.MAL_KODU = t.MAL_KODU OR LTRIM(mh.MAL_KODU, '0') = LTRIM(t.MAL_KODU, '0')) 
                              AND mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 30
                              AND (
                                  UPPER(TRIM(mh.BELGE_TURU)) LIKE 'RECET%' 
                                  OR UPPER(TRIM(mh.BELGE_TURU)) LIKE 'REÇET%'
                                  OR UPPER(TRIM(mh.BELGE_TURU)) IN ('FIS', 'FİŞ', 'FATURA', 'PS', 'SF')
                                  OR mh.BELGE_TIP_NO IN ('01', '06', '02', '03')
                              )
                        ), 0) as CIKIS_30GUN,
                        (
                            SELECT TO_CHAR(d.MIKTAR) || '+' || TO_CHAR(d.MF_MIKTAR) || ' MF (' || TO_CHAR(b.BELGE_TARIHI, 'DD.MM.YYYY') || ')'
                            FROM TBL_BELGE_DETAY d
                            JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                            WHERE (d.MAL_KODU = t.MAL_KODU OR LTRIM(d.MAL_KODU, '0') = LTRIM(t.MAL_KODU, '0')) AND b.TIP_NO IN ('AAF', 'KAF', 'TGF') AND NVL(d.MF_MIKTAR, 0) > 0
                              AND ROWNUM = 1
                        ) as SON_MF_BILGI,
                        NVL(t.KAMU_ISKONTO_ORANI, 0) as KAMU_ISK,
                        NVL(t.DEPOCU_SATIS_FIYATI, 0) as DSF,
                        NVL(t.ALIS_FIYATI_1, 0) as ALIS_1,
                        NVL((SELECT MAX(k.KDV) FROM TBL_KDV_TANIM k WHERE k.ID = t.SATIS_KDV_ID), 10) as KDV_ORAN
                    FROM TBL_MAL_TANIM t
                    WHERE t.ESDEGER_GRUP_KODU = :grp AND (t.PASIF IS NULL OR t.PASIF = 0)
                    ORDER BY STOK DESC, CIKIS_30GUN DESC
                """, {"grp": grup_str})

                items = []
                current_kamu_kari = 0.0
                for row in cur.fetchall():
                    kodu = str(row[0])
                    adi = fix_tria_str(row[1])
                    barkod = str(row[2])
                    psf = round(float(row[3] or 0), 2)
                    stok = int(round(float(row[4] or 0)))
                    cikis30 = int(round(float(row[5] or 0)))
                    mf_bilgi = str(row[6] or "").strip() if row[6] else ""
                    kamu_isk = round(float(row[7] or 0.0), 2)
                    dsf_val = round(float(row[8] or 0.0), 2)
                    alis1_val = round(float(row[9] or 0.0), 2)
                    kdv_oran = float(row[10] or 10.0)
                    kdv_div = 1.0 + (kdv_oran / 100.0) if kdv_oran > 0 else 1.10

                    # Eğer Tria'da kamu iskontosu 0 görünüyorsa ancak DSF veya Alış fiyatından kamu iskontosu anlaşılıyorsa çıkar
                    dsf_brut = (psf / kdv_div) * 0.78125 if psf > 0 else 0.0
                    if kamu_isk <= 0.0 and dsf_brut > 0 and alis1_val > 0 and alis1_val < (dsf_brut * 0.985):
                        derived_isk = round((1.0 - (alis1_val / dsf_brut)) * 100.0, 1)
                        if 1.5 <= derived_isk <= 75.0:
                            kamu_isk = derived_isk

                    ksf = round(psf * (1.0 - (kamu_isk / 100.0)), 2) if (psf > 0 and kamu_isk > 0) else round(psf, 2)

                    if alis1_val > 0:
                        net_kdvsiz = alis1_val
                    elif dsf_val > 0:
                        net_kdvsiz = round(dsf_val * (1.0 - (kamu_isk / 100.0)), 2) if dsf_val >= (dsf_brut * 0.95) else dsf_val
                    elif dsf_brut > 0:
                        net_kdvsiz = round(dsf_brut * (1.0 - (kamu_isk / 100.0)), 2)
                    else:
                        net_kdvsiz = 0.0

                    net_kdvli = round(net_kdvsiz * kdv_div, 2)
                    kamu_kari = round(ksf - net_kdvli, 2) if (ksf > 0 and net_kdvli > 0) else 0.0
                    perakende_kari = round(psf - net_kdvli, 2) if (psf > 0 and net_kdvli > 0) else 0.0
                    is_curr = (kodu == str(m_kodu))
                    if is_curr:
                        current_kamu_kari = kamu_kari

                    items.append({
                        "kod": kodu,
                        "mal_kodu": kodu,
                        "ad": adi,
                        "urun_adi": adi,
                        "barkod": barkod,
                        "etiket_fiyati": psf,
                        "psf": psf,
                        "kamu_fiyati": ksf,
                        "ksf": ksf,
                        "kamu_iskontosu": kamu_isk,
                        "birim_maliyet": net_kdvsiz,
                        "net_birim_maliyet": net_kdvsiz,
                        "birim_maliyet_kdvli": net_kdvli,
                        "net_birim_maliyet_kdvli": net_kdvli,
                        "kamu_kari": kamu_kari,
                        "perakende_kari": perakende_kari,
                        "stok": stok,
                        "cikis_30gun": cikis30,
                        "gecmis_mf_var": bool(mf_bilgi),
                        "gecmis_mf_bilgi": mf_bilgi,
                        "is_current": is_curr
                    })

                for it in items:
                    kf = round(it["kamu_kari"] - current_kamu_kari, 2)
                    it["kar_farki"] = kf
                    it["is_more_profitable"] = (kf > 0)
                    it["kar_artis_yuzdesi"] = round((kf / current_kamu_kari * 100.0), 1) if (current_kamu_kari > 0 and kf > 0) else 0.0

                items.sort(key=lambda x: (x.get("kamu_kari") or 0.0, x.get("stok") or 0), reverse=True)

                en_karli = None
                muadil_kar_avantaji = 0.0
                for it in items:
                    if it.get("kar_farki", 0.0) > 0 and not it.get("is_current"):
                        it["is_best_deal"] = True
                        en_karli = it
                        muadil_kar_avantaji = it["kar_farki"]
                        break

                return {
                    "found": True,
                    "esdeger_kodu": grup_str,
                    "count": len(items),
                    "en_karli_muadil": en_karli,
                    "muadil_kar_avantaji": muadil_kar_avantaji,
                    "current_kamu_kari": current_kamu_kari,
                    "muadiller": items
                }
        except Exception as e:
            print(f"[Tria] get_product_equivalents hatası: {e}")
            return {"found": False, "error": str(e), "esdeger_kodu": None, "muadiller": []}

    def list_available_schemas(self) -> Dict[str, Any]:
        """Oracle veritabanındaki kayıtlı eczane şemalarını listeler (EdaPrim list_available_schemas)."""
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                cur.execute("""
                    SELECT USERNAME FROM ALL_USERS 
                    WHERE USERNAME NOT IN (
                        'SYS', 'SYSTEM', 'ANONYMOUS', 'APEX_PUBLIC_USER', 'APPQOSSYS',
                        'CTXSYS', 'DBSNMP', 'DIP', 'EXFSYS', 'FLOWS_FILES', 'MDDATA',
                        'MDSYS', 'MGMT_VIEW', 'OLAPSYS', 'ORACLE_OCM', 'ORDDATA',
                        'ORDPLUGINS', 'ORDSYS', 'OUTLN', 'OWBSYS', 'OWBSYS_AUDIT',
                        'SCOTT', 'SI_INFORMTN_SCHEMA', 'SPATIAL_CSW_ADMIN_USR',
                        'SPATIAL_WFS_ADMIN_USR', 'SYSMAN', 'WMSYS', 'XDB', 'XS$NULL'
                    )
                    AND USERNAME NOT LIKE 'APEX_%'
                    ORDER BY USERNAME
                """)
                schemas = [r[0] for r in cur.fetchall() if r and r[0] != 'XS$NULL']
                return {"success": True, "schemas": schemas}
        except Exception as e:
            return {"success": False, "error": str(e), "schemas": []}

    def discover_tria_host(self) -> Dict[str, Any]:
        """Ağda veya yerel makinede TRIA Oracle sunucusunu tüm alt ağda paralel tarayarak otomatik keşfeder."""
        import socket
        import concurrent.futures

        local_ip = "127.0.0.1"
        prefix = "192.168.1"
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            prefix = ".".join(local_ip.split(".")[:3])
        except Exception:
            pass

        # Öncelikli bilinen IP'ler + tüm alt ağ (1..254)
        priority_ips = [f"{prefix}.57", f"{prefix}.155", f"{prefix}.100", f"{prefix}.200", f"{prefix}.10"]
        all_ips = list(dict.fromkeys(
            priority_ips + [f"{prefix}.{i}" for i in range(1, 255) if f"{prefix}.{i}" != local_ip]
        ))

        def _probe_port(ip_port):
            ip, p = ip_port
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.25)
            try:
                if sock.connect_ex((ip, p)) == 0:
                    return (ip, str(p))
            except Exception:
                pass
            finally:
                sock.close()
            return None

        targets = [(ip, p) for p in (1521, 1522) for ip in all_ips]
        open_endpoints = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=96) as ex:
            for res in ex.map(_probe_port, targets):
                if res:
                    open_endpoints.append(res)

        # En sonda yerel makineyi aday olarak ekle (ağda canlı sunucu varsa ağ sunucusu önceliklidir)
        for p in (1521, 1522):
            res = _probe_port(("127.0.0.1", p))
            if res:
                open_endpoints.append(res)

        # Açık portlarda geçerli Tria şemasını doğrula (en güncel reçete tarihli ve 1521 portlu olanı seç)
        candidates_found = []
        if oracledb is not None:
            self._init_oracle_client()
            for cand_ip, cand_port in open_endpoints:
                for cand_sid in ("ORCL", "XEPDB1", "XE"):
                    for cand_u, cand_pw in (("ARASTIRMA", "ARASTIRMA"), ("EDA", "EDA")):
                        try:
                            conn = oracledb.connect(
                                user=cand_u,
                                password=cand_pw,
                                dsn=f"{cand_ip}:{cand_port}/{cand_sid}",
                                tcp_connect_timeout=1.5
                            )
                            cur = conn.cursor()
                            cur.execute("SELECT MAX(RECETE_TARIHI) FROM TBL_RECETE")
                            max_dt = cur.fetchone()[0]
                            conn.close()
                            max_dt_str = str(max_dt or "")
                            match_info = {
                                "success": True,
                                "found": True,
                                "host": cand_ip,
                                "port": cand_port,
                                "sid": cand_sid,
                                "user": cand_u,
                                "password": cand_pw,
                                "max_date": max_dt_str,
                                "_score": (
                                    1 if cand_ip != "127.0.0.1" else 0,
                                    1 if str(cand_port) == "1521" else 0,
                                    max_dt_str,
                                ),
                                "message": f"Ağda canlı TRIA Oracle sunucusu bulundu: {cand_ip}:{cand_port}/{cand_sid} ({cand_u})"
                            }
                            candidates_found.append(match_info)
                        except Exception:
                            continue

        if candidates_found:
            candidates_found.sort(key=lambda x: x["_score"], reverse=True)
            best_match = dict(candidates_found[0])
            best_match.pop("_score", None)
            if best_match["host"] != "127.0.0.1":
                self._persist_env_settings(
                    best_match["host"],
                    best_match["port"],
                    best_match["sid"],
                    best_match["user"],
                    best_match["password"],
                )
            return best_match

        if open_endpoints:
            found_ip, found_port = open_endpoints[0]
            return {
                "success": True,
                "found": True,
                "host": found_ip,
                "port": found_port,
                "sid": "ORCL",
                "user": "EDA",
                "message": f"Ağda TRIA Oracle sunucusu bulundu: {found_ip}:{found_port}"
            }
        return {
            "success": False,
            "found": False,
            "host": "192.168.1.57",
            "port": "1521",
            "sid": "ORCL",
            "user": "EDA",
            "message": "Ağda aktif sunucu tespit edilemedi."
        }


# Singleton instance
tria_client = TriaOracleClient()
