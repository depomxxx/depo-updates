import asyncio
import os
import sys
import time
import re
import json
from pathlib import Path
from typing import Optional, List

# Ensure script directory and parent are in sys.path
_script_dir = str(Path(__file__).resolve().parent)
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

# Ensure process runs as Tria.exe on Windows so TriaWinService.exe never kills Oracle sessions (ORA-00028 / DPY-4011)
if __name__ == "__main__" and sys.platform == "win32" and os.environ.get("TRIA_EXE_REEXEC") != "1":
    _exe_name = os.path.basename(sys.executable).lower()
    if _exe_name in ("python.exe", "pythonw.exe"):
        import shutil
        import subprocess
        _exe_dir = Path(sys.executable).resolve().parent
        _target_name = "TriaPcPOS.exe" if _exe_name == "pythonw.exe" else "Tria.exe"
        _tria_exe = _exe_dir / _target_name
        if not _tria_exe.exists():
            try:
                shutil.copy2(sys.executable, _tria_exe)
            except Exception:
                pass
        if not _tria_exe.exists():
            _rt_tria = Path(__file__).resolve().parent / "runtime" / "Tria.exe"
            if _rt_tria.exists():
                _tria_exe = _rt_tria
        if _tria_exe.exists():
            _env = os.environ.copy()
            _env["TRIA_EXE_REEXEC"] = "1"
            _cflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
            subprocess.Popen(
                [str(_tria_exe), *sys.argv],
                cwd=str(Path(__file__).resolve().parent),
                env=_env,
                creationflags=_cflags,
                close_fds=True
            )
            os._exit(0)

# Ensure UTF-8 and valid stdout/stderr handles on Windows (including pythonw / detached mode)
if sys.platform == "win32":
    _log_path = Path(__file__).resolve().parent / "server.log"
    try:
        if sys.stdout is None or not hasattr(sys.stdout, "write"):
            sys.stdout = open(_log_path, "a", encoding="utf-8", buffering=1)
        else:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            sys.stdout.write("")
    except Exception:
        sys.stdout = open(_log_path, "a", encoding="utf-8", buffering=1)
    try:
        if sys.stderr is None or not hasattr(sys.stderr, "write"):
            sys.stderr = sys.stdout
        else:
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
            sys.stderr.write("")
    except Exception:
        sys.stderr = sys.stdout

# Load .env
def load_env():
    env_file = Path(__file__).parent / ".env"
    if env_file.exists():
        with open(env_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    k_clean = k.strip()
                    v_clean = v.strip()
                    if k_clean == "TRIA_DB_HOST" and v_clean.lower() in ("127.0.0.1", "localhost"):
                        v_clean = "192.168.1.155"
                    if k_clean not in os.environ:
                        os.environ[k_clean] = v_clean

load_env()

# Auto-configure PLAYWRIGHT_BROWSERS_PATH if bundled in runtime/playwright-browsers
_base_dir = Path(__file__).resolve().parent
_bundled_browsers = _base_dir / "runtime" / "playwright-browsers"
if _bundled_browsers.exists():
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(_bundled_browsers)


from fastapi import FastAPI, Query, Request, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from backend.query_engine import DepoSorguMotoru
from backend.models import DepoKarsilastirmaRaporu, DepoKodu
from backend.catalog import catalog
from backend.core.session_store import SessionStore
from backend.tria_client import tria_client
from backend.botanik_client import botanik_client
from backend.tebeos_client import tebeos_client
from backend.market.market_engine import RetailMarketEngine
from backend.market.models import MarketPriceReport
from backend.dermo_sync import audit_botanik_dermo_barcodes, apply_botanik_dermo_barcodes, POPULAR_DERMO_BRANDS
from backend.mf_resolver import mf_resolver
from backend.updater import updater
from backend.order_tracker import order_tracker
from backend.license_manager import license_manager

ENV_FILE = Path(__file__).resolve().parent / ".env"
market_engine: Optional[RetailMarketEngine] = None

def get_current_credentials():
    def _is_active(depo: str, has_creds: bool):
        if not has_creds:
            return "0"
        return os.environ.get(f"{depo.upper()}_ACTIVE", "1")

    return {
        "alliance": {
            "pharmacy_code": os.environ.get("ALLIANCE_PHARMACY_CODE", ""),
            "username": os.environ.get("ALLIANCE_USERNAME", ""),
            "password": os.environ.get("ALLIANCE_PASSWORD", ""),
            "active": _is_active("ALLIANCE", bool(os.environ.get("ALLIANCE_PHARMACY_CODE", "").strip() and os.environ.get("ALLIANCE_USERNAME", "").strip() and os.environ.get("ALLIANCE_PASSWORD", "").strip()))
        },
        "selcuk": {
            "username": os.environ.get("SELCUK_USERNAME", ""),
            "password": os.environ.get("SELCUK_PASSWORD", ""),
            "active": _is_active("SELCUK", bool(os.environ.get("SELCUK_USERNAME", "").strip() and os.environ.get("SELCUK_PASSWORD", "").strip()))
        },
        "nevzat": {
            "account_code": os.environ.get("NEVZAT_ACCOUNT_CODE", ""),
            "username": os.environ.get("NEVZAT_USERNAME", ""),
            "password": os.environ.get("NEVZAT_PASSWORD", ""),
            "active": _is_active("NEVZAT", bool(os.environ.get("NEVZAT_ACCOUNT_CODE", "").strip() and os.environ.get("NEVZAT_USERNAME", "").strip() and os.environ.get("NEVZAT_PASSWORD", "").strip()))
        },
        "iskoop": {
            "username": os.environ.get("ISKOOP_USERNAME", ""),
            "password": os.environ.get("ISKOOP_PASSWORD", ""),
            "active": _is_active("ISKOOP", bool(os.environ.get("ISKOOP_USERNAME", "").strip() and os.environ.get("ISKOOP_PASSWORD", "").strip()))
        },
        "bek": {
            "username": os.environ.get("BEK_USERNAME", ""),
            "password": os.environ.get("BEK_PASSWORD", ""),
            "active": _is_active("BEK", bool(os.environ.get("BEK_USERNAME", "").strip() and os.environ.get("BEK_PASSWORD", "").strip()))
        },
        "ecza1": {
            "username": os.environ.get("ECZA1_USERNAME", ""),
            "password": os.environ.get("ECZA1_PASSWORD", ""),
            "active": _is_active("ECZA1", bool(os.environ.get("ECZA1_USERNAME", "").strip() and os.environ.get("ECZA1_PASSWORD", "").strip()))
        },
        "farmazon": {
            "username": os.environ.get("FARMAZON_USERNAME", ""),
            "password": os.environ.get("FARMAZON_PASSWORD", ""),
            "active": _is_active("FARMAZON", bool(os.environ.get("FARMAZON_USERNAME", "").strip() and os.environ.get("FARMAZON_PASSWORD", "").strip()))
        },
        "dna": {
            "username": os.environ.get("DNA_USERNAME", ""),
            "password": os.environ.get("DNA_PASSWORD", ""),
            "active": _is_active("DNA", bool(os.environ.get("DNA_USERNAME", "").strip() and os.environ.get("DNA_PASSWORD", "").strip()))
        },
        "eczatrend": {
            "username": os.environ.get("ECZATREND_USERNAME", ""),
            "password": os.environ.get("ECZATREND_PASSWORD", ""),
            "active": _is_active("ECZATREND", bool(os.environ.get("ECZATREND_USERNAME", "").strip() and os.environ.get("ECZATREND_PASSWORD", "").strip()))
        },
        "eczanetakas": {
            "username": os.environ.get("ECZANETAKAS_USERNAME", "ecz.gamzegultekin@gmail.com"),
            "password": os.environ.get("ECZANETAKAS_PASSWORD", ""),
            "active": _is_active("ECZANETAKAS", bool(os.environ.get("ECZANETAKAS_USERNAME", "").strip() and os.environ.get("ECZANETAKAS_PASSWORD", "").strip()))
        },
        "tria": {
            "host": os.environ.get("TRIA_DB_HOST", "192.168.1.155"),
            "port": os.environ.get("TRIA_DB_PORT", "1521"),
            "sid": os.environ.get("TRIA_DB_SID", "ORCL"),
            "user": os.environ.get("TRIA_DB_USER", "ARASTIRMA"),
            "password": os.environ.get("TRIA_DB_PASSWORD", "ARASTIRMA")
        },
        "botanik": {
            "server": os.environ.get("BOTANIK_DB_SERVER", r"DESKTOP-L6GG7P6\BOTANIKSQL"),
            "database": os.environ.get("BOTANIK_DB_DATABASE", "eczane"),
            "user": os.environ.get("BOTANIK_DB_USER", "sa"),
            "password": os.environ.get("BOTANIK_DB_PASSWORD", "123"),
            "trusted": os.environ.get("BOTANIK_DB_TRUSTED", "false")
        },
        "tebeos": {
            "host": os.environ.get("TEBEOS_DB_HOST", tebeos_client.get_config().get("host", "192.168.1.11")),
            "port": str(os.environ.get("TEBEOS_DB_PORT", "5454")),
            "database": os.environ.get("TEBEOS_DB_DATABASE", "tebeos_db"),
            "user": os.environ.get("TEBEOS_DB_USER", "tebeos"),
            "password": os.environ.get("TEBEOS_DB_PASSWORD", "123")
        },
        "active_otomasyon": os.environ.get("ACTIVE_OTOMASYON", "TRIA")
    }

def save_credentials_to_env(new_creds: dict):
    mapping = {
        ("alliance", "pharmacy_code"): "ALLIANCE_PHARMACY_CODE",
        ("alliance", "username"): "ALLIANCE_USERNAME",
        ("alliance", "password"): "ALLIANCE_PASSWORD",
        ("alliance", "active"): "ALLIANCE_ACTIVE",
        ("selcuk", "username"): "SELCUK_USERNAME",
        ("selcuk", "password"): "SELCUK_PASSWORD",
        ("selcuk", "active"): "SELCUK_ACTIVE",
        ("nevzat", "account_code"): "NEVZAT_ACCOUNT_CODE",
        ("nevzat", "username"): "NEVZAT_USERNAME",
        ("nevzat", "password"): "NEVZAT_PASSWORD",
        ("nevzat", "active"): "NEVZAT_ACTIVE",
        ("iskoop", "username"): "ISKOOP_USERNAME",
        ("iskoop", "password"): "ISKOOP_PASSWORD",
        ("iskoop", "active"): "ISKOOP_ACTIVE",
        ("bek", "username"): "BEK_USERNAME",
        ("bek", "password"): "BEK_PASSWORD",
        ("bek", "active"): "BEK_ACTIVE",
        ("ecza1", "username"): "ECZA1_USERNAME",
        ("ecza1", "password"): "ECZA1_PASSWORD",
        ("ecza1", "active"): "ECZA1_ACTIVE",
        ("farmazon", "username"): "FARMAZON_USERNAME",
        ("farmazon", "password"): "FARMAZON_PASSWORD",
        ("farmazon", "active"): "FARMAZON_ACTIVE",
        ("dna", "username"): "DNA_USERNAME",
        ("dna", "password"): "DNA_PASSWORD",
        ("dna", "active"): "DNA_ACTIVE",
        ("eczatrend", "username"): "ECZATREND_USERNAME",
        ("eczatrend", "password"): "ECZATREND_PASSWORD",
        ("eczatrend", "active"): "ECZATREND_ACTIVE",
        ("eczanetakas", "username"): "ECZANETAKAS_USERNAME",
        ("eczanetakas", "password"): "ECZANETAKAS_PASSWORD",
        ("eczanetakas", "active"): "ECZANETAKAS_ACTIVE",
        ("tria", "host"): "TRIA_DB_HOST",
        ("tria", "port"): "TRIA_DB_PORT",
        ("tria", "sid"): "TRIA_DB_SID",
        ("tria", "user"): "TRIA_DB_USER",
        ("tria", "password"): "TRIA_DB_PASSWORD",
        ("botanik", "server"): "BOTANIK_DB_SERVER",
        ("botanik", "database"): "BOTANIK_DB_DATABASE",
        ("botanik", "user"): "BOTANIK_DB_USER",
        ("botanik", "password"): "BOTANIK_DB_PASSWORD",
        ("botanik", "trusted"): "BOTANIK_DB_TRUSTED",
        ("tebeos", "host"): "TEBEOS_DB_HOST",
        ("tebeos", "port"): "TEBEOS_DB_PORT",
        ("tebeos", "database"): "TEBEOS_DB_DATABASE",
        ("tebeos", "user"): "TEBEOS_DB_USER",
        ("tebeos", "password"): "TEBEOS_DB_PASSWORD",
    }
    
    flat_updates = {}
    for (depo, field), env_var in mapping.items():
        if depo in new_creds and field in new_creds[depo]:
            val = str(new_creds[depo][field]).strip()
            flat_updates[env_var] = val

    # Şifre veya kullanıcı adı eksikse kesinlikle otomatik pasif yap
    req_checks = {
        "ALLIANCE": ["ALLIANCE_PHARMACY_CODE", "ALLIANCE_USERNAME", "ALLIANCE_PASSWORD"],
        "SELCUK": ["SELCUK_USERNAME", "SELCUK_PASSWORD"],
        "NEVZAT": ["NEVZAT_ACCOUNT_CODE", "NEVZAT_USERNAME", "NEVZAT_PASSWORD"],
        "ISKOOP": ["ISKOOP_USERNAME", "ISKOOP_PASSWORD"],
        "BEK": ["BEK_USERNAME", "BEK_PASSWORD"],
        "ECZA1": ["ECZA1_USERNAME", "ECZA1_PASSWORD"],
        "FARMAZON": ["FARMAZON_USERNAME", "FARMAZON_PASSWORD"],
        "DNA": ["DNA_USERNAME", "DNA_PASSWORD"],
        "ECZATREND": ["ECZATREND_USERNAME", "ECZATREND_PASSWORD"],
        "ECZANETAKAS": ["ECZANETAKAS_USERNAME", "ECZANETAKAS_PASSWORD"],
    }
    for depo_prefix, fields in req_checks.items():
        has_all = all(bool(flat_updates.get(f, os.environ.get(f, "")).strip()) for f in fields)
        if not has_all:
            flat_updates[f"{depo_prefix}_ACTIVE"] = "0"

    if "active_otomasyon" in new_creds:
        flat_updates["ACTIVE_OTOMASYON"] = str(new_creds["active_otomasyon"]).strip()

    lines = []
    if ENV_FILE.exists():
        with open(ENV_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()

    updated_keys = set()
    new_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            k, _ = stripped.split("=", 1)
            k = k.strip()
            if k in flat_updates:
                new_lines.append(f"{k}={flat_updates[k]}\n")
                updated_keys.add(k)
                os.environ[k] = flat_updates[k]
                continue
        new_lines.append(line)

    for k, v in flat_updates.items():
        if k not in updated_keys:
            new_lines.append(f"{k}={v}\n")
            os.environ[k] = v

    with open(ENV_FILE, "w", encoding="utf-8") as f:
        f.writelines(new_lines)

app = FastAPI(title="Eczane Depo Şart & Maliyet Karşılaştırma", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

motor: Optional[DepoSorguMotoru] = None
_critical_stock_cache = {"time": 0.0, "data": []}

@app.on_event("startup")
async def startup_event():
    global motor
    motor = DepoSorguMotoru(headless=True)
    print(">> Depo Sorgu Motoru başlatıldı. Aktif depolar:", list(motor.adapters.keys()))

    _prewarm_done_event = asyncio.Event()

    async def _prewarm_single_depot(depo_kodu: DepoKodu, label: str):
        try:
            if motor and depo_kodu in motor.adapters:
                adp = motor.adapters[depo_kodu]
                await adp.login()
                await adp._ensure_ready_page()
                print(f">> [{label}] Arka plan hızlı sipariş oturumu hazırlandı.")
        except Exception as e:
            print(f">> [{label}] Oturum ön-ısıtma uyarısı: {e}")

    async def _prewarm_all_depot_sessions():
        try:
            await asyncio.sleep(0.2)
            await asyncio.gather(
                _prewarm_single_depot(DepoKodu.SELCUK, "Selçuk"),
                _prewarm_single_depot(DepoKodu.NEVZAT, "Nevzat"),
                _prewarm_single_depot(DepoKodu.ALLIANCE, "Alliance"),
                _prewarm_single_depot(DepoKodu.ISKOOP, "İSKOOP"),
                return_exceptions=True
            )
        finally:
            _prewarm_done_event.set()

    asyncio.create_task(_prewarm_all_depot_sessions())

    async def _prewarm_cache():
        try:
            await asyncio.sleep(0.5)
            active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
            items = []
            source_used = active_oto
            if active_oto == "TRIA":
                print(">> [Tria] Arka planda kritik stok ve günün çıkışları taranıyor...")
                try:
                    items = await asyncio.to_thread(tria_client.get_critical_stock_sales)
                except Exception as e:
                    print(f">> [Tria] Önbellek çekme uyarısı: {e}")
                if not items:
                    for fb_name, fb_fn in [("BOTANIK", botanik_client.get_critical_stock_sales), ("TEBEOS", tebeos_client.get_critical_stock_sales)]:
                        try:
                            items = await asyncio.to_thread(fb_fn)
                            if items:
                                source_used = fb_name
                                break
                        except Exception:
                            pass
            elif active_oto == "TEBEOS":
                print(">> [TEBEOS] Arka planda kritik stok ve günün çıkışları taranıyor...")
                try:
                    items = await asyncio.to_thread(tebeos_client.get_critical_stock_sales)
                    source_used = "TEBEOS"
                except Exception as e:
                    print(f">> [TEBEOS] Bağlantı uyarısı: {e}")
                    items = []
                if not items:
                    for fb_name, fb_fn in [("TRIA", tria_client.get_critical_stock_sales), ("BOTANIK", botanik_client.get_critical_stock_sales)]:
                        try:
                            items = await asyncio.to_thread(fb_fn)
                            if items:
                                source_used = fb_name
                                break
                        except Exception:
                            pass
            else:
                print(">> [Botanik] Arka planda kritik stok önbelleği ısıtılıyor...")
                try:
                    items = await asyncio.to_thread(botanik_client.get_critical_stock_sales)
                    source_used = "BOTANIK"
                except Exception as e:
                    print(f">> [Botanik] Bağlantı uyarısı: {e}")
                    items = []
                if not items:
                    for fb_name, fb_fn in [("TRIA", tria_client.get_critical_stock_sales), ("TEBEOS", tebeos_client.get_critical_stock_sales)]:
                        try:
                            items = await asyncio.to_thread(fb_fn)
                            if items:
                                source_used = fb_name
                                break
                        except Exception:
                            pass

            global _critical_stock_cache
            _critical_stock_cache = {"time": time.time(), "data": items, "source": source_used}
            print(f">> [{source_used}] Kritik stok önbelleği hazır: {len(items)} kalem ürün yüklendi.")

            async def _prewarm_mf_worker():
                try:
                    try:
                        await asyncio.wait_for(_prewarm_done_event.wait(), timeout=20.0)
                    except asyncio.TimeoutError:
                        pass
                    await asyncio.sleep(1.5)
                    top_barcodes = [str(x.get("barkod") or "").strip() for x in items[:35] if str(x.get("barkod") or "").strip()]
                    if top_barcodes and motor:
                        print(f">> [MF Motoru] İlk {len(top_barcodes)} azalan ürün için MF şartları arka planda taranıyor...")
                        await mf_resolver.resolve_batch(motor, top_barcodes, max_concurrency=4)
                        print(">> [MF Motoru] İlk parti MF şartları başarıyla önbelleğe alındı.")
                except Exception as e:
                    print(f">> [MF Motoru] Arka plan MF tarama uyarısı: {e}")

            asyncio.create_task(_prewarm_mf_worker())
        except Exception as e:
            print(f">> [Otomasyon] Önbellek ısıtma hatası: {e}")

    asyncio.create_task(_prewarm_cache())

    async def _auto_sync_active_dermo_worker():
        try:
            await asyncio.sleep(2.0)
            from backend.dermo_sync import auto_sync_active_dermo_in_background
            print(">> [Taban Motoru] Botanik dermo ve OTC ürünleri arka planda taranıyor...")
            res = await asyncio.to_thread(auto_sync_active_dermo_in_background, 80)
            print(f">> [Taban Motoru] {res.get('message')}")
        except Exception as e:
            print(f">> [Taban Motoru] Arka plan eşleme notu: {e}")

    async def _live_auto_update_worker():
        """Arka planda GitHub Canlı Portalını ve LAN dağıtım sunucusunu periyodik denetler; yeni sürüm varsa canlı kurar."""
        await asyncio.sleep(12.0)
        while True:
            try:
                chk = await asyncio.to_thread(updater.check_for_updates, 3.0)
                if chk.get("update_available") and chk.get("download_url"):
                    if chk.get("auto_update", True) or chk.get("mandatory", False):
                        print(f">> [Canlı Güncelleme] Yeni sürüm tespit edildi: v{chk.get('latest_version')}. Otomatik kuruluyor...")
                        apply_res = await asyncio.to_thread(
                            updater.apply_update,
                            chk["download_url"],
                            chk.get("sha256", ""),
                            chk.get("latest_version", "")
                        )
                        if apply_res.get("success"):
                            print(f">> [Canlı Güncelleme] v{chk.get('latest_version')} başarıyla kuruldu, sunucu yeniden başlatılıyor...")
                            await asyncio.sleep(1.5)
                            base_dir = os.path.dirname(os.path.abspath(__file__))
                            tria_cand = os.path.join(base_dir, "runtime", "Tria.exe")
                            py_exe = tria_cand if os.path.isfile(tria_cand) else sys.executable
                            script = os.path.join(base_dir, "server.py")
                            cflags = 0
                            if sys.platform == "win32":
                                import subprocess
                                cflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
                                subprocess.Popen([py_exe, script], cwd=base_dir, creationflags=cflags, close_fds=True)
                            os._exit(0)
            except Exception as e:
                print(f">> [Canlı Güncelleme] Kontrol notu: {e}")
            await asyncio.sleep(300.0)

    asyncio.create_task(_auto_sync_active_dermo_worker())
    asyncio.create_task(_live_auto_update_worker())

@app.on_event("shutdown")
async def shutdown_event():
    global motor
    if motor:
        await motor.close_all()
        print(">> Depo oturumları kapatıldı.")

@app.get("/api/status")
async def get_status():
    global motor
    active = [k.value for k in motor.adapters.keys()] if motor else []
    return {
        "status": "ready",
        "active_wholesalers": active,
        "count": len(active)
    }

@app.get("/api/settings/credentials")
async def get_credentials_endpoint():
    return get_current_credentials()

@app.post("/api/settings/credentials")
async def save_credentials_endpoint(request: Request):
    global motor, _critical_stock_cache
    data = await request.json()
    old_creds = get_current_credentials()

    # Eğer bir deponun şifresi veya kullanıcı adı değiştiyse, eski oturum çerezini temizle
    for depo in ["alliance", "selcuk", "nevzat", "iskoop", "bek", "ecza1", "farmazon", "dna", "eczatrend", "eczanetakas"]:
        if depo in data:
            old_d = old_creds.get(depo, {})
            new_d = data[depo]
            has_changed = any(str(new_d.get(k, "")).strip() != str(old_d.get(k, "")).strip() for k in new_d)
            if has_changed:
                print(f">> [{depo}] Bilgileri güncellendi, eski oturum temizleniyor...")
                SessionStore.clear(depo)

    save_credentials_to_env(data)
    _critical_stock_cache = {"time": 0.0, "data": []}

    if motor:
        await motor.reload_adapters()
    else:
        motor = DepoSorguMotoru(headless=True)

    active = [k.value for k in motor.adapters.keys()]
    return {
        "success": True,
        "message": f"Depo giriş bilgileri başarıyla kaydedildi. {len(active)} platform hazır.",
        "active_wholesalers": active
    }

@app.get("/api/version")
async def get_version_endpoint():
    """Mevcut yerel sürüm bilgilerini döndürür."""
    return updater.get_local_version_info()

@app.get("/api/license/status")
async def get_license_status_endpoint():
    """Mevcut eczane lisans durumunu ve donanım kimliğini (HWID) döndürür."""
    return await asyncio.to_thread(license_manager.get_status)

@app.post("/api/license/activate")
async def activate_license_endpoint(request: Request):
    """Yeni bir lisans anahtarını doğrular ve aktive eder."""
    try:
        body = await request.json()
        key_str = str(body.get("license_key") or "").strip()
        res = await asyncio.to_thread(license_manager.activate_license, key_str)
        return res
    except Exception as e:
        return JSONResponse(status_code=400, content={"valid": False, "message": str(e)})

def _find_release_dir() -> Optional[Path]:
    base_d = Path(os.path.dirname(os.path.abspath(__file__)))
    candidates = [
        base_d / "releases",
        base_d / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "releases",
        base_d.parent / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "releases",
        Path(r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases"),
    ]
    for c in candidates:
        if (c / "version.json").exists():
            return c
    return None

def _load_release_publisher_module():
    base_d = Path(os.path.dirname(os.path.abspath(__file__)))
    candidates = [
        base_d / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI",
        base_d.parent / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI",
        Path(r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI"),
        Path(r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI"),
    ]
    for c in candidates:
        if (c / "release_publisher.py").exists():
            if str(c) not in sys.path:
                sys.path.insert(0, str(c))
            import release_publisher
            return release_publisher
    return None

@app.get("/portal", response_class=HTMLResponse)
@app.get("/releases", response_class=HTMLResponse)
@app.get("/releases/index.html", response_class=HTMLResponse)
async def serve_release_portal_html():
    """Canlı Güncelleme Portalı web sayfasını sunar."""
    rel_dir = _find_release_dir()
    if rel_dir and (rel_dir / "index.html").exists():
        return HTMLResponse(content=(rel_dir / "index.html").read_text(encoding="utf-8"))
    return HTMLResponse(content="<h3>Canlı Güncelleme Portalı hazırlanıyor...</h3>")

@app.get("/releases/version.json")
@app.get("/api/releases/version.json")
async def serve_release_manifest_endpoint(request: Request):
    """Merkezi/Admin bilgisayarda yayınlanan güncel version.json manifestosunu ağa ve istemcilere sunar."""
    rel_dir = _find_release_dir()
    if not rel_dir or not (rel_dir / "version.json").exists():
        return JSONResponse(status_code=404, content={"error": "Yayınlanmış güncelleme manifestosu bulunamadı."})
    try:
        data = json.loads((rel_dir / "version.json").read_text(encoding="utf-8"))
        ver = data.get("version", "1.0.0")
        host_hdr = request.headers.get("host") or "127.0.0.1:8080"
        zip_name = f"update_v{ver}.zip"
        if (rel_dir / zip_name).exists():
            data["download_url"] = f"http://{host_hdr}/releases/{zip_name}"
        return data
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.get("/releases/{filename}")
@app.get("/api/releases/{filename}")
async def serve_release_package_endpoint(filename: str):
    """Merkezi/Admin bilgisayarda yayınlanan update_vX.Y.Z.zip paketini indirilebilir olarak sunar."""
    from fastapi.responses import Response
    safe_name = os.path.basename(filename)
    rel_dir = _find_release_dir()
    if not rel_dir or not (rel_dir / safe_name).exists():
        return JSONResponse(status_code=404, content={"error": "Güncelleme paketi bulunamadı."})
    if safe_name.endswith(".html"):
        return HTMLResponse(content=(rel_dir / safe_name).read_text(encoding="utf-8"))
    content_bytes = (rel_dir / safe_name).read_bytes()
    return Response(
        content=content_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{safe_name}"'}
    )

@app.post("/api/update/config")
async def update_config_endpoint(request: Request):
    """Manifest URL ve otomatik canlı güncelleme ayarlarını kaydeder."""
    try:
        body = await request.json()
        manifest_url = str(body.get("manifest_url") or "").strip()
        auto_update = body.get("auto_update")
        res = await asyncio.to_thread(updater.set_manifest_url, manifest_url, auto_update)
        return res
    except Exception as e:
        return JSONResponse(status_code=400, content={"success": False, "message": str(e)})

@app.get("/api/github-portal/config")
async def get_github_portal_config_endpoint():
    """GitHub Canlı Güncelleme Portalı ayarlarını döndürür."""
    pub = _load_release_publisher_module()
    local_v = updater.get_local_version_info()
    cur_ver = local_v.get("version", "1.0.7")
    if not pub:
        return {
            "available": False,
            "current_version": cur_ver,
            "next_version": "1.0.8",
            "manifest_url": local_v.get("manifest_url", ""),
            "auto_update": local_v.get("auto_update", True)
        }
    cfg = pub.load_github_config()
    owner = cfg.get("owner", "depomxxx")
    repo = cfg.get("repo", "depo-updates")
    branch = cfg.get("branch", "main")
    return {
        "available": True,
        "owner": owner,
        "repo": repo,
        "branch": branch,
        "has_token": bool(cfg.get("token")),
        "token_preview": (cfg["token"][:7] + "..." + cfg["token"][-4:]) if len(cfg.get("token", "")) > 12 else "",
        "current_version": cur_ver,
        "next_version": pub.bump_patch_version(cur_ver),
        "manifest_url": f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/version.json",
        "pages_url": f"https://{owner}.github.io/{repo}/",
        "auto_update": local_v.get("auto_update", True)
    }

@app.post("/api/github-portal/verify")
async def verify_github_portal_endpoint(request: Request):
    """GitHub Token ile repo oluşturur/doğrular ve Manifest URL'yi kaydeder."""
    pub = _load_release_publisher_module()
    if not pub:
        return JSONResponse(status_code=400, content={"success": False, "message": "Yayınlayıcı modülü (release_publisher.py) bu bilgisayarda bulunamadı."})
    body = await request.json()
    cfg = pub.load_github_config()
    token = str(body.get("token") or cfg.get("token") or "").strip()
    owner = str(body.get("owner") or cfg.get("owner") or "depomxxx").strip()
    repo = str(body.get("repo") or cfg.get("repo") or "depo-updates").strip()
    branch = str(body.get("branch") or cfg.get("branch") or "main").strip()
    res = await asyncio.to_thread(pub.setup_and_verify_github_portal, token, owner, repo, branch)
    if res.get("success") and res.get("manifest_url"):
        await asyncio.to_thread(updater.set_manifest_url, res["manifest_url"], True)
    return res

@app.post("/api/github-portal/publish")
async def publish_github_portal_endpoint(request: Request):
    """Yeni sürümü paketler, GitHub Canlı Portalına yükler ve ağdaki tüm bilgisayarları günceller."""
    pub = _load_release_publisher_module()
    if not pub:
        return JSONResponse(status_code=400, content={"success": False, "message": "Yayınlayıcı modülü (release_publisher.py) bu bilgisayarda bulunamadı."})
    body = await request.json()
    cfg = pub.load_github_config()
    token = str(body.get("token") or cfg.get("token") or "").strip()
    owner = str(body.get("owner") or cfg.get("owner") or "depomxxx").strip()
    repo = str(body.get("repo") or cfg.get("repo") or "depo-updates").strip()
    new_ver = str(body.get("version") or pub.bump_patch_version(updater.get_local_version_info().get("version", "1.0.7"))).strip()
    changelog = str(body.get("changelog") or "Canlı güncelleme ve performans iyileştirmeleri.").strip()

    res = await asyncio.to_thread(
        pub.build_and_publish_release,
        new_ver,
        changelog,
        "",
        True,
        token,
        owner,
        repo
    )
    return res

@app.get("/api/update/check")
async def check_update_endpoint(timeout: float = Query(3.0, ge=0.5, le=10.0)):
    """Merkezi sunucudan (GitHub ve Yerel Ağ LAN) yeni güncelleme olup olmadığını denetler."""
    res = await asyncio.to_thread(updater.check_for_updates, timeout)
    return res

def _trigger_delayed_server_restart(delay_sec: float = 1.5):
    def _delayed_restart():
        import time, subprocess
        time.sleep(delay_sec)
        base_dir = os.path.dirname(os.path.abspath(__file__))
        tria_cand = os.path.join(base_dir, "runtime", "Tria.exe")
        py_exe = tria_cand if os.path.isfile(tria_cand) else sys.executable
        script = os.path.join(base_dir, "server.py")
        cflags = 0
        if sys.platform == "win32":
            cflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
        subprocess.Popen([py_exe, script], cwd=base_dir, creationflags=cflags, close_fds=True)
        os._exit(0)

    import threading
    threading.Thread(target=_delayed_restart, daemon=True).start()

@app.post("/api/update/apply")
async def apply_update_endpoint(request: Request):
    """Merkezi sunucudan (GitHub veya LAN) güncellemeyi indirip kurar ve sunucuyu yeniden başlatır."""
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass

    custom_manifest = str(body.get("manifest_url") or body.get("update_url") or "").strip()
    if custom_manifest.startswith("http"):
        try:
            updater.set_manifest_url(custom_manifest, True)
        except Exception:
            pass

    download_url = body.get("download_url")
    expected_sha256 = body.get("sha256", "")
    new_version = str(body.get("latest_version") or body.get("target_version") or body.get("version") or "").strip()

    if not download_url:
        chk = await asyncio.to_thread(updater.check_for_updates, 4.0)
        if chk.get("download_url") and (chk.get("update_available") or body.get("force")):
            download_url = chk["download_url"]
            expected_sha256 = chk.get("sha256", "")
            new_version = chk.get("latest_version", "") or new_version
        else:
            return JSONResponse(status_code=400, content={"success": False, "message": "İndirilecek yeni bir sürüm bulunamadı veya sisteminiz zaten güncel."})

    res = await asyncio.to_thread(updater.apply_update, download_url, expected_sha256, new_version)
    if res.get("success"):
        _trigger_delayed_server_restart(1.5)
        res["restart"] = True
    return res

def _start_background_auto_update_watcher():
    """Arka planda periyodik olarak hem yerel ağı (LAN) hem de GitHub portalını kontrol eder; yeni sürüm varsa otomatik günceller."""
    import threading, time
    def _watcher_loop():
        time.sleep(25)  # Başlangıçta sunucunun tam açılmasını bekle
        while True:
            try:
                vinfo = updater.get_local_version_info()
                if vinfo.get("auto_update", True):
                    chk = updater.check_for_updates(timeout=3.5)
                    if chk.get("update_available") and chk.get("download_url"):
                        dl_url = chk["download_url"]
                        sha = chk.get("sha256", "")
                        lat_ver = chk.get("latest_version", "")
                        print(f"[AUTO-UPDATE] Yeni sürüm tespit edildi: v{lat_ver} ({dl_url}) -> Otomatik kuruluyor...")
                        res = updater.apply_update(dl_url, sha, lat_ver)
                        if res.get("success"):
                            print(f"[AUTO-UPDATE] v{lat_ver} başarıyla kuruldu, sunucu yeniden başlatılıyor...")
                            _trigger_delayed_server_restart(2.0)
                            return
            except Exception as e:
                print(f"[AUTO-UPDATE] Kontrol hatası: {e}")
            time.sleep(180)  # Her 3 dakikada bir LAN + GitHub denetimi

    t = threading.Thread(target=_watcher_loop, daemon=True, name="AutoUpdateWatcher")
    t.start()

_start_background_auto_update_watcher()

@app.post("/api/server/restart")
async def restart_server_endpoint():
    """Sunucuyu yeniden başlatır."""
    def _do_restart():
        import time, subprocess
        time.sleep(1.0)
        base_dir = os.path.dirname(os.path.abspath(__file__))
        tria_cand = os.path.join(base_dir, "runtime", "Tria.exe")
        py_exe = tria_cand if os.path.isfile(tria_cand) else sys.executable
        script = os.path.join(base_dir, "server.py")
        cflags = 0
        if sys.platform == "win32":
            cflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
        subprocess.Popen([py_exe, script], cwd=base_dir, creationflags=cflags, close_fds=True)
        os._exit(0)

    import threading
    threading.Thread(target=_do_restart, daemon=True).start()
    return {"success": True, "message": "Sunucu yeniden başlatılıyor. Sayfa 3 saniye içinde yenilenecek."}

@app.get("/api/catalog/suggest")
async def suggest_endpoint(q: str = Query(..., min_length=2)):
    """Kullanıcı yazarken anlık ilaç ve OTC önerisi sunar."""
    suggestions = await asyncio.to_thread(catalog.search_suggestions, q, 15)
    return suggestions

@app.get("/api/catalog/stats")
async def catalog_stats_endpoint():
    """Katalogdaki toplam tekil ürün ve çoklu barkod sayılarını döndürür."""
    with catalog._get_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM products")
        total_p = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM product_barcodes")
        total_b = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM product_barcodes WHERE is_primary = 0")
        total_sec = cur.fetchone()[0]
    return {
        "total_products": total_p,
        "total_barcodes": total_b,
        "secondary_barcodes": total_sec
    }

@app.post("/api/catalog/sync-tria")
async def catalog_sync_tria_endpoint():
    """TRIA Oracle'dan çoklu barkod senkronizasyonunu tetikler."""
    try:
        catalog.sync_from_tria()
        return {"success": True, "message": "TRIA çoklu barkod senkronizasyonu tamamlandı."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})

@app.post("/api/catalog/sync-botanik")
async def catalog_sync_botanik_endpoint():
    """Botanik MS SQL'den çoklu barkod senkronizasyonunu tetikler."""
    try:
        catalog.sync_from_botanik()
        return {"success": True, "message": "Botanik çoklu barkod senkronizasyonu başarıyla tamamlandı."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})

@app.post("/api/catalog/upload-excel")
async def catalog_upload_excel_endpoint(file: UploadFile = File(...)):
    """Kullanıcının yüklediği Dermokozmetik / OTC Excel dosyasını kataloğa aktarır."""
    try:
        suffix = Path(file.filename).suffix
        if suffix.lower() not in [".xlsx", ".xls"]:
            return JSONResponse(status_code=400, content={"success": False, "error": "Lütfen geçerli bir Excel (.xlsx) dosyası yükleyin."})
        
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = Path(tmp.name)
            
        res = catalog.import_custom_excel(tmp_path)
        try:
            tmp_path.unlink()
        except:
            pass
        return res
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})

@app.get("/api/products/find")
async def find_products_endpoint(q: str = Query(..., min_length=2)):
    """
    Kullanıcı arama yaptığında:
    - Barkod ise doğrudan tekil barkod döndürür.
    - Kelime araması ise (örn: 'ocean', 'parol', 'solgar') eşleşen tüm ürünleri döndürür.
    """
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    
    clean_q = q.strip()
    if clean_q.isdigit() and len(clean_q) >= 8:
        cat_item = catalog.get_by_barcode(clean_q)
        return {
            "is_barcode": True,
            "barcode": clean_q,
            "count": 1,
            "products": [cat_item] if cat_item else [{
                "barcode": clean_q,
                "name": f"Ürün Barkodu: {clean_q}",
                "manufacturer": "Genel",
                "price": 0.0
            }]
        }

    products = await motor.find_products(clean_q, limit=20)
    return {
        "is_barcode": False,
        "count": len(products),
        "products": products
    }

@app.get("/api/search", response_model=DepoKarsilastirmaRaporu)
async def search_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    
    clean_q = q.strip()
    if not clean_q:
        return JSONResponse(status_code=400, content={"error": "Arama ifadesi boş olamaz"})

    rapor = await motor.search_all(clean_q)

    # Ürün adını katalogdan zenginleştir
    cat_item = catalog.get_by_barcode(rapor.barkod)
    if cat_item:
        rapor.urun_adi = cat_item["name"]

    # Eczane Otomasyonu (Botanik, Tria & Tebeos) Raf Stoğu, Giriş & Çıkış Analizi
    active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
    oto_res = None
    
    if active_oto == "TEBEOS":
        try:
            tebeos_res = tebeos_client.get_product_analysis(clean_q, barcode=rapor.barkod)
            if tebeos_res and tebeos_res.get("found"):
                oto_res = tebeos_res
                rapor.tria_bilgisi = tebeos_res
        except Exception as e:
            print(f"[Tebeos] Arama hatası: {e}")

        if not oto_res:
            for fallback_client in (tria_client, botanik_client):
                try:
                    fb_res = fallback_client.get_product_analysis(clean_q, barcode=rapor.barkod)
                    if fb_res and fb_res.get("found"):
                        oto_res = fb_res
                        break
                except Exception:
                    pass
    elif active_oto == "TRIA":
        try:
            tria_res = tria_client.get_product_analysis(clean_q, barcode=rapor.barkod)
            if tria_res and tria_res.get("found"):
                oto_res = tria_res
                rapor.tria_bilgisi = tria_res
        except Exception as e:
            print(f"[Tria] Arama hatası: {e}")

        if not oto_res:
            for fallback_client in (tebeos_client, botanik_client):
                try:
                    fb_res = fallback_client.get_product_analysis(clean_q, barcode=rapor.barkod)
                    if fb_res and fb_res.get("found"):
                        oto_res = fb_res
                        break
                except Exception:
                    pass
    else:  # BOTANIK or OTOMATIK
        try:
            botanik_res = botanik_client.get_product_analysis(clean_q, barcode=rapor.barkod)
            if botanik_res and botanik_res.get("found"):
                oto_res = botanik_res
                rapor.botanik_bilgisi = botanik_res
        except Exception as e:
            print(f"[Botanik] Arama hatası: {e}")

        if not oto_res:
            for fallback_client in (tria_client, tebeos_client):
                try:
                    fb_res = fallback_client.get_product_analysis(clean_q, barcode=rapor.barkod)
                    if fb_res and fb_res.get("found"):
                        oto_res = fb_res
                        break
                except Exception:
                    pass

    # Eğer sistemlerde spesifik bulunamadıysa en azından aktif otomasyonun boş şablonunu ata
    if not oto_res:
        if active_oto == "TEBEOS":
            try:
                oto_res = tebeos_client.get_product_analysis(clean_q, barcode=rapor.barkod)
            except Exception:
                oto_res = {"found": False, "connected": False, "kaynak": "TEBEOS", "message": "TEBEOS otomasyonuna bağlanılamadı."}
        elif active_oto == "TRIA":
            try:
                oto_res = tria_client.get_product_analysis(clean_q, barcode=rapor.barkod)
            except Exception:
                oto_res = {"found": False, "connected": False, "kaynak": "TRIA", "message": "TRIA otomasyonuna bağlanılamadı."}
        else:
            try:
                oto_res = botanik_client.get_product_analysis(clean_q, barcode=rapor.barkod)
            except Exception:
                oto_res = {"found": False, "connected": False, "kaynak": "BOTANIK", "message": "Eczane otomasyonuna bağlanılamadı."}

    rapor.otomasyon_bilgisi = oto_res
    rapor.tria_bilgisi = oto_res  # Geriye dönük tam uyumluluk
    if oto_res and oto_res.get("kaynak") == "BOTANIK":
        rapor.botanik_bilgisi = oto_res
    elif oto_res and oto_res.get("kaynak") in ("TRIA", "TEBEOS"):
        rapor.tria_bilgisi = oto_res

    # Bugün eczanedeki herhangi bir bilgisayardan sipariş verilmiş mi / sepete atılmış mı kontrol et
    try:
        orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
        bc_key = str(rapor.barkod or "").strip()
        nm_key = str(rapor.urun_adi or "").strip().upper()
        ord_info = orders_map.get(bc_key) or (orders_map.get(bc_key[1:]) if len(bc_key) == 14 and bc_key.startswith("0") else None) or orders_map.get(nm_key)
        if ord_info:
            rapor.bugun_siparis = ord_info
    except Exception:
        pass

    return rapor

@app.get("/api/market/search", response_model=MarketPriceReport)
async def market_search_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    global motor, market_engine
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    if not market_engine or market_engine.depo_motoru is None:
        market_engine = RetailMarketEngine(depo_motoru=motor)
    
    clean_q = q.strip()
    if not clean_q:
        return JSONResponse(status_code=400, content={"error": "Arama ifadesi boş olamaz"})
    
    report = await market_engine.generate_market_report(clean_q)
    return report

# --- Botanik MS SQL Endpoints ---
@app.get("/api/botanik/ping")
async def botanik_ping_endpoint(
    server: Optional[str] = None,
    database: Optional[str] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    trusted: Optional[bool] = None
):
    """Botanik MS SQL veritabanı bağlantı testi ve ping metrikleri."""
    return await asyncio.to_thread(
        botanik_client.ping,
        server=server,
        database=database,
        user=user,
        password=password,
        trusted=trusted
    )

@app.get("/api/botanik/product")
async def botanik_product_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    """Tekil olarak ilacın Botanik stok, giriş ve aylık hareket analizini döner."""
    return botanik_client.get_product_analysis(q)

@app.get("/api/botanik/read-config")
async def botanik_read_config_endpoint():
    """Botanik config dosyasından (BotanikEczane.exe.config) otomatik bağlantı bilgilerini okur."""
    return botanik_client.read_botanik_config_file()

_smart_order_list_cache = {}

@app.get("/api/botanik/smart-order-list")
async def botanik_smart_order_list_endpoint(
    scope: str = Query("today", description="today | week | top6m | search"),
    q: str = Query("", description="Arama kelimesi veya barkod"),
    target_days: int = Query(15, description="Hedef stok gün sayısı (örn: 1, 7, 15, 30)"),
    limit: int = Query(250, description="Maksimum ürün sayısı"),
    force: bool = Query(False, description="Önbelleği yoksay ve canlı sorgula")
):
    """
    Botanik Eczane Otomasyonu 6 Aylık Çıkış & Akıllı Toplu Sipariş Planlama Listesi.
    Ürünlerin son 6 aylık ay-ay çıkışlarını, çıkış trendini (Stabil, Çıkışı Azalan, Artan),
    günlük tahmini sipariş önerisini, geçmiş fatura MF'lerini, anlık canlı depo MF'lerini
    ve ortak sipariş takip durumunu birlikte döner.
    """
    global _smart_order_list_cache
    now = time.time()
    cache_key = f"{scope.strip().lower()}_{(q or '').strip().lower()}_{int(target_days)}_{int(limit)}"

    res_data = None
    if not force and cache_key in _smart_order_list_cache:
        cached_entry = _smart_order_list_cache[cache_key]
        if (now - cached_entry.get("time", 0)) < 90:
            res_data = dict(cached_entry["data"])

    if not res_data:
        res_data = await asyncio.to_thread(
            botanik_client.get_six_month_smart_order_list,
            scope=scope,
            search_query=q,
            target_days=target_days,
            limit=limit
        )
        if res_data and res_data.get("success"):
            _smart_order_list_cache[cache_key] = {"time": now, "data": dict(res_data)}

    raw_items = res_data.get("items", []) if res_data else []
    enriched_items = await _enrich_critical_items_with_orders(raw_items)

    # Özet istatistikleri hesapla
    stabil_count = sum(1 for it in enriched_items if it.get("trend_kodu") == "STABIL")
    azalan_count = sum(1 for it in enriched_items if it.get("trend_kodu") == "AZALAN")
    artan_count = sum(1 for it in enriched_items if it.get("trend_kodu") == "ARTAN")
    mf_count = sum(1 for it in enriched_items if (it.get("mf_metni") and it.get("mf_metni") != "YOK") or it.get("gecmis_mf_var"))
    ordered_count = sum(1 for it in enriched_items if it.get("siparis_durumu"))

    return {
        "success": bool(res_data and res_data.get("success")),
        "source": "BOTANIK",
        "scope": scope,
        "target_days": target_days,
        "count": len(enriched_items),
        "months": res_data.get("months", []) if res_data else [],
        "stats": {
            "total": len(enriched_items),
            "stabil": stabil_count,
            "azalan": azalan_count,
            "artan": artan_count,
            "mf_olan": mf_count,
            "siparis_verilen": ordered_count,
        },
        "pc_name": order_tracker.pc_name,
        "error": res_data.get("error") if res_data else None,
        "items": enriched_items,
    }

async def _enrich_critical_items_with_orders(items_list: list) -> list:
    """Günün çıkışları listesini tüm bilgisayarlardaki ortak sipariş durumuyla zenginleştirir ve sipariş verilenleri alta alır."""
    try:
        orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
    except Exception:
        orders_map = {}

    enriched = []
    for raw_it in items_list:
        it = dict(raw_it)
        bc = str(it.get("barkod") or "").strip()
        nm = str(it.get("urun_adi") or "").strip().upper()
        c_mf = mf_resolver.get_cached_mf(bc)
        if c_mf and c_mf.get("mf"):
            it["mf_metni"] = c_mf["mf"]
            it["mf_depo"] = c_mf.get("depo", "Depo")
        else:
            it["mf_metni"] = None
            it["mf_depo"] = None

        ord_info = orders_map.get(bc) or (orders_map.get(bc[1:]) if len(bc) == 14 and bc.startswith("0") else None) or orders_map.get(nm)
        if ord_info:
            it["siparis_durumu"] = ord_info.get("durum")
            it["siparis_depo"] = ord_info.get("depo")
            it["siparis_miktar"] = ord_info.get("miktar")
            it["siparis_masa"] = ord_info.get("masa_adi")
            it["siparis_saat"] = ord_info.get("saat")
        else:
            it["siparis_durumu"] = None
            it["siparis_depo"] = None
            it["siparis_miktar"] = None
            it["siparis_masa"] = None
            it["siparis_saat"] = None
        enriched.append(it)

    # Sipariş verilenler listenin altına kaysın, bekleyenler üstte kalsın
    enriched.sort(key=lambda x: (1 if x.get("siparis_durumu") == "SIPARIS_VERILDI" else 0))
    return enriched

@app.get("/api/otomasyon/critical-stock")
async def otomasyon_critical_stock_endpoint(force: bool = False, limit: int = 0, max_days: int = 21):
    """Bugün eczaneden çıkışı olan ve stoğu kritik/azalan ürünleri döner (limit=0 tüm ürünleri getirir). 21 gün üzeri stokları filtreler."""
    global _critical_stock_cache
    now = time.time()
    active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
    if not force and _critical_stock_cache["data"] and _critical_stock_cache.get("source") == active_oto and (now - _critical_stock_cache["time"] < 120):
        cached_items = _critical_stock_cache["data"]
        # 21 Gün kuralı: Eğer max_days > 0 ise 21 günden fazla yetecek stokları filtrele
        if max_days > 0:
            filtered_items = [it for it in cached_items if it.get("stok", 0) <= 0 or it.get("stok_gun", 0) <= max_days]
        else:
            filtered_items = cached_items

        res_items = filtered_items[:limit] if (limit and limit > 0) else filtered_items
        res_items = await _enrich_critical_items_with_orders(res_items)

        return {
            "success": True,
            "source": _critical_stock_cache.get("source", active_oto),
            "cached": True,
            "count": len(res_items),
            "total_count": len(filtered_items),
            "max_days": max_days,
            "pc_name": order_tracker.pc_name,
            "items": res_items
        }

    items = []
    source_used = active_oto
    try:
        if active_oto == "TEBEOS":
            try:
                items = await asyncio.to_thread(tebeos_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)
            except Exception:
                items = []
            if not items:
                for fb_name, fb_client in (("TRIA", tria_client), ("BOTANIK", botanik_client)):
                    try:
                        fb_items = await asyncio.to_thread(fb_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)
                        if fb_items:
                            items = fb_items
                            source_used = fb_name
                            break
                    except Exception:
                        pass
        elif active_oto == "TRIA":
            items = await asyncio.to_thread(tria_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)
            if not items:
                for fb_name, fb_client in (("TEBEOS", tebeos_client), ("BOTANIK", botanik_client)):
                    try:
                        fb_items = await asyncio.to_thread(fb_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)
                        if fb_items:
                            items = fb_items
                            source_used = fb_name
                            break
                    except Exception:
                        pass
        elif active_oto == "BOTANIK":
            try:
                items = await asyncio.to_thread(botanik_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)
            except Exception:
                items = []
            if not items:
                for fb_name, fb_client in (("TRIA", tria_client), ("TEBEOS", tebeos_client)):
                    try:
                        fb_items = await asyncio.to_thread(fb_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)
                        if fb_items:
                            items = fb_items
                            source_used = fb_name
                            break
                    except Exception:
                        pass
        else:
            for fb_name, fb_client in (("TRIA", tria_client), ("TEBEOS", tebeos_client), ("BOTANIK", botanik_client)):
                try:
                    fb_items = await asyncio.to_thread(fb_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)
                    if fb_items:
                        items = fb_items
                        source_used = fb_name
                        break
                except Exception:
                    pass
        
        _critical_stock_cache = {"time": now, "data": items, "source": source_used}
    except Exception as e:
        print(f"[Otomasyon] Critical stock endpoint hatası: {e}")

    # 21 Gün kuralı filtresi
    if max_days > 0:
        filtered_items = [it for it in items if it.get("stok", 0) <= 0 or it.get("stok_gun", 0) <= max_days]
    else:
        filtered_items = items

    res_items = filtered_items[:limit] if (limit and limit > 0) else filtered_items
    res_items = await _enrich_critical_items_with_orders(res_items)

    return {
        "success": True,
        "source": source_used,
        "cached": False,
        "count": len(res_items),
        "total_count": len(filtered_items),
        "max_days": max_days,
        "pc_name": order_tracker.pc_name,
        "items": res_items
    }

@app.post("/api/otomasyon/resolve-mf")
async def resolve_mf_endpoint(request: Request):
    """Günün azalan ürünlerinin MF şartlarını depolar arasında bölüştürerek paralel çözer."""
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        data = await request.json()
        barcodes = data.get("barcodes", [])
        if not barcodes:
            return {"success": True, "results": {}}
        results = await mf_resolver.resolve_batch(motor, barcodes[:40], max_concurrency=4)
        return {"success": True, "results": results}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


# --- Tria Oracle Endpoints ---
@app.get("/api/tria/ping")
async def tria_ping_endpoint(
    host: Optional[str] = Query(None),
    port: Optional[str] = Query(None),
    sid: Optional[str] = Query(None),
    user: Optional[str] = Query(None),
    password: Optional[str] = Query(None)
):
    """Tria Oracle veritabanı bağlantı testi ve ping metrikleri."""
    return tria_client.ping(host=host, port=port, sid=sid, user=user, password=password)

@app.get("/api/tria/product")
async def tria_product_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    """Tekil olarak ilacın Tria stok ve aylık hareket analizini döner."""
    return tria_client.get_product_analysis(q)

@app.get("/api/tria/schemas")
async def tria_schemas_endpoint():
    """Oracle veritabanındaki kayıtlı eczane şemalarını listeler (EdaPrim stili)."""
    return tria_client.list_available_schemas()

@app.get("/api/tria/discover")
async def tria_discover_endpoint():
    """Ağda veya yerel ortamda TRIA Oracle sunucusunu otomatik tespit eder (EdaPrim stili)."""
    return tria_client.discover_tria_host()


# --- Tebeos PostgreSQL Endpoints ---
@app.get("/api/tebeos/ping")
async def tebeos_ping_endpoint(
    host: Optional[str] = Query(None),
    port: Optional[str] = Query(None),
    database: Optional[str] = Query(None),
    user: Optional[str] = Query(None),
    password: Optional[str] = Query(None)
):
    """TEBEOS PostgreSQL veritabanı bağlantı testi ve ping metrikleri."""
    return await asyncio.to_thread(
        tebeos_client.ping,
        host=host,
        port=port,
        database=database,
        user=user,
        password=password
    )

@app.get("/api/tebeos/product")
async def tebeos_product_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    """Tekil olarak ilacın TEBEOS stok, giriş ve aylık hareket analizini döner."""
    return await asyncio.to_thread(tebeos_client.get_product_analysis, q)

@app.get("/api/tebeos/discover")
async def tebeos_discover_endpoint():
    """Ağda veya yerel ortamda TEBEOS PostgreSQL sunucusunu (Port 5454) otomatik tespit eder."""
    return await asyncio.to_thread(tebeos_client.discover_tebeos_host)


@app.get("/api/products/equivalents")
@app.get("/api/otomasyon/equivalents")
async def get_equivalents_endpoint(
    kod: Optional[str] = Query(None),
    esdeger: Optional[str] = Query(None),
    jenerik: Optional[str] = Query(""),
    barcode: Optional[str] = Query(None),
    q: Optional[str] = Query(None)
):
    """
    Aranan ilacın SGK eşdeğer grubundaki tüm muadilleri;
    anlık canlı depo MF şartları, net birim maliyetleri, SGK kamu ve perakende kârlılıkları
    ve eczane raf stoğu ile birlikte kârlılık sırasına göre döner.
    """
    target = barcode or q or kod or ""
    active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()

    # 1. Tria / Botanik / Tebeos'tan SGK eşdeğer kodu ve eczane stok/çıkışlarını al
    oto_data = None
    oto_map = {}
    esdeger_kodu = esdeger or None

    if target:
        if active_oto == "TEBEOS":
            try:
                res = await asyncio.to_thread(tebeos_client.get_product_equivalents, target)
                if res.get("found"):
                    oto_data = res
                    esdeger_kodu = esdeger_kodu or res.get("esdeger_kodu")
            except Exception as e:
                print(f"[Tebeos] get_product_equivalents hatası: {e}")
        elif active_oto == "TRIA":
            try:
                res = await asyncio.to_thread(tria_client.get_product_equivalents, target)
                if res.get("found"):
                    oto_data = res
                    esdeger_kodu = esdeger_kodu or res.get("esdeger_kodu")
            except Exception as e:
                print(f"[Tria] get_product_equivalents hatası: {e}")
        elif active_oto == "BOTANIK":
            try:
                res = await asyncio.to_thread(botanik_client.get_product_equivalents, target)
                if res.get("found"):
                    oto_data = res
                    esdeger_kodu = esdeger_kodu or res.get("esdeger_kodu")
            except Exception as e:
                print(f"[Botanik] get_product_equivalents hatası: {e}")

    def clean_brand_name(text: str) -> str:
        if not text:
            return ""
        tr_map = {'İ': 'i', 'I': 'i', 'ı': 'i', 'Ş': 's', 'ş': 's', 'Ğ': 'g', 'ğ': 'g', 'Ü': 'u', 'ü': 'u', 'Ö': 'o', 'ö': 'o', 'Ç': 'c', 'ç': 'c'}
        n = text
        for k, v in tr_map.items():
            n = n.replace(k, v)
        words = re.findall(r'[a-z0-9]+', n.lower())
        return words[0] if words else ""

    oto_brand_map = {}
    if oto_data and oto_data.get("muadiller"):
        for item in oto_data["muadiller"]:
            m_kod = str(item.get("mal_kodu", "")).strip()
            m_bc = str(item.get("barkod", "")).strip()
            m_name = str(item.get("urun_adi", "")).strip()
            if m_kod:
                oto_map[m_kod] = item
            if m_bc:
                oto_map[m_bc] = item
            b = clean_brand_name(m_name)
            if b and (b not in oto_brand_map or item.get("stok", 0) > oto_brand_map[b].get("stok", 0)):
                oto_brand_map[b] = item

    # 2. Selçuk Ecza üzerinden canlı depo MF şartlarını ve birim kârları çek
    raw_eqs = []
    global motor
    try:
        if not motor:
            motor = DepoSorguMotoru(headless=True)
        selcuk_ad = motor.adapters.get(DepoKodu.SELCUK) if motor else None
        search_code = barcode or q or target or kod or ""
        if selcuk_ad and (search_code or esdeger_kodu):
            raw_eqs = await selcuk_ad.get_equivalents(search_code, esdeger_kodu or "", jenerik or "")
    except Exception as e:
        print(f"[Equivalents] Selçuk get_equivalents hatası: {e}")

    # Eğer başlangıçta otomasyondan çekilemediyse ancak Selçuk'tan muadil listesi geldiyse, ilacın adından aktif otomasyonu tamamla
    if not oto_data and raw_eqs:
        try:
            curr_ref = next((x for x in raw_eqs if x.get("is_current")), raw_eqs[0])
            ref_name = curr_ref.get("ad") or curr_ref.get("urun_adi") or ""
            if ref_name:
                sec_res = None
                if active_oto == "TEBEOS":
                    sec_res = await asyncio.to_thread(tebeos_client.get_product_equivalents, ref_name)
                elif active_oto == "TRIA":
                    sec_res = await asyncio.to_thread(tria_client.get_product_equivalents, ref_name)
                elif active_oto == "BOTANIK":
                    sec_res = await asyncio.to_thread(botanik_client.get_product_equivalents, ref_name)

                if sec_res and sec_res.get("found"):
                    oto_data = sec_res
                    esdeger_kodu = esdeger_kodu or sec_res.get("esdeger_kodu")
                    for item in sec_res.get("muadiller", []):
                        m_kod = str(item.get("mal_kodu", "")).strip()
                        m_bc = str(item.get("barkod", "")).strip()
                        m_name = str(item.get("urun_adi", "")).strip()
                        if m_kod: oto_map[m_kod] = item
                        if m_bc: oto_map[m_bc] = item
                        b = clean_brand_name(m_name)
                        if b and (b not in oto_brand_map or item.get("stok", 0) > oto_brand_map[b].get("stok", 0)):
                            oto_brand_map[b] = item
        except Exception as e:
            print(f"[Equivalents] Otomasyon ikincil çözümleme hatası: {e}")

    def extract_drug_tokens(name: str):
        if not name:
            return "", set()
        n = name.upper().replace("-", " ").replace(".", " ")
        n = re.sub(r"\b1\s*(GR|G)\b", "1000 MG", n)
        n = re.sub(r"\b2\s*(GR|G)\b", "2000 MG", n)
        nums = set(re.findall(r"\d+", n))
        tr_map = {'İ': 'i', 'I': 'i', 'ı': 'i', 'Ş': 's', 'ş': 's', 'Ğ': 'g', 'ğ': 'g', 'Ü': 'u', 'ü': 'u', 'Ö': 'o', 'ö': 'o', 'Ç': 'c', 'ç': 'c'}
        for k, v in tr_map.items():
            n = n.replace(k, v.upper())
        skip = {'MG', 'ML', 'GR', 'G', 'TB', 'FTB', 'TAB', 'TABLET', 'FILM', 'SUS', 'SUSP', 'SURUP', 'KAP', 'KAPSUL', 'ADET', 'KUTU', 'FLK', 'AMP'}
        words = [w for w in re.findall(r"[A-Z0-9]+", n) if w not in skip and not w.isdigit()]
        brand = words[0].lower() if words else ""
        return brand, nums

    # Eğer Selçuk'tan muadil geldiyse, otomasyon stoklarıyla zenginleştir ve kârlılık farkını hesapla
    if raw_eqs:
        for eq in raw_eqs:
            c_kod = str(eq.get("kod", "")).strip()
            c_ad = str(eq.get("ad") or eq.get("urun_adi") or "").strip()
            c_brand, c_nums = extract_drug_tokens(c_ad)

            # Eşleşme arama:
            # 1. Kod veya Barkod ile doğrudan
            oto_info = oto_map.get(c_kod) or {}

            # 2. Token (Marka + Dozaj/Ambalaj Numaraları) eşleşmesi
            if not oto_info and oto_data and oto_data.get("muadiller"):
                best_match = None
                best_score = 0
                for m_item in oto_data["muadiller"]:
                    m_name = m_item.get("urun_adi", "")
                    m_brand, m_nums = extract_drug_tokens(m_name)
                    if c_brand and m_brand and c_brand == m_brand:
                        common = c_nums.intersection(m_nums)
                        score = len(common) + 1
                        if score > best_score:
                            best_score = score
                            best_match = m_item
                if best_match:
                    oto_info = best_match

            # 3. Barkod tespit et (13 haneli EAN/GTIN)
            final_bc = oto_info.get("barkod") if oto_info else None
            cat_inst_isk = 0.0
            if not final_bc or len(str(final_bc)) < 8 or not str(final_bc).isdigit():
                try:
                    from backend.catalog import catalog
                    with catalog._get_connection() as c_conn:
                        c_cur = c_conn.cursor()
                        if c_brand and c_nums:
                            like_terms = [f"%{c_brand}%"] + [f"%{n}%" for n in sorted(c_nums, key=lambda x: -len(x))[:2]]
                            where_clause = " AND ".join(["name_normalized LIKE ?" for _ in like_terms])
                            c_cur.execute(f"SELECT primary_barcode, institution_discount FROM products WHERE {where_clause} LIMIT 1", [t.lower() for t in like_terms])
                            c_row = c_cur.fetchone()
                            if c_row and c_row[0]:
                                final_bc = c_row[0]
                                cat_inst_isk = float(c_row[1] or 0.0)
                        if not final_bc:
                            suggs = catalog.search_suggestions(c_ad, limit=1)
                            if suggs and suggs[0].get("barcode"):
                                final_bc = suggs[0]["barcode"]
                                cat_inst_isk = float(suggs[0].get("institution_discount") or 0.0)
                except Exception:
                    pass

            # Eğer barkod bulunduysa ve henüz oto_info yoksa barkodla oto_map'e tekrar bak
            if final_bc and not oto_info:
                oto_info = oto_map.get(str(final_bc)) or oto_map.get(str(final_bc).lstrip("0")) or {}

            eq["stok"] = oto_info.get("stok", 0) if oto_info else 0
            eq["cikis_30gun"] = oto_info.get("cikis_30gun", 0) if oto_info else 0
            eq["barkod"] = final_bc or c_kod
            eq["gecmis_mf_var"] = oto_info.get("gecmis_mf_var", False) if oto_info else False
            eq["gecmis_mf_bilgi"] = oto_info.get("gecmis_mf_bilgi", "") if oto_info else ""
            eq["gecmis_mf_kisa"] = oto_info.get("gecmis_mf_kisa", "") if oto_info else ""

            # Kamu İskontosu, KSF, SGK Reçete Kârı ve Elden Satış Kârını doğrula/güncelle
            kamu_isk_val = float(eq.get("kamu_iskontosu") or 0.0)
            if kamu_isk_val <= 0.0 and oto_info and float(oto_info.get("kamu_iskontosu") or 0.0) > 0.0:
                kamu_isk_val = float(oto_info["kamu_iskontosu"])
            if kamu_isk_val <= 0.0 and cat_inst_isk > 0.0:
                kamu_isk_val = cat_inst_isk
            if kamu_isk_val <= 0.0 and final_bc:
                try:
                    from backend.catalog import catalog
                    cat_p = catalog.get_by_barcode(str(final_bc))
                    if cat_p and float(cat_p.get("institution_discount") or 0.0) > 0.0:
                        kamu_isk_val = float(cat_p["institution_discount"])
                except Exception:
                    pass

            psf_v = float(eq.get("psf") or eq.get("etiket_fiyati") or (oto_info.get("psf") if oto_info else 0.0) or 0.0)
            existing_ksf_v = float(eq.get("ksf") or eq.get("kamu_fiyati") or (oto_info.get("ksf") if oto_info else 0.0) or 0.0)
            if existing_ksf_v > 0 and (psf_v <= 0 or existing_ksf_v < psf_v):
                ksf_v = round(existing_ksf_v, 2)
                if kamu_isk_val <= 0.0 and psf_v > ksf_v > 0:
                    kamu_isk_val = round((1.0 - (ksf_v / psf_v)) * 100.0, 2)
            else:
                ksf_v = round(psf_v * (1.0 - (kamu_isk_val / 100.0)), 2) if (psf_v > 0 and kamu_isk_val > 0) else round(psf_v, 2)

            eq["psf"] = round(psf_v, 2)
            eq["kamu_iskontosu"] = round(kamu_isk_val, 2)
            eq["ksf"] = ksf_v
            eq["kamu_fiyati"] = ksf_v

        # Diğer aktif depolar (Alliance, İSKOOP, Eczatrend vb.) üzerinden de canlı MF şartlarını birleştir
        if motor:
            await motor.enrich_equivalents_with_live_mf(raw_eqs, search_target=target)

        curr_item = next((x for x in raw_eqs if x.get("is_current")), None)
        curr_kamu_kari = float(curr_item.get("kamu_kari") or 0.0) if curr_item else 0.0

        en_karli = None
        muadil_kar_avantaji = 0.0
        for item in raw_eqs:
            if item.get("is_best_deal") or (float(item.get("kar_farki") or 0.0) > 0 and not item.get("is_current")):
                item["is_best_deal"] = True
                en_karli = item
                muadil_kar_avantaji = float(item.get("kar_farki") or 0.0)
                break

        return {
            "found": True,
            "esdeger_kodu": esdeger_kodu or "SGK_ESDEGER",
            "count": len(raw_eqs),
            "en_karli_muadil": en_karli,
            "muadil_kar_avantaji": muadil_kar_avantaji,
            "current_kamu_kari": curr_kamu_kari,
            "muadiller": raw_eqs
        }

    # 3. Selçuk'tan çekilemediyse Otomasyon (Tria/Botanik/Tebeos) muadillerini aktif depoların (Alliance, İSKOOP, Eczatrend vb.) CANLI MF'leriyle zenginleştirip dön
    if oto_data and oto_data.get("found"):
        muadiller = oto_data.get("muadiller", [])
        base_kari = float(oto_data.get("current_kamu_kari") or 0.0)
        if motor and muadiller:
            await motor.enrich_equivalents_with_live_mf(
                esdegerler=muadiller,
                search_target=target,
                base_kamu_kari=base_kari
            )

        curr_item = next((x for x in muadiller if x.get("is_current")), None)
        curr_kamu_kari = float(curr_item.get("kamu_kari") or base_kari) if curr_item else base_kari
        en_karli = next((x for x in muadiller if x.get("is_best_deal")), oto_data.get("en_karli_muadil"))
        muadil_kar_avantaji = float(en_karli.get("kar_farki") or 0.0) if en_karli else float(oto_data.get("muadil_kar_avantaji") or 0.0)

        return {
            "found": True,
            "esdeger_kodu": oto_data.get("esdeger_kodu"),
            "count": len(muadiller),
            "en_karli_muadil": en_karli,
            "muadil_kar_avantaji": muadil_kar_avantaji,
            "current_kamu_kari": curr_kamu_kari,
            "muadiller": muadiller
        }

    return {
        "found": False,
        "esdeger_kodu": None,
        "count": 0,
        "en_karli_muadil": None,
        "muadil_kar_avantaji": 0.0,
        "current_kamu_kari": 0.0,
        "muadiller": []
    }

@app.post("/api/cart/add")
async def add_to_cart_endpoint(request: Request):
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        data = await request.json()
        depo = str(data.get("depo", "")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        barkod = str(data.get("barkod", "")).strip()
        satis_sekli = str(data.get("satis_sekli", "")).strip()
        name = str(data.get("name") or data.get("urun_adi") or "").strip()

        if not depo:
            return JSONResponse({"success": False, "message": "Depo belirtilmedi."}, status_code=400)

        res = await motor.add_to_cart(
            depo=depo,
            urun_id=urun_id or barkod,
            miktar=miktar,
            barkod=barkod,
            satis_sekli=satis_sekli,
            name=name,
            urun_adi=name
        )
        if res.get("success"):
            try:
                await asyncio.to_thread(
                    order_tracker.mark_items,
                    [{"barkod": barkod or urun_id, "urun_adi": name, "depo": depo, "miktar": miktar}],
                    "SEPETTE",
                    depo
                )
            except Exception as e:
                print(f"[OrderTracker] add_to_cart kayıt uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepete ekleme hatası: {str(e)}"}, status_code=500)

@app.post("/api/cart/bulk-add")
async def bulk_add_to_cart_endpoint(request: Request):
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        data = await request.json()
        depo = str(data.get("depo", "ALLIANCE")).strip()
        items = data.get("items", [])
        cascade = bool(data.get("cascade", False))

        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek ürün listesi boş."}, status_code=400)

        if cascade:
            res = await motor.cascade_bulk_add_to_cart(start_depo=depo, items=items)
        else:
            res = await motor.bulk_add_to_cart(depo=depo, items=items)

        try:
            succ_items = [
                {
                    "barkod": r.get("barcode") or r.get("barkod"),
                    "urun_adi": r.get("name") or r.get("urun_adi"),
                    "depo": r.get("assigned_depo") or depo,
                    "miktar": r.get("miktar", 1)
                }
                for r in res.get("items", []) if r.get("success")
            ]
            if succ_items:
                await asyncio.to_thread(order_tracker.mark_items, succ_items, "SEPETTE", depo)
        except Exception as e:
            print(f"[OrderTracker] bulk_add kayıt uyarısı: {e}")

        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Toplu sepete ekleme hatası: {str(e)}"}, status_code=500)

@app.post("/api/cart/cascade-bulk-add")
async def cascade_bulk_add_to_cart_endpoint(request: Request):
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        data = await request.json()
        depo = str(data.get("depo", "ALLIANCE")).strip()
        items = data.get("items", [])
        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek ürün listesi boş."}, status_code=400)
        res = await motor.cascade_bulk_add_to_cart(start_depo=depo, items=items)
        try:
            succ_items = [
                {
                    "barkod": r.get("barcode") or r.get("barkod"),
                    "urun_adi": r.get("name") or r.get("urun_adi"),
                    "depo": r.get("assigned_depo") or depo,
                    "miktar": r.get("miktar", 1)
                }
                for r in res.get("items", []) if r.get("success")
            ]
            if succ_items:
                await asyncio.to_thread(order_tracker.mark_items, succ_items, "SEPETTE", depo)
        except Exception as e:
            print(f"[OrderTracker] cascade_bulk_add kayıt uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Şelale sepete ekleme hatası: {str(e)}"}, status_code=500)

@app.get("/api/cart/status")
async def cart_status_endpoint(depo: str = Query("SELCUK")):
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        res = await motor.get_cart_status(depo=depo)
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepet sorgulama hatası: {str(e)}"}, status_code=500)

@app.post("/api/cart/quick-finalize-check")
async def quick_finalize_check_endpoint(request: Request):
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        barkod = str(data.get("barkod", "")).strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        urun_adi = str(data.get("urun_adi", "")).strip()

        cart_status = await motor.get_cart_status(depo=depo)
        items = cart_status.get("items", [])
        item_count = len(items)

        has_other_items = False
        if item_count > 0:
            if item_count > 1:
                has_other_items = True
            else:
                it0 = items[0]
                it_kod = str(it0.get("kod") or it0.get("id") or "").strip()
                it_ad = str(it0.get("ad") or "").strip().lower()
                u_clean = urun_id.strip()
                u_words = [w for w in urun_adi.lower().split() if len(w) >= 3]
                same_brand = bool(u_words and u_words[0] in it_ad)
                if u_clean and u_clean != it_kod and not same_brand and (urun_adi.lower() not in it_ad and it_ad not in urun_adi.lower()):
                    has_other_items = True

        return JSONResponse({
            "success": True,
            "depo": depo,
            "can_finalize_directly": not has_other_items,
            "has_other_items": has_other_items,
            "item_count": item_count,
            "items": items,
            "total_amount": cart_status.get("total_amount", 0.0),
            "cart_url": cart_status.get("cart_url", ""),
            "checkout_url": cart_status.get("checkout_url", ""),
            "supported": cart_status.get("supported", False)
        })
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Hızlı sipariş kontrol hatası: {str(e)}"}, status_code=500)

@app.post("/api/cart/finalize")
async def finalize_cart_endpoint(request: Request):
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        barkod = str(data.get("barkod", "")).strip()
        urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        force = bool(data.get("force", False))
        satis_sekli = str(data.get("satis_sekli", "")).strip()
        bulk_items = data.get("items", [])

        res = await motor.finalize_order(
            depo=depo,
            urun_id=urun_id or barkod,
            miktar=miktar,
            force=force,
            barkod=barkod,
            satis_sekli=satis_sekli,
            name=urun_adi,
            urun_adi=urun_adi,
            items=bulk_items
        )
        if res.get("success"):
            try:
                to_mark = []
                if barkod or urun_id or urun_adi:
                    to_mark.append({
                        "barkod": barkod or urun_id,
                        "urun_adi": urun_adi,
                        "depo": depo,
                        "miktar": miktar
                    })
                if bulk_items and isinstance(bulk_items, list):
                    for bi in bulk_items:
                        to_mark.append({
                            "barkod": bi.get("barcode") or bi.get("barkod") or bi.get("urun_id") or "",
                            "urun_adi": bi.get("name") or bi.get("urun_adi") or "",
                            "depo": depo,
                            "miktar": bi.get("miktar", 1)
                        })
                # Ayrıca bu depoda bugün SEPETTE olarak bekleyen kalemleri de otomatik SIPARIS_VERILDI'ye yükselt
                cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
                seen_bcs = set()
                for val in cur_orders.values():
                    if isinstance(val, dict) and val.get("depo", "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                        v_bc = val.get("barkod") or ""
                        if v_bc and v_bc not in seen_bcs:
                            seen_bcs.add(v_bc)
                            to_mark.append({
                                "barkod": v_bc,
                                "urun_adi": val.get("urun_adi") or "",
                                "depo": depo,
                                "miktar": val.get("miktar", 1)
                            })
                if to_mark:
                    await asyncio.to_thread(order_tracker.mark_items, to_mark, "SIPARIS_VERILDI", depo)
            except Exception as e:
                print(f"[OrderTracker] finalize_order kayıt uyarısı: {e}")

        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sipariş sonlandırma hatası: {str(e)}"}, status_code=500)

@app.post("/api/cart/clear")
async def clear_cart_endpoint(request: Request):
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        res = await motor.clear_cart(depo=depo)
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepet temizleme hatası: {str(e)}"}, status_code=500)


@app.post("/api/cart/bulk-finalize-check")
async def bulk_finalize_check_endpoint(request: Request):
    """
    Günlük toplu sipariş sonlandırma öncesi sepeti kontrol eder.
    Sepetteki ürünleri, bugün sipariş edilmek istenen beklenen ürünlerle karşılaştırır.
    Farklı/önceden sepette olan ürünleri ayıklar.
    """
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        expected_items = data.get("items", []) or []

        # Eğer istemciden expected_items boş geldiyse (ör. yan menüden doğrudan tıklandıysa veya farklı bilgisayardan açıldıysa),
        # bugün bu depoya SEPETTE olarak kaydedilmiş kalemleri order_tracker'dan çek
        if not expected_items:
            try:
                cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
                seen_bcs = set()
                for val in cur_orders.values():
                    if isinstance(val, dict) and val.get("depo", "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                        v_bc = str(val.get("barkod") or "").strip()
                        if v_bc and v_bc not in seen_bcs:
                            seen_bcs.add(v_bc)
                            expected_items.append({
                                "barcode": v_bc,
                                "name": val.get("urun_adi") or "",
                                "miktar": int(val.get("miktar") or 1)
                            })
            except Exception:
                pass

        cart_status = await motor.get_cart_status(depo=depo)
        cart_items = cart_status.get("items", [])

        # Eğer depo sepeti oturum düşmesi vb. sebeple boş döndüyse ve beklenen ürünler varsa otomatik olarak yeniden sepete ekle
        if len(cart_items) == 0 and len(expected_items) > 0:
            try:
                print(f"[{depo}] bulk-finalize-check: Sepet boş döndü, {len(expected_items)} beklenen ürün otomatik yeniden sepete ekleniyor...")
                await motor.bulk_add_to_cart(depo=depo, items=expected_items)
                cart_status = await motor.get_cart_status(depo=depo)
                cart_items = cart_status.get("items", [])
            except Exception as re_err:
                print(f"[{depo}] Otomatik sepet geri yükleme uyarısı: {re_err}")

        total_amount = cart_status.get("total_amount", 0.0)

        # Beklenen ürünlerin arama indeksini oluştur
        expected_barcodes = set()
        expected_names = []
        for it in expected_items:
            bc = str(it.get("barcode") or it.get("barkod") or "").strip()
            if bc:
                expected_barcodes.add(bc)
                if len(bc) == 14 and bc.startswith("0"):
                    expected_barcodes.add(bc[1:])
            nm = str(it.get("name") or it.get("urun_adi") or "").strip()
            if nm:
                expected_names.append(nm.lower())

        matched_items = []
        extra_items = []

        for c_it in cart_items:
            c_kod = str(c_it.get("kod") or c_it.get("id") or "").strip()
            c_bc = str(c_it.get("barkod") or "").strip()
            c_ad = str(c_it.get("ad") or c_it.get("urun_adi") or "").strip().lower()

            is_matched = False
            if c_kod and (c_kod in expected_barcodes):
                is_matched = True
            elif c_bc and (c_bc in expected_barcodes):
                is_matched = True
            elif c_ad and any(exp in c_ad or c_ad in exp for exp in expected_names if len(exp) >= 3):
                is_matched = True

            if is_matched:
                matched_items.append(c_it)
            else:
                extra_items.append(c_it)

        has_extra_items = len(extra_items) > 0
        can_finalize_directly = (not has_extra_items) and (len(cart_items) > 0)

        extra_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in extra_items)

        return JSONResponse({
            "success": True,
            "depo": depo,
            "can_finalize_directly": can_finalize_directly,
            "has_extra_items": has_extra_items,
            "cart_count": len(cart_items),
            "matched_count": len(matched_items),
            "extra_count": len(extra_items),
            "extra_total": round(extra_total, 2),
            "total_amount": total_amount,
            "matched_items": matched_items,
            "extra_items": extra_items,
            "all_items": cart_items,
            "cart_url": cart_status.get("cart_url", ""),
            "checkout_url": cart_status.get("checkout_url", ""),
            "supported": cart_status.get("supported", False)
        })
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Günlük sipariş sepet kontrol hatası: {str(e)}"}, status_code=500)


@app.post("/api/cart/bulk-finalize-clean-submit")
async def bulk_finalize_clean_submit_endpoint(request: Request):
    """
    Sepetteki farklı ürünleri temizler:
    1. Sepeti tamamen boşaltır (/api/cart/clear)
    2. Sadece bugün gönderilmek istenen günlük sipariş ürünlerini yeniden sepete ekler
    3. Siparişi depoya onaylayıp sonlandırır (/api/cart/finalize force=True)
    """
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        items = data.get("items", [])

        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek günlük sipariş kalemi bulunamadı."}, status_code=400)

        # 1. Sepeti temizle
        clear_res = await motor.clear_cart(depo=depo)
        if not clear_res.get("success"):
            pass

        # 2. Sadece istenen ürünleri sepete ekle
        added_count = 0
        adapter = motor._get_adapter_by_depo(depo)
        if not adapter:
            return JSONResponse({"success": False, "message": f"'{depo}' için adaptör bulunamadı."}, status_code=400)

        for it in items:
            bc = str(it.get("barcode") or it.get("barkod") or "").strip()
            u_id = str(it.get("urun_id") or "").strip()
            mik = int(it.get("miktar") or 1)
            try:
                target_id = u_id if u_id else bc
                add_res = await adapter.add_to_cart(urun_id=target_id, miktar=mik, barkod=bc)
                if add_res.get("success"):
                    added_count += 1
            except Exception as e:
                print(f"[Bulk Finalize Clean] Ürün ekleme hatası ({bc}): {e}")

        if added_count == 0:
            return JSONResponse({"success": False, "message": "Günlük sipariş ürünleri sepete yeniden eklenemedi."}, status_code=500)

        # 3. Siparişi depoya ilet ve sonlandır
        fin_res = await motor.finalize_order(depo=depo, urun_id="", force=True)
        if fin_res.get("success"):
            try:
                await asyncio.to_thread(order_tracker.mark_items, items, "SIPARIS_VERILDI", depo)
            except Exception as e:
                print(f"[OrderTracker] bulk_finalize_clean_submit kayıt uyarısı: {e}")
        return JSONResponse(fin_res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Temizleyip sonlandırma hatası: {str(e)}"}, status_code=500)


# --- Çoklu Bilgisayar (Multi-PC) Günlük Sipariş Senkronizasyon Endpoints ---
@app.get("/api/orders/today")
async def get_today_orders_endpoint():
    """Tüm eczane bilgisayarlarında bugün verilen / sepete eklenen siparişlerin anlık haritasını döner."""
    try:
        orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
        return {"success": True, "orders": orders, "pc_name": order_tracker.pc_name}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/orders/mark")
async def mark_orders_endpoint(request: Request):
    """Bir veya birden fazla ürünü tüm bilgisayarlarda 'SIPARIS_VERILDI' veya 'SEPETTE' olarak işaretler."""
    try:
        data = await request.json()
        items = data.get("items", [])
        durum = str(data.get("durum", "SIPARIS_VERILDI")).strip()
        depo = str(data.get("depo", "MANUEL")).strip()
        count = await asyncio.to_thread(order_tracker.mark_items, items, durum, depo)
        return JSONResponse({"success": True, "count": count, "pc_name": order_tracker.pc_name})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/orders/unmark")
async def unmark_order_endpoint(request: Request):
    """Sipariş verildi işaretini geri alır (tüm bilgisayarlarda tekrar aktif listeye sokar)."""
    try:
        data = await request.json()
        barkod = str(data.get("barkod") or data.get("barcode") or "").strip()
        urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
        ok = await asyncio.to_thread(order_tracker.unmark_item, barkod, urun_adi)
        return JSONResponse({"success": bool(ok), "pc_name": order_tracker.pc_name})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)



# --- Botanik Dermo & OTC Barkod Onarım Endpoints ---
@app.get("/api/botanik/dermo-audit")
async def botanik_dermo_audit_endpoint(brand: str = Query("", description="Marka filtresi"), limit: int = Query(50, ge=1, le=200)):
    """Botanik'teki dermo ürünlerini tarayıp eşleşen gerçek üretici EAN barkodlarını döndürür."""
    return await asyncio.to_thread(audit_botanik_dermo_barcodes, brand_filter=brand, limit=limit)

@app.post("/api/botanik/dermo-sync")
async def botanik_dermo_sync_endpoint(request: Request):
    """Kullanıcının onayladığı gerçek EAN barkodlarını Botanik'in Barkod tablosuna ekler."""
    try:
        data = await request.json()
        items = data.get("items", [])
        return await asyncio.to_thread(apply_botanik_dermo_barcodes, items)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Senkronizasyon hatası: {str(e)}"}, status_code=500)

@app.get("/", response_class=HTMLResponse)
async def get_ui():
    html_content = """<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eczane Depo Şart & Net Maliyet Karşılaştırma</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .depo-alliance { border-left-color: #0284c7; }
        .depo-selcuk { border-left-color: #16a34a; }
        .depo-nevzat { border-left-color: #ea580c; }
        .depo-iskoop { border-left-color: #dc2626; }
        .depo-bek { border-left-color: #0d9488; }
        .depo-ecza1 { border-left-color: #9333ea; }
        .depo-farmazon { border-left-color: #ea580c; }
        .depo-dna { border-left-color: #06b6d4; }
        .depo-eczatrend { border-left-color: #f97316; }
        .depo-eczanetakas { border-left-color: #0284c7; }
        .badge-pulse { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: .5; } }
    </style>
</head>
<body class="min-h-screen text-slate-800">
    <!-- Toast Notifications Container -->
    <div id="toastContainer" class="fixed top-5 right-5 z-[9999] flex flex-col space-y-2 pointer-events-none"></div>

    <!-- Header -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-100">
                    <i class="fa-solid fa-pills text-lg"></i>
                </div>
                <div>
                    <h1 class="text-lg font-bold text-slate-900 leading-tight">Eczane Depo Şart & MF Karşılaştırma</h1>
                    <p class="text-xs text-slate-500 font-medium">Alliance • Selçuk • Nevzat • İSKOOP • BEK • DNA • Ecza1 • Farmazon • Eczatrend • EczaneTakas</p>
                </div>
            </div>
            
            <div class="flex items-center space-x-2 text-xs">
                <!-- Aktif Eczane Otomasyonu Durum Butonu (TRIA veya Botanik) -->
                <button type="button" onclick="openCurrentOtomasyonSettings()" id="headerActiveOtomasyonBtn" class="inline-flex items-center space-x-2 px-3 py-2 rounded-xl font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 transition shadow-xs cursor-pointer" title="TRIA Oracle Eczane Otomasyonu Bağlantı & Ping Durumu">
                    <i id="headerOtomasyonIcon" class="fa-solid fa-database text-amber-600"></i>
                    <span id="headerOtomasyonText">TRIA: Bağlanıyor...</span>
                    <span id="headerOtomasyonDot" class="w-2 h-2 rounded-full bg-amber-500 animate-pulse ml-0.5"></span>
                </button>

                <!-- Depolar Rozeti -->
                <button type="button" onclick="openSettingsModal('depolar')" id="headerDepoBadgeBtn" class="inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition shadow-2xs cursor-pointer" title="Ecza depoları giriş şifrelerini ve aktiflik durumunu aç">
                    <span id="headerDepoDot" class="w-2 h-2 rounded-full bg-emerald-500 mr-0.5"></span>
                    <span id="headerDepoText">6 Depo Aktif</span>
                </button>

                <!-- Sürüm & Otomatik Güncelleme Rozeti -->
                <button type="button" onclick="openUpdateModal()" id="headerVersionBtn" class="inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition shadow-2xs cursor-pointer" title="Program Sürümü ve Güncellemeleri Denetle">
                    <i class="fa-solid fa-cloud-arrow-down text-slate-500" id="headerVersionIcon"></i>
                    <span id="headerVersionText">v1.0.0</span>
                    <span id="headerUpdateDot" class="hidden w-2 h-2 rounded-full bg-amber-500 animate-pulse ml-0.5"></span>
                </button>

                <!-- Belirgin AYARLAR Butonu -->
                <button type="button" onclick="openSettingsModal()" id="headerSettingsBtn" class="inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-slate-900 hover:bg-slate-800 text-white transition shadow-sm cursor-pointer" title="Eczane Otomasyonu (Botanik/TRIA), Depolar ve Sistem Ayarlarını Aç">
                    <i class="fa-solid fa-gear text-amber-400"></i>
                    <span>⚙️ Ayarlar</span>
                </button>
            </div>
        </div>
    </header>

    <!-- Main View Switcher (Tabs) -->
    <div class="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between overflow-x-auto">
            <div class="flex space-x-1 sm:space-x-2">
                <button id="mainTabDepo" onclick="switchMainView('depo')" class="py-3 px-4 sm:px-5 border-b-2 border-emerald-600 text-emerald-800 font-bold text-sm flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-boxes-stacked text-emerald-600"></i>
                    <span>🏢 Depo & MF Karşılaştırma</span>
                    <span class="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">6 Depo</span>
                </button>
                <button id="mainTabSmartOrder" onclick="switchMainView('smart_order')" class="py-3 px-4 sm:px-5 border-b-2 border-transparent text-slate-600 hover:text-slate-900 font-bold text-sm flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-chart-column text-amber-600"></i>
                    <span>📊 6 Aylık Çıkış & Toplu Sipariş (Botanik)</span>
                    <span id="smartOrderTabBadge" class="text-[11px] font-extrabold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300">Akıllı Öneri & MF</span>
                </button>
                <button id="mainTabMarket" onclick="switchMainView('market')" class="py-3 px-4 sm:px-5 border-b-2 border-transparent text-slate-500 hover:text-slate-900 font-semibold text-sm flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-basket-shopping text-indigo-600"></i>
                    <span>🛍️ E-Ticaret & Piyasa Fiyat Kıyaslama</span>
                    <span class="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">9 Platform</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- VIEW 1: DEPO & MF KARŞILAŞTIRMA (Depo Modülü) -->
        <div id="viewDepo" class="space-y-8 relative">
        <!-- Search Box Container with Relative Positioning for Dropdown -->
        <div class="max-w-3xl mx-auto mb-8">
            <!-- Günün Verileri Durum Rozeti -->
            <div id="botanikDataStatusPill" class="mb-3.5 flex items-center justify-between px-3.5 py-2 rounded-xl text-xs transition-all duration-300 bg-amber-50/90 border border-amber-200/80 text-amber-900 shadow-xs backdrop-blur-xs">
                <div class="flex items-center space-x-2.5 min-w-0">
                    <span id="dataStatusIcon" class="inline-block w-2.5 h-2.5 rounded-full border-2 border-amber-500 border-t-transparent animate-spin shrink-0"></span>
                    <span id="dataStatusText" class="truncate font-medium">
                        Günün çıkışları & azalan stok verileri hazırlanıyor...
                    </span>
                </div>
                <div class="flex items-center space-x-1.5 text-[11px] shrink-0">
                    <button type="button" onclick="switchMainView('smart_order')" class="font-bold px-2.5 py-0.5 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer flex items-center space-x-1 shadow-2xs" title="6 Aylık Çıkış, Trend Analizi, Canlı MF ve Akıllı Toplu Sipariş Planlama Sayfasını Aç">
                        <i class="fa-solid fa-table-list text-xs"></i>
                        <span>6 Aylık Toplu Sipariş Planlama</span>
                    </button>
                    <button type="button" onclick="toggleSideWidget(true)" class="font-bold px-2.5 py-0.5 rounded-md bg-amber-200/70 hover:bg-amber-300/80 text-amber-950 transition cursor-pointer flex items-center space-x-1">
                        <i class="fa-solid fa-fire text-amber-600 text-xs"></i>
                        <span>Günün Çıkışları</span>
                    </button>
                </div>
            </div>

            <div class="relative">
                <div class="bg-white p-3 rounded-2xl shadow-lg shadow-slate-100 border border-slate-200 flex items-center space-x-3 relative z-30">
                    <div class="pl-3 text-slate-400">
                        <i class="fa-solid fa-barcode text-xl"></i>
                    </div>
                    <input 
                        type="text" 
                        id="searchInput" 
                        placeholder="İlaç Adı (Parol, Augmentin), Barkod (869...) veya OTC (Ocean, Solgar)..."
                        class="w-full py-2.5 text-base text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
                        autocomplete="off"
                        autofocus
                    >
                    <button 
                        id="searchBtn" 
                        onclick="handleSearchSubmit()"
                        class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-xl text-sm transition-all shadow-md shadow-emerald-200 flex items-center space-x-2 shrink-0 cursor-pointer"
                    >
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <span>Sorgula</span>
                    </button>
                </div>

                <!-- Auto-Suggest Dropdown (Anchored directly under the search bar) -->
                <div id="suggestBox" class="hidden absolute left-0 right-0 top-full mt-1.5 bg-white rounded-2xl border border-slate-200 shadow-2xl z-50 overflow-hidden divide-y divide-slate-100 max-h-96 overflow-y-auto">
                    <!-- Suggestions will be injected here -->
                </div>
            </div>
            
            <!-- Quick Chips -->
            <div class="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-500">
                <span class="font-medium">Hızlı Örnekler:</span>
                <button onclick="selectAndSearch('8699717010109', 'PAROL 500 MG 20 TB')" class="px-2.5 py-1 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 text-slate-600 transition">Parol 500 mg 20 Tb</button>
                <button onclick="selectAndSearch('8699522095650', 'AUGMENTIN BID 1000 MG 14 TB')" class="px-2.5 py-1 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 text-slate-600 transition">Augmentin BID 1g</button>
                <button onclick="handleSearchSubmit('OCEAN')" class="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 text-emerald-700 font-medium transition">Ocean (OTC Seçimi)</button>
                <button onclick="selectAndSearch('8697595872413', 'OCEAN ALFA LIPOIK ASIT 200 MG 30 CAP')" class="px-2.5 py-1 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 text-slate-600 transition">Ocean Alfa Lipoik 200mg</button>
                <button onclick="selectAndSearch('8697595872451', 'OCEAN ALFA LIP ASIT 600 MG 30 CAP')" class="px-2.5 py-1 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 text-slate-600 transition">Ocean Alfa Lipoik 600mg</button>
            </div>
        </div>

        <!-- Loading Spinner -->
        <div id="loading" class="hidden text-center py-16">
            <div class="inline-block animate-spin rounded-full h-12 w-12 border-4 border-emerald-500 border-t-transparent"></div>
            <p class="mt-4 text-base font-semibold text-slate-700" id="loadingText">Depo şartları taranıyor...</p>
            <p class="text-xs text-slate-400 mt-1">Alliance • Selçuk • Nevzat • İSKOOP • BEK • Ecza1 • Farmazon eşzamanlı sorgulanıyor...</p>
        </div>

        <!-- Product Selection Grid (When search query matches multiple products, e.g. OTC brand) -->
        <div id="productSelection" class="hidden mb-8 space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-lg font-bold text-slate-900" id="selectionTitle">Eşleşen Ürünler</h2>
                    <p class="text-xs text-slate-500">Ürünlerin karışmaması için lütfen karşılaştırmak istediğiniz spesifik ürünü seçin:</p>
                </div>
                <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-600" id="selectionCount">0 Ürün</span>
            </div>
            
            <div id="selectionGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- Injected dynamically -->
            </div>
        </div>

        <!-- Result Container -->
        <div id="results" class="hidden space-y-6">
            <!-- Bugün Sipariş Verildi / Sepette Uyarısı (Tüm Bilgisayarlarla Senkron) -->
            <div id="resTodayOrderedBanner" class="hidden"></div>

            <!-- Product Banner -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="text-xs font-bold px-2.5 py-1 rounded bg-slate-100 text-slate-700 font-mono" id="resBarcode">8699717010109</span>
                        <span class="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200" id="resStockCount">3 Depoda Stok Var</span>
                        <!-- Soğuk Zincir Rozeti -->
                        <span id="resColdChainBadge" class="hidden text-xs font-bold text-sky-800 bg-sky-50 px-2.5 py-0.5 rounded border border-sky-300 items-center shadow-xs">
                            <i class="fa-solid fa-snowflake text-sky-500 mr-1 animate-pulse"></i>Soğuk Zincir (+2°C / +8°C)
                        </span>
                        <!-- Muadiller / Eşdeğer Butonu -->
                        <button type="button" id="resEquivalentsBtn" onclick="scrollToMuadillerTab()" title="Aşağıdaki Eczane Analiz panelindeki Muadiller sekmesine git (Stok, Çıkış Hızı ve Geçmiş MF)" class="hidden text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-0.5 rounded border border-indigo-200 transition items-center space-x-1 cursor-pointer">
                            <i class="fa-solid fa-arrows-split-up-and-left mr-1 text-indigo-600"></i>
                            <span id="resEquivalentsBtnText">Muadiller</span>
                        </button>
                    </div>
                    <h2 class="text-xl font-bold text-slate-900 mt-1.5" id="resTitle">PAROL 500 MG 20 TB.</h2>
                    
                    <!-- SGK Kamu İskontosu & Eczacı Kâr Marjı Bilgi Şeridi -->
                    <div class="text-xs text-slate-500 mt-2 flex flex-wrap items-center gap-x-3 gap-y-1.5">
                        <span id="resVatInfo"><i class="fa-solid fa-receipt mr-1"></i>KDV: <strong>%10</strong></span>
                        <span class="text-slate-300">•</span>
                        <span id="resSgkInfo" title="SGK'ya verilen yasal kamu iskontosu"><i class="fa-solid fa-shield-halved mr-1 text-blue-600"></i>Kamu İsk: <strong id="resKamuIsk" class="text-slate-700 font-bold">%0.0</strong></span>
                        <span class="text-slate-300">•</span>
                        <span id="resKarInfo" title="Yasal bareme göre eczacı kâr oranı"><i class="fa-solid fa-coins mr-1 text-amber-600"></i>Yasal Kâr: <strong id="resEczaciKari" class="text-slate-700 font-bold">%0.0</strong></span>
                        <span class="text-slate-300">•</span>
                        <span id="resPsfInfo" title="Perakende Satış / Kutu Etiket Fiyatı"><i class="fa-solid fa-tag mr-1 text-slate-400"></i>Elden Satış (PSF): <strong id="resPsf" class="text-slate-800 font-bold">0.00 ₺</strong></span>
                        <span class="text-slate-300">•</span>
                        <span id="resKsfInfo" title="Kamu Satış Fiyatı = PSF * (1 - Kamu İskontosu)"><i class="fa-solid fa-building-columns mr-1 text-indigo-600"></i>Kamu Fiyatı (KSF): <strong id="resKsf" class="text-indigo-900 font-bold">0.00 ₺</strong></span>
                    </div>

                    <!-- Kâr Gösterge Rozetleri (SGK Kamu Satışı vs Elden Perakende Satışı) -->
                    <div class="mt-3 flex flex-wrap items-center gap-2.5" id="resProfitBadges">
                        <div class="inline-flex items-center px-3 py-1 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900 shadow-2xs" title="SGK reçeteli satışında kutu başına düşen tahmini net kâr (KSF - Alış)">
                            <i class="fa-solid fa-file-prescription mr-1.5 text-blue-600"></i>
                            <span>SGK Reçeteli Kutu Kârı: <strong id="resKamuProfit" class="font-extrabold text-blue-800 ml-1">0.00 ₺</strong></span>
                        </div>
                        <div class="inline-flex items-center px-3 py-1 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 shadow-2xs" title="Reçetesiz elden nakit/kredi kartı satışında kutu başına düşen tahmini net kâr (PSF - Alış)">
                            <i class="fa-solid fa-hand-holding-dollar mr-1.5 text-emerald-600"></i>
                            <span>Elden Satış Kutu Kârı: <strong id="resPerakendeProfit" class="font-extrabold text-emerald-800 ml-1">0.00 ₺</strong></span>
                        </div>
                        <!-- Daha Kârlı Muadil Rozeti (Tıklanınca doğrudan Muadiller sekmesine kayar) -->
                        <div id="resMuadilProfitOpportunity" onclick="scrollToMuadillerTab()" class="hidden cursor-pointer items-center px-3.5 py-1 rounded-xl bg-gradient-to-r from-amber-500/15 via-emerald-500/15 to-teal-500/15 border border-emerald-500/60 text-xs text-emerald-950 font-bold shadow-2xs hover:bg-emerald-100/60 transition" title="SGK eşdeğer grubunda daha kârlı muadil ilaç bulunuyor, görmek için tıklayın">
                            <i class="fa-solid fa-trophy mr-1.5 text-amber-500 animate-pulse"></i>
                            <span>Daha Kârlı Muadil Var: <strong id="resBestMuadilName" class="text-emerald-900 font-extrabold">--</strong> (Kutu başı <strong id="resBestMuadilGain" class="text-emerald-700 font-black">+0.00 ₺</strong> daha kârlı!) <span class="underline ml-1">İncele &rarr;</span></span>
                        </div>
                    </div>
                </div>
                
                <div id="bestDealBanner" class="hidden bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4 flex items-center space-x-4 shadow-sm">
                    <div class="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xl shadow-md shadow-emerald-200">
                        <i class="fa-solid fa-trophy"></i>
                    </div>
                    <div>
                        <div class="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">En Avantajlı Depo</div>
                        <div class="text-lg font-extrabold text-emerald-950" id="bestDepoName">NEVZAT ECZA</div>
                        <div class="text-xs text-emerald-700 mt-0.5">
                            Net Kutu: <strong class="text-sm font-bold text-emerald-800" id="bestCost">52.31 ₺</strong> (KDV Hariç)
                            <span class="text-emerald-600 ml-1">(KDV Dahil: <span id="bestCostKdvli">57.54 ₺</span>)</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TRIA Eczane Stok & Aylık Çıkış Hızı & Akıllı Sipariş Paneli -->
            <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl shadow-xl p-6 text-white border border-indigo-900/50">
                <!-- Üst Başlık & Anlık Raf Stoğu Rozeti -->
                <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-white/10">
                    <div class="space-y-1.5">
                        <div class="flex flex-wrap items-center gap-2">
                            <span id="otoBrandBadge" class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1.5"></span>
                                <span id="otoBrandText">BOTANİK ECZANE OTOMASYONU • CANLI ENTEGRASYON</span>
                            </span>
                            <span id="triaHostSubBadge" class="text-[11px] text-slate-400 font-mono">DESKTOP-L6GG7P6\\BOTANIKSQL (eczane)</span>
                            <button type="button" onclick="openCurrentOtomasyonSettings()" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 transition cursor-pointer flex items-center space-x-1" title="Otomasyon Veritabanı ve Şifre Ayarlarını Aç">
                                <i class="fa-solid fa-gear text-[10px]"></i>
                                <span>Veritabanı & Şifre Ayarları</span>
                            </button>
                        </div>
                        <h3 class="text-lg font-bold text-white flex items-center space-x-2">
                            <span>Eczane Raf Stoğu & Giriş - Çıkış Hareket Analizi</span>
                        </h3>
                        <p class="text-xs text-slate-300 max-w-2xl">
                            Aradığınız ilacın eczanenizdeki anlık raf stoğunu, son 6 aylık Nakit (elden) ve Reçeteli (SGK) çıkışlarını ve depolardan gelen son alış faturalarını (girişleri) gösterir.
                        </p>
                    </div>

                    <!-- Anlık Raf Stoğu Kartı -->
                    <div class="flex items-center space-x-3.5 bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/15">
                        <div class="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center text-xl shadow-lg shadow-emerald-950/40">
                            <i class="fa-solid fa-boxes-stacked"></i>
                        </div>
                        <div>
                            <div class="text-[11px] font-semibold text-slate-300 uppercase tracking-wider">Eczane Raf Stoğu</div>
                            <div class="flex items-baseline space-x-2">
                                <span class="text-2xl font-black text-white" id="triaStockQty">--</span>
                                <span class="text-xs font-semibold text-slate-300">Kutu</span>
                                <span id="triaStockStatusBadge" class="ml-1.5 px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-slate-700 text-slate-200">
                                    Hesaplanıyor...
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Giriş & Çıkış Görünüm Seçici ve Filtreler -->
                <div class="mt-5">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3 border-b border-white/10 pb-2.5">
                        <!-- Sekmeler (Çıkış / Giriş / Her İkisi / Muadiller) -->
                        <div class="flex flex-wrap items-center gap-1.5 bg-white/10 p-1 rounded-xl w-fit">
                            <button type="button" id="tabBtnCikislar" onclick="switchOtomasyonMovementsTab('cikis')" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-white/20 text-white transition flex items-center space-x-1.5 cursor-pointer shadow-xs">
                                <i class="fa-solid fa-chart-simple text-emerald-400"></i>
                                <span>📉 ÇIKIŞ: Satış Hızı (6 Ay)</span>
                            </button>
                            <button type="button" id="tabBtnGirisler" onclick="switchOtomasyonMovementsTab('giris')" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-white/10 transition flex items-center space-x-1.5 cursor-pointer">
                                <i class="fa-solid fa-truck-ramp-box text-cyan-400"></i>
                                <span>📥 GİRİŞ: Son Depo Alışları</span>
                                <span id="badgeGirisCount" class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-cyan-500/30 text-cyan-200">0</span>
                            </button>
                            <button type="button" id="tabBtnBoth" onclick="switchOtomasyonMovementsTab('both')" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-white/10 transition flex items-center space-x-1.5 cursor-pointer">
                                <i class="fa-solid fa-table-columns text-indigo-400"></i>
                                <span>📊 İkisi Birlikte</span>
                            </button>
                            <button type="button" id="tabBtnMuadiller" onclick="switchOtomasyonMovementsTab('muadil')" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-white/10 transition flex items-center space-x-1.5 cursor-pointer">
                                <i class="fa-solid fa-arrows-split-up-and-left text-amber-400"></i>
                                <span>🔄 MUADİLLER (SGK Eşdeğer)</span>
                                <span id="badgeMuadilCount" class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500/30 text-amber-200">0</span>
                            </button>
                        </div>

                        <!-- Legend & Ek Bilgi -->
                        <div id="cikisLegend" class="flex items-center space-x-3 text-[11px] text-slate-400">
                            <span class="flex items-center"><span class="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block mr-1"></span>Nakit / Elden Satış</span>
                            <span class="flex items-center"><span class="w-2.5 h-2.5 rounded-full bg-blue-400 inline-block mr-1"></span>SGK / Reçeteli Çıkış</span>
                        </div>
                        <div id="girisLegend" class="hidden flex items-center space-x-2 text-[11px] text-cyan-300">
                            <i class="fa-solid fa-file-invoice text-xs"></i>
                            <span>İskoop, Hedef, Selçuk, Nevzat vb. faturaları</span>
                        </div>
                        <div id="muadilLegend" class="hidden flex items-center space-x-2 text-[11px] text-amber-300">
                            <i class="fa-solid fa-shield-halved text-xs"></i>
                            <span>SGK Grubu: <strong id="darkEsdegerKodu" class="font-mono text-white">--</strong> • Raf Stoğu, 30 Günlük Çıkış & Geçmiş MF Durumu</span>
                        </div>
                    </div>

                    <!-- 1. Çıkışlar Görünümü (Dinamik Aylık Çıkış Kartları Grid) -->
                    <div id="boxCikislarView" class="space-y-2">
                        <div id="triaMonthlyGrid" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                            <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                                <i class="fa-solid fa-spinner animate-spin mr-1.5"></i>Otomasyon veritabanından aylık hareketler alınıyor...
                            </div>
                        </div>
                    </div>

                    <!-- 2. Girişler Görünümü (Son Depo Alış Faturaları) -->
                    <div id="boxGirislerView" class="hidden space-y-2">
                        <div id="otomasyonGirislerGrid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                            <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                                <i class="fa-solid fa-spinner animate-spin mr-1.5"></i>Depo alış faturaları taranıyor...
                            </div>
                        </div>
                    </div>

                    <!-- 3. Muadiller Görünümü (SGK Eşdeğer Grubu İlaçları, Anlık MF, Kârlılık ve Raf Stoğu) -->
                    <div id="boxMuadillerView" class="hidden space-y-3">
                        <!-- En Kârlı Muadil Üst Vurgu Bannerı -->
                        <div id="boxMuadilHighlightBanner" class="hidden"></div>

                        <div id="otomasyonMuadillerGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                            <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                                <i class="fa-solid fa-spinner animate-spin mr-1.5 text-amber-400"></i>Eşdeğer grup ilaçları ve canlı depo kârlılıkları taranıyor...
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Analiz Metrikleri ve Akıllı Sipariş Çubuğu -->
                <div class="mt-5 pt-4 border-t border-white/10 grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
                    <!-- Sol: Metrikler (3 Sütun) -->
                    <div class="lg:col-span-5 grid grid-cols-3 gap-2 text-center">
                        <div class="bg-white/5 rounded-xl p-2.5 border border-white/10">
                            <div class="text-[10px] text-slate-400">Aylık Ort. Çıkış</div>
                            <div class="text-base font-bold text-emerald-300 mt-0.5" id="triaAvgMonthly">--</div>
                            <div class="text-[9px] text-slate-400" id="triaAvgDaily">-- / Gün</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2.5 border border-white/10">
                            <div class="text-[10px] text-slate-400">Kalan Stok Süresi</div>
                            <div class="text-base font-bold text-cyan-300 mt-0.5" id="triaDaysLeft">--</div>
                            <div class="text-[9px] text-slate-400">Yeterlilik</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2.5 border border-white/10">
                            <div class="text-[10px] text-slate-400">30 Günlük İhtiyaç</div>
                            <div class="text-base font-bold text-amber-300 mt-0.5" id="triaOrderSuggested">--</div>
                            <div class="text-[9px] text-slate-400">Önerilen Sipariş</div>
                        </div>
                    </div>

                    <!-- Sağ: Entegre Hızlı Sipariş ve Sepete Ekleme Alanı -->
                    <div class="lg:col-span-7 bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/15 flex flex-col sm:flex-row items-center justify-between gap-3">
                        <div class="flex items-center space-x-3 w-full sm:w-auto">
                            <div>
                                <label class="text-[10px] font-semibold text-slate-300 block mb-0.5">Sipariş (Kutu)</label>
                                <input 
                                    type="number" 
                                    id="simQtyInput" 
                                    value="25" 
                                    min="1" 
                                    max="5000"
                                    oninput="onSimulatorChange()"
                                    class="w-24 bg-white text-slate-900 font-extrabold px-2.5 py-1.5 rounded-lg text-center text-base focus:outline-none focus:ring-2 focus:ring-emerald-400"
                                >
                            </div>
                            <div class="flex flex-wrap gap-1">
                                <button type="button" onclick="setSimulatorQty(10)" class="px-2 py-1 text-[11px] font-semibold rounded bg-white/10 hover:bg-white/20 text-white transition cursor-pointer">10</button>
                                <button type="button" onclick="setSimulatorQty(25)" class="px-2 py-1 text-[11px] font-semibold rounded bg-white/10 hover:bg-white/20 text-white transition cursor-pointer">25</button>
                                <button type="button" onclick="setSimulatorQty(50)" class="px-2 py-1 text-[11px] font-semibold rounded bg-white/10 hover:bg-white/20 text-white transition cursor-pointer">50</button>
                                <button type="button" id="btnQuickSuggested" onclick="setSuggestedQty()" class="px-2 py-1 text-[11px] font-semibold rounded bg-amber-500/30 hover:bg-amber-500/50 text-amber-200 border border-amber-400/40 transition cursor-pointer" title="Aylık ortalama satışa göre eksik kalan miktarı seçer">
                                    <i class="fa-solid fa-bullseye mr-1"></i>Önerilen
                                </button>
                            </div>
                        </div>

                        <div class="flex items-center space-x-3 w-full sm:w-auto justify-end">
                            <div class="text-right hidden sm:block">
                                <div class="text-[10px] text-slate-300 font-medium" id="simDepoNote">En Avantajlı Depo</div>
                                <div class="text-sm font-extrabold text-emerald-300" id="simTotalInvoice">0.00 ₺</div>
                                <div class="text-[9px] text-slate-400" id="simInvoiceKdvli">KDV Dahil: 0.00 ₺</div>
                            </div>
                            <button id="simAddToCartBtn" onclick="addSimulatedToCart(this)" class="px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-950/40 flex items-center space-x-2 cursor-pointer shrink-0">
                                <i class="fa-solid fa-cart-arrow-down text-sm"></i>
                                <span id="simAddToCartText">Sepete Ekle</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Detaylı MF & Baremler Açılır Akordeonu -->
                <div class="mt-3 pt-2 text-right">
                    <button type="button" onclick="toggleMfDetails()" class="text-[11px] text-indigo-300 hover:text-white transition inline-flex items-center space-x-1 cursor-pointer">
                        <i class="fa-solid fa-circle-chevron-down mr-1" id="mfToggleIcon"></i>
                        <span>MF Baremleri & Birim Kutu Maliyet Detayını Göster</span>
                    </button>
                    <div id="simResultsBox" class="hidden mt-3 pt-3 border-t border-white/10 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-center">
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Faturalanan Kutu</div>
                            <div class="text-base font-bold text-white mt-0.5" id="simPaidBoxes">--</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-emerald-400 font-semibold">Bedelsiz MF</div>
                            <div class="text-base font-bold text-emerald-400 mt-0.5" id="simFreeBoxes">--</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Teslim Alınan</div>
                            <div class="text-base font-bold text-white mt-0.5" id="simTotalBoxes">--</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Birim Net (KDV Hariç)</div>
                            <div class="text-base font-bold text-emerald-400 mt-0.5" id="simUnitNet">0.00 ₺</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Birim Net (KDV Dahil)</div>
                            <div class="text-base font-bold text-cyan-300 mt-0.5" id="simUnitKdvli">0.00 ₺</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Depo Şartı</div>
                            <div class="text-xs font-bold text-slate-200 mt-1 truncate" id="simMfText">--</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Table of Warehouse Conditions -->
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                    <div>
                        <h3 class="font-bold text-slate-900 text-sm">Depo Ticari Şartları ve Maliyet Karşılaştırması</h3>
                        <p class="text-xs text-slate-500">Tüm depolarda geçerli MF kademeleri, vadeler ve KDV hariç/dahil net fiyatlar</p>
                    </div>
                    <span class="text-xs text-slate-400"><i class="fa-solid fa-circle-info mr-1"></i>MF rozetlerine tıklayarak simülatörü güncelleyebilirsiniz</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-sm">
                        <thead>
                            <tr class="bg-slate-50/75 border-b border-slate-100 text-slate-500 text-xs uppercase tracking-wider font-semibold">
                                <th class="py-3 px-6">Depo / Platform</th>
                                <th class="py-3 px-6">Stok Durumu</th>
                                <th class="py-3 px-6">DSF (KDV Hariç)</th>
                                <th class="py-3 px-6">MF Kademeleri</th>
                                <th class="py-3 px-6">Vade & İskonto</th>
                                <th class="py-3 px-6">Net Kutu (KDV Hariç)</th>
                                <th class="py-3 px-6">Net Kutu (KDV Dahil)</th>
                                <th class="py-3 px-6 text-right">Sepet İşlemi</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody" class="divide-y divide-slate-100">
                            <!-- Injected dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- End of results -->

        <!-- ============================================================== -->
        <!-- SAĞ TARAFTA KOMPAKT GÜNLÜK ÇIKIŞ & AZALAN STOK ÇEKMECESİ      -->
        <!-- ============================================================== -->
        <!-- 1. Katlanmış Durum Butonu (Ekranın Sağ Kenarında Fazla Yer Kaplamayan Rozet) -->
        <button 
            id="criticalMiniBadgeBtn" 
            onclick="toggleSideWidget(true)" 
            class="fixed right-0 top-36 z-40 bg-slate-900/90 hover:bg-slate-900 text-white py-2.5 px-3 rounded-l-2xl shadow-2xl flex items-center space-x-2 border-l-2 border-amber-400 cursor-pointer transition transform hover:-translate-x-1 backdrop-blur-md" 
            title="Günün Çıkışları ve Azalan Stok Listesini Aç"
        >
            <i class="fa-solid fa-fire text-amber-400 text-sm animate-pulse"></i>
            <span class="text-xs font-bold tracking-tight">Günün Çıkışları</span>
            <span id="miniSideCriticalCount" class="bg-amber-400 text-slate-950 font-black text-[10px] px-1.5 py-0.5 rounded-full font-mono">0</span>
        </button>

        <!-- 2. Açılabilir Kompakt Sağ Panel (Ana Düzeni Bozmayan Floating Panel) -->
        <div 
            id="criticalSideWidget" 
            class="hidden fixed right-4 top-24 z-40 w-80 sm:w-[420px] bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200/90 shadow-2xl overflow-hidden flex flex-col transition-all duration-300"
            style="max-height: calc(100vh - 120px);"
        >
            <!-- Başlık Çubuğu -->
            <div class="px-3.5 py-2.5 bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white flex items-center justify-between">
                <div class="flex items-center space-x-2 min-w-0">
                    <div class="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs shrink-0">
                        <i class="fa-solid fa-fire text-amber-400"></i>
                    </div>
                    <div class="truncate">
                        <h4 class="font-extrabold text-xs text-white leading-tight">Günün Çıkışları</h4>
                        <p class="text-[9px] text-slate-300">Azalan Stok & Sipariş Dağıtıcı</p>
                    </div>
                </div>
                <div class="flex items-center space-x-1.5 shrink-0">
                    <span id="sideCriticalCountBadge" class="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-400 text-slate-950 font-mono">0</span>
                    <button onclick="loadCriticalStockList(true)" class="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white flex items-center justify-center transition cursor-pointer" title="Listeyi Yenile">
                        <i class="fa-solid fa-arrows-rotate text-[10px]" id="criticalRefreshIcon"></i>
                    </button>
                    <!-- Küçült / Kapat Butonu -->
                    <button onclick="toggleSideWidget(false)" class="w-6 h-6 rounded-lg bg-white/10 hover:bg-rose-500/30 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer" title="Kapat">
                        <i class="fa-solid fa-minus text-[10px]"></i>
                    </button>
                </div>
            </div>

            <!-- Filtreleme & Arama Çubuğu -->
            <div class="p-2 bg-slate-50 border-b border-slate-200/80 space-y-1.5">
                <div class="relative">
                    <i class="fa-solid fa-magnifying-glass absolute left-2.5 top-2 text-[10px] text-slate-400"></i>
                    <input 
                        type="text" 
                        id="criticalFilterInput" 
                        placeholder="Listede ara (ilaç / barkod)..." 
                        oninput="filterCriticalList()"
                        class="w-full pl-7 pr-2.5 py-1 text-[11px] bg-white border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-400"
                    />
                </div>
                <!-- Tükenen (0) & Eksiye Düşen (<0) Özel Takip Panosu -->
                <div class="grid grid-cols-2 gap-1.5 pt-0.5" id="criticalZeroNegSummaryBar">
                    <button 
                        type="button" 
                        id="cardCritSummaryZero"
                        onclick="toggleCriticalZeroOrNegFilter('zero')" 
                        class="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100/80 border border-rose-200 text-left transition cursor-pointer group"
                        title="Stoğu tam 0'a inen (tükenen) ürünleri listele (Tekrar tıklayınca tüm kritik listeye döner)"
                    >
                        <div class="flex items-center space-x-1.5 min-w-0">
                            <span class="w-5 h-5 rounded-md bg-rose-600 text-white flex items-center justify-center text-[10px] font-black shrink-0 shadow-2xs">0</span>
                            <div class="truncate">
                                <div class="text-[9px] font-extrabold text-rose-950 leading-tight">Tükenen (0'a İnen)</div>
                                <div class="text-[8px] text-rose-600 font-semibold leading-tight" id="critZeroSubText">Stok Sıfırlandı</div>
                            </div>
                        </div>
                        <span id="critZeroCountBadge" class="px-1.5 py-0.5 rounded-md bg-white text-rose-800 border border-rose-200 font-black text-[10px] font-mono shrink-0">0</span>
                    </button>

                    <button 
                        type="button" 
                        id="cardCritSummaryNegative"
                        onclick="toggleCriticalZeroOrNegFilter('negative')" 
                        class="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-purple-50 hover:bg-purple-100/80 border border-purple-200 text-left transition cursor-pointer group"
                        title="Stoğu eksiye (-1, -2 vb.) düşen ürünleri listele (Tekrar tıklayınca tüm kritik listeye döner)"
                    >
                        <div class="flex items-center space-x-1.5 min-w-0">
                            <span class="w-5 h-5 rounded-md bg-purple-700 text-white flex items-center justify-center text-[10px] font-black shrink-0 shadow-2xs">-</span>
                            <div class="truncate">
                                <div class="text-[9px] font-extrabold text-purple-950 leading-tight">Eksiye Düşen (&lt;0)</div>
                                <div class="text-[8px] text-purple-700 font-semibold leading-tight" id="critNegativeSubText">0 Kutu Açık</div>
                            </div>
                        </div>
                        <span id="critNegativeCountBadge" class="px-1.5 py-0.5 rounded-md bg-white text-purple-900 border border-purple-200 font-black text-[10px] font-mono shrink-0">0</span>
                    </button>
                </div>

                <div class="flex items-center justify-between pt-0.5 gap-1">
                    <div class="flex flex-wrap items-center gap-1 text-[10px]">
                        <button type="button" onclick="setCriticalFilterMode('days_21')" id="btnCritFilter21" class="px-2 py-0.5 rounded-md font-bold bg-slate-900 text-white transition text-[9px] cursor-pointer" title="Stoğu 21 gün ve altı kalan kritik ürünler">≤21 Gün</button>
                        <button type="button" onclick="setCriticalFilterMode('zero')" id="btnCritFilterZero" class="px-2 py-0.5 rounded-md font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 transition text-[9px] cursor-pointer" title="Stoğu tam 0 olan tükenen ürünler">Tükenen (0)</button>
                        <button type="button" onclick="setCriticalFilterMode('negative')" id="btnCritFilterNegative" class="px-2 py-0.5 rounded-md font-bold bg-purple-100 hover:bg-purple-200 text-purple-900 transition text-[9px] cursor-pointer" title="Stoğu 0'ın altına (eksiye) düşen ürünler">Eksi (&lt;0)</button>
                        <button type="button" onclick="setCriticalFilterMode('mf_only')" id="btnCritFilterMf" class="px-2 py-0.5 rounded-md font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 transition text-[9px] cursor-pointer flex items-center space-x-1" title="Depolarda aktif MF'si olan veya geçmişte MF'li alınanları filtrele">
                            <i class="fa-solid fa-gift text-amber-600 text-[8px]"></i>
                            <span>MF'liler</span>
                        </button>
                        <button type="button" onclick="setCriticalFilterMode('all')" id="btnCritFilterAll" class="px-2 py-0.5 rounded-md font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 transition text-[9px] cursor-pointer" title="Tüm çıkışları göster">Tümü</button>
                    </div>
                    <button 
                        type="button" 
                        id="btnToggleMfBadges" 
                        onclick="toggleMfBadgesView()" 
                        class="px-2 py-0.5 rounded-md font-extrabold text-[9px] transition cursor-pointer flex items-center space-x-1 bg-amber-500 text-white shadow-2xs hover:bg-amber-600 shrink-0"
                        title="MF rozetlerini göster / gizle"
                    >
                        <i class="fa-solid fa-gift text-[8px]"></i>
                        <span id="btnToggleMfBadgesText">MF: Açık</span>
                    </button>
                </div>
                <!-- Çoklu Bilgisayar Sipariş Durumu & Gizleme Barı -->
                <div class="flex items-center justify-between pt-1 border-t border-slate-200/70 text-[9px]">
                    <div class="flex items-center space-x-1.5 text-slate-600 font-semibold" title="Eczanedeki tüm bilgisayarlar Tria/Botanik ortak veritabanı üzerinden anlık senkronize edilir">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span>Ortak Sipariş Takibi:</span>
                        <span id="orderedTodayCountBadge" class="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 font-extrabold border border-emerald-200">0 Sipariş</span>
                    </div>
                    <button 
                        type="button" 
                        id="btnToggleHideOrdered" 
                        onclick="toggleHideOrderedItems()" 
                        class="px-2 py-0.5 rounded-md font-extrabold text-[9px] transition cursor-pointer flex items-center space-x-1 bg-slate-200 text-slate-700 hover:bg-slate-300"
                        title="Sipariş verilen ürünleri listeden tamamen gizle veya en altta uyarı rozetiyle göster"
                    >
                        <i class="fa-solid fa-eye-slash text-[8px]" id="btnToggleHideOrderedIcon"></i>
                        <span id="btnToggleHideOrderedText">Siparişlileri Gizle</span>
                    </button>
                </div>
            </div>

            <!-- Toplu Sipariş Aksiyon Barı (Alliance Healthcare) -->
            <div class="p-2.5 bg-gradient-to-r from-sky-50 via-blue-50 to-indigo-50 border-b border-sky-200 space-y-2">
                <div class="flex items-center justify-between text-xs">
                    <div class="flex items-center space-x-2">
                        <label class="inline-flex items-center space-x-1.5 cursor-pointer select-none group" onclick="handleMasterSelectClick(event)">
                            <input type="checkbox" id="bulkSelectAllCheck" class="sr-only" checked>
                            <span id="bulkSelectAllVisualBox" class="w-4 h-4 rounded border-2 border-sky-600 bg-sky-600 text-white flex items-center justify-center transition-all shadow-2xs group-hover:ring-2 group-hover:ring-sky-300">
                                <i id="bulkSelectAllVisualIcon" class="fa-solid fa-check text-[10px] leading-none"></i>
                            </span>
                            <span class="font-bold text-[11px] text-slate-800 group-hover:text-sky-900">Tümünü Seç</span>
                        </label>
                        <span id="bulkSelectedBadge" class="text-[10px] font-black px-2 py-0.5 rounded-full bg-sky-200 text-sky-900 font-mono">0 Seçili</span>
                    </div>
                    <div class="flex items-center space-x-1 text-[10px]">
                        <button type="button" onclick="selectTopNItems(40)" class="px-2 py-0.5 rounded bg-white hover:bg-sky-100 text-sky-800 border border-sky-200 font-bold transition cursor-pointer" title="Listenin ilk 40 kalemini seç">İlk 40'ı Seç</button>
                        <button type="button" onclick="clearBulkSelection()" class="px-1.5 py-0.5 rounded bg-white hover:bg-slate-100 text-slate-500 border border-slate-200 transition cursor-pointer" title="Seçimleri temizle">Temizle</button>
                    </div>
                </div>

                <!-- Toplu Depo Siparişi Gönderim Paneli -->
                <div class="space-y-1.5 pt-1">
                    <div class="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                        <span>🚀 Kalemleri Sepete Aktar (Tek Tık):</span>
                        <span class="text-[9px] text-sky-700 font-bold bg-sky-100 px-1.5 py-0.5 rounded">Hızlı Aktarım</span>
                    </div>

                    <div class="grid grid-cols-2 gap-1.5">
                        <!-- Alliance Butonu -->
                        <button 
                            type="button" 
                            id="btnSendToAlliance"
                            onclick="triggerBulkOrder('ALLIANCE')" 
                            class="py-2 px-2 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-extrabold text-[11px] rounded-xl shadow-sm transition-all flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98"
                            title="Alliance Healthcare B2B sepetine ekle"
                        >
                            <i class="fa-solid fa-truck-fast text-sky-200 text-xs"></i>
                            <span id="btnSendToAllianceText">Alliance</span>
                        </button>

                        <!-- Selçuk Butonu -->
                        <button 
                            type="button" 
                            id="btnSendToSelcuk"
                            onclick="triggerBulkOrder('SELCUK')" 
                            class="py-2 px-2 bg-gradient-to-r from-rose-600 to-red-700 hover:from-rose-700 hover:to-red-800 text-white font-extrabold text-[11px] rounded-xl shadow-sm transition-all flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98"
                            title="Selçuk Ecza Deposu sepetine ekle"
                        >
                            <i class="fa-solid fa-paper-plane text-rose-200 text-xs"></i>
                            <span id="btnSendToSelcukText">Selçuk</span>
                        </button>

                        <!-- İSKOOP Butonu -->
                        <button 
                            type="button" 
                            id="btnSendToIskoop"
                            onclick="triggerBulkOrder('ISKOOP')" 
                            class="py-2 px-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-extrabold text-[11px] rounded-xl shadow-sm transition-all flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98"
                            title="İSKOOP E-Şube taslak siparişine ekle"
                        >
                            <i class="fa-solid fa-cart-plus text-emerald-200 text-xs"></i>
                            <span id="btnSendToIskoopText">İSKOOP</span>
                        </button>

                        <!-- Nevzat Butonu -->
                        <button 
                            type="button" 
                            id="btnSendToNevzat"
                            onclick="triggerBulkOrder('NEVZAT')" 
                            class="py-2 px-2 bg-gradient-to-r from-amber-600 to-orange-700 hover:from-amber-700 hover:to-orange-800 text-white font-extrabold text-[11px] rounded-xl shadow-sm transition-all flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98"
                            title="Nevzat Ecza Deposu sepetine ekle"
                        >
                            <i class="fa-solid fa-boxes-packing text-amber-200 text-xs"></i>
                            <span id="btnSendToNevzatText">Nevzat</span>
                        </button>
                    </div>

                    <!-- Hızlı Depo Sipariş Sonlandırma Butonları -->
                    <div class="pt-2 border-t border-sky-100 flex items-center justify-between">
                        <span class="text-[9px] text-slate-500 font-extrabold uppercase tracking-wider">Siparişi Bitir & Gönder:</span>
                        <div class="flex items-center space-x-1">
                            <button type="button" onclick="openBulkFinalizeFlow('SELCUK')" class="px-2 py-0.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10px] font-black border border-rose-200 transition flex items-center space-x-1 cursor-pointer" title="Selçuk Ecza sepetini doğrula ve depoya gönder">
                                <i class="fa-solid fa-paper-plane text-[8px]"></i>
                                <span>Selçuk</span>
                            </button>
                            <button type="button" onclick="openBulkFinalizeFlow('ALLIANCE')" class="px-2 py-0.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 text-[10px] font-black border border-sky-200 transition flex items-center space-x-1 cursor-pointer" title="Alliance Healthcare sepetini doğrula ve depoya gönder">
                                <i class="fa-solid fa-paper-plane text-[8px]"></i>
                                <span>Alliance</span>
                            </button>
                            <button type="button" onclick="openBulkFinalizeFlow('ISKOOP')" class="px-2 py-0.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-[10px] font-black border border-emerald-200 transition flex items-center space-x-1 cursor-pointer" title="İSKOOP E-Şube sepetini doğrula ve depoya gönder">
                                <i class="fa-solid fa-paper-plane text-[8px]"></i>
                                <span>İSKOOP</span>
                            </button>
                            <button type="button" onclick="openBulkFinalizeFlow('NEVZAT')" class="px-2 py-0.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-700 text-[10px] font-black border border-amber-200 transition flex items-center space-x-1 cursor-pointer" title="Nevzat Ecza sepetini doğrula ve depoya gönder">
                                <i class="fa-solid fa-paper-plane text-[8px]"></i>
                                <span>Nevzat</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dikey / Alt Alta İlaç Kartları Listesi -->
            <div id="criticalStockListContainer" class="p-2 overflow-y-auto space-y-1.5 divide-y divide-slate-100 flex-1">
                <div class="p-4 text-center text-slate-400 text-xs">
                    <i class="fa-solid fa-spinner fa-spin text-amber-500 mr-1.5"></i>Yükleniyor...
                </div>
            </div>

            <!-- Panel Altı Kısa Bilgi -->
            <div class="px-2.5 py-1.5 bg-slate-50 border-t border-slate-200 text-center">
                <span class="text-[9px] text-slate-400">💡 İlacın üzerine tıklayarak hemen depolarda sorgulayın</span>
            </div>
        </div>
        </div> <!-- End of viewDepo -->

        <!-- ======================================================================= -->
        <!-- VIEW 1.5: BOTANİK 6 AYLIK ÇIKIŞ & AKILLI TOPLU SİPARİŞ PLANLAMA         -->
        <!-- ======================================================================= -->
        <div id="viewSmartOrder" class="hidden space-y-6">
            <!-- Üst Başlık & Botanik Canlı Durum Bannerı -->
            <div class="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-3xl p-6 text-white shadow-xl border border-emerald-800/50">
                <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div class="space-y-1.5">
                        <div class="flex flex-wrap items-center gap-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-black tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1.5"></span>
                                <span>🌿 BOTANİK ECZANE OTOMASYONU • 6 AYLIK ÇIKIŞ & TOPLU SİPARİŞ MERKEZİ</span>
                            </span>
                            <span class="text-[11px] text-amber-300 font-semibold bg-amber-500/15 px-2.5 py-0.5 rounded-full border border-amber-400/30">
                                <i class="fa-solid fa-wand-magic-sparkles mr-1"></i>Trend Analizi & Canlı MF Önerisi Aktif
                            </span>
                        </div>
                        <h2 class="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5">
                            <i class="fa-solid fa-chart-column text-amber-400"></i>
                            <span>6 Aylık Çıkış Analizi, Tahmini Sipariş Ayarlayıcı & Canlı MF Takibi</span>
                        </h2>
                        <p class="text-xs text-slate-300 max-w-3xl leading-relaxed">
                            İlaçların son 6 aylık ay-ay satışlarını, <strong class="text-emerald-300">🟢 Stabil Çıkan</strong> ve <strong class="text-rose-300">📉 Çıkışı Son Zamanlarda Azalan</strong> uyarılarını, şu anki var olan depo MF'lerini ve geçmiş fatura MF'lerini tek tabloda görün; hedef gün sayısına göre sipariş rakamlarını belirleyip tek tıkla depolara aktarın.
                        </p>
                    </div>
                    <div class="flex flex-wrap items-center gap-2 shrink-0">
                        <button type="button" onclick="resolveAllSmartOrderMfs(true)" id="btnSmartResolveMf" class="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-black text-xs shadow-lg shadow-amber-950/30 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-gift text-sm" id="smartResolveMfIcon"></i>
                            <span id="smartResolveMfText">🎁 Şu Anki Var Olan MF'leri Tara</span>
                        </button>
                        <button type="button" onclick="loadSmartOrderList(true)" class="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/15 transition flex items-center space-x-1.5 cursor-pointer">
                            <i class="fa-solid fa-arrows-rotate" id="smartOrderRefreshIcon"></i>
                            <span>Listeyi Yenile</span>
                        </button>
                    </div>
                </div>

                <!-- 6 Özet KPI & Hızlı Filtre Kartları -->
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-5 pt-5 border-t border-white/10">
                    <div onclick="setSmartTrendFilter('ALL')" id="smartKpiAll" class="p-3 rounded-2xl bg-white/15 border-2 border-emerald-400 cursor-pointer transition hover:bg-white/20">
                        <div class="text-[10px] font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                            <span>Toplam Kalem</span>
                            <i class="fa-solid fa-layer-group text-slate-300"></i>
                        </div>
                        <div class="text-2xl font-black text-white mt-1" id="smartStatTotal">0</div>
                        <div class="text-[10px] text-emerald-300 font-semibold mt-0.5">Tümünü Göster</div>
                    </div>

                    <div onclick="setSmartTrendFilter('STABIL')" id="smartKpiStabil" class="p-3 rounded-2xl bg-emerald-950/50 border border-emerald-500/40 cursor-pointer transition hover:bg-emerald-900/50">
                        <div class="text-[10px] font-bold text-emerald-300 uppercase tracking-wider flex items-center justify-between">
                            <span>🟢 Stabil Çıkan</span>
                            <i class="fa-solid fa-shield-heart text-emerald-400"></i>
                        </div>
                        <div class="text-2xl font-black text-emerald-300 mt-1" id="smartStatStabil">0</div>
                        <div class="text-[10px] text-emerald-200/80 mt-0.5">MF'li Alıma Uygun</div>
                    </div>

                    <div onclick="setSmartTrendFilter('AZALAN')" id="smartKpiAzalan" class="p-3 rounded-2xl bg-rose-950/50 border border-rose-500/40 cursor-pointer transition hover:bg-rose-900/50">
                        <div class="text-[10px] font-bold text-rose-300 uppercase tracking-wider flex items-center justify-between">
                            <span>📉 Çıkışı Azalan</span>
                            <i class="fa-solid fa-arrow-trend-down text-rose-400"></i>
                        </div>
                        <div class="text-2xl font-black text-rose-300 mt-1" id="smartStatAzalan">0</div>
                        <div class="text-[10px] text-rose-200/80 mt-0.5">Fazla Stok Yapmayın!</div>
                    </div>

                    <div onclick="setSmartTrendFilter('ARTAN')" id="smartKpiArtan" class="p-3 rounded-2xl bg-sky-950/50 border border-sky-500/40 cursor-pointer transition hover:bg-sky-900/50">
                        <div class="text-[10px] font-bold text-sky-300 uppercase tracking-wider flex items-center justify-between">
                            <span>📈 Çıkışı Artan</span>
                            <i class="fa-solid fa-arrow-trend-up text-sky-400"></i>
                        </div>
                        <div class="text-2xl font-black text-sky-300 mt-1" id="smartStatArtan">0</div>
                        <div class="text-[10px] text-sky-200/80 mt-0.5">Talebi Yükselenler</div>
                    </div>

                    <div onclick="setSmartTrendFilter('MF_ONLY')" id="smartKpiMf" class="p-3 rounded-2xl bg-amber-950/50 border border-amber-500/40 cursor-pointer transition hover:bg-amber-900/50">
                        <div class="text-[10px] font-bold text-amber-300 uppercase tracking-wider flex items-center justify-between">
                            <span>🎁 MF Fırsatı Olan</span>
                            <i class="fa-solid fa-gift text-amber-400"></i>
                        </div>
                        <div class="text-2xl font-black text-amber-300 mt-1" id="smartStatMf">0</div>
                        <div class="text-[10px] text-amber-200/80 mt-0.5">Canlı / Geçmiş MF</div>
                    </div>

                    <div onclick="setSmartTrendFilter('ORDERED')" id="smartKpiOrdered" class="p-3 rounded-2xl bg-indigo-950/50 border border-indigo-400/40 cursor-pointer transition hover:bg-indigo-900/50">
                        <div class="text-[10px] font-bold text-indigo-300 uppercase tracking-wider flex items-center justify-between">
                            <span>✅ Sipariş Verilen</span>
                            <i class="fa-solid fa-circle-check text-indigo-400"></i>
                        </div>
                        <div class="text-2xl font-black text-indigo-300 mt-1" id="smartStatOrdered">0</div>
                        <div class="text-[10px] text-indigo-200/80 mt-0.5">Ortak Sipariş Takibi</div>
                    </div>
                </div>
            </div>

            <!-- Kontrol Paneli: 1) Liste Kapsamı 2) Günlük Tahmini Sipariş Hedefi Ayarlayıcı 3) Filtre & Arama -->
            <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 space-y-4">
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
                    <!-- Sol (4/12): Liste Kapsamı (Bugün Çıkanlar / Son 7 Gün / 6 Ayda En Çok Çıkanlar) -->
                    <div class="lg:col-span-5 space-y-1.5">
                        <label class="text-[11px] font-extrabold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
                            <i class="fa-solid fa-list-check text-emerald-600"></i>
                            <span>1. İncelenecek Çıkış Listesi Kapsamı:</span>
                        </label>
                        <div class="flex flex-wrap gap-1.5">
                            <button type="button" id="btnSmartScopeToday" onclick="changeSmartOrderScope('today')" class="px-3 py-2 rounded-xl text-xs font-extrabold bg-emerald-600 text-white shadow-xs transition cursor-pointer flex items-center gap-1.5">
                                <i class="fa-solid fa-fire text-amber-300"></i>
                                <span>Bugün Çıkanlar</span>
                            </button>
                            <button type="button" id="btnSmartScopeWeek" onclick="changeSmartOrderScope('week')" class="px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer flex items-center gap-1.5">
                                <i class="fa-solid fa-calendar-week text-sky-600"></i>
                                <span>Son 7 Gün Çıkanlar</span>
                            </button>
                            <button type="button" id="btnSmartScopeTop6m" onclick="changeSmartOrderScope('top6m')" class="px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer flex items-center gap-1.5">
                                <i class="fa-solid fa-trophy text-amber-600"></i>
                                <span>6 Ayda En Çok Çıkanlar</span>
                            </button>
                        </div>
                    </div>

                    <!-- Orta (5/12): Günlük Tahmini Sipariş Hedefi Ayarlayıcı -->
                    <div class="lg:col-span-7 bg-gradient-to-r from-amber-50 via-orange-50/70 to-emerald-50/60 p-3.5 rounded-2xl border border-amber-200/90 space-y-2">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <label class="text-xs font-black text-slate-900 flex items-center gap-1.5">
                                <i class="fa-solid fa-sliders text-amber-600"></i>
                                <span>2. Günlük Tahmini Sipariş Hedefi (Kaç Günlük Stok Tamamlansın?):</span>
                            </label>
                            <span class="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500 text-white shadow-2xs" id="smartTargetDaysLabel">
                                Hedef: 15 Günlük Stok
                            </span>
                        </div>
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <div class="flex flex-wrap items-center gap-1">
                                <button type="button" onclick="setSmartTargetDays(1)" id="btnSmartDays_1" class="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 transition cursor-pointer" title="Sadece 1 günlük / bugünkü eksilen kadar sipariş öner">1 Gün</button>
                                <button type="button" onclick="setSmartTargetDays(7)" id="btnSmartDays_7" class="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 transition cursor-pointer">7 Gün</button>
                                <button type="button" onclick="setSmartTargetDays(10)" id="btnSmartDays_10" class="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 transition cursor-pointer">10 Gün</button>
                                <button type="button" onclick="setSmartTargetDays(15)" id="btnSmartDays_15" class="px-2.5 py-1.5 rounded-lg text-xs font-black bg-amber-600 text-white border border-amber-700 shadow-xs transition cursor-pointer">15 Gün</button>
                                <button type="button" onclick="setSmartTargetDays(21)" id="btnSmartDays_21" class="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 transition cursor-pointer">21 Gün</button>
                                <button type="button" onclick="setSmartTargetDays(30)" id="btnSmartDays_30" class="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 transition cursor-pointer">30 Gün (1 Ay)</button>
                                <button type="button" onclick="setSmartTargetDays(45)" id="btnSmartDays_45" class="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 transition cursor-pointer">45 Gün</button>
                                <button type="button" onclick="setSmartTargetDays(60)" id="btnSmartDays_60" class="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 transition cursor-pointer">60 Gün (2 Ay)</button>
                            </div>
                            <div class="flex items-center space-x-1.5 bg-white px-2.5 py-1 rounded-xl border border-amber-300">
                                <span class="text-[11px] font-bold text-slate-600">Özel Gün:</span>
                                <input type="number" id="smartCustomDaysInput" value="15" min="1" max="180" onchange="setSmartTargetDays(this.value)" class="w-14 text-center font-black text-xs text-amber-900 focus:outline-none" />
                                <button type="button" onclick="applyRecommendedToAllInputs()" class="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-extrabold transition cursor-pointer" title="Tablodaki tüm sipariş kutularını bu hedef güne göre önerilen rakamlara eşitle">
                                    Rakamları Uygula
                                </button>
                            </div>
                        </div>
                        <div class="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px] text-slate-600 border-t border-amber-200/60">
                            <label class="inline-flex items-center space-x-1.5 cursor-pointer select-none font-semibold text-amber-950">
                                <input type="checkbox" id="smartAutoRoundMfCheck" checked onchange="recalculateSmartOrderClientSide(true)" class="rounded text-amber-600 focus:ring-amber-500 w-3.5 h-3.5 cursor-pointer">
                                <span>🎁 <strong>Stabil & Artan</strong> ürünlerde yakın MF kademesi varsa sipariş rakamını otomatik MF baremine tamamla</span>
                            </label>
                            <span class="text-[10px] text-rose-700 font-bold">
                                <i class="fa-solid fa-shield-halved mr-0.5"></i>Çıkışı son zamanlarda azalan ürünlerde aşırı stok otomatik frenlenir
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Alt Satır: Arama Kutusu, Stok Yeterlilik Filtresi & Siparişlileri Gizle -->
                <div class="pt-3 border-t border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div class="flex flex-1 items-center space-x-2 max-w-xl">
                        <div class="relative flex-1">
                            <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-2.5 text-slate-400 text-xs"></i>
                            <input 
                                type="text" 
                                id="smartOrderSearchInput" 
                                placeholder="Tabloda filtrele veya Botanik'te herhangi bir ilacı / barkodu ara (Enter)..." 
                                oninput="renderSmartOrderTable()"
                                onkeydown="if(event.key === 'Enter') searchBotanikInSmartOrder()"
                                class="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-emerald-500"
                            />
                        </div>
                        <button type="button" onclick="searchBotanikInSmartOrder()" class="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl transition cursor-pointer shrink-0 flex items-center space-x-1.5" title="Botanik veritabanındaki tüm ilaçlar içinde 6 aylık çıkışını ara">
                            <i class="fa-solid fa-database text-emerald-400 text-[11px]"></i>
                            <span>Botanik'te Ara</span>
                        </button>
                    </div>

                    <div class="flex flex-wrap items-center gap-2 text-xs">
                        <span class="text-[11px] font-bold text-slate-500">Raf Stoğu Süresi:</span>
                        <button type="button" id="btnSmartStock_21" onclick="setSmartStockMaxDays(21)" class="px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-slate-900 text-white transition cursor-pointer">≤21 Gün Stok</button>
                        <button type="button" id="btnSmartStock_14" onclick="setSmartStockMaxDays(14)" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer">≤14 Gün</button>
                        <button type="button" id="btnSmartStock_0" onclick="setSmartStockMaxDays(0)" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer">Tükenenler (≤0)</button>
                        <button type="button" id="btnSmartStock_999" onclick="setSmartStockMaxDays(999)" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer">Tüm Stoklar</button>

                        <span class="text-slate-300">|</span>
                        <label class="inline-flex items-center space-x-1.5 cursor-pointer select-none text-[11px] font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-lg hover:bg-slate-200 transition">
                            <input type="checkbox" id="smartHideOrderedCheck" onchange="renderSmartOrderTable()" class="rounded text-emerald-600 w-3.5 h-3.5 cursor-pointer">
                            <span>Sipariş Verilenleri Gizle</span>
                        </label>
                    </div>
                </div>
            </div>

            <!-- TOPLU SİPARİŞ AKTARIM & TAKİP BARI -->
            <div class="bg-gradient-to-r from-sky-50 via-indigo-50/80 to-emerald-50 border-2 border-sky-200 rounded-3xl p-4 shadow-sm flex flex-col xl:flex-row xl:items-center justify-between gap-4 sticky top-14 z-30 backdrop-blur-md">
                <div class="flex flex-wrap items-center gap-3">
                    <label class="inline-flex items-center space-x-2 cursor-pointer select-none bg-white px-3 py-1.5 rounded-xl border border-sky-200 shadow-2xs">
                        <input type="checkbox" id="smartMasterCheck" checked onchange="toggleSmartSelectAll(this)" class="rounded text-sky-600 focus:ring-sky-500 w-4 h-4 cursor-pointer">
                        <span class="font-extrabold text-xs text-slate-800">Tümünü Seç</span>
                    </label>
                    <div class="flex items-center space-x-2 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                        <span class="text-xs font-black text-sky-900" id="smartSelectedCountBadge">0 Kalem Seçili</span>
                        <span class="text-slate-300">•</span>
                        <span class="text-xs font-extrabold text-emerald-700" id="smartSelectedBoxesBadge">Toplam 0 Kutu</span>
                    </div>
                    <div class="flex items-center gap-1">
                        <button type="button" onclick="selectSmartByTrend('STABIL')" class="px-2.5 py-1.5 rounded-xl bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-bold transition cursor-pointer" title="Sadece stabil çıkan güvenli ürünleri seç">🟢 Sadece Stabilleri Seç</button>
                        <button type="button" onclick="selectSmartByTrend('MF')" class="px-2.5 py-1.5 rounded-xl bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 text-[11px] font-bold transition cursor-pointer" title="Şu an MF'si olan ürünleri seç">🎁 MF'lileri Seç</button>
                        <button type="button" onclick="markSelectedSmartItemsOrdered()" class="px-2.5 py-1.5 rounded-xl bg-white hover:bg-indigo-50 text-indigo-800 border border-indigo-200 text-[11px] font-bold transition cursor-pointer" title="Seçili ürünleri tüm bilgisayarlarda Sipariş Verildi olarak işaretle">✓ Seçilileri Sipariş Verildi İşaretle</button>
                    </div>
                </div>

                <!-- Depo Aktarım Butonları -->
                <div class="flex flex-wrap items-center gap-2">
                    <span class="text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mr-1">🚀 Seçili Rakamları Sepete Aktar:</span>
                    <button type="button" onclick="triggerSmartBulkOrder('ALLIANCE')" class="px-3.5 py-2 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-truck-fast text-sky-200"></i>
                        <span>Alliance</span>
                    </button>
                    <button type="button" onclick="triggerSmartBulkOrder('SELCUK')" class="px-3.5 py-2 bg-gradient-to-r from-rose-600 to-red-700 hover:from-rose-700 hover:to-red-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-paper-plane text-rose-200"></i>
                        <span>Selçuk</span>
                    </button>
                    <button type="button" onclick="triggerSmartBulkOrder('ISKOOP')" class="px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-cart-plus text-emerald-200"></i>
                        <span>İSKOOP</span>
                    </button>
                    <button type="button" onclick="triggerSmartBulkOrder('NEVZAT')" class="px-3.5 py-2 bg-gradient-to-r from-amber-600 to-orange-700 hover:from-amber-700 hover:to-orange-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-boxes-packing text-amber-200"></i>
                        <span>Nevzat</span>
                    </button>
                    <button type="button" onclick="triggerSmartBulkOrderByRowDepo()" class="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-amber-300 font-black text-xs rounded-xl shadow-xs border border-amber-400/40 transition flex items-center space-x-1.5 cursor-pointer" title="Her ürünü satırında seçili olan kendi hedef deposuna (ör. MF'si hangi depodaysa oraya) topluca gönderir">
                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                        <span>Her Ürünü Seçili Deposuna Dağıt</span>
                    </button>
                </div>
            </div>

            <!-- 6 AYLIK ÇIKIŞ & AKILLI SİPARİŞ TABLOSU -->
            <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                <div class="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                    <div class="flex items-center space-x-2">
                        <i class="fa-solid fa-table-list text-emerald-600"></i>
                        <h3 class="font-extrabold text-slate-900 text-sm" id="smartTableTitle">6 Aylık Çıkış Listesi & Tahmini Sipariş Önerileri</h3>
                        <span id="smartMfScanProgressBadge" class="hidden text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                            <i class="fa-solid fa-spinner fa-spin mr-1"></i>Canlı MF'ler taranıyor...
                        </span>
                    </div>
                    <div class="text-[11px] text-slate-500 flex items-center gap-3">
                        <span>💡 <strong>MF rozetine</strong> tıklayarak sipariş rakamını otomatik o MF baremine ayarlayabilirsiniz.</span>
                    </div>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="bg-slate-100/90 border-b border-slate-200 text-slate-600 text-[11px] uppercase tracking-wider font-extrabold" id="smartOrderTableHeadRow">
                                <th class="py-3 px-3 w-8 text-center">Seç</th>
                                <th class="py-3 px-3 min-w-[220px]">İlaç Adı / Barkod / Takip</th>
                                <th class="py-3 px-2.5 text-center">Raf Stoğu</th>
                                <th class="py-3 px-2 text-center bg-amber-50/60 text-amber-900">Bugün</th>
                                <th class="py-3 px-2 text-center" id="smartMonthCol_0">Ay 1</th>
                                <th class="py-3 px-2 text-center" id="smartMonthCol_1">Ay 2</th>
                                <th class="py-3 px-2 text-center" id="smartMonthCol_2">Ay 3</th>
                                <th class="py-3 px-2 text-center" id="smartMonthCol_3">Ay 4</th>
                                <th class="py-3 px-2 text-center" id="smartMonthCol_4">Ay 5</th>
                                <th class="py-3 px-2 text-center bg-emerald-50/60 text-emerald-900" id="smartMonthCol_5">Bu Ay</th>
                                <th class="py-3 px-2.5 text-center bg-slate-200/60 text-slate-900">6 Ay Top / Ort</th>
                                <th class="py-3 px-3 min-w-[155px]">Çıkış Trendi & Uyarı</th>
                                <th class="py-3 px-3 min-w-[165px]">Şu Anki MF & Geçmiş MF</th>
                                <th class="py-3 px-3 min-w-[210px]">Akıllı Sipariş Önerisi</th>
                                <th class="py-3 px-3 min-w-[215px] text-right">Sipariş Rakamı & Sepete Aktar</th>
                            </tr>
                        </thead>
                        <tbody id="smartOrderTableBody" class="divide-y divide-slate-100">
                            <tr>
                                <td colspan="15" class="py-12 text-center text-slate-400 text-sm">
                                    <i class="fa-solid fa-spinner fa-spin text-amber-500 mr-2 text-lg"></i>Botanik 6 aylık çıkış ve stok verileri analiz ediliyor...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ========================================== -->
        <!-- VIEW 2: E-TİCARET & PİYASA FİYAT KIYASLAMA -->
        <!-- ========================================== -->
        <div id="viewMarket" class="hidden space-y-8">
            <!-- Pazaryeri Kıyaslamasının Üstünde: 6 Aylık Çıkış & Toplu Sipariş Planlama Hızlı Geçiş Kartı -->
            <div class="bg-gradient-to-r from-slate-900 via-emerald-950 to-indigo-950 rounded-2xl p-4 text-white shadow-md border border-emerald-700/50 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div class="flex items-center space-x-3.5">
                    <div class="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-amber-300 flex items-center justify-center text-xl shrink-0">
                        <i class="fa-solid fa-chart-column"></i>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <span class="text-xs font-black uppercase tracking-wider text-emerald-300">🌿 Botanik 6 Aylık Çıkış & Akıllı Toplu Sipariş</span>
                            <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30">Stabil / Azalan Uyarılı + Canlı MF</span>
                        </div>
                        <p class="text-xs text-slate-300 mt-0.5">
                            6 aylık çıkış listesini görmek, günlük tahmini siparişi ayarlamak, mevcut MF'leri incelemek ve toplu siparişe aktarmak için tıklayın.
                        </p>
                    </div>
                </div>
                <button type="button" onclick="switchMainView('smart_order')" class="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs shadow-md transition flex items-center space-x-2 shrink-0 cursor-pointer">
                    <i class="fa-solid fa-table-list"></i>
                    <span>📊 6 Aylık Çıkış & Toplu Sipariş Sayfasını Aç</span>
                </button>
            </div>

            <!-- Market Search Box -->
            <div class="max-w-3xl mx-auto mb-8 relative">
                <div class="bg-white p-3 rounded-2xl shadow-lg shadow-indigo-100/60 border border-indigo-200 flex items-center space-x-3 relative z-30">
                    <div class="pl-3 text-indigo-500">
                        <i class="fa-solid fa-basket-shopping text-xl"></i>
                    </div>
                    <input 
                        type="text" 
                        id="marketSearchInput" 
                        placeholder="E-Ticaret İçin Barkod (869...) veya Ürün Adı (Ocean, Solgar, Bioderma, CeraVe)..."
                        class="w-full py-2.5 text-base text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
                        autocomplete="off"
                        onkeydown="if(event.key === 'Enter') handleMarketSearchSubmit()"
                    >
                    <button 
                        id="marketSearchBtn" 
                        onclick="handleMarketSearchSubmit()"
                        class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl text-sm transition-all shadow-md shadow-indigo-200 flex items-center space-x-2 shrink-0 cursor-pointer"
                    >
                        <i class="fa-solid fa-bolt"></i>
                        <span>Piyasayı Tara</span>
                    </button>
                </div>

                <!-- Auto-Suggest Dropdown for Market -->
                <div id="marketSuggestBox" class="hidden absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl border border-slate-200 shadow-2xl z-40 overflow-hidden divide-y divide-slate-100 max-h-96 overflow-y-auto">
                    <!-- Suggestions will be injected here -->
                </div>

                <!-- Market Quick Chips -->
                <div class="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-500">
                    <span class="font-medium">Popüler Ürünler:</span>
                    <button onclick="quickMarketSearch('8697595872413', 'Ocean Alfa Lipoik 200mg')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Ocean Alfa Lipoik 200mg</button>
                    <button onclick="quickMarketSearch('8697595872451', 'Ocean Alfa Lipoik 600mg')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Ocean Alfa Lipoik 600mg</button>
                    <button onclick="quickMarketSearch('8697595870020', 'Ocean Plus 1200mg 50 Kapsül')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Ocean Plus 1200mg</button>
                    <button onclick="quickMarketSearch('Bioderma Sebium', 'Bioderma Sebium')" class="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 rounded-lg border border-indigo-200 text-indigo-700 font-medium transition cursor-pointer">Bioderma Sebium</button>
                    <button onclick="quickMarketSearch('Solgar Alfa Lipoik', 'Solgar Alfa Lipoik')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Solgar Alfa Lipoik</button>
                    <button onclick="quickMarketSearch('CeraVe Nemlendirici Krem', 'CeraVe')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">CeraVe</button>
                </div>
            </div>

            <!-- Loading Spinner State -->
            <div id="marketLoading" class="hidden bg-white p-12 rounded-3xl border border-slate-200 shadow-sm text-center max-w-2xl mx-auto">
                <div class="relative w-16 h-16 mx-auto mb-4">
                    <div class="w-16 h-16 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin"></div>
                    <div class="absolute inset-0 flex items-center justify-center text-indigo-600">
                        <i class="fa-solid fa-shop text-xl"></i>
                    </div>
                </div>
                <h3 class="text-base font-bold text-slate-900 mb-1" id="marketLoadingTitle">9 E-Ticaret Platformu ve Depolar Eşzamanlı Taranıyor...</h3>
                <p class="text-xs text-slate-500 max-w-md mx-auto">Trendyol, Hepsiburada, Sachane, Dermoeczanem, Dermokozmetika, Kırmızıbeyaz, Dermojet, Kozvit ve Daffne canlı fiyatları toplanıyor...</p>
                <div class="flex items-center justify-center gap-2 mt-4 text-[11px] text-slate-400">
                    <span class="w-2 h-2 rounded-full bg-indigo-500 animate-ping"></span>
                    <span>Anti-bot güvenlik bypass aktif</span>
                </div>
            </div>

            <!-- Initial Empty State -->
            <div id="marketEmptyState" class="bg-white p-10 rounded-3xl border border-slate-200 shadow-sm text-center max-w-3xl mx-auto">
                <div class="w-16 h-16 mx-auto mb-4 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-2xl">
                    <i class="fa-solid fa-scale-balanced"></i>
                </div>
                <h3 class="text-lg font-bold text-slate-900 mb-2">E-Ticaret & Perakende Piyasa Fiyat Analizi</h3>
                <p class="text-sm text-slate-500 max-w-xl mx-auto mb-6">
                    Barkod veya ürün adı aratarak 9 büyük perakende e-ticaret platformunun anlık fiyatlarını görün, ecza depolarındaki net alış maliyetiniz ve kâr marjınızla karşılaştırın.
                </p>
                <div class="grid grid-cols-2 sm:grid-cols-5 gap-3 max-w-2xl mx-auto text-xs font-semibold text-slate-700">
                    <div class="p-2.5 rounded-xl bg-orange-50 border border-orange-200 text-orange-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-orange-600"></i> Trendyol</div>
                    <div class="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-amber-600"></i> Hepsiburada</div>
                    <div class="p-2.5 rounded-xl bg-pink-50 border border-pink-200 text-pink-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-pink-600"></i> Sachane</div>
                    <div class="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-emerald-600"></i> Dermoeczanem</div>
                    <div class="p-2.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-indigo-600"></i> Dermokozmetika</div>
                    <div class="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-rose-600"></i> Kırmızıbeyaz</div>
                    <div class="p-2.5 rounded-xl bg-cyan-50 border border-cyan-200 text-cyan-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-cyan-600"></i> Dermojet</div>
                    <div class="p-2.5 rounded-xl bg-purple-50 border border-purple-200 text-purple-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-purple-600"></i> Kozvit</div>
                    <div class="p-2.5 rounded-xl bg-teal-50 border border-teal-200 text-teal-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-teal-600"></i> Daffne</div>
                    <div class="p-2.5 rounded-xl bg-slate-100 border border-slate-300 text-slate-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-truck-ramp-box text-slate-600"></i> 6 Ecza Deposu</div>
                </div>
            </div>

            <!-- Market Results Container -->
            <div id="marketResults" class="hidden space-y-6">
                <!-- Header Title & Info -->
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <div class="flex items-center gap-2 mb-1">
                            <span class="px-2.5 py-0.5 rounded-md text-xs font-bold bg-indigo-100 text-indigo-800" id="marketResBadge">PİYASA RAPORU</span>
                            <span class="text-xs font-mono text-slate-500 font-semibold" id="marketResBarcode"></span>
                        </div>
                        <h2 class="text-xl font-extrabold text-slate-900" id="marketResTitle">Ürün Adı</h2>
                    </div>
                    <div class="flex items-center gap-3">
                        <button onclick="handleMarketSearchSubmit()" class="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1.5 cursor-pointer">
                            <i class="fa-solid fa-rotate-right"></i>
                            <span>Fiyatları Yenile</span>
                        </button>
                    </div>
                </div>

                <!-- Cheaper than Warehouse Warning Alert Banner -->
                <div id="marketCheaperWarning" class="hidden bg-gradient-to-r from-red-600 to-rose-700 text-white p-5 rounded-2xl shadow-lg shadow-red-200 flex items-start gap-4">
                    <div class="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-2xl shrink-0">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                    </div>
                    <div class="flex-1">
                        <h4 class="text-base font-black tracking-wide uppercase">KRİTİK UYARI: İnternet Satış Fiyatı Depo Maliyetinden Daha Düşük!</h4>
                        <p class="text-xs text-red-100 mt-1 leading-relaxed" id="marketCheaperText">
                            Bu ürünün internetteki en ucuz perakende satış fiyatı, eczane ecza deposu net alış maliyetinin altındadır. Piyasada damping veya serbest fiyat rekabeti bulunmaktadır.
                        </p>
                    </div>
                </div>

                <!-- KPI Stat Cards -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <!-- 1. En Ucuz Depo Alışı -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">En Ucuz Depo Alış</span>
                            <span class="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center"><i class="fa-solid fa-truck-ramp-box"></i></span>
                        </div>
                        <div>
                            <div class="text-2xl font-black text-slate-900" id="kpiDepoFiyat">- ₺</div>
                            <div class="text-xs text-slate-500 mt-1 truncate font-medium" id="kpiDepoAdi">-</div>
                        </div>
                    </div>

                    <!-- 2. En Ucuz İnternet Satışı -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">En Ucuz İnternet Satışı</span>
                            <span class="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center"><i class="fa-solid fa-cart-shopping"></i></span>
                        </div>
                        <div>
                            <div class="text-2xl font-black text-indigo-600" id="kpiInternetFiyat">- ₺</div>
                            <div class="text-xs text-slate-500 mt-1 truncate font-medium" id="kpiInternetPlatform">-</div>
                        </div>
                    </div>

                    <!-- 3. Kâr / Marj Analizi -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between" id="kpiKarCard">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">Potansiyel Brüt Kâr</span>
                            <span class="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center"><i class="fa-solid fa-chart-line"></i></span>
                        </div>
                        <div>
                            <div class="text-2xl font-black text-slate-900" id="kpiKarFark">- ₺</div>
                            <div class="text-xs text-slate-500 mt-1 font-medium" id="kpiKarYuzde">Marj: -%</div>
                        </div>
                    </div>

                    <!-- 4. Piyasa Derinliği -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">Piyasa Fiyat Dağılımı</span>
                            <span class="w-7 h-7 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center"><i class="fa-solid fa-scale-balanced"></i></span>
                        </div>
                        <div>
                            <div class="text-xs font-bold text-slate-700 flex justify-between">
                                <span>Ortalama:</span>
                                <span id="kpiOrtalamaFiyat">- ₺</span>
                            </div>
                            <div class="text-xs font-bold text-slate-700 flex justify-between mt-1">
                                <span>En Yüksek:</span>
                                <span id="kpiYuksekFiyat">- ₺</span>
                            </div>
                            <div class="text-[11px] text-slate-400 mt-1 font-medium" id="kpiToplamTeklif">- Teklif</div>
                        </div>
                    </div>
                </div>

                <!-- Main Content Split: Wholesale (Left) vs Retail Offers (Right) -->
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    <!-- LEFT COLUMN: Depo & Pazaryeri Alış Fiyatları (4/12) -->
                    <div class="lg:col-span-4 space-y-4">
                        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                            <div class="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                                <h3 class="font-bold text-sm text-slate-900 flex items-center gap-2">
                                    <i class="fa-solid fa-truck-ramp-box text-emerald-600"></i>
                                    <span>Depo Alış Fiyatları</span>
                                </h3>
                                <span class="text-xs text-slate-500 font-medium" id="depoOzetCount">6 Depo</span>
                            </div>
                            <div class="p-3 divide-y divide-slate-100" id="depoFiyatlariList">
                                <!-- Injected dynamically -->
                            </div>
                        </div>
                    </div>

                    <!-- RIGHT COLUMN: E-Ticaret Perakende Teklifleri (8/12) -->
                    <div class="lg:col-span-8 space-y-4">
                        <!-- Platform Filter Bar -->
                        <div class="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-2 overflow-x-auto" id="platformFilterBar">
                            <!-- Platform chips injected dynamically -->
                        </div>

                        <!-- Retail Offers Grid -->
                        <div class="space-y-3" id="retailOffersList">
                            <!-- Injected dynamically -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>

    <!-- Settings Modal -->
    <div id="settingsModal" style="display: none;" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div class="px-6 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div id="settingsModalIcon" class="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
                        <i class="fa-solid fa-database text-lg"></i>
                    </div>
                    <div>
                        <h3 id="settingsModalTitle" class="text-base font-bold text-white leading-snug">TRIA Eczane Veritabanı (Oracle) Bağlantı & Şifre Ayarları</h3>
                        <p id="settingsModalDesc" class="text-xs text-slate-300">Oracle sunucu IP, port, şema adı ve şifresini buradan girip canlı test edebilirsiniz.</p>
                    </div>
                </div>
                <button onclick="closeSettingsModal()" class="text-slate-400 hover:text-white transition p-1.5 rounded-lg hover:bg-white/10 cursor-pointer">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <!-- Modal Tabs Navigation -->
            <div class="flex border-b border-slate-200 px-6 pt-3 bg-slate-50 gap-2 overflow-x-auto">
                <button type="button" id="tabBtnBotanik" onclick="switchSettingsTab('botanik')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-emerald-600 text-emerald-900 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-leaf text-emerald-600"></i>
                    <span>🌿 Botanik Eczane (MS SQL)</span>
                    <span id="tabBotanikBadge" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">Canlı</span>
                </button>
                <button type="button" id="tabBtnTria" onclick="switchSettingsTab('tria')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-database text-amber-600"></i>
                    <span>⚡ TRIA Eczane (Oracle)</span>
                    <span id="tabTriaBadge" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-600 font-bold">Hazır</span>
                </button>
                <button type="button" id="tabBtnTebeos" onclick="switchSettingsTab('tebeos')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-mortar-pestle text-sky-600"></i>
                    <span>🔷 TEBEOS Eczane (PostgreSQL)</span>
                    <span id="tabTebeosBadge" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-sky-100 text-sky-800 font-bold">Canlı</span>
                </button>
                <button type="button" id="tabBtnDepolar" onclick="switchSettingsTab('depolar')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-truck-ramp-box text-slate-600"></i>
                    <span>🏢 Ecza Depoları & Pazaryeri</span>
                </button>
                <button type="button" id="tabBtnKatalog" onclick="switchSettingsTab('katalog')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-barcode text-indigo-600"></i>
                    <span>📊 Ürün & Çoklu Barkod Kataloğu</span>
                </button>
                <button type="button" id="tabBtnDermo" onclick="switchSettingsTab('dermo')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-wand-magic-sparkles text-pink-600"></i>
                    <span>✨ Dermo Barkod Eşleme</span>
                    <span class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-pink-100 text-pink-800 font-bold">Sihirbaz</span>
                </button>
                <button type="button" id="tabBtnGuncelleme" onclick="switchSettingsTab('guncelleme')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-cloud-arrow-down text-cyan-600"></i>
                    <span>🔄 Sürüm & Güncelleme</span>
                    <span id="tabUpdateBadge" class="hidden ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold">Yeni</span>
                </button>
            </div>

            <!-- Modal Body (Form Grid) -->
            <div class="p-6 max-h-[75vh] overflow-y-auto space-y-6">
                <!-- Eczane Otomasyon Yazılımı Tercihi (Botanik, TRIA, TEBEOS) -->
                <div class="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-2xl p-4 shadow-sm space-y-3">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <div class="flex items-center space-x-2">
                            <i class="fa-solid fa-hospital text-emerald-400 text-base"></i>
                            <span class="text-xs font-bold text-white uppercase tracking-wider">Eczanenizde Kullanılan Otomasyon Sistemi:</span>
                        </div>
                        <span class="text-[11px] text-slate-300">Bu eczane hangi programı kullanıyorsa seçiniz (Stok & Giriş-Çıkış)</span>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <!-- Botanik Seçim Kartı -->
                        <div id="otoChoiceCardBotanik" onclick="selectActiveOtomasyon('BOTANIK')" class="p-3.5 rounded-xl border border-white/10 bg-white/5 cursor-pointer transition flex items-center justify-between group hover:bg-white/10">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-lg shadow-sm">
                                    <i class="fa-solid fa-leaf"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-white group-hover:text-emerald-300 transition">🌿 Botanik Eczane</div>
                                    <div class="text-[10px] text-slate-300 font-mono">MS SQL Server</div>
                                </div>
                            </div>
                            <span id="otoChoiceBadgeBotanik" class="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/10 text-slate-400">SEÇ</span>
                        </div>

                        <!-- TRIA Seçim Kartı -->
                        <div id="otoChoiceCardTria" onclick="selectActiveOtomasyon('TRIA')" class="p-3.5 rounded-xl border-2 border-amber-500 bg-amber-500/20 cursor-pointer transition flex items-center justify-between group hover:bg-amber-500/30 shadow-sm">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center text-lg shadow-sm">
                                    <i class="fa-solid fa-database"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-white group-hover:text-amber-300 transition">⚡ TRIA Eczane</div>
                                    <div class="text-[10px] text-slate-300 font-mono">Oracle Database</div>
                                </div>
                            </div>
                            <span id="otoChoiceBadgeTria" class="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-400 text-slate-950">✓ AKTİF SEÇİM</span>
                        </div>

                        <!-- TEBEOS Seçim Kartı -->
                        <div id="otoChoiceCardTebeos" onclick="selectActiveOtomasyon('TEBEOS')" class="p-3.5 rounded-xl border border-white/10 bg-white/5 cursor-pointer transition flex items-center justify-between group hover:bg-white/10">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-lg bg-sky-500 text-white flex items-center justify-center text-lg shadow-sm">
                                    <i class="fa-solid fa-mortar-pestle"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-white group-hover:text-sky-300 transition">🔷 TEBEOS Eczane</div>
                                    <div class="text-[10px] text-slate-300 font-mono">PostgreSQL (5454)</div>
                                </div>
                            </div>
                            <span id="otoChoiceBadgeTebeos" class="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/10 text-slate-400">SEÇ</span>
                        </div>
                    </div>
                    <input type="hidden" id="cfg_active_otomasyon" value="TRIA">
                </div>

                <!-- Tab: Botanik Eczane Veritabanı (MS SQL Server) -->
                <div id="tabContentBotanik" class="space-y-5">
                    <!-- Botanik Header Alert -->
                    <div class="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4 flex items-start space-x-3.5">
                        <div class="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-emerald-200">
                            <i class="fa-solid fa-leaf"></i>
                        </div>
                        <div class="text-xs text-emerald-950 leading-relaxed">
                            <div class="font-bold text-sm text-emerald-900 mb-0.5">Botanik Eczane Otomasyonu (MS SQL Server) Veri Bağlantısı</div>
                            Eczanenizin ana bilgisayarında veya yerel ağında çalışan Botanik MS SQL Server veritabanı bağlantı bilgilerini buradan yapılandırabilirsiniz.
                            Sorgulanan her ilacın güncel raf stoğu, son 6 aylık Nakit/Reçete satışları ve depolardan gelen son alış faturaları (girişleri) anında analiz edilir.
                        </div>
                    </div>

                    <!-- Hızlı Profil & Config'den Otomatik Oku -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                        <div class="text-xs font-bold text-slate-700 flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-bolt text-amber-500"></i><span>Hızlı Bağlantı & Otomatik Algılama:</span></span>
                            <span class="text-[11px] text-slate-400 font-normal">Tek tıkla formu doldurur</span>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button type="button" onclick="autoReadBotanikConfigFile()" class="px-3.5 py-2 rounded-xl bg-white border border-emerald-400 hover:border-emerald-600 hover:bg-emerald-50 text-emerald-800 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-file-invoice text-emerald-600"></i>
                                <span>📁 Botanik Config Dosyasından Otomatik Doldur</span>
                            </button>
                            <button type="button" onclick="setBotanikProfile('bu_bilgisayar')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
                                <span>🖥️ Bu Bilgisayar (DESKTOP-L6GG7P6\\BOTANIKSQL)</span>
                            </button>
                            <button type="button" onclick="setBotanikProfile('yerel')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>💻 Yerel Makine (.\\BOTANIKSQL)</span>
                            </button>
                        </div>
                    </div>

                    <!-- Botanik Bağlantı Parametreleri Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                        <!-- Sunucu / Server / Instance -->
                        <div class="md:col-span-2">
                            <label class="text-xs font-bold text-slate-700 flex items-center space-x-1 mb-1">
                                <i class="fa-solid fa-server text-emerald-600"></i>
                                <span>SQL Server Adı / Instance (Host):</span>
                            </label>
                            <input type="text" id="cfg_botanik_server" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="Örn: DESKTOP-L6GG7P6\\BOTANIKSQL veya .\\BOTANIKSQL">
                        </div>

                        <!-- Veritabanı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Veritabanı Adı (Database):</label>
                            <input type="text" id="cfg_botanik_db" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="eczane">
                        </div>

                        <!-- Kullanıcı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">SQL Kullanıcı Adı (UID):</label>
                            <input type="text" id="cfg_botanik_user" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="sa">
                        </div>

                        <!-- Şifre -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">SQL Şifresi (PWD):</label>
                            <div class="relative">
                                <input type="password" id="cfg_botanik_pwd" class="w-full text-xs px-3.5 py-2.5 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="••••••••">
                                <button type="button" onclick="togglePasswordVisibility('cfg_botanik_pwd', this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Windows Authentication Checkbox -->
                        <div class="flex items-center space-x-2 pt-6">
                            <input type="checkbox" id="cfg_botanik_trusted" class="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer">
                            <label for="cfg_botanik_trusted" class="text-xs font-bold text-slate-700 cursor-pointer">Windows Kimlik Doğrulama (Trusted Connection)</label>
                        </div>
                    </div>

                    <!-- Canlı Ping & Test Alanı -->
                    <div class="flex items-center justify-between pt-1">
                        <button type="button" id="btnPingBotanik" onclick="pingBotanikConnection()" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-200 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-bolt"></i>
                            <span>🔍 Botanik Bağlantısını Test Et & Ping</span>
                        </button>
                        <span class="text-[11px] text-slate-400">Canlı ping süresini, SQL Server sürümünü ve kayıtlı veri adetlerini doğrular.</span>
                    </div>
                    <div id="botanikPingResult" class="hidden mt-3 p-3.5 rounded-2xl text-xs"></div>
                </div>
                <!-- Tab 1: Depolar & Pazaryerleri -->
                <div id="tabContentDepolar" class="hidden space-y-6">
                    <!-- Info Alert with Active / Passive summary -->
                    <div class="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div class="flex items-start space-x-3">
                            <i class="fa-solid fa-shield-halved text-blue-600 text-lg mt-0.5"></i>
                            <div class="text-xs text-blue-900 leading-relaxed">
                                <strong>Depo Yönetimi & Otomatik Pasiflik:</strong> Çalışmadığınız depoları anahtarından <strong>Pasif</strong> yapabilirsiniz. <u>Kullanıcı adı veya şifresi girilmeyen depolar otomatik olarak devre dışı bırakılır</u> ve karşılaştırmada taranmaz.
                            </div>
                        </div>
                        <div id="depoTabSummaryBadge" class="shrink-0 px-3 py-1.5 rounded-xl bg-blue-100 text-blue-900 text-xs font-bold border border-blue-300">
                            Yükleniyor...
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <!-- 1. Alliance Healthcare Card -->
                        <div id="card_alliance" class="p-4 rounded-2xl border border-sky-100 bg-sky-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-sky-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-sky-800 font-bold text-sm">
                                    <i class="fa-solid fa-truck-medical text-sky-600"></i>
                                    <span>Alliance Healthcare</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Alliance Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_alliance_active" onchange="onDepoActiveToggle('alliance')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-600"></div>
                                    </label>
                                    <span id="badge_alliance_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Eczane Kodu (GLN / Şube)</label>
                                    <input type="text" id="cfg_alliance_pcode" oninput="onDepoCredInput('alliance')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="Örn: 41890">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı</label>
                                    <input type="text" id="cfg_alliance_user" oninput="onDepoCredInput('alliance')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_alliance_pwd" oninput="onDepoCredInput('alliance')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_alliance_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 2. Selçuk Ecza Deposu Card -->
                        <div id="card_selcuk" class="p-4 rounded-2xl border border-emerald-100 bg-emerald-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-emerald-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-emerald-800 font-bold text-sm">
                                    <i class="fa-solid fa-building-columns text-emerald-600"></i>
                                    <span>Selçuk Ecza Deposu</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Selçuk Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_selcuk_active" onchange="onDepoActiveToggle('selcuk')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-emerald-600"></div>
                                    </label>
                                    <span id="badge_selcuk_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı (SEL...)</label>
                                    <input type="text" id="cfg_selcuk_user" oninput="onDepoCredInput('selcuk')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono" placeholder="Örn: SEL30101073184">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_selcuk_pwd" oninput="onDepoCredInput('selcuk')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_selcuk_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 3. Nevzat Ecza Deposu Card -->
                        <div id="card_nevzat" class="p-4 rounded-2xl border border-orange-100 bg-orange-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-orange-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-orange-800 font-bold text-sm">
                                    <i class="fa-solid fa-truck-ramp-box text-orange-600"></i>
                                    <span>Nevzat Ecza Deposu</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Nevzat Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_nevzat_active" onchange="onDepoActiveToggle('nevzat')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-orange-600"></div>
                                    </label>
                                    <span id="badge_nevzat_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Hesap Kodu</label>
                                    <input type="text" id="cfg_nevzat_account" oninput="onDepoCredInput('nevzat')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="Örn: 1205501283">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı</label>
                                    <input type="text" id="cfg_nevzat_user" oninput="onDepoCredInput('nevzat')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_nevzat_pwd" oninput="onDepoCredInput('nevzat')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_nevzat_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 4. İSKOOP Card -->
                        <div id="card_iskoop" class="p-4 rounded-2xl border border-red-100 bg-red-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-red-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-red-800 font-bold text-sm">
                                    <i class="fa-solid fa-handshake-angle text-red-600"></i>
                                    <span>İSKOOP (İstanbul Ecza Koop)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="İSKOOP Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_iskoop_active" onchange="onDepoActiveToggle('iskoop')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-red-600"></div>
                                    </label>
                                    <span id="badge_iskoop_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı (i...)</label>
                                    <input type="text" id="cfg_iskoop_user" oninput="onDepoCredInput('iskoop')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-red-500 focus:outline-none bg-white font-mono" placeholder="Örn: i019069">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_iskoop_pwd" oninput="onDepoCredInput('iskoop')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-red-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_iskoop_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 5. BEK (Bursa Ecza Koop) Card -->
                        <div id="card_bek" class="p-4 rounded-2xl border border-teal-100 bg-teal-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-teal-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-teal-800 font-bold text-sm">
                                    <i class="fa-solid fa-handshake-simple text-teal-600"></i>
                                    <span>BEK (Bursa Eczacılar Kooperatifi)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="BEK Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_bek_active" onchange="onDepoActiveToggle('bek')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-teal-600"></div>
                                    </label>
                                    <span id="badge_bek_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı (b...)</label>
                                    <input type="text" id="cfg_bek_user" oninput="onDepoCredInput('bek')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white font-mono" placeholder="Örn: b02026">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_bek_pwd" oninput="onDepoCredInput('bek')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_bek_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 6. Ecza1 Pazaryeri Card -->
                        <div id="card_ecza1" class="p-4 rounded-2xl border border-purple-100 bg-purple-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-purple-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-purple-800 font-bold text-sm">
                                    <i class="fa-solid fa-cart-shopping text-purple-600"></i>
                                    <span>Ecza1 Pazaryeri</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Ecza1 Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_ecza1_active" onchange="onDepoActiveToggle('ecza1')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-purple-600"></div>
                                    </label>
                                    <span id="badge_ecza1_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / E-Posta</label>
                                    <input type="text" id="cfg_ecza1_user" oninput="onDepoCredInput('ecza1')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_ecza1_pwd" oninput="onDepoCredInput('ecza1')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_ecza1_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 7. Farmazon Pazaryeri Card -->
                        <div id="card_farmazon" class="p-4 rounded-2xl border border-amber-100 bg-amber-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-amber-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-amber-800 font-bold text-sm">
                                    <i class="fa-solid fa-store text-amber-600"></i>
                                    <span>Farmazon Pazaryeri</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Farmazon Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_farmazon_active" onchange="onDepoActiveToggle('farmazon')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-amber-600"></div>
                                    </label>
                                    <span id="badge_farmazon_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / Telefon / E-Posta</label>
                                    <input type="text" id="cfg_farmazon_user" oninput="onDepoCredInput('farmazon')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_farmazon_pwd" oninput="onDepoCredInput('farmazon')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_farmazon_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 8. DNA Ecza Deposu Card -->
                        <div id="card_dna" class="p-4 rounded-2xl border border-cyan-100 bg-cyan-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-cyan-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-cyan-800 font-bold text-sm">
                                    <i class="fa-solid fa-dna text-cyan-600"></i>
                                    <span>DNA Ecza Deposu</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="DNA Ecza Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_dna_active" onchange="onDepoActiveToggle('dna')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-cyan-600"></div>
                                    </label>
                                    <span id="badge_dna_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / E-Posta</label>
                                    <input type="text" id="cfg_dna_user" oninput="onDepoCredInput('dna')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-cyan-500 focus:outline-none bg-white font-mono" placeholder="Örn: taysevinci@gmail.com">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_dna_pwd" oninput="onDepoCredInput('dna')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-cyan-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_dna_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 9. Eczatrend Ortak Alım Grubu Card -->
                        <div id="card_eczatrend" class="p-4 rounded-2xl border border-orange-100 bg-orange-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-orange-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-orange-900 font-bold text-sm">
                                    <i class="fa-solid fa-people-group text-orange-600"></i>
                                    <span>Eczatrend (Alım Grubu)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Eczatrend Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_eczatrend_active" onchange="onDepoActiveToggle('eczatrend')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-orange-600"></div>
                                    </label>
                                    <span id="badge_eczatrend_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / E-Posta</label>
                                    <input type="text" id="cfg_eczatrend_user" oninput="onDepoCredInput('eczatrend')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="Örn: bilgin_eda@hotmail.com">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_eczatrend_pwd" oninput="onDepoCredInput('eczatrend')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_eczatrend_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 10. EczaneTakas Pazaryeri Card -->
                        <div id="card_eczanetakas" class="p-4 rounded-2xl border border-sky-100 bg-sky-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-sky-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-sky-900 font-bold text-sm">
                                    <i class="fa-solid fa-arrow-right-arrow-left text-sky-600"></i>
                                    <span>EczaneTakas (Pazaryeri)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="EczaneTakas Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_eczanetakas_active" onchange="onDepoActiveToggle('eczanetakas')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-600"></div>
                                    </label>
                                    <span id="badge_eczanetakas_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">E-Posta / Kullanıcı Adı</label>
                                    <input type="text" id="cfg_eczanetakas_user" oninput="onDepoCredInput('eczanetakas')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="Örn: ecz.gamzegultekin@gmail.com">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_eczanetakas_pwd" oninput="onDepoCredInput('eczanetakas')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_eczanetakas_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 2: Tria Eczane Veritabanı (Oracle) (EdaPrim dialog_settings.py stili) -->
                <div id="tabContentTria" class="space-y-5">
                    <!-- EdaPrim Style Header Alert -->
                    <div class="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-4 flex items-start space-x-3.5">
                        <div class="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-amber-200">
                            <i class="fa-solid fa-database"></i>
                        </div>
                        <div class="text-xs text-amber-950 leading-relaxed">
                            <div class="font-bold text-sm text-amber-900 mb-0.5">TRIA Eczane Otomasyonu (Oracle) Veri Bağlantısı</div>
                            Eczanenizin ana bilgisayarında veya yerel yedek veritabanında çalışan Oracle bağlantı bilgilerini buradan tanımlayabilirsiniz.
                            Bu sayede sorgulanan her ilacın gerçek raf stoğu ve son 6 aylık Nakit/Reçete satış hızı anında analiz edilir.
                        </div>
                    </div>

                    <!-- Hızlı Profil Seçimi (Tek Tıkla Doldurma) -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                        <div class="text-xs font-bold text-slate-700 flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-bolt text-amber-500"></i><span>Hazır Bağlantı Profilleri:</span></span>
                            <span class="text-[11px] text-slate-400 font-normal">Tek tıkla formu doldurur</span>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button type="button" onclick="setTriaProfile('eda_canli')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
                                <span>⚡ Canlı Eda Eczanesi (192.168.1.57)</span>
                            </button>
                            <button type="button" onclick="setTriaProfile('arastirma')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-amber-500"></span>
                                <span>⚡ Canlı Araştırma Eczanesi (192.168.1.155)</span>
                            </button>
                            <button type="button" onclick="setTriaProfile('eda_yerel')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>💻 Eda Eczanesi Yedeği / Yerel (127.0.0.1)</span>
                            </button>
                        </div>
                    </div>

                    <!-- Tria Bağlantı Parametreleri Grid (EdaPrim dialog_settings.py stili) -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                        <!-- Host + Otomatik Bul Butonu -->
                        <div class="md:col-span-2">
                            <div class="flex items-center justify-between mb-1">
                                <label class="text-xs font-bold text-slate-700 flex items-center space-x-1">
                                    <i class="fa-solid fa-network-wired text-indigo-600"></i>
                                    <span>TRIA Sunucu IP (Host):</span>
                                </label>
                                <button type="button" onclick="discoverTriaHost()" id="btnDiscoverHost" class="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 transition flex items-center space-x-1 cursor-pointer">
                                    <i class="fa-solid fa-globe"></i>
                                    <span>🌐 Ağda TRIA Sunucusunu Otomatik Bul</span>
                                </button>
                            </div>
                            <input type="text" id="cfg_tria_host" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="Örn: 192.168.1.155 veya 127.0.0.1">
                            <div id="discoverResult" class="hidden text-[11px] mt-1 text-indigo-600 font-medium"></div>
                        </div>

                        <!-- Port -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Oracle Port:</label>
                            <input type="text" id="cfg_tria_port" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="1521">
                        </div>

                        <!-- SID / Servis -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Oracle SID / Servis:</label>
                            <input type="text" id="cfg_tria_sid" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="ORCL">
                        </div>

                        <!-- Şema / Kullanıcı Adı + Şemaları Listele Butonu -->
                        <div class="md:col-span-2">
                            <div class="flex items-center justify-between mb-1">
                                <label class="text-xs font-bold text-slate-700 flex items-center space-x-1">
                                    <i class="fa-solid fa-user-gear text-amber-600"></i>
                                    <span>TRIA Kullanıcı Adı (Şema):</span>
                                </label>
                                <button type="button" onclick="loadAvailableSchemas()" id="btnListSchemas" class="text-[11px] font-bold text-amber-700 hover:text-amber-900 transition flex items-center space-x-1 cursor-pointer">
                                    <i class="fa-solid fa-list-check"></i>
                                    <span>📋 Eczane Şemalarını Listele</span>
                                </button>
                            </div>
                            <input type="text" id="cfg_tria_user" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-slate-50 font-mono font-bold uppercase" placeholder="Örn: ARASTIRMA veya EDA">
                            <!-- Dinamik Şema Rozetleri Listesi -->
                            <div id="schemaListContainer" class="hidden mt-2 p-2.5 bg-amber-50/70 border border-amber-200 rounded-xl text-xs">
                                <div class="text-[11px] font-bold text-amber-900 mb-1.5 flex items-center space-x-1">
                                    <i class="fa-solid fa-server"></i>
                                    <span>Veritabanında Bulunan Eczane Şemaları (Tıklayarak Seçin):</span>
                                </div>
                                <div id="schemaPills" class="flex flex-wrap gap-1.5"></div>
                            </div>
                        </div>

                        <!-- Şifre -->
                        <div class="md:col-span-2">
                            <label class="text-xs font-bold text-slate-700 block mb-1">TRIA Oracle Şifresi:</label>
                            <div class="relative">
                                <input type="password" id="cfg_tria_pwd" class="w-full text-xs px-3.5 py-2.5 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="••••••••">
                                <button type="button" onclick="togglePasswordVisibility('cfg_tria_pwd', this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- EdaPrim Stili Bilgilendirme Kartı -->
                    <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-start space-x-3">
                        <i class="fa-solid fa-lightbulb text-emerald-600 text-lg mt-0.5"></i>
                        <div class="text-xs text-emerald-900 leading-relaxed">
                            <strong>💡 Başka Eczane Yedeği İncelerken:</strong><br>
                            TRIA yedeğini Oracle'a kurduğunuzda o eczanenin şema adını (Örn: <em>EDA</em> veya <em>ARASTIRMA</em>) <strong>Kullanıcı Adı</strong> kutusuna yazmanız yeterlidir. <strong>'Eczane Şemalarını Listele'</strong> butonuna basarak sunucudaki tüm kayıtlı eczane şemalarını tek tıkla görebilir ve seçebilirsiniz.
                        </div>
                    </div>

                    <!-- Canlı Ping & Test Alanı -->
                    <div class="flex items-center justify-between pt-1">
                        <button type="button" id="btnPingTria" onclick="pingTriaConnection()" class="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-xs font-bold shadow-md shadow-amber-200 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-bolt"></i>
                            <span>🔍 Bağlantıyı Test Et & Ping</span>
                        </button>
                        <span class="text-[11px] text-slate-400">Canlı ping süresini, Oracle sürümünü ve kayıtlı veri adetlerini doğrular.</span>
                    </div>
                    <div id="triaPingResult" class="hidden mt-3 p-3.5 rounded-2xl text-xs"></div>
                </div>

                <!-- Tab: TEBEOS Eczane Veritabanı (PostgreSQL - Port 5454) -->
                <div id="tabContentTebeos" class="hidden space-y-5">
                    <!-- TEBEOS Header Alert -->
                    <div class="bg-gradient-to-r from-sky-50 to-cyan-50 border border-sky-200 rounded-2xl p-4 flex items-start space-x-3.5">
                        <div class="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-sky-200">
                            <i class="fa-solid fa-mortar-pestle"></i>
                        </div>
                        <div class="text-xs text-sky-950 leading-relaxed">
                            <div class="font-bold text-sm text-sky-900 mb-0.5">TEBEOS Eczane Otomasyonu (PostgreSQL) Veri Bağlantısı</div>
                            Türk Eczacıları Birliği TEBEOS otomasyonunun PostgreSQL veritabanına (varsayılan port: <strong>5454</strong>) doğrudan bağlanır.
                            Sorgulanan her ilacın gerçek raf stoğu, son 6 aylık Reçeteli/Elden çıkışları, son depo alış faturaları ve muadil stokları anında analiz edilir.
                        </div>
                    </div>

                    <!-- Hızlı Profil & Otomatik Bul -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                        <div class="text-xs font-bold text-slate-700 flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-bolt text-sky-500"></i><span>Hızlı Bağlantı & Otomatik Algılama:</span></span>
                            <span class="text-[11px] text-slate-400 font-normal">Tek tıkla formu doldurur</span>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button type="button" onclick="discoverTebeosHost()" id="btnDiscoverTebeos" class="px-3.5 py-2 rounded-xl bg-white border border-sky-400 hover:border-sky-600 hover:bg-sky-50 text-sky-800 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-radar text-sky-600"></i>
                                <span>🌐 Ağda TEBEOS Sunucusunu Otomatik Bul (Port 5454)</span>
                            </button>
                            <button type="button" onclick="setTebeosProfile('ana_makine')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-sky-500 hover:text-sky-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
                                <span>🖥️ Ana Makine (192.168.1.11:5454)</span>
                            </button>
                            <button type="button" onclick="setTebeosProfile('yerel')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-sky-500 hover:text-sky-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>💻 Bu Bilgisayar / Yerel (127.0.0.1:5454)</span>
                            </button>
                        </div>
                        <div id="tebeosDiscoverResult" class="hidden text-[11px] mt-1 text-sky-700 font-medium"></div>
                    </div>

                    <!-- TEBEOS Bağlantı Parametreleri Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                        <!-- Host -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 flex items-center space-x-1 mb-1">
                                <i class="fa-solid fa-server text-sky-600"></i>
                                <span>TEBEOS Sunucu IP (Host):</span>
                            </label>
                            <input type="text" id="cfg_tebeos_host" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="Örn: 192.168.1.11 veya 127.0.0.1">
                        </div>

                        <!-- Port -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">PostgreSQL Port:</label>
                            <input type="text" id="cfg_tebeos_port" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="5454">
                        </div>

                        <!-- Veritabanı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Veritabanı Adı (Database):</label>
                            <input type="text" id="cfg_tebeos_db" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="tebeos_db">
                        </div>

                        <!-- Kullanıcı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">PostgreSQL Kullanıcı Adı:</label>
                            <input type="text" id="cfg_tebeos_user" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="tebeos">
                        </div>

                        <!-- Şifre -->
                        <div class="md:col-span-2">
                            <label class="text-xs font-bold text-slate-700 block mb-1">PostgreSQL Şifresi:</label>
                            <div class="relative">
                                <input type="password" id="cfg_tebeos_pwd" class="w-full text-xs px-3.5 py-2.5 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="••••••••">
                                <button type="button" onclick="togglePasswordVisibility('cfg_tebeos_pwd', this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Canlı Ping & Test Alanı -->
                    <div class="flex items-center justify-between pt-1">
                        <button type="button" id="btnPingTebeos" onclick="pingTebeosConnection()" class="px-5 py-2.5 bg-gradient-to-r from-sky-600 to-cyan-600 hover:from-sky-700 hover:to-cyan-700 text-white rounded-xl text-xs font-bold shadow-md shadow-sky-200 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-bolt"></i>
                            <span>🔍 TEBEOS Bağlantısını Test Et & Ping</span>
                        </button>
                        <span class="text-[11px] text-slate-400">Canlı ping süresini, PostgreSQL sürümünü ve kayıtlı veri adetlerini doğrular.</span>
                    </div>
                    <div id="tebeosPingResult" class="hidden mt-3 p-3.5 rounded-2xl text-xs"></div>
                </div>

                <!-- Tab 3: Ürün Kataloğu & Excel / TRIA Aktarımı -->
                <div id="tabContentKatalog" class="hidden space-y-6">
                    <div class="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-2xl p-5">
                        <div class="flex items-center justify-between mb-3">
                            <h4 class="font-bold text-sm text-indigo-900 flex items-center gap-2">
                                <i class="fa-solid fa-layer-group text-indigo-600"></i>
                                <span>Katalog ve Barkod İstatistikleri</span>
                            </h4>
                            <span class="text-xs bg-indigo-100 text-indigo-800 px-2.5 py-1 rounded-full font-bold">1-to-N Çoklu Barkod</span>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
                            <div class="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                                <div class="text-[11px] text-slate-500">Tekil Ürün Sayısı</div>
                                <div class="text-xl font-black text-slate-800 mt-1" id="catStatProducts">--</div>
                                <div class="text-[10px] text-slate-400">Selçuk & TRIA & OTC</div>
                            </div>
                            <div class="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                                <div class="text-[11px] text-slate-500">Toplam Kayıtlı Barkod</div>
                                <div class="text-xl font-black text-indigo-700 mt-1" id="catStatBarcodes">--</div>
                                <div class="text-[10px] text-indigo-500 font-medium">EAN-13 & Orijinal Barkodlar</div>
                            </div>
                            <div class="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                                <div class="text-[11px] text-slate-500">Alternatif / Çoklu Barkod</div>
                                <div class="text-xl font-black text-purple-700 mt-1" id="catStatSecondary">--</div>
                                <div class="text-[10px] text-purple-500 font-medium">Bir ürüne bağlı ikincil kodlar</div>
                            </div>
                        </div>
                    </div>

                    <!-- Aksiyon 1: Botanik Senkronizasyon -->
                    <div class="p-5 rounded-2xl border border-emerald-200 bg-emerald-50/30 space-y-3">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div>
                                <h5 class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                                    <i class="fa-solid fa-leaf text-emerald-600"></i>
                                    <span>Botanik MS SQL Otomatik Senkronizasyonu</span>
                                </h5>
                                <p class="text-xs text-slate-500">Eczanenizin Botanik programındaki tüm kayıtlı ürünleri ve barkodlarını kataloğa anında aktarır.</p>
                            </div>
                            <button type="button" onclick="syncBotanikCatalog()" id="btnSyncBotanikCat" class="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0">
                                <i class="fa-solid fa-rotate"></i>
                                <span>Botanik'ten Şimdi Güncelle</span>
                            </button>
                        </div>
                        <div id="botanikSyncStatus" class="hidden text-xs font-semibold p-3 rounded-xl"></div>
                    </div>

                    <!-- Aksiyon 2: TRIA Senkronizasyon -->
                    <div class="p-5 rounded-2xl border border-slate-200 bg-white space-y-3">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div>
                                <h5 class="text-sm font-bold text-slate-900">TRIA Oracle Otomatik Senkronizasyonu</h5>
                                <p class="text-xs text-slate-500">Eczanenizin TRIA otomasyonundaki tüm aktif ürünleri ve çoklu barkodlarını kataloğa günceller.</p>
                            </div>
                            <button type="button" onclick="syncTriaCatalog()" id="btnSyncTriaCat" class="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0">
                                <i class="fa-solid fa-rotate"></i>
                                <span>TRIA'dan Şimdi Güncelle</span>
                            </button>
                        </div>
                        <div id="triaSyncStatus" class="hidden text-xs font-semibold p-3 rounded-xl"></div>
                    </div>

                    <!-- Aksiyon 2: Excel Dosyası Yükleme -->
                    <div class="p-5 rounded-2xl border border-slate-200 bg-white space-y-3">
                        <div>
                            <h5 class="text-sm font-bold text-slate-900">Özel Dermokozmetik / OTC Excel Listesi Yükle</h5>
                            <p class="text-xs text-slate-500">Elinizdeki temiz bir Excel (.xlsx) dosyasını (Barkod, Ürün Adı, Fiyat, KDV vb.) doğrudan kataloğa ekleyebilirsiniz.</p>
                        </div>
                        <div class="flex flex-col sm:flex-row items-center gap-3 pt-1">
                            <input type="file" id="excelCatalogFile" accept=".xlsx,.xls" class="text-xs text-slate-600 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer w-full sm:w-auto" />
                            <button type="button" onclick="uploadCatalogExcel()" id="btnUploadCatExcel" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0">
                                <i class="fa-solid fa-file-excel"></i>
                                <span>Excel'i Kataloğa Aktar</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Tab: Dermo Barkod Onarım & Eşleme Sihirbazı -->
                <div id="tabContentDermo" class="hidden space-y-6">
                    <!-- Üst Bilgi Kutusu -->
                    <div class="bg-gradient-to-r from-pink-50 via-rose-50 to-amber-50 border border-pink-200 rounded-2xl p-5 shadow-xs">
                        <div class="flex items-start space-x-3.5">
                            <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-600 to-rose-500 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-pink-200">
                                <i class="fa-solid fa-wand-magic-sparkles"></i>
                            </div>
                            <div class="space-y-1">
                                <h4 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                                    <span>🌿 Botanik Dermo & OTC Barkod Onarım Sihirbazı</span>
                                    <span class="text-[10px] bg-pink-100 text-pink-800 font-extrabold px-2 py-0.5 rounded-full border border-pink-200">Sıfır Riskli</span>
                                </h4>
                                <p class="text-xs text-slate-600 leading-relaxed">
                                    Botanik veritabanınızda elden sahte barkodla (<code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">869922...</code>, <code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">869000...</code>), harfli veya distribütörün geçici promosyon etiketleriyle (<code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">VTR...</code>, <code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">ÖZEL FİYAT</code>) açılmış kartları tarar.
                                </p>
                                <p class="text-[11px] text-emerald-800 font-medium pt-1 flex items-center gap-1.5">
                                    <i class="fa-solid fa-shield-check text-emerald-600 text-sm"></i>
                                    <span><strong>Güvenlik Garantisi:</strong> Bu işlem Botanik'teki mevcut hiçbir barkodunuzu veya ürününüzü <strong>silmez</strong>. Orijinal üretici EAN barkodunu Botanik'e <strong>ikincil barkod olarak</strong> ekler.</span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Filtreler ve Tarama Barı -->
                    <div class="p-5 rounded-2xl border border-slate-200 bg-white space-y-4 shadow-2xs">
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div>
                                <label class="block text-[11px] font-bold text-slate-700 mb-1">Marka Filtresi:</label>
                                <select id="dermoBrandSelect" class="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:outline-none focus:border-pink-500">
                                    <option value="">Tüm Popüler Markalar (La Roche, Bioderma, CeraVe...)</option>
                                    <option value="LA ROCHE">La Roche-Posay</option>
                                    <option value="BIODERMA">Bioderma (Naos)</option>
                                    <option value="CERAVE">CeraVe</option>
                                    <option value="AVENE">Avene (Pierre Fabre)</option>
                                    <option value="VICHY">Vichy</option>
                                    <option value="SOLGAR">Solgar (OTC)</option>
                                    <option value="OCEAN">Ocean (Orzax)</option>
                                    <option value="BEPANTHOL">Bepanthol</option>
                                    <option value="DUCRAY">Ducray</option>
                                    <option value="CAUDALIE">Caudalie</option>
                                    <option value="MUSTELA">Mustela</option>
                                    <option value="ISDIN">ISDIN</option>
                                    <option value="SVR">SVR</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-700 mb-1">İnceleme Limiti:</label>
                                <select id="dermoLimitSelect" class="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:outline-none focus:border-pink-500">
                                    <option value="30">İlk 30 Hatalı Kart</option>
                                    <option value="50" selected>İlk 50 Hatalı Kart</option>
                                    <option value="100">İlk 100 Hatalı Kart</option>
                                    <option value="150">İlk 150 Hatalı Kart</option>
                                </select>
                            </div>
                            <div class="flex items-end">
                                <button type="button" onclick="runDermoAudit()" id="btnRunDermoAudit" class="w-full py-2.5 px-4 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white text-xs font-bold rounded-xl transition shadow-md shadow-pink-200 flex items-center justify-center gap-2 cursor-pointer">
                                    <i class="fa-solid fa-magnifying-glass-arrow-right"></i>
                                    <span>Hatalı Barkodları Tara & Eşleştir</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Yükleniyor Göstergesi -->
                    <div id="dermoLoading" class="hidden text-center py-10 bg-white rounded-2xl border border-slate-200">
                        <div class="inline-block animate-spin rounded-full h-8 w-8 border-3 border-pink-500 border-t-transparent"></div>
                        <p class="mt-3 text-xs font-bold text-slate-700">Botanik veritabanı taranıyor ve uluslararası barkodlar eşleştiriliyor...</p>
                        <p class="text-[11px] text-slate-400 mt-0.5">TRIA, Webliste ve Farmazon katalog havuzuyla karşılaştırılıyor</p>
                    </div>

                    <!-- Sonuçlar ve Eşleme Tablosu -->
                    <div id="dermoResultsContainer" class="hidden space-y-4">
                        <!-- Özet Metrikler ve Toplu Aksiyon Barı -->
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-xl bg-slate-900 text-white shadow-sm">
                            <div class="flex items-center space-x-4 text-xs">
                                <div>
                                    <span class="text-slate-400">Taranan Kart:</span>
                                    <span class="font-black text-white ml-1" id="dermoStatScanned">0</span>
                                </div>
                                <div class="w-px h-4 bg-slate-700"></div>
                                <div>
                                    <span class="text-slate-400">Eşleşen Gerçek EAN:</span>
                                    <span class="font-black text-emerald-400 ml-1" id="dermoStatMatched">0</span>
                                </div>
                                <div class="w-px h-4 bg-slate-700"></div>
                                <div>
                                    <span class="text-slate-400">Süre:</span>
                                    <span class="font-mono text-slate-300 ml-1" id="dermoStatElapsed">0s</span>
                                </div>
                            </div>
                            <div class="flex items-center space-x-3 w-full sm:w-auto justify-end">
                                <label class="inline-flex items-center space-x-1.5 text-xs text-slate-300 cursor-pointer select-none">
                                    <input type="checkbox" id="dermoMasterCheck" onchange="toggleAllDermoCheckboxes(this)" checked class="rounded text-pink-600 focus:ring-0 w-4 h-4 cursor-pointer">
                                    <span>Tümünü Seç</span>
                                </label>
                                <button type="button" onclick="applyDermoSync()" id="btnApplyDermoSync" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition shadow-md shadow-emerald-900/40 flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-floppy-disk"></i>
                                    <span>Seçilenleri Botanik'e Ekle</span>
                                </button>
                            </div>
                        </div>

                        <!-- Önizleme Tablosu -->
                        <div class="border border-slate-200 rounded-2xl bg-white overflow-hidden shadow-2xs">
                            <div class="max-h-96 overflow-y-auto">
                                <table class="w-full text-left text-xs divide-y divide-slate-100">
                                    <thead class="bg-slate-50 text-slate-600 font-bold sticky top-0 z-10 text-[11px] uppercase tracking-wider">
                                        <tr>
                                            <th class="py-2.5 px-3 w-10 text-center">Seç</th>
                                            <th class="py-2.5 px-3">Botanik Ürün Kartı</th>
                                            <th class="py-2.5 px-3">Mevcut Kod (Hatalı/Geçici)</th>
                                            <th class="py-2.5 px-3">Bulunan Gerçek EAN (Eklenecek)</th>
                                            <th class="py-2.5 px-3">Katalog Eşleşmesi</th>
                                            <th class="py-2.5 px-3 text-center">Durum</th>
                                        </tr>
                                    </thead>
                                    <tbody id="dermoAuditTableBody" class="divide-y divide-slate-100">
                                        <!-- Dinamik satırlar -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Geri Bildirim Alanı -->
                    <div id="dermoSyncFeedback" class="hidden p-3.5 rounded-xl text-xs font-semibold"></div>
                </div>

                <!-- Tab: Otomatik Güncelleme & Sürüm Yönetimi -->
                <div id="tabContentGuncelleme" class="hidden space-y-6">
                    <!-- Sürüm Bilgi Kartı -->
                    <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/60 rounded-2xl p-6 text-white shadow-md">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div class="flex items-center space-x-4">
                                <div class="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-2xl text-cyan-300 shadow-md">
                                    <i class="fa-solid fa-cloud-arrow-down"></i>
                                </div>
                                <div>
                                    <div class="flex items-center space-x-2">
                                        <h4 class="text-lg font-black text-white" id="updateLocalVersionTitle">EDA Depo v1.0.0</h4>
                                        <span class="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">Kararlı Sürüm</span>
                                    </div>
                                    <p class="text-xs text-slate-300 mt-1">1000+ Eczane Otomatik Güncelleme & Dağıtım Ağı</p>
                                    <p class="text-[11px] text-slate-400 font-mono mt-0.5" id="updateBuildDateText">Son Derleme: 2026-10-12</p>
                                </div>
                            </div>

                            <div class="flex flex-wrap items-center gap-2">
                                <button type="button" onclick="checkAppUpdate(true)" id="btnCheckUpdateNow" class="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold rounded-xl transition shadow-md shadow-cyan-900/40 flex items-center gap-2 cursor-pointer">
                                    <i class="fa-solid fa-arrows-rotate" id="checkUpdateIcon"></i>
                                    <span>Güncellemeleri Denetle</span>
                                </button>
                                <button type="button" onclick="restartAppServer()" class="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-bold rounded-xl transition border border-white/15 flex items-center gap-1.5 cursor-pointer" title="Sunucuyu yeniden başlatır">
                                    <i class="fa-solid fa-power-off text-amber-400"></i>
                                    <span>Yeniden Başlat</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Güncelleme Durum & Sonuç Kartı -->
                    <div id="updateStatusCard" class="hidden p-5 rounded-2xl border transition-all">
                        <!-- JS ile güncellenecek -->
                    </div>

                    <!-- Dağıtım & Manifest Bilgisi -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-2">
                                <i class="fa-solid fa-network-wired text-cyan-600 text-xs"></i>
                                <span class="text-xs font-bold text-slate-800">Merkezi Canlı Dağıtım Sunucusu (GitHub Manifest URL)</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <a href="/portal" target="_blank" class="text-[11px] font-bold text-cyan-700 hover:text-cyan-900 underline flex items-center gap-1">
                                    <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>Canlı Portal Sayfası
                                </a>
                                <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">Canlı Otomatik Güncelleme Aktif</span>
                            </div>
                        </div>
                        <p class="text-[11px] text-slate-500">Program her açılışta ve arka planda 5 dakikada bir bu GitHub adresini kontrol ederek yeni sürümleri otomatik kurar. Eczane şifreleriniz (.env), lisansınız ve yerel verileriniz asla ezilmez.</p>
                        <div class="flex flex-col sm:flex-row gap-2">
                            <input type="text" id="cfg_update_manifest_url" class="flex-1 text-xs font-mono p-2.5 rounded-xl border border-slate-300 bg-white text-slate-700 focus:outline-none focus:border-cyan-600 select-all" value="https://raw.githubusercontent.com/depomxxx/depo-updates/main/version.json">
                            <button type="button" onclick="saveManifestUrlConfig()" class="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl transition cursor-pointer shrink-0">
                                <i class="fa-solid fa-floppy-disk mr-1"></i>Adresi Kaydet
                            </button>
                        </div>
                    </div>

                    <!-- GitHub Canlı Güncelleme & Yayınlama Portalı (Admin) -->
                    <div id="githubAdminPortalBox" class="bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-cyan-500/30 rounded-2xl p-5 space-y-4 shadow-md">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700/80 pb-3">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-300 text-lg">
                                    <i class="fa-brands fa-github"></i>
                                </div>
                                <div>
                                    <h5 class="text-sm font-black text-white">GitHub Canlı Güncelleme & Yayınlama Portalı (Merkez)</h5>
                                    <p class="text-[11px] text-slate-300">Git kurulumu gerekmeden doğrudan GitHub bulutuna ve ağdaki tüm bilgisayarlara canlı sürüm gönderin.</p>
                                </div>
                            </div>
                            <span id="ghPortalStatusBadge" class="text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">HAZIR</span>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                            <div>
                                <label class="block text-[11px] font-bold text-slate-300 mb-1">GitHub Token (ghp_...)</label>
                                <input type="password" id="ghPortalToken" placeholder="ghp_... (Kayıtlıysa boş bırakın)" class="w-full font-mono text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-emerald-300 focus:outline-none focus:border-cyan-400">
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-300 mb-1">GitHub Kullanıcı Adı</label>
                                <input type="text" id="ghPortalOwner" placeholder="depomxxx" value="depomxxx" class="w-full font-mono text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-white focus:outline-none focus:border-cyan-400">
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-300 mb-1">GitHub Depo (Repo) Adı</label>
                                <div class="flex gap-1.5">
                                    <input type="text" id="ghPortalRepo" placeholder="depo-updates" value="depo-updates" class="w-full font-mono text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-white focus:outline-none focus:border-cyan-400">
                                    <button type="button" onclick="verifyAndSetupGithubPortal()" id="btnVerifyGhPortal" class="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[11px] rounded-xl transition cursor-pointer shrink-0" title="GitHub'da depoyu otomatik oluşturur ve bağlar">
                                        Bağla
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs pt-1">
                            <div>
                                <label class="block text-[11px] font-bold text-slate-300 mb-1">Yayınlanacak Sürüm</label>
                                <input type="text" id="ghPortalNewVersion" value="1.0.8" class="w-full font-mono font-bold text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-amber-300 focus:outline-none focus:border-cyan-400">
                            </div>
                            <div class="sm:col-span-3">
                                <label class="block text-[11px] font-bold text-slate-300 mb-1">Sürüm Notları (Changelog)</label>
                                <input type="text" id="ghPortalChangelog" value="Selçuk & Nevzat hızlı sepet/MF iyileştirmesi ve GitHub Canlı Güncelleme Portalı senkronizasyonu." class="w-full text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-slate-200 focus:outline-none focus:border-cyan-400">
                            </div>
                        </div>

                        <div class="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
                            <div id="ghPortalResultText" class="text-[11px] text-slate-300 font-mono truncate max-w-md">
                                Tek tıkla tüm eczane bilgisayarlarını ve GitHub portalını güncelleyebilirsiniz.
                            </div>
                            <button type="button" onclick="publishLiveReleaseFromPortal()" id="btnPublishGhPortal" class="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-900/40 transition flex items-center justify-center gap-2 cursor-pointer shrink-0">
                                <i class="fa-solid fa-rocket"></i>
                                <span>GitHub + Tüm Bilgisayarlara Canlı Yayınla</span>
                            </button>
                        </div>
                    </div>

                    <!-- Kurumsal Lisans & Abonelik Yönetimi -->
                    <div class="bg-white border-2 border-indigo-100 rounded-2xl p-5 space-y-4 shadow-xs">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600 text-lg">
                                    <i class="fa-solid fa-key"></i>
                                </div>
                                <div>
                                    <div class="flex items-center gap-2">
                                        <h5 class="text-sm font-black text-slate-900" id="licPharmacyTitle">Eczane Kurumsal Lisansı</h5>
                                        <span id="licStatusBadge" class="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">AKTİF</span>
                                    </div>
                                    <p class="text-[11px] text-slate-500 mt-0.5">Bu Bilgisayar Donanım Kimliği (HWID): <strong id="licMyHwid" class="font-mono text-indigo-700 select-all">----</strong></p>
                                </div>
                            </div>
                            <div class="text-right text-xs">
                                <div class="text-slate-500">Bitiş Tarihi: <strong id="licExpiresAt" class="text-slate-800 font-mono">--</strong></div>
                                <div class="text-[11px] text-emerald-700 font-bold" id="licDaysLeftText">-- gün kaldı</div>
                            </div>
                        </div>

                        <div class="space-y-2">
                            <label class="block text-xs font-bold text-slate-700">Lisans Anahtarı (EDP-...)</label>
                            <div class="flex flex-col sm:flex-row gap-2">
                                <input type="text" id="licKeyInput" placeholder="EDP-..." class="flex-1 text-xs font-mono p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white focus:outline-none focus:border-indigo-500">
                                <button type="button" onclick="activateNewLicense()" id="btnActivateLic" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition shadow-xs cursor-pointer shrink-0 flex items-center justify-center gap-1.5">
                                    <i class="fa-solid fa-shield-check"></i>
                                    <span>Lisansı Doğrula & Kaydet</span>
                                </button>
                            </div>
                            <div id="licFeedbackMsg" class="hidden text-xs font-semibold p-2.5 rounded-xl"></div>
                        </div>
                    </div>
                </div>

                <div id="settingsFeedback" class="hidden p-3 rounded-xl text-xs font-semibold"></div>
            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span class="text-[11px] text-slate-500 text-center sm:text-left">Değişiklik yapmadığınız ayarlar mevcut halleriyle çalışmaya devam eder.</span>
                <div class="flex items-center space-x-2">
                    <button type="button" onclick="closeSettingsModal()" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200 transition cursor-pointer">Vazgeç</button>
                    <button type="button" id="saveSettingsBtn" onclick="saveSettings()" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-200 transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-check"></i>
                        <span>Tüm Ayarları Kaydet</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Eşdeğer / Muadil İlaçlar Modalı -->
    <div id="esdegerModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-3xl w-full max-h-[85vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div class="px-6 py-5 bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300">
                        <i class="fa-solid fa-code-compare text-lg"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-white flex items-center space-x-2">
                            <span>SGK Eşdeğer & Muadil İlaçlar</span>
                            <span id="modalEsdegerKodu" class="text-xs font-mono bg-indigo-500/30 text-indigo-200 px-2 py-0.5 rounded border border-indigo-400/40"></span>
                        </h3>
                        <p class="text-xs text-indigo-200/80">Bu ilacın yerine SGK kapsamında verilebilecek muadil ilaçlar ve Selçuk Ecza ticari şartları</p>
                    </div>
                </div>
                <button type="button" onclick="closeEsdegerModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Content (Cards) -->
            <div class="p-6 overflow-y-auto space-y-3 flex-1 bg-slate-50/50">
                <div class="text-xs text-slate-500 mb-2 flex items-center justify-between">
                    <span>Toplam <strong id="modalEsdegerCount" class="text-slate-800">0</strong> Muadil İlaç Bulundu</span>
                    <span class="text-[11px] text-indigo-600"><i class="fa-solid fa-circle-info mr-1"></i>Herhangi bir muadili seçerek 6 depoda anında karşılaştırabilirsiniz</span>
                </div>
                <div id="modalEsdegerList" class="space-y-2">
                    <!-- Dynamic Rows -->
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
                <button type="button" onclick="closeEsdegerModal()" class="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
            </div>
        </div>
    </div>

    <!-- ========================================== -->
    <!-- TEKLİ HIZLI SİPARİŞİ SONLANDIRMA MODALI    -->
    <!-- ========================================== -->
    <div id="quickFinalizeModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div id="quickFinHeader" class="px-6 py-5 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center text-yellow-200 text-lg">
                        <i class="fa-solid fa-bolt-lightning animate-pulse"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-black text-white flex items-center space-x-2">
                            <span>Tekli Siparişi Tamamla & Sonlandır</span>
                            <span id="quickFinDepoBadge" class="text-[10px] bg-white/20 text-white font-extrabold px-2.5 py-0.5 rounded-full border border-white/30">Selçuk Ecza</span>
                        </h3>
                        <p class="text-xs text-amber-100 font-medium">Doğrudan depoya iletim ve tek tıkla sipariş tamamlama</p>
                    </div>
                </div>
                <button type="button" onclick="closeQuickFinalizeModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Body -->
            <div id="quickFinBody" class="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
                <!-- Dynamic Content injected via JS -->
            </div>

            <!-- Modal Footer -->
            <div id="quickFinFooter" class="px-6 py-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
                <!-- Dynamic Buttons injected via JS -->
            </div>
        </div>
    </div>


    <!-- ========================================== -->
    <!-- TOPLU SİPARİŞ GÖNDERİCİ MODAL (ALLIANCE)   -->
    <!-- ========================================== -->
    <div id="bulkOrderModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div id="bulkModalHeader" class="px-6 py-5 bg-gradient-to-r from-sky-900 via-slate-900 to-indigo-950 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div id="bulkModalIconBox" class="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-300 text-lg">
                        <i id="bulkModalIcon" class="fa-solid fa-truck-ramp-box"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-white flex items-center space-x-2">
                            <span id="bulkModalTitle">🚀 Alliance Healthcare Toplu Sipariş Gönderici</span>
                            <span id="bulkModalBadge" class="text-[10px] bg-sky-500/30 text-sky-200 font-extrabold px-2.5 py-0.5 rounded-full border border-sky-400/40">B2B Canlı Sepet</span>
                        </h3>
                        <p id="bulkModalDesc" class="text-xs text-sky-200/80">Günün çıkışlarından seçilen ilaçlar otomatik taranarak sepetinize taslak sipariş olarak aktarılır.</p>
                    </div>
                </div>
                <button type="button" onclick="closeBulkOrderModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Content -->
            <div class="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
                <!-- Status & Progress Banner -->
                <div id="bulkProgressArea" class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2.5">
                    <div class="flex items-center justify-between text-xs font-bold text-slate-800">
                        <span id="bulkProgressStatus" class="flex items-center gap-2">
                            <i class="fa-solid fa-spinner fa-spin text-sky-600" id="bulkProgressSpinner"></i>
                            <span id="bulkProgressText">Alliance sepetine ürünler aktarılıyor...</span>
                        </span>
                        <span id="bulkProgressPercent" class="font-mono text-sky-700 font-extrabold">%0</span>
                    </div>
                    <!-- Progress Bar -->
                    <div class="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                        <div id="bulkProgressBar" class="bg-gradient-to-r from-sky-500 to-blue-600 h-2.5 rounded-full transition-all duration-300" style="width: 0%"></div>
                    </div>
                </div>

                <!-- 4 KPI Stat Boxes -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                        <div class="text-[11px] text-slate-500">Gönderilen Kalem</div>
                        <div class="text-lg font-black text-slate-900 mt-0.5" id="bulkStatTotal">0</div>
                    </div>
                    <div class="bg-white p-3 rounded-xl border border-emerald-100 shadow-2xs">
                        <div class="text-[11px] text-emerald-700">Başarıyla Eklenen</div>
                        <div class="text-lg font-black text-emerald-600 mt-0.5" id="bulkStatSuccess">0</div>
                    </div>
                    <div class="bg-white p-3 rounded-xl border border-rose-100 shadow-2xs">
                        <div class="text-[11px] text-rose-700" id="bulkStatFailedLabel">Depoda Bulunamayan</div>
                        <div class="text-lg font-black text-rose-600 mt-0.5" id="bulkStatFailed">0</div>
                    </div>
                    <div class="bg-white p-3 rounded-xl border border-sky-100 shadow-2xs">
                        <div class="text-[11px] text-sky-700">Taslak Sepet Tutarı</div>
                        <div class="text-lg font-black text-sky-800 mt-0.5 font-mono" id="bulkStatAmount">0.00 ₺</div>
                    </div>
                </div>

                <!-- Eksik Kalemleri Başka Depoya Aktarma Paneli (Hızlı ve Kontrollü) -->
                <div id="bulkTransferMissingBar" class="hidden p-3.5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl flex flex-col md:flex-row items-center justify-between gap-3 shadow-md border border-indigo-700/50">
                    <div class="flex items-center space-x-2.5 min-w-0">
                        <span class="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center font-bold text-sm shrink-0">
                            <i class="fa-solid fa-layer-group"></i>
                        </span>
                        <div class="min-w-0">
                            <div class="text-xs font-bold text-white flex items-center gap-1.5">
                                <span>Bu depoda olmayan <strong class="text-amber-300 font-extrabold" id="bulkMissingCount">0</strong> kalem toplandı!</span>
                            </div>
                            <div class="text-[11px] text-indigo-200/80">Bu eksik ürünleri istediğiniz depoya tek tıkla aktarın:</div>
                        </div>
                    </div>
                    <div class="flex flex-wrap items-center gap-1.5 shrink-0" id="bulkTransferButtonsContainer">
                        <!-- Dinamik doldurulacak: Alliance, Selçuk, İSKOOP, Nevzat -->
                    </div>
                </div>

                <!-- Depo Dağılım Hapları -->
                <div id="bulkModalDepoBreakdown" class="hidden grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <!-- Dinamik doldurulacak -->
                </div>

                <!-- Item Results Table with Tabs & Yok Listesi Export -->
                <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
                    <div class="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-slate-700">
                        <div class="flex items-center space-x-1.5" id="bulkResultTabsContainer">
                            <button type="button" id="bulkTabBtnAll" onclick="switchBulkResultTab('ALL')" class="px-2.5 py-1 rounded-lg text-xs font-black bg-white text-slate-900 shadow-2xs border border-slate-200 cursor-pointer">
                                Tüm Kalemler (<span id="bulkTabCountAll">0</span>)
                            </button>
                            <button type="button" id="bulkTabBtnYok" onclick="switchBulkResultTab('YOK')" class="px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 hover:bg-rose-50 border border-transparent cursor-pointer flex items-center space-x-1">
                                <i class="fa-solid fa-triangle-exclamation text-rose-500"></i>
                                <span>Bulunamayanlar (<span id="bulkTabCountYok">0</span>)</span>
                            </button>
                        </div>
                        <div class="flex items-center space-x-2">
                            <button type="button" id="btnCopyYokList" onclick="copyMissingItemsToClipboard()" class="hidden px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[11px] font-bold shadow-2xs transition flex items-center space-x-1.5 cursor-pointer active:scale-98" title="Bulunamayan ilaçları kopyala">
                                <i class="fa-solid fa-copy text-[10px]"></i>
                                <span>Eksikleri Kopyala</span>
                            </button>
                            <span id="bulkModalTargetDepo" class="text-[11px] text-slate-400 font-medium">B2B Canlı Sepet</span>
                        </div>
                    </div>
                    <div class="max-h-72 overflow-y-auto divide-y divide-slate-100 text-xs" id="bulkOrderItemsList">
                        <div class="p-6 text-center text-slate-400">İşlem başlatılıyor...</div>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div class="flex flex-wrap items-center gap-2" id="bulkModalFooterLinks">
                    <a 
                        id="bulkModalCartLink"
                        href="https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart" 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        class="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-md shadow-sky-200 transition flex items-center space-x-1.5 cursor-pointer"
                    >
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        <span id="bulkModalCartBtnText">Alliance eSipariş Sepetini Aç ↗</span>
                    </a>
                </div>
                <div class="flex items-center space-x-2">
                    <button type="button" id="btnBulkFinalize" onclick="openBulkFinalizeFlow()" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-500/20 transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-paper-plane text-xs"></i>
                        <span>Siparişi Sonlandır & Depoya Gönder</span>
                    </button>
                    <button type="button" onclick="closeBulkOrderModal()" class="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ========================================== -->
    <!-- GÜNLÜK TOPLU SİPARİŞİ SONLANDIRMA MODALI   -->
    <!-- ========================================== -->
    <div id="bulkFinalizeModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div id="bulkFinHeader" class="px-6 py-5 bg-gradient-to-r from-emerald-700 via-teal-700 to-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center text-emerald-200 text-lg">
                        <i class="fa-solid fa-clipboard-check"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-black text-white flex items-center space-x-2">
                            <span>Günlük Siparişi Sonlandır & Depoya Gönder</span>
                            <span id="bulkFinDepoBadge" class="text-[10px] bg-white/20 text-white font-extrabold px-2.5 py-0.5 rounded-full border border-white/30">Alliance</span>
                        </h3>
                        <p class="text-xs text-emerald-100 font-medium">Sepet kontrolü, farklı ürün analizi ve tek tıkla depoya gönderim</p>
                    </div>
                </div>
                <button type="button" onclick="closeBulkFinalizeModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Body -->
            <div id="bulkFinBody" class="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
                <!-- Dynamic Content injected via JS -->
            </div>

            <!-- Modal Footer -->
            <div id="bulkFinFooter" class="px-6 py-4 bg-slate-100 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2">
                <!-- Dynamic Buttons injected via JS -->
            </div>
        </div>
    </div>

    <script>
        const searchInput = document.getElementById('searchInput');
        const suggestBox = document.getElementById('suggestBox');
        const loading = document.getElementById('loading');
        const loadingText = document.getElementById('loadingText');
        const results = document.getElementById('results');
        const productSelection = document.getElementById('productSelection');
        const selectionGrid = document.getElementById('selectionGrid');
        const tableBody = document.getElementById('tableBody');
        const simQtyInput = document.getElementById('simQtyInput');

        let debounceTimer;
        let currentReport = null;
        let selectedDepoForSim = null;

        // Anlık öneri sistemi (Sıfır gecikmeli istemci önbelleği, klavye gezintisi ve odaklanma)
        let suggestAbortController = null;
        let currentSuggestions = [];
        let selectedSuggestIndex = -1;
        const clientSuggestCache = {};

        function highlightMatch(text, query) {
            if (!query) return text;
            const terms = query.trim().split(/\\s+/).filter(t => t.length > 0);
            if (terms.length === 0) return text;
            try {
                const escaped = terms.map(t => t.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')).join('|');
                const regex = new RegExp(`(${escaped})`, 'gi');
                return text.replace(regex, '<span class="bg-amber-100 text-amber-900 font-bold px-0.5 rounded">$1</span>');
            } catch (e) {
                return text;
            }
        }

        async function fetchAndRenderSuggestions(val) {
            const query = val.trim();
            if (query.length < 2) {
                suggestBox.classList.add('hidden');
                currentSuggestions = [];
                selectedSuggestIndex = -1;
                return;
            }

            // İstemci önbelleği kontrolü (Anında 0 ms gösterim)
            if (clientSuggestCache[query]) {
                currentSuggestions = clientSuggestCache[query];
                selectedSuggestIndex = -1;
                renderSuggestions(currentSuggestions, query);
                return;
            }

            if (suggestAbortController) {
                suggestAbortController.abort();
            }
            suggestAbortController = new AbortController();

            try {
                const res = await fetch(`/api/catalog/suggest?q=${encodeURIComponent(query)}`, {
                    signal: suggestAbortController.signal
                });
                if (res.ok) {
                    const items = await res.json();
                    clientSuggestCache[query] = items;
                    currentSuggestions = items;
                    selectedSuggestIndex = -1;
                    renderSuggestions(items, query);
                }
            } catch(e) {
                if (e.name !== 'AbortError') {
                    console.error("Öneri hatası:", e);
                }
            }
        }

        searchInput.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            const val = this.value;
            if (val.trim().length < 2) {
                suggestBox.classList.add('hidden');
                return;
            }
            // Hızlı 30ms gecikme (yazarken donma olmadan anında tepki)
            debounceTimer = setTimeout(() => {
                fetchAndRenderSuggestions(val);
            }, 30);
        });

        // Arama kutusuna tıklandığında (focus) mevcut metin varsa önerileri hemen aç
        searchInput.addEventListener('focus', function () {
            if (this.value.trim().length >= 2) {
                fetchAndRenderSuggestions(this.value);
            }
        });

        // Klavye Yön Tuşları (Yukarı/Aşağı) ve Enter ile Anında Seçim
        searchInput.addEventListener('keydown', function (e) {
            const isSuggestOpen = !suggestBox.classList.contains('hidden') && currentSuggestions.length > 0;

            if (e.key === 'ArrowDown') {
                if (isSuggestOpen) {
                    e.preventDefault();
                    selectedSuggestIndex = (selectedSuggestIndex + 1) % currentSuggestions.length;
                    updateSuggestHighlight();
                }
            } else if (e.key === 'ArrowUp') {
                if (isSuggestOpen) {
                    e.preventDefault();
                    selectedSuggestIndex = (selectedSuggestIndex - 1 + currentSuggestions.length) % currentSuggestions.length;
                    updateSuggestHighlight();
                }
            } else if (e.key === 'Enter') {
                if (isSuggestOpen && selectedSuggestIndex >= 0 && selectedSuggestIndex < currentSuggestions.length) {
                    e.preventDefault();
                    const chosen = currentSuggestions[selectedSuggestIndex];
                    selectAndSearch(chosen.barcode, chosen.name);
                } else if (isSuggestOpen && currentSuggestions.length > 0 && !/^\d{8,14}$/.test(searchInput.value.trim())) {
                    // Kullanıcı Enter bastıysa ve listede öneriler varsa en üstteki 1. ürünü otomatik seç
                    e.preventDefault();
                    const chosen = currentSuggestions[0];
                    selectAndSearch(chosen.barcode, chosen.name);
                } else {
                    suggestBox.classList.add('hidden');
                    handleSearchSubmit();
                }
            } else if (e.key === 'Escape') {
                suggestBox.classList.add('hidden');
                selectedSuggestIndex = -1;
            }
        });

        function updateSuggestHighlight() {
            const rows = suggestBox.querySelectorAll('.suggest-item-row');
            rows.forEach((row, idx) => {
                if (idx === selectedSuggestIndex) {
                    row.classList.add('bg-emerald-50', 'border-l-4', 'border-l-emerald-600', 'pl-3');
                    row.classList.remove('hover:bg-slate-50');
                    row.scrollIntoView({ block: 'nearest' });
                } else {
                    row.classList.remove('bg-emerald-50', 'border-l-4', 'border-l-emerald-600', 'pl-3');
                    row.classList.add('hover:bg-slate-50');
                }
            });
        }

        function renderSuggestions(items, query = '') {
            if (!items || items.length === 0) {
                suggestBox.classList.add('hidden');
                return;
            }

            suggestBox.innerHTML = '';
            
            // Başlık / İpucu çubuğu
            const headerDiv = document.createElement('div');
            headerDiv.className = 'px-4 py-1.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-medium select-none';
            headerDiv.innerHTML = `
                <span><i class="fa-solid fa-bolt text-amber-500 mr-1"></i> Akıllı İlaç & Ürün Seçimi (${items.length})</span>
                <span class="text-slate-400">Yön tuşları <kbd class="px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px]">↑</kbd> <kbd class="px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px]">↓</kbd> ile seçip <kbd class="px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px]">Enter</kbd> yapın</span>
            `;
            suggestBox.appendChild(headerDiv);

            items.forEach((item, index) => {
                const multiBadge = (item.barcode_count && item.barcode_count > 1)
                    ? `<span class="ml-1.5 px-1.5 py-0.5 text-[10px] font-semibold bg-indigo-50 text-indigo-700 rounded border border-indigo-200" title="Kayıtlı Tüm Barkodlar: ${(item.all_barcodes || []).join(', ')}">+${item.barcode_count - 1} Barkod</span>` 
                    : '';
                const highlightedName = highlightMatch(item.name, query);
                const div = document.createElement('div');
                div.className = 'suggest-item-row px-4 py-2.5 hover:bg-slate-50 cursor-pointer flex items-center justify-between transition border-b border-slate-100/60 last:border-b-0';
                div.innerHTML = `
                    <div class="flex items-center space-x-3 min-w-0">
                        <div class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center text-xs font-bold shrink-0">
                            <i class="fa-solid fa-tablets"></i>
                        </div>
                        <div class="min-w-0">
                            <div class="text-sm font-semibold text-slate-800 truncate">${highlightedName}</div>
                            <div class="text-xs text-slate-400 font-mono">${item.barcode}${multiBadge} • <span class="text-slate-500">${item.manufacturer || 'Genel'}</span></div>
                        </div>
                    </div>
                    <div class="text-right shrink-0 ml-3">
                        <div class="text-xs font-semibold text-slate-700">${item.price ? item.price.toFixed(2) + ' ₺' : ''}</div>
                        <span class="text-[10px] text-emerald-600 font-semibold flex items-center justify-end space-x-1">
                            <span>Karşılaştır</span>
                            <i class="fa-solid fa-arrow-right text-[9px]"></i>
                        </span>
                    </div>
                `;
                div.onmouseenter = () => {
                    selectedSuggestIndex = index;
                    updateSuggestHighlight();
                };
                div.onclick = (e) => {
                    e.stopPropagation();
                    selectAndSearch(item.barcode, item.name);
                };
                suggestBox.appendChild(div);
            });

            suggestBox.classList.remove('hidden');
        }

        // Tıklama dışına çıkınca öneri kutusunu kapat
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !suggestBox.contains(e.target)) {
                suggestBox.classList.add('hidden');
                selectedSuggestIndex = -1;
            }
        });

        async function selectAndSearch(barcode, name) {
            // Önceki aramadan kalan önerileri tamamen temizle (karışmayı önler)
            currentSuggestions = [];
            selectedSuggestIndex = -1;

            const input = document.getElementById('searchInput');
            if (input && name) input.value = name;
            else if (input && barcode) input.value = barcode;

            const sBox = document.getElementById('suggestBox');
            if (sBox) sBox.classList.add('hidden');
            const pSel = document.getElementById('productSelection');
            if (pSel) pSel.classList.add('hidden');

            // Sayfanın en üstüne yumuşak kaydır
            window.scrollTo({ top: 0, behavior: 'smooth' });

            const q = (barcode || '').toString().trim();
            // Doğrudan geçerli 8-14 haneli EAN barkod ise hemen sorgula
            if (q && /^\d{8,14}$/.test(q)) {
                performBarcodeSearch(q);
                return;
            }

            // Eğer barkod geçerli EAN değilse (örn: depo kodu veya salt isim), önce 13 haneli EAN barkodunu çöz
            const targetText = (name || q).trim();
            if (targetText) {
                try {
                    const res = await fetch(`/api/products/find?q=${encodeURIComponent(targetText)}`);
                    if (res.ok) {
                        const data = await res.json();
                        const foundBc = data.barcode || (data.products && data.products.length > 0 ? data.products[0].barcode : null);
                        const foundName = data.name || (data.products && data.products.length > 0 ? data.products[0].name : null);
                        if (foundBc && /^\d{8,14}$/.test(foundBc)) {
                            if (input && foundName) input.value = foundName;
                            performBarcodeSearch(foundBc);
                            return;
                        }
                    }
                } catch (e) {
                    console.warn('[selectAndSearch] Barkod çözümleme hatası:', e);
                }
            }

            handleSearchSubmit(q || name);
        }

        async function handleSearchSubmit(customQuery) {
            if (customQuery) {
                // Özel parametre ile geldiyse eski önerileri sıfırla
                currentSuggestions = [];
                selectedSuggestIndex = -1;
            }

            const query = (customQuery || searchInput.value).trim();
            if (!query) return;

            suggestBox.classList.add('hidden');

            // Eğer doğrudan barkod ise (en az 8 hane rakam), direkt depo sorgula
            if (/^\d{8,14}$/.test(query)) {
                productSelection.classList.add('hidden');
                performBarcodeSearch(query);
                return;
            }

            // AKILLI EŞLEŞTİRME: Yalnızca kullanıcı arama kutusuna yazıp enter'a bastıysa önerilerle eşleştir
            if (!customQuery && currentSuggestions && currentSuggestions.length > 0) {
                const qLower = query.toLowerCase();
                const exact = currentSuggestions.find(s => (s.name || '').toLowerCase() === qLower || s.barcode === query);
                if (exact) {
                    currentSuggestions = [];
                    selectAndSearch(exact.barcode, exact.name);
                    return;
                }
                if (currentSuggestions.length === 1) {
                    const onlySug = currentSuggestions[0];
                    currentSuggestions = [];
                    selectAndSearch(onlySug.barcode, onlySug.name);
                    return;
                }
            }

            // Metin araması: Eşleşen ürünleri bul
            loadingText.innerText = `'${query}' için ürünler taranıyor...`;
            loading.classList.remove('hidden');
            results.classList.add('hidden');
            productSelection.classList.add('hidden');

            const abortCtrl = new AbortController();
            const timeoutId = setTimeout(() => abortCtrl.abort(), 10000);

            try {
                const res = await fetch(`/api/products/find?q=${encodeURIComponent(query)}`, {
                    signal: abortCtrl.signal
                });
                clearTimeout(timeoutId);
                if (!res.ok) throw new Error("Arama yapılamadı");
                const data = await res.json();

                if (data.is_barcode || (data.products && data.products.length === 1)) {
                    // Tek bir ürün eşleştiyse doğrudan depolarda karşılaştır
                    const targetBarcode = data.barcode || data.products[0].barcode;
                    performBarcodeSearch(targetBarcode);
                } else if (data.products && data.products.length > 1) {
                    // Birden fazla ürün bulundu (örn: OTC markası) -> Kullanıcıya ürün seçtir
                    renderProductSelection(data.products, query);
                } else {
                    alert(`'${query}' aramasıyla eşleşen ürün bulunamadı. Lütfen barkod veya farklı bir isim deneyin.`);
                }
            } catch (err) {
                clearTimeout(timeoutId);
                if (err.name === 'AbortError') {
                    alert(`'${query}' araması zaman aşımına uğradı. Lütfen doğrudan barkod yazarak deneyin.`);
                } else {
                    alert("Hata oluştu: " + err.message);
                }
            } finally {
                loading.classList.add('hidden');
            }
        }

        function renderProductSelection(products, query) {
            document.getElementById('selectionTitle').innerText = `'${query}' ile Eşleşen Ürünler`;
            document.getElementById('selectionCount').innerText = `${products.length} Farklı Ürün`;

            selectionGrid.innerHTML = '';
            products.forEach(p => {
                const card = document.createElement('div');
                card.className = 'bg-white p-5 rounded-2xl border border-slate-200 hover:border-emerald-500 hover:shadow-md transition cursor-pointer flex flex-col justify-between';
                card.onclick = () => selectAndSearch(p.barcode, p.name);

                card.innerHTML = `
                    <div>
                        <div class="flex items-center justify-between mb-2">
                            <span class="px-2 py-0.5 text-[11px] font-mono font-bold bg-slate-100 text-slate-700 rounded">${p.barcode}</span>
                            <span class="text-xs text-slate-400">${p.manufacturer || 'Genel'}</span>
                        </div>
                        <h4 class="text-sm font-bold text-slate-900 leading-snug line-clamp-2">${p.name}</h4>
                    </div>
                    <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div class="text-xs text-slate-500">
                            ${p.price ? `<span class="font-bold text-slate-800 text-sm">${p.price.toFixed(2)} ₺</span>` : ''}
                        </div>
                        <button class="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold rounded-lg transition flex items-center space-x-1">
                            <span>Karşılaştır</span>
                            <i class="fa-solid fa-arrow-right text-[10px]"></i>
                        </button>
                    </div>
                `;
                selectionGrid.appendChild(card);
            });

            productSelection.classList.remove('hidden');
        }

        async function performBarcodeSearch(barcode) {
            currentReport = null;
            loadingText.innerText = "Tüm aktif depolarda ve pazaryerlerinde eşzamanlı ticari şartlar taranıyor...";
            loading.classList.remove('hidden');
            results.classList.add('hidden');

            const searchCtrl = new AbortController();
            const timeoutId = setTimeout(() => searchCtrl.abort(), 40000);

            try {
                const res = await fetch(`/api/search?q=${encodeURIComponent(barcode)}`, {
                    signal: searchCtrl.signal
                });
                clearTimeout(timeoutId);
                if (!res.ok) throw new Error("Arama başarısız");
                const data = await res.json();
                currentReport = data;
                renderResults(data);
            } catch (err) {
                clearTimeout(timeoutId);
                if (err.name === 'AbortError') {
                    alert("Depo sorgusu zaman aşımına uğradı. Depo portalları geç yanıt veriyor olabilir, lütfen tekrar deneyin.");
                } else {
                    alert("Depo sorgu hatası: " + err.message);
                }
            } finally {
                loading.classList.add('hidden');
            }
        }

        function renderResults(data) {
            const sInp = document.getElementById('searchInput');
            if (sInp && data.urun_adi) sInp.value = data.urun_adi;

            document.getElementById('resBarcode').innerText = data.barkod;
            document.getElementById('resTitle').innerText = data.urun_adi;
            document.getElementById('resStockCount').innerText = `${data.stokta_bulunan_depolar.length} Depoda Stok Mevcut`;

            // Soğuk Zincir Rozeti
            const coldBadge = document.getElementById('resColdChainBadge');
            if (data.soguk_zincir) {
                coldBadge.classList.remove('hidden');
                coldBadge.classList.add('inline-flex');
            } else {
                coldBadge.classList.add('hidden');
                coldBadge.classList.remove('inline-flex');
            }

            // Muadiller / Eşdeğer Butonu
            const eqBtn = document.getElementById('resEquivalentsBtn');
            const eqCount = (data.esdegerler && data.esdegerler.length > 0) ? data.esdegerler.length : 0;
            if (eqCount > 0 || data.esdeger_kodu) {
                eqBtn.classList.remove('hidden');
                eqBtn.classList.add('inline-flex');
                document.getElementById('resEquivalentsBtnText').innerText = eqCount > 0 ? `Muadiller (${eqCount})` : 'Muadiller';
            } else {
                eqBtn.classList.add('hidden');
                eqBtn.classList.remove('inline-flex');
            }

            // SGK Kamu İskontosu, Eczacı Kârı, PSF ve KSF
            const kamuIsk = data.kamu_iskontosu || 0;
            const eczaciKari = data.eczaci_kari || 0;
            const psf = data.psf || 0;
            const ksf = data.kamu_fiyati || (psf > 0 ? (psf * (1.0 - (kamuIsk / 100.0))) : 0);

            document.getElementById('resKamuIsk').innerText = `%${kamuIsk.toFixed(1)}`;
            document.getElementById('resEczaciKari').innerText = `%${eczaciKari.toFixed(1)}`;
            document.getElementById('resPsf').innerText = `${psf.toFixed(2)} ₺`;
            document.getElementById('resKsf').innerText = `${ksf.toFixed(2)} ₺`;

            // Tahmini Kutu Başı Kârlar (Kamu vs Elden)
            const kamuKari = data.kamu_kari !== undefined ? data.kamu_kari : (ksf > 0 && data.en_dusuk_maliyet_kdvli > 0 ? (ksf - data.en_dusuk_maliyet_kdvli) : 0);
            const perakendeKari = data.perakende_kari !== undefined ? data.perakende_kari : (psf > 0 && data.en_dusuk_maliyet_kdvli > 0 ? (psf - data.en_dusuk_maliyet_kdvli) : 0);

            const kamuProfitEl = document.getElementById('resKamuProfit');
            const perakendeProfitEl = document.getElementById('resPerakendeProfit');

            if (kamuKari < 0) {
                kamuProfitEl.innerText = `${kamuKari.toFixed(2)} ₺ (Zarar!)`;
                kamuProfitEl.className = 'font-extrabold text-red-600 ml-1';
            } else {
                kamuProfitEl.innerText = `+${kamuKari.toFixed(2)} ₺`;
                kamuProfitEl.className = 'font-extrabold text-blue-800 ml-1';
            }

            perakendeProfitEl.innerText = `+${perakendeKari.toFixed(2)} ₺`;

            // Daha Kârlı Muadil Rozeti (En kârlı muadil varsa üst arama sonucunda uyarır)
            const muadilAlertEl = document.getElementById('resMuadilProfitOpportunity');
            const bestMuadilNameEl = document.getElementById('resBestMuadilName');
            const bestMuadilGainEl = document.getElementById('resBestMuadilGain');
            if (data.en_karli_muadil && data.muadil_kar_avantaji > 0) {
                if (bestMuadilNameEl) bestMuadilNameEl.innerText = data.en_karli_muadil.urun_adi || data.en_karli_muadil.ad || 'Muadil İlaç';
                if (bestMuadilGainEl) bestMuadilGainEl.innerText = `+${data.muadil_kar_avantaji.toFixed(2)} ₺`;
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('hidden');
                    muadilAlertEl.classList.add('inline-flex');
                }
            } else {
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('inline-flex');
                    muadilAlertEl.classList.add('hidden');
                }
            }

            // KDV bilgisi ve ürün tipi rozeti
            let kdv = 10;
            if (data.sonuclar && data.sonuclar.length > 0) {
                const foundKdv = data.sonuclar.find(s => s.kdv_orani && s.kdv_orani > 0);
                if (foundKdv) kdv = foundKdv.kdv_orani;
            }
            let kdvBadge = '';
            if (Math.abs(kdv - 1.0) < 0.1) {
                kdvBadge = `<span class="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded border border-amber-300 ml-1.5"><i class="fa-solid fa-seedling mr-1"></i>Gıda Takviyesi (%1 KDV)</span>`;
            } else if (Math.abs(kdv - 20.0) < 0.1) {
                kdvBadge = `<span class="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded border border-blue-300 ml-1.5"><i class="fa-solid fa-pump-soap mr-1"></i>Kozmetik / Itriyat (%20 KDV)</span>`;
            } else {
                kdvBadge = `<span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-300 ml-1.5"><i class="fa-solid fa-capsules mr-1"></i>İlaç (%10 KDV)</span>`;
            }
            document.getElementById('resVatInfo').innerHTML = `<i class="fa-solid fa-receipt mr-1"></i>KDV: <strong>%${kdv}</strong> ${kdvBadge}`;

            // Bugün sipariş verildi / sepette uyarısı
            const todayOrdBanner = document.getElementById('resTodayOrderedBanner');
            if (todayOrdBanner) {
                const ord = data.bugun_siparis;
                if (ord && ord.durum) {
                    const isFinalized = ord.durum === 'SIPARIS_VERILDI';
                    const safeBc = (data.barkod || ord.barkod || '').replace(/'/g, "\\'");
                    const safeNm = (data.urun_adi || ord.urun_adi || '').replace(/'/g, "\\'");
                    todayOrdBanner.classList.remove('hidden');
                    if (isFinalized) {
                        todayOrdBanner.innerHTML = `
                            <div class="p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-lg shadow-emerald-600/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                                <div class="flex items-center space-x-3">
                                    <div class="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl shrink-0">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </div>
                                    <div>
                                        <div class="text-xs font-black uppercase tracking-wider text-emerald-100">⚠️ Mükerrer Sipariş Uyarısı — Bugün Sipariş Verildi!</div>
                                        <div class="text-sm font-bold mt-0.5">
                                            Bu ürün bugün saat <strong>${ord.saat || '--:--'}</strong> itibarıyla <strong>${ord.masa || 'Eczane PC'}</strong> üzerinden <strong>${ord.depo || 'Depo'}</strong> deposuna <strong>${ord.miktar || 1} Kutu</strong> olarak sipariş verilip sonlandırılmıştır.
                                        </div>
                                    </div>
                                </div>
                                <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeNm}', event)" class="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold border border-white/30 transition shrink-0 cursor-pointer">
                                    <i class="fa-solid fa-rotate-left mr-1"></i>İşareti Kaldır
                                </button>
                            </div>
                        `;
                    } else {
                        todayOrdBanner.innerHTML = `
                            <div class="p-3.5 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                                <div class="flex items-center space-x-3">
                                    <div class="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center text-base shrink-0">
                                        <i class="fa-solid fa-cart-shopping"></i>
                                    </div>
                                    <div class="text-xs">
                                        <div class="font-black text-sm">🛒 Bu Ürün Bugün Depo Sepetine Eklendi</div>
                                        <div class="mt-0.5">
                                            Saat <strong>${ord.saat || '--:--'}</strong> itibarıyla <strong>${ord.masa || 'Eczane PC'}</strong> bilgisayarından <strong>${ord.depo || 'Depo'}</strong> sepetine <strong>${ord.miktar || 1} Kutu</strong> eklendi.
                                        </div>
                                    </div>
                                </div>
                                <div class="flex items-center space-x-2 shrink-0">
                                    <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeNm}', '${ord.depo || 'SELCUK'}', ${ord.miktar || 1})" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition cursor-pointer">
                                        <i class="fa-solid fa-check mr-1"></i>Sipariş Verildi İşaretle
                                    </button>
                                    <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeNm}', event)" class="px-2.5 py-1.5 rounded-xl bg-white hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-amber-300 text-xs font-bold transition cursor-pointer">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                </div>
                            </div>
                        `;
                    }
                } else {
                    todayOrdBanner.classList.add('hidden');
                    todayOrdBanner.innerHTML = '';
                }
            }

            const bestBanner = document.getElementById('bestDealBanner');
            if (data.en_avantajli_depo && data.en_dusuk_maliyet !== null) {
                bestBanner.classList.remove('hidden');
                const bestRow = data.sonuclar.find(s => s.depo === data.en_avantajli_depo && Math.abs(s.net_birim_maliyet - data.en_dusuk_maliyet) < 0.01) || data.sonuclar[0];
                document.getElementById('bestDepoName').innerText = bestRow ? bestRow.depo_adi : data.en_avantajli_depo;
                document.getElementById('bestCost').innerText = (data.en_dusuk_maliyet || 0).toFixed(2) + ' ₺';
                document.getElementById('bestCostKdvli').innerText = (data.en_dusuk_maliyet_kdvli || 0).toFixed(2) + ' ₺';
            } else {
                bestBanner.classList.add('hidden');
            }

            tableBody.innerHTML = '';
            selectedRowIndex = null;

            data.sonuclar.forEach((item, index) => {
                const isBest = (item.depo === data.en_avantajli_depo && Math.abs(item.net_birim_maliyet - data.en_dusuk_maliyet) < 0.01);
                const tr = document.createElement('tr');
                tr.className = `hover:bg-slate-50/80 transition ${isBest ? 'bg-emerald-50/40 font-medium' : ''}`;

                let depoColor = 'text-slate-700 font-bold';
                if (item.depo === 'ALLIANCE') depoColor = 'text-sky-700 font-bold';
                if (item.depo === 'SELCUK') depoColor = 'text-emerald-700 font-bold';
                if (item.depo === 'NEVZAT') depoColor = 'text-orange-700 font-bold';
                if (item.depo === 'ISKOOP') depoColor = 'text-red-700 font-bold';
                if (item.depo === 'BEK') depoColor = 'text-teal-700 font-bold';
                if (item.depo === 'ECZA1') depoColor = 'text-purple-700 font-bold';
                if (item.depo === 'FARMAZON') depoColor = 'text-amber-600 font-bold';
                if (item.depo === 'DNA') depoColor = 'text-cyan-700 font-bold';
                if (item.depo === 'ECZATREND') depoColor = 'text-orange-600 font-bold';
                if (item.depo === 'ECZANETAKAS') depoColor = 'text-sky-700 font-bold';

                let stockBadge = item.stok_durumu === 'VAR' 
                    ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800"><i class="fa-solid fa-check mr-1"></i>VAR ${item.stok_adedi ? `(${item.stok_adedi})` : ''}</span>`
                    : `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-500"><i class="fa-solid fa-xmark mr-1"></i>YOK</span>`;

                if (item.depo === 'ECZATREND') {
                    if (item.stok_adedi > 0) {
                        stockBadge = `<span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-extrabold bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs" title="Kampanyayı tamamlamak için kalan adet"><i class="fa-solid fa-hourglass-half mr-1 text-[11px] text-amber-700"></i>Kalan: ${item.stok_adedi} Adet</span>`;
                    } else {
                        stockBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-500" title="Kampanya hedefine ulaşıldı"><i class="fa-solid fa-check-double mr-1 text-[10px]"></i>Hedef Doldu</span>`;
                    }
                } else if (item.depo === 'ECZANETAKAS') {
                    if (item.stok_durumu === 'VAR' && item.stok_adedi > 0) {
                        stockBadge = `<span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-extrabold bg-sky-100 text-sky-900 border border-sky-300 shadow-2xs" title="EczaneTakas açık tekliflerde kalan toplam stok"><i class="fa-solid fa-boxes-stacked mr-1 text-[11px] text-sky-700"></i>Kalan: ${item.stok_adedi} Kutu</span>`;
                    } else {
                        stockBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-500" title="Açık teklif bulunmuyor"><i class="fa-solid fa-xmark mr-1 text-[10px]"></i>YOK</span>`;
                    }
                }

                // Soğuk Zincir Simgesi
                const rowColdIcon = item.soguk_zincir ? `<span class="text-sky-500 text-xs ml-1" title="Soğuk Zincir (+2°C / +8°C)"><i class="fa-solid fa-snowflake"></i></span>` : '';

                // MF Kademeleri veya Pazaryeri Satıcı Teklifleri HTML (MF'siz Fiyat ve MF'li Birim Fiyat KDV Hariç)
                const baseSingleNet = (item.ticari_iskonto && item.ticari_iskonto > 0 && item.depocu_satis_fiyati > 0)
                    ? (item.depocu_satis_fiyati * (1.0 - (item.ticari_iskonto / 100.0)))
                    : (item.net_birim_maliyet || item.depocu_satis_fiyati || 0);

                // Gerçekten indirim sağlayan veya hediye kutu içeren baremler
                const realKademeler = (item.kademeler || []).filter(k => 
                    (k.hediye && k.hediye > 0) || 
                    (k.net_birim_maliyet && k.net_birim_maliyet < (baseSingleNet - 0.02))
                );
                const hasRealMf = realKademeler.length > 0 || (item.hediye && item.hediye > 0);

                let mfHtml = '';
                if (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri.length > 0) {
                    const isFarmazon = item.depo === 'FARMAZON';
                    const isEczatrend = item.depo === 'ECZATREND';
                    const isEczanetakas = item.depo === 'ECZANETAKAS';
                    let btnCls = 'bg-purple-100 hover:bg-purple-200 text-purple-900 border-purple-300';
                    let btnLabel = `${item.pazaryeri_teklifleri.length} Farklı Satıcı Fiyatı`;
                    let btnIcon = 'fa-tags';
                    if (isFarmazon) {
                        btnCls = 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300';
                    } else if (isEczatrend) {
                        btnCls = 'bg-orange-100 hover:bg-orange-200 text-orange-950 border-orange-300';
                        btnLabel = `${item.pazaryeri_teklifleri.length} Grup Teklifi (${item.mf_metni})`;
                        btnIcon = 'fa-people-group';
                    } else if (isEczanetakas) {
                        btnCls = 'bg-sky-100 hover:bg-sky-200 text-sky-950 border-sky-300';
                        btnLabel = `${item.pazaryeri_teklifleri.length} Eczane Teklifi (${item.mf_metni})`;
                        btnIcon = 'fa-arrow-right-arrow-left';
                    }
                    mfHtml = `
                        <div class="flex flex-col space-y-1">
                            ${isEczatrend ? `
                                <div class="inline-flex items-center space-x-1.5 text-xs font-bold text-orange-900">
                                    <span class="px-2 py-0.5 rounded bg-orange-100 border border-orange-300"><i class="fa-solid fa-users mr-1"></i>Barem: ${item.mf_metni}</span>
                                    <span class="text-[10px] text-slate-500 font-medium">Hedef: ${item.pazaryeri_teklifleri[0]?.hedef || '-'} Kutu</span>
                                </div>
                            ` : isEczanetakas ? `
                                <div class="inline-flex items-center space-x-1.5 text-xs font-bold text-sky-900">
                                    <span class="px-2 py-0.5 rounded bg-sky-100 border border-sky-300"><i class="fa-solid fa-handshake mr-1"></i>Barem: ${item.mf_metni}</span>
                                    <span class="text-[10px] text-slate-500 font-medium truncate max-w-xs" title="${item.ozel_kampanya_notu || ''}">${item.ozel_kampanya_notu || ''}</span>
                                </div>
                            ` : ''}
                            <button type="button" onclick="toggleOffersRow(${index})" class="px-2.5 py-1 text-xs font-bold rounded-xl border ${btnCls} transition flex items-center space-x-1.5 cursor-pointer shadow-2xs">
                                <i class="fa-solid ${btnIcon} text-[10px]"></i>
                                <span>${btnLabel}</span>
                                <i id="offersChevron_${index}" class="fa-solid fa-chevron-down text-[10px] transition-transform duration-200"></i>
                            </button>
                        </div>
                    `;
                } else if (realKademeler.length > 0) {
                    mfHtml = `
                        <div class="flex flex-col space-y-1.5">
                            <div class="flex items-center space-x-1.5 text-[11px] text-slate-500">
                                <span>MF'siz (1 Adet):</span>
                                <span class="font-mono text-slate-700 font-semibold text-[10px]">${baseSingleNet.toFixed(2)} ₺</span>
                            </div>
                            <div class="flex flex-wrap gap-1.5">` + realKademeler.map(k => {
                                const tot = (k.alinan || 0) + (k.hediye || 0);
                                const tierMfliNet = (k.net_birim_maliyet && k.net_birim_maliyet > 0) ? k.net_birim_maliyet : (tot > 0 ? (((k.alinan || 1) * baseSingleNet) / tot) : baseSingleNet);
                                const tierMfliKdvli = (k.net_birim_maliyet_kdvli && k.net_birim_maliyet_kdvli > 0) ? k.net_birim_maliyet_kdvli : (tierMfliNet * (1.0 + (item.kdv_orani || 10.0) / 100.0));
                                return `
                                    <button type="button" onclick="setSimWithTier(${index}, ${k.alinan}, ${k.hediye})" class="group inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-indigo-50/90 hover:bg-indigo-600 hover:text-white border border-indigo-200 text-indigo-900 transition shadow-2xs cursor-pointer text-left" title="MF Barem: ${k.mf_text} — Tıklayarak siparişe aktarın (KDV Dahil: ${tierMfliKdvli.toFixed(2)} ₺)">
                                        <span class="font-bold text-xs">${k.mf_text}</span>
                                        <span class="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 group-hover:bg-emerald-500 group-hover:text-white font-extrabold font-mono text-emerald-800" title="MF'li Birim Net Maliyet (KDV Hariç)">
                                            ${tierMfliNet.toFixed(2)} ₺
                                        </span>
                                        <span class="text-[9px] text-slate-500 group-hover:text-indigo-200 font-mono" title="KDV Dahil Net Maliyet">
                                            (${tierMfliKdvli.toFixed(2)} ₺ KDV'li)
                                        </span>
                                    </button>
                                `;
                            }).join('') + `</div>
                        </div>
                    `;
                } else if (item.hediye && item.hediye > 0) {
                    const tot = (item.alinan || 1) + item.hediye;
                    const singleMfliNet = tot > 0 ? (((item.alinan || 1) * baseSingleNet) / tot) : baseSingleNet;
                    const singleMfliKdvli = singleMfliNet * (1.0 + (item.kdv_orani || 10.0) / 100.0);
                    mfHtml = `
                        <div class="flex flex-col space-y-1">
                            <div class="flex items-center space-x-1.5 text-[11px] text-slate-500">
                                <span>MF'siz (1 Adet):</span>
                                <span class="font-mono text-slate-700 text-[10px] font-semibold">${baseSingleNet.toFixed(2)} ₺</span>
                            </div>
                            <button type="button" onclick="setSimWithTier(${index}, ${item.alinan || 1}, ${item.hediye})" class="group inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-600 hover:text-white border border-emerald-300 text-emerald-950 transition shadow-2xs cursor-pointer text-left" title="Tıklayarak siparişe aktarın">
                                <span class="font-bold text-xs">${item.mf_metni}</span>
                                <span class="text-[10px] px-1.5 py-0.5 rounded bg-white group-hover:bg-white/20 font-black font-mono text-emerald-700 group-hover:text-white border border-emerald-200 group-hover:border-transparent">
                                    ${singleMfliNet.toFixed(2)} ₺
                                </span>
                                <span class="text-[9px] text-slate-500 group-hover:text-emerald-200 font-mono">
                                    (${singleMfliKdvli.toFixed(2)} ₺ KDV'li)
                                </span>
                            </button>
                        </div>
                    `;
                } else if (item.mf_metni && item.mf_metni !== 'YOK' && item.mf_metni !== 'None' && item.mf_metni !== '-' && item.mf_metni.trim() !== '') {
                    const mfParts = item.mf_metni.split('/').map(p => p.trim()).filter(Boolean);
                    mfHtml = `
                        <div class="flex flex-col space-y-1">
                            <div class="flex items-center space-x-1.5 text-[11px] text-slate-500">
                                <span>MF'siz (1 Adet):</span>
                                <span class="font-mono text-slate-700 text-[10px] font-semibold">${baseSingleNet.toFixed(2)} ₺</span>
                            </div>
                            <div class="flex flex-wrap gap-1">` + mfParts.map(part => {
                                const pairMatch = part.match(/(\d+)\s*\+\s*(\d+)/);
                                let alinan = 1, hediye = 0;
                                if (pairMatch) {
                                    alinan = parseInt(pairMatch[1], 10);
                                    hediye = parseInt(pairMatch[2], 10);
                                }
                                const tot = alinan + hediye;
                                const partNet = tot > 0 ? ((alinan * baseSingleNet) / tot) : baseSingleNet;
                                const partKdvli = partNet * (1.0 + (item.kdv_orani || 10.0) / 100.0);
                                return `
                                    <button type="button" onclick="setSimWithTier(${index}, ${alinan}, ${hediye})" class="group inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-lg bg-emerald-50 hover:bg-emerald-600 hover:text-white border border-emerald-300 text-emerald-950 transition shadow-2xs cursor-pointer text-left" title="MF Barem: ${part} — Tıklayarak siparişe aktarın (KDV Dahil: ${partKdvli.toFixed(2)} ₺)">
                                        <span class="font-bold text-xs">${part}</span>
                                        <span class="text-[10px] px-1.5 py-0.5 rounded bg-white group-hover:bg-white/20 font-black font-mono text-emerald-700 group-hover:text-white border border-emerald-200 group-hover:border-transparent">
                                            ${partNet.toFixed(2)} ₺
                                        </span>
                                    </button>
                                `;
                            }).join('') + `</div>
                        </div>
                    `;
                } else {
                    mfHtml = `
                        <span class="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-400">MF Yok</span>
                    `;
                }

                // Miad ve İskonto Rozetleri
                const miadBadge = item.miad 
                    ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200 mt-1" title="Son Kullanma Tarihi / Miad"><i class="fa-regular fa-calendar-check mr-1 text-[10px]"></i>Miad: ${item.miad}</span>` 
                    : '';

                const iskBadge = (item.ticari_iskonto && item.ticari_iskonto > 0)
                    ? `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 mt-1" title="Ticari / Nakit İskonto"><i class="fa-solid fa-percent mr-0.5 text-[8px]"></i>%${item.ticari_iskonto.toFixed(1)} İsk</span>`
                    : '';

                const isEczatrendItem = item.depo === 'ECZATREND';
                const isEczanetakasItem = item.depo === 'ECZANETAKAS';
                const offersBadgeCol1 = (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri.length > 0) ? `
                    <button type="button" onclick="toggleOffersRow(${index})" class="mt-1 text-[11px] font-bold ${isEczatrendItem ? 'text-orange-700 hover:text-orange-900' : isEczanetakasItem ? 'text-sky-700 hover:text-sky-900' : 'text-amber-700 hover:text-amber-900'} flex items-center space-x-1 cursor-pointer">
                        <i class="fa-solid ${isEczatrendItem ? 'fa-people-group' : isEczanetakasItem ? 'fa-arrow-right-arrow-left' : 'fa-layer-group'} text-[10px]"></i>
                        <span>${isEczatrendItem ? 'Grup Teklifleri & Kalanı Gör' : isEczanetakasItem ? 'Tüm Eczane Tekliflerini Gör' : 'Fiyat Detaylarını Gör'} (${item.pazaryeri_teklifleri.length})</span>
                    </button>
                ` : '';

                const safeItemName = (item.urun_adi || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
                const DEPO_PORTAL_CARTS = {
                    'SELCUK': 'https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx',
                    'ALLIANCE': 'https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart',
                    'ISKOOP': 'https://esube.iskoop.org/FrameWorkT1/#/baskets',
                    'NEVZAT': 'http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx',
                    'ECZANETAKAS': 'https://eczanetakas.com/teklifler/1'
                };
                const cartPortalUrl = DEPO_PORTAL_CARTS[item.depo];
                const cartLinkBadge = cartPortalUrl ? `
                    <a href="${cartPortalUrl}" target="_blank" class="mt-1 text-[10px] font-bold text-slate-400 hover:text-slate-800 flex items-center space-x-1 transition" title="${item.depo_adi} canlı portal sayfasını yeni sekmede aç">
                        <i class="fa-solid fa-cart-shopping text-[9px] text-slate-500"></i>
                        <span>${item.depo === 'ECZANETAKAS' ? 'Takas Portalı ↗' : 'Sepeti Gör ↗'}</span>
                    </a>
                ` : '';

                tr.innerHTML = `
                    <td class="py-4 px-6">
                        <div class="flex flex-col items-start">
                            <div class="flex items-center space-x-2">
                                <span class="${depoColor}">${item.depo_adi}</span>
                                ${rowColdIcon}
                                ${isBest ? '<span class="px-2 py-0.5 text-[10px] bg-emerald-600 text-white rounded-full font-bold uppercase tracking-wider">En Avantajlı</span>' : ''}
                            </div>
                            ${miadBadge}
                            ${offersBadgeCol1}
                            ${cartLinkBadge}
                        </div>
                    </td>
                    <td class="py-4 px-6">${stockBadge}</td>
                    <td class="py-4 px-6 text-slate-700 font-semibold">${item.depocu_satis_fiyati.toFixed(2)} ₺</td>
                    <td class="py-4 px-6">${mfHtml}</td>
                    <td class="py-4 px-6 text-slate-600">
                        <div class="font-medium">${item.vade_gun > 0 ? item.vade_gun + ' Gün' : 'Peşin / Kredi Kartı'}</div>
                        ${iskBadge}
                    </td>
                    <td class="py-4 px-6">
                        <div class="text-base font-extrabold ${isBest ? 'text-emerald-600' : 'text-slate-900'}">
                            ${item.net_birim_maliyet.toFixed(2)} ₺
                        </div>
                        <div class="text-[10px] text-slate-500 font-medium">
                            KDV Hariç ${realKademeler.length > 0 ? `(${realKademeler[0].mf_text} ile)` : ''}
                        </div>
                        ${psf > 0 ? `
                        <div class="text-[10px] text-slate-500 mt-1 flex flex-col space-y-0.5">
                            <span title="SGK Reçeteli Kutu Kârı: KSF - Alış" class="${(item.kamu_kari || 0) < 0 ? 'text-red-600 font-bold' : 'text-blue-700 font-medium'}">
                                <i class="fa-solid fa-file-prescription mr-1 text-[9px]"></i>SGK: ${(item.kamu_kari || 0) >= 0 ? '+' : ''}${(item.kamu_kari || 0).toFixed(2)} ₺
                            </span>
                            <span title="Elden Satış Kutu Kârı: PSF - Alış" class="text-emerald-700 font-medium">
                                <i class="fa-solid fa-hand-holding-dollar mr-1 text-[9px]"></i>Elden: +${(item.perakende_kari || 0).toFixed(2)} ₺
                            </span>
                        </div>
                        ` : ''}
                    </td>
                    <td class="py-4 px-6 text-right font-bold text-slate-700">
                        <div class="text-base font-extrabold text-slate-900">${item.net_birim_maliyet_kdvli.toFixed(2)} ₺</div>
                        <div class="text-[10px] text-slate-400 font-normal">%${item.kdv_orani} KDV Dahil</div>
                        ${(realKademeler.length > 0 && Math.abs(baseSingleNet - item.net_birim_maliyet) > 0.05) ? `
                            <div class="text-[10px] text-slate-500 mt-0.5 font-medium" title="1 Adet Tek Alımda KDV Dahil Tutar">
                                1 Adet: ${(baseSingleNet * (1 + item.kdv_orani/100)).toFixed(2)} ₺
                            </div>
                        ` : ''}
                    </td>
                    <td class="py-4 px-6 text-right">
                        ${item.depo === 'ECZATREND' ? `
                            <div class="flex items-center justify-end space-x-1.5">
                                <a href="https://eczatrend.com/eczanet/panelNew/main" target="_blank" class="px-3 py-1.5 rounded-xl text-xs font-bold bg-orange-600 hover:bg-orange-700 text-white shadow-sm shadow-orange-200 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer" title="Eczatrend portalında ortak alıma katıl">
                                    <i class="fa-solid fa-people-group text-[11px]"></i>
                                    <span>Ortak Alıma Git</span>
                                    <i class="fa-solid fa-arrow-up-right-from-square text-[9px] ml-0.5 opacity-80"></i>
                                </a>
                            </div>
                        ` : item.depo === 'ECZANETAKAS' ? `
                            <div class="flex items-center justify-end space-x-1.5">
                                <a href="${(item.pazaryeri_teklifleri && item.pazaryeri_teklifleri[0] && item.pazaryeri_teklifleri[0].katil_url) ? item.pazaryeri_teklifleri[0].katil_url : 'https://eczanetakas.com/teklifler/1'}" target="_blank" class="px-3 py-1.5 rounded-xl text-xs font-bold bg-sky-600 hover:bg-sky-700 text-white shadow-sm shadow-sky-200 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer" title="EczaneTakas portalında teklife katıl">
                                    <i class="fa-solid fa-arrow-right-arrow-left text-[11px]"></i>
                                    <span>Teklife Katıl</span>
                                    <i class="fa-solid fa-arrow-up-right-from-square text-[9px] ml-0.5 opacity-80"></i>
                                </a>
                            </div>
                        ` : ['ECZA1', 'FARMAZON'].includes(item.depo) ? `
                            <div class="flex items-center justify-end">
                                <button type="button" onclick="toggleOffersRow(${index})" class="px-3 py-1.5 rounded-xl text-xs font-bold ${item.depo === 'FARMAZON' ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-200' : 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-200'} transition flex items-center space-x-1 shadow-sm cursor-pointer whitespace-nowrap" title="Tüm satıcıların fiyatlarını ve stoklarını gör">
                                    <i class="fa-solid fa-list-ul text-[10px]"></i>
                                    <span>Teklifleri Gör</span>
                                </button>
                            </div>
                        ` : `
                            <div class="flex flex-col items-end space-y-1.5 min-w-[190px]">
                                <div class="flex items-center justify-end space-x-1.5 w-full">
                                    <input type="number" id="qty_${index}" min="1" value="1" class="w-14 px-2 py-1 text-xs border border-slate-300 rounded-lg text-center font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none" title="Sipariş Adedi" />
                                    <button onclick="addToCart('${item.depo}', '${item.urun_id || item.barkod}', '${item.barkod}', ${index}, this, '${safeItemName}')" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center space-x-1 shadow-sm cursor-pointer whitespace-nowrap" title="${item.depo_adi} sepetine ekle">
                                        <i class="fa-solid fa-cart-plus text-[11px]"></i>
                                        <span>Sepete At</span>
                                    </button>
                                </div>
                                <button onclick="quickFinalizeOrder('${item.depo}', '${item.urun_id || item.barkod}', '${item.barkod}', ${index}, '${safeItemName}', ${item.net_birim_maliyet_kdvli || item.depocu_satis_fiyati || 0})" class="w-full px-2.5 py-1 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white rounded-lg text-xs font-black transition flex items-center justify-center space-x-1.5 shadow-xs hover:shadow cursor-pointer whitespace-nowrap" title="Tekli acil siparişi hemen depoya ilet ve sonlandır (Sepet kontrolü ile)">
                                    <i class="fa-solid fa-bolt-lightning text-amber-200 animate-pulse text-[11px]"></i>
                                    <span>Siparişi Sonlandır</span>
                                </button>
                            </div>
                        `}
                    </td>
                `;
                tableBody.appendChild(tr);

                // Pazaryeri (Farmazon & Ecza1) ve Alım Grubu (Eczatrend) Detaylı Satıcı Teklifleri Akordiyon Satırı
                if (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri.length > 0) {
                    const trOffers = document.createElement('tr');
                    trOffers.id = `offersRow_${index}`;
                    trOffers.className = 'hidden bg-slate-50/90 border-y border-dashed border-slate-300';

                    const isFarmazon = item.depo === 'FARMAZON';
                    const isEczatrend = item.depo === 'ECZATREND';
                    const isEczanetakas = item.depo === 'ECZANETAKAS';
                    let themeHeader = isFarmazon ? 'text-amber-900 bg-amber-50/90 border-amber-200' : 'text-purple-900 bg-purple-50/90 border-purple-200';
                    let iconHeader = isFarmazon ? 'fa-store text-amber-600' : 'fa-cart-shopping text-purple-600';
                    if (isEczatrend) {
                        themeHeader = 'text-orange-950 bg-orange-50/90 border-orange-200';
                        iconHeader = 'fa-people-group text-orange-600';
                    } else if (isEczanetakas) {
                        themeHeader = 'text-sky-950 bg-sky-50/90 border-sky-200';
                        iconHeader = 'fa-arrow-right-arrow-left text-sky-600';
                    }

                    let offersTbody = '';
                    let tableHeaderHtml = '';

                    if (isEczatrend) {
                        tableHeaderHtml = `
                            <tr>
                                <th class="py-2.5 px-3 text-center w-20">Sıra</th>
                                <th class="py-2.5 px-3">Açan Eczane & Grup</th>
                                <th class="py-2.5 px-3 text-center w-24">Barem (MF)</th>
                                <th class="py-2.5 px-3 text-center w-28">Hedef / Alınan</th>
                                <th class="py-2.5 px-3 text-center w-28">Kalan Adet</th>
                                <th class="py-2.5 px-3 text-right w-28">Birim KDV Hariç</th>
                                <th class="py-2.5 px-3 text-right w-28">Birim KDV Dahil</th>
                                <th class="py-2.5 px-3 text-center w-36">Durum & Süre</th>
                                <th class="py-2.5 px-3 text-right w-24">İşlem</th>
                            </tr>
                        `;
                        offersTbody = item.pazaryeri_teklifleri.map((off, oIdx) => {
                            const isCheapest = oIdx === 0;
                            const isAcik = (off.kalan || 0) > 0;
                            const durumBadge = isAcik
                                ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200"><i class="fa-solid fa-circle-check mr-1 text-[9px]"></i>Alıma Açık</span>`
                                : `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-500"><i class="fa-solid fa-flag-checkered mr-1 text-[9px]"></i>Hedef Doldu</span>`;

                            return `
                                <tr class="hover:bg-white transition ${isCheapest ? 'bg-orange-50/40' : ''}">
                                    <td class="py-2.5 px-3 text-center">
                                        ${isCheapest ? '<span class="px-1.5 py-0.5 text-[10px] font-black rounded bg-orange-600 text-white uppercase tracking-wider">En Uygun</span>' : `<span class="text-slate-400 font-mono text-[11px]">#${oIdx + 1}</span>`}
                                    </td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-bold text-slate-900 flex items-center">
                                            <i class="fa-solid fa-hospital text-[11px] text-orange-600 mr-1.5"></i>
                                            <span>${off.satici || off.pharmacy}</span>
                                            <span class="text-[10px] text-slate-500 font-normal ml-1.5 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">${off.groupName}</span>
                                        </div>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-black bg-indigo-100 text-indigo-900 border border-indigo-200 font-mono">
                                            ${off.mf || 'Barem'}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-center text-xs">
                                        <div class="font-bold text-slate-800">${off.hedef} Kutu Hedef</div>
                                        <div class="text-[10px] text-slate-500 font-medium">Alınan: ${off.alinan} (${off.doluluk})</div>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-black ${isAcik ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-slate-100 text-slate-500'}">
                                            ${off.kalan} Kutu
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-bold text-slate-800 font-mono">
                                        ${(off.fiyat_kdvsiz || 0).toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-extrabold text-orange-700 font-mono">
                                        ${(off.fiyat || 0).toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        ${durumBadge}
                                        ${off.kalan_sure ? `<span class="text-[10px] text-slate-500 block mt-0.5 font-medium">${off.kalan_sure}</span>` : ''}
                                    </td>
                                    <td class="py-2.5 px-3 text-right">
                                        <a href="https://eczatrend.com/eczanet/panelNew/main" target="_blank" class="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold bg-orange-600 hover:bg-orange-700 text-white shadow-2xs transition">
                                            <i class="fa-solid fa-arrow-up-right-from-square mr-1 text-[10px]"></i>Katıl
                                        </a>
                                    </td>
                                </tr>
                            `;
                        }).join('');
                    } else if (isEczanetakas) {
                        tableHeaderHtml = `
                            <tr>
                                <th class="py-2.5 px-3 text-center w-20">Sıra</th>
                                <th class="py-2.5 px-3">Teklifi Veren Eczane</th>
                                <th class="py-2.5 px-3 text-center w-24">Barem (MF)</th>
                                <th class="py-2.5 px-3 text-center w-28">Kalan Kutu</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Hariç</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Dahil</th>
                                <th class="py-2.5 px-3 text-center w-28">Miad Tarihi</th>
                                <th class="py-2.5 px-3">Not / Açıklama</th>
                                <th class="py-2.5 px-3 text-right w-24">İşlem</th>
                            </tr>
                        `;
                        offersTbody = item.pazaryeri_teklifleri.map((off, oIdx) => {
                            const isCheapest = oIdx === 0;
                            const kdvli = (off.fiyat_kdvli != null ? off.fiyat_kdvli : (off.fiyat || 0));
                            const kdvsiz = (off.fiyat_kdvsiz != null ? off.fiyat_kdvsiz : (kdvli / (1.0 + (item.kdv_orani || 10.0) / 100.0)));
                            const katilLink = off.katil_url || `https://eczanetakas.com/katil/${off.teklif_no}`;
                            return `
                                <tr class="hover:bg-white transition ${isCheapest ? 'bg-sky-50/40' : ''}">
                                    <td class="py-2.5 px-3 text-center">
                                        ${isCheapest ? '<span class="px-1.5 py-0.5 text-[10px] font-black rounded bg-sky-600 text-white uppercase tracking-wider">En Uygun</span>' : `<span class="text-slate-400 font-mono text-[11px]">#${oIdx + 1}</span>`}
                                    </td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-bold text-slate-900 flex items-center">
                                            <i class="fa-solid fa-hospital text-[11px] text-sky-600 mr-1.5"></i>
                                            <span>${off.satici || 'Eczane'}</span>
                                            <span class="text-[10px] text-slate-500 font-mono ml-2">#${off.teklif_no || ''}</span>
                                        </div>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-black bg-indigo-100 text-indigo-900 border border-indigo-200 font-mono">
                                            ${off.mf || 'MF Yok'}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-black bg-sky-100 text-sky-900 border border-sky-300">
                                            ${off.stok} Kutu
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-bold text-slate-800 font-mono">
                                        ${kdvsiz.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-extrabold text-sky-700 font-mono">
                                        ${kdvli.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-800 font-mono">
                                            <i class="fa-regular fa-calendar-check mr-1 text-[10px] text-slate-500"></i>${off.miad || '-'}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-[11px] text-slate-600">
                                        ${off.not ? `<span class="italic text-slate-500">${off.not}</span>` : '<span class="text-slate-400">-</span>'}
                                    </td>
                                    <td class="py-2.5 px-3 text-right">
                                        <a href="${katilLink}" target="_blank" class="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold bg-sky-600 hover:bg-sky-700 text-white shadow-2xs transition">
                                            <i class="fa-solid fa-arrow-up-right-from-square mr-1 text-[10px]"></i>Katıl
                                        </a>
                                    </td>
                                </tr>
                            `;
                        }).join('');
                    } else {
                        tableHeaderHtml = `
                            <tr>
                                <th class="py-2.5 px-3 text-center w-20">Sıra</th>
                                <th class="py-2.5 px-3">Satıcı (Eczane / Mağaza)</th>
                                <th class="py-2.5 px-3 text-center w-24">Stok</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Hariç</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Dahil</th>
                                <th class="py-2.5 px-3 text-center w-28">Miad</th>
                                <th class="py-2.5 px-3">Kargo & Koşullar</th>
                            </tr>
                        `;
                        offersTbody = item.pazaryeri_teklifleri.map((off, oIdx) => {
                            const isCheapest = oIdx === 0;
                            const ratingTag = off.puan ? `
                                <span class="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-100 text-amber-800 ml-1.5 border border-amber-200" title="Satıcı Puanı: ${off.puan.toFixed(1)} / 10">
                                    <i class="fa-solid fa-star text-[9px] text-amber-500 mr-0.5"></i>${off.puan.toFixed(1)}
                                </span>
                            ` : '';

                            const miadDisplay = (off.miad && off.miad !== '-') ? `
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-800 font-mono">
                                    <i class="fa-regular fa-calendar-check mr-1 text-[10px] text-slate-500"></i>${off.miad}
                                </span>
                            ` : '<span class="text-slate-400 font-mono">-</span>';

                            const termsList = [];
                            if (off.min_tutar && off.min_tutar > 0) termsList.push(`Min: <strong>${off.min_tutar} ₺</strong>`);
                            if (off.ucretsiz_kargo && off.ucretsiz_kargo > 0) termsList.push(`<span class="text-emerald-700 font-semibold">${off.ucretsiz_kargo} ₺ Kargo Bedava</span>`);
                            if (off.kargo) termsList.push(`<span class="text-slate-500">${off.kargo}</span>`);
                            if (off.e_fatura) termsList.push(`<span class="text-purple-700 font-bold">e-Fatura</span>`);

                            const termsHtml = termsList.length > 0 ? termsList.join(' • ') : '<span class="text-slate-400">-</span>';
                            const noteHtml = off.aciklama ? `<div class="text-[10px] text-slate-500 italic mt-0.5 truncate max-w-sm" title="${off.aciklama}">${off.aciklama}</div>` : '';

                            return `
                                <tr class="hover:bg-white transition ${isCheapest ? 'bg-emerald-50/40' : ''}">
                                    <td class="py-2.5 px-3 text-center">
                                        ${isCheapest ? '<span class="px-1.5 py-0.5 text-[10px] font-black rounded bg-emerald-600 text-white uppercase tracking-wider">En Uygun</span>' : `<span class="text-slate-400 font-mono text-[11px]">#${oIdx + 1}</span>`}
                                    </td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-bold text-slate-900 flex items-center">
                                            <i class="fa-solid fa-shop text-[11px] text-slate-400 mr-1.5"></i>
                                            <span>${off.satici}</span>
                                            ${ratingTag}
                                        </div>
                                        ${noteHtml}
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${off.stok > 5 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
                                            ${off.stok} Kutu
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-bold text-slate-800 font-mono">
                                        ${off.fiyat_kdvsiz.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-extrabold text-emerald-700 font-mono">
                                        ${off.fiyat_kdvli.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        ${miadDisplay}
                                    </td>
                                    <td class="py-2.5 px-3 text-[11px] text-slate-600">
                                        ${termsHtml}
                                    </td>
                                </tr>
                            `;
                        }).join('');
                    }

                    trOffers.innerHTML = `
                        <td colspan="8" class="p-3 sm:p-4">
                            <div class="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden">
                                <div class="px-4 py-3 border-b flex flex-wrap items-center justify-between gap-2 ${themeHeader}">
                                    <div class="flex items-center space-x-2 font-bold text-xs">
                                        <i class="fa-solid ${iconHeader} text-sm"></i>
                                        <span>${isEczatrend ? `Eczatrend — Ortak Alım Grubu Teklifleri & Barem Kademeleri (${item.pazaryeri_teklifleri.length} Teklif)` : isEczanetakas ? `EczaneTakas — Açık Teklifler & Satıcı Eczaneler (${item.pazaryeri_teklifleri.length} Teklif)` : `${item.depo_adi} — Tüm Satıcı Eczane Teklifleri (${item.pazaryeri_teklifleri.length} Farklı Satıcı)`}</span>
                                    </div>
                                    <div class="text-[11px] font-medium text-slate-600 flex items-center space-x-2">
                                        <span>KDV Oranı: <strong>%${item.kdv_orani}</strong></span>
                                        <span>•</span>
                                        <span>Fiyata Göre Sıralı (En Düşük &rarr; En Yüksek)</span>
                                    </div>
                                </div>
                                <div class="overflow-x-auto max-h-72 overflow-y-auto divide-y divide-slate-100">
                                    <table class="w-full text-left text-xs">
                                        <thead class="bg-slate-100/80 text-[11px] font-bold text-slate-600 sticky top-0 backdrop-blur-xs">
                                            ${tableHeaderHtml}
                                        </thead>
                                        <tbody class="divide-y divide-slate-100 font-sans">
                                            ${offersTbody}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </td>
                    `;
                    tableBody.appendChild(trOffers);
                }
            });

            // Simülatörü güncelle
            selectedDepoForSim = data.en_avantajli_depo || (data.sonuclar[0] ? data.sonuclar[0].depo : null);
            updateSimulator();

            // Tria Eczane Raf Stoğu & Aylık Satış / Çıkış Hızı Paneli
            renderTriaAnalysis(data.tria_bilgisi);

            // SGK Eşdeğer Grubu ve Muadiller Analizi (Canlı MF Kârlılık, Raf Stoğu ve Satış Hızı)
            loadEquivalentsAnalysis(
                data.barkod || data.barcode,
                (data.tria_bilgisi && data.tria_bilgisi.mal_kodu) || '',
                data.esdegerler || [],
                data.esdeger_kodu || '',
                kamuKari,
                data.en_karli_muadil,
                data.muadil_kar_avantaji
            );

            results.classList.remove('hidden');
        }

        // ================= Eczane Otomasyonu (Botanik & Tria) Analiz & Raf Stoğu Görselleştirme =================
        window.currentOtomasyonSource = 'TRIA';
        window.currentOtomasyonMovementsTab = 'cikis';

        function openCurrentOtomasyonSettings() {
            const src = (window.currentOtomasyonSource || window.activeOtomasyon || 'TRIA').toUpperCase();
            if (src === 'TEBEOS') openSettingsModal('tebeos');
            else if (src === 'TRIA') openSettingsModal('tria');
            else openSettingsModal('botanik');
        }

        function switchOtomasyonMovementsTab(tab) {
            window.currentOtomasyonMovementsTab = tab;
            const btnCikis = document.getElementById('tabBtnCikislar');
            const btnGiris = document.getElementById('tabBtnGirisler');
            const btnBoth = document.getElementById('tabBtnBoth');
            const btnMuadil = document.getElementById('tabBtnMuadiller');
            const boxCikis = document.getElementById('boxCikislarView');
            const boxGiris = document.getElementById('boxGirislerView');
            const boxMuadil = document.getElementById('boxMuadillerView');
            const legendCikis = document.getElementById('cikisLegend');
            const legendGiris = document.getElementById('girisLegend');
            const legendMuadil = document.getElementById('muadilLegend');

            const activeClass = 'px-3 py-1.5 rounded-lg text-xs font-bold bg-white/20 text-white transition flex items-center space-x-1.5 cursor-pointer shadow-xs';
            const passiveClass = 'px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-white/10 transition flex items-center space-x-1.5 cursor-pointer';

            if (btnCikis) btnCikis.className = passiveClass;
            if (btnGiris) btnGiris.className = passiveClass;
            if (btnBoth) btnBoth.className = passiveClass;
            if (btnMuadil) btnMuadil.className = passiveClass;
            if (boxCikis) boxCikis.classList.add('hidden');
            if (boxGiris) boxGiris.classList.add('hidden');
            if (boxMuadil) boxMuadil.classList.add('hidden');
            if (legendCikis) legendCikis.classList.add('hidden');
            if (legendGiris) legendGiris.classList.add('hidden');
            if (legendMuadil) legendMuadil.classList.add('hidden');

            if (tab === 'cikis') {
                if (btnCikis) btnCikis.className = activeClass;
                if (boxCikis) boxCikis.classList.remove('hidden');
                if (legendCikis) legendCikis.classList.remove('hidden');
            } else if (tab === 'giris') {
                if (btnGiris) btnGiris.className = activeClass;
                if (boxGiris) boxGiris.classList.remove('hidden');
                if (legendGiris) legendGiris.classList.remove('hidden');
            } else if (tab === 'both') {
                if (btnBoth) btnBoth.className = activeClass;
                if (boxCikis) boxCikis.classList.remove('hidden');
                if (boxGiris) boxGiris.classList.remove('hidden');
                if (legendCikis) legendCikis.classList.remove('hidden');
                if (legendGiris) legendGiris.classList.remove('hidden');
            } else if (tab === 'muadil') {
                if (btnMuadil) btnMuadil.className = activeClass;
                if (boxMuadil) boxMuadil.classList.remove('hidden');
                if (legendMuadil) legendMuadil.classList.remove('hidden');
            }
        }

        function scrollToMuadillerTab() {
            switchOtomasyonMovementsTab('muadil');
            const targetEl = document.getElementById('tabBtnMuadiller') || document.getElementById('boxMuadillerView');
            if (targetEl) {
                targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        async function loadEquivalentsAnalysis(barcode, malKodu, fallbackEquivalents, fallbackGrupKodu, currentKamuKari, directEnKarliMuadil, directMuadilAvantaji) {
            const gridEl = document.getElementById('otomasyonMuadillerGrid');
            const badgeCountEl = document.getElementById('badgeMuadilCount');
            const darkGrupEl = document.getElementById('darkEsdegerKodu');
            const topEqBtn = document.getElementById('resEquivalentsBtn');
            const topEqBtnText = document.getElementById('resEquivalentsBtnText');
            const bannerEl = document.getElementById('boxMuadilHighlightBanner');
            const muadilAlertEl = document.getElementById('resMuadilProfitOpportunity');
            const bestMuadilNameEl = document.getElementById('resBestMuadilName');
            const bestMuadilGainEl = document.getElementById('resBestMuadilGain');

            if (!gridEl) return;

            // Yükleniyor durumu
            gridEl.innerHTML = `
                <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                    <i class="fa-solid fa-spinner animate-spin mr-1.5 text-amber-400"></i>Eşdeğer ilaçlar ve canlı depo kârlılıkları taranıyor...
                </div>
            `;

            let eqData = null;
            if (fallbackEquivalents && fallbackEquivalents.length > 0) {
                const hasValidBarcodes = fallbackEquivalents.some(e => e.barkod && String(e.barkod).length >= 8 && /^\d+$/.test(String(e.barkod)));
                const hasLiveMfChecked = fallbackEquivalents.some(e => e.live_mf_checked || (e.en_iyi_mf && e.en_iyi_mf !== 'YOK' && e.en_iyi_mf !== '-') || (e.mf && e.mf !== 'YOK' && e.mf !== '-'));
                if (hasValidBarcodes && hasLiveMfChecked) {
                    eqData = {
                        found: true,
                        esdeger_kodu: fallbackGrupKodu || 'DEPO_ESDEGER',
                        count: fallbackEquivalents.length,
                        en_karli_muadil: directEnKarliMuadil || null,
                        muadil_kar_avantaji: directMuadilAvantaji || 0.0,
                        current_kamu_kari: currentKamuKari || 0.0,
                        muadiller: fallbackEquivalents
                    };
                }
            }

            if (!eqData) {
                try {
                    const target = barcode || malKodu || '';
                    if (target) {
                        const resp = await fetch(`/api/products/equivalents?barcode=${encodeURIComponent(target)}&kod=${encodeURIComponent(malKodu || '')}`);
                        if (resp.ok) {
                            const json = await resp.json();
                            if (json && json.found && json.muadiller && json.muadiller.length > 0) {
                                eqData = json;
                            }
                        }
                    }
                } catch (e) {
                    console.warn('[Muadiller] Otomasyon eşdeğer sorgulama hatası:', e);
                }
            }

            if (!eqData && fallbackEquivalents && fallbackEquivalents.length > 0) {
                eqData = {
                    found: true,
                    esdeger_kodu: fallbackGrupKodu || 'DEPO_ESDEGER',
                    count: fallbackEquivalents.length,
                    en_karli_muadil: directEnKarliMuadil || null,
                    muadil_kar_avantaji: directMuadilAvantaji || 0.0,
                    current_kamu_kari: currentKamuKari || 0.0,
                    muadiller: fallbackEquivalents
                };
            }

            if (eqData && eqData.muadiller && typeof currentReport === 'object' && currentReport) {
                currentReport.esdegerler = eqData.muadiller;
                if (eqData.esdeger_kodu) currentReport.esdeger_kodu = eqData.esdeger_kodu;
                if (eqData.en_karli_muadil) currentReport.en_karli_muadil = eqData.en_karli_muadil;
                if (eqData.muadil_kar_avantaji !== undefined) currentReport.muadil_kar_avantaji = eqData.muadil_kar_avantaji;
            }


            if (!eqData || !eqData.muadiller || eqData.muadiller.length === 0) {
                if (badgeCountEl) badgeCountEl.innerText = '0';
                if (darkGrupEl) darkGrupEl.innerText = fallbackGrupKodu || 'Yok';
                if (bannerEl) { bannerEl.innerHTML = ''; bannerEl.classList.add('hidden'); }
                if (muadilAlertEl) { muadilAlertEl.classList.remove('inline-flex'); muadilAlertEl.classList.add('hidden'); }
                gridEl.innerHTML = `
                    <div class="bg-white/5 border border-white/10 rounded-xl p-5 text-center col-span-full text-xs text-slate-400">
                        <i class="fa-solid fa-circle-info text-amber-400 mr-1.5"></i>
                        Bu ilacın kayıtlı bir SGK eşdeğer grubu veya canlı muadili bulunamadı.
                    </div>
                `;
                return;
            }

            // Eşdeğerler var!
            const muadiller = eqData.muadiller;
            const count = muadiller.length;
            if (badgeCountEl) badgeCountEl.innerText = count;
            if (darkGrupEl) darkGrupEl.innerText = eqData.esdeger_kodu || 'SGK Grubu';
            if (topEqBtn && topEqBtnText) {
                topEqBtn.classList.remove('hidden');
                topEqBtn.classList.add('inline-flex');
                topEqBtnText.innerText = `Muadiller (${count})`;
            }

            const bestM = eqData.en_karli_muadil || directEnKarliMuadil;
            const bestGain = (eqData.muadil_kar_avantaji !== undefined && eqData.muadil_kar_avantaji !== null) ? eqData.muadil_kar_avantaji : (directMuadilAvantaji || 0);

            // 1. Üst Arama Sonucu Bildirim Rozeti (#resMuadilProfitOpportunity)
            if (bestM && bestGain > 0) {
                if (bestMuadilNameEl) bestMuadilNameEl.innerText = bestM.urun_adi || bestM.ad || 'Muadil İlaç';
                if (bestMuadilGainEl) bestMuadilGainEl.innerText = `+${bestGain.toFixed(2)} ₺`;
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('hidden');
                    muadilAlertEl.classList.add('inline-flex');
                }
            } else {
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('inline-flex');
                    muadilAlertEl.classList.add('hidden');
                }
            }

            // 2. Muadiller Sekmesi İçi En Kârlı İlaç Vurgu Bannerı (#boxMuadilHighlightBanner)
            if (bannerEl) {
                if (bestM && bestGain > 0) {
                    const mName = bestM.urun_adi || bestM.ad || '';
                    const mSafeName = mName.replace(/'/g, "\\'").replace(/"/g, '&quot;');
                    const mCode = bestM.barkod || bestM.kod || bestM.mal_kodu || '';
                    const mLiveMf = (bestM.en_iyi_mf && bestM.en_iyi_mf !== 'YOK' && bestM.en_iyi_mf !== '-') ? bestM.en_iyi_mf : ((bestM.mf && bestM.mf !== 'YOK' && bestM.mf !== '-') ? bestM.mf : 'Barem Yok');
                    const mCostKdvli = bestM.net_birim_maliyet_kdvli || bestM.birim_maliyet_kdvli || 0;
                    const mKamuKari = bestM.kamu_kari || 0;
                    const mYuzde = bestM.kar_artis_yuzdesi || 0;

                    bannerEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-gradient-to-r from-amber-950/70 via-emerald-950/70 to-slate-900 border-2 border-amber-400/80 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4">
                            <div class="flex items-center space-x-4">
                                <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center text-2xl shadow-lg shadow-amber-500/30 shrink-0 font-black">
                                    <i class="fa-solid fa-trophy"></i>
                                </div>
                                <div>
                                    <div class="text-[11px] uppercase tracking-wider font-extrabold text-amber-300 flex items-center gap-2 flex-wrap">
                                        <span>🏆 EN KÂRLI ANLIK SGK EŞDEĞERİ</span>
                                        ${mYuzde > 0 ? `<span class="px-2 py-0.5 rounded-full text-[10px] bg-amber-400 text-slate-950 font-black">%${mYuzde} DAHA KÂRLI</span>` : ''}
                                    </div>
                                    <div class="text-base font-black text-white mt-0.5">
                                        ${mName}
                                    </div>
                                    <div class="text-xs text-slate-300 mt-1 flex flex-wrap items-center gap-2 font-medium">
                                        <span class="text-amber-300 font-bold"><i class="fa-solid fa-fire mr-1"></i>Anlık Depo MF: ${mLiveMf} ${bestM.depo ? `(${bestM.depo})` : ''}</span>
                                        <span class="text-slate-500">•</span>
                                        <span>Birim Alış: <strong class="text-white font-mono">${mCostKdvli.toFixed(2)} ₺</strong> (KDV Dahil)</span>
                                        <span class="text-slate-500">•</span>
                                        <span>SGK Reçete Kârı: <strong class="text-emerald-400 font-bold">+${mKamuKari.toFixed(2)} ₺</strong></span>
                                    </div>
                                </div>
                            </div>
                            <div class="flex flex-col sm:flex-row items-center gap-2.5 shrink-0 w-full md:w-auto">
                                <div class="px-3.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-black text-center sm:text-right w-full sm:w-auto">
                                    <div class="text-[10px] uppercase text-emerald-400 font-medium">Kutu Başı Kâr Avantajı</div>
                                    <div class="text-base font-extrabold text-emerald-300">+${bestGain.toFixed(2)} ₺</div>
                                </div>
                                <button type="button" onclick="selectAndSearch('${mCode}', '${mSafeName}')" class="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs transition shadow-lg shadow-amber-500/20 cursor-pointer flex items-center justify-center space-x-2">
                                    <i class="fa-solid fa-arrows-split-up-and-left"></i>
                                    <span>Bu Kârlı Muadili Karşılaştır</span>
                                </button>
                            </div>
                        </div>
                    `;
                    bannerEl.classList.remove('hidden');
                } else {
                    bannerEl.innerHTML = '';
                    bannerEl.classList.add('hidden');
                }
            }

            // 3. Muadil Kartlarını Kârlılık Sırasıyla Render Et
            gridEl.innerHTML = muadiller.map(item => {
                const isCur = !!item.is_current;
                const isBestDeal = !!item.is_best_deal;
                const mName = item.urun_adi || item.ad || '';
                const safeName = mName.replace(/'/g, "\\'").replace(/"/g, '&quot;');
                const searchCode = item.barkod || item.kod || item.mal_kodu || '';
                
                const psf = item.psf || item.etiket_fiyati || 0;
                const ksf = item.ksf || item.kamu_fiyati || (psf > 0 ? (psf * (1.0 - ((item.kamu_iskontosu || 0) / 100.0))) : 0);
                const netKdvsiz = item.net_birim_maliyet || item.birim_maliyet || 0;
                const netKdvli = item.net_birim_maliyet_kdvli || item.birim_maliyet_kdvli || 0;
                const kamuKari = (item.kamu_kari !== undefined && item.kamu_kari !== null) ? item.kamu_kari : (ksf > 0 && netKdvli > 0 ? (ksf - netKdvli) : 0);
                const perakendeKari = (item.perakende_kari !== undefined && item.perakende_kari !== null) ? item.perakende_kari : (psf > 0 && netKdvli > 0 ? (psf - netKdvli) : 0);
                const karFarki = item.kar_farki || 0;
                const karArtis = item.kar_artis_yuzdesi || 0;

                let cardBorder = 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10';
                if (isBestDeal) {
                    cardBorder = 'border-2 border-amber-400/80 bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-900 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400/40';
                } else if (isCur) {
                    cardBorder = 'border-indigo-400/60 bg-indigo-950/30 ring-1 ring-indigo-500/30';
                } else if (karFarki > 0) {
                    cardBorder = 'border-emerald-500/40 bg-emerald-950/20 hover:border-emerald-500/60';
                }

                // Stok rozeti
                const stockColor = item.stok > 0 ? 'text-emerald-400' : 'text-amber-400';
                const stockBadge = item.stok > 0 
                    ? `<span class="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">${item.stok} Kutu Stok</span>`
                    : `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">Stok Yok</span>`;

                // Canlı MF Alanı
                const rawBestMf = (item.en_iyi_mf && item.en_iyi_mf !== '-' && item.en_iyi_mf !== 'YOK') ? item.en_iyi_mf : null;
                const rawFullMf = (item.mf && item.mf !== '-' && item.mf !== 'YOK') ? item.mf : null;
                const liveMf = rawBestMf || rawFullMf;
                let mfSectionHtml = '';
                if (liveMf) {
                    const kademeler = item.kademeler || [];
                    mfSectionHtml = `
                        <div class="mt-2.5 p-2 rounded-xl bg-amber-500/15 border border-amber-400/30">
                            <div class="flex items-center justify-between text-xs gap-1">
                                <div class="flex items-center space-x-1.5 min-w-0">
                                    <i class="fa-solid fa-fire text-amber-400 animate-pulse shrink-0"></i>
                                    <span class="text-slate-300 font-medium shrink-0">Anlık Canlı MF:</span>
                                    <strong class="text-amber-300 font-black text-sm font-mono truncate" title="${rawFullMf || liveMf}">${rawFullMf || liveMf}</strong>
                                </div>
                                <span class="text-[10px] font-bold text-amber-200/90 bg-black/30 px-1.5 py-0.5 rounded uppercase tracking-wider shrink-0">${item.depo || 'Canlı Depo'}</span>
                            </div>
                            ${kademeler.length > 0 ? `
                                <div class="flex flex-wrap gap-1 mt-1.5 pt-1.5 border-t border-amber-400/20">
                                    ${kademeler.map(k => {
                                        const kNet = k.net_birim_maliyet || k.birim_maliyet || 0;
                                        const kKdvli = k.net_birim_maliyet_kdvli || k.birim_maliyet_kdvli || 0;
                                        return `
                                            <span class="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-black/40 text-amber-200 border border-amber-400/20" title="KDV Hariç: ${kNet.toFixed(2)} ₺ | KDV Dahil: ${kKdvli.toFixed(2)} ₺">
                                                ${k.mf_text} (${kKdvli.toFixed(1)} ₺)
                                            </span>
                                        `;
                                    }).join('')}
                                </div>
                            ` : ''}
                        </div>
                    `;
                } else if (item.gecmis_mf_var && (item.gecmis_mf_kisa || item.gecmis_mf_bilgi)) {
                    mfSectionHtml = `
                        <div class="mt-2.5 p-1.5 rounded-lg bg-indigo-500/15 border border-indigo-400/30 text-center text-[11px] text-indigo-200 flex items-center justify-center space-x-1.5" title="${item.gecmis_mf_bilgi || ''}">
                            <i class="fa-solid fa-clock-rotate-left text-indigo-400"></i>
                            <span>Anlık MF Yok • <strong>Son Fatura: ${item.gecmis_mf_kisa ? item.gecmis_mf_kisa + ' MF' : item.gecmis_mf_bilgi}</strong></span>
                        </div>
                    `;
                } else {
                    mfSectionHtml = `
                        <div class="mt-2.5 p-1.5 rounded-lg bg-white/5 border border-white/10 text-center text-[11px] text-slate-400 flex items-center justify-center space-x-1">
                            <i class="fa-regular fa-circle-xmark text-slate-500"></i>
                            <span>Anlık MF Yok (Tekli Alım Fiyatı)</span>
                        </div>
                    `;
                }

                // Kâr Farkı Bannerı
                let profitDiffBanner = '';
                if (isBestDeal || karFarki > 0) {
                    profitDiffBanner = `
                        <div class="mt-2.5 px-2.5 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 text-xs font-bold flex items-center justify-between shadow-2xs">
                            <div class="flex items-center space-x-1.5">
                                <i class="fa-solid fa-arrow-trend-up text-emerald-400"></i>
                                <span>Kutu Başı Kâr Avantajı:</span>
                            </div>
                            <span class="text-emerald-300 font-black font-mono text-sm">+${karFarki.toFixed(2)} ₺ ${karArtis > 0 ? `(%${karArtis})` : ''}</span>
                        </div>
                    `;
                } else if (isCur) {
                    profitDiffBanner = `
                        <div class="mt-2.5 px-2 py-1 rounded-lg bg-indigo-500/15 border border-indigo-400/20 text-indigo-300 text-[11px] font-medium text-center">
                            <i class="fa-solid fa-circle-dot text-indigo-400 mr-1"></i>Şu an sorgulanan baz ilaç
                        </div>
                    `;
                }

                return `
                    <div class="rounded-2xl p-4 border ${cardBorder} flex flex-col justify-between transition relative">
                        <div>
                            <!-- Üst Rozetler (En Kârlı / Aranan) -->
                            <div class="flex items-center justify-between gap-2 mb-2">
                                <div class="flex items-center space-x-1.5 flex-wrap">
                                    ${isBestDeal ? `
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 uppercase tracking-wider shadow-sm">
                                            <i class="fa-solid fa-trophy mr-1 text-[10px]"></i>EN KÂRLI MUADİL
                                        </span>
                                    ` : ''}
                                    ${isCur ? `
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-indigo-500 text-white uppercase tracking-wider">
                                            Aranan İlaç
                                        </span>
                                    ` : ''}
                                    ${(!isBestDeal && karFarki > 0) ? `
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/30 text-emerald-300 border border-emerald-500/40">
                                            +${karFarki.toFixed(2)} ₺ Daha Kârlı
                                        </span>
                                    ` : ''}
                                </div>
                                <div class="shrink-0">
                                    ${stockBadge}
                                </div>
                            </div>

                            <!-- İlaç Adı ve Fiyatları -->
                            <div class="min-w-0">
                                <h4 class="text-sm font-black text-white leading-snug line-clamp-2" title="${mName}">
                                    ${mName}
                                </h4>
                                <div class="text-[11px] text-slate-400 font-mono mt-1 flex flex-wrap items-center gap-1.5">
                                    <span>${searchCode}</span>
                                    ${psf > 0 ? `<span class="text-slate-500">•</span><span class="text-slate-300">PSF: <strong>${psf.toFixed(2)} ₺</strong></span>` : ''}
                                    ${ksf > 0 ? `<span class="text-slate-500">•</span><span class="text-indigo-300">KSF: <strong>${ksf.toFixed(2)} ₺</strong></span>` : ''}
                                </div>
                            </div>

                            <!-- Canlı MF Bilgisi -->
                            ${mfSectionHtml}

                            <!-- 3 Sütun Kârlılık ve Birim Maliyet Tablosu -->
                            <div class="grid grid-cols-3 gap-1.5 mt-3 pt-2 border-t border-white/10 text-center">
                                <div class="bg-black/30 rounded-xl p-2 flex flex-col justify-between">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider leading-tight">Net Kutu Alış</div>
                                    <div class="text-xs font-black text-white font-mono mt-1">${netKdvli.toFixed(2)} ₺</div>
                                    <div class="text-[8px] text-slate-500 mt-0.5">KDV Dahil</div>
                                </div>
                                <div class="bg-black/30 rounded-xl p-2 flex flex-col justify-between border ${kamuKari >= 0 ? 'border-blue-500/20' : 'border-red-500/30'}">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider leading-tight">SGK Reçete Kârı</div>
                                    <div class="text-xs font-black ${kamuKari >= 0 ? 'text-blue-400' : 'text-red-400'} font-mono mt-1">
                                        ${kamuKari >= 0 ? '+' : ''}${kamuKari.toFixed(2)} ₺
                                    </div>
                                    <div class="text-[8px] text-slate-500 mt-0.5">KSF - Alış</div>
                                </div>
                                <div class="bg-black/30 rounded-xl p-2 flex flex-col justify-between border border-emerald-500/20">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider leading-tight">Elden Satış Kârı</div>
                                    <div class="text-xs font-black text-emerald-400 font-mono mt-1">
                                        ${perakendeKari >= 0 ? '+' : ''}${perakendeKari.toFixed(2)} ₺
                                    </div>
                                    <div class="text-[8px] text-slate-500 mt-0.5">PSF - Alış</div>
                                </div>
                            </div>

                            <!-- Kâr Farkı Avantaj Rozeti -->
                            ${profitDiffBanner}

                            <!-- 30 Günlük Çıkış & Raf Stoğu Metrikleri -->
                            <div class="grid grid-cols-2 gap-2 mt-2.5 pt-2 border-t border-white/10 text-center">
                                <div class="bg-black/20 rounded-lg p-1.5">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider">Raf Stoğu</div>
                                    <div class="text-xs font-black ${stockColor} mt-0.5">${item.stok} Kutu</div>
                                </div>
                                <div class="bg-black/20 rounded-lg p-1.5">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider">30 Gün Satış</div>
                                    <div class="text-xs font-black text-cyan-300 mt-0.5">${item.cikis_30gun} Kutu</div>
                                </div>
                            </div>

                            <!-- Geçmiş MF Göstergesi (varsa) -->
                            ${item.gecmis_mf_var ? `
                                <div class="mt-2 text-[10px] text-amber-300/80 flex items-center space-x-1">
                                    <i class="fa-solid fa-clock-rotate-left text-amber-400"></i>
                                    <span>Eczane Geçmiş Alım MF: <strong>${item.gecmis_mf_bilgi}</strong></span>
                                </div>
                            ` : ''}
                        </div>

                        <!-- Karşılaştırma Butonu -->
                        <div class="mt-3.5 pt-2.5 border-t border-white/10">
                            <button type="button" onclick="selectAndSearch('${searchCode}', '${safeName}')" class="w-full py-2 px-3 rounded-xl text-xs font-black ${isBestDeal ? 'bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-md shadow-amber-500/20' : 'bg-indigo-600/90 hover:bg-indigo-600 text-white shadow-sm'} transition flex items-center justify-center space-x-1.5 cursor-pointer">
                                <i class="fa-solid ${isBestDeal ? 'fa-crown' : 'fa-arrows-split-up-and-left'} text-[11px]"></i>
                                <span>${isBestDeal ? 'Bu Kârlı Muadili Karşılaştır' : 'Tüm Depolarda Karşılaştır'}</span>
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        function renderTriaAnalysis(tria) {
            const stockQtyEl = document.getElementById('triaStockQty');
            const statusBadgeEl = document.getElementById('triaStockStatusBadge');
            const gridEl = document.getElementById('triaMonthlyGrid');
            const girisGridEl = document.getElementById('otomasyonGirislerGrid');
            const girisBadgeEl = document.getElementById('badgeGirisCount');
            const avgMonthlyEl = document.getElementById('triaAvgMonthly');
            const avgDailyEl = document.getElementById('triaAvgDaily');
            const daysLeftEl = document.getElementById('triaDaysLeft');
            const suggestedEl = document.getElementById('triaOrderSuggested');
            const brandBadgeEl = document.getElementById('otoBrandBadge');
            const brandTextEl = document.getElementById('otoBrandText');
            const hostSubBadgeEl = document.getElementById('triaHostSubBadge');

            if (!tria || !tria.found) {
                stockQtyEl.innerText = '--';
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-slate-700 text-slate-300';
                statusBadgeEl.innerText = (!tria || !tria.connected) ? 'BAĞLANTI YOK' : 'STOK KAYDI BULUNAMADI';
                avgMonthlyEl.innerText = '--';
                avgDailyEl.innerText = '-- / Gün';
                daysLeftEl.innerText = '--';
                suggestedEl.innerText = '--';
                if (girisBadgeEl) girisBadgeEl.innerText = '0';
                gridEl.innerHTML = `
                    <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                        <i class="fa-solid fa-circle-info mr-1.5 text-amber-400"></i>
                        ${tria && tria.message ? tria.message : 'Bu ilaç eczane otomasyonunda bulunamadı veya henüz satış/stok hareketi oluşmamış.'}
                    </div>
                `;
                if (girisGridEl) {
                    girisGridEl.innerHTML = `
                        <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                            Depo alış faturaları bulunamadı.
                        </div>
                    `;
                }
                return;
            }

            // 0. Otomasyon Kaynağı ve Başlık Rozeti (Botanik vs Tria vs Tebeos)
            window.currentOtomasyonSource = tria.kaynak || 'BOTANIK';
            if (tria.kaynak === 'TEBEOS') {
                if (brandBadgeEl) brandBadgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-sky-500/20 text-sky-300 border border-sky-400/30';
                if (brandTextEl) brandTextEl.innerText = 'TEBEOS ECZANE OTOMASYONU • CANLI ENTEGRASYON';
                if (hostSubBadgeEl) hostSubBadgeEl.innerText = `PostgreSQL 5454 (${tria.mal_adi ? tria.mal_adi.substring(0, 24) : 'Bağlı'})`;
            } else if (tria.kaynak === 'BOTANIK') {
                if (brandBadgeEl) brandBadgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/30';
                if (brandTextEl) brandTextEl.innerText = 'BOTANİK ECZANE OTOMASYONU • CANLI ENTEGRASYON';
                if (hostSubBadgeEl) hostSubBadgeEl.innerText = `MS SQL Server (${tria.mal_adi ? tria.mal_adi.substring(0, 24) : 'Bağlı'})`;
            } else {
                if (brandBadgeEl) brandBadgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-500/20 text-amber-300 border border-amber-400/30';
                if (brandTextEl) brandTextEl.innerText = 'TRIA ECZANE OTOMASYONU • CANLI ENTEGRASYON';
                if (hostSubBadgeEl) hostSubBadgeEl.innerText = (tria.mal_kodu ? `TRIA Kod: ${tria.mal_kodu}` : 'Oracle ORCL');
            }

            // 1. Raf Stoğu
            stockQtyEl.innerText = tria.stok;

            // Durum Rozeti
            if (tria.hareketsiz_kart) {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-slate-500/25 text-slate-300 border border-slate-500/40';
                statusBadgeEl.innerText = 'HAREKET YOK';
                daysLeftEl.innerText = '-';
                avgMonthlyEl.innerText = '0 Kutu';
                avgDailyEl.innerText = '~0 / Gün';
                suggestedEl.innerText = '1 Kutu (Öneri)';
            } else if (tria.stok <= 0) {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-rose-500/25 text-rose-300 border border-rose-500/40';
                statusBadgeEl.innerText = 'TÜKENDİ';
            } else if (tria.kalan_gun < 10) {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-amber-500/25 text-amber-300 border border-amber-500/40';
                statusBadgeEl.innerText = 'KRİTİK AZ';
            } else if (tria.kalan_gun <= 30) {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-emerald-500/25 text-emerald-300 border border-emerald-500/40';
                statusBadgeEl.innerText = 'YETERLİ';
            } else {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-sky-500/25 text-sky-300 border border-sky-500/40';
                statusBadgeEl.innerText = 'YÜKSEK STOK';
            }

            // 2. Metrikler
            if (!tria.hareketsiz_kart) {
                avgMonthlyEl.innerText = `${tria.ort_aylik_cikis} Kutu`;
                avgDailyEl.innerText = `~${tria.ort_gunluk_cikis} / Gün`;
                
                if (tria.stok <= 0) {
                    daysLeftEl.innerText = '0 Gün';
                } else if (tria.kalan_gun >= 90) {
                    daysLeftEl.innerText = '> 90 Gün';
                } else {
                    daysLeftEl.innerText = `~${tria.kalan_gun} Gün`;
                }

                suggestedEl.innerText = `${tria.onerilen_siparis} Kutu`;
            }

            // Otomatik olarak simülatör sipariş miktarını önerilen değere ayarla
            if (tria.onerilen_siparis > 0) {
                simQtyInput.value = tria.onerilen_siparis;
                updateSimulator();
            } else if (tria.hareketsiz_kart) {
                simQtyInput.value = 1;
                updateSimulator();
            }

            // 3. ÇIKIŞLAR: Aylık Satış Kartları Grid (6 Takvim Ayı: Nakit vs Reçeteli)
            const cikislar = tria.aylik_cikislar || [];
            if (cikislar.length === 0) {
                gridEl.innerHTML = `
                    <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                        Son 6 ayda herhangi bir çıkış hareketi bulunamadı.
                    </div>
                `;
            } else {
                gridEl.innerHTML = cikislar.map(m => {
                    const nakitPct = m.toplam > 0 ? Math.round((m.nakit / m.toplam) * 100) : 0;
                    const recetePct = m.toplam > 0 ? (100 - nakitPct) : 0;

                    return `
                        <div class="bg-white/5 hover:bg-white/10 border ${m.is_current ? 'border-amber-400/50 bg-amber-500/5' : 'border-white/10'} rounded-xl p-3 flex flex-col justify-between transition group">
                            <div class="flex items-center justify-between text-[11px] mb-2">
                                <span class="font-bold ${m.is_current ? 'text-amber-300 font-extrabold' : 'text-slate-300'} group-hover:text-white truncate" title="${m.label}">
                                    ${m.label}
                                </span>
                                <span class="font-black text-emerald-400 text-xs shrink-0 ml-1">
                                    ${m.toplam} <span class="text-[9px] font-normal text-slate-400">Kt</span>
                                </span>
                            </div>
                            
                            <!-- Orantılı Çıkış Barı: Nakit (Yeşil) vs SGK Reçete (Mavi) -->
                            <div class="my-1.5">
                                <div class="w-full bg-white/10 rounded-full h-2 flex overflow-hidden">
                                    <div style="width: ${nakitPct}%" class="bg-emerald-400 h-full transition-all duration-500" title="Nakit / Elden: ${m.nakit} kutu (%${nakitPct})"></div>
                                    <div style="width: ${recetePct}%" class="bg-blue-400 h-full transition-all duration-500" title="SGK / Reçete: ${m.receteli} kutu (%${recetePct})"></div>
                                </div>
                            </div>

                            <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1.5 border-t border-white/5">
                                <span class="text-emerald-300 font-semibold" title="Nakit / Elden Satış">
                                    <i class="fa-solid fa-coins mr-0.5 text-[8px]"></i>${m.nakit}
                                </span>
                                <span class="text-blue-300 font-semibold" title="SGK Reçeteli Çıkış">
                                    <i class="fa-solid fa-file-prescription mr-0.5 text-[8px]"></i>${m.receteli}
                                </span>
                            </div>
                        </div>
                    `;
                }).join('');
            }

            // 4. GİRİŞLER: Son Depo Alış Faturaları Kartları Grid
            const girisler = tria.son_girisler || [];
            if (girisBadgeEl) girisBadgeEl.innerText = girisler.length;

            if (girisGridEl) {
                if (girisler.length === 0) {
                    girisGridEl.innerHTML = `
                        <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                            <i class="fa-solid fa-circle-info mr-1.5 text-cyan-400"></i>
                            Bu ilaca ait son 6 ayda sisteme girilmiş kayıtlı depo faturası bulunamadı.
                        </div>
                    `;
                } else {
                    girisGridEl.innerHTML = girisler.map(g => {
                        const depoUpper = (g.depo || '').toUpperCase();
                        let badgeColor = 'bg-slate-700 text-slate-200 border-slate-600';
                        let depoIcon = 'fa-solid fa-truck-ramp-box';

                        if (depoUpper.includes('ISKOOP') || depoUpper.includes('İSKOOP')) {
                            badgeColor = 'bg-rose-500/20 text-rose-300 border-rose-500/30';
                            depoIcon = 'fa-solid fa-building text-rose-400';
                        } else if (depoUpper.includes('HEDEF') || depoUpper.includes('ALLIANCE')) {
                            badgeColor = 'bg-sky-500/20 text-sky-300 border-sky-500/30';
                            depoIcon = 'fa-solid fa-truck-medical text-sky-400';
                        } else if (depoUpper.includes('SELCUK') || depoUpper.includes('SELÇUK')) {
                            badgeColor = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
                            depoIcon = 'fa-solid fa-building-columns text-emerald-400';
                        } else if (depoUpper.includes('NEVZAT')) {
                            badgeColor = 'bg-amber-500/20 text-amber-300 border-amber-500/30';
                            depoIcon = 'fa-solid fa-truck text-amber-400';
                        } else if (depoUpper.includes('DNA')) {
                            badgeColor = 'bg-purple-500/20 text-purple-300 border-purple-500/30';
                            depoIcon = 'fa-solid fa-boxes-packing text-purple-400';
                        }

                        const mfBadge = g.mf > 0 ? `<span class="ml-1 px-1.5 py-0.2 rounded text-[10px] font-black bg-amber-500/30 text-amber-200 border border-amber-400/30">+${g.mf} MF</span>` : '';

                        return `
                            <div class="bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-3 flex flex-col justify-between transition group">
                                <div class="flex items-center justify-between text-[11px] mb-2 pb-1.5 border-b border-white/5">
                                    <span class="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold border ${badgeColor}">
                                        <i class="${depoIcon} mr-1"></i>
                                        <span>${g.depo}</span>
                                    </span>
                                    <span class="text-slate-400 font-mono text-[10px] flex items-center">
                                        <i class="fa-regular fa-calendar mr-1"></i>${g.tarih}
                                    </span>
                                </div>

                                <div class="flex items-center justify-between my-1">
                                    <div>
                                        <div class="text-[10px] text-slate-400">Gelen Miktar</div>
                                        <div class="text-sm font-black text-white flex items-center">
                                            <span>${g.adet} Kutu</span>
                                            ${mfBadge}
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <div class="text-[10px] text-slate-400">Birim Net Maliyet</div>
                                        <div class="text-sm font-black text-emerald-400 font-mono">
                                            ${g.maliyet.toFixed(2)} ₺
                                        </div>
                                    </div>
                                </div>

                                <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1.5 border-t border-white/5 mt-1 font-mono">
                                    <span class="truncate max-w-[150px]" title="Fatura No: ${g.fatura_no || '-'}">Fat: ${g.fatura_no || '-'}</span>
                                    <span class="text-cyan-300 font-bold">Toplam: ${g.toplam_adet} Kutu</span>
                                </div>
                            </div>
                        `;
                    }).join('');
                }
            }
        }

        function setSuggestedQty() {
            const oto = currentReport ? (currentReport.otomasyon_bilgisi || currentReport.botanik_bilgisi || currentReport.tria_bilgisi) : null;
            if (!oto) {
                showToast('Bilgi', 'Öneri için otomasyon verisi bulunamadı.', 'error');
                return;
            }
            const qty = oto.onerilen_siparis > 0 ? oto.onerilen_siparis : Math.max(1, Math.round(oto.ort_aylik_cikis || 10));
            setSimulatorQty(qty);
            showToast('Önerilen Miktar Seçildi', `30 günlük güvenlik ihtiyacınıza göre ${qty} kutu sipariş miktarı belirlendi.`, 'success');
        }

        function toggleMfDetails() {
            const box = document.getElementById('simResultsBox');
            const icon = document.getElementById('mfToggleIcon');
            if (!box || !icon) return;
            if (box.classList.contains('hidden')) {
                box.classList.remove('hidden');
                icon.className = 'fa-solid fa-circle-chevron-up mr-1';
            } else {
                box.classList.add('hidden');
                icon.className = 'fa-solid fa-circle-chevron-down mr-1';
            }
        }

        async function openEsdegerModal() {
            if (!currentReport) return;
            const modal = document.getElementById('esdegerModal');
            const list = document.getElementById('modalEsdegerList');
            const countEl = document.getElementById('modalEsdegerCount');
            const kodEl = document.getElementById('modalEsdegerKodu');

            modal.classList.remove('hidden');
            kodEl.innerText = currentReport.esdeger_kodu ? `SGK Kodu: ${currentReport.esdeger_kodu}` : 'SGK Eşdeğer Grubu';

            let eqList = currentReport.esdegerler || [];
            const needsLiveRefresh = eqList.length === 0 || !eqList.some(e => e.live_mf_checked);

            function renderModalItems(items) {
                countEl.innerText = items.length;
                list.innerHTML = '';
                if (items.length === 0) {
                    list.innerHTML = `
                        <div class="p-8 text-center text-slate-400 text-xs bg-white rounded-2xl border border-dashed border-slate-200">
                            <i class="fa-solid fa-circle-exclamation text-2xl text-slate-300 mb-2 block"></i>
                            Bu ilaç için SGK eşdeğer grubunda kayıtlı muadil ilaç bulunamadı.
                        </div>
                    `;
                    return;
                }
                items.forEach(eq => {
                    const div = document.createElement('div');
                    const isBest = !!eq.is_best_deal;
                    const karFarki = eq.kar_farki || 0;
                    let borderCls = 'bg-white border-slate-200 hover:border-indigo-400 hover:shadow-xs';
                    if (isBest) borderCls = 'bg-amber-50/70 border-2 border-amber-400 shadow-sm';
                    else if (eq.is_current) borderCls = 'bg-indigo-50/60 border-indigo-300';
                    else if (karFarki > 0) borderCls = 'bg-emerald-50/40 border-emerald-300';

                    div.className = `p-4 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${borderCls}`;

                    const isSameTag = eq.is_current ? `<span class="px-2 py-0.5 bg-indigo-600 text-white text-[10px] font-bold rounded">Aranan İlaç</span>` : '';
                    const bestTag = isBest ? `<span class="px-2 py-0.5 bg-amber-500 text-slate-950 text-[10px] font-black rounded"><i class="fa-solid fa-trophy mr-1"></i>EN KÂRLI MUADİL</span>` : '';
                    const profitTag = (!eq.is_current && karFarki > 0) ? `<span class="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded">+${karFarki.toFixed(2)} ₺ Kâr Avantajı</span>` : '';

                    const mName = eq.ad || eq.urun_adi || '';
                    const safeName = mName.replace(/'/g, "\\'");
                    const psfVal = eq.psf || eq.etiket_fiyati || 0;
                    const ksfVal = eq.ksf || eq.kamu_fiyati || (psfVal > 0 ? psfVal * (1 - ((eq.kamu_iskontosu || 0) / 100.0)) : 0);
                    const netKdvli = eq.net_birim_maliyet_kdvli || eq.birim_maliyet_kdvli || 0;
                    const kamuKari = (eq.kamu_kari !== undefined && eq.kamu_kari !== null) ? eq.kamu_kari : (ksfVal > 0 && netKdvli > 0 ? (ksfVal - netKdvli) : 0);
                    const eldenKari = (eq.perakende_kari !== undefined && eq.perakende_kari !== null) ? eq.perakende_kari : (psfVal > 0 && netKdvli > 0 ? (psfVal - netKdvli) : 0);

                    const rawFullMf = (eq.mf && eq.mf !== 'YOK' && eq.mf !== '-') ? eq.mf : ((eq.en_iyi_mf && eq.en_iyi_mf !== 'YOK' && eq.en_iyi_mf !== '-') ? eq.en_iyi_mf : null);
                    const kademeler = eq.kademeler || [];
                    const mfBadgeHtml = rawFullMf
                        ? `<span class="inline-flex items-center px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 font-black text-[11px]"><i class="fa-solid fa-fire text-amber-600 mr-1"></i>Canlı MF: ${rawFullMf} ${eq.depo ? `(${eq.depo})` : ''}</span>`
                        : (eq.gecmis_mf_var && eq.gecmis_mf_kisa ? `<span class="inline-flex items-center px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 border border-indigo-200 font-bold text-[11px]">Son Fatura MF: ${eq.gecmis_mf_kisa}</span>` : `<span class="text-slate-400">MF: YOK</span>`);

                    const kademelerHtml = kademeler.length > 0 ? `
                        <div class="flex flex-wrap gap-1.5 mt-1.5">
                            ${kademeler.map(k => {
                                const kKdvli = k.net_birim_maliyet_kdvli || k.birim_maliyet_kdvli || 0;
                                return `<span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-50 text-amber-900 border border-amber-300">${k.mf_text} → ${kKdvli.toFixed(2)} ₺ (KDV Dahil)</span>`;
                            }).join('')}
                        </div>
                    ` : '';

                    div.innerHTML = `
                        <div class="flex items-start space-x-3">
                            <div class="w-9 h-9 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center text-sm font-bold shrink-0 mt-0.5">
                                <i class="fa-solid fa-pills"></i>
                            </div>
                            <div>
                                <div class="flex flex-wrap items-center gap-1.5">
                                    <span class="text-sm font-bold text-slate-900">${mName}</span>
                                    ${bestTag}
                                    ${isSameTag}
                                    ${profitTag}
                                </div>
                                <div class="text-[11px] text-slate-500 mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1">
                                    <span>Barkod: <strong class="font-mono text-slate-700">${eq.barkod || eq.kod}</strong></span>
                                    <span>•</span>
                                    <span>Raf Stoğu: <strong class="${eq.stok > 0 ? 'text-emerald-600 font-bold' : 'text-slate-500'}">${eq.stok || 0} Kutu</strong></span>
                                    <span>•</span>
                                    <span>30 Gün Satış: <strong class="text-cyan-700 font-bold">${eq.cikis_30gun || 0} Kutu</strong></span>
                                    <span>•</span>
                                    <span>PSF: <strong class="text-slate-800">${psfVal > 0 ? psfVal.toFixed(2) + ' ₺' : '-'}</strong></span>
                                    ${ksfVal > 0 ? `<span>•</span><span>KSF: <strong class="text-indigo-700">${ksfVal.toFixed(2)} ₺</strong></span>` : ''}
                                    ${netKdvli > 0 ? `<span>•</span><span>Net Alış (KDV'li): <strong class="text-slate-900">${netKdvli.toFixed(2)} ₺</strong></span>` : ''}
                                    <span>•</span>
                                    <span>SGK Kârı: <strong class="${kamuKari >= 0 ? 'text-blue-600' : 'text-red-600'} font-bold">${kamuKari >= 0 ? '+' : ''}${kamuKari.toFixed(2)} ₺</strong></span>
                                    <span>•</span>
                                    <span>Elden Kârı: <strong class="text-emerald-600 font-bold">${eldenKari >= 0 ? '+' : ''}${eldenKari.toFixed(2)} ₺</strong></span>
                                    <span>•</span>
                                    ${mfBadgeHtml}
                                    ${eq.vade ? `<span>•</span><span>Vade: <strong>${eq.vade}</strong></span>` : ''}
                                    ${eq.iskonto > 0 ? `<span>• İsk: <strong class="text-blue-600">%${eq.iskonto}</strong></span>` : ''}
                                </div>
                                ${kademelerHtml}
                            </div>
                        </div>
                        <div class="shrink-0 flex items-center space-x-2">
                            <button onclick="closeEsdegerModal(); selectAndSearch('${eq.barkod || eq.kod}', '${safeName}')" class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center space-x-1.5 shadow-sm shadow-emerald-200 cursor-pointer">
                                <i class="fa-solid fa-arrows-split-up-and-left text-[11px]"></i>
                                <span>Tüm Depolarda Karşılaştır</span>
                            </button>
                        </div>
                    `;
                    list.appendChild(div);
                });
            }

            renderModalItems(eqList);

            if (needsLiveRefresh && currentReport.barkod) {
                try {
                    const resp = await fetch(`/api/products/equivalents?barcode=${encodeURIComponent(currentReport.barkod)}`);
                    if (resp.ok) {
                        const json = await resp.json();
                        if (json && json.found && json.muadiller && json.muadiller.length > 0) {
                            currentReport.esdegerler = json.muadiller;
                            if (json.esdeger_kodu) currentReport.esdeger_kodu = json.esdeger_kodu;
                            if (json.en_karli_muadil) currentReport.en_karli_muadil = json.en_karli_muadil;
                            if (json.muadil_kar_avantaji !== undefined) currentReport.muadil_kar_avantaji = json.muadil_kar_avantaji;
                            kodEl.innerText = currentReport.esdeger_kodu ? `SGK Kodu: ${currentReport.esdeger_kodu}` : 'SGK Eşdeğer Grubu';
                            renderModalItems(json.muadiller);
                        }
                    }
                } catch (e) {}
            }
        }

        function closeEsdegerModal() {
            document.getElementById('esdegerModal').classList.add('hidden');
        }

        // Simülatör Fonksiyonları
        function setSimulatorQty(qty) {
            simQtyInput.value = qty;
            updateSimulator();
        }

        function onSimulatorChange() {
            updateSimulator();
        }

        let selectedRowIndex = null;

        function setSimWithTier(rowIndex, alinan, hediye) {
            selectedRowIndex = rowIndex;
            const targetQty = (parseInt(alinan) || 1) + (parseInt(hediye) || 0);
            const rowQty = document.getElementById(`qty_${rowIndex}`);
            if (rowQty) {
                rowQty.value = parseInt(alinan) || 1;
                rowQty.classList.add('ring-2', 'ring-emerald-500', 'bg-emerald-50');
                setTimeout(() => rowQty.classList.remove('ring-2', 'ring-emerald-500', 'bg-emerald-50'), 1500);
            }
            const qtyInput = document.getElementById('simQtyInput');
            if (qtyInput) qtyInput.value = targetQty;
            updateSimulator();
            const resultsBox = document.getElementById('simResultsBox');
            if (resultsBox && resultsBox.classList.contains('hidden')) {
                toggleMfDetails();
            }
        }

        function selectMfTierAnalysis(depoIndex, alinan, hediye, mfText) {
            setSimWithTier(depoIndex, alinan, hediye);
        }

        function updateSimulator() {
            if (!currentReport || !currentReport.sonuclar || currentReport.sonuclar.length === 0) return;

            const qtyInput = document.getElementById('simQtyInput');
            const qty = qtyInput ? (parseInt(qtyInput.value) || 1) : 1;
            let depoItem = null;
            if (selectedRowIndex !== null && currentReport.sonuclar[selectedRowIndex]) {
                depoItem = currentReport.sonuclar[selectedRowIndex];
            } else {
                depoItem = currentReport.sonuclar.find(s => s.depo === currentReport.en_avantajli_depo && Math.abs(s.net_birim_maliyet - currentReport.en_dusuk_maliyet) < 0.01) || currentReport.sonuclar[0];
            }

            if (!depoItem) return;

            const dsf = depoItem.depocu_satis_fiyati || 0;
            const kdvOrani = depoItem.kdv_orani || 10.0;
            const kdvMultiplier = 1.0 + (kdvOrani / 100.0);
            const iskMultiplier = 1.0 - ((depoItem.ticari_iskonto || 0.0) / 100.0);

            let paidBoxes = qty;
            let freeBoxes = 0;
            let totalReceived = qty;

            // MF Kademesi varsa hesapla
            let tierVolumeNetPrice = null;
            if (depoItem.kademeler && depoItem.kademeler.length > 0) {
                let bestKademe = null;
                for (let k of depoItem.kademeler) {
                    const lot = (k.alinan || 1) + (k.hediye || 0);
                    if (qty >= lot) {
                        bestKademe = k;
                    }
                }

                if (bestKademe) {
                    if (bestKademe.hediye > 0) {
                        const lotSize = bestKademe.alinan + bestKademe.hediye;
                        const fullLots = Math.floor(qty / lotSize);
                        const remainder = qty % lotSize;
                        paidBoxes = (fullLots * bestKademe.alinan) + remainder;
                        freeBoxes = fullLots * bestKademe.hediye;
                        totalReceived = paidBoxes + freeBoxes;
                    } else if (bestKademe.net_birim_maliyet && bestKademe.net_birim_maliyet > 0) {
                        tierVolumeNetPrice = bestKademe.net_birim_maliyet;
                    }
                }
            }

            const totalInvoiceNet = (tierVolumeNetPrice !== null) ? (paidBoxes * tierVolumeNetPrice) : (paidBoxes * dsf * iskMultiplier);
            const totalInvoiceKdvli = totalInvoiceNet * kdvMultiplier;
            const unitNet = totalReceived > 0 ? (totalInvoiceNet / totalReceived) : 0;
            const unitKdvli = unitNet * kdvMultiplier;

            const elPaid = document.getElementById('simPaidBoxes');
            if (elPaid) elPaid.innerText = `${paidBoxes} Kutu`;
            const elFree = document.getElementById('simFreeBoxes');
            if (elFree) elFree.innerText = freeBoxes > 0 ? `+${freeBoxes} Kutu` : `0 Kutu`;
            const elTotal = document.getElementById('simTotalBoxes');
            if (elTotal) elTotal.innerText = `${totalReceived} Kutu`;
            const elUnitNet = document.getElementById('simUnitNet');
            if (elUnitNet) elUnitNet.innerText = `${unitNet.toFixed(2)} ₺`;
            const elUnitKdv = document.getElementById('simUnitKdvli');
            if (elUnitKdv) elUnitKdv.innerText = `${unitKdvli.toFixed(2)} ₺`;
            const elTotalInv = document.getElementById('simTotalInvoice');
            if (elTotalInv) elTotalInv.innerText = `${totalInvoiceNet.toFixed(2)} ₺`;
            const elInvKdv = document.getElementById('simInvoiceKdvli');
            if (elInvKdv) elInvKdv.innerText = `KDV Dahil: ${totalInvoiceKdvli.toFixed(2)} ₺`;

            const elDepoNote = document.getElementById('simDepoNote');
            if (elDepoNote) elDepoNote.innerText = `Hesaplama ${depoItem.depo_adi} şartlarına göre (${depoItem.mf_metni}) yapılmıştır.`;
            const simMfTextEl = document.getElementById('simMfText');
            if (simMfTextEl) simMfTextEl.innerText = `${depoItem.depo_adi}: ${depoItem.mf_metni}`;

            selectedDepoForSim = depoItem.depo;
            const simBtn = document.getElementById('simAddToCartBtn');
            const simText = document.getElementById('simAddToCartText');
            if (simBtn && simText) {
                if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depoItem.depo)) {
                    simBtn.classList.add('opacity-50', 'cursor-not-allowed');
                    simBtn.disabled = true;
                    simText.innerText = `${depoItem.depo_adi} (Pazaryeri Portalı)`;
                } else {
                    simBtn.classList.remove('opacity-50', 'cursor-not-allowed');
                    simBtn.disabled = false;
                    simText.innerText = `${depoItem.depo_adi} Sepetine Ekle (${paidBoxes} Kutu)`;
                }
            }
        }

        // ================= Sepete Ekleme & Bildirimler =================
        function showToast(title, message, type = 'success') {
            const container = document.getElementById('toastContainer');
            if (!container) return;
            const toast = document.createElement('div');
            const isSuccess = type === 'success';
            const bgClass = isSuccess ? 'bg-emerald-600 text-white shadow-emerald-200' : 'bg-rose-600 text-white shadow-rose-200';
            const icon = isSuccess ? 'fa-circle-check' : 'fa-triangle-exclamation';

            toast.className = `${bgClass} pointer-events-auto flex items-start space-x-3 px-4 py-3 rounded-2xl shadow-xl transition-all duration-300 transform translate-y-[-20px] opacity-0 max-w-md`;
            toast.innerHTML = `
                <i class="fa-solid ${icon} text-lg mt-0.5 shrink-0"></i>
                <div class="flex-1 text-xs">
                    <div class="font-bold text-sm leading-tight">${title}</div>
                    <div class="mt-0.5 text-white/90 leading-relaxed">${message}</div>
                </div>
                <button onclick="this.parentElement.remove()" class="text-white/70 hover:text-white ml-2 cursor-pointer">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            `;
            container.appendChild(toast);
            setTimeout(() => {
                toast.classList.remove('translate-y-[-20px]', 'opacity-0');
            }, 10);
            setTimeout(() => {
                toast.classList.add('opacity-0', 'translate-y-[-10px]');
                setTimeout(() => toast.remove(), 300);
            }, 5000);
        }

        async function addToCart(depo, urunId, barkod, rowIndex, btn, explicitName = '') {
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depo)) {
                showToast('Bilgi', 'Ortak alım grubu ve pazaryeri siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const qtyInput = document.getElementById(`qty_${rowIndex}`);
            const miktar = parseInt(qtyInput ? qtyInput.value : 1) || 1;

            const originalContent = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1"></i>Ekleniyor...`;

            const prodName = explicitName || ((typeof currentReport !== 'undefined' && currentReport) ? (currentReport.urun_adi || currentReport.name || '') : '');
            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: urunId,
                        barkod: barkod,
                        miktar: miktar,
                        name: prodName
                    })
                });
                const result = await res.json();
                if (result.success) {
                    let extra = '';
                    if (result.sepet_no) extra += ` (Belge No: ${result.sepet_no})`;
                    if (result.sepet_tutari) extra += ` (Sepet Tutarı: ${result.sepet_tutari} ₺)`;
                    showToast('Sepete Eklendi', `${result.message || `${miktar} kutu başarıyla ${depo} sepetine eklendi!`}${extra}`, 'success');
                } else {
                    showToast('Hata', result.message || `${depo} sepetine eklenemedi.`, 'error');
                }
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalContent;
            }
        }

        // ================= TEKLİ SİPARİŞİ TAMAMLA & SONLANDIR =================
        function closeQuickFinalizeModal() {
            const modal = document.getElementById('quickFinalizeModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
        }

        async function quickFinalizeOrder(depo, urunId, barkod, rowIndex, urunAdi, unitPrice) {
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depo)) {
                showToast('Bilgi', 'Ortak alım grubu ve pazaryeri siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const qtyInput = document.getElementById(`qty_${rowIndex}`);
            const miktar = parseInt(qtyInput ? qtyInput.value : 1) || 1;
            const cleanUrunAdi = urunAdi || 'Ürün';

            const modal = document.getElementById('quickFinalizeModal');
            const badgeEl = document.getElementById('quickFinDepoBadge');
            const bodyEl = document.getElementById('quickFinBody');
            const footerEl = document.getElementById('quickFinFooter');

            if (!modal || !bodyEl || !footerEl) return;

            if (badgeEl) badgeEl.innerText = depo === 'SELCUK' ? 'Selçuk Ecza' : (depo === 'NEVZAT' ? 'Nevzat Ecza' : (depo === 'ALLIANCE' ? 'Alliance Healthcare' : (depo === 'ISKOOP' ? 'İSKOOP' : depo)));
            
            modal.classList.remove('hidden');
            modal.style.display = 'flex';

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-circle-notch fa-spin text-3xl text-amber-500 mb-3"></i>
                    <div class="font-extrabold text-slate-800 text-sm">Depo Sepeti Kontrol Ediliyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depo} sepet durumu ve mevcut siparişler sorgulanıyor...</div>
                </div>
            `;
            footerEl.innerHTML = `
                <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
            `;

            try {
                const res = await fetch('/api/cart/quick-finalize-check', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: urunId,
                        barkod: barkod,
                        miktar: miktar,
                        urun_adi: cleanUrunAdi
                    })
                });
                const checkData = await res.json();

                if (!checkData.success) {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-exclamation mr-1.5"></i>Sepet Sorgulanamadı</div>
                            <div>${checkData.message || 'Depo sepet bilgisi alınamadı.'}</div>
                        </div>
                    `;
                    return;
                }

                const totalEst = miktar * (unitPrice || 0);

                if (checkData.can_finalize_directly) {
                    // Sepette başka ürün YOK! Doğrudan sonlandırılabilir
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Ürün Özeti -->
                            <div class="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center justify-between">
                                <div class="pr-3">
                                    <div class="text-[11px] font-bold text-amber-800 uppercase tracking-wider mb-0.5"><i class="fa-solid fa-pills mr-1"></i>Sipariş Verilecek Ürün</div>
                                    <div class="text-base font-black text-slate-900 leading-snug">${cleanUrunAdi}</div>
                                    <div class="text-xs text-slate-500 mt-1">
                                        Birim Fiyat: <strong class="text-slate-800 font-mono">${(unitPrice || 0).toFixed(2)} ₺</strong> (KDV Dahil)
                                    </div>
                                </div>
                                <div class="text-right shrink-0 pl-3 border-l border-slate-100">
                                    <div class="text-[10px] text-slate-400 font-semibold uppercase">Miktar</div>
                                    <div class="text-2xl font-black text-amber-600 font-mono">${miktar} <span class="text-xs font-bold text-slate-500">Kutu</span></div>
                                    <div class="text-xs font-extrabold text-slate-700 mt-0.5 font-mono">~${totalEst.toFixed(2)} ₺</div>
                                </div>
                            </div>

                            <!-- Güvenlik Onayı -->
                            <div class="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start space-x-3">
                                <div class="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                                    <i class="fa-solid fa-shield-check text-sm"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-bold text-emerald-950 text-sm">Sepet Kontrolü Başarılı ✅</div>
                                    <div class="text-emerald-800 mt-0.5 leading-relaxed">
                                        ${checkData.item_count === 0 ? 'Depo sepetiniz şu an tamamen boş.' : 'Sepette sadece bu ürün yer alıyor.'}
                                        Onay verdiğinizde sipariş <strong>doğrudan ${depo} sistemine iletilip sonlandırılacaktır</strong>. Web arayüzüne gitmenize gerek kalmaz.
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;

                    footerEl.innerHTML = `
                        <div class="flex items-center justify-between w-full">
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
                            <div class="flex items-center space-x-2">
                                ${checkData.checkout_url ? `<a href="${checkData.checkout_url}" target="_blank" class="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1.5"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Sepeti İncele</span></a>` : ''}
                                <button type="button" id="btnExecuteFinalize" onclick="executeFinalize('${depo}', '${urunId}', '${barkod}', ${miktar}, false)" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md hover:shadow-lg transition flex items-center space-x-2 cursor-pointer">
                                    <i class="fa-solid fa-paper-plane text-xs"></i>
                                    <span>Evet, Siparişi Sonlandır (Depoya Gönder)</span>
                                </button>
                            </div>
                        </div>
                    `;
                } else {
                    // Sepette BAŞKA ÜRÜNLER VAR! Uyarı göster
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Dikkat Uyarısı -->
                            <div class="p-3.5 rounded-2xl bg-amber-50 border-2 border-amber-300 flex items-start space-x-3">
                                <div class="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 mt-0.5">
                                    <i class="fa-solid fa-triangle-exclamation text-sm"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-black text-amber-950 text-sm">Dikkat: Depo Sepetinde Başka Ürünler Var!</div>
                                    <div class="text-amber-900 mt-0.5 leading-relaxed">
                                        ${depo} sepetinizde önceden eklenmiş <strong>${checkData.item_count} farklı ürün</strong> bulunmaktadır (Toplam Tutar: <strong>${(checkData.total_amount || 0).toFixed(2)} ₺</strong>).
                                    </div>
                                </div>
                            </div>

                            <!-- Mevcut Ürünler Listesi -->
                            <div class="bg-white rounded-2xl border border-slate-200 p-3 max-h-40 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Sepetteki Mevcut Ürünler:</div>
                                ${(checkData.items || []).map(it => `
                                    <div class="flex items-center justify-between py-1 px-2.5 rounded-lg bg-slate-50 text-xs">
                                        <span class="font-medium text-slate-800 truncate mr-2">${it.ad}</span>
                                        <span class="font-extrabold text-slate-700 whitespace-nowrap">${it.miktar} Adet (${(it.tutar || 0).toFixed(2)} ₺)</span>
                                    </div>
                                `).join('')}
                            </div>

                            <!-- Eklenecek Yeni Ürün -->
                            <div class="p-3 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-between text-xs">
                                <div>
                                    <span class="text-indigo-600 font-bold uppercase text-[10px]">Şimdi Eklenecek Acil Ürün:</span>
                                    <div class="font-black text-slate-900">${cleanUrunAdi} (${miktar} Kutu)</div>
                                </div>
                                <div class="font-black text-indigo-700 text-sm font-mono">+${totalEst.toFixed(2)} ₺</div>
                            </div>
                        </div>
                    `;

                    const safeCleanName = cleanUrunAdi.replace(/'/g, "\\'");
                    footerEl.innerHTML = `
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition w-full sm:w-auto cursor-pointer">Vazgeç</button>
                            <div class="flex flex-wrap items-center gap-2 justify-end w-full sm:w-auto">
                                ${checkData.checkout_url ? `<a href="${checkData.checkout_url}" target="_blank" class="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Sepeti İncele</span></a>` : ''}
                                <button type="button" onclick="onlyClearCart('${depo}')" class="px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-300 hover:border-rose-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer" title="Sepetteki tüm ürünleri boşaltır (Sipariş göndermez)">
                                    <i class="fa-solid fa-trash-can text-[10px] text-rose-500"></i>
                                    <span>Sadece Sepeti Boşalt</span>
                                </button>
                                <button type="button" onclick="clearCartAndFinalize('${depo}', '${urunId}', '${barkod}', ${miktar}, '${safeCleanName}', ${unitPrice})" class="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer" title="Sepetteki diğer ürünleri temizler ve sadece bu acil ürünü gönderir">
                                    <i class="fa-solid fa-broom text-[10px]"></i>
                                    <span>Sepeti Boşalt & Sadece Bunu Gönder</span>
                                </button>
                                <button type="button" onclick="executeFinalize('${depo}', '${urunId}', '${barkod}', ${miktar}, true)" class="px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white rounded-xl text-xs font-black shadow-sm transition flex items-center space-x-1.5 cursor-pointer" title="Mevcut tüm sepeti bu ürünle birlikte onaylar">
                                    <i class="fa-solid fa-paper-plane text-[10px]"></i>
                                    <span>Tüm Sepeti Onayla & Gönder</span>
                                </button>
                            </div>
                        </div>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
            }
        }

        async function executeFinalize(depo, urunId, barkod, miktar, force) {
            const bodyEl = document.getElementById('quickFinBody');
            const footerEl = document.getElementById('quickFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-spinner fa-spin text-4xl text-emerald-500 mb-3"></i>
                    <div class="text-base font-extrabold text-slate-800">Sipariş Depoya İletiliyor...</div>
                    <div class="text-xs text-slate-500 mt-1">${depo} sistemine bağlanılıyor ve sipariş doğrudan onaylanıyor...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            try {
                const res = await fetch('/api/cart/finalize', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: urunId,
                        barkod: barkod || (currentReport && currentReport.barkod) || '',
                        urun_adi: (currentReport && currentReport.urun_adi) || '',
                        miktar: miktar,
                        force: force
                    })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-emerald-500/20">
                                <i class="fa-solid fa-circle-check animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sipariş Başarıyla Sonlandırıldı! 🎉</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message}</p>
                            </div>
                            ${result.order_info ? `
                                <div class="p-3 rounded-2xl bg-slate-100 border border-slate-200 text-xs font-mono font-bold text-slate-700 max-w-sm mx-auto">
                                    ${result.order_info}
                                </div>
                            ` : ''}
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            ${result.portal_url ? `<a href="${result.portal_url}" target="_blank" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-sm"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>WebDepo'da İncele</span></a>` : ''}
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Tamam</button>
                        </div>
                    `;
                    showToast('Sipariş Sonlandırıldı', result.message, 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sipariş Onaylanamadı</div>
                            <div class="leading-relaxed">${result.message || 'Bilinmeyen bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        async function clearCartAndFinalize(depo, urunId, barkod, miktar, urunAdi, unitPrice) {
            const bodyEl = document.getElementById('quickFinBody');
            if (bodyEl) {
                bodyEl.innerHTML = `
                    <div class="text-center py-8">
                        <i class="fa-solid fa-spinner fa-spin text-3xl text-rose-500 mb-3"></i>
                        <div class="font-bold text-slate-800 text-sm">Sepet Temizleniyor...</div>
                        <div class="text-xs text-slate-400 mt-1">Önceki ürünler siliniyor, ardından acil ürün eklenecek...</div>
                    </div>
                `;
            }
            try {
                await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo })
                });
                await executeFinalize(depo, urunId, barkod, miktar, true);
            } catch (e) {
                showToast('Hata', 'Sepet temizlenirken hata: ' + e.message, 'error');
            }
        }

        async function onlyClearCart(depo) {
            const bodyEl = document.getElementById('quickFinBody');
            const footerEl = document.getElementById('quickFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-8">
                    <i class="fa-solid fa-spinner fa-spin text-3xl text-rose-500 mb-3"></i>
                    <div class="font-bold text-slate-800 text-sm">Sepet Boşaltılıyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depo} sepetindeki tüm ürünler siliniyor...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            try {
                const res = await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-rose-500/20">
                                <i class="fa-solid fa-trash-can animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sepetiniz Başarıyla Boşaltıldı 🗑️</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message || `${depo} sepetindeki tüm ürünler temizlendi.`}</p>
                                <p class="text-[11px] text-slate-400 mt-1.5 font-bold">Herhangi bir sipariş onaylanmamış veya iletilmemiştir.</p>
                            </div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                        </div>
                    `;
                    showToast('Sepet Boşaltıldı', `${depo} sepetiniz temizlendi (Sipariş verilmedi).`, 'info');
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sepet Temizlenemedi</div>
                            <div class="leading-relaxed">${result.message || 'Sepet boşaltılırken bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        // ================= GÜNLÜK TOPLU SİPARİŞİ SONLANDIRMA FONKSİYONLARI =================
        function closeBulkFinalizeModal() {
            const modal = document.getElementById('bulkFinalizeModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
        }

        async function openBulkFinalizeFlow(customDepo) {
            const depo = customDepo || (window.currentBulkState && window.currentBulkState.depo) || 'SELCUK';
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depo)) {
                showToast('Bilgi', 'Pazaryeri ve ortak alım siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const modal = document.getElementById('bulkFinalizeModal');
            const badgeEl = document.getElementById('bulkFinDepoBadge');
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');

            if (!modal || !bodyEl || !footerEl) return;

            const depoNames = {
                'SELCUK': 'Selçuk Ecza',
                'NEVZAT': 'Nevzat Ecza',
                'ALLIANCE': 'Alliance Healthcare',
                'ISKOOP': 'İSKOOP E-Şube'
            };
            if (badgeEl) badgeEl.innerText = depoNames[depo] || depo;

            modal.classList.remove('hidden');
            modal.style.display = 'flex';

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-circle-notch fa-spin text-3xl text-emerald-500 mb-3"></i>
                    <div class="font-extrabold text-slate-800 text-sm">Depo Sepeti ve Sipariş Listesi Kontrol Ediliyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depoNames[depo] || depo} canlı sepetindeki ürünler bugünkü listenizle karşılaştırılıyor...</div>
                </div>
            `;
            footerEl.innerHTML = `
                <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
            `;

            // Bugünkü siparişte ilgili depoya eklenen kalemleri al
            const addedItems = (window.currentBulkState && window.currentBulkState.allResults)
                ? window.currentBulkState.allResults
                    .filter(r => r.status === 'ADDED' && (!r.assigned_depo || r.assigned_depo === depo))
                    .map(it => ({
                        barcode: it.barcode,
                        name: it.name,
                        miktar: it.miktar,
                        urun_id: it.urun_id || ''
                    }))
                : [];

            try {
                const res = await fetch('/api/cart/bulk-finalize-check', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        items: addedItems
                    })
                });
                const checkData = await res.json();

                if (!checkData.success) {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-exclamation mr-1.5"></i>Sepet Sorgulanamadı</div>
                            <div>${checkData.message || 'Depo sepet bilgisi alınamadı.'}</div>
                        </div>
                    `;
                    return;
                }

                if (checkData.cart_count === 0) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-8 space-y-3">
                            <div class="w-14 h-14 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto text-2xl">
                                <i class="fa-solid fa-cart-shopping"></i>
                            </div>
                            <div class="font-black text-slate-900 text-sm">Sepette Ürün Bulunamadı</div>
                            <p class="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                                ${depoNames[depo] || depo} sepetiniz şu anda boş görünüyor. Önce günlük sipariş listesinden ürünleri sepete aktarınız.
                            </p>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                    return;
                }

                if (!checkData.has_extra_items) {
                    // Sepette sadece bugünkü sipariş ürünleri var! Doğrudan onaylanabilir
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Başarılı Eşleşme Bilgisi -->
                            <div class="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start space-x-3.5">
                                <div class="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                                    <i class="fa-solid fa-shield-check text-base"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-extrabold text-emerald-950 text-sm">Sepet Kontrolü Başarılı ✅</div>
                                    <div class="text-emerald-800 mt-1 leading-relaxed">
                                        ${depoNames[depo] || depo} sepetinizde sadece bugünkü siparişinize ait <strong>${checkData.cart_count} kalem ürün</strong> yer alıyor.
                                        Sepette yabancı veya önceden kalmış farklı bir ürün bulunmamaktadır.
                                    </div>
                                </div>
                            </div>

                            <!-- Sepet Tutarı ve Kalem Sayısı Kartı -->
                            <div class="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center justify-between">
                                <div>
                                    <div class="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Onaylanacak Günlük Sipariş</div>
                                    <div class="text-base font-black text-slate-900 mt-0.5">${checkData.cart_count} Kalem İlaç</div>
                                </div>
                                <div class="text-right">
                                    <div class="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Toplam Sepet Tutarı</div>
                                    <div class="text-xl font-black text-emerald-600 font-mono mt-0.5">${(checkData.total_amount || 0).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺</div>
                                </div>
                            </div>

                            <!-- Sepetteki Ürünlerin Listesi -->
                            <div class="bg-white rounded-2xl border border-slate-200 p-3 max-h-56 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Sepetteki Ürünler (${checkData.cart_count} Kalem):</div>
                                ${(checkData.all_items || []).map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-3 rounded-xl bg-slate-50 text-xs">
                                        <span class="font-semibold text-slate-800 truncate mr-2">${it.ad || it.urun_adi || 'Ürün'}</span>
                                        <span class="font-extrabold text-slate-700 whitespace-nowrap font-mono">${it.miktar} Kutu ${(it.tutar ? `(${it.tutar.toFixed(2)} ₺)` : '')}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `;

                    footerEl.innerHTML = `
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer w-full sm:w-auto">Vazgeç</button>
                            <div class="flex flex-wrap items-center gap-2 justify-end w-full sm:w-auto">
                                ${checkData.checkout_url ? `<a href="${checkData.checkout_url}" target="_blank" class="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Sepeti İncele</span></a>` : ''}
                                <button type="button" onclick="onlyClearCartFromBulk('${depo}')" class="px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-300 hover:border-rose-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer" title="Sepetteki tüm ürünleri boşaltır (Sipariş göndermez)">
                                    <i class="fa-solid fa-trash-can text-[10px] text-rose-500"></i>
                                    <span>Sadece Sepeti Boşalt</span>
                                </button>
                                <button type="button" onclick="executeBulkFinalizeSubmit('${depo}', true)" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md hover:shadow-lg transition flex items-center space-x-2 cursor-pointer">
                                    <i class="fa-solid fa-paper-plane text-xs"></i>
                                    <span>Evet, Günlük Siparişi Sonlandır (Depoya Gönder)</span>
                                </button>
                            </div>
                        </div>
                    `;
                } else {
                    // Sepette FARKLI / ÖNCEDEN EKLENMİŞ ÜRÜNLER VAR!
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Dikkat Uyarısı -->
                            <div class="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 flex items-start space-x-3.5 shadow-xs">
                                <div class="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 mt-0.5">
                                    <i class="fa-solid fa-triangle-exclamation text-base"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-black text-amber-950 text-sm">Dikkat: Depo Sepetinde Farklı / Önceden Eklenmiş Ürünler Var!</div>
                                    <div class="text-amber-900 mt-1 leading-relaxed">
                                        ${depoNames[depo] || depo} sepetinizde bugünkü sipariş listeniz dışında <strong>${checkData.extra_count} farklı ürün</strong> tespit edildi.
                                        Sepet Toplamı: <strong>${(checkData.total_amount || 0).toFixed(2)} ₺</strong> (Farklı Ürünler Tutarı: <strong>${(checkData.extra_total || 0).toFixed(2)} ₺</strong>).
                                    </div>
                                </div>
                            </div>

                            <!-- Farklı / Önceden Eklenmiş Ürünler Listesi -->
                            <div class="bg-rose-50/60 rounded-2xl border border-rose-200 p-3 max-h-44 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-extrabold text-rose-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-circle-exclamation mr-1 text-rose-500"></i>Sepetteki Farklı / Önceden Eklenmiş Ürünler (${checkData.extra_count} Kalem):</span>
                                    <span class="font-mono text-rose-700">${(checkData.extra_total || 0).toFixed(2)} ₺</span>
                                </div>
                                ${(checkData.extra_items || []).map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-3 rounded-xl bg-white border border-rose-100 text-xs shadow-2xs">
                                        <span class="font-medium text-slate-800 truncate mr-2">${it.ad || it.urun_adi || 'Ürün'}</span>
                                        <span class="font-extrabold text-rose-700 whitespace-nowrap font-mono">${it.miktar} Kutu ${(it.tutar ? `(${it.tutar.toFixed(2)} ₺)` : '')}</span>
                                    </div>
                                `).join('')}
                            </div>

                            <!-- Bugünkü Günlük Sipariş Kalemleri -->
                            <div class="bg-emerald-50/60 rounded-2xl border border-emerald-200 p-3 max-h-36 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider mb-1">
                                    <i class="fa-solid fa-circle-check mr-1 text-emerald-500"></i>Bugünkü Günlük Sipariş Kalemleri (${checkData.matched_count} Kalem):
                                </div>
                                ${(checkData.matched_items || []).map(it => `
                                    <div class="flex items-center justify-between py-1 px-2.5 rounded-lg bg-white border border-emerald-100 text-xs">
                                        <span class="font-medium text-slate-700 truncate mr-2">${it.ad || it.urun_adi || 'Ürün'}</span>
                                        <span class="font-bold text-emerald-700 whitespace-nowrap font-mono">${it.miktar} Kutu</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `;

                    footerEl.innerHTML = `
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition w-full sm:w-auto cursor-pointer">Vazgeç</button>
                            <div class="flex flex-wrap items-center gap-2 justify-end w-full sm:w-auto">
                                ${checkData.checkout_url ? `<a href="${checkData.checkout_url}" target="_blank" class="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Sepeti İncele</span></a>` : ''}
                                <button type="button" onclick="onlyClearCartFromBulk('${depo}')" class="px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-300 hover:border-rose-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer" title="Sepetteki tüm ürünleri siler (Sipariş verilmez)">
                                    <i class="fa-solid fa-trash-can text-[10px] text-rose-500"></i>
                                    <span>Sadece Sepeti Boşalt</span>
                                </button>
                                <button type="button" onclick="cleanCartAndSubmitBulk('${depo}')" class="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer shadow-2xs" title="Sepetteki diğer yabancı ürünleri çıkarır ve yalnızca bugünkü günlük siparişi depoya iletir">
                                    <i class="fa-solid fa-broom text-[10px]"></i>
                                    <span>Farklı Ürünleri Çıkar & Sadece Günlük Siparişi Onayla</span>
                                </button>
                                <button type="button" onclick="executeBulkFinalizeSubmit('${depo}', true)" class="px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white rounded-xl text-xs font-black shadow-sm transition flex items-center space-x-1.5 cursor-pointer" title="Mevcut tüm sepeti bu ürünlerle birlikte onaylar">
                                    <i class="fa-solid fa-paper-plane text-[10px]"></i>
                                    <span>Tüm Sepeti Beraber Onayla & Gönder</span>
                                </button>
                            </div>
                        </div>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
            }
        }

        async function executeBulkFinalizeSubmit(depo, force) {
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-spinner fa-spin text-4xl text-emerald-500 mb-3"></i>
                    <div class="font-black text-slate-800 text-base">Sipariş Depoya İletiliyor ve Sonlandırılıyor...</div>
                    <div class="text-xs text-slate-500 mt-1">${depo} B2B sistemi üzerinde sipariş onaylanıyor, lütfen bekleyiniz...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            const addedItems = (window.currentBulkState && window.currentBulkState.allResults)
                ? window.currentBulkState.allResults
                    .filter(r => r.status === 'ADDED' && (!r.assigned_depo || r.assigned_depo === depo))
                    .map(it => ({
                        barcode: it.barcode,
                        name: it.name,
                        miktar: it.miktar,
                        urun_id: it.urun_id || ''
                    }))
                : [];

            try {
                const res = await fetch('/api/cart/finalize', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: '',
                        barkod: '',
                        miktar: 1,
                        force: force,
                        items: addedItems
                    })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-8 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-emerald-500/20">
                                <i class="fa-solid fa-check animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Günlük Sipariş Başarıyla İletildi! 🎉</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message || `${depo} siparişiniz sisteme kaydedildi.`}</p>
                                ${result.order_info ? `<div class="mt-2.5 inline-block px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-mono font-bold">${result.order_info}</div>` : ''}
                            </div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            ${result.portal_url ? `<a href="${result.portal_url}" target="_blank" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-sm"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Depo Panelinde İncele</span></a>` : ''}
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Tamam</button>
                        </div>
                    `;
                    showToast('Sipariş Sonlandırıldı', result.message, 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sipariş Onaylanamadı</div>
                            <div class="leading-relaxed">${result.message || 'Bilinmeyen bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        async function cleanCartAndSubmitBulk(depo) {
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-spinner fa-spin text-4xl text-rose-500 mb-3"></i>
                    <div class="font-black text-slate-800 text-base">Farklı Ürünler Temizleniyor & Günlük Sipariş Hazırlanıyor...</div>
                    <div class="text-xs text-slate-500 mt-1">Önceki yabancı ürünler sepetten çıkarılıyor, ardından sadece bugünkü siparişiniz eklenip depoya gönderilecek...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            const addedItems = (window.currentBulkState && window.currentBulkState.allResults)
                ? window.currentBulkState.allResults
                    .filter(r => r.status === 'ADDED' && (!r.assigned_depo || r.assigned_depo === depo))
                    .map(it => ({
                        barcode: it.barcode,
                        name: it.name,
                        miktar: it.miktar,
                        urun_id: it.urun_id || ''
                    }))
                : [];

            try {
                const res = await fetch('/api/cart/bulk-finalize-clean-submit', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        items: addedItems
                    })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-8 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-emerald-500/20">
                                <i class="fa-solid fa-check animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sadece Günlük Sipariş Başarıyla İletildi! 🎉</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">Farklı ürünler sepetten arındırıldı ve yalnızca bugünkü siparişiniz depoya aktarılıp onaylandı.</p>
                                ${result.order_info ? `<div class="mt-2.5 inline-block px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-mono font-bold">${result.order_info}</div>` : ''}
                            </div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            ${result.portal_url ? `<a href="${result.portal_url}" target="_blank" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-sm"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Depo Panelinde İncele</span></a>` : ''}
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Tamam</button>
                        </div>
                    `;
                    showToast('Sipariş Sonlandırıldı', result.message || 'Farklı ürünler çıkarılarak sipariş onaylandı.', 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>İşlem Tamamlanamadı</div>
                            <div class="leading-relaxed">${result.message || 'Sipariş iletilirken bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        async function onlyClearCartFromBulk(depo) {
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-8">
                    <i class="fa-solid fa-spinner fa-spin text-3xl text-rose-500 mb-3"></i>
                    <div class="font-bold text-slate-800 text-sm">Sepet Boşaltılıyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depo} sepetindeki tüm ürünler siliniyor...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            try {
                const res = await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-rose-500/20">
                                <i class="fa-solid fa-trash-can animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sepetiniz Başarıyla Boşaltıldı 🗑️</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message || `${depo} sepetindeki tüm ürünler temizlendi.`}</p>
                                <p class="text-[11px] text-slate-400 mt-1.5 font-bold">Herhangi bir sipariş onaylanmamış veya iletilmemiştir.</p>
                            </div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                        </div>
                    `;
                    showToast('Sepet Boşaltıldı', `${depo} sepetiniz temizlendi (Sipariş verilmedi).`, 'info');
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sepet Temizlenemedi</div>
                            <div class="leading-relaxed">${result.message || 'Sepet boşaltılırken bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }


        async function addSimulatedToCart(btn) {

            if (!currentReport || !selectedDepoForSim) return;
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(selectedDepoForSim)) {
                showToast('Bilgi', 'Pazaryeri ve ortak alım siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const miktar = parseInt(simQtyInput.value) || 1;
            const targetItem = currentReport.sonuclar.find(s => s.depo === selectedDepoForSim) || currentReport.sonuclar[0];
            const urunId = targetItem ? (targetItem.urun_id || targetItem.barkod) : currentReport.barkod;
            const barkod = currentReport.barkod;

            const originalContent = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1"></i>Sepete Ekleniyor...`;

            const prodName = (targetItem && (targetItem.urun_adi || targetItem.name)) || ((typeof currentReport !== 'undefined' && currentReport) ? (currentReport.urun_adi || currentReport.name || '') : '');
            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: selectedDepoForSim,
                        urun_id: urunId,
                        barkod: barkod,
                        miktar: miktar,
                        name: prodName
                    })
                });
                const result = await res.json();
                if (result.success) {
                    let extra = '';
                    if (result.sepet_no) extra += ` (Belge No: ${result.sepet_no})`;
                    if (result.sepet_tutari) extra += ` (Sepet Tutarı: ${result.sepet_tutari} ₺)`;
                    showToast('Simülasyon Sepete Eklendi', `${result.message || `${miktar} kutu ${selectedDepoForSim} sepetine taslak olarak eklendi.`}${extra}`, 'success');
                } else {
                    showToast('Hata', result.message || 'Sepete ekleme başarısız oldu.', 'error');
                }
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalContent;
            }
        }

        // ================= Pazaryeri (Farmazon & Ecza1) Teklif Akordiyonu =================
        function toggleOffersRow(index) {
            const row = document.getElementById(`offersRow_${index}`);
            const chevron = document.getElementById(`offersChevron_${index}`);
            if (!row) return;
            if (row.classList.contains('hidden')) {
                row.classList.remove('hidden');
                if (chevron) chevron.style.transform = 'rotate(180deg)';
            } else {
                row.classList.add('hidden');
                if (chevron) chevron.style.transform = 'rotate(0deg)';
            }
        }

        // ================= Ayarlar & Şifre Yönetimi =================
        function togglePasswordVisibility(inputId, btn) {
            const input = document.getElementById(inputId);
            const icon = btn.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fa-solid fa-eye-slash text-slate-700';
            } else {
                input.type = 'password';
                icon.className = 'fa-solid fa-eye text-slate-400';
            }
        }

        // ================= Ayarlar Tab & TRIA Oracle Entegrasyonu (EdaPrim Stili) =================
        // ================= Ayarlar Tab & TRIA Oracle Entegrasyonu (EdaPrim Stili) =================
        function switchSettingsTab(tabName) {
            const btnBotanik = document.getElementById('tabBtnBotanik');
            const btnTria = document.getElementById('tabBtnTria');
            const btnTebeos = document.getElementById('tabBtnTebeos');
            const btnDepolar = document.getElementById('tabBtnDepolar');
            const btnKatalog = document.getElementById('tabBtnKatalog');
            const btnDermo = document.getElementById('tabBtnDermo');
            const btnGuncelleme = document.getElementById('tabBtnGuncelleme');
            const contentBotanik = document.getElementById('tabContentBotanik');
            const contentTria = document.getElementById('tabContentTria');
            const contentTebeos = document.getElementById('tabContentTebeos');
            const contentDepolar = document.getElementById('tabContentDepolar');
            const contentKatalog = document.getElementById('tabContentKatalog');
            const contentDermo = document.getElementById('tabContentDermo');
            const contentGuncelleme = document.getElementById('tabContentGuncelleme');
            const modalTitle = document.getElementById('settingsModalTitle');
            const modalDesc = document.getElementById('settingsModalDesc');
            const modalIcon = document.getElementById('settingsModalIcon');

            // Hepsini pasife çek
            [btnBotanik, btnTria, btnTebeos, btnDepolar, btnKatalog, btnDermo, btnGuncelleme].forEach(b => {
                if (b) b.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0';
            });
            if (contentBotanik) contentBotanik.classList.add('hidden');
            if (contentTria) contentTria.classList.add('hidden');
            if (contentTebeos) contentTebeos.classList.add('hidden');
            if (contentDepolar) contentDepolar.classList.add('hidden');
            if (contentKatalog) contentKatalog.classList.add('hidden');
            if (contentDermo) contentDermo.classList.add('hidden');
            if (contentGuncelleme) contentGuncelleme.classList.add('hidden');

            if (tabName === 'botanik') {
                if (btnBotanik) btnBotanik.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-emerald-600 text-emerald-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentBotanik) contentBotanik.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'Botanik Eczane Otomasyonu (MS SQL) Bağlantı & Şifre Ayarları';
                if (modalDesc) modalDesc.innerText = 'Botanik SQL Server adı, veritabanı adı, kullanıcı ve şifresini buradan yapılandırıp canlı ping testi yapabilirsiniz.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-leaf text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400';
                }
            } else if (tabName === 'tria') {
                if (btnTria) btnTria.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-amber-600 text-amber-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentTria) contentTria.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'TRIA Eczane Veritabanı (Oracle) Bağlantı & Şifre Ayarları';
                if (modalDesc) modalDesc.innerText = 'Oracle sunucu IP, port, şema adı ve şifresini buradan yapılandırıp canlı ping testi yapabilirsiniz.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-database text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400';
                }
            } else if (tabName === 'tebeos') {
                if (btnTebeos) btnTebeos.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-sky-600 text-sky-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentTebeos) contentTebeos.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'TEBEOS Eczane Veritabanı (PostgreSQL) Bağlantı & Şifre Ayarları';
                if (modalDesc) modalDesc.innerText = 'TEBEOS PostgreSQL sunucu IP (Port 5454), veritabanı adı ve şifresini buradan yapılandırıp canlı ping testi yapabilirsiniz.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-mortar-pestle text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-400';
                }
            } else if (tabName === 'katalog') {
                if (btnKatalog) btnKatalog.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-indigo-600 text-indigo-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentKatalog) contentKatalog.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'Ürün Kataloğu & Çoklu Barkod Yönetimi';
                if (modalDesc) modalDesc.innerText = 'Botanik, TRIA ve TEBEOS otomasyonundaki çoklu barkodları güncelleyebilir veya özel Excel ürün listesi yükleyebilirsiniz.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-barcode text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-400';
                }
                fetchCatalogStats();
            } else if (tabName === 'dermo') {
                if (btnDermo) btnDermo.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-pink-600 text-pink-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentDermo) contentDermo.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'Dermokozmetik & OTC Barkod Onarım Sihirbazı';
                if (modalDesc) modalDesc.innerText = 'Botanik veritabanındaki sahte/promosyon barkodları tespit edip gerçek üretici EAN barkodlarını ek barkod olarak ekler.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-pink-500/20 border border-pink-400/30 flex items-center justify-center text-pink-400';
                }
            } else if (tabName === 'guncelleme') {
                if (btnGuncelleme) btnGuncelleme.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-cyan-600 text-cyan-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentGuncelleme) contentGuncelleme.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'Otomatik Güncelleme & Lisans Yönetimi';
                if (modalDesc) modalDesc.innerText = 'Programın sürümünü ve kurumsal lisans durumunu kontrol edebilir, tek tıkla en son güncellemeleri yükleyebilirsiniz.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-cloud-arrow-down text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-400';
                }
                checkAppUpdate(false);
                loadLicenseStatus();
                loadGithubPortalConfig();
            } else {
                if (btnDepolar) btnDepolar.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-emerald-600 text-emerald-800 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentDepolar) contentDepolar.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'Ecza Depoları & Pazaryeri Giriş Bilgileri';
                if (modalDesc) modalDesc.innerText = 'Alliance, Selçuk, Nevzat, İSKOOP, Ecza1 ve Farmazon resmi B2B giriş şifrelerinizi yönetin.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-truck-ramp-box text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400';
                }
            }
        }

        // ================= Otomatik Güncelleme & Lisans Yönetimi =================
        let lastCheckedUpdate = null;

        async function loadGithubPortalConfig() {
            try {
                const res = await fetch('/api/github-portal/config');
                const data = await res.json();
                const mInput = document.getElementById('cfg_update_manifest_url');
                if (mInput && data.manifest_url) mInput.value = data.manifest_url;
                const ownerEl = document.getElementById('ghPortalOwner');
                if (ownerEl && data.owner) ownerEl.value = data.owner;
                const repoEl = document.getElementById('ghPortalRepo');
                if (repoEl && data.repo) repoEl.value = data.repo;
                const verEl = document.getElementById('ghPortalNewVersion');
                if (verEl && data.next_version) verEl.value = data.next_version;
                const badgeEl = document.getElementById('ghPortalStatusBadge');
                const tokenEl = document.getElementById('ghPortalToken');
                if (data.has_token) {
                    if (badgeEl) {
                        badgeEl.innerText = 'GITHUB BAĞLI ✓';
                        badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30';
                    }
                    if (tokenEl) tokenEl.placeholder = `Kayıtlı (${data.token_preview})`;
                }
            } catch (e) {}
        }

        async function saveManifestUrlConfig() {
            const mInput = document.getElementById('cfg_update_manifest_url');
            const urlVal = (mInput?.value || '').trim();
            if (!urlVal) {
                showToast('Uyarı', 'Lütfen geçerli bir GitHub Manifest URL girin.', 'error');
                return;
            }
            try {
                const res = await fetch('/api/update/config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ manifest_url: urlVal, auto_update: true })
                });
                const data = await res.json();
                if (data.success) {
                    if (mInput && data.manifest_url) mInput.value = data.manifest_url;
                    showToast('Kaydedildi', 'Canlı güncelleme Manifest URL adresi güncellendi.', 'success');
                    checkAppUpdate(true);
                } else {
                    showToast('Hata', data.message || 'Kaydedilemedi.', 'error');
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function verifyAndSetupGithubPortal() {
            const btn = document.getElementById('btnVerifyGhPortal');
            const resBox = document.getElementById('ghPortalResultText');
            const badgeEl = document.getElementById('ghPortalStatusBadge');
            const token = (document.getElementById('ghPortalToken')?.value || '').trim();
            const owner = (document.getElementById('ghPortalOwner')?.value || '').trim();
            const repo = (document.getElementById('ghPortalRepo')?.value || 'depo-updates').trim();

            if (btn) { btn.disabled = true; btn.innerText = 'Bağlanıyor...'; }
            if (resBox) resBox.innerText = 'GitHub API ile depo kontrol ediliyor / oluşturuluyor...';

            try {
                const res = await fetch('/api/github-portal/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ token, owner, repo })
                });
                const data = await res.json();
                if (data.success) {
                    const ownerEl = document.getElementById('ghPortalOwner');
                    if (ownerEl && data.owner) ownerEl.value = data.owner;
                    const mInput = document.getElementById('cfg_update_manifest_url');
                    if (mInput && data.manifest_url) mInput.value = data.manifest_url;
                    if (badgeEl) {
                        badgeEl.innerText = 'GITHUB BAĞLI ✓';
                        badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30';
                    }
                    if (resBox) resBox.innerText = `✅ ${data.message} (${data.manifest_url})`;
                    showToast('GitHub Portalı Hazır', data.message, 'success');
                } else {
                    if (resBox) resBox.innerText = `❌ ${data.message}`;
                    showToast('GitHub Hatası', data.message || 'Bağlantı kurulamadı.', 'error');
                }
            } catch (e) {
                if (resBox) resBox.innerText = `❌ ${e.message}`;
                showToast('Hata', e.message, 'error');
            } finally {
                if (btn) { btn.disabled = false; btn.innerText = 'Bağla'; }
            }
        }

        async function publishLiveReleaseFromPortal() {
            const btn = document.getElementById('btnPublishGhPortal');
            const resBox = document.getElementById('ghPortalResultText');
            const token = (document.getElementById('ghPortalToken')?.value || '').trim();
            const owner = (document.getElementById('ghPortalOwner')?.value || '').trim();
            const repo = (document.getElementById('ghPortalRepo')?.value || 'depo-updates').trim();
            const version = (document.getElementById('ghPortalNewVersion')?.value || '').trim();
            const changelog = (document.getElementById('ghPortalChangelog')?.value || '').trim();

            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Paketreleniyor & Yayınlanıyor...</span>`;
            }
            if (resBox) resBox.innerText = 'Güncelleme paketi hazırlanıyor, GitHub ve yerel ağa gönderiliyor...';

            try {
                const res = await fetch('/api/github-portal/publish', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ token, owner, repo, version, changelog })
                });
                const data = await res.json();
                if (data.success) {
                    if (resBox) resBox.innerText = `✅ v${data.version} yayınlandı (${data.size_kb} KB) | ${data.git_message}`;
                    showToast(`v${data.version} Canlı Yayınlandı!`, data.git_message, 'success');
                    loadGithubPortalConfig();
                    checkAppUpdate(false);
                } else {
                    if (resBox) resBox.innerText = `❌ ${data.message}`;
                    showToast('Yayınlama Hatası', data.message || 'Paket yayınlanamadı.', 'error');
                }
            } catch (e) {
                if (resBox) resBox.innerText = `❌ ${e.message}`;
                showToast('Hata', e.message, 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = `<i class="fa-solid fa-rocket"></i><span>GitHub + Tüm Bilgisayarlara Canlı Yayınla</span>`;
                }
            }
        }

        async function loadLicenseStatus() {
            try {
                const res = await fetch('/api/license/status');
                const data = await res.json();
                const titleEl = document.getElementById('licPharmacyTitle');
                const badgeEl = document.getElementById('licStatusBadge');
                const hwidEl = document.getElementById('licMyHwid');
                const expEl = document.getElementById('licExpiresAt');
                const daysEl = document.getElementById('licDaysLeftText');
                const keyInput = document.getElementById('licKeyInput');

                if (hwidEl && data.my_hwid) hwidEl.innerText = data.my_hwid;
                if (keyInput && data.license_key) keyInput.value = data.license_key;
                if (titleEl && data.pharmacy_name) titleEl.innerText = `${data.pharmacy_name} (${data.plan || 'KURUMSAL'})`;
                if (expEl && data.expires_at) expEl.innerText = data.expires_at;
                if (daysEl && data.days_left !== undefined) {
                    daysEl.innerText = data.days_left >= 0 ? `${data.days_left} gün kaldı` : 'Süresi Doldu';
                    daysEl.className = data.days_left > 15 ? 'text-[11px] text-emerald-700 font-bold' : 'text-[11px] text-rose-600 font-bold';
                }
                if (badgeEl) {
                    if (data.valid) {
                        badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300';
                        badgeEl.innerText = 'LİSANS AKTİF';
                    } else {
                        badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-300';
                        badgeEl.innerText = 'GEÇERSİZ / SÜRESİ DOLDU';
                    }
                }
            } catch (e) {}
        }

        async function activateNewLicense() {
            const keyInput = document.getElementById('licKeyInput');
            const fb = document.getElementById('licFeedbackMsg');
            const keyVal = (keyInput?.value || '').trim();
            if (!keyVal) {
                showToast('Uyarı', 'Lütfen geçerli bir EDP-... lisans anahtarı girin.', 'error');
                return;
            }
            try {
                const res = await fetch('/api/license/activate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ license_key: keyVal })
                });
                const data = await res.json();
                if (fb) {
                    fb.classList.remove('hidden');
                    if (data.valid) {
                        fb.className = 'text-xs font-semibold p-2.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200';
                        fb.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5 text-emerald-600"></i>${data.message}`;
                        showToast('Lisans Aktive Edildi', data.message, 'success');
                        loadLicenseStatus();
                    } else {
                        fb.className = 'text-xs font-semibold p-2.5 rounded-xl bg-rose-50 text-rose-800 border border-rose-200';
                        fb.innerHTML = `<i class="fa-solid fa-circle-xmark mr-1.5 text-rose-600"></i>${data.message}`;
                        showToast('Lisans Hatası', data.message, 'error');
                    }
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        function openUpdateModal() {
            openSettingsModal('guncelleme');
            checkAppUpdate(true);
            loadLicenseStatus();
            loadGithubPortalConfig();
        }

        async function checkAppUpdate(isManual = false) {
            const btnCheck = document.getElementById('btnCheckUpdateNow');
            const checkIcon = document.getElementById('checkUpdateIcon');
            const statusCard = document.getElementById('updateStatusCard');
            const headerVersionBtn = document.getElementById('headerVersionBtn');
            const headerVersionText = document.getElementById('headerVersionText');
            const headerUpdateDot = document.getElementById('headerUpdateDot');
            const tabUpdateBadge = document.getElementById('tabUpdateBadge');

            if (isManual && checkIcon) {
                checkIcon.classList.add('fa-spin');
            }

            try {
                // 1. Önce yerel sürümü al
                const verRes = await fetch('/api/version');
                const localInfo = await verRes.json();
                if (localInfo.version && headerVersionText) {
                    headerVersionText.innerText = `v${localInfo.version}`;
                }
                const titleEl = document.getElementById('updateLocalVersionTitle');
                if (titleEl) titleEl.innerText = `EDA Depo v${localInfo.version || '1.0.0'}`;
                const dateEl = document.getElementById('updateBuildDateText');
                if (dateEl) dateEl.innerText = `Son Güncelleme: ${localInfo.updated_at || localInfo.build_date || '2026-10-12'}`;
                const mInput = document.getElementById('cfg_update_manifest_url');
                if (mInput && localInfo.manifest_url && document.activeElement !== mInput) {
                    mInput.value = localInfo.manifest_url;
                }

                // 2. Güncelleme denetimi yap
                const chkRes = await fetch('/api/update/check');
                const chk = await chkRes.json();
                lastCheckedUpdate = chk;

                if (chk.update_available) {
                    // Yeni sürüm bulundu!
                    if (headerVersionBtn) {
                        headerVersionBtn.className = 'inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl font-bold bg-amber-500 hover:bg-amber-600 text-white transition shadow-sm cursor-pointer animate-pulse';
                    }
                    if (headerVersionText) {
                        headerVersionText.innerText = `🔔 v${chk.latest_version} Güncelle`;
                    }
                    if (headerUpdateDot) headerUpdateDot.classList.remove('hidden');
                    if (tabUpdateBadge) tabUpdateBadge.classList.remove('hidden');

                    if (statusCard) {
                        statusCard.classList.remove('hidden');
                        statusCard.className = 'p-5 rounded-2xl border border-amber-300 bg-amber-50/90 text-amber-950 space-y-3 shadow-sm';
                        statusCard.innerHTML = `
                            <div class="flex items-start justify-between">
                                <div class="flex items-center space-x-3">
                                    <div class="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center text-lg shadow-sm">
                                        <i class="fa-solid fa-bell"></i>
                                    </div>
                                    <div>
                                        <h5 class="text-sm font-black text-amber-950">Yeni Sürüm Yayında: v${chk.latest_version}</h5>
                                        <p class="text-xs text-amber-800">Mevcut sürümünüz: v${chk.current_version}</p>
                                    </div>
                                </div>
                                <span class="text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-amber-200 text-amber-900">Güncelleme Hazır</span>
                            </div>
                            <div class="bg-white/80 p-3.5 rounded-xl border border-amber-200 text-xs space-y-1">
                                <div class="font-bold text-slate-800">Yenilikler & Düzeltmeler:</div>
                                <p class="text-slate-700 whitespace-pre-line">${escapeHtml(chk.changelog || 'Hata düzeltmeleri ve hızlandırmalar.')}</p>
                            </div>
                            <div class="flex items-center justify-between pt-2">
                                <span class="text-[11px] text-amber-800 font-medium">Paket Boyutu: ~1.5 MB (Şifreleriniz ve ayarlarınız korunur)</span>
                                <button type="button" onclick="applyAppUpdate()" id="btnApplyUpdate" class="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-200 transition flex items-center space-x-2 cursor-pointer">
                                    <i class="fa-solid fa-cloud-arrow-down"></i>
                                    <span>Hemen Güncelle & Yeniden Başlat</span>
                                </button>
                            </div>
                        `;
                    }

                    if (isManual) {
                        showToast('Yeni Güncelleme Mevcut!', `Sürüm v${chk.latest_version} yayınlandı. Kurulum başlatılıyor...`, 'info');
                    } else if (chk.auto_update !== false || chk.mandatory) {
                        showToast('Canlı Güncelleme', `Yeni sürüm (v${chk.latest_version}) bulundu, otomatik kuruluyor...`, 'info');
                        setTimeout(() => applyAppUpdate(), 1200);
                    }
                } else {
                    // En güncel sürüm
                    if (headerUpdateDot) headerUpdateDot.classList.add('hidden');
                    if (tabUpdateBadge) tabUpdateBadge.classList.add('hidden');

                    if (statusCard) {
                        statusCard.classList.remove('hidden');
                        statusCard.className = 'p-4 rounded-2xl border border-emerald-200 bg-emerald-50 text-emerald-950 flex items-center space-x-3.5';
                        statusCard.innerHTML = `
                            <div class="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center text-lg shrink-0">
                                <i class="fa-solid fa-check"></i>
                            </div>
                            <div>
                                <h5 class="text-xs font-bold text-emerald-950">Programınız En Güncel Sürümde (v${chk.current_version})</h5>
                                <p class="text-[11px] text-emerald-700">Tüm depo entegrasyonları, 13 haneli barkod motoru ve sepet özellikleri güncel.</p>
                            </div>
                        `;
                    }

                    if (isManual) {
                        showToast('Güncel', `Programınız zaten en güncel sürümde (v${chk.current_version}).`, 'success');
                    }
                }
            } catch (err) {
                if (isManual) {
                    showToast('Kontrol Uyarısı', 'Güncelleme sunucusuna bağlanılamadı.', 'error');
                }
            } finally {
                if (checkIcon) checkIcon.classList.remove('fa-spin');
            }
        }

        async function applyAppUpdate() {
            const btn = document.getElementById('btnApplyUpdate');
            const statusCard = document.getElementById('updateStatusCard');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1.5"></i>İndiriliyor & Kuruluyor...`;
            }

            try {
                const res = await fetch('/api/update/apply', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(lastCheckedUpdate || {})
                });
                const data = await res.json();

                if (data.success) {
                    if (statusCard) {
                        statusCard.className = 'p-5 rounded-2xl border border-emerald-300 bg-emerald-50 text-emerald-950 text-center space-y-2';
                        statusCard.innerHTML = `
                            <div class="inline-flex w-12 h-12 rounded-xl bg-emerald-600 text-white items-center justify-center text-2xl shadow-md">
                                <i class="fa-solid fa-circle-check"></i>
                            </div>
                            <h4 class="text-sm font-black text-emerald-950">Güncelleme Başarıyla Kuruldu!</h4>
                            <p class="text-xs text-emerald-800">Sunucu yeni kodlarla yeniden başlatılıyor. Sayfa 3 saniye içinde açılacak...</p>
                            <div class="w-full bg-emerald-200 h-1.5 rounded-full overflow-hidden mt-3">
                                <div class="bg-emerald-600 h-full animate-pulse w-full"></div>
                            </div>
                        `;
                    }
                    showToast('Başarılı', 'Güncelleme kuruldu! Sayfa yenileniyor...', 'success');
                    setTimeout(() => {
                        window.location.reload();
                    }, 3500);
                } else {
                    showToast('Güncelleme Hatası', data.message || 'Güncelleme uygulanamadı.', 'error');
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = `<i class="fa-solid fa-rotate-right mr-1.5"></i>Tekrar Dene`;
                    }
                }
            } catch (err) {
                showToast('Hata', 'Güncelleme sırasında bağlantı kesildi: ' + err.message, 'error');
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = `<i class="fa-solid fa-rotate-right mr-1.5"></i>Tekrar Dene`;
                }
            }
        }

        async function restartAppServer() {
            if (!confirm('EDA Depo sunucusu yeniden başlatılsın mı? Sayfa 3 saniye içinde otomatik tazelenecektir.')) return;
            try {
                showToast('Yeniden Başlatılıyor', 'Sunucu yeniden başlatılıyor...', 'info');
                await fetch('/api/server/restart', { method: 'POST' });
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            } catch (e) {
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            }
        }

        // ================= Dermo & OTC Barkod Onarım Sihirbazı İşlemleri =================
        function escapeHtml(text) {
            if (!text) return '';
            return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }

        let currentDermoMatches = [];

        async function runDermoAudit() {
            const brand = document.getElementById('dermoBrandSelect')?.value || '';
            const limit = document.getElementById('dermoLimitSelect')?.value || 50;
            const btn = document.getElementById('btnRunDermoAudit');
            const loading = document.getElementById('dermoLoading');
            const resultsContainer = document.getElementById('dermoResultsContainer');
            const feedback = document.getElementById('dermoSyncFeedback');

            if (feedback) feedback.classList.add('hidden');
            if (resultsContainer) resultsContainer.classList.add('hidden');
            if (loading) loading.classList.remove('hidden');
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> Taranıyor...'; }

            try {
                const resp = await fetch(`/api/botanik/dermo-audit?brand=${encodeURIComponent(brand)}&limit=${limit}`);
                const data = await resp.json();

                if (loading) loading.classList.add('hidden');
                if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-magnifying-glass-arrow-right"></i> Hatalı Barkodları Tara & Eşleştir'; }

                if (!data.success) {
                    showToast(data.message || 'Tarama sırasında bir hata oluştu.', 'error');
                    return;
                }

                currentDermoMatches = data.matches || [];
                document.getElementById('dermoStatScanned').innerText = data.scanned_count || 0;
                document.getElementById('dermoStatMatched').innerText = currentDermoMatches.length;
                document.getElementById('dermoStatElapsed').innerText = (data.elapsed_sec || 0) + 's';

                const tbody = document.getElementById('dermoAuditTableBody');
                if (!tbody) return;
                tbody.innerHTML = '';

                if (currentDermoMatches.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-slate-400 font-medium">Bu filtreye uygun hatalı veya eksik barkodlu ürün bulunamadı.</td></tr>`;
                } else {
                    currentDermoMatches.forEach((item) => {
                        const tr = document.createElement('tr');
                        tr.id = `dermoRow_${item.urun_id}`;
                        tr.className = 'hover:bg-pink-50/40 transition';
                        tr.innerHTML = `
                            <td class="py-2.5 px-3 text-center">
                                <input type="checkbox" class="dermoItemCheck rounded text-pink-600 focus:ring-0 w-4 h-4 cursor-pointer" data-id="${item.urun_id}" data-bc="${item.oneri_barkod}" checked />
                            </td>
                            <td class="py-2.5 px-3">
                                <div class="font-bold text-slate-800">${escapeHtml(item.urun_adi)}</div>
                                <div class="text-[10px] text-slate-400 font-mono">ID: ${item.urun_id} • Stok: ${item.stok} Kutu</div>
                            </td>
                            <td class="py-2.5 px-3">
                                <span class="inline-flex items-center px-2 py-0.5 rounded font-mono text-[11px] font-bold ${item.mevcut_barkod === 'YOK' ? 'bg-slate-100 text-slate-500' : 'bg-amber-100 text-amber-800'}">
                                    ${item.mevcut_barkod}
                                </span>
                            </td>
                            <td class="py-2.5 px-3">
                                <span class="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-800 font-mono text-xs font-black shadow-2xs">
                                    <i class="fa-solid fa-barcode text-emerald-600"></i>
                                    <span>${item.oneri_barkod}</span>
                                </span>
                            </td>
                            <td class="py-2.5 px-3 text-[11px] text-slate-600 font-medium">
                                ${escapeHtml(item.katalog_urun_adi || '-')}
                            </td>
                            <td class="py-2.5 px-3 text-center" id="dermoStatusCell_${item.urun_id}">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-pink-100 text-pink-700">
                                    ${item.guven || 'Tam Uyum'}
                                </span>
                            </td>
                        `;
                        tbody.appendChild(tr);
                    });
                }

                if (resultsContainer) resultsContainer.classList.remove('hidden');
                showToast(data.message, 'success');

            } catch (err) {
                if (loading) loading.classList.add('hidden');
                if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-magnifying-glass-arrow-right"></i> Hatalı Barkodları Tara & Eşleştir'; }
                showToast('Bağlantı hatası: ' + err.message, 'error');
            }
        }

        function toggleAllDermoCheckboxes(masterCheckbox) {
            const checks = document.querySelectorAll('.dermoItemCheck');
            checks.forEach(c => c.checked = masterCheckbox.checked);
        }

        async function applyDermoSync() {
            const checks = document.querySelectorAll('.dermoItemCheck:checked');
            if (checks.length === 0) {
                showToast('Lütfen Botanik’e eklemek için en az bir ürün seçin.', 'info');
                return;
            }

            const itemsToSync = [];
            checks.forEach(c => {
                itemsToSync.push({
                    urun_id: parseInt(c.dataset.id),
                    oneri_barkod: c.dataset.bc
                });
            });

            const confirmed = confirm(`${itemsToSync.length} adet gerçek üretici barkodu Botanik programınıza ek barkod olarak eklenecektir.\n\nMevcut verileriniz silinmez. Devam edilsin mi?`);
            if (!confirmed) return;

            const btn = document.getElementById('btnApplyDermoSync');
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> Ekleniyor...'; }

            try {
                const resp = await fetch('/api/botanik/dermo-sync', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ items: itemsToSync })
                });
                const res = await resp.json();

                if (btn) { btn.disabled = false; btn.innerHTML = `<i class="fa-solid fa-floppy-disk"></i> Seçilenleri Botanik'e Ekle`; }

                if (res.success) {
                    showToast(res.message, 'success');
                    // Başarılı satırları güncelle
                    itemsToSync.forEach(it => {
                        const cell = document.getElementById(`dermoStatusCell_${it.urun_id}`);
                        if (cell) {
                            cell.innerHTML = '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800"><i class="fa-solid fa-check mr-1"></i> Eklendi</span>';
                        }
                    });
                } else {
                    showToast(res.message || 'Eklenirken bir hata oluştu.', 'error');
                }
            } catch (err) {
                if (btn) { btn.disabled = false; btn.innerHTML = `<i class="fa-solid fa-floppy-disk"></i> Seçilenleri Botanik'e Ekle`; }
                showToast('Hata: ' + err.message, 'error');
            }
        }

        async function fetchCatalogStats() {
            try {
                const res = await fetch('/api/catalog/stats');
                if (res.ok) {
                    const data = await res.json();
                    document.getElementById('catStatProducts').innerText = (data.total_products || 0).toLocaleString('tr-TR');
                    document.getElementById('catStatBarcodes').innerText = (data.total_barcodes || 0).toLocaleString('tr-TR');
                    document.getElementById('catStatSecondary').innerText = (data.secondary_barcodes || 0).toLocaleString('tr-TR');
                }
            } catch(e) {
                console.error('Katalog istatistik hatası:', e);
            }
        }

        async function syncBotanikCatalog() {
            const btn = document.getElementById('btnSyncBotanikCat');
            const statusDiv = document.getElementById('botanikSyncStatus');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Botanik taranıyor...`;
            statusDiv.className = 'hidden';

            try {
                const res = await fetch('/api/catalog/sync-botanik', { method: 'POST' });
                const data = await res.json();
                if (data.success) {
                    statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200';
                    statusDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5"></i>${data.message}`;
                    fetchCatalogStats();
                    showToast('Katalog Güncellendi', data.message, 'success');
                } else {
                    throw new Error(data.error || 'Botanik senkronizasyonu başarısız oldu.');
                }
            } catch(e) {
                statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-red-50 text-red-800 border border-red-200';
                statusDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        async function syncTriaCatalog() {
            const btn = document.getElementById('btnSyncTriaCat');
            const statusDiv = document.getElementById('triaSyncStatus');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Senkronize ediliyor...`;
            statusDiv.className = 'hidden';

            try {
                const res = await fetch('/api/catalog/sync-tria', { method: 'POST' });
                const data = await res.json();
                if (data.success) {
                    statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200';
                    statusDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5"></i>${data.message}`;
                    fetchCatalogStats();
                    showToast('Katalog Güncellendi', data.message, 'success');
                } else {
                    throw new Error(data.error || 'Senkronizasyon başarısız oldu.');
                }
            } catch(e) {
                statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-red-50 text-red-800 border border-red-200';
                statusDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        async function uploadCatalogExcel() {
            const fileInput = document.getElementById('excelCatalogFile');
            const btn = document.getElementById('btnUploadCatExcel');
            const statusDiv = document.getElementById('excelUploadStatus');

            if (!fileInput.files || fileInput.files.length === 0) {
                alert('Lütfen yüklenecek bir Excel (.xlsx) dosyası seçin.');
                return;
            }

            const formData = new FormData();
            formData.append('file', fileInput.files[0]);

            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Aktarılıyor...`;
            statusDiv.className = 'hidden';

            try {
                const res = await fetch('/api/catalog/upload-excel', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.success) {
                    statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200';
                    statusDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5"></i>Başarılı: ${data.count} ürün kataloğa aktarıldı.`;
                    fetchCatalogStats();
                    showToast('Excel Aktarıldı', `${data.count} ürün kataloğa eklendi.`, 'success');
                    fileInput.value = '';
                } else {
                    throw new Error(data.error || 'Excel aktarımı başarısız oldu.');
                }
            } catch(e) {
                statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-red-50 text-red-800 border border-red-200';
                statusDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        function setBotanikProfile(profile) {
            if (profile === 'bu_bilgisayar') {
                document.getElementById('cfg_botanik_server').value = 'DESKTOP-L6GG7P6\\BOTANIKSQL';
                document.getElementById('cfg_botanik_db').value = 'eczane';
                document.getElementById('cfg_botanik_user').value = 'sa';
                document.getElementById('cfg_botanik_pwd').value = '123';
                document.getElementById('cfg_botanik_trusted').checked = false;
                showToast('Profil Yüklendi', 'Bu Bilgisayar (DESKTOP-L6GG7P6\\BOTANIKSQL) ayarları uygulandı.', 'success');
            } else if (profile === 'yerel') {
                document.getElementById('cfg_botanik_server').value = '.\\BOTANIKSQL';
                document.getElementById('cfg_botanik_db').value = 'eczane';
                document.getElementById('cfg_botanik_user').value = 'sa';
                document.getElementById('cfg_botanik_pwd').value = '123';
                document.getElementById('cfg_botanik_trusted').checked = false;
                showToast('Profil Yüklendi', 'Yerel Makine (.\\BOTANIKSQL) ayarları uygulandı.', 'success');
            }
        }

        async function autoReadBotanikConfigFile() {
            try {
                const res = await fetch('/api/botanik/read-config');
                const data = await res.json();
                if (data.success) {
                    const cfg = data.config || data;
                    const serverVal = cfg.server || data.server;
                    const dbVal = cfg.database || data.database;
                    const userVal = cfg.user || data.user;
                    const pwdVal = cfg.password || data.password;
                    const trustedVal = (cfg.trusted !== undefined) ? cfg.trusted : data.trusted;

                    if (serverVal) document.getElementById('cfg_botanik_server').value = serverVal;
                    if (dbVal) document.getElementById('cfg_botanik_db').value = dbVal;
                    if (userVal) document.getElementById('cfg_botanik_user').value = userVal;
                    if (pwdVal) document.getElementById('cfg_botanik_pwd').value = pwdVal;
                    if (trustedVal !== undefined) {
                        document.getElementById('cfg_botanik_trusted').checked = (trustedVal === true || trustedVal === 'true');
                    }
                    const pathInfo = data.path ? ` (${data.path})` : '';
                    showToast('Config Başarıyla Okundu', data.message || `Botanik config${pathInfo} dosyasından bilgiler otomatik aktarıldı.`, 'success');
                } else {
                    showToast('Config Bulunamadı', data.message || 'Botanik config dosyası okunamadı. Lütfen elle giriniz.', 'error');
                }
            } catch(e) {
                showToast('Hata', `Config okuma hatası: ${e.message}`, 'error');
            }
        }

        async function pingBotanikConnection() {
            const btn = document.getElementById('btnPingBotanik');
            const resBox = document.getElementById('botanikPingResult');
            const origHtml = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i><span>Ping Atılıyor...</span>`;
            resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-slate-100 text-slate-600 border border-slate-200';
            resBox.innerHTML = '<i class="fa-solid fa-spinner animate-spin mr-1.5"></i>Botanik MS SQL veritabanına bağlanılıyor...';
            resBox.classList.remove('hidden');

            try {
                const res = await fetch('/api/botanik/ping');
                const data = await res.json();
                if (data.success && data.connected) {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-emerald-50 text-emerald-900 border border-emerald-300';
                    resBox.innerHTML = `
                        <div class="flex items-center justify-between border-b border-emerald-200/80 pb-1.5 mb-2">
                            <span class="font-bold text-sm text-emerald-800 flex items-center space-x-1.5">
                                <i class="fa-solid fa-circle-check text-emerald-600"></i>
                                <span>Botanik SQL Bağlantısı Başarılı</span>
                            </span>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-200 text-emerald-900 font-mono">${data.latency_ms} ms</span>
                        </div>
                        <div class="text-[11px] text-emerald-800 space-y-1">
                            <div>Sunucu: <strong class="font-mono text-emerald-950">${data.server}</strong> | Veritabanı: <strong class="font-mono text-emerald-950">${data.database}</strong> (Kullanıcı: <strong>${data.user}</strong>)</div>
                            <div>SQL Sürüm: <strong>${data.version || 'MS SQL Server'}</strong></div>
                            <div>Kayıtlı Veri: <strong>${(data.stats && data.stats.kayitli_urun_sayisi) ? data.stats.kayitli_urun_sayisi.toLocaleString() : '-'}</strong> İlaç/Ürün, <strong>${(data.stats && data.stats.toplam_recete_sayisi) ? data.stats.toplam_recete_sayisi.toLocaleString() : '-'}</strong> Reçete, <strong>${(data.stats && data.stats.fatura_sayisi) ? data.stats.fatura_sayisi.toLocaleString() : '-'}</strong> Fatura</div>
                        </div>
                    `;
                    updateHeaderBotanikStatus(true, data);
                    showToast('Botanik Bağlantısı Başarılı', `Botanik veritabanına ${data.latency_ms} ms içinde bağlanıldı.`, 'success');
                } else {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                    resBox.innerHTML = `
                        <div class="font-bold text-sm text-red-800 flex items-center space-x-1.5 mb-1">
                            <i class="fa-solid fa-circle-xmark text-red-600"></i>
                            <span>Bağlantı Başarısız (${data.latency_ms || 0} ms)</span>
                        </div>
                        <div class="text-[11px] text-red-700">
                            <strong>Hata Detayı:</strong> ${data.message || data.error || 'Veritabanı yanıt vermedi.'}
                        </div>
                    `;
                    updateHeaderBotanikStatus(false, data);
                }
            } catch(e) {
                resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                resBox.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5 text-red-600"></i>Bağlantı hatası: ${e.message}`;
                updateHeaderBotanikStatus(false);
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        }

        window.activeOtomasyon = 'TRIA';
        window.botanikStatus = { connected: null, latency_ms: null };
        window.triaStatus = { connected: null, latency_ms: null };
        window.tebeosStatus = { connected: null, latency_ms: null };

        function refreshHeaderActiveOtomasyon() {
            const btn = document.getElementById('headerActiveOtomasyonBtn');
            const icon = document.getElementById('headerOtomasyonIcon');
            const text = document.getElementById('headerOtomasyonText');
            const dot = document.getElementById('headerOtomasyonDot');

            if (!btn || !text) return;

            const activeOto = (window.activeOtomasyon || 'TRIA').toUpperCase();

            if (activeOto === 'TEBEOS') {
                if (icon) icon.className = 'fa-solid fa-mortar-pestle text-sky-600';
                if (window.tebeosStatus.connected === true) {
                    btn.className = 'inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-300 transition shadow-xs cursor-pointer';
                    const lat = window.tebeosStatus.latency_ms ? ` (${window.tebeosStatus.latency_ms}ms)` : '';
                    text.innerText = `TEBEOS: Bağlı${lat}`;
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-emerald-500 animate-pulse ml-0.5';
                } else if (window.tebeosStatus.connected === false) {
                    btn.className = 'inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-300 transition shadow-xs cursor-pointer';
                    text.innerText = 'TEBEOS: Bağlantı Yok';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-rose-500 ml-0.5';
                } else {
                    btn.className = 'inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-300 transition shadow-xs cursor-pointer';
                    text.innerText = 'TEBEOS: Bağlanıyor...';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-amber-500 animate-pulse ml-0.5';
                }
                btn.title = 'TEBEOS PostgreSQL Veritabanı ve Şifre Ayarlarını Aç';
            } else if (activeOto === 'BOTANIK') {
                if (icon) icon.className = 'fa-solid fa-leaf text-emerald-600';
                if (window.botanikStatus.connected === true) {
                    btn.className = 'inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 transition shadow-xs cursor-pointer';
                    const lat = window.botanikStatus.latency_ms ? ` (${window.botanikStatus.latency_ms}ms)` : '';
                    text.innerText = `Botanik: Bağlı${lat}`;
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-emerald-500 animate-pulse ml-0.5';
                } else if (window.botanikStatus.connected === false) {
                    btn.className = 'inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-300 transition shadow-xs cursor-pointer';
                    text.innerText = 'Botanik: Bağlantı Yok';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-rose-500 ml-0.5';
                } else {
                    btn.className = 'inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 transition shadow-xs cursor-pointer';
                    text.innerText = 'Botanik: Bağlanıyor...';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-amber-500 animate-pulse ml-0.5';
                }
                btn.title = 'Botanik Eczane MS SQL Veritabanı ve Şifre Ayarlarını Aç';
            } else {
                if (icon) icon.className = 'fa-solid fa-database text-amber-600';
                if (window.triaStatus.connected === true) {
                    btn.className = 'inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 transition shadow-xs cursor-pointer';
                    const lat = window.triaStatus.latency_ms ? ` (${window.triaStatus.latency_ms}ms)` : '';
                    text.innerText = `TRIA: Bağlı${lat}`;
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-emerald-500 animate-pulse ml-0.5';
                } else if (window.triaStatus.connected === false) {
                    btn.className = 'inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-300 transition shadow-xs cursor-pointer';
                    text.innerText = 'TRIA: Bağlantı Yok';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-rose-500 ml-0.5';
                } else {
                    btn.className = 'inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 transition shadow-xs cursor-pointer';
                    text.innerText = 'TRIA: Bağlanıyor...';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-amber-500 animate-pulse ml-0.5';
                }
                btn.title = 'TRIA Oracle Veritabanı ve Şifre Ayarlarını Aç';
            }
        }

        function selectActiveOtomasyon(type, switchTab = true) {
            window.activeOtomasyon = type;
            const sel = document.getElementById('cfg_active_otomasyon');
            if (sel) sel.value = type;

            const cardBotanik = document.getElementById('otoChoiceCardBotanik');
            const cardTria = document.getElementById('otoChoiceCardTria');
            const cardTebeos = document.getElementById('otoChoiceCardTebeos');
            const badgeBotanik = document.getElementById('otoChoiceBadgeBotanik');
            const badgeTria = document.getElementById('otoChoiceBadgeTria');
            const badgeTebeos = document.getElementById('otoChoiceBadgeTebeos');

            const inactiveCardClass = 'p-3.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 cursor-pointer transition flex items-center justify-between group';
            const inactiveBadgeClass = 'text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/10 text-slate-400';

            if (cardBotanik) cardBotanik.className = inactiveCardClass;
            if (cardTria) cardTria.className = inactiveCardClass;
            if (cardTebeos) cardTebeos.className = inactiveCardClass;
            if (badgeBotanik) { badgeBotanik.className = inactiveBadgeClass; badgeBotanik.innerText = 'SEÇ'; }
            if (badgeTria) { badgeTria.className = inactiveBadgeClass; badgeTria.innerText = 'SEÇ'; }
            if (badgeTebeos) { badgeTebeos.className = inactiveBadgeClass; badgeTebeos.innerText = 'SEÇ'; }

            if (type === 'BOTANIK') {
                if (cardBotanik) cardBotanik.className = 'p-3.5 rounded-xl border-2 border-emerald-500 bg-emerald-500/20 cursor-pointer transition flex items-center justify-between group shadow-sm';
                if (badgeBotanik) {
                    badgeBotanik.className = 'text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-400 text-slate-950';
                    badgeBotanik.innerText = '✓ AKTİF SEÇİM';
                }
                if (switchTab) switchSettingsTab('botanik');
            } else if (type === 'TEBEOS') {
                if (cardTebeos) cardTebeos.className = 'p-3.5 rounded-xl border-2 border-sky-500 bg-sky-500/20 cursor-pointer transition flex items-center justify-between group shadow-sm';
                if (badgeTebeos) {
                    badgeTebeos.className = 'text-[10px] font-black px-2 py-0.5 rounded-full bg-sky-400 text-slate-950';
                    badgeTebeos.innerText = '✓ AKTİF SEÇİM';
                }
                if (switchTab) switchSettingsTab('tebeos');
            } else {
                if (cardTria) cardTria.className = 'p-3.5 rounded-xl border-2 border-amber-500 bg-amber-500/20 cursor-pointer transition flex items-center justify-between group shadow-sm';
                if (badgeTria) {
                    badgeTria.className = 'text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-400 text-slate-950';
                    badgeTria.innerText = '✓ AKTİF SEÇİM';
                }
                if (switchTab) switchSettingsTab('tria');
            }

            refreshHeaderActiveOtomasyon();
        }

        function setTebeosProfile(profile) {
            if (profile === 'ana_makine') {
                document.getElementById('cfg_tebeos_host').value = '192.168.1.11';
                document.getElementById('cfg_tebeos_port').value = '5454';
                document.getElementById('cfg_tebeos_db').value = 'tebeos_db';
                document.getElementById('cfg_tebeos_user').value = 'tebeos';
                document.getElementById('cfg_tebeos_pwd').value = '123';
                showToast('Profil Yüklendi', 'TEBEOS Ana Makine (192.168.1.11:5454) ayarları uygulandı.', 'success');
            } else if (profile === 'yerel') {
                document.getElementById('cfg_tebeos_host').value = '127.0.0.1';
                document.getElementById('cfg_tebeos_port').value = '5454';
                document.getElementById('cfg_tebeos_db').value = 'tebeos_db';
                document.getElementById('cfg_tebeos_user').value = 'tebeos';
                document.getElementById('cfg_tebeos_pwd').value = '123';
                showToast('Profil Yüklendi', 'TEBEOS Yerel (127.0.0.1:5454) ayarları uygulandı.', 'success');
            }
        }

        async function discoverTebeosHost() {
            const btn = document.getElementById('btnDiscoverTebeos');
            const resDiv = document.getElementById('tebeosDiscoverResult');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Taranıyor...`;
            resDiv.className = 'text-[11px] mt-1 text-slate-500 font-medium';
            resDiv.innerText = 'Yerel ağdaki TEBEOS PostgreSQL sunucusu taranıyor (Port 5454)...';
            resDiv.classList.remove('hidden');

            try {
                const res = await fetch('/api/tebeos/discover');
                const data = await res.json();
                if (data.success && data.found) {
                    if (data.host) document.getElementById('cfg_tebeos_host').value = data.host;
                    if (data.port) document.getElementById('cfg_tebeos_port').value = data.port;
                    if (data.database) document.getElementById('cfg_tebeos_db').value = data.database;
                    if (data.user) document.getElementById('cfg_tebeos_user').value = data.user;
                    if (data.password) document.getElementById('cfg_tebeos_pwd').value = data.password;
                    resDiv.className = 'text-[11px] mt-1 text-emerald-700 font-bold';
                    resDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>Bulundu: <strong>${data.host}:${data.port || '5454'}/${data.database || 'tebeos_db'}</strong> (${data.message})`;
                    showToast('TEBEOS Sunucusu Bulundu', `Ağda çalışan TEBEOS PostgreSQL sunucusu (${data.host}) tespit edildi ve tüm alanlar dolduruldu.`, 'success');
                } else {
                    resDiv.className = 'text-[11px] mt-1 text-amber-700 font-medium';
                    resDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1 text-amber-500"></i>${data.message || 'Otomatik tespit edilemedi, lütfen IP adresini elle giriniz.'}`;
                }
            } catch(e) {
                resDiv.className = 'text-[11px] mt-1 text-rose-600 font-medium';
                resDiv.innerText = `Arama hatası: ${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        async function pingTebeosConnection() {
            const btn = document.getElementById('btnPingTebeos');
            const resBox = document.getElementById('tebeosPingResult');
            const origHtml = btn.innerHTML;

            const host = (document.getElementById('cfg_tebeos_host')?.value || '').trim();
            const port = (document.getElementById('cfg_tebeos_port')?.value || '').trim();
            const db = (document.getElementById('cfg_tebeos_db')?.value || '').trim();
            const user = (document.getElementById('cfg_tebeos_user')?.value || '').trim();
            const pwd = (document.getElementById('cfg_tebeos_pwd')?.value || '').trim();

            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i><span>Bağlanıyor...</span>`;
            resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-slate-100 text-slate-600 border border-slate-200';
            resBox.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1.5"></i><strong>${host || '192.168.1.11'}:${port || '5454'}/${db || 'tebeos_db'}</strong> (${user || 'tebeos'}) adresine bağlanılıyor...`;
            resBox.classList.remove('hidden');

            try {
                const params = new URLSearchParams();
                if (host) params.append('host', host);
                if (port) params.append('port', port);
                if (db) params.append('database', db);
                if (user) params.append('user', user);
                if (pwd) params.append('password', pwd);

                const res = await fetch(`/api/tebeos/ping?${params.toString()}`);
                const data = await res.json();
                if (data.success && data.connected) {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-emerald-50 text-emerald-900 border border-emerald-300';
                    resBox.innerHTML = `
                        <div class="flex items-center justify-between border-b border-emerald-200/80 pb-1.5 mb-2">
                            <span class="font-bold text-sm text-emerald-800 flex items-center space-x-1.5">
                                <i class="fa-solid fa-circle-check text-emerald-600"></i>
                                <span>TEBEOS PostgreSQL Bağlantısı Başarılı</span>
                            </span>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-200 text-emerald-900 font-mono">${data.latency_ms} ms</span>
                        </div>
                        <div class="text-[11px] text-emerald-800 space-y-1">
                            <div>Host: <strong class="font-mono text-emerald-950">${data.host}:${data.port}/${data.database}</strong> (Kullanıcı: <strong>${data.user}</strong>)</div>
                            <div>PostgreSQL Sürüm: <strong>${data.version || 'PostgreSQL 12'}</strong></div>
                            <div>Kayıtlı Veri: <strong>${(data.stats && data.stats.kayitli_urun_sayisi) ? data.stats.kayitli_urun_sayisi.toLocaleString() : '-'}</strong> İlaç/Ürün, <strong>${(data.stats && data.stats.toplam_satis_hareketi) ? data.stats.toplam_satis_hareketi.toLocaleString() : '-'}</strong> Satış Hareketi, <strong>${(data.stats && data.stats.fatura_sayisi) ? data.stats.fatura_sayisi.toLocaleString() : '-'}</strong> Fatura</div>
                        </div>
                    `;
                    updateHeaderTebeosStatus(true, data);
                    showToast('TEBEOS Bağlantısı Başarılı', `TEBEOS PostgreSQL veritabanına ${data.latency_ms} ms içinde bağlanıldı.`, 'success');
                } else {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                    resBox.innerHTML = `
                        <div class="font-bold text-sm text-red-800 flex items-center space-x-1.5 mb-1">
                            <i class="fa-solid fa-circle-xmark text-red-600"></i>
                            <span>Bağlantı Başarısız (${data.latency_ms || 0} ms)</span>
                        </div>
                        <div class="text-[11px] text-red-700">
                            <strong>Hata Detayı:</strong> ${data.message || data.error || 'Veritabanı yanıt vermedi.'}
                        </div>
                    `;
                    updateHeaderTebeosStatus(false, data);
                }
            } catch(e) {
                resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                resBox.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5 text-red-600"></i>Bağlantı hatası: ${e.message}`;
                updateHeaderTebeosStatus(false);
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        }

        function updateHeaderTebeosStatus(connected, data) {
            window.tebeosStatus = {
                connected: !!connected,
                latency_ms: (data && data.latency_ms) ? data.latency_ms : null
            };
            const tabBadge = document.getElementById('tabTebeosBadge');
            if (tabBadge) {
                tabBadge.className = connected 
                    ? 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold'
                    : 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold';
                tabBadge.innerText = connected ? 'Bağlı' : 'Kesildi';
            }
            refreshHeaderActiveOtomasyon();
        }

        async function checkTebeosStatusOnLoad() {
            try {
                const res = await fetch('/api/tebeos/ping');
                const data = await res.json();
                updateHeaderTebeosStatus(data.success && data.connected, data);
            } catch(e) {
                updateHeaderTebeosStatus(false);
            }
        }

        function updateHeaderBotanikStatus(connected, data) {
            window.botanikStatus = {
                connected: !!connected,
                latency_ms: (data && data.latency_ms) ? data.latency_ms : null
            };
            const tabBadge = document.getElementById('tabBotanikBadge');
            if (tabBadge) {
                tabBadge.className = connected 
                    ? 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold'
                    : 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold';
                tabBadge.innerText = connected ? 'Bağlı' : 'Kesildi';
            }
            refreshHeaderActiveOtomasyon();
        }

        async function checkBotanikStatusOnLoad() {
            try {
                const res = await fetch('/api/botanik/ping');
                const data = await res.json();
                updateHeaderBotanikStatus(data.success && data.connected, data);
            } catch(e) {
                updateHeaderBotanikStatus(false);
            }
        }

        function setTriaProfile(profile) {
            if (profile === 'eda_canli') {
                document.getElementById('cfg_tria_host').value = '192.168.1.57';
                document.getElementById('cfg_tria_port').value = '1521';
                document.getElementById('cfg_tria_sid').value = 'ORCL';
                document.getElementById('cfg_tria_user').value = 'EDA';
                document.getElementById('cfg_tria_pwd').value = 'EDA';
                showToast('Profil Yüklendi', 'Canlı Eda Eczanesi (192.168.1.57) Oracle ayarları uygulandı.', 'success');
            } else if (profile === 'arastirma') {
                document.getElementById('cfg_tria_host').value = '192.168.1.155';
                document.getElementById('cfg_tria_port').value = '1521';
                document.getElementById('cfg_tria_sid').value = 'ORCL';
                document.getElementById('cfg_tria_user').value = 'ARASTIRMA';
                document.getElementById('cfg_tria_pwd').value = 'ARASTIRMA';
                showToast('Profil Yüklendi', 'Canlı Araştırma Eczanesi (192.168.1.155) Oracle ayarları uygulandı.', 'success');
            } else if (profile === 'eda_yerel') {
                document.getElementById('cfg_tria_host').value = '127.0.0.1';
                document.getElementById('cfg_tria_port').value = '1521';
                document.getElementById('cfg_tria_sid').value = 'XEPDB1';
                document.getElementById('cfg_tria_user').value = 'EDA';
                document.getElementById('cfg_tria_pwd').value = 'EDA';
                showToast('Profil Yüklendi', 'Eda Eczanesi Yedeği (127.0.0.1) yerel ayarları uygulandı.', 'success');
            }
        }

        async function discoverTriaHost() {
            const btn = document.getElementById('btnDiscoverHost');
            const resDiv = document.getElementById('discoverResult');
            const hostInput = document.getElementById('cfg_tria_host');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Taranıyor...`;
            resDiv.className = 'text-[11px] mt-1 text-slate-500 font-medium';
            resDiv.innerText = 'Ağdaki TRIA Oracle sunucusu taranıyor (Port 1521/1522)...';
            resDiv.classList.remove('hidden');

            try {
                const res = await fetch('/api/tria/discover');
                const data = await res.json();
                if (data.success && data.found) {
                    hostInput.value = data.host;
                    if (data.port) document.getElementById('cfg_tria_port').value = data.port;
                    if (data.sid) document.getElementById('cfg_tria_sid').value = data.sid;
                    if (data.user) document.getElementById('cfg_tria_user').value = data.user;
                    if (data.password) document.getElementById('cfg_tria_pwd').value = data.password;
                    resDiv.className = 'text-[11px] mt-1 text-emerald-700 font-bold';
                    resDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>Bulundu: <strong>${data.host}:${data.port || '1521'}/${data.sid || 'ORCL'}</strong> (${data.message})`;
                    showToast('TRIA Sunucusu Bulundu', `Ağda çalışan canlı Oracle sunucusu (${data.host}) tespit edildi ve tüm alanlar dolduruldu.`, 'success');
                } else {
                    resDiv.className = 'text-[11px] mt-1 text-amber-700 font-medium';
                    resDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1 text-amber-500"></i>${data.message || 'Otomatik tespit edilemedi, lütfen IP adresini elle giriniz.'}`;
                }
            } catch(e) {
                resDiv.className = 'text-[11px] mt-1 text-rose-600 font-medium';
                resDiv.innerText = `Arama hatası: ${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        async function loadAvailableSchemas() {
            const btn = document.getElementById('btnListSchemas');
            const container = document.getElementById('schemaListContainer');
            const pills = document.getElementById('schemaPills');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Listeleniyor...`;

            try {
                const res = await fetch('/api/tria/schemas');
                const data = await res.json();
                if (data.success && data.schemas && data.schemas.length > 0) {
                    container.classList.remove('hidden');
                    pills.innerHTML = data.schemas.map(s => `
                        <button type="button" onclick="selectTriaSchema('${s}')" class="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-lg text-xs font-mono font-bold transition flex items-center space-x-1 cursor-pointer">
                            <i class="fa-solid fa-circle-arrow-right text-[10px] text-amber-700"></i>
                            <span>${s}</span>
                        </button>
                    `).join('');
                    showToast('Şemalar Listelendi', `${data.count} eczane şeması bulundu.`, 'success');
                } else {
                    showToast('Bilgi', data.message || 'Eczane şeması bulunamadı.', 'error');
                }
            } catch(e) {
                showToast('Hata', `Şemalar çekilemedi: ${e.message}`, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        function selectTriaSchema(schemaName) {
            document.getElementById('cfg_tria_user').value = schemaName;
            const pwdInput = document.getElementById('cfg_tria_pwd');
            if (!pwdInput.value || pwdInput.value === 'ARASTIRMA' || pwdInput.value === 'EDA') {
                pwdInput.value = schemaName;
            }
            showToast('Şema Seçildi', `${schemaName} şeması seçildi. Şifre alanı otomatik dolduruldu.`, 'success');
        }

        async function pingTriaConnection() {
            const btn = document.getElementById('btnPingTria');
            const resBox = document.getElementById('triaPingResult');
            const origHtml = btn.innerHTML;

            const host = (document.getElementById('cfg_tria_host')?.value || '').trim();
            const port = (document.getElementById('cfg_tria_port')?.value || '').trim();
            const sid = (document.getElementById('cfg_tria_sid')?.value || '').trim();
            const user = (document.getElementById('cfg_tria_user')?.value || '').trim();
            const pwd = (document.getElementById('cfg_tria_pwd')?.value || '').trim();

            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i><span>Bağlanıyor...</span>`;
            resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-slate-100 text-slate-600 border border-slate-200';
            resBox.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1.5"></i><strong>${host || '127.0.0.1'}:${port || '1522'}/${sid || 'XEPDB1'}</strong> (${user || 'EDA'}) adresine bağlanılıyor...`;
            resBox.classList.remove('hidden');

            try {
                const params = new URLSearchParams();
                if (host) params.append('host', host);
                if (port) params.append('port', port);
                if (sid) params.append('sid', sid);
                if (user) params.append('user', user);
                if (pwd) params.append('password', pwd);

                const res = await fetch(`/api/tria/ping?${params.toString()}`);
                const data = await res.json();
                if (data.success && data.connected) {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-emerald-50 text-emerald-900 border border-emerald-300';
                    resBox.innerHTML = `
                        <div class="flex items-center justify-between border-b border-emerald-200/80 pb-1.5 mb-2">
                            <span class="font-bold text-sm text-emerald-800 flex items-center space-x-1.5">
                                <i class="fa-solid fa-circle-check text-emerald-600"></i>
                                <span>Oracle Bağlantısı Başarılı</span>
                            </span>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-200 text-emerald-900 font-mono">${data.latency_ms} ms</span>
                        </div>
                        <div class="text-[11px] text-emerald-800 space-y-1">
                            <div>Host: <strong class="font-mono text-emerald-950">${data.host}:${data.port}/${data.sid}</strong> (Kullanıcı: <strong>${data.user}</strong>)</div>
                            <div>Oracle Sürüm: <strong>${data.version || '11.2'}</strong></div>
                            <div>Kayıtlı Veri: <strong>${(data.stats && data.stats.recete_sayisi) ? data.stats.recete_sayisi.toLocaleString() : '-'}</strong> Reçete, <strong>${(data.stats && data.stats.kayitli_urun_sayisi) ? data.stats.kayitli_urun_sayisi.toLocaleString() : '-'}</strong> Kayıtlı Ürün</div>
                        </div>
                    `;
                    updateHeaderTriaStatus(true, data);
                    showToast('Oracle Bağlantısı Başarılı', `Tria veritabanına ${data.latency_ms} ms içinde bağlanıldı.`, 'success');
                } else {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                    resBox.innerHTML = `
                        <div class="font-bold text-sm text-red-800 flex items-center space-x-1.5 mb-1">
                            <i class="fa-solid fa-circle-xmark text-red-600"></i>
                            <span>Bağlantı Başarısız (${data.latency_ms || 0} ms)</span>
                        </div>
                        <div class="text-[11px] text-red-700">
                            <strong>Hata Detayı:</strong> ${data.message || data.error || 'Veritabanı yanıt vermedi.'}
                        </div>
                    `;
                    updateHeaderTriaStatus(false, data);
                }
            } catch(e) {
                resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                resBox.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5 text-red-600"></i>Bağlantı hatası: ${e.message}`;
                updateHeaderTriaStatus(false);
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        }

        function updateHeaderTriaStatus(connected, data) {
            window.triaStatus = {
                connected: !!connected,
                latency_ms: (data && data.latency_ms) ? data.latency_ms : null
            };
            const hostBadge = document.getElementById('triaHostSubBadge');
            const tabTriaBadge = document.getElementById('tabTriaBadge');

            if (hostBadge && data && data.host) {
                hostBadge.innerText = `${data.host} (${data.user || 'TRIA'})`;
            }
            if (tabTriaBadge) {
                tabTriaBadge.className = connected
                    ? 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold'
                    : 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold';
                tabTriaBadge.innerText = connected ? 'Bağlı' : 'Kesildi';
            }
            refreshHeaderActiveOtomasyon();
        }

        async function checkTriaStatusOnLoad() {
            try {
                const res = await fetch('/api/tria/ping');
                const data = await res.json();
                updateHeaderTriaStatus(data.success && data.connected, data);
            } catch(e) {
                updateHeaderTriaStatus(false);
            }
        }

        // ==========================================
        // DEPO AKTİF / PASİF YÖNETİMİ & VALIDASYONU
        // ==========================================
        const DEPO_LIST = ['alliance', 'selcuk', 'nevzat', 'iskoop', 'bek', 'ecza1', 'farmazon', 'dna', 'eczatrend', 'eczanetakas'];

        function hasDepoCredentials(depo) {
            if (depo === 'alliance') {
                const p = (document.getElementById('cfg_alliance_pcode')?.value || '').trim();
                const u = (document.getElementById('cfg_alliance_user')?.value || '').trim();
                const pwd = (document.getElementById('cfg_alliance_pwd')?.value || '').trim();
                return !!(p && u && pwd);
            }
            if (depo === 'nevzat') {
                const a = (document.getElementById('cfg_nevzat_account')?.value || '').trim();
                const u = (document.getElementById('cfg_nevzat_user')?.value || '').trim();
                const pwd = (document.getElementById('cfg_nevzat_pwd')?.value || '').trim();
                return !!(a && u && pwd);
            }
            const u = (document.getElementById(`cfg_${depo}_user`)?.value || '').trim();
            const pwd = (document.getElementById(`cfg_${depo}_pwd`)?.value || '').trim();
            return !!(u && pwd);
        }

        function updateDepoCardUI(depo) {
            const chk = document.getElementById(`cfg_${depo}_active`);
            const badge = document.getElementById(`badge_${depo}_status`);
            const card = document.getElementById(`card_${depo}`);
            if (!chk || !badge) return;

            const hasCreds = hasDepoCredentials(depo);

            if (!hasCreds) {
                chk.checked = false;
                badge.className = 'hidden';
                badge.innerHTML = '';
                if (card) {
                    card.classList.add('opacity-70');
                    card.classList.remove('ring-2', 'ring-emerald-400');
                }
            } else if (chk.checked) {
                badge.className = 'text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 inline-block';
                badge.innerHTML = '● Aktif';
                if (card) {
                    card.classList.remove('opacity-70');
                }
            } else {
                badge.className = 'text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200 inline-block';
                badge.innerHTML = '○ Pasif';
                if (card) {
                    card.classList.add('opacity-70');
                    card.classList.remove('ring-2', 'ring-emerald-400');
                }
            }
        }

        function updateDepoTabSummary() {
            const summaryBadge = document.getElementById('depoTabSummaryBadge');
            let activeCount = 0;
            DEPO_LIST.forEach(d => {
                const chk = document.getElementById(`cfg_${d}_active`);
                const hasCreds = hasDepoCredentials(d);
                if (chk && chk.checked && hasCreds) {
                    activeCount++;
                }
            });
            if (summaryBadge) {
                summaryBadge.innerHTML = `<span class="inline-flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span> <strong class="text-emerald-800">${activeCount} Depo Aktif</strong></span>`;
            }
        }

        function onDepoActiveToggle(depo) {
            const chk = document.getElementById(`cfg_${depo}_active`);
            if (!chk) return;
            const hasCreds = hasDepoCredentials(depo);
            if (chk.checked && !hasCreds) {
                chk.checked = false;
                const feedback = document.getElementById('settingsFeedback');
                if (feedback) {
                    feedback.className = 'p-3 rounded-xl text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200 mb-3 block';
                    feedback.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5 text-amber-600"></i><strong>${depo.toUpperCase()}</strong> için kullanıcı adı ve şifre girilmediğinden aktif edilemez.`;
                    feedback.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }
            } else {
                if (!chk.checked) {
                    chk.dataset.manuallyDeactivated = "true";
                } else {
                    delete chk.dataset.manuallyDeactivated;
                }
            }
            updateDepoCardUI(depo);
            updateDepoTabSummary();
        }

        function onDepoCredInput(depo) {
            const chk = document.getElementById(`cfg_${depo}_active`);
            if (!chk) return;
            const hasCreds = hasDepoCredentials(depo);
            if (!hasCreds) {
                chk.checked = false;
            } else if (!chk.dataset.manuallyDeactivated) {
                chk.checked = true;
            }
            updateDepoCardUI(depo);
            updateDepoTabSummary();
        }

        function updateHeaderDepoBadge(activeCount, totalCount = 7) {
            const text = document.getElementById('headerDepoText');
            const dot = document.getElementById('headerDepoDot');
            const btn = document.getElementById('headerDepoBadgeBtn');
            if (!text || !dot) return;

            if (activeCount > 0) {
                text.innerText = `${activeCount} Depo Aktif`;
                dot.className = "w-2 h-2 rounded-full bg-emerald-500 mr-0.5";
                if (btn) btn.className = "inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border border-emerald-200 bg-emerald-50/90 text-emerald-800 text-xs font-semibold hover:bg-emerald-100 transition shadow-sm cursor-pointer";
            } else {
                text.innerText = "0 Depo Aktif";
                dot.className = "w-2 h-2 rounded-full bg-slate-400 mr-0.5";
                if (btn) btn.className = "inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 text-xs font-semibold hover:bg-slate-100 transition shadow-sm cursor-pointer";
            }
        }

        async function refreshDepoStatusBadge() {
            try {
                const res = await fetch('/api/settings/credentials');
                if (res.ok) {
                    const c = await res.json();
                    let activeCount = 0;
                    DEPO_LIST.forEach(d => {
                        if (c[d] && (c[d].active === "1" || c[d].active === true || c[d].active === 1)) {
                            activeCount++;
                        }
                    });
                    updateHeaderDepoBadge(activeCount, DEPO_LIST.length);
                }
            } catch(e) {
                console.error("Depo durum bilgisi alınamadı:", e);
            }
        }

        async function openSettingsModal(defaultTab = null) {
            const modal = document.getElementById('settingsModal');
            const feedback = document.getElementById('settingsFeedback');
            if (feedback) feedback.className = 'hidden';

            const activeOtoUpper = (window.activeOtomasyon || 'TRIA').toUpperCase();
            const activeTab = defaultTab || (activeOtoUpper === 'TEBEOS' ? 'tebeos' : (activeOtoUpper === 'TRIA' ? 'tria' : 'botanik'));
            switchSettingsTab(activeTab);
            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
            }

            try {
                const res = await fetch('/api/settings/credentials');
                if (res.ok) {
                    const c = await res.json();
                    if (c.active_otomasyon) {
                        selectActiveOtomasyon(c.active_otomasyon, defaultTab !== null ? false : true);
                    }
                    if (c.alliance) {
                        document.getElementById('cfg_alliance_pcode').value = c.alliance.pharmacy_code || '';
                        document.getElementById('cfg_alliance_user').value = c.alliance.username || '';
                        document.getElementById('cfg_alliance_pwd').value = c.alliance.password || '';
                    }
                    if (c.selcuk) {
                        document.getElementById('cfg_selcuk_user').value = c.selcuk.username || '';
                        document.getElementById('cfg_selcuk_pwd').value = c.selcuk.password || '';
                    }
                    if (c.nevzat) {
                        document.getElementById('cfg_nevzat_account').value = c.nevzat.account_code || '';
                        document.getElementById('cfg_nevzat_user').value = c.nevzat.username || '';
                        document.getElementById('cfg_nevzat_pwd').value = c.nevzat.password || '';
                    }
                    if (c.iskoop) {
                        document.getElementById('cfg_iskoop_user').value = c.iskoop.username || '';
                        document.getElementById('cfg_iskoop_pwd').value = c.iskoop.password || '';
                    }
                    if (c.bek) {
                        document.getElementById('cfg_bek_user').value = c.bek.username || '';
                        document.getElementById('cfg_bek_pwd').value = c.bek.password || '';
                    }
                    if (c.ecza1) {
                        document.getElementById('cfg_ecza1_user').value = c.ecza1.username || '';
                        document.getElementById('cfg_ecza1_pwd').value = c.ecza1.password || '';
                    }
                    if (c.farmazon) {
                        document.getElementById('cfg_farmazon_user').value = c.farmazon.username || '';
                        document.getElementById('cfg_farmazon_pwd').value = c.farmazon.password || '';
                    }
                    if (c.dna) {
                        document.getElementById('cfg_dna_user').value = c.dna.username || '';
                        document.getElementById('cfg_dna_pwd').value = c.dna.password || '';
                    }
                    if (c.eczatrend) {
                        document.getElementById('cfg_eczatrend_user').value = c.eczatrend.username || '';
                        document.getElementById('cfg_eczatrend_pwd').value = c.eczatrend.password || '';
                    }
                    if (c.eczanetakas) {
                        document.getElementById('cfg_eczanetakas_user').value = c.eczanetakas.username || '';
                        document.getElementById('cfg_eczanetakas_pwd').value = c.eczanetakas.password || '';
                    }
                    if (c.tria) {
                        document.getElementById('cfg_tria_host').value = c.tria.host || '192.168.1.155';
                        document.getElementById('cfg_tria_port').value = c.tria.port || '1521';
                        document.getElementById('cfg_tria_sid').value = c.tria.sid || 'ORCL';
                        document.getElementById('cfg_tria_user').value = c.tria.user || 'ARASTIRMA';
                        document.getElementById('cfg_tria_pwd').value = c.tria.password || 'ARASTIRMA';
                    }
                    if (c.botanik) {
                        document.getElementById('cfg_botanik_server').value = c.botanik.server || 'DESKTOP-L6GG7P6\\BOTANIKSQL';
                        document.getElementById('cfg_botanik_db').value = c.botanik.database || 'eczane';
                        document.getElementById('cfg_botanik_user').value = c.botanik.user || 'sa';
                        document.getElementById('cfg_botanik_pwd').value = c.botanik.password || '123';
                        document.getElementById('cfg_botanik_trusted').checked = (c.botanik.trusted === 'true' || c.botanik.trusted === true);
                    }
                    if (c.tebeos) {
                        document.getElementById('cfg_tebeos_host').value = c.tebeos.host || '192.168.1.11';
                        document.getElementById('cfg_tebeos_port').value = c.tebeos.port || '5454';
                        document.getElementById('cfg_tebeos_db').value = c.tebeos.database || 'tebeos_db';
                        document.getElementById('cfg_tebeos_user').value = c.tebeos.user || 'tebeos';
                        document.getElementById('cfg_tebeos_pwd').value = c.tebeos.password || '123';
                    }
                    if (c.active_otomasyon) {
                        const sel = document.getElementById('cfg_active_otomasyon');
                        if (sel) sel.value = c.active_otomasyon;
                    }

                    // Depo Kartlarının Aktif/Pasif durumlarını ve rozetlerini ayarla
                    DEPO_LIST.forEach(d => {
                        const chk = document.getElementById(`cfg_${d}_active`);
                        if (!chk) return;
                        const dData = c[d] || {};
                        const isActive = dData.active === "1" || dData.active === true || dData.active === 1;
                        chk.checked = isActive;
                        if (!isActive && hasDepoCredentials(d)) {
                            chk.dataset.manuallyDeactivated = "true";
                        } else {
                            delete chk.dataset.manuallyDeactivated;
                        }
                        updateDepoCardUI(d);
                    });
                    updateDepoTabSummary();
                }
            } catch(e) {
                console.error("Ayarlar yüklenemedi:", e);
            }
        }

        function closeSettingsModal() {
            const modal = document.getElementById('settingsModal');
            if (modal) {
                modal.style.display = 'none';
                modal.classList.add('hidden');
            }
        }

        // Modal dışına tıklandığında kazara kapanmayı engelle (kullanıcı sadece X veya Vazgeç butonuyla kapatabilir)
        // window.addEventListener('click', function(e) { if (e.target === modal) closeSettingsModal(); });

        async function saveSettings() {
            const btn = document.getElementById('saveSettingsBtn');
            const feedback = document.getElementById('settingsFeedback');
            const origHtml = btn.innerHTML;

            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i><span>Kaydediliyor...</span>`;
            feedback.className = 'hidden';

            const payload = {
                alliance: {
                    pharmacy_code: document.getElementById('cfg_alliance_pcode').value.trim(),
                    username: document.getElementById('cfg_alliance_user').value.trim(),
                    password: document.getElementById('cfg_alliance_pwd').value.trim(),
                    active: document.getElementById('cfg_alliance_active').checked ? "1" : "0"
                },
                selcuk: {
                    username: document.getElementById('cfg_selcuk_user').value.trim(),
                    password: document.getElementById('cfg_selcuk_pwd').value.trim(),
                    active: document.getElementById('cfg_selcuk_active').checked ? "1" : "0"
                },
                nevzat: {
                    account_code: document.getElementById('cfg_nevzat_account').value.trim(),
                    username: document.getElementById('cfg_nevzat_user').value.trim(),
                    password: document.getElementById('cfg_nevzat_pwd').value.trim(),
                    active: document.getElementById('cfg_nevzat_active').checked ? "1" : "0"
                },
                iskoop: {
                    username: document.getElementById('cfg_iskoop_user').value.trim(),
                    password: document.getElementById('cfg_iskoop_pwd').value.trim(),
                    active: document.getElementById('cfg_iskoop_active').checked ? "1" : "0"
                },
                bek: {
                    username: document.getElementById('cfg_bek_user').value.trim(),
                    password: document.getElementById('cfg_bek_pwd').value.trim(),
                    active: document.getElementById('cfg_bek_active').checked ? "1" : "0"
                },
                ecza1: {
                    username: document.getElementById('cfg_ecza1_user').value.trim(),
                    password: document.getElementById('cfg_ecza1_pwd').value.trim(),
                    active: document.getElementById('cfg_ecza1_active').checked ? "1" : "0"
                },
                farmazon: {
                    username: document.getElementById('cfg_farmazon_user').value.trim(),
                    password: document.getElementById('cfg_farmazon_pwd').value.trim(),
                    active: document.getElementById('cfg_farmazon_active').checked ? "1" : "0"
                },
                dna: {
                    username: document.getElementById('cfg_dna_user').value.trim(),
                    password: document.getElementById('cfg_dna_pwd').value.trim(),
                    active: document.getElementById('cfg_dna_active').checked ? "1" : "0"
                },
                eczatrend: {
                    username: document.getElementById('cfg_eczatrend_user').value.trim(),
                    password: document.getElementById('cfg_eczatrend_pwd').value.trim(),
                    active: document.getElementById('cfg_eczatrend_active').checked ? "1" : "0"
                },
                eczanetakas: {
                    username: document.getElementById('cfg_eczanetakas_user').value.trim(),
                    password: document.getElementById('cfg_eczanetakas_pwd').value.trim(),
                    active: document.getElementById('cfg_eczanetakas_active').checked ? "1" : "0"
                },
                tria: {
                    host: document.getElementById('cfg_tria_host').value.trim(),
                    port: document.getElementById('cfg_tria_port').value.trim(),
                    sid: document.getElementById('cfg_tria_sid').value.trim(),
                    user: document.getElementById('cfg_tria_user').value.trim(),
                    password: document.getElementById('cfg_tria_pwd').value.trim()
                },
                botanik: {
                    server: document.getElementById('cfg_botanik_server').value.trim(),
                    database: document.getElementById('cfg_botanik_db').value.trim(),
                    user: document.getElementById('cfg_botanik_user').value.trim(),
                    password: document.getElementById('cfg_botanik_pwd').value.trim(),
                    trusted: document.getElementById('cfg_botanik_trusted').checked ? 'true' : 'false'
                },
                tebeos: {
                    host: document.getElementById('cfg_tebeos_host').value.trim(),
                    port: document.getElementById('cfg_tebeos_port').value.trim(),
                    database: document.getElementById('cfg_tebeos_db').value.trim(),
                    user: document.getElementById('cfg_tebeos_user').value.trim(),
                    password: document.getElementById('cfg_tebeos_pwd').value.trim()
                },
                active_otomasyon: document.getElementById('cfg_active_otomasyon') ? document.getElementById('cfg_active_otomasyon').value : 'TRIA'
            };

            try {
                const res = await fetch('/api/settings/credentials', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const data = await res.json();
                if (res.ok && data.success) {
                    feedback.className = 'p-3 rounded-xl text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 block';
                    feedback.innerHTML = `
                        <div class="flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-circle-check text-emerald-600 text-sm"></i><span>${data.message || 'Ayarlar ve tercihler başarıyla kaydedildi!'}</span></span>
                            <button type="button" onclick="closeSettingsModal()" class="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition shadow-xs cursor-pointer">Kapat</button>
                        </div>
                    `;
                    feedback.classList.remove('hidden');
                    refreshDepoStatusBadge();
                    checkBotanikStatusOnLoad();
                    checkTriaStatusOnLoad();
                    checkTebeosStatusOnLoad();
                    if (typeof loadCriticalStockList === 'function') loadCriticalStockList(true);
                    showToast('Ayarlar Kaydedildi', 'Tüm tercihler ve bağlantı bilgileri kaydedildi.', 'success');
                } else {
                    throw new Error(data.error || 'Kaydetme sırasında bir hata oluştu');
                }
            } catch(e) {
                feedback.className = 'p-3 rounded-xl text-xs font-semibold bg-red-50 text-red-800 border border-red-200 block';
                feedback.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${e.message}`;
                feedback.classList.remove('hidden');
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        }

        // ==========================================
        // E-TİCARET & PİYASA FİYAT KIYASLAMA MODÜLÜ JS
        // ==========================================
        window.currentMarketReport = null;
        window.currentSelectedMarketPlatform = 'ALL';

        function switchMainView(tab) {
            const btnDepo = document.getElementById('mainTabDepo');
            const btnSmart = document.getElementById('mainTabSmartOrder');
            const btnMarket = document.getElementById('mainTabMarket');
            const viewDepo = document.getElementById('viewDepo');
            const viewSmart = document.getElementById('viewSmartOrder');
            const viewMarket = document.getElementById('viewMarket');

            const inactiveBtnCls = 'py-3 px-4 sm:px-5 border-b-2 border-transparent text-slate-500 hover:text-slate-900 font-semibold text-sm flex items-center space-x-2 transition cursor-pointer shrink-0';

            if (viewDepo) viewDepo.classList.add('hidden');
            if (viewSmart) viewSmart.classList.add('hidden');
            if (viewMarket) viewMarket.classList.add('hidden');

            if (btnDepo) btnDepo.className = inactiveBtnCls;
            if (btnSmart) btnSmart.className = inactiveBtnCls;
            if (btnMarket) btnMarket.className = inactiveBtnCls;

            if (tab === 'depo') {
                if (viewDepo) viewDepo.classList.remove('hidden');
                if (btnDepo) btnDepo.className = 'py-3 px-4 sm:px-5 border-b-2 border-emerald-600 text-emerald-800 font-bold text-sm flex items-center space-x-2 transition cursor-pointer shrink-0';
            } else if (tab === 'smart_order') {
                if (viewSmart) viewSmart.classList.remove('hidden');
                if (btnSmart) btnSmart.className = 'py-3 px-4 sm:px-5 border-b-2 border-amber-500 text-amber-900 font-bold text-sm flex items-center space-x-2 transition cursor-pointer shrink-0 bg-amber-50/40';
                if (!window.smartOrderLoadedOnce) {
                    loadSmartOrderList(false);
                }
            } else if (tab === 'market') {
                if (viewMarket) viewMarket.classList.remove('hidden');
                if (btnMarket) btnMarket.className = 'py-3 px-4 sm:px-5 border-b-2 border-indigo-600 text-indigo-800 font-bold text-sm flex items-center space-x-2 transition cursor-pointer shrink-0';

                const marketInput = document.getElementById('marketSearchInput');
                const depoInput = document.getElementById('searchInput');
                if (marketInput && !marketInput.value && depoInput && depoInput.value) {
                    marketInput.value = depoInput.value;
                }
                if (marketInput) marketInput.focus();
            }
        }

        // =========================================================================
        // BOTANİK 6 AYLIK ÇIKIŞ & AKILLI TOPLU SİPARİŞ PLANLAMA MODÜLÜ JS
        // =========================================================================
        window.smartOrderItems = [];
        window.smartOrderFiltered = [];
        window.smartOrderMonths = [];
        window.smartOrderScope = 'today';
        window.smartTargetDays = 15;
        window.smartTrendFilter = 'ALL';
        window.smartStockMaxDays = 21;
        window.smartRowDepos = {};
        window.smartRowCustomQty = {};
        window.smartOrderLoadedOnce = false;
        window.isSmartMfScanning = false;

        function parseMfPair(mfStr) {
            if (!mfStr || mfStr === 'YOK' || mfStr === '-') return null;
            const m = String(mfStr).match(/(\\d+)\\s*\\+\\s*(\\d+)/);
            if (!m) return null;
            const alinan = parseInt(m[1]) || 0;
            const hediye = parseInt(m[2]) || 0;
            if (alinan <= 0 || hediye <= 0) return null;
            return { alinan, hediye, text: `${alinan}+${hediye}` };
        }

        function normalizeDepoCode(rawDepo) {
            if (!rawDepo) return 'ALLIANCE';
            const u = String(rawDepo).toUpperCase();
            if (u.includes('SELCUK') || u.includes('SELÇUK')) return 'SELCUK';
            if (u.includes('ISKOOP') || u.includes('İSKOOP')) return 'ISKOOP';
            if (u.includes('NEVZAT')) return 'NEVZAT';
            if (u.includes('ALLIANCE') || u.includes('HEDEF')) return 'ALLIANCE';
            return 'ALLIANCE';
        }

        async function loadSmartOrderList(force = false, customSearch = null) {
            const tbody = document.getElementById('smartOrderTableBody');
            const refreshIcon = document.getElementById('smartOrderRefreshIcon');
            if (refreshIcon) refreshIcon.classList.add('fa-spin');

            if (tbody && (force || !window.smartOrderLoadedOnce)) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="15" class="py-12 text-center text-slate-500 text-sm">
                            <i class="fa-solid fa-spinner fa-spin text-amber-500 mr-2 text-lg"></i>Botanik veritabanından 6 aylık çıkışlar, stok yeterliliği ve geçmiş MF'ler hesaplanıyor...
                        </td>
                    </tr>
                `;
            }

            try {
                const qParam = customSearch !== null ? customSearch : '';
                const url = `/api/botanik/smart-order-list?scope=${encodeURIComponent(window.smartOrderScope)}&q=${encodeURIComponent(qParam)}&target_days=${window.smartTargetDays}&limit=250&force=${force}`;
                const res = await fetch(url);
                if (!res.ok) throw new Error('Botanik 6 aylık analiz servisi yanıt vermedi');
                const data = await res.json();

                window.smartOrderLoadedOnce = true;
                window.smartOrderItems = data.items || [];
                window.smartOrderMonths = data.months || [];

                // Ay sütun başlıklarını güncelle
                if (window.smartOrderMonths.length > 0) {
                    window.smartOrderMonths.forEach((m, idx) => {
                        const th = document.getElementById(`smartMonthCol_${idx}`);
                        if (th) {
                            th.innerText = m.short || m.label || `Ay ${idx + 1}`;
                            th.title = m.label || '';
                        }
                    });
                }

                // Sekme rozetini güncelle
                const tabBadge = document.getElementById('smartOrderTabBadge');
                if (tabBadge) {
                    tabBadge.innerText = `${window.smartOrderItems.length} Ürün`;
                }

                recalculateSmartOrderClientSide(true);
                renderSmartOrderTable();

                // Arka planda canlı MF taramasını başlat
                setTimeout(() => resolveAllSmartOrderMfs(false), 250);
            } catch (e) {
                console.error('Smart order list error:', e);
                if (tbody) {
                    tbody.innerHTML = `
                        <tr>
                            <td colspan="15" class="py-8 text-center text-rose-600 text-xs bg-rose-50">
                                <i class="fa-solid fa-circle-exclamation mr-1.5 text-base"></i>6 Aylık çıkış listesi alınamadı: ${e.message}
                            </td>
                        </tr>
                    `;
                }
            } finally {
                if (refreshIcon) refreshIcon.classList.remove('fa-spin');
            }
        }

        function changeSmartOrderScope(newScope) {
            window.smartOrderScope = newScope;
            const scopes = ['today', 'week', 'top6m'];
            const ids = { 'today': 'btnSmartScopeToday', 'week': 'btnSmartScopeWeek', 'top6m': 'btnSmartScopeTop6m' };
            scopes.forEach(s => {
                const el = document.getElementById(ids[s]);
                if (!el) return;
                if (s === newScope) {
                    el.className = 'px-3 py-2 rounded-xl text-xs font-extrabold bg-emerald-600 text-white shadow-xs transition cursor-pointer flex items-center gap-1.5';
                } else {
                    el.className = 'px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer flex items-center gap-1.5';
                }
            });
            if (newScope === 'top6m') {
                setSmartStockMaxDays(999, false);
            }
            loadSmartOrderList(false);
        }

        function searchBotanikInSmartOrder() {
            const inp = document.getElementById('smartOrderSearchInput');
            const val = inp ? inp.value.trim() : '';
            if (!val) {
                loadSmartOrderList(false);
                return;
            }
            window.smartOrderScope = 'search';
            setSmartStockMaxDays(999, false);
            loadSmartOrderList(true, val);
        }

        function setSmartTargetDays(daysVal) {
            const d = Math.max(1, Math.min(180, parseInt(daysVal) || 15));
            window.smartTargetDays = d;

            const customInp = document.getElementById('smartCustomDaysInput');
            if (customInp) customInp.value = d;

            const lbl = document.getElementById('smartTargetDaysLabel');
            if (lbl) lbl.innerText = d === 1 ? 'Hedef: 1 Günlük (Anlık Eksik)' : `Hedef: ${d} Günlük Stok`;

            [1, 7, 10, 15, 21, 30, 45, 60].forEach(preset => {
                const btn = document.getElementById(`btnSmartDays_${preset}`);
                if (!btn) return;
                if (preset === d) {
                    btn.className = 'px-2.5 py-1.5 rounded-lg text-xs font-black bg-amber-600 text-white border border-amber-700 shadow-xs transition cursor-pointer';
                } else {
                    btn.className = 'px-2.5 py-1.5 rounded-lg text-xs font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 transition cursor-pointer';
                }
            });

            recalculateSmartOrderClientSide(true);
            renderSmartOrderTable();
            showToast('Tahmini Sipariş Hedefi Güncellendi', `Tüm ilaçların önerilen sipariş rakamları ${d} günlük hedef stoğa göre yeniden hesaplandı.`, 'success');
        }

        function applyRecommendedToAllInputs() {
            window.smartRowCustomQty = {};
            recalculateSmartOrderClientSide(true);
            renderSmartOrderTable();
            showToast('Önerilen Rakamlar Uygulandı', `Tüm satırlardaki sipariş kutuları ${window.smartTargetDays} günlük akıllı öneriye eşitlendi.`, 'success');
        }

        function setSmartTrendFilter(filterMode) {
            window.smartTrendFilter = filterMode;
            const kpis = {
                'ALL': { id: 'smartKpiAll', active: 'p-3 rounded-2xl bg-white/20 border-2 border-emerald-400 cursor-pointer transition', passive: 'p-3 rounded-2xl bg-white/10 border border-white/15 cursor-pointer transition hover:bg-white/15' },
                'STABIL': { id: 'smartKpiStabil', active: 'p-3 rounded-2xl bg-emerald-900/80 border-2 border-emerald-400 cursor-pointer transition', passive: 'p-3 rounded-2xl bg-emerald-950/50 border border-emerald-500/40 cursor-pointer transition hover:bg-emerald-900/50' },
                'AZALAN': { id: 'smartKpiAzalan', active: 'p-3 rounded-2xl bg-rose-900/80 border-2 border-rose-400 cursor-pointer transition', passive: 'p-3 rounded-2xl bg-rose-950/50 border border-rose-500/40 cursor-pointer transition hover:bg-rose-900/50' },
                'ARTAN': { id: 'smartKpiArtan', active: 'p-3 rounded-2xl bg-sky-900/80 border-2 border-sky-400 cursor-pointer transition', passive: 'p-3 rounded-2xl bg-sky-950/50 border border-sky-500/40 cursor-pointer transition hover:bg-sky-900/50' },
                'MF_ONLY': { id: 'smartKpiMf', active: 'p-3 rounded-2xl bg-amber-900/80 border-2 border-amber-400 cursor-pointer transition', passive: 'p-3 rounded-2xl bg-amber-950/50 border border-amber-500/40 cursor-pointer transition hover:bg-amber-900/50' },
                'ORDERED': { id: 'smartKpiOrdered', active: 'p-3 rounded-2xl bg-indigo-900/80 border-2 border-indigo-400 cursor-pointer transition', passive: 'p-3 rounded-2xl bg-indigo-950/50 border border-indigo-400/40 cursor-pointer transition hover:bg-indigo-900/50' }
            };
            Object.keys(kpis).forEach(k => {
                const el = document.getElementById(kpis[k].id);
                if (el) el.className = (k === filterMode) ? kpis[k].active : kpis[k].passive;
            });
            renderSmartOrderTable();
        }

        function setSmartStockMaxDays(maxDays, shouldRender = true) {
            window.smartStockMaxDays = maxDays;
            [21, 14, 0, 999].forEach(val => {
                const btn = document.getElementById(`btnSmartStock_${val}`);
                if (!btn) return;
                if (val === maxDays) {
                    btn.className = 'px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-slate-900 text-white transition cursor-pointer';
                } else {
                    btn.className = 'px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer';
                }
            });
            if (shouldRender) renderSmartOrderTable();
        }

        function recalculateSmartOrderClientSide(resetCustomQty = false) {
            const autoRoundMfEl = document.getElementById('smartAutoRoundMfCheck');
            const autoRoundMf = autoRoundMfEl ? autoRoundMfEl.checked : true;
            const tDays = window.smartTargetDays || 15;

            (window.smartOrderItems || []).forEach(it => {
                const stok = it.stok || 0;
                const bugun = it.bugun_cikis || 0;
                const gunlukHiz = it.gunluk_hiz || 0;
                const son2Ort = it.son2_ort || 0;
                const ilk4Ort = it.ilk4_ort || 0;
                const ort6m = it.ort_aylik_6m || 0;
                const stokGun = it.stok_gun !== undefined ? it.stok_gun : 999;
                const trend = it.trend_kodu || 'STABIL';

                let effHiz = gunlukHiz;
                if (trend === 'AZALAN') {
                    effHiz = Math.min(gunlukHiz, son2Ort / 30.0);
                } else if (trend === 'ARTAN') {
                    effHiz = Math.max(gunlukHiz, son2Ort / 30.0);
                }

                let hamIhtiyac = 0;
                if (tDays <= 1) {
                    if (stok <= 0) {
                        hamIhtiyac = Math.max(1, bugun || 1);
                    } else if (stok < bugun) {
                        hamIhtiyac = Math.max(1, bugun - stok);
                    } else if (stokGun <= 3) {
                        hamIhtiyac = Math.max(1, Math.ceil(effHiz * 2));
                    } else {
                        hamIhtiyac = 0;
                    }
                } else {
                    const hedefToplam = Math.ceil(effHiz * tDays);
                    hamIhtiyac = Math.max(0, hedefToplam - Math.max(0, stok));
                    if (stok <= 0 && (bugun > 0 || it.toplam_6ay > 0) && hamIhtiyac <= 0) {
                        hamIhtiyac = Math.max(1, bugun || 1);
                    }
                    if (trend === 'AZALAN' && stok > 0 && stokGun >= 10) {
                        hamIhtiyac = 0;
                    } else if (trend === 'AZALAN' && hamIhtiyac > 0) {
                        const maxSafe = Math.max(1, Math.ceil((son2Ort / 30.0) * Math.min(tDays, 10)));
                        hamIhtiyac = Math.min(hamIhtiyac, maxSafe);
                    }
                }

                let onerilen = hamIhtiyac;
                let oneriMetni = '';

                // MF bilgisi (önce canlı MF, yoksa geçmiş MF)
                const liveMfObj = parseMfPair(it.mf_metni);
                const pastMfObj = it.gecmis_mf_var && it.gecmis_mf_min_alim > 0
                    ? { alinan: it.gecmis_mf_min_alim, hediye: it.gecmis_mf_bedelsiz || 1, text: it.gecmis_mf_kisa || `${it.gecmis_mf_min_alim}+${it.gecmis_mf_bedelsiz || 1}` }
                    : null;
                const activeMf = liveMfObj || pastMfObj;

                if (trend === 'AZALAN') {
                    if (onerilen <= 0) {
                        oneriMetni = `⚠️ Çıkışı son zamanlarda azaldı (${ilk4Ort} → ${son2Ort} kt/ay). Mevcut ${stok} kutu yeterli, sipariş önerilmez.`;
                    } else {
                        oneriMetni = `⚠️ Çıkışı azalıyor (${ilk4Ort} → ${son2Ort} kt/ay). Stok şişmemesi için sadece ${onerilen} kutu önerilir.`;
                    }
                } else if (trend === 'STABIL' || trend === 'ARTAN') {
                    if (autoRoundMf && activeMf && activeMf.alinan > 1) {
                        const minA = activeMf.alinan;
                        const mfCoverDays = minA / Math.max(0.15, effHiz);
                        if (hamIhtiyac >= Math.ceil(minA * 0.6) && hamIhtiyac <= minA && mfCoverDays <= Math.max(60, tDays * 2.2)) {
                            onerilen = minA;
                            const mfSourceLbl = liveMfObj ? `${it.mf_depo || 'Depo'} Canlı MF (${activeMf.text})` : `Geçmiş MF (${activeMf.text})`;
                            oneriMetni = `🎁 ${trend === 'STABIL' ? 'Stabil' : 'Artan'} çıkışlı! ${mfSourceLbl} yakalamak için ${minA} kutu önerilir.`;
                        }
                    }
                    if (!oneriMetni) {
                        if (onerilen > 0) {
                            oneriMetni = `${trend === 'STABIL' ? '🟢 Stabil çıkıyor' : '📈 Çıkışı artıyor'} (Aylık ~${ort6m} kt). ${tDays} günlük hedef için ${onerilen} kutu önerilir.`;
                        } else {
                            oneriMetni = `✅ Raf stoğu (${stok} kt / ${stokGun} gün) ${tDays} günlük hedef için yeterli.`;
                        }
                    }
                } else {
                    if (onerilen > 0) {
                        oneriMetni = `⚡ Aralıklı çıkıyor. ${tDays} günlük hedef için ${onerilen} kutu önerilir.`;
                    } else {
                        oneriMetni = `Mevcut stok (${stok} kt) yeterli.`;
                    }
                }

                it.onerilen_siparis = onerilen;
                it.oneri_metni = oneriMetni;

                const key = it.barkod || it.urun_kodu || it.urun_adi;
                if (resetCustomQty || window.smartRowCustomQty[key] === undefined) {
                    window.smartRowCustomQty[key] = Math.max(1, onerilen > 0 ? onerilen : (bugun > 0 ? bugun : 1));
                }
                if (it.mf_depo && (!window.smartRowDepos[key])) {
                    window.smartRowDepos[key] = normalizeDepoCode(it.mf_depo);
                }
            });

            updateSmartKpiCounters();
        }

        function updateSmartKpiCounters() {
            const all = window.smartOrderItems || [];
            const setTxt = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = val; };
            setTxt('smartStatTotal', all.length);
            setTxt('smartStatStabil', all.filter(x => x.trend_kodu === 'STABIL').length);
            setTxt('smartStatAzalan', all.filter(x => x.trend_kodu === 'AZALAN').length);
            setTxt('smartStatArtan', all.filter(x => x.trend_kodu === 'ARTAN').length);
            setTxt('smartStatMf', all.filter(x => (x.mf_metni && x.mf_metni !== 'YOK') || x.gecmis_mf_var).length);
            setTxt('smartStatOrdered', all.filter(x => !!x.siparis_durumu).length);
        }

        function renderSmartOrderTable() {
            const tbody = document.getElementById('smartOrderTableBody');
            if (!tbody) return;

            const searchInp = document.getElementById('smartOrderSearchInput');
            const q = searchInp ? searchInp.value.trim().toLowerCase() : '';
            const hideOrdEl = document.getElementById('smartHideOrderedCheck');
            const hideOrdered = hideOrdEl ? hideOrdEl.checked : false;
            const maxDays = window.smartStockMaxDays !== undefined ? window.smartStockMaxDays : 21;
            const tFilter = window.smartTrendFilter || 'ALL';

            const filtered = (window.smartOrderItems || []).filter(it => {
                if (hideOrdered && it.siparis_durumu === 'SIPARIS_VERILDI') return false;

                // Stok gün filtresi
                if (maxDays === 0) {
                    if ((it.stok || 0) > 0) return false;
                } else if (maxDays < 900) {
                    if ((it.stok || 0) > 0 && (it.stok_gun || 0) > maxDays) return false;
                }

                // Trend / KPI filtresi
                if (tFilter === 'STABIL' && it.trend_kodu !== 'STABIL') return false;
                if (tFilter === 'AZALAN' && it.trend_kodu !== 'AZALAN') return false;
                if (tFilter === 'ARTAN' && it.trend_kodu !== 'ARTAN') return false;
                if (tFilter === 'MF_ONLY') {
                    const hasMf = (it.mf_metni && it.mf_metni !== 'YOK') || !!it.gecmis_mf_var;
                    if (!hasMf) return false;
                }
                if (tFilter === 'ORDERED' && !it.siparis_durumu) return false;

                // Arama filtresi (eğer scope=search değilse yerel filtrele)
                if (q && window.smartOrderScope !== 'search') {
                    const nm = (it.urun_adi || '').toLowerCase();
                    const bc = (it.barkod || '').toLowerCase();
                    if (!nm.includes(q) && !bc.includes(q)) return false;
                }
                return true;
            });

            window.smartOrderFiltered = filtered;

            if (filtered.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="15" class="py-10 text-center text-slate-400 text-xs">
                            <i class="fa-solid fa-filter-circle-xmark text-2xl text-slate-300 mb-2 block"></i>
                            Seçili filtre kriterlerine uyan ilaç bulunamadı. Üstteki "Tüm Stoklar" veya "Toplam Kalem" kartına tıklayarak filtreyi genişletebilirsiniz.
                        </td>
                    </tr>
                `;
                updateSmartSelectionSummary();
                return;
            }

            tbody.innerHTML = filtered.map((it, idx) => {
                const key = it.barkod || it.urun_kodu || it.urun_adi;
                const safeBc = (it.barkod || '').replace(/'/g, "\\'");
                const safeName = (it.urun_adi || '').replace(/'/g, "\\'");
                const stok = it.stok || 0;
                const stokGun = it.stok_gun !== undefined ? it.stok_gun : 999;

                // Stok rozeti
                let stockBadge = '';
                if (stok <= 0) {
                    stockBadge = `<span class="px-2 py-0.5 rounded-lg text-[10px] font-black bg-rose-100 text-rose-800 border border-rose-300 block">TÜKENDİ (0)</span>`;
                } else if (stokGun <= 7) {
                    stockBadge = `<span class="px-2 py-0.5 rounded-lg text-[10px] font-black bg-rose-50 text-rose-700 border border-rose-200 block">🔥 ${stok} Kt (${stokGun} G)</span>`;
                } else if (stokGun <= 14) {
                    stockBadge = `<span class="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200 block">⚠️ ${stok} Kt (${stokGun} G)</span>`;
                } else if (stokGun <= 21) {
                    stockBadge = `<span class="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-sky-50 text-sky-800 border border-sky-200 block">📦 ${stok} Kt (${stokGun} G)</span>`;
                } else {
                    stockBadge = `<span class="px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200 block">✅ ${stok} Kt (${stokGun > 180 ? '180+' : stokGun} G)</span>`;
                }

                // 6 Aylık hücreler
                const aylikDetay = it.aylik_detay || [];
                let monthCellsHtml = '';
                for (let mIdx = 0; mIdx < 6; mIdx++) {
                    const mObj = aylikDetay[mIdx] || { toplam: 0, nakit: 0, recete: 0 };
                    const val = mObj.toplam || 0;
                    const isCur = mIdx === 5;
                    const cellBg = isCur ? 'bg-emerald-50/40 font-black text-emerald-950' : (val > 0 ? 'text-slate-800 font-bold' : 'text-slate-300');
                    monthCellsHtml += `
                        <td class="py-2.5 px-2 text-center font-mono ${cellBg}" title="${mObj.label || ''}: Toplam ${val} Kutu (${mObj.recete || 0} SGK Reçete + ${mObj.nakit || 0} Elden)">
                            ${val}
                        </td>
                    `;
                }

                // Trend Rozeti
                let trendBadge = '';
                if (it.trend_kodu === 'STABIL') {
                    trendBadge = `
                        <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-black bg-emerald-100 text-emerald-900 border border-emerald-300">
                            🟢 Stabil Çıkan
                        </span>
                        <div class="text-[10px] text-slate-500 mt-0.5 leading-tight">${it.trend_uyari || 'Düzenli satıyor'}</div>
                    `;
                } else if (it.trend_kodu === 'AZALAN') {
                    trendBadge = `
                        <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-black bg-rose-100 text-rose-900 border border-rose-300 animate-pulse">
                            📉 Çıkışı Azalan!
                        </span>
                        <div class="text-[10px] text-rose-700 font-bold mt-0.5 leading-tight">${it.trend_uyari || 'Son aylarda satış düştü, fazla stok yapmayın'}</div>
                    `;
                } else if (it.trend_kodu === 'ARTAN') {
                    trendBadge = `
                        <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-black bg-sky-100 text-sky-900 border border-sky-300">
                            📈 Çıkışı Artan
                        </span>
                        <div class="text-[10px] text-sky-800 font-semibold mt-0.5 leading-tight">${it.trend_uyari || 'Son aylarda talep yükseldi'}</div>
                    `;
                } else {
                    trendBadge = `
                        <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-50 text-amber-900 border border-amber-200">
                            ${it.trend_etiket || '⚡ Aralıklı'}
                        </span>
                        <div class="text-[10px] text-slate-500 mt-0.5 leading-tight">${it.trend_uyari || ''}</div>
                    `;
                }

                // Şu Anki Canlı MF ve Geçmiş MF Sütunu
                const hasLiveMf = it.mf_metni && it.mf_metni !== 'YOK';
                const livePair = parseMfPair(it.mf_metni);
                let mfColHtml = '';
                if (hasLiveMf) {
                    const clickQty = livePair ? livePair.alinan : 10;
                    const clickDepo = normalizeDepoCode(it.mf_depo);
                    mfColHtml += `
                        <button type="button" onclick="applySmartMfToRow(${idx}, ${clickQty}, '${clickDepo}', '${it.mf_metni}')" class="mb-1 inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg text-[10px] font-black bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-xs transition cursor-pointer" title="Tıklayın: Sipariş adedini ${clickQty} kutu yap ve depoyu ${it.mf_depo || 'Depo'} seç">
                            <i class="fa-solid fa-gift text-[9px]"></i>
                            <span>Şu An: ${it.mf_metni}</span>
                            <span class="bg-black/25 px-1 rounded text-[9px]">${it.mf_depo || 'Depo'}</span>
                        </button>
                    `;
                } else {
                    mfColHtml += `
                        <div class="mb-1 flex items-center space-x-1">
                            <span class="text-[10px] text-slate-400">Canlı MF: Yok</span>
                            <button type="button" onclick="resolveSingleSmartRowMf(${idx})" class="text-[10px] text-indigo-600 hover:text-indigo-800 underline font-bold cursor-pointer" title="Bu ilacın şu anki depo MF'sini canlı sorgula">Sorgula</button>
                        </div>
                    `;
                }

                if (it.gecmis_mf_var) {
                    const pastQty = it.gecmis_mf_min_alim || 10;
                    const pastDepo = normalizeDepoCode(it.gecmis_mf_depo);
                    mfColHtml += `
                        <button type="button" onclick="applySmartMfToRow(${idx}, ${pastQty}, '${pastDepo}', '${it.gecmis_mf_kisa || ''}')" class="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 transition cursor-pointer block" title="${it.gecmis_mf_bilgi || 'Geçmiş faturada MF ile alınmış'} — Tıklayınca miktarı ${pastQty} yapar">
                            <i class="fa-solid fa-star text-amber-500 text-[9px]"></i>
                            <span>Geçmiş: ${it.gecmis_mf_kisa || 'MFLİ'}</span>
                        </button>
                    `;
                }

                // Sipariş Durumu Rozeti
                let orderStatusBadge = '';
                let rowBgClass = 'hover:bg-slate-50/90';
                if (it.siparis_durumu === 'SIPARIS_VERILDI') {
                    rowBgClass = 'bg-emerald-50/40 opacity-80';
                    orderStatusBadge = `
                        <div class="mt-1 inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[9px] font-black">
                            <i class="fa-solid fa-circle-check"></i>
                            <span>SİPARİŞ VERİLDİ • ${it.siparis_depo || 'DEPO'} (${it.siparis_miktar || 1} Kt)</span>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event); setTimeout(()=>loadSmartOrderList(true), 400);" class="ml-1 underline hover:text-rose-200 cursor-pointer">İptal×</button>
                        </div>
                    `;
                } else if (it.siparis_durumu === 'SEPETTE') {
                    rowBgClass = 'bg-amber-50/30';
                    orderStatusBadge = `
                        <div class="mt-1 inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md bg-amber-100 text-amber-950 border border-amber-300 text-[9px] font-extrabold">
                            <i class="fa-solid fa-cart-shopping text-amber-600"></i>
                            <span>SEPETTE • ${it.siparis_depo || 'DEPO'} (${it.siparis_miktar || 1} Kt)</span>
                            <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeName}', '${it.siparis_depo || 'ALLIANCE'}', ${it.siparis_miktar || 1}); setTimeout(()=>loadSmartOrderList(true), 400);" class="px-1 rounded bg-emerald-600 text-white cursor-pointer">✓Onayla</button>
                        </div>
                    `;
                }

                const curQty = window.smartRowCustomQty[key] !== undefined ? window.smartRowCustomQty[key] : Math.max(1, it.onerilen_siparis || 1);
                const curDepo = window.smartRowDepos[key] || normalizeDepoCode(it.mf_depo) || 'ALLIANCE';
                window.smartRowDepos[key] = curDepo;

                const isDefaultChecked = (!it.siparis_durumu) && ((it.onerilen_siparis || 0) > 0) && (it.trend_kodu !== 'AZALAN' || stok <= 0);

                return `
                    <tr class="${rowBgClass} transition">
                        <td class="py-2.5 px-3 text-center align-middle">
                            <input 
                                type="checkbox" 
                                class="smartRowCheck rounded text-sky-600 focus:ring-sky-500 w-4 h-4 cursor-pointer" 
                                data-idx="${idx}"
                                onchange="updateSmartSelectionSummary()"
                                ${isDefaultChecked ? 'checked' : ''}
                            />
                        </td>
                        <td class="py-2.5 px-3 align-middle">
                            <div class="font-extrabold text-xs text-slate-900 hover:text-emerald-700 cursor-pointer leading-snug" onclick="searchFromCritical('${safeBc}', '${safeName}')" title="Tüm depolarda detaylı karşılaştırmak için tıklayın">
                                ${it.urun_adi}
                            </div>
                            <div class="flex flex-wrap items-center gap-1.5 mt-0.5 text-[10px] text-slate-400 font-mono">
                                <span>${it.barkod || '-'}</span>
                                ${it.psf > 0 ? `<span>•</span><span class="text-slate-600 font-bold">PSF: ${it.psf.toFixed(2)} ₺</span>` : ''}
                                <button type="button" onclick="searchFromCritical('${safeBc}', '${safeName}')" class="text-emerald-600 hover:underline font-sans font-bold ml-1 cursor-pointer">6 Depo Kıyasla ↗</button>
                            </div>
                            ${orderStatusBadge}
                        </td>
                        <td class="py-2.5 px-2.5 text-center align-middle">
                            ${stockBadge}
                        </td>
                        <td class="py-2.5 px-2 text-center align-middle bg-amber-50/30 font-mono font-black text-amber-700">
                            ${it.bugun_cikis > 0 ? `🔥 ${it.bugun_cikis}` : '0'}
                        </td>
                        ${monthCellsHtml}
                        <td class="py-2.5 px-2.5 text-center align-middle bg-slate-100/70">
                            <div class="font-black text-slate-900 font-mono text-xs">${it.toplam_6ay || 0} Kt</div>
                            <div class="text-[10px] text-slate-500 font-semibold">${it.ort_aylik_6m || 0}/Ay • ${it.gunluk_hiz || 0}/G</div>
                        </td>
                        <td class="py-2.5 px-3 align-middle">
                            ${trendBadge}
                        </td>
                        <td class="py-2.5 px-3 align-middle" id="smartMfCell_${idx}">
                            ${mfColHtml}
                        </td>
                        <td class="py-2.5 px-3 align-middle">
                            <div class="flex items-center space-x-1.5">
                                <span class="px-2 py-0.5 rounded bg-indigo-50 text-indigo-900 border border-indigo-200 font-black font-mono text-[11px]">
                                    Öneri: ${it.onerilen_siparis || 0} Kt
                                </span>
                                ${(it.onerilen_siparis || 0) > 0 && curQty !== it.onerilen_siparis ? `
                                    <button type="button" onclick="setSmartRowQty(${idx}, ${it.onerilen_siparis})" class="text-[10px] text-indigo-600 hover:underline font-bold cursor-pointer">Uygula</button>
                                ` : ''}
                            </div>
                            <div class="text-[10px] text-slate-600 mt-1 leading-snug">${it.oneri_metni || ''}</div>
                        </td>
                        <td class="py-2.5 px-3 align-middle text-right">
                            <div class="flex items-center justify-end space-x-1.5">
                                <!-- Miktar Ayarlayıcı -->
                                <div class="inline-flex items-center bg-slate-100 rounded-xl p-0.5 border border-slate-300">
                                    <button type="button" onclick="changeSmartRowQty(${idx}, -1)" class="w-6 h-6 rounded-lg bg-white hover:bg-slate-200 text-slate-800 font-black text-xs cursor-pointer shadow-2xs">-</button>
                                    <input 
                                        type="number" 
                                        id="smartQtyInput_${idx}" 
                                        value="${curQty}" 
                                        min="1" 
                                        max="999"
                                        oninput="onSmartRowQtyInput(${idx}, this.value)"
                                        class="w-11 text-center font-black font-mono text-xs text-slate-900 bg-transparent focus:outline-none"
                                    />
                                    <button type="button" onclick="changeSmartRowQty(${idx}, 1)" class="w-6 h-6 rounded-lg bg-white hover:bg-slate-200 text-slate-800 font-black text-xs cursor-pointer shadow-2xs">+</button>
                                </div>

                                <!-- Hedef Depo Seçici -->
                                <select 
                                    id="smartDepoSelect_${idx}" 
                                    onchange="onSmartRowDepoChange(${idx}, this.value)"
                                    class="py-1.5 px-2 rounded-xl text-[11px] font-extrabold border border-slate-300 bg-white text-slate-800 focus:outline-none focus:border-sky-500 cursor-pointer"
                                >
                                    <option value="ALLIANCE" ${curDepo === 'ALLIANCE' ? 'selected' : ''}>Alliance</option>
                                    <option value="SELCUK" ${curDepo === 'SELCUK' ? 'selected' : ''}>Selçuk</option>
                                    <option value="ISKOOP" ${curDepo === 'ISKOOP' ? 'selected' : ''}>İSKOOP</option>
                                    <option value="NEVZAT" ${curDepo === 'NEVZAT' ? 'selected' : ''}>Nevzat</option>
                                </select>

                                <!-- Tekil Sepete At Butonu -->
                                <button 
                                    type="button" 
                                    id="btnSmartSingleAdd_${idx}"
                                    onclick="sendSingleSmartRowToDepo(${idx})" 
                                    class="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] shadow-xs transition cursor-pointer shrink-0"
                                    title="Bu ilacı seçili rakamla doğrudan sepete gönder"
                                >
                                    <i class="fa-solid fa-cart-plus"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');

            updateSmartSelectionSummary();
        }

        function setSmartRowQty(idx, val) {
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it) return;
            const key = it.barkod || it.urun_kodu || it.urun_adi;
            const clean = Math.max(1, parseInt(val) || 1);
            window.smartRowCustomQty[key] = clean;
            const inp = document.getElementById(`smartQtyInput_${idx}`);
            if (inp) inp.value = clean;
            updateSmartSelectionSummary();
        }

        function changeSmartRowQty(idx, delta) {
            const inp = document.getElementById(`smartQtyInput_${idx}`);
            if (!inp) return;
            const cur = parseInt(inp.value) || 1;
            setSmartRowQty(idx, Math.max(1, cur + delta));
        }

        function onSmartRowQtyInput(idx, val) {
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it) return;
            const key = it.barkod || it.urun_kodu || it.urun_adi;
            window.smartRowCustomQty[key] = Math.max(1, parseInt(val) || 1);
            updateSmartSelectionSummary();
        }

        function onSmartRowDepoChange(idx, depoCode) {
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it) return;
            const key = it.barkod || it.urun_kodu || it.urun_adi;
            window.smartRowDepos[key] = depoCode;
        }

        function applySmartMfToRow(idx, minAlimQty, depoCode, mfText) {
            setSmartRowQty(idx, minAlimQty);
            onSmartRowDepoChange(idx, depoCode);
            const sel = document.getElementById(`smartDepoSelect_${idx}`);
            if (sel) sel.value = depoCode;
            const chk = document.querySelector(`.smartRowCheck[data-idx="${idx}"]`);
            if (chk) chk.checked = true;
            updateSmartSelectionSummary();
            showToast('MF Kademesi Uygulandı', `Sipariş rakamı ${mfText || minAlimQty} MF şartı için ${minAlimQty} kutu (${depoCode}) olarak ayarlandı.`, 'success');
        }

        function toggleSmartSelectAll(master) {
            const checks = document.querySelectorAll('.smartRowCheck');
            checks.forEach(c => { c.checked = master.checked; });
            updateSmartSelectionSummary();
        }

        function selectSmartByTrend(mode) {
            const checks = document.querySelectorAll('.smartRowCheck');
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (!it || it.siparis_durumu === 'SIPARIS_VERILDI') {
                    c.checked = false;
                    return;
                }
                if (mode === 'STABIL') {
                    c.checked = (it.trend_kodu === 'STABIL' && (it.onerilen_siparis || 0) > 0);
                } else if (mode === 'MF') {
                    c.checked = !!((it.mf_metni && it.mf_metni !== 'YOK') || it.gecmis_mf_var);
                }
            });
            updateSmartSelectionSummary();
        }

        function updateSmartSelectionSummary() {
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            let totalBoxes = 0;
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const inp = document.getElementById(`smartQtyInput_${idx}`);
                totalBoxes += inp ? (parseInt(inp.value) || 1) : 1;
            });
            const cntBadge = document.getElementById('smartSelectedCountBadge');
            const boxBadge = document.getElementById('smartSelectedBoxesBadge');
            if (cntBadge) cntBadge.innerText = `${checks.length} Kalem Seçili`;
            if (boxBadge) boxBadge.innerText = `Toplam ${totalBoxes} Kutu`;
        }

        async function resolveSingleSmartRowMf(idx) {
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it || !it.barkod) return;
            const cell = document.getElementById(`smartMfCell_${idx}`);
            if (cell) cell.innerHTML = `<span class="text-[10px] text-amber-600 font-bold"><i class="fa-solid fa-spinner fa-spin mr-1"></i>Sorgulanıyor...</span>`;
            try {
                const res = await fetch('/api/otomasyon/resolve-mf', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barcodes: [it.barkod] })
                });
                const data = await res.json();
                const mfInfo = data.results ? data.results[it.barkod] : null;
                if (mfInfo && mfInfo.mf) {
                    it.mf_metni = mfInfo.mf;
                    it.mf_depo = mfInfo.depo || 'Depo';
                    recalculateSmartOrderClientSide(false);
                    renderSmartOrderTable();
                    showToast('Canlı MF Bulundu', `${it.urun_adi}: ${mfInfo.mf} MF (${mfInfo.depo})`, 'success');
                } else {
                    renderSmartOrderTable();
                    showToast('MF Bulunamadı', `${it.urun_adi} için şu an aktif depo MF'si görünmüyor.`, 'info');
                }
            } catch (e) {
                renderSmartOrderTable();
            }
        }

        async function resolveAllSmartOrderMfs(manualClick = false) {
            if (window.isSmartMfScanning) return;
            const list = window.smartOrderFiltered && window.smartOrderFiltered.length > 0 ? window.smartOrderFiltered : (window.smartOrderItems || []);
            const targets = list.filter(it => it.barkod && (!it.mf_metni || manualClick)).slice(0, 40).map(it => it.barkod);
            if (targets.length === 0) {
                if (manualClick) showToast('MF Taraması Tamam', 'Listedeki ürünlerin güncel MF bilgileri zaten yüklü.', 'info');
                return;
            }

            window.isSmartMfScanning = true;
            const progBadge = document.getElementById('smartMfScanProgressBadge');
            const btnIcon = document.getElementById('smartResolveMfIcon');
            if (progBadge) progBadge.classList.remove('hidden');
            if (btnIcon) btnIcon.className = 'fa-solid fa-spinner fa-spin text-sm';

            try {
                const res = await fetch('/api/otomasyon/resolve-mf', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barcodes: targets })
                });
                if (res.ok) {
                    const data = await res.json();
                    const results = data.results || {};
                    let foundCount = 0;
                    (window.smartOrderItems || []).forEach(it => {
                        if (it.barkod && results[it.barkod] && results[it.barkod].mf) {
                            it.mf_metni = results[it.barkod].mf;
                            it.mf_depo = results[it.barkod].depo || 'Depo';
                            foundCount++;
                        }
                    });
                    if (foundCount > 0) {
                        recalculateSmartOrderClientSide(false);
                        renderSmartOrderTable();
                    }
                    if (manualClick) {
                        showToast('Canlı MF Taraması Tamamlandı', `${targets.length} ürün tarandı, ${foundCount} üründe aktif depo MF şartı bulundu.`, 'success');
                    }
                }
            } catch (e) {
                console.error('Smart MF batch error:', e);
            } finally {
                window.isSmartMfScanning = false;
                if (progBadge) progBadge.classList.add('hidden');
                if (btnIcon) btnIcon.className = 'fa-solid fa-gift text-sm';
            }
        }

        async function sendSingleSmartRowToDepo(idx) {
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it) return;
            const inp = document.getElementById(`smartQtyInput_${idx}`);
            const sel = document.getElementById(`smartDepoSelect_${idx}`);
            const btn = document.getElementById(`btnSmartSingleAdd_${idx}`);
            const qty = inp ? (parseInt(inp.value) || 1) : 1;
            const depo = sel ? sel.value : 'ALLIANCE';

            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i>`;
            }
            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        barkod: it.barkod,
                        urun_id: it.barkod,
                        miktar: qty,
                        name: it.urun_adi || ''
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast(`${depo} Sepetine Eklendi`, `${it.urun_adi} x${qty} kutu sepete aktarıldı.`, 'success');
                    it.siparis_durumu = 'SEPETTE';
                    it.siparis_depo = depo;
                    it.siparis_miktar = qty;
                    renderSmartOrderTable();
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    showToast('Sepet Hatası', data.message || 'Ürün eklenemedi.', 'error');
                }
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = `<i class="fa-solid fa-cart-plus"></i>`;
                }
            }
        }

        async function markSelectedSmartItemsOrdered() {
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yok', 'Lütfen işaretlemek için en az bir ilaç seçin.', 'info');
                return;
            }
            const itemsPayload = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (!it) return;
                const inp = document.getElementById(`smartQtyInput_${idx}`);
                const sel = document.getElementById(`smartDepoSelect_${idx}`);
                itemsPayload.push({
                    barkod: it.barkod || '',
                    urun_adi: it.urun_adi || '',
                    depo: sel ? sel.value : 'MANUEL',
                    miktar: inp ? (parseInt(inp.value) || 1) : 1
                });
            });
            try {
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ durum: 'SIPARIS_VERILDI', depo: 'TOPLU', items: itemsPayload })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Ortak Sipariş Takibine İşlendi', `${itemsPayload.length} kalem ilaç tüm bilgisayarlarda 'Sipariş Verildi' olarak işaretlendi.`, 'success');
                    await loadSmartOrderList(true);
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function triggerSmartBulkOrder(depoKodu = 'ALLIANCE') {
            const depo = (depoKodu || 'ALLIANCE').toUpperCase();
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', 'Lütfen sepete aktarmak istediğiniz ilaçları tablodan seçiniz.', 'info');
                return;
            }

            const itemsToOrder = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (it && it.barkod) {
                    const inp = document.getElementById(`smartQtyInput_${idx}`);
                    const qty = inp ? (parseInt(inp.value) || 1) : 1;
                    itemsToOrder.push({
                        barcode: it.barkod,
                        name: it.urun_adi,
                        miktar: qty
                    });
                }
            });

            await executeBulkOrderWithItems(depo, itemsToOrder);
        }

        async function triggerSmartBulkOrderByRowDepo() {
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', 'Lütfen dağıtılacak ilaçları tablodan seçiniz.', 'info');
                return;
            }
            const groups = {};
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (it && it.barkod) {
                    const inp = document.getElementById(`smartQtyInput_${idx}`);
                    const sel = document.getElementById(`smartDepoSelect_${idx}`);
                    const qty = inp ? (parseInt(inp.value) || 1) : 1;
                    const d = sel ? sel.value : 'ALLIANCE';
                    if (!groups[d]) groups[d] = [];
                    groups[d].push({ barcode: it.barkod, name: it.urun_adi, miktar: qty });
                }
            });

            const depoKeys = Object.keys(groups);
            if (depoKeys.length === 1) {
                await executeBulkOrderWithItems(depoKeys[0], groups[depoKeys[0]]);
                return;
            }

            // Birden fazla depoya dağıtım
            const firstDepo = depoKeys[0];
            await executeBulkOrderWithItems(firstDepo, groups[firstDepo]);
            for (let i = 1; i < depoKeys.length; i++) {
                const dKey = depoKeys[i];
                window.currentBulkState.missingItems = groups[dKey];
                await transferMissingItemsTo(dKey);
            }
            await loadSmartOrderList(true);
        }

        async function executeBulkOrderWithItems(depo, itemsToOrder) {
            const cfg = DEPO_BULK_CONFIGS[depo] || DEPO_BULK_CONFIGS['ALLIANCE'];
            window.currentBulkState = {
                depo: depo,
                initialDepo: depo,
                requestedItems: itemsToOrder,
                depoSessions: {},
                missingItems: [],
                allResults: itemsToOrder.map(it => ({
                    barcode: it.barcode,
                    name: it.name,
                    miktar: it.miktar,
                    status: 'PENDING',
                    assigned_depo: null,
                    net_fiyat: 0,
                    vade: 30,
                    message: 'İşleniyor...'
                }))
            };
            window.activeBulkResultTab = 'ALL';

            const modal = document.getElementById('bulkOrderModal');
            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
            }

            const modalTitle = document.getElementById('bulkModalTitle');
            const modalDesc = document.getElementById('bulkModalDesc');
            const modalIcon = document.getElementById('bulkModalIcon');
            const modalTargetDepo = document.getElementById('bulkModalTargetDepo');
            const modalCartLink = document.getElementById('bulkModalCartLink');
            const modalCartText = document.getElementById('bulkModalCartBtnText');

            if (modalTitle) modalTitle.innerText = cfg.title;
            if (modalDesc) modalDesc.innerText = cfg.desc;
            if (modalTargetDepo) modalTargetDepo.innerText = `${cfg.name} B2B`;
            if (modalIcon) modalIcon.className = cfg.icon;
            if (modalCartLink) modalCartLink.href = cfg.cartUrl;
            if (modalCartText) modalCartText.innerText = cfg.cartBtnText;

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');
            const statTotal = document.getElementById('bulkStatTotal');
            const statSuccess = document.getElementById('bulkStatSuccess');
            const statFailed = document.getElementById('bulkStatFailed');
            const statAmount = document.getElementById('bulkStatAmount');

            if (statTotal) statTotal.innerText = itemsToOrder.length;
            if (statSuccess) statSuccess.innerText = '0';
            if (statFailed) statFailed.innerText = '0';
            if (statAmount) statAmount.innerText = '0.00 ₺';
            if (pBar) pBar.style.width = '25%';
            if (pPercent) pPercent.innerText = '%25';
            if (pText) pText.innerText = `${cfg.name} sepetine ${itemsToOrder.length} kalem aktarılıyor...`;
            if (pSpinner) pSpinner.className = 'fa-solid fa-spinner fa-spin text-sky-600';

            renderBulkItemsTable();

            try {
                const res = await fetch('/api/cart/bulk-add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo, items: itemsToOrder, cascade: false })
                });
                const data = await res.json();
                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '%100';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-check text-emerald-600';

                if (data.success || data.success_count > 0 || data.items) {
                    const successCount = data.success_count || 0;
                    const totalAmount = data.total_amount || 0;
                    window.currentBulkState.depoSessions[depo] = {
                        count: successCount,
                        amount: totalAmount,
                        name: cfg.name,
                        cartUrl: cfg.cartUrl
                    };
                    const missing = [];
                    (data.items || []).forEach(r => {
                        const target = window.currentBulkState.allResults.find(it => it.barcode === r.barcode);
                        if (r.success) {
                            if (target) {
                                target.status = 'ADDED';
                                target.assigned_depo = depo;
                                target.net_fiyat = r.net_fiyat || 0;
                                target.vade = r.vade || 30;
                                target.message = r.message || 'Eklendi';
                            }
                        } else {
                            if (target) {
                                target.status = 'YOK';
                                target.message = r.message || 'Stok Yok';
                            }
                            missing.push({
                                barcode: r.barcode,
                                name: r.name || (target ? target.name : r.barcode),
                                miktar: r.miktar || (target ? target.miktar : 1),
                                message: r.message || 'Stok Yok'
                            });
                        }
                    });
                    window.currentBulkState.missingItems = missing;
                    if (statSuccess) statSuccess.innerText = `${successCount} Kalem`;
                    if (statFailed) statFailed.innerText = `${missing.length} Kalem`;
                    if (statAmount) statAmount.innerText = `${totalAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;
                    if (pText) pText.innerHTML = `<strong>Tamamlandı:</strong> ${successCount} Kalem ${cfg.name} sepetine eklendi!`;
                    renderDepoBreakdownPills();
                    renderTransferMissingBar(depo);
                    renderBulkItemsTable();
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                    loadSmartOrderList(true);
                }
            } catch (e) {
                if (pText) pText.innerText = `Hata: ${e.message}`;
            }
        }

        function quickMarketSearch(query, label) {
            const input = document.getElementById('marketSearchInput');
            if (input) input.value = query;
            handleMarketSearchSubmit(query);
        }

        async function handleMarketSearchSubmit(overrideQuery = null) {
            const input = document.getElementById('marketSearchInput');
            const query = (overrideQuery || (input ? input.value : '')).trim();
            if (!query) {
                showToast('Eksik Bilgi', 'Lütfen aramak için bir ilaç/ürün adı veya barkod giriniz', 'error');
                return;
            }

            const loadingEl = document.getElementById('marketLoading');
            const emptyEl = document.getElementById('marketEmptyState');
            const resultsEl = document.getElementById('marketResults');
            const btn = document.getElementById('marketSearchBtn');

            if (loadingEl) loadingEl.classList.remove('hidden');
            if (emptyEl) emptyEl.classList.add('hidden');
            if (resultsEl) resultsEl.classList.add('hidden');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1.5"></i><span>Taranıyor...</span>`;
            }

            try {
                const res = await fetch(`/api/market/search?q=${encodeURIComponent(query)}`);
                if (!res.ok) {
                    const err = await res.json().catch(() => ({}));
                    throw new Error(err.error || `Arama hatası: HTTP ${res.status}`);
                }
                const data = await res.json();
                window.currentMarketReport = data;
                window.currentSelectedMarketPlatform = 'ALL';

                renderMarketReport(data);

                if (loadingEl) loadingEl.classList.add('hidden');
                if (resultsEl) resultsEl.classList.remove('hidden');
                showToast('Piyasa Taraması', `${data.toplam_teklif_sayisi} teklif bulundu`, 'success');
            } catch (err) {
                console.error("Market search error:", err);
                if (loadingEl) loadingEl.classList.add('hidden');
                if (emptyEl) emptyEl.classList.remove('hidden');
                showToast('Tarama Hatası', err.message || 'Piyasa fiyatları alınamadı', 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = `<i class="fa-solid fa-bolt mr-1.5"></i><span>Piyasayı Tara</span>`;
                }
            }
        }

        function renderMarketReport(report) {
            // Header Info
            const titleEl = document.getElementById('marketResTitle');
            const barcodeEl = document.getElementById('marketResBarcode');
            if (titleEl) titleEl.textContent = report.urun_adi || report.aranan_kelime;
            if (barcodeEl) barcodeEl.textContent = report.barkod ? `Barkod: ${report.barkod}` : `Arama: ${report.aranan_kelime}`;

            // KPIs
            const kpiDepoFiyat = document.getElementById('kpiDepoFiyat');
            const kpiDepoAdi = document.getElementById('kpiDepoAdi');
            if (kpiDepoFiyat) {
                kpiDepoFiyat.textContent = report.depo_en_dusuk_fiyat ? `${report.depo_en_dusuk_fiyat.toFixed(2)} ₺` : 'Kayıt Yok';
                kpiDepoFiyat.className = report.depo_en_dusuk_fiyat ? "text-2xl font-black text-emerald-600" : "text-2xl font-black text-slate-400";
            }
            if (kpiDepoAdi) kpiDepoAdi.textContent = report.depo_en_dusuk_adi ? `En Uygun: ${report.depo_en_dusuk_adi}` : 'Depo alış fiyatı bulunamadı';

            const kpiIntFiyat = document.getElementById('kpiInternetFiyat');
            const kpiIntPlat = document.getElementById('kpiInternetPlatform');
            if (kpiIntFiyat) {
                kpiIntFiyat.textContent = report.internet_en_dusuk_fiyat ? `${report.internet_en_dusuk_fiyat.toFixed(2)} ₺` : 'Teklif Yok';
            }
            if (kpiIntPlat) kpiIntPlat.textContent = report.internet_en_dusuk_platform ? `Platform: ${report.internet_en_dusuk_platform}` : 'Piyasada teklif yok';

            const kpiKarFark = document.getElementById('kpiKarFark');
            const kpiKarYuzde = document.getElementById('kpiKarYuzde');
            const kpiKarCard = document.getElementById('kpiKarCard');
            if (kpiKarFark && kpiKarYuzde) {
                if (report.kar_farki_tl !== null) {
                    const isPositive = report.kar_farki_tl >= 0;
                    kpiKarFark.textContent = `${isPositive ? '+' : ''}${report.kar_farki_tl.toFixed(2)} ₺`;
                    kpiKarFark.className = isPositive ? "text-2xl font-black text-emerald-600" : "text-2xl font-black text-red-600";
                    kpiKarYuzde.textContent = `Brüt Kâr: %${report.kar_yuzdesi}`;
                    if (!isPositive && kpiKarCard) {
                        kpiKarCard.classList.add('border-red-300', 'bg-red-50/20');
                    } else if (kpiKarCard) {
                        kpiKarCard.classList.remove('border-red-300', 'bg-red-50/20');
                    }
                } else {
                    kpiKarFark.textContent = '-';
                    kpiKarYuzde.textContent = 'Maliyet veya satış eksik';
                }
            }

            const kpiOrt = document.getElementById('kpiOrtalamaFiyat');
            const kpiYuk = document.getElementById('kpiYuksekFiyat');
            const kpiTop = document.getElementById('kpiToplamTeklif');
            if (kpiOrt) kpiOrt.textContent = report.internet_ortalama_fiyat ? `${report.internet_ortalama_fiyat.toFixed(2)} ₺` : '- ₺';
            if (kpiYuk) kpiYuk.textContent = report.internet_en_yuksek_fiyat ? `${report.internet_en_yuksek_fiyat.toFixed(2)} ₺` : '- ₺';
            if (kpiTop) kpiTop.textContent = `${report.platform_sayisi} Farklı Platformda ${report.toplam_teklif_sayisi} Teklif`;

            // Cheaper Warning
            const warningEl = document.getElementById('marketCheaperWarning');
            const warningText = document.getElementById('marketCheaperText');
            if (warningEl && warningText) {
                if (report.internet_depodan_ucuz && report.internet_en_dusuk_fiyat && report.depo_en_dusuk_fiyat) {
                    warningEl.classList.remove('hidden');
                    const diff = Math.abs(report.kar_farki_tl).toFixed(2);
                    warningText.innerHTML = `İnternet en ucuz perakende satış fiyatı (<b>${report.internet_en_dusuk_fiyat.toFixed(2)} ₺</b> - ${report.internet_en_dusuk_platform}), en ucuz ecza deposu alış maliyetinden (<b>${report.depo_en_dusuk_fiyat.toFixed(2)} ₺</b> - ${report.depo_en_dusuk_adi}) <b>${diff} ₺ daha ucuzdur!</b> Piyasada damping veya serbest fiyat rekabeti bulunmaktadır. Bu üründe stok yaparken dikkatli olunuz.`;
                } else {
                    warningEl.classList.add('hidden');
                }
            }

            // Render Wholesale Depo List (Left Column)
            renderDepoOzetList(report.depo_fiyatlari, report.depo_en_dusuk_fiyat);

            // Render Platform Filter Bar (Right Column)
            renderPlatformFilterChips(report.teklifler);

            // Render Retail Offers (Right Column)
            renderRetailOffersList(report.teklifler, report.depo_en_dusuk_fiyat);
        }

        function renderDepoOzetList(depoList, lowestCost) {
            const listEl = document.getElementById('depoFiyatlariList');
            const countEl = document.getElementById('depoOzetCount');
            if (!listEl) return;
            if (countEl) countEl.textContent = `${depoList.length} Depo Kaydı`;

            if (!depoList || depoList.length === 0) {
                listEl.innerHTML = `
                    <div class="py-6 text-center text-xs text-slate-400">
                        <i class="fa-solid fa-boxes-packing text-2xl mb-2 text-slate-300"></i>
                        <p>Bu ürün için ecza depolarında kayıtlı alış şartı bulunamadı veya ürün doğrudan üretici/ithalatçı kanallı OTC ürünü.</p>
                    </div>
                `;
                return;
            }

            const depoColors = {
                'ALLIANCE': 'border-l-sky-500 bg-sky-50/30 text-sky-800',
                'SELCUK': 'border-l-emerald-500 bg-emerald-50/30 text-emerald-800',
                'NEVZAT': 'border-l-orange-500 bg-orange-50/30 text-orange-800',
                'ISKOOP': 'border-l-red-500 bg-red-50/30 text-red-800',
                'BEK': 'border-l-teal-500 bg-teal-50/30 text-teal-800',
                'FARMAZON': 'border-l-amber-500 bg-amber-50/30 text-amber-800',
                'ECZA1': 'border-l-purple-500 bg-purple-50/30 text-purple-800',
                'DNA': 'border-l-cyan-500 bg-cyan-50/30 text-cyan-800',
                'ECZATREND': 'border-l-orange-500 bg-orange-50/30 text-orange-800',
                'ECZANETAKAS': 'border-l-sky-500 bg-sky-50/30 text-sky-800',
            };

            let html = '';
            depoList.forEach(df => {
                const isBest = lowestCost && Math.abs(df.net_birim_maliyet_kdvli - lowestCost) < 0.05;
                const colorCls = depoColors[df.depo] || 'border-l-slate-400 bg-slate-50 text-slate-800';

                html += `
                    <div class="py-3 px-3 rounded-xl border-l-4 ${colorCls} my-1.5 transition hover:bg-slate-50">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-1.5">
                                <span class="font-bold text-xs text-slate-900">${df.depo_adi}</span>
                                ${isBest ? '<span class="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-emerald-600 text-white">EN İYİ</span>' : ''}
                            </div>
                            <span class="text-sm font-black text-slate-900">${df.net_birim_maliyet_kdvli.toFixed(2)} ₺</span>
                        </div>
                        <div class="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                            <span>MF: <b class="text-slate-700 font-semibold">${df.mf_metni}</b></span>
                            <span>KDV Hariç: <b>${df.net_birim_maliyet.toFixed(2)} ₺</b></span>
                        </div>
                        <div class="mt-1 flex items-center justify-between text-[10px] text-slate-400">
                            <span>Stok: <b class="${df.stok_durumu === 'VAR' ? 'text-emerald-600' : 'text-slate-500'}">${df.stok_durumu}${df.stok_adedi ? ` (${df.stok_adedi} adet)` : ''}</b></span>
                            ${df.miad ? `<span>Miad: ${df.miad}</span>` : ''}
                        </div>
                    </div>
                `;
            });
            listEl.innerHTML = html;
        }

        function renderPlatformFilterChips(offers) {
            const barEl = document.getElementById('platformFilterBar');
            if (!barEl) return;

            // Count per platform
            const counts = {};
            offers.forEach(o => {
                counts[o.platform] = (counts[o.platform] || 0) + 1;
            });

            const platformNames = {
                'TRENDYOL': 'Trendyol',
                'HEPSIBURADA': 'Hepsiburada',
                'DERMOECZANEM': 'Dermoeczanem',
                'SACHANE': 'Sachane',
                'DERMOKOZMETIKA': 'Dermokozmetika',
                'KIRMIZIBEYAZ': 'Kırmızıbeyaz',
                'DERMOJET': 'Dermojet',
                'KOZVIT': 'Kozvit',
                'DAFFNE': 'Daffne',
            };

            let html = `
                <button onclick="filterMarketPlatform('ALL')" class="px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${window.currentSelectedMarketPlatform === 'ALL' ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'}">
                    Tüm Platformlar (${offers.length})
                </button>
            `;

            Object.keys(counts).forEach(pKey => {
                const isSelected = window.currentSelectedMarketPlatform === pKey;
                const pName = platformNames[pKey] || pKey;
                html += `
                    <button onclick="filterMarketPlatform('${pKey}')" class="px-3 py-1.5 rounded-xl text-xs font-semibold transition shrink-0 cursor-pointer ${isSelected ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'}">
                        ${pName} (${counts[pKey]})
                    </button>
                `;
            });

            barEl.innerHTML = html;
        }

        function filterMarketPlatform(platformKey) {
            window.currentSelectedMarketPlatform = platformKey;
            if (!window.currentMarketReport) return;

            renderPlatformFilterChips(window.currentMarketReport.teklifler);

            let filtered = window.currentMarketReport.teklifler;
            if (platformKey !== 'ALL') {
                filtered = filtered.filter(o => o.platform === platformKey);
            }
            renderRetailOffersList(filtered, window.currentMarketReport.depo_en_dusuk_fiyat);
        }

        function togglePlatformOffers(platKey) {
            const drawer = document.getElementById(`platDrawer_${platKey}`);
            const chevron = document.getElementById(`platChevron_${platKey}`);
            if (!drawer) return;
            if (drawer.classList.contains('hidden')) {
                drawer.classList.remove('hidden');
                if (chevron) chevron.style.transform = 'rotate(180deg)';
            } else {
                drawer.classList.add('hidden');
                if (chevron) chevron.style.transform = 'rotate(0deg)';
            }
        }

        function renderRetailOffersList(offers, depoCost) {
            const listEl = document.getElementById('retailOffersList');
            if (!listEl) return;

            if (!offers || offers.length === 0) {
                listEl.innerHTML = `
                    <div class="bg-white p-8 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
                        Bu platformda veya kriterde teklif bulunamadı.
                    </div>
                `;
                return;
            }

            const platformBadges = {
                'TRENDYOL': { bg: 'bg-orange-500', text: 'Trendyol', icon: 'fa-tag', border: 'border-orange-200' },
                'HEPSIBURADA': { bg: 'bg-amber-600', text: 'Hepsiburada', icon: 'fa-tag', border: 'border-amber-200' },
                'SACHANE': { bg: 'bg-pink-600', text: 'Sachane', icon: 'fa-scissors', border: 'border-pink-200' },
                'DERMOECZANEM': { bg: 'bg-emerald-600', text: 'Dermoeczanem', icon: 'fa-shield-heart', border: 'border-emerald-200' },
                'DERMOKOZMETIKA': { bg: 'bg-indigo-600', text: 'Dermokozmetika', icon: 'fa-sparkles', border: 'border-indigo-200' },
                'KIRMIZIBEYAZ': { bg: 'bg-rose-600', text: 'Kırmızıbeyaz', icon: 'fa-plus', border: 'border-rose-200' },
                'DERMOJET': { bg: 'bg-cyan-600', text: 'Dermojet', icon: 'fa-plane', border: 'border-cyan-200' },
                'KOZVIT': { bg: 'bg-purple-600', text: 'Kozvit', icon: 'fa-star', border: 'border-purple-200' },
                'DAFFNE': { bg: 'bg-teal-600', text: 'Daffne', icon: 'fa-leaf', border: 'border-teal-200' },
            };

            // 1. Platform bazında teklifleri grupla
            const groups = {};
            offers.forEach(o => {
                if (!groups[o.platform]) groups[o.platform] = [];
                groups[o.platform].push(o);
            });

            // 2. Her gruptaki teklifleri fiyata göre sırala
            Object.keys(groups).forEach(pKey => {
                groups[pKey].sort((a, b) => a.fiyat - b.fiyat);
            });

            // 3. Platformları en ucuz tekliflerine göre sırala
            const sortedPlatforms = Object.keys(groups).sort((a, b) => {
                return groups[a][0].fiyat - groups[b][0].fiyat;
            });

            let html = '';
            sortedPlatforms.forEach((pKey, pIdx) => {
                const pOffers = groups[pKey];
                const bestOffer = pOffers[0];
                const plat = platformBadges[pKey] || { bg: 'bg-slate-700', text: bestOffer.platform_adi, icon: 'fa-bag-shopping', border: 'border-slate-200' };

                // Kâr marjı (en ucuz teklife göre)
                let marginHtml = '';
                if (depoCost && depoCost > 0) {
                    const diff = bestOffer.fiyat - depoCost;
                    const pct = ((diff / depoCost) * 100).toFixed(1);
                    if (diff >= 0) {
                        marginHtml = `<span class="px-2 py-0.5 rounded-md text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">+${diff.toFixed(2)} ₺ (%${pct} Kâr)</span>`;
                    } else {
                        marginHtml = `<span class="px-2 py-0.5 rounded-md text-[11px] font-bold bg-red-50 text-red-700 border border-red-200">${diff.toFixed(2)} ₺ Depodan Ucuz!</span>`;
                    }
                }

                const imgHtml = bestOffer.gorsel_url 
                    ? `<img src="${bestOffer.gorsel_url}" alt="${bestOffer.urun_adi}" class="w-14 h-14 object-contain rounded-xl bg-slate-50 border border-slate-100 p-1 shrink-0" onerror="this.src='https://via.placeholder.com/56?text=Foto'"/>`
                    : `<div class="w-14 h-14 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400 text-base shrink-0"><i class="fa-solid fa-box"></i></div>`;

                const hasMultiple = pOffers.length > 1;

                // Alt Kıvrım (Accordion Sub-Panel) HTML
                let drawerHtml = '';
                if (hasMultiple) {
                    let subItemsHtml = pOffers.map((sub, sIdx) => {
                        let subMarginHtml = '';
                        if (depoCost && depoCost > 0) {
                            const diff = sub.fiyat - depoCost;
                            const pct = ((diff / depoCost) * 100).toFixed(1);
                            subMarginHtml = diff >= 0 
                                ? `<span class="text-[10px] font-semibold text-emerald-600">+${diff.toFixed(2)} ₺ (%${pct})</span>`
                                : `<span class="text-[10px] font-semibold text-red-600">${diff.toFixed(2)} ₺</span>`;
                        }

                        return `
                            <div class="p-2.5 rounded-xl bg-slate-50/90 border border-slate-200/80 hover:bg-slate-100/80 transition flex items-center justify-between gap-3 text-xs">
                                <div class="flex items-center gap-2.5 min-w-0 flex-1">
                                    <span class="w-5 h-5 rounded-full ${sIdx === 0 ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'} flex items-center justify-center text-[10px] font-bold shrink-0">
                                        ${sIdx + 1}
                                    </span>
                                    <div class="min-w-0 flex-1">
                                        <div class="flex items-center gap-2">
                                            <span class="font-bold text-slate-800 truncate">${sub.satici || 'Pazaryeri Satıcısı'}</span>
                                            ${sub.puan ? `<span class="text-[10px] text-amber-600 font-bold flex items-center gap-0.5"><i class="fa-solid fa-star text-[8px]"></i>${sub.puan}</span>` : ''}
                                            ${sIdx === 0 ? '<span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800">En Düşük Fiyat</span>' : ''}
                                        </div>
                                        <div class="text-[11px] text-slate-500 truncate" title="${sub.urun_adi}">${sub.urun_adi}</div>
                                    </div>
                                </div>
                                <div class="flex items-center gap-3 shrink-0">
                                    <div class="text-right">
                                        <div class="text-sm font-black text-slate-900">${sub.fiyat.toFixed(2)} ₺</div>
                                        ${subMarginHtml}
                                    </div>
                                    <a href="${sub.url}" target="_blank" rel="noopener noreferrer" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-800 hover:bg-indigo-600 text-white transition flex items-center gap-1 shadow-2xs cursor-pointer">
                                        <span>Git</span>
                                        <i class="fa-solid fa-arrow-up-right-from-square text-[9px]"></i>
                                    </a>
                                </div>
                            </div>
                        `;
                    }).join('');

                    drawerHtml = `
                        <div id="platDrawer_${pKey}" class="hidden mt-3 pt-3 border-t border-dashed border-slate-200">
                            <div class="mb-2 flex items-center justify-between text-[11px] font-bold text-slate-500 px-1">
                                <span><i class="fa-solid fa-store mr-1 text-slate-400"></i>${plat.text} Üzerindeki Tüm Satıcılar (${pOffers.length} Teklif)</span>
                                <span>Ucuzdan Pahalıya</span>
                            </div>
                            <div class="space-y-1.5">
                                ${subItemsHtml}
                            </div>
                        </div>
                    `;
                }

                html += `
                    <div class="bg-white p-4 rounded-2xl border ${plat.border} shadow-xs hover:shadow-md transition">
                        <!-- PLATFORM ANA SATIRI -->
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div class="flex items-center gap-3 min-w-0 flex-1">
                                ${imgHtml}
                                <div class="min-w-0 flex-1">
                                    <div class="flex flex-wrap items-center gap-1.5 mb-1">
                                        <span class="px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase text-white ${plat.bg} flex items-center gap-1">
                                            <i class="fa-solid ${plat.icon} text-[9px]"></i>
                                            <span>${plat.text}</span>
                                        </span>
                                        ${pIdx === 0 ? '<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-600 text-white">EN UCUZ PLATFORM</span>' : ''}
                                        
                                        <!-- ALT KIVRIM BUTONU -->
                                        ${hasMultiple ? `
                                            <button type="button" onclick="togglePlatformOffers('${pKey}')" class="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition flex items-center gap-1 cursor-pointer" title="Diğer satıcı fiyatlarını gör">
                                                <i class="fa-solid fa-layer-group text-[9px]"></i>
                                                <span>${pOffers.length} Farklı Satıcı Fiyatı</span>
                                                <i id="platChevron_${pKey}" class="fa-solid fa-chevron-down text-[8px] transition-transform duration-200"></i>
                                            </button>
                                        ` : `
                                            <span class="text-[10px] text-slate-400 font-semibold">(Tek Satıcı)</span>
                                        `}
                                    </div>
                                    <h4 class="text-xs font-bold text-slate-900 leading-snug line-clamp-1" title="${bestOffer.urun_adi}">
                                        ${bestOffer.urun_adi}
                                    </h4>
                                    <div class="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                                        ${bestOffer.satici ? `<span>En Uygun Satıcı: <b class="text-slate-700">${bestOffer.satici}</b></span>` : ''}
                                        ${marginHtml}
                                    </div>
                                </div>
                            </div>

                            <div class="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100">
                                <div class="text-right">
                                    <div class="text-lg font-black text-slate-900">${bestOffer.fiyat.toFixed(2)} ₺</div>
                                    ${bestOffer.eski_fiyat && bestOffer.eski_fiyat > bestOffer.fiyat ? `<div class="text-[11px] text-slate-400 line-through font-medium">${bestOffer.eski_fiyat.toFixed(2)} ₺</div>` : ''}
                                </div>
                                <div class="flex items-center gap-1.5 mt-1">
                                    ${hasMultiple ? `
                                        <button type="button" onclick="togglePlatformOffers('${pKey}')" class="px-2.5 py-1 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1 cursor-pointer">
                                            <span>Detay</span>
                                            <i class="fa-solid fa-chevron-down text-[9px]"></i>
                                        </button>
                                    ` : ''}
                                    <a href="${bestOffer.url}" target="_blank" rel="noopener noreferrer" class="px-3 py-1 rounded-xl text-xs font-bold bg-slate-900 hover:bg-indigo-600 text-white transition flex items-center gap-1 shadow-xs cursor-pointer">
                                        <span>Ürüne Git</span>
                                        <i class="fa-solid fa-arrow-up-right-from-square text-[9px]"></i>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- ALT KIVRIM (DRAWER) -->
                        ${drawerHtml}
                    </div>
                `;
            });

            listEl.innerHTML = html;
        }

        // ==========================================
        // Market Arama İçin Canlı Akıllı Öneri (Suggest)
        // ==========================================
        function initMarketSuggest() {
            const marketInput = document.getElementById('marketSearchInput');
            const marketSuggestBox = document.getElementById('marketSuggestBox');
            if (!marketInput || !marketSuggestBox) return;

            let mDebounce;
            marketInput.addEventListener('input', function() {
                clearTimeout(mDebounce);
                const val = this.value.trim();
                if (val.length < 2) {
                    marketSuggestBox.classList.add('hidden');
                    return;
                }
                mDebounce = setTimeout(async () => {
                    try {
                        const res = await fetch(`/api/catalog/suggest?q=${encodeURIComponent(val)}`);
                        if (res.ok) {
                            const items = await res.json();
                            renderMarketSuggestions(items);
                        }
                    } catch(e) {
                        console.error("Market suggest error:", e);
                    }
                }, 80);
            });

            document.addEventListener('click', (e) => {
                if (!marketInput.contains(e.target) && !marketSuggestBox.contains(e.target)) {
                    marketSuggestBox.classList.add('hidden');
                }
            });
        }

        function renderMarketSuggestions(items) {
            const marketInput = document.getElementById('marketSearchInput');
            const marketSuggestBox = document.getElementById('marketSuggestBox');
            if (!marketSuggestBox) return;
            if (!items || items.length === 0) {
                marketSuggestBox.classList.add('hidden');
                return;
            }
            marketSuggestBox.innerHTML = '';
            items.forEach(item => {
                const multiBadge = (item.barcode_count && item.barcode_count > 1)
                    ? `<span class="ml-1.5 px-1.5 py-0.5 text-[10px] font-semibold bg-indigo-100 text-indigo-800 rounded border border-indigo-200" title="Kayıtlı Tüm Barkodlar: ${(item.all_barcodes || []).join(', ')}">+${item.barcode_count - 1} Barkod</span>`
                    : '';
                const div = document.createElement('div');
                div.className = 'px-4 py-3 hover:bg-indigo-50/70 cursor-pointer flex items-center justify-between transition';
                div.innerHTML = `
                    <div class="flex items-center space-x-3">
                        <div class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center text-xs font-bold shrink-0">
                            <i class="fa-solid fa-sparkles"></i>
                        </div>
                        <div>
                            <div class="text-sm font-semibold text-slate-800">${item.name}</div>
                            <div class="text-xs text-slate-400 font-mono">${item.barcode}${multiBadge} • <span class="text-indigo-600 font-medium">${item.manufacturer || 'Genel'}</span></div>
                        </div>
                    </div>
                    <div class="text-right">
                        ${item.price ? `<div class="text-xs font-bold text-slate-700">${item.price.toFixed(2)} ₺</div>` : ''}
                        <span class="text-[10px] text-indigo-600 font-semibold">Seç & Tara ↗</span>
                    </div>
                `;
                div.addEventListener('click', () => {
                    marketInput.value = item.name;
                    marketSuggestBox.classList.add('hidden');
                    handleMarketSearchSubmit(item.barcode);
                });
                marketSuggestBox.appendChild(div);
            });
            marketSuggestBox.classList.remove('hidden');
        }

        // ================= Günlük Çıkış & Azalan / Kritik Stok Paneli =================
        let criticalStockItems = [];
        let criticalFilterMode = 'days_21';

        async function loadCriticalStockList(force = false) {
            const container = document.getElementById('criticalStockListContainer');
            const countBadge = document.getElementById('sideCriticalCountBadge');
            const topBadge = document.getElementById('topBarCriticalCount');
            const refreshIcon = document.getElementById('criticalRefreshIcon');
            const statusPill = document.getElementById('botanikDataStatusPill');
            const statusIcon = document.getElementById('dataStatusIcon');
            const statusText = document.getElementById('dataStatusText');

            if (refreshIcon) refreshIcon.classList.add('fa-spin');
            if (force && statusPill && statusText) {
                statusPill.className = "mb-3.5 flex items-center justify-between px-3.5 py-2 rounded-xl text-xs transition-all duration-300 bg-amber-50/90 border border-amber-200/80 text-amber-900 shadow-xs";
                if (statusIcon) {
                    statusIcon.className = "inline-block w-2.5 h-2.5 rounded-full border-2 border-amber-500 border-t-transparent animate-spin shrink-0";
                    statusIcon.innerHTML = '';
                }
                statusText.innerText = "Günün çıkışları & azalan stok verileri güncelleniyor...";
            }
            if (container && force) {
                container.innerHTML = `
                    <div class="p-6 text-center text-slate-400 text-xs">
                        <i class="fa-solid fa-spinner fa-spin text-xl text-amber-500 mb-2 block"></i>
                        Güncel stok ve çıkışlar taranıyor...
                    </div>
                `;
            }

            try {
                const res = await fetch(`/api/otomasyon/critical-stock?force=${force}`);
                if (!res.ok) throw new Error('API yanıt vermedi');
                const data = await res.json();
                criticalStockItems = data.items || [];

                const countStr = `${criticalStockItems.length}`;
                if (countBadge) countBadge.innerText = countStr;
                if (topBadge) topBadge.innerText = countStr;
                const miniBadge = document.getElementById('miniSideCriticalCount');
                if (miniBadge) miniBadge.innerText = countStr;

                if (statusPill && statusText) {
                    statusPill.className = "mb-3.5 flex items-center justify-between px-3.5 py-2 rounded-xl text-xs transition-all duration-300 bg-emerald-50/90 border border-emerald-200/80 text-emerald-900 shadow-xs";
                    if (statusIcon) {
                        statusIcon.className = "inline-flex items-center justify-center w-4 h-4 rounded-full bg-emerald-600 text-white text-[9px] shrink-0";
                        statusIcon.innerHTML = '<i class="fa-solid fa-check"></i>';
                    }
                    statusText.innerHTML = `<span class="font-bold text-emerald-950">Günün Sipariş Listesi Hazır:</span> <span class="font-semibold text-emerald-700">${criticalStockItems.length} Kalem Kritik Ürün (≤21 Günlük Stok)</span>`;
                }

                renderCriticalList();
            } catch (err) {
                console.error("Critical stock fetch error:", err);
                if (statusPill && statusText) {
                    statusPill.className = "mb-3.5 flex items-center justify-between px-3.5 py-2 rounded-xl text-xs transition-all duration-300 bg-slate-100 border border-slate-200 text-slate-700";
                    if (statusIcon) {
                        statusIcon.className = "inline-flex items-center justify-center w-4 h-4 rounded-full bg-slate-500 text-white text-[9px] shrink-0";
                        statusIcon.innerHTML = '<i class="fa-solid fa-info"></i>';
                    }
                    statusText.innerText = "Otomasyon verisi: " + err.message;
                }
                if (container) {
                    container.innerHTML = `
                        <div class="p-4 text-center text-rose-500 text-xs bg-rose-50 rounded-xl border border-rose-200">
                            <i class="fa-solid fa-circle-exclamation text-base mb-1 block"></i>
                            Kritik stok bilgisi alınamadı: ${err.message}
                        </div>
                    `;
                }
            } finally {
                if (refreshIcon) refreshIcon.classList.remove('fa-spin');
            }
        }

        let showMfBadges = localStorage.getItem('showMfBadges') !== 'false';
        let hideOrderedItems = localStorage.getItem('hideOrderedItems') === 'true';
        let isMfResolutionRunning = false;

        function updateHideOrderedButtonUI() {
            const btn = document.getElementById('btnToggleHideOrdered');
            const txt = document.getElementById('btnToggleHideOrderedText');
            const icn = document.getElementById('btnToggleHideOrderedIcon');
            if (!btn || !txt) return;
            if (hideOrderedItems) {
                btn.className = 'px-2 py-0.5 rounded-md font-extrabold text-[9px] transition cursor-pointer flex items-center space-x-1 bg-emerald-600 text-white shadow-2xs hover:bg-emerald-700';
                txt.innerText = 'Siparişliler Gizli';
                if (icn) icn.className = 'fa-solid fa-eye text-[8px]';
            } else {
                btn.className = 'px-2 py-0.5 rounded-md font-extrabold text-[9px] transition cursor-pointer flex items-center space-x-1 bg-slate-200 text-slate-700 hover:bg-slate-300';
                txt.innerText = 'Siparişlileri Gizle';
                if (icn) icn.className = 'fa-solid fa-eye-slash text-[8px]';
            }
        }

        function toggleHideOrderedItems() {
            hideOrderedItems = !hideOrderedItems;
            localStorage.setItem('hideOrderedItems', hideOrderedItems ? 'true' : 'false');
            updateHideOrderedButtonUI();
            renderCriticalList();
        }

        async function syncTodayOrdersAcrossPCs() {
            try {
                const res = await fetch('/api/orders/today');
                if (!res.ok) return;
                const data = await res.json();
                if (!data.success || !data.orders) return;
                const ordersMap = data.orders || {};

                let changed = false;
                let orderedTotal = 0;

                if (criticalStockItems && criticalStockItems.length > 0) {
                    criticalStockItems.forEach(it => {
                        const bc = (it.barkod || '').toString().trim();
                        const bcNoZero = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;
                        const nm = (it.urun_adi || '').toString().trim().toLowerCase();
                        const match = (bc && ordersMap[bc]) || (bcNoZero && ordersMap[bcNoZero]) || (nm && ordersMap[`NAME:${nm}`]);

                        const newStatus = match ? match.durum : null;
                        const newDepo = match ? match.depo : null;
                        const newMiktar = match ? match.miktar : null;
                        const newMasa = match ? match.masa : null;
                        const newSaat = match ? match.saat : null;

                        if (newStatus) orderedTotal++;

                        if (it.siparis_durumu !== newStatus || it.siparis_depo !== newDepo || it.siparis_miktar !== newMiktar) {
                            it.siparis_durumu = newStatus;
                            it.siparis_depo = newDepo;
                            it.siparis_miktar = newMiktar;
                            it.siparis_masa = newMasa;
                            it.siparis_saat = newSaat;
                            changed = true;
                        }
                    });
                }

                const ordBadge = document.getElementById('orderedTodayCountBadge');
                if (ordBadge) {
                    ordBadge.innerText = `${orderedTotal} İşlem`;
                }

                if (changed) {
                    // Sipariş verilenleri listenin en altına taşı, bekleyenleri üstte tut
                    criticalStockItems.sort((a, b) => {
                        const aOrd = a.siparis_durumu === 'SIPARIS_VERILDI' ? 1 : 0;
                        const bOrd = b.siparis_durumu === 'SIPARIS_VERILDI' ? 1 : 0;
                        if (aOrd !== bOrd) return aOrd - bOrd;
                        return (b.bugun_cikis || 0) - (a.bugun_cikis || 0);
                    });
                    renderCriticalList();
                }
            } catch (e) {
                // Sessizce geç
            }
        }

        // Her 10 saniyede bir eczanedeki diğer bilgisayarlarla sipariş durumunu senkronize et
        setInterval(syncTodayOrdersAcrossPCs, 10000);
        setTimeout(() => { updateHideOrderedButtonUI(); syncTodayOrdersAcrossPCs(); }, 1500);

        async function markItemOrderedManually(idx, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;
            const depo = (window.cardSelectedDepos && window.cardSelectedDepos[idx]) || window.defaultQuickDepo || 'SELCUK';
            const input = document.getElementById(`bulkQtyInput_${idx}`);
            const qty = input ? (parseInt(input.value) || 1) : (item.onerilen_siparis || 1);
            await markItemOrderedDirect(item.barkod || '', item.urun_adi || '', depo, qty);
        }

        async function markItemOrderedDirect(barkod, urunAdi, depo, miktar) {
            try {
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        durum: 'SIPARIS_VERILDI',
                        depo: depo || 'MANUEL',
                        items: [{ barkod: barkod, urun_adi: urunAdi, depo: depo || 'MANUEL', miktar: miktar || 1 }]
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Sipariş Verildi İşaretlendi', `${urunAdi || barkod} tüm bilgisayarlarda 'Sipariş Verildi' olarak işaretlendi.`, 'success');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function unmarkItemOrderStatus(barkod, urunAdi, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            try {
                const res = await fetch('/api/orders/unmark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barkod: barkod, urun_adi: urunAdi })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Sipariş İşareti Kaldırıldı', `${urunAdi || barkod} tekrar sipariş listesine alındı.`, 'info');
                    const todayOrdBanner = document.getElementById('resTodayOrderedBanner');
                    if (todayOrdBanner) {
                        todayOrdBanner.classList.add('hidden');
                        todayOrdBanner.innerHTML = '';
                    }
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        function toggleCriticalZeroOrNegFilter(targetMode) {
            if (criticalFilterMode === targetMode) {
                setCriticalFilterMode('days_21');
            } else {
                setCriticalFilterMode(targetMode);
            }
        }

        function setCriticalFilterMode(mode) {
            criticalFilterMode = mode;
            const btn21 = document.getElementById('btnCritFilter21');
            const btnAll = document.getElementById('btnCritFilterAll');
            const btnZero = document.getElementById('btnCritFilterZero');
            const btnNegative = document.getElementById('btnCritFilterNegative');
            const btnMf = document.getElementById('btnCritFilterMf');
            const cardZero = document.getElementById('cardCritSummaryZero');
            const cardNeg = document.getElementById('cardCritSummaryNegative');

            const activeClass = 'px-2 py-0.5 rounded-md font-bold bg-slate-900 text-white transition text-[9px] cursor-pointer';
            const passiveClass = 'px-2 py-0.5 rounded-md font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 transition text-[9px] cursor-pointer';

            if (btn21) btn21.className = mode === 'days_21' ? activeClass : passiveClass;
            if (btnAll) btnAll.className = mode === 'all' ? activeClass : passiveClass;
            if (btnZero) {
                btnZero.className = mode === 'zero'
                    ? 'px-2 py-0.5 rounded-md font-extrabold bg-rose-600 text-white transition text-[9px] cursor-pointer shadow-2xs'
                    : passiveClass;
            }
            if (btnNegative) {
                btnNegative.className = mode === 'negative'
                    ? 'px-2 py-0.5 rounded-md font-extrabold bg-purple-700 text-white transition text-[9px] cursor-pointer shadow-2xs'
                    : 'px-2 py-0.5 rounded-md font-bold bg-purple-100 hover:bg-purple-200 text-purple-900 transition text-[9px] cursor-pointer';
            }
            if (btnMf) {
                btnMf.className = mode === 'mf_only' 
                    ? 'px-2 py-0.5 rounded-md font-bold bg-amber-600 text-white transition text-[9px] cursor-pointer flex items-center space-x-1'
                    : 'px-2 py-0.5 rounded-md font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 transition text-[9px] cursor-pointer flex items-center space-x-1';
            }

            if (cardZero) {
                cardZero.className = mode === 'zero'
                    ? 'flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-rose-100 border-2 border-rose-500 ring-2 ring-rose-200 text-left transition cursor-pointer group shadow-xs'
                    : 'flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100/80 border border-rose-200 text-left transition cursor-pointer group';
            }
            if (cardNeg) {
                cardNeg.className = mode === 'negative'
                    ? 'flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-purple-100 border-2 border-purple-600 ring-2 ring-purple-200 text-left transition cursor-pointer group shadow-xs'
                    : 'flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-purple-50 hover:bg-purple-100/80 border border-purple-200 text-left transition cursor-pointer group';
            }

            renderCriticalList();
        }

        function filterCriticalList() {
            renderCriticalList();
        }

        function toggleMfBadgesView() {
            showMfBadges = !showMfBadges;
            localStorage.setItem('showMfBadges', showMfBadges ? 'true' : 'false');
            const btn = document.getElementById('btnToggleMfBadges');
            const txt = document.getElementById('btnToggleMfBadgesText');
            if (showMfBadges) {
                if (btn) btn.className = 'px-2 py-0.5 rounded-md font-extrabold text-[9px] transition cursor-pointer flex items-center space-x-1 bg-amber-500 text-white shadow-2xs hover:bg-amber-600 shrink-0';
                if (txt) txt.innerText = 'MF: Açık';
                updateMfBadgesInDom();
                triggerBackgroundMfResolution();
            } else {
                if (btn) btn.className = 'px-2 py-0.5 rounded-md font-extrabold text-[9px] transition cursor-pointer flex items-center space-x-1 bg-slate-200 text-slate-600 hover:bg-slate-300 shrink-0';
                if (txt) txt.innerText = 'MF: Kapalı';
                updateMfBadgesInDom();
            }
        }

        function updateMfBadgesInDom() {
            if (!window.currentFilteredCriticalItems) return;
            window.currentFilteredCriticalItems.forEach((item, index) => {
                const badgeSlot = document.getElementById(`criticalMfBadge_${index}`);
                if (!badgeSlot) return;
                const hasMf = showMfBadges && item.mf_metni && item.mf_metni !== 'YOK';
                if (hasMf) {
                    badgeSlot.className = 'mt-1';
                    badgeSlot.innerHTML = `
                        <div class="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-2xs">
                            <i class="fa-solid fa-gift text-[9px]"></i>
                            <span>${item.mf_metni} MF</span>
                            <span class="text-amber-100 font-semibold text-[8px] bg-black/20 px-1 rounded-sm">${item.mf_depo || 'Depo'}</span>
                        </div>
                    `;
                } else {
                    badgeSlot.className = 'hidden';
                    badgeSlot.innerHTML = '';
                }
            });
        }

        async function triggerBackgroundMfResolution() {
            if (!showMfBadges || isMfResolutionRunning) return;
            if (!criticalStockItems || criticalStockItems.length === 0) return;

            const uncachedBarcodes = [];
            criticalStockItems.forEach(it => {
                const bc = (it.barkod || '').toString().trim();
                if (bc && it.mf_metni === undefined && uncachedBarcodes.length < 35) {
                    uncachedBarcodes.push(bc);
                }
            });

            if (uncachedBarcodes.length === 0) return;

            isMfResolutionRunning = true;
            try {
                const res = await fetch('/api/otomasyon/resolve-mf', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barcodes: uncachedBarcodes })
                });
                if (res.ok) {
                    const data = await res.json();
                    const results = data.results || {};
                    criticalStockItems.forEach(it => {
                        const bc = (it.barkod || '').toString().trim();
                        if (bc in results) {
                            const mfObj = results[bc];
                            if (mfObj && mfObj.mf) {
                                it.mf_metni = mfObj.mf;
                                it.mf_depo = mfObj.depo || 'Depo';
                            } else {
                                it.mf_metni = null;
                                it.mf_depo = null;
                            }
                        }
                    });
                    updateMfBadgesInDom();
                }
            } catch(e) {
                console.error('MF resolution error:', e);
            } finally {
                isMfResolutionRunning = false;
            }
        }

        function renderCriticalList() {
            const container = document.getElementById('criticalStockListContainer');
            if (!container) return;

            const searchInput = document.getElementById('criticalFilterInput');
            const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

            // Sipariş sayacını güncelle
            const totalOrderedCount = (criticalStockItems || []).filter(x => !!x.siparis_durumu).length;
            const ordBadge = document.getElementById('orderedTodayCountBadge');
            if (ordBadge) ordBadge.innerText = `${totalOrderedCount} İşlem`;

            // Tükenen (==0) ve Eksiye Düşen (<0) sayaçlarını güncelle
            const baseForCounts = (criticalStockItems || []).filter(item => {
                if (hideOrderedItems && item.siparis_durumu === 'SIPARIS_VERILDI') return false;
                if (q) {
                    const name = (item.urun_adi || '').toLowerCase();
                    const barcode = (item.barkod || '').toLowerCase();
                    if (!name.includes(q) && !barcode.includes(q)) return false;
                }
                return true;
            });
            const zeroCount = baseForCounts.filter(x => Number(x.stok || 0) === 0).length;
            const negativeList = baseForCounts.filter(x => Number(x.stok || 0) < 0);
            const negativeCount = negativeList.length;
            const totalNegativeBoxes = negativeList.reduce((acc, x) => acc + Math.abs(Number(x.stok || 0)), 0);

            const zeroBadgeEl = document.getElementById('critZeroCountBadge');
            const zeroSubEl = document.getElementById('critZeroSubText');
            const negBadgeEl = document.getElementById('critNegativeCountBadge');
            const negSubEl = document.getElementById('critNegativeSubText');
            const btnZeroEl = document.getElementById('btnCritFilterZero');
            const btnNegEl = document.getElementById('btnCritFilterNegative');

            if (zeroBadgeEl) zeroBadgeEl.innerText = `${zeroCount}`;
            if (zeroSubEl) zeroSubEl.innerText = zeroCount > 0 ? `${zeroCount} ürün 0'a indi` : `Sıfırlanan yok`;
            if (negBadgeEl) negBadgeEl.innerText = `${negativeCount}`;
            if (negSubEl) negSubEl.innerText = negativeCount > 0 ? `Toplam -${totalNegativeBoxes} Kt Açık` : `Eksi stok yok`;
            if (btnZeroEl) btnZeroEl.innerText = `Tükenen (0)${zeroCount > 0 ? ' [' + zeroCount + ']' : ''}`;
            if (btnNegEl) btnNegEl.innerText = `Eksi (<0)${negativeCount > 0 ? ' [' + negativeCount + ']' : ''}`;

            let filtered = criticalStockItems.filter(item => {
                if (hideOrderedItems && item.siparis_durumu === 'SIPARIS_VERILDI') return false;
                const stokVal = Number(item.stok || 0);
                const effectiveAylik = Math.max(item.aylik_cikis || 0, item.bugun_cikis || 1);
                const stokGun = item.stok_gun !== undefined ? item.stok_gun : (stokVal <= 0 ? 0 : Math.round((stokVal * 300.0) / effectiveAylik) / 10);
                if (criticalFilterMode === 'days_21' && stokVal > 0 && stokGun > 21) return false;
                if (criticalFilterMode === 'zero' && stokVal !== 0) return false;
                if (criticalFilterMode === 'negative' && stokVal >= 0) return false;
                const hasAnyMf = (item.mf_metni && item.mf_metni !== 'YOK') || !!item.gecmis_mf_var;
                if (criticalFilterMode === 'mf_only' && !hasAnyMf) return false;
                if (q) {
                    const name = (item.urun_adi || '').toLowerCase();
                    const barcode = (item.barkod || '').toLowerCase();
                    return name.includes(q) || barcode.includes(q);
                }
                return true;
            });

            if (filtered.length === 0) {
                window.currentFilteredCriticalItems = [];
                let emptyMsg = 'Kriterlere uyan kritik ürün bulunamadı.';
                if (criticalFilterMode === 'negative') emptyMsg = 'Bugün çıkışı olup stoğu eksiye (<0) düşen ürün bulunmuyor.';
                else if (criticalFilterMode === 'zero') emptyMsg = 'Bugün çıkışı olup stoğu tam 0\'a inen ürün bulunmuyor.';
                container.innerHTML = `
                    <div class="p-6 text-center text-slate-400 text-xs bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                        <i class="fa-solid fa-box-open text-2xl text-slate-300 mb-2 block"></i>
                        ${emptyMsg}
                    </div>
                `;
                updateBulkSelectionCount();
                return;
            }

            window.currentFilteredCriticalItems = filtered;
            let unOrderedCounter = 0;
            container.innerHTML = filtered.map((item, index) => {
                const stokVal = Number(item.stok || 0);
                const effectiveAylik = Math.max(item.aylik_cikis || 0, item.bugun_cikis || 1);
                const stokGun = item.stok_gun !== undefined ? item.stok_gun : (stokVal <= 0 ? 0 : Math.round((stokVal * 300.0) / effectiveAylik) / 10);
                
                let stockBadgeClass = 'bg-slate-100 text-slate-700 border-slate-200';
                let stockText = `${stokVal} Kutu`;
                let negativeAlertBanner = '';

                if (stokVal < 0) {
                    stockBadgeClass = 'bg-purple-700 text-white border-purple-900 font-black shadow-2xs animate-pulse';
                    stockText = `🚨 EKSİ (${stokVal} Kt)`;
                    negativeAlertBanner = `
                        <div class="flex items-center justify-between px-2 py-0.5 rounded-md bg-purple-100/90 border border-purple-300 text-purple-950 text-[9px] font-extrabold">
                            <span><i class="fa-solid fa-triangle-exclamation text-purple-700 mr-1"></i>Stok Eksiye Düştü: <strong>${stokVal} Kutu</strong></span>
                            <span class="text-[8px] font-bold text-purple-700 bg-white/80 px-1.5 py-0.2 rounded">Emanet / Açık Stok</span>
                        </div>
                    `;
                } else if (stokVal === 0) {
                    stockBadgeClass = 'bg-rose-100 text-rose-800 border-rose-300 font-extrabold';
                    stockText = '🛑 TÜKENDİ (0 Kt)';
                } else if (stokGun <= 7) {
                    stockBadgeClass = 'bg-rose-50 text-rose-700 border-rose-200 font-bold';
                    stockText = `🔥 ${stokVal} Kt (${stokGun} G)`;
                } else if (stokGun <= 14) {
                    stockBadgeClass = 'bg-amber-50 text-amber-800 border-amber-200 font-bold';
                    stockText = `⚠️ ${stokVal} Kt (${stokGun} G)`;
                } else if (stokGun <= 21) {
                    stockBadgeClass = 'bg-sky-50 text-sky-800 border-sky-200 font-bold';
                    stockText = `📦 ${stokVal} Kt (${stokGun} G)`;
                } else {
                    stockBadgeClass = 'bg-slate-100 text-slate-600 border-slate-200 font-medium';
                    stockText = `✅ ${stokVal} Kt (${stokGun} G)`;
                }

                const safeName = (item.urun_adi || '').replace(/'/g, "\\'");
                const safeBc = (item.barkod || '').replace(/'/g, "\\'");
                const searchTarget = item.barkod || item.urun_adi;
                const isAlreadyOrderedOrInCart = !!item.siparis_durumu;
                if (!isAlreadyOrderedOrInCart) unOrderedCounter++;
                const isInitialSelected = (!isAlreadyOrderedOrInCart) && (unOrderedCounter <= 40);
                const hasMf = showMfBadges && item.mf_metni && item.mf_metni !== 'YOK';

                // Sipariş Durumu Rozeti (Tüm bilgisayarlarda ortak görünür)
                let orderStatusHtml = '';
                let cardWrapperClass = stokVal < 0
                    ? 'bg-purple-50/25 hover:bg-purple-50/50 border border-purple-300 border-l-4 border-l-purple-700'
                    : 'bg-white hover:bg-sky-50/30 border border-slate-200 hover:border-sky-300';
                if (item.siparis_durumu === 'SIPARIS_VERILDI') {
                    cardWrapperClass = 'bg-emerald-50/50 hover:bg-emerald-50 border-2 border-emerald-400/80 opacity-85';
                    orderStatusHtml = `
                        <div class="flex items-center justify-between px-2 py-1 rounded-lg bg-emerald-600 text-white text-[9px] font-black shadow-2xs" onclick="event.stopPropagation()">
                            <div class="flex items-center space-x-1 truncate">
                                <i class="fa-solid fa-circle-check text-[10px]"></i>
                                <span>SİPARİŞ VERİLDİ • ${item.siparis_depo || 'DEPO'} (${item.siparis_miktar || 1} Kt)</span>
                                ${item.siparis_saat ? `<span class="opacity-80 font-mono">• ${item.siparis_saat}</span>` : ''}
                                ${item.siparis_masa ? `<span class="opacity-80 hidden sm:inline">(${item.siparis_masa})</span>` : ''}
                            </div>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event)" class="ml-1.5 px-1.5 py-0.2 rounded bg-white/20 hover:bg-white/30 text-white text-[8px] font-bold cursor-pointer shrink-0" title="Sipariş verildi işaretini kaldır">
                                İptal ×
                            </button>
                        </div>
                    `;
                } else if (item.siparis_durumu === 'SEPETTE') {
                    cardWrapperClass = 'bg-amber-50/40 hover:bg-amber-50/70 border border-amber-300';
                    orderStatusHtml = `
                        <div class="flex items-center justify-between px-2 py-1 rounded-lg bg-amber-100 border border-amber-300 text-amber-950 text-[9px] font-extrabold" onclick="event.stopPropagation()">
                            <div class="flex items-center space-x-1 truncate">
                                <i class="fa-solid fa-cart-shopping text-amber-600 text-[9px]"></i>
                                <span>SEPETTE • ${item.siparis_depo || 'DEPO'} (${item.siparis_miktar || 1} Kt)</span>
                                ${item.siparis_saat ? `<span class="opacity-75 font-mono">• ${item.siparis_saat}</span>` : ''}
                            </div>
                            <div class="flex items-center space-x-1 shrink-0 ml-1">
                                <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeName}', '${item.siparis_depo || 'SELCUK'}', ${item.siparis_miktar || 1})" class="px-1.5 py-0.2 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[8px] font-bold cursor-pointer" title="Sipariş verildi olarak kesinleştir">
                                    ✓ Onayla
                                </button>
                                <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event)" class="px-1 py-0.2 rounded bg-white hover:bg-rose-50 text-slate-600 hover:text-rose-700 border border-amber-300 text-[8px] font-bold cursor-pointer" title="İşareti kaldır">
                                    ×
                                </button>
                            </div>
                        </div>
                    `;
                }

                // Depo seçimi (varsayılan: ALLIANCE, veya ürünün MF'si varsa o depo)
                window.cardSelectedDepos = window.cardSelectedDepos || {};
                let cardDepo = window.cardSelectedDepos[index];
                if (!cardDepo) {
                    if (item.mf_depo) {
                        const dUpper = String(item.mf_depo).toUpperCase();
                        if (dUpper.includes('ALLIANCE')) cardDepo = 'ALLIANCE';
                        else if (dUpper.includes('SELCUK') || dUpper.includes('SELÇUK')) cardDepo = 'SELCUK';
                        else if (dUpper.includes('ISKOOP') || dUpper.includes('İSKOOP')) cardDepo = 'ISKOOP';
                        else if (dUpper.includes('NEVZAT')) cardDepo = 'NEVZAT';
                    }
                }
                if (!cardDepo) cardDepo = window.defaultQuickDepo || 'ALLIANCE';
                window.cardSelectedDepos[index] = cardDepo;

                const curDepoCfg = (typeof QUICK_DEPO_CONFIGS !== 'undefined' && QUICK_DEPO_CONFIGS[cardDepo]) 
                    ? QUICK_DEPO_CONFIGS[cardDepo] 
                    : { name: 'Alliance Healthcare', shortName: 'Alliance', actionText: "Alliance'a At", bgClass: 'bg-sky-600 hover:bg-sky-700', chevronClass: 'bg-sky-700 hover:bg-sky-800', icon: 'fa-solid fa-truck-fast' };

                return `
                    <div class="${cardWrapperClass} rounded-2xl p-3 transition-all duration-200 space-y-2 group shadow-2xs">
                        ${orderStatusHtml}
                        ${negativeAlertBanner}
                        <div class="flex items-start justify-between gap-2">
                            <div class="flex items-start space-x-2 flex-1 min-w-0">
                                <input 
                                    type="checkbox" 
                                    style="accent-color: #0284c7;"
                                    class="bulkItemCheck rounded text-sky-600 focus:ring-sky-500 w-4 h-4 cursor-pointer mt-0.5 shrink-0" 
                                    data-idx="${index}" 
                                    data-ordered="${isAlreadyOrderedOrInCart ? '1' : '0'}"
                                    onchange="updateBulkSelectionCount()" 
                                    ${isInitialSelected ? 'checked' : ''} 
                                />
                                <div class="cursor-pointer flex-1 min-w-0" onclick="searchFromCriticalByIndex(${index})">
                                    <div class="flex items-center space-x-1.5 flex-wrap">
                                        <h4 class="font-extrabold text-xs ${item.siparis_durumu === 'SIPARIS_VERILDI' ? 'line-through text-slate-500' : 'text-slate-900 group-hover:text-sky-900'} truncate max-w-[85%]" title="${item.urun_adi}">
                                            ${item.urun_adi}
                                        </h4>
                                        ${item.gecmis_mf_var ? `
                                            <span class="inline-flex items-center text-amber-500 font-bold shrink-0 cursor-help" title="⭐ DİKKAT: Bu ürün geçmişte eczanenize MF (Mal Fazlası) ile alınmış!&#10;${item.gecmis_mf_bilgi || 'Geçmişte MF ile alım yapılmış.'}">
                                                <i class="fa-solid fa-star text-amber-400 text-xs drop-shadow-xs animate-pulse"></i>
                                            </span>
                                        ` : ''}
                                    </div>
                                    <div class="flex items-center justify-between mt-0.5">
                                        <div class="flex items-center space-x-1.5">
                                            <span class="text-[10px] font-mono text-slate-400 font-bold">${item.barkod || 'Barkodsuz'}</span>
                                            ${item.psf > 0 ? `<span class="text-[10px] text-slate-300">•</span><span class="text-[10px] font-mono text-slate-600 font-semibold">${item.psf.toFixed(2)} ₺</span>` : ''}
                                        </div>
                                        ${!item.siparis_durumu ? `
                                            <button type="button" onclick="markItemOrderedManually(${index}, event)" class="text-[9px] text-slate-400 hover:text-emerald-700 font-bold transition cursor-pointer flex items-center space-x-0.5" title="Bu ürünü başka yerden sipariş verdiyseniz tek tıkla 'Sipariş Verildi' olarak işaretleyin (Diğer bilgisayarlarda da görünür)">
                                                <i class="fa-regular fa-square-check text-[9px]"></i>
                                                <span>Sipariş Verildi İşaretle</span>
                                            </button>
                                        ` : ''}
                                    </div>
                                    <div class="flex flex-wrap items-center gap-1 mt-1">
                                        <div id="criticalMfBadge_${index}" class="${hasMf ? '' : 'hidden'}">
                                            ${hasMf ? `
                                                <div class="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-2xs">
                                                    <i class="fa-solid fa-gift text-[9px]"></i>
                                                    <span>${item.mf_metni} MF</span>
                                                    <span class="text-amber-100 font-semibold text-[8px] bg-black/20 px-1 rounded-sm">${item.mf_depo || 'Depo'}</span>
                                                </div>
                                            ` : ''}
                                        </div>
                                        ${item.gecmis_mf_var ? `
                                            <div class="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[9px] font-black bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs transition cursor-help" title="${item.gecmis_mf_bilgi || 'Geçmişte MF ile alım yapılmış.'}">
                                                <i class="fa-solid fa-star text-amber-500 text-[9px]"></i>
                                                <span>Geçmişte MF'li</span>
                                                ${item.gecmis_mf_kisa ? `<span class="text-amber-800 font-bold text-[8px] bg-amber-200/70 px-1 rounded-sm">${item.gecmis_mf_kisa}</span>` : ''}
                                            </div>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                            <span class="shrink-0 px-2 py-0.5 rounded-lg text-[10px] font-black border ${stockBadgeClass}" title="Mevcut Stok: ${item.stok} Kutu • Kalan Stok Süresi: ${stokGun} Gün">
                                ${stockText}
                            </span>
                        </div>

                        <!-- 3 Metrik Rozeti: Bugün Çıkış, 30 Günlük Çıkış, Sipariş Miktarı -->
                        <div class="grid grid-cols-3 gap-1.5 text-center text-[10px]">
                            <div class="bg-slate-50 group-hover:bg-white rounded-lg p-1.5 border border-slate-200/80 transition" title="Bugün reçeteli ve elden satılan toplam kutu">
                                <span class="text-slate-400 block text-[9px] font-medium">Bugün</span>
                                <strong class="text-amber-600 font-black flex items-center justify-center space-x-0.5">
                                    <i class="fa-solid fa-fire text-[8px] text-amber-500 mr-0.5 animate-pulse"></i>${item.bugun_cikis} Kt
                                </strong>
                            </div>
                            <div class="bg-slate-50 group-hover:bg-white rounded-lg p-1.5 border border-slate-200/80 transition" title="Son 30 gündeki toplam çıkış adedi">
                                <span class="text-slate-400 block text-[9px] font-medium">Aylık</span>
                                <strong class="text-slate-700 font-bold font-mono">${item.aylik_cikis} Kt</strong>
                            </div>
                            <div class="bg-sky-50/80 group-hover:bg-sky-50 rounded-lg p-1 border border-sky-200 transition flex flex-col justify-between" title="Siparişe eklenecek kutu adedi">
                                <span class="text-sky-800 block text-[9px] font-bold">Miktar</span>
                                <div class="flex items-center justify-center space-x-1 mt-0.5" onclick="event.stopPropagation()">
                                    <button type="button" onclick="changeBulkItemQty(${index}, -1)" class="w-4 h-4 rounded bg-white hover:bg-sky-200 text-sky-900 flex items-center justify-center font-bold text-[10px] shadow-2xs border border-sky-300 cursor-pointer">-</button>
                                    <input 
                                        type="number" 
                                        id="bulkQtyInput_${index}" 
                                        value="${item.onerilen_siparis || item.bugun_cikis || 1}" 
                                        min="1" 
                                        max="999" 
                                        oninput="updateBulkSelectionCount()" 
                                        class="w-8 text-center text-[11px] font-black font-mono py-0 border-0 bg-transparent focus:ring-0 text-sky-950" 
                                    />
                                    <button type="button" onclick="changeBulkItemQty(${index}, 1)" class="w-4 h-4 rounded bg-white hover:bg-sky-200 text-sky-900 flex items-center justify-center font-bold text-[10px] shadow-2xs border border-sky-300 cursor-pointer">+</button>
                                </div>
                            </div>
                        </div>

                        <!-- Aksiyon Butonları (Karşılaştır & Seçimli Depoya At) -->
                        <div class="grid grid-cols-2 gap-1.5 pt-0.5">
                            <button 
                                type="button" 
                                onclick="searchFromCriticalByIndex(${index})" 
                                class="py-1.5 px-2 bg-slate-100 hover:bg-emerald-600 hover:text-white text-slate-700 font-bold text-[11px] rounded-xl transition flex items-center justify-center space-x-1 cursor-pointer"
                                title="Tüm depolarda anında canlı fiyat ve şartları sorgula"
                            >
                                <i class="fa-solid fa-code-compare text-[10px]"></i>
                                <span>Karşılaştır</span>
                            </button>

                            <!-- Seçimli Depo Split Butonu -->
                            <div class="relative flex items-stretch rounded-xl shadow-xs" id="quickAddWrapper_${index}">
                                <button 
                                    type="button" 
                                    onclick="sendSingleCriticalToDepo(${index})" 
                                    id="btnQuickAdd_${index}" 
                                    class="flex-1 py-1.5 px-2 ${curDepoCfg.bgClass} text-white font-extrabold text-[11px] rounded-l-xl transition flex items-center justify-center space-x-1 cursor-pointer active:scale-98"
                                    title="Sadece bu ilacı ${curDepoCfg.name} sepetine ekle"
                                >
                                    <i class="${curDepoCfg.icon} text-[10px]" id="btnQuickAddIcon_${index}"></i>
                                    <span id="btnQuickAddText_${index}">${curDepoCfg.actionText}</span>
                                </button>
                                <button 
                                    type="button" 
                                    onclick="toggleCardDepoMenu(${index}, event)" 
                                    id="btnQuickAddChevron_${index}" 
                                    class="px-2 ${curDepoCfg.chevronClass} text-white/90 hover:text-white border-l border-white/20 rounded-r-xl transition flex items-center justify-center cursor-pointer"
                                    title="Hedef depoyu değiştir (Alliance, Selçuk, İSKOOP, Nevzat)"
                                >
                                    <i class="fa-solid fa-caret-down text-[10px]"></i>
                                </button>

                                <!-- Açılır Depo Menüsü -->
                                <div id="cardDepoMenu_${index}" class="hidden absolute right-0 bottom-full mb-1 z-50 w-44 bg-white border border-slate-200 rounded-xl shadow-2xl py-1 text-xs divide-y divide-slate-100">
                                    <div class="px-2.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                                        Hedef Depo Seç
                                    </div>
                                    <div class="py-0.5">
                                        <button type="button" onclick="setCardDepo(${index}, 'ALLIANCE', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-sky-50 text-slate-700 hover:text-sky-900 font-semibold cursor-pointer">
                                            <span class="w-2 h-2 rounded-full bg-sky-500 shrink-0"></span>
                                            <span class="flex-1 text-[11px]">Alliance</span>
                                            ${cardDepo === 'ALLIANCE' ? '<i class="fa-solid fa-check text-[10px] text-sky-600"></i>' : ''}
                                        </button>
                                        <button type="button" onclick="setCardDepo(${index}, 'SELCUK', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-rose-50 text-slate-700 hover:text-rose-900 font-semibold cursor-pointer">
                                            <span class="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
                                            <span class="flex-1 text-[11px]">Selçuk</span>
                                            ${cardDepo === 'SELCUK' ? '<i class="fa-solid fa-check text-[10px] text-rose-600"></i>' : ''}
                                        </button>
                                        <button type="button" onclick="setCardDepo(${index}, 'ISKOOP', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 font-semibold cursor-pointer">
                                            <span class="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                                            <span class="flex-1 text-[11px]">İSKOOP</span>
                                            ${cardDepo === 'ISKOOP' ? '<i class="fa-solid fa-check text-[10px] text-emerald-600"></i>' : ''}
                                        </button>
                                        <button type="button" onclick="setCardDepo(${index}, 'NEVZAT', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-amber-50 text-slate-700 hover:text-amber-900 font-semibold cursor-pointer">
                                            <span class="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                                            <span class="flex-1 text-[11px]">Nevzat</span>
                                            ${cardDepo === 'NEVZAT' ? '<i class="fa-solid fa-check text-[10px] text-amber-600"></i>' : ''}
                                        </button>
                                    </div>
                                    <div class="py-0.5">
                                        <button type="button" onclick="setCardDepo(${index}, '${cardDepo}', true, event)" class="w-full text-left px-2.5 py-1.5 text-[10px] text-slate-600 hover:bg-slate-100 hover:text-slate-900 cursor-pointer flex items-center space-x-1.5 font-bold">
                                            <i class="fa-solid fa-check-double text-[9px] text-sky-600"></i>
                                            <span>Tüm kartları buna ayarla</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');

            updateBulkSelectionCount();
            triggerBackgroundMfResolution();
        }

        function searchFromCriticalByIndex(idx) {
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;

            // 1. Depo sekmesine geç
            if (typeof switchMainView === 'function') {
                switchMainView('depo');
            }

            // 2. Sağ çekmeceyi hemen kapat
            if (typeof toggleSideWidget === 'function') {
                toggleSideWidget(false);
            }

            // 3. Arama inputuna ürün adını veya barkodu yaz
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.value = item.urun_adi || item.barkod;
            }

            // 4. Öneri ve ara seçim kutularını kapat
            const suggestBox = document.getElementById('suggestBox');
            if (suggestBox) suggestBox.classList.add('hidden');
            const productSelection = document.getElementById('productSelection');
            if (productSelection) productSelection.classList.add('hidden');

            // 5. Sayfanın en üstüne yumuşakça kaydır
            window.scrollTo({ top: 0, behavior: 'smooth' });

            // 6. ANINDA CANLI DEPO SORGULAMASINI BAŞLAT
            const barcode = (item.barkod || '').toString().trim();
            if (barcode && /^\d{8,14}$/.test(barcode)) {
                performBarcodeSearch(barcode);
            } else {
                handleSearchSubmit(barcode || item.urun_adi);
            }
        }

        function searchFromCritical(barcodeOrName, title) {
            if (typeof switchMainView === 'function') {
                switchMainView('depo');
            }
            if (typeof toggleSideWidget === 'function') {
                toggleSideWidget(false);
            }
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.value = title || barcodeOrName;
            }
            const suggestBox = document.getElementById('suggestBox');
            if (suggestBox) suggestBox.classList.add('hidden');
            const productSelection = document.getElementById('productSelection');
            if (productSelection) productSelection.classList.add('hidden');
            window.scrollTo({ top: 0, behavior: 'smooth' });

            const q = (barcodeOrName || '').toString().trim();
            if (q && /^\d{8,14}$/.test(q)) {
                performBarcodeSearch(q);
            } else {
                handleSearchSubmit(q || title);
            }
        }

        // Global switchTab fonksiyonu (tam uyumluluk)
        function switchTab(t) {
            if (typeof switchMainView === 'function') switchMainView(t);
        }

        function toggleSideWidget(open) {
            const widget = document.getElementById('criticalSideWidget');
            const miniBtn = document.getElementById('criticalMiniBadgeBtn');
            if (!widget || !miniBtn) return;
            if (open) {
                widget.classList.remove('hidden');
                miniBtn.classList.add('hidden');
            } else {
                widget.classList.add('hidden');
                miniBtn.classList.remove('hidden');
            }
        }

        // ================= Toplu Sipariş Gönderici & Akıllı Şelale Dağıtıcısı =================
        function syncMasterCheckboxVisual(isChecked) {
            const masterCheck = document.getElementById('bulkSelectAllCheck');
            const box = document.getElementById('bulkSelectAllVisualBox');
            const icon = document.getElementById('bulkSelectAllVisualIcon');
            if (masterCheck) {
                masterCheck.checked = !!isChecked;
                masterCheck.indeterminate = false;
            }
            if (box) {
                box.className = isChecked
                    ? 'w-4 h-4 rounded border-2 border-sky-600 bg-sky-600 text-white flex items-center justify-center transition-all shadow-2xs group-hover:ring-2 group-hover:ring-sky-300'
                    : 'w-4 h-4 rounded border-2 border-slate-400 bg-white text-transparent flex items-center justify-center transition-all shadow-2xs group-hover:border-sky-500';
            }
            if (icon) {
                icon.className = isChecked
                    ? 'fa-solid fa-check text-[10px] leading-none text-white opacity-100'
                    : 'fa-solid fa-check text-[10px] leading-none text-transparent opacity-0';
            }
        }

        function handleMasterSelectClick(ev) {
            if (ev) {
                ev.preventDefault();
                ev.stopPropagation();
            }
            const masterCheck = document.getElementById('bulkSelectAllCheck');
            const allChecks = Array.from(document.querySelectorAll('.bulkItemCheck'));
            if (allChecks.length === 0) {
                syncMasterCheckboxVisual(false);
                return;
            }
            const currentlyChecked = masterCheck ? !!masterCheck.checked : false;
            const nextState = !currentlyChecked;
            if (masterCheck) masterCheck.checked = nextState;
            toggleBulkSelectAll(masterCheck || { checked: nextState });
        }

        function updateBulkSelectionCount(preserveMaster = false) {
            const allChecks = Array.from(document.querySelectorAll('.bulkItemCheck'));
            const checkedChecks = allChecks.filter(c => c.checked);
            const count = checkedChecks.length;
            const badge = document.getElementById('bulkSelectedBadge');
            const masterCheck = document.getElementById('bulkSelectAllCheck');

            if (badge) badge.innerText = `${count} Seçili`;
            if (masterCheck) {
                if (!preserveMaster) {
                    const unorderedChecks = allChecks.filter(c => c.dataset.ordered !== '1');
                    const targetPool = unorderedChecks.length > 0 ? unorderedChecks : allChecks;
                    const isAllSelected = targetPool.length > 0 && targetPool.every(c => c.checked);
                    syncMasterCheckboxVisual(isAllSelected);
                } else {
                    syncMasterCheckboxVisual(!!masterCheck.checked);
                }
            }
        }

        function toggleBulkSelectAll(master) {
            const allChecks = Array.from(document.querySelectorAll('.bulkItemCheck'));
            const shouldSelect = !!(master && master.checked);
            if (shouldSelect) {
                const unorderedChecks = allChecks.filter(c => c.dataset.ordered !== '1');
                if (unorderedChecks.length > 0) {
                    allChecks.forEach(c => {
                        c.checked = (c.dataset.ordered !== '1');
                    });
                } else {
                    allChecks.forEach(c => {
                        c.checked = true;
                    });
                }
                syncMasterCheckboxVisual(true);
            } else {
                allChecks.forEach(c => {
                    c.checked = false;
                });
                syncMasterCheckboxVisual(false);
            }
            updateBulkSelectionCount(true);
        }

        function selectTopNItems(n = 40) {
            const checks = document.querySelectorAll('.bulkItemCheck');
            let selectedSoFar = 0;
            checks.forEach((c) => {
                if (c.dataset.ordered !== '1' && selectedSoFar < n) {
                    c.checked = true;
                    selectedSoFar++;
                } else {
                    c.checked = false;
                }
            });
            updateBulkSelectionCount(false);
        }

        function clearBulkSelection() {
            const checks = document.querySelectorAll('.bulkItemCheck');
            checks.forEach(c => c.checked = false);
            syncMasterCheckboxVisual(false);
            updateBulkSelectionCount(true);
        }

        function changeBulkItemQty(idx, delta) {
            const input = document.getElementById(`bulkQtyInput_${idx}`);
            if (!input) return;
            let val = parseInt(input.value) || 1;
            val = Math.max(1, val + delta);
            input.value = val;
            updateBulkSelectionCount();
        }

        function closeBulkOrderModal() {
            const modal = document.getElementById('bulkOrderModal');
            if (modal) {
                modal.style.display = 'none';
                modal.classList.add('hidden');
            }
        }

        // ================= Kart Bazlı Seçimli Depo Hızlı Ekleme =================
        const QUICK_DEPO_CONFIGS = {
            'ALLIANCE': {
                code: 'ALLIANCE',
                name: 'Alliance Healthcare',
                shortName: 'Alliance',
                actionText: "Alliance'a At",
                bgClass: 'bg-sky-600 hover:bg-sky-700',
                chevronClass: 'bg-sky-700 hover:bg-sky-800',
                dotColor: 'bg-sky-500',
                icon: 'fa-solid fa-truck-fast'
            },
            'SELCUK': {
                code: 'SELCUK',
                name: 'Selçuk Ecza',
                shortName: 'Selçuk',
                actionText: "Selçuk'a At",
                bgClass: 'bg-rose-600 hover:bg-rose-700',
                chevronClass: 'bg-rose-700 hover:bg-rose-800',
                dotColor: 'bg-rose-500',
                icon: 'fa-solid fa-paper-plane'
            },
            'ISKOOP': {
                code: 'ISKOOP',
                name: 'İSKOOP E-Şube',
                shortName: 'İSKOOP',
                actionText: "İSKOOP'a At",
                bgClass: 'bg-emerald-600 hover:bg-emerald-700',
                chevronClass: 'bg-emerald-700 hover:bg-emerald-800',
                dotColor: 'bg-emerald-500',
                icon: 'fa-solid fa-cart-plus'
            },
            'NEVZAT': {
                code: 'NEVZAT',
                name: 'Nevzat Ecza',
                shortName: 'Nevzat',
                actionText: "Nevzat'a At",
                bgClass: 'bg-amber-600 hover:bg-amber-700',
                chevronClass: 'bg-amber-700 hover:bg-amber-800',
                dotColor: 'bg-amber-500',
                icon: 'fa-solid fa-boxes-packing'
            }
        };

        window.cardSelectedDepos = window.cardSelectedDepos || {};
        window.defaultQuickDepo = 'ALLIANCE';

        function toggleCardDepoMenu(idx, ev) {
            if (ev) {
                ev.stopPropagation();
                ev.preventDefault();
            }
            const menu = document.getElementById(`cardDepoMenu_${idx}`);
            if (!menu) return;
            const isHidden = menu.classList.contains('hidden');
            document.querySelectorAll('[id^="cardDepoMenu_"]').forEach(el => el.classList.add('hidden'));
            if (isHidden) {
                menu.classList.remove('hidden');
            }
        }

        function setCardDepo(idx, depoCode, applyToAll = false, ev = null) {
            if (ev) {
                ev.stopPropagation();
                ev.preventDefault();
            }
            window.cardSelectedDepos = window.cardSelectedDepos || {};
            const cfg = QUICK_DEPO_CONFIGS[depoCode] || QUICK_DEPO_CONFIGS['ALLIANCE'];

            if (applyToAll) {
                window.defaultQuickDepo = depoCode;
                const total = (window.currentFilteredCriticalItems || []).length;
                for (let i = 0; i < total; i++) {
                    window.cardSelectedDepos[i] = depoCode;
                    updateSingleCardDepoUI(i, depoCode);
                }
                showToast('Tüm Kartlar Güncellendi', `Tüm ilaçlar için hedef depo ${cfg.shortName} olarak belirlendi.`, 'success');
            } else {
                window.cardSelectedDepos[idx] = depoCode;
                updateSingleCardDepoUI(idx, depoCode);
                showToast('Depo Seçildi', `Bu ilaç için ${cfg.shortName} seçildi.`, 'success');
            }

            const menu = document.getElementById(`cardDepoMenu_${idx}`);
            if (menu) menu.classList.add('hidden');
        }

        function refreshCardDepoMenuContent(idx, currentDepo) {
            const menu = document.getElementById(`cardDepoMenu_${idx}`);
            if (!menu) return;
            menu.innerHTML = `
                <div class="px-2.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Hedef Depo Seç
                </div>
                <div class="py-0.5">
                    <button type="button" onclick="setCardDepo(${idx}, 'ALLIANCE', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-sky-50 text-slate-700 hover:text-sky-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-sky-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">Alliance</span>
                        ${currentDepo === 'ALLIANCE' ? '<i class="fa-solid fa-check text-[10px] text-sky-600"></i>' : ''}
                    </button>
                    <button type="button" onclick="setCardDepo(${idx}, 'SELCUK', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-rose-50 text-slate-700 hover:text-rose-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">Selçuk</span>
                        ${currentDepo === 'SELCUK' ? '<i class="fa-solid fa-check text-[10px] text-rose-600"></i>' : ''}
                    </button>
                    <button type="button" onclick="setCardDepo(${idx}, 'ISKOOP', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">İSKOOP</span>
                        ${currentDepo === 'ISKOOP' ? '<i class="fa-solid fa-check text-[10px] text-emerald-600"></i>' : ''}
                    </button>
                    <button type="button" onclick="setCardDepo(${idx}, 'NEVZAT', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-amber-50 text-slate-700 hover:text-amber-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">Nevzat</span>
                        ${currentDepo === 'NEVZAT' ? '<i class="fa-solid fa-check text-[10px] text-amber-600"></i>' : ''}
                    </button>
                </div>
                <div class="py-0.5 border-t border-slate-100">
                    <button type="button" onclick="setCardDepo(${idx}, '${currentDepo}', true, event)" class="w-full text-left px-2.5 py-1.5 text-[10px] text-slate-600 hover:bg-slate-100 hover:text-slate-900 cursor-pointer flex items-center space-x-1.5 font-bold">
                        <i class="fa-solid fa-check-double text-[9px] text-sky-600"></i>
                        <span>Tüm kartları buna ayarla</span>
                    </button>
                </div>
            `;
        }

        function updateSingleCardDepoUI(idx, depoCode) {
            const cfg = QUICK_DEPO_CONFIGS[depoCode] || QUICK_DEPO_CONFIGS['ALLIANCE'];
            const btn = document.getElementById(`btnQuickAdd_${idx}`);
            const chevron = document.getElementById(`btnQuickAddChevron_${idx}`);
            const icon = document.getElementById(`btnQuickAddIcon_${idx}`);
            const text = document.getElementById(`btnQuickAddText_${idx}`);

            if (btn) {
                btn.className = `flex-1 py-1.5 px-2 ${cfg.bgClass} text-white font-extrabold text-[11px] rounded-l-xl transition flex items-center justify-center space-x-1 cursor-pointer active:scale-98`;
                btn.title = `Sadece bu ilacı ${cfg.name} sepetine ekle`;
            }
            if (chevron) {
                chevron.className = `px-2 ${cfg.chevronClass} text-white/90 hover:text-white border-l border-white/20 rounded-r-xl transition flex items-center justify-center cursor-pointer`;
            }
            if (icon) {
                icon.className = `${cfg.icon} text-[10px]`;
            }
            if (text) {
                text.innerText = cfg.actionText;
            }
            refreshCardDepoMenuContent(idx, depoCode);
        }

        // Dışarı tıklanınca tüm depo menülerini kapat
        document.addEventListener('click', function(e) {
            if (!e.target.closest('[id^="quickAddWrapper_"]')) {
                document.querySelectorAll('[id^="cardDepoMenu_"]').forEach(el => el.classList.add('hidden'));
            }
        });

        async function sendSingleCriticalToDepo(idx) {
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;

            window.cardSelectedDepos = window.cardSelectedDepos || {};
            const depoCode = window.cardSelectedDepos[idx] || window.defaultQuickDepo || 'ALLIANCE';
            const cfg = QUICK_DEPO_CONFIGS[depoCode] || QUICK_DEPO_CONFIGS['ALLIANCE'];

            const btn = document.getElementById(`btnQuickAdd_${idx}`);
            const chevron = document.getElementById(`btnQuickAddChevron_${idx}`);
            const origHtml = btn ? btn.innerHTML : '';
            
            if (btn) {
                btn.disabled = true;
                if (chevron) chevron.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin text-[10px]"></i><span>Ekleniyor...</span>`;
            }

            const input = document.getElementById(`bulkQtyInput_${idx}`);
            const qty = input ? (parseInt(input.value) || 1) : 1;

            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depoCode,
                        barkod: item.barkod,
                        urun_id: item.barkod,
                        miktar: qty,
                        name: item.urun_adi || ''
                    })
                });
                const data = await res.json();
                if (data.success) {
                    let extra = '';
                    if (data.sepet_no) extra += ` (Belge No: ${data.sepet_no})`;
                    if (data.sepet_tutari) extra += ` (Tutar: ${data.sepet_tutari} ₺)`;
                    showToast(`${cfg.shortName} Sepetine Eklendi`, `${item.urun_adi} x${qty} kutu ${cfg.name} sepetinize aktarıldı.${extra}`, 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                    if (btn) {
                        btn.className = 'flex-1 py-1.5 px-2 bg-emerald-600 text-white font-extrabold text-[11px] rounded-l-xl flex items-center justify-center space-x-1';
                        btn.innerHTML = `<i class="fa-solid fa-check text-[10px]"></i><span>Eklendi</span>`;
                        setTimeout(() => {
                            updateSingleCardDepoUI(idx, depoCode);
                            btn.disabled = false;
                            if (chevron) chevron.disabled = false;
                        }, 2500);
                    }
                } else {
                    showToast(`${cfg.shortName} Hatası`, data.message || 'Ürün sepete eklenemedi.', 'error');
                    if (btn) {
                        updateSingleCardDepoUI(idx, depoCode);
                        btn.disabled = false;
                        if (chevron) chevron.disabled = false;
                    }
                }
            } catch(e) {
                showToast('Bağlantı Hatası', e.message, 'error');
                if (btn) {
                    updateSingleCardDepoUI(idx, depoCode);
                    btn.disabled = false;
                    if (chevron) chevron.disabled = false;
                }
            }
        }

        // Geriye dönük uyumluluk
        window.sendSingleCriticalToAlliance = sendSingleCriticalToDepo;

        const DEPO_BULK_CONFIGS = {
            'ALLIANCE': {
                name: 'Alliance Healthcare',
                title: '🚀 Alliance Healthcare Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar otomatik taranarak Alliance Healthcare sepetinize aktarılır.',
                cartUrl: 'https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart',
                cartBtnText: 'Alliance eSipariş Sepetini Aç ↗',
                icon: 'fa-solid fa-truck-fast',
                color: 'sky'
            },
            'SELCUK': {
                name: 'Selçuk Ecza',
                title: '🚀 Selçuk Ecza Deposu Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar Selçuk WebDepo sepetinize aktarılır.',
                cartUrl: 'https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx',
                cartBtnText: 'Selçuk WebDepo Sepetini Aç ↗',
                icon: 'fa-solid fa-paper-plane',
                color: 'rose'
            },
            'ISKOOP': {
                name: 'İSKOOP E-Şube',
                title: '🚀 İSKOOP E-Şube Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar İSKOOP E-Şube taslak siparişinize aktarılır.',
                cartUrl: 'https://esube.iskoop.org/FrameWorkT1/#/baskets',
                cartBtnText: 'İSKOOP E-Şube Sepetini Aç ↗',
                icon: 'fa-solid fa-cart-plus',
                color: 'emerald'
            },
            'NEVZAT': {
                name: 'Nevzat Ecza',
                title: '🚀 Nevzat Ecza Deposu Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar Nevzat WebDepo sepetinize aktarılır.',
                cartUrl: 'http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx',
                cartBtnText: 'Nevzat WebDepo Sepetini Aç ↗',
                icon: 'fa-solid fa-boxes-packing',
                color: 'amber'
            }
        };

        // ================= Toplu Sipariş Gönderici (Tek Depo Ultra Hızlı + Eksikleri Topla & Aktar) =================
        window.currentBulkState = {
            initialDepo: null,
            requestedItems: [],
            depoSessions: {}, // { 'ALLIANCE': { count: X, amount: Y, name: '...', cartUrl: '...' } }
            missingItems: [], // items still missing across tried depots
            allResults: []    // trace array for table rendering
        };
        window.activeBulkResultTab = 'ALL';

        function switchBulkResultTab(tab = 'ALL') {
            window.activeBulkResultTab = tab;
            const btnAll = document.getElementById('bulkTabBtnAll');
            const btnYok = document.getElementById('bulkTabBtnYok');

            if (tab === 'ALL') {
                if (btnAll) btnAll.className = 'px-2.5 py-1 rounded-lg text-xs font-black bg-white text-slate-900 shadow-2xs border border-slate-200 cursor-pointer';
                if (btnYok) btnYok.className = 'px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 hover:bg-rose-50 border border-transparent cursor-pointer flex items-center space-x-1';
            } else {
                if (btnAll) btnAll.className = 'px-2.5 py-1 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-100 border border-transparent cursor-pointer';
                if (btnYok) btnYok.className = 'px-2.5 py-1 rounded-lg text-xs font-black bg-rose-600 text-white shadow-2xs border border-rose-700 cursor-pointer flex items-center space-x-1';
            }

            renderBulkItemsTable();
        }

        function renderBulkItemsTable() {
            const listEl = document.getElementById('bulkOrderItemsList');
            if (!listEl) return;

            const state = window.currentBulkState;
            if (!state) return;

            const itemsToShow = (window.activeBulkResultTab === 'YOK') 
                ? (state.missingItems || []) 
                : (state.allResults || []);

            if (itemsToShow.length === 0) {
                listEl.innerHTML = window.activeBulkResultTab === 'YOK'
                    ? `<div class="p-8 text-center text-emerald-600 font-bold"><i class="fa-solid fa-circle-check text-2xl block mb-2 text-emerald-500"></i>Harika! Tüm ürünler sepete eklendi, eksik ürün bulunmuyor.</div>`
                    : `<div class="p-8 text-center text-slate-400">Listelenecek ürün bulunamadı.</div>`;
                return;
            }

            const depoColors = {
                'ALLIANCE': { badge: 'bg-sky-100 text-sky-800 border-sky-200', text: 'Alliance' },
                'SELCUK': { badge: 'bg-rose-100 text-rose-800 border-rose-200', text: 'Selçuk' },
                'ISKOOP': { badge: 'bg-emerald-100 text-emerald-800 border-emerald-200', text: 'İSKOOP' },
                'NEVZAT': { badge: 'bg-amber-100 text-amber-800 border-amber-200', text: 'Nevzat' }
            };

            listEl.innerHTML = itemsToShow.map((it, i) => {
                const isYok = it.status === 'YOK' || !it.assigned_depo;
                const dCfg = depoColors[it.assigned_depo] || { badge: 'bg-slate-100 text-slate-800', text: it.assigned_depo || 'Depo' };
                const netFiyatStr = it.net_fiyat > 0 ? `${it.net_fiyat.toFixed(2)} ₺` : '';
                const vadeStr = it.vade ? `${it.vade} Gün` : '';
                const subDetail = [netFiyatStr, vadeStr].filter(Boolean).join(' • ');

                let badgeHtml = '';
                if (!isYok) {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${dCfg.badge}">
                            <i class="fa-solid fa-check text-[9px] mr-1"></i>
                            <span>${dCfg.text} Sepetinde</span>
                            ${subDetail ? `<span class="opacity-80 font-mono">(${subDetail})</span>` : ''}
                        </span>
                    `;
                } else {
                    const failMsg = it.message || 'Depoda Yok / Teklif Yok';
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            <i class="fa-solid fa-circle-exclamation text-[9px] mr-1"></i>
                            <span>${failMsg}</span>
                        </span>
                    `;
                }

                return `
                    <div class="px-4 py-2.5 flex items-center justify-between transition hover:bg-slate-50 ${isYok ? 'bg-rose-50/20' : 'bg-white'}" id="bulkRow_${i}">
                        <div class="flex items-center space-x-2.5 min-w-0">
                            <span class="w-5 h-5 rounded-full ${isYok ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-500'} font-mono text-[10px] font-bold flex items-center justify-center shrink-0">${i + 1}</span>
                            <div class="min-w-0">
                                <div class="font-bold text-slate-800 truncate">${it.name}</div>
                                <div class="text-[10px] text-slate-400 font-mono">${it.barcode} • Sipariş: <strong class="text-sky-700 font-bold">${it.miktar} Kutu</strong></div>
                            </div>
                        </div>
                        <div class="shrink-0 text-right">
                            ${badgeHtml}
                        </div>
                    </div>
                `;
            }).join('');
        }

        function copyMissingItemsToClipboard() {
            const missing = window.currentBulkState ? window.currentBulkState.missingItems : [];
            if (!missing || missing.length === 0) {
                showToast('Eksik Yok', 'Tüm ürünler sepete başarıyla eklendi, eksik ürün bulunmuyor.', 'info');
                return;
            }
            const now = new Date();
            const dateStr = now.toLocaleDateString('tr-TR') + ' ' + now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
            
            let text = `📋 ECZANE DEPO EKSİK / YOK LİSTESİ (${dateStr})\n`;
            text += `Aşağıdaki ${missing.length} kalem ürün depolarda bulunamamıştır:\n`;
            text += `--------------------------------------------------\n`;
            missing.forEach((it, idx) => {
                text += `${idx + 1}. ${it.name} (${it.barcode}) - ${it.miktar} Kutu\n`;
            });
            text += `--------------------------------------------------\n`;
            text += `Toplam: ${missing.length} Kalem • Eksik / Yok\n`;

            const finishCopy = () => {
                showToast('Eksik Listesi Kopyalandı!', `${missing.length} kalemlik eksik listesi panoya kopyalandı. WhatsApp veya notlara yapıştırabilirsiniz.`, 'success');
            };

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(finishCopy).catch(() => {
                    fallbackCopyText(text);
                    finishCopy();
                });
            } else {
                fallbackCopyText(text);
                finishCopy();
            }
        }

        function fallbackCopyText(text) {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
        }

        function renderTransferMissingBar(currentDepo) {
            const bar = document.getElementById('bulkTransferMissingBar');
            const countEl = document.getElementById('bulkMissingCount');
            const btnsContainer = document.getElementById('bulkTransferButtonsContainer');
            if (!bar || !countEl || !btnsContainer) return;

            const missing = window.currentBulkState ? window.currentBulkState.missingItems : [];
            if (!missing || missing.length === 0) {
                bar.classList.add('hidden');
                return;
            }

            bar.classList.remove('hidden');
            countEl.innerText = missing.length;

            const depos = [
                { key: 'ALLIANCE', name: 'Alliance', color: 'bg-sky-600 hover:bg-sky-700', icon: 'fa-solid fa-truck-fast' },
                { key: 'SELCUK', name: 'Selçuk', color: 'bg-rose-600 hover:bg-rose-700', icon: 'fa-solid fa-paper-plane' },
                { key: 'ISKOOP', name: 'İSKOOP', color: 'bg-emerald-600 hover:bg-emerald-700', icon: 'fa-solid fa-cart-plus' },
                { key: 'NEVZAT', name: 'Nevzat', color: 'bg-amber-600 hover:bg-amber-700', icon: 'fa-solid fa-boxes-packing' }
            ];

            // Son gönderilen depoyu hariç tutarak diğer depoları göster
            const availableDepos = depos.filter(d => d.key !== currentDepo);

            btnsContainer.innerHTML = availableDepos.map(d => `
                <button 
                    type="button" 
                    onclick="transferMissingItemsTo('${d.key}')" 
                    class="px-3 py-1.5 ${d.color} text-white rounded-xl text-xs font-extrabold transition flex items-center space-x-1.5 cursor-pointer shadow-xs active:scale-98"
                    title="Bu ${missing.length} eksik ilacı ${d.name} deposunda sorgulayıp sepete ekle"
                >
                    <i class="${d.icon} text-[10px]"></i>
                    <span>${d.name}'a Gönder (${missing.length})</span>
                </button>
            `).join('') + `
                <button 
                    type="button" 
                    onclick="copyMissingItemsToClipboard()" 
                    class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer active:scale-98" 
                    title="Eksik ürünleri panoya kopyala"
                >
                    <i class="fa-solid fa-copy text-[10px]"></i>
                    <span>Kopyala</span>
                </button>
            `;
        }

        function renderDepoBreakdownPills() {
            const breakdownEl = document.getElementById('bulkModalDepoBreakdown');
            if (!breakdownEl) return;

            const sessions = window.currentBulkState ? window.currentBulkState.depoSessions : {};
            const keys = Object.keys(sessions);
            if (keys.length === 0) {
                breakdownEl.classList.add('hidden');
                return;
            }

            breakdownEl.classList.remove('hidden');
            const colors = {
                'ALLIANCE': 'bg-sky-50 border-sky-300 text-sky-900',
                'SELCUK': 'bg-rose-50 border-rose-300 text-rose-900',
                'ISKOOP': 'bg-emerald-50 border-emerald-300 text-emerald-900',
                'NEVZAT': 'bg-amber-50 border-amber-300 text-amber-900'
            };

            breakdownEl.innerHTML = keys.map(k => {
                const s = sessions[k];
                const cStyle = colors[k] || 'bg-slate-50 border-slate-300 text-slate-900';
                return `
                    <div class="p-2.5 rounded-xl border ${cStyle} flex flex-col justify-between shadow-2xs">
                        <div class="flex items-center justify-between text-[11px] font-bold">
                            <span>${s.name}</span>
                            <a href="${s.cartUrl}" target="_blank" rel="noopener noreferrer" class="text-[10px] underline font-extrabold hover:opacity-80">Sepeti Aç ↗</a>
                        </div>
                        <div class="mt-1 flex items-baseline justify-between">
                            <span class="text-xs font-black">${s.count} Kalem Eklendi</span>
                            <span class="text-[10px] font-mono font-bold">${(s.amount || 0).toFixed(2)} ₺</span>
                        </div>
                        <button type="button" onclick="openBulkFinalizeFlow('${k}')" class="mt-2 w-full py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[10px] transition flex items-center justify-center space-x-1 cursor-pointer shadow-xs">
                            <i class="fa-solid fa-paper-plane text-[9px]"></i>
                            <span>${s.name} Siparişini Sonlandır</span>
                        </button>
                    </div>
                `;
            }).join('');
        }

        async function triggerBulkOrder(depoKodu = 'ALLIANCE') {
            const depo = (depoKodu || 'ALLIANCE').toUpperCase();
            const cfg = DEPO_BULK_CONFIGS[depo] || DEPO_BULK_CONFIGS['ALLIANCE'];

            const checks = document.querySelectorAll('.bulkItemCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', `Lütfen sepete aktarmak için en az bir ilaç seçiniz.`, 'info');
                return;
            }

            const itemsToOrder = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
                if (it) {
                    const input = document.getElementById(`bulkQtyInput_${idx}`);
                    const qty = input ? (parseInt(input.value) || 1) : 1;
                    itemsToOrder.push({
                        barcode: it.barkod,
                        name: it.urun_adi,
                        miktar: qty
                    });
                }
            });

            // State sıfırla
            window.currentBulkState = {
                depo: depo,
                initialDepo: depo,
                requestedItems: itemsToOrder,
                depoSessions: {},
                missingItems: [],
                allResults: itemsToOrder.map(it => ({
                    barcode: it.barcode,
                    name: it.name,
                    miktar: it.miktar,
                    status: 'PENDING',
                    assigned_depo: null,
                    net_fiyat: 0,
                    vade: 30,
                    message: 'İşleniyor...'
                }))
            };
            window.activeBulkResultTab = 'ALL';

            // Modalı aç
            const modal = document.getElementById('bulkOrderModal');
            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
            }

            const modalTitle = document.getElementById('bulkModalTitle');
            const modalDesc = document.getElementById('bulkModalDesc');
            const modalIcon = document.getElementById('bulkModalIcon');
            const modalTargetDepo = document.getElementById('bulkModalTargetDepo');
            const modalCartLink = document.getElementById('bulkModalCartLink');
            const modalCartText = document.getElementById('bulkModalCartBtnText');

            if (modalTitle) modalTitle.innerText = cfg.title;
            if (modalDesc) modalDesc.innerText = cfg.desc;
            if (modalTargetDepo) modalTargetDepo.innerText = `${cfg.name} B2B`;
            if (modalIcon) modalIcon.className = cfg.icon;
            if (modalCartLink) {
                modalCartLink.href = cfg.cartUrl;
                modalCartLink.onclick = function(e) {
                    e.preventDefault();
                    window.open(cfg.cartUrl, '_blank', 'noopener,noreferrer');
                    return false;
                };
            }
            if (modalCartText) modalCartText.innerText = cfg.cartBtnText;

            // Gizle
            const missingBar = document.getElementById('bulkTransferMissingBar');
            if (missingBar) missingBar.classList.add('hidden');
            const breakdownEl = document.getElementById('bulkModalDepoBreakdown');
            if (breakdownEl) breakdownEl.classList.add('hidden');

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');
            const statTotal = document.getElementById('bulkStatTotal');
            const statSuccess = document.getElementById('bulkStatSuccess');
            const statFailed = document.getElementById('bulkStatFailed');
            const statAmount = document.getElementById('bulkStatAmount');

            if (statTotal) statTotal.innerText = itemsToOrder.length;
            if (statSuccess) statSuccess.innerText = '0';
            if (statFailed) statFailed.innerText = '0';
            if (statAmount) statAmount.innerText = '0.00 ₺';
            if (pBar) pBar.style.width = '20%';
            if (pPercent) pPercent.innerText = '%20';
            if (pText) pText.innerText = `${cfg.name} sepetine ${itemsToOrder.length} kalem aktarılıyor (Hızlı Gönderim)...`;
            if (pSpinner) pSpinner.className = 'fa-solid fa-spinner fa-spin text-sky-600';

            renderBulkItemsTable();

            let progress = 20;
            const progressInterval = setInterval(() => {
                if (progress < 90) {
                    progress += 10;
                    if (pBar) pBar.style.width = `${progress}%`;
                    if (pPercent) pPercent.innerText = `%${progress}`;
                }
            }, 300);

            try {
                const res = await fetch('/api/cart/bulk-add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        items: itemsToOrder,
                        cascade: false // TEK DEPO ULTRA HIZLI
                    })
                });
                clearInterval(progressInterval);

                const data = await res.json();
                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '%100';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-check text-emerald-600';

                if (data.success || data.success_count > 0 || data.items) {
                    const successCount = data.success_count || 0;
                    const totalAmount = data.total_amount || 0;

                    // Depo sepet oturumunu kaydet
                    window.currentBulkState.depoSessions[depo] = {
                        count: successCount,
                        amount: totalAmount,
                        name: cfg.name,
                        cartUrl: cfg.cartUrl
                    };

                    // Eksik ürünleri topla
                    const missing = [];
                    const results = data.items || [];
                    results.forEach(r => {
                        const target = window.currentBulkState.allResults.find(it => it.barcode === r.barcode);
                        if (r.success) {
                            if (target) {
                                target.status = 'ADDED';
                                target.assigned_depo = depo;
                                target.urun_id = r.urun_id || target.urun_id || '';
                                target.net_fiyat = r.net_fiyat || 0;
                                target.vade = r.vade || 30;
                                target.message = r.message || 'Eklendi';
                            }
                        } else {
                            if (target) {
                                target.status = 'YOK';
                                target.message = r.message || `${cfg.shortName}'ta Stok Yok`;
                            }
                            missing.push({
                                barcode: r.barcode,
                                name: r.name || (target ? target.name : r.barcode),
                                miktar: r.miktar || (target ? target.miktar : 1),
                                message: r.message || `${cfg.shortName}'ta Yok`
                            });
                        }
                    });

                    window.currentBulkState.missingItems = missing;

                    // UI Güncelle
                    if (statSuccess) statSuccess.innerText = `${successCount} Kalem`;
                    if (statFailed) statFailed.innerText = `${missing.length} Kalem`;
                    if (statAmount) statAmount.innerText = `${totalAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;
                    
                    const tabAllCount = document.getElementById('bulkTabCountAll');
                    const tabYokCount = document.getElementById('bulkTabCountYok');
                    if (tabAllCount) tabAllCount.innerText = itemsToOrder.length;
                    if (tabYokCount) tabYokCount.innerText = missing.length;

                    if (pText) {
                        pText.innerHTML = `<strong>Tamamlandı:</strong> ${successCount} Kalem ${cfg.name} sepetine eklendi! ${missing.length > 0 ? `<span class="text-rose-600 font-bold ml-1">(${missing.length} kalem bu depoda bulunamadı)</span>` : ''}`;
                    }

                    renderDepoBreakdownPills();
                    renderTransferMissingBar(depo);
                    renderBulkItemsTable();

                    showToast(`${cfg.name} Sepetine Eklendi`, `${successCount} kalem sepete yüklendi. ${missing.length > 0 ? `${missing.length} eksik kalem toplandı.` : ''}`, 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    if (pText) pText.innerText = `Aktarım uyarısı: ${data.message || 'Ürünler sepete eklenemedi'}`;
                    if (pSpinner) pSpinner.className = 'fa-solid fa-triangle-exclamation text-rose-600';
                    showToast('Aktarım Uyarısı', data.message || 'İşlem tamamlanamadı.', 'error');
                }
            } catch(e) {
                clearInterval(progressInterval);
                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '!';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-xmark text-rose-600';
                if (pText) pText.innerText = `Bağlantı hatası: ${e.message}`;
                showToast('Hata', e.message, 'error');
            }
        }

        async function transferMissingItemsTo(targetDepo) {
            const targetDepoClean = (targetDepo || '').toUpperCase();
            const cfg = DEPO_BULK_CONFIGS[targetDepoClean];
            if (!cfg) return;

            const missing = window.currentBulkState ? window.currentBulkState.missingItems : [];
            if (!missing || missing.length === 0) {
                showToast('Eksik Yok', 'Tüm ürünler depolara eklendi!', 'info');
                return;
            }

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');

            if (pBar) pBar.style.width = '20%';
            if (pPercent) pPercent.innerText = '%20';
            if (pText) pText.innerText = `${cfg.name} sepetine eksik ${missing.length} kalem aktarılıyor...`;
            if (pSpinner) pSpinner.className = 'fa-solid fa-spinner fa-spin text-sky-600';

            const toSend = [...missing];

            let progress = 20;
            const progressInterval = setInterval(() => {
                if (progress < 90) {
                    progress += 10;
                    if (pBar) pBar.style.width = `${progress}%`;
                    if (pPercent) pPercent.innerText = `%${progress}`;
                }
            }, 300);

            try {
                const res = await fetch('/api/cart/bulk-add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: targetDepoClean,
                        items: toSend,
                        cascade: false
                    })
                });
                clearInterval(progressInterval);

                const data = await res.json();
                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '%100';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-check text-emerald-600';

                if (data.success || data.success_count > 0 || data.items) {
                    const newSuccess = data.success_count || 0;
                    const newAmount = data.total_amount || 0;

                    // Hedef depo istatistiğini kaydet / güncelle
                    window.currentBulkState.depo = targetDepoClean;
                    if (!window.currentBulkState.depoSessions[targetDepoClean]) {
                        window.currentBulkState.depoSessions[targetDepoClean] = {
                            count: newSuccess,
                            amount: newAmount,
                            name: cfg.name,
                            cartUrl: cfg.cartUrl
                        };
                    } else {
                        window.currentBulkState.depoSessions[targetDepoClean].count += newSuccess;
                        window.currentBulkState.depoSessions[targetDepoClean].amount += newAmount;
                    }

                    // Kalan eksikleri hesapla
                    const stillMissing = [];
                    const results = data.items || [];
                    results.forEach(r => {
                        const target = window.currentBulkState.allResults.find(it => it.barcode === r.barcode);
                        if (r.success) {
                            if (target) {
                                target.status = 'ADDED';
                                target.assigned_depo = targetDepoClean;
                                target.net_fiyat = r.net_fiyat || 0;
                                target.vade = r.vade || 30;
                                target.message = r.message || 'Eklendi';
                            }
                        } else {
                            if (target && target.status !== 'ADDED') {
                                target.message = r.message || `${cfg.shortName}'ta da Yok`;
                            }
                            stillMissing.push({
                                barcode: r.barcode,
                                name: r.name || (target ? target.name : r.barcode),
                                miktar: r.miktar || (target ? target.miktar : 1),
                                message: r.message || `${cfg.shortName}'ta da Yok`
                            });
                        }
                    });

                    window.currentBulkState.missingItems = stillMissing;

                    // Toplam başarı ve tutar hesapla
                    let totalAdded = 0;
                    let totalAmount = 0;
                    Object.values(window.currentBulkState.depoSessions).forEach(s => {
                        totalAdded += s.count;
                        totalAmount += s.amount;
                    });

                    const statSuccess = document.getElementById('bulkStatSuccess');
                    const statFailed = document.getElementById('bulkStatFailed');
                    const statAmount = document.getElementById('bulkStatAmount');
                    const tabYokCount = document.getElementById('bulkTabCountYok');

                    if (statSuccess) statSuccess.innerText = `${totalAdded} Kalem`;
                    if (statFailed) statFailed.innerText = `${stillMissing.length} Kalem`;
                    if (statAmount) statAmount.innerText = `${totalAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;
                    if (tabYokCount) tabYokCount.innerText = stillMissing.length;

                    if (pText) {
                        pText.innerHTML = `<strong>${cfg.name} Tamamlandı:</strong> ${newSuccess} Kalem sepete eklendi! ${stillMissing.length > 0 ? `<span class="text-rose-600 font-bold">(${stillMissing.length} kalem halen bulunamadı)</span>` : '<span class="text-emerald-600 font-bold">(Tüm eksikler tamamlandı!)</span>'}`;
                    }

                    renderDepoBreakdownPills();
                    renderTransferMissingBar(targetDepoClean);
                    renderBulkItemsTable();

                    showToast(`${cfg.name} Aktarımı Yapıldı`, `${newSuccess} kalem ${cfg.name} sepetine eklendi. ${stillMissing.length > 0 ? `${stillMissing.length} kalem kaldı.` : 'Tüm ürünler tamamlandı!'}`, 'success');
                } else {
                    if (pText) pText.innerText = `Aktarım uyarısı: ${data.message || 'Ürünler sepete eklenemedi'}`;
                    showToast('Aktarım Uyarısı', data.message || 'İşlem tamamlanamadı.', 'error');
                }
            } catch(e) {
                clearInterval(progressInterval);
                if (pText) pText.innerText = `Bağlantı hatası: ${e.message}`;
                showToast('Hata', e.message, 'error');
            }
        }

        // Geriye dönük uyumluluk için alias
        const triggerBulkAllianceOrder = () => triggerBulkOrder('ALLIANCE');

        // Sayfa yüklendiğinde aktif otomasyonu çek, Botanik MS SQL, Tria Oracle ve Tebeos PostgreSQL bağlantılarını test et ve durumları güncelle
        document.addEventListener('DOMContentLoaded', async () => {
            try {
                const res = await fetch('/api/settings/credentials');
                if (res.ok) {
                    const c = await res.json();
                    if (c.active_otomasyon) {
                        window.activeOtomasyon = c.active_otomasyon;
                    }
                }
            } catch(e) {}
            refreshHeaderActiveOtomasyon();
            refreshDepoStatusBadge();
            checkBotanikStatusOnLoad();
            checkTriaStatusOnLoad();
            checkTebeosStatusOnLoad();
            initMarketSuggest();
            loadCriticalStockList(false);
            setTimeout(() => checkAppUpdate(false), 2000);
            setInterval(() => checkAppUpdate(false), 180000);
        });
    </script>
</body>
</html>
"""
    return HTMLResponse(content=html_content)

if __name__ == "__main__":
    import uvicorn
    import socket

    host = os.environ.get("SERVER_HOST", "0.0.0.0")
    port = int(os.environ.get("SERVER_PORT", "8080"))

    local_ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass

    print("\n" + "=" * 65)
    print("  🚀 ECZANE DEPO ŞART & MF SİSTEMİ ÇALIŞIYOR")
    print(f"  📍 Bu Bilgisayardan Erişim : http://localhost:{port}")
    print(f"  🌐 Eczane Ağından Erişim   : http://{local_ip}:{port}")
    print("=" * 65 + "\n")

    import threading
    import webbrowser
    import subprocess

    def _auto_open_browser():
        time.sleep(1.0)
        url = f"http://localhost:{port}"
        chrome_candidates = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
        ]
        opened = False
        for c_exe in chrome_candidates:
            if os.path.exists(c_exe):
                try:
                    subprocess.Popen([c_exe, f"--app={url}", "--window-size=1440,920"])
                    opened = True
                    break
                except Exception:
                    pass
        if not opened:
            try:
                webbrowser.open(url)
            except Exception:
                pass

    # Eğer port zaten aktifse (sistem arka planda çalışıyorsa), sadece tarayıcıyı aç ve çık
    def _is_port_busy(p):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            return s.connect_ex(('127.0.0.1', p)) == 0

    if _is_port_busy(port):
        print(f"\n[BILGI] Sistem zaten {port} portunda calisiyor!")
        print(f"Tarayici aciliyor: http://localhost:{port}\n")
        _auto_open_browser()
        time.sleep(1.5)
        sys.exit(0)

    threading.Thread(target=_auto_open_browser, daemon=True).start()

    uvicorn.run(app, host=host, port=port, reload=False)

