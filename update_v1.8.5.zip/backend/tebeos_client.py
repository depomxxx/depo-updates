# -*- coding: utf-8 -*-
"""
backend/tebeos_client.py
------------------------
TEBEOS (Türk Eczacıları Birliği Eczane Otomasyon Sistemi - PostgreSQL) Veri Erişim & Analiz Modülü.
Hiçbir harici kütüphane (psycopg2 / pg8000) gerektirmeden, %100 saf Python PostgreSQL v3 Wire Protocol
üzerinden (Port 5454) eczane raf stoğu, aylık nakit ve SGK reçeteli satış hareketlerini (ÇIKIŞ),
depolardan gelen alış faturalarını (GİRİŞ) ve SGK eşdeğer ilaç gruplarını sorgular.
"""

import os
import re
import time
import socket
import struct
import hashlib
import hmac
import base64
import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any, List, Optional, Tuple


def _sql_lit(val: Any) -> str:
    """Değeri güvenli PostgreSQL SQL literal formatına dönüştürür."""
    if val is None:
        return "NULL"
    if isinstance(val, bool):
        return "TRUE" if val else "FALSE"
    if isinstance(val, (int, float)):
        return str(val)
    s = str(val).replace("\x00", "").replace("'", "''")
    return f"'{s}'"


_sql_quote = _sql_lit


def _sql_in(values: List[Any]) -> str:
    if not values:
        return "('')"
    return "(" + ", ".join(_sql_lit(v) for v in values) + ")"


class TebeosWireConnection:
    """
    Harici C/pip bağımlılığı olmadan (runtime/Tria.exe ile %100 uyumlu)
    PostgreSQL v3 Wire Protocol (TCP 5454) bağlantı sınıfı.
    Trust (0), Cleartext (3), MD5 (5) ve SCRAM-SHA-256 (10) kimlik doğrulamalarını destekler.
    """
    def __init__(self, host: str, port: int = 5454, user: str = "tebeos", password: str = "123", database: str = "tebeos_db", timeout: float = 5.0):
        self.host = host
        self.port = int(port)
        self.user = user
        self.password = password
        self.database = database
        self.timeout = timeout
        self.sock: Optional[socket.socket] = None

    def connect(self):
        self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        params = (
            f"user\x00{self.user}\x00"
            f"database\x00{self.database}\x00"
            f"client_encoding\x00UTF8\x00"
            f"application_name\x00EczaneDepoPro\x00\x00"
        ).encode("utf-8")
        startup_pkt = struct.pack("!II", len(params) + 8, 196608) + params
        self.sock.sendall(startup_pkt)

        while True:
            mtype, body = self._recv_msg()
            if mtype == "R":
                auth_type = struct.unpack("!I", body[:4])[0]
                if auth_type == 0:
                    continue
                elif auth_type == 3:
                    # Cleartext password
                    payload = self.password.encode("utf-8") + b"\x00"
                    self.sock.sendall(b"p" + struct.pack("!I", len(payload) + 4) + payload)
                elif auth_type == 5:
                    # MD5 password (TEBEOS varsayılan pg_authid rolpassword md5 özetini doğrudan destekler)
                    salt = body[4:8]
                    if self.user.lower() == "tebeos" and (self.password or "") in ("123", "", "tebeos"):
                        h1 = "ff7f8356ec682fa02db378d1bbd847e8"
                    else:
                        h1 = hashlib.md5((self.password + self.user).encode("utf-8")).hexdigest()
                    h2 = "md5" + hashlib.md5(h1.encode("ascii") + salt).hexdigest()
                    payload = h2.encode("ascii") + b"\x00"
                    self.sock.sendall(b"p" + struct.pack("!I", len(payload) + 4) + payload)
                elif auth_type == 10:
                    # SCRAM-SHA-256
                    self._handle_scram_sha256()
                else:
                    raise RuntimeError(f"Desteklenmeyen PostgreSQL auth tipi: {auth_type}")
            elif mtype == "E":
                raise RuntimeError(self._parse_error(body))
            elif mtype == "Z":
                break
        return self

    def _handle_scram_sha256(self):
        client_nonce = base64.b64encode(os.urandom(18)).decode("ascii")
        client_first_bare = f"n=,r={client_nonce}"
        gs2_header = "n,,"
        client_first_msg = (gs2_header + client_first_bare).encode("utf-8")
        mech = b"SCRAM-SHA-256\x00"
        sasl_initial = mech + struct.pack("!I", len(client_first_msg)) + client_first_msg
        self.sock.sendall(b"p" + struct.pack("!I", len(sasl_initial) + 4) + sasl_initial)

        mtype, body = self._recv_msg()
        if mtype == "E":
            raise RuntimeError(self._parse_error(body))
        auth_sub = struct.unpack("!I", body[:4])[0]
        if auth_sub != 11:
            raise RuntimeError(f"SCRAM adım hatası: {auth_sub}")
        server_first = body[4:].decode("utf-8")
        parts = dict(item.split("=", 1) for item in server_first.split(","))
        r_nonce = parts["r"]
        salt = base64.b64decode(parts["s"])
        iters = int(parts["i"])

        salted_pwd = hashlib.pbkdf2_hmac("sha256", self.password.encode("utf-8"), salt, iters)
        client_key = hmac.new(salted_pwd, b"Client Key", hashlib.sha256).digest()
        stored_key = hashlib.sha256(client_key).digest()
        client_final_without_proof = f"c={base64.b64encode(gs2_header.encode()).decode()},r={r_nonce}"
        auth_msg = f"{client_first_bare},{server_first},{client_final_without_proof}".encode("utf-8")
        client_sig = hmac.new(stored_key, auth_msg, hashlib.sha256).digest()
        client_proof = bytes(a ^ b for a, b in zip(client_key, client_sig))
        client_final = f"{client_final_without_proof},p={base64.b64encode(client_proof).decode()}".encode("utf-8")
        self.sock.sendall(b"p" + struct.pack("!I", len(client_final) + 4) + client_final)

    def _recv_exact(self, n: int) -> bytes:
        buf = bytearray()
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("PostgreSQL bağlantısı kapandı.")
            buf.extend(chunk)
        return bytes(buf)

    def _recv_msg(self) -> Tuple[str, bytes]:
        hdr = self._recv_exact(5)
        mtype = chr(hdr[0])
        mlen = struct.unpack("!I", hdr[1:5])[0] - 4
        body = self._recv_exact(mlen) if mlen > 0 else b""
        return mtype, body

    @staticmethod
    def _decode_pg_bytes(raw: bytes) -> str:
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            return raw.decode("cp1254", errors="replace")

    def _parse_error(self, body: bytes) -> str:
        msgs = []
        pos = 0
        while pos < len(body):
            code = body[pos]
            if code == 0:
                break
            end = body.find(b"\x00", pos + 1)
            if end == -1:
                break
            val = self._decode_pg_bytes(body[pos + 1:end])
            if chr(code) in ("M", "D", "H"):
                msgs.append(val)
            pos = end + 1
        return " | ".join(msgs) if msgs else self._decode_pg_bytes(body)

    def query(self, sql: str) -> Tuple[List[str], List[List[Optional[str]]]]:
        """SQL sorgusunu çalıştırır ve (kolon_listesi, satir_listesi) döner."""
        q_bytes = sql.encode("utf-8") + b"\x00"
        self.sock.sendall(b"Q" + struct.pack("!I", len(q_bytes) + 4) + q_bytes)
        cols: List[str] = []
        rows: List[List[Optional[str]]] = []
        err_msg: Optional[str] = None

        while True:
            mtype, body = self._recv_msg()
            if mtype == "T":
                ncols = struct.unpack("!H", body[:2])[0]
                pos = 2
                cols = []
                for _ in range(ncols):
                    end = body.index(b"\x00", pos)
                    cols.append(body[pos:end].decode("utf-8", errors="replace"))
                    pos = end + 19
            elif mtype == "D":
                ncols = struct.unpack("!H", body[:2])[0]
                pos = 2
                row: List[Optional[str]] = []
                for _ in range(ncols):
                    clen = struct.unpack("!i", body[pos:pos + 4])[0]
                    pos += 4
                    if clen == -1:
                        row.append(None)
                    else:
                        row.append(body[pos:pos + clen].decode("utf-8", errors="replace"))
                        pos += clen
                rows.append(row)
            elif mtype == "E":
                err_msg = self._parse_error(body)
            elif mtype == "Z":
                break

        if err_msg:
            raise RuntimeError(err_msg)
        return cols, rows

    def close(self):
        if self.sock:
            try:
                self.sock.sendall(b"X\x00\x00\x00\x04")
            except Exception:
                pass
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None

    def __enter__(self):
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


def _expand_barcode_variants(barcodes: List[str]) -> Dict[str, List[str]]:
    """
    Her bir barkod için TEBEOS'ta 8/11/12/13/14 haneli (başındaki sıfır farklılıkları dahil)
    format varyasyonlarını deterministik olarak üretir. Ürünler arası katalog birleştirmesi YAPMAZ.
    Dönüş: {orijinal_barkod: [varyasyon_1, varyasyon_2, ...]} (ilk eleman daima orijinal barkoddur).
    """
    out: Dict[str, List[str]] = {}
    for raw_b in (barcodes or []):
        b = str(raw_b or "").strip()
        if not b:
            continue
        vars_list = [b]
        if b.isdigit() and len(b) >= 7:
            candidates = [b]
            if len(b) == 16 and b.startswith("010"):
                candidates.append(b[3:16])
            for cand in candidates:
                core = cand.lstrip("0")
                if len(core) >= 7:
                    if core not in vars_list:
                        vars_list.append(core)
                    for pad_len in (12, 13, 14):
                        if len(core) <= pad_len:
                            padded = core.zfill(pad_len)
                            if padded not in vars_list:
                                vars_list.append(padded)
                if len(cand) == 13 and ("0" + cand) not in vars_list:
                    vars_list.append("0" + cand)
                elif len(cand) == 14 and cand.startswith("0") and cand[1:] not in vars_list:
                    vars_list.append(cand[1:])
        out[b] = vars_list
    return out


class TebeosPGClient:
    """
    TEBEOS Eczane Otomasyonu (PostgreSQL - Port 5454) İstemcisi.
    Botanik ve TRIA ile birebir aynı veri şemasını üretir.
    """
    # TEBEOS Hareket Tipi Grupları (public.urun_hareket_tip_lp)
    # SGK / Kurum / Medula Reçeteli Satış Çıkışları
    RECETE_CIKIS_TIPLERI = (9, 27, 29, 37, 53, 56)
    # SGK / Kurum / Medula Satış İptal / Silme / İade Girişleri (Örn: 34 Medula Satış İptal)
    RECETE_IPTAL_TIPLERI = (10, 34, 41, 44, 51, 54, 55)
    # Nakit / Elden / Veresiye / Reçetesiz Satış Çıkışları
    NAKIT_CIKIS_TIPLERI = (11, 13, 25)
    # Nakit / Elden / Veresiye Satış Silme / İade Girişleri
    NAKIT_IPTAL_TIPLERI = (12, 14, 40, 43)
    # Tüm Satış Çıkışları ve İptal/İadeleri (stok_hareket_ms yedek sabitleri)
    TUM_SATIS_CIKIS_TIPLERI = (9, 11, 13, 25, 27, 29, 37, 53, 56)
    TUM_SATIS_IPTAL_TIPLERI = (10, 12, 14, 34, 40, 41, 43, 44, 51, 54, 55)
    TUM_SATIS_VE_IPTAL_TIPLERI = (9, 10, 11, 12, 13, 14, 25, 27, 29, 34, 37, 40, 41, 43, 44, 51, 53, 54, 55, 56)

    # TEBEOS Kendi Ürün Satış Ekranı (raporlama.alis_satis_raporu_tarihe_bagli_yeni) ile %100 Birebir Aktif Satış Tablosu Bağlantısı:
    # Emanet devri ve ay sonu reçete/karekod düzeltmelerinden kaynaklanan aylar arası kaymaları %100 önler.
    SATIS_MS_FROM_SQL = (
        "FROM satis.satis_ms s "
        "JOIN satis.satis_hareket_stok_hareket_ju_ms shsh "
        "  ON shsh.satis_id = s.satis_id AND shsh.satis_hareket_aktif = 1::bit "
        "JOIN stok.stok_hareket_ms sh "
        "  ON sh.stok_hareket_id = shsh.stok_hareket_id"
    )
    SATIS_MS_ACTIVE_WHERE = "s.satis_aktif = 1::bit AND s.degistirme_tarihi IS NULL"

    def _sql_satis_ms_expr(self, date_cond: str = "", mode: str = "all", s_alias: str = "s", sh_alias: str = "sh") -> str:
        """
        TEBEOS'un kendi ürün kartı ay-ay satış raporuyla (alis_satis_raporu_tarihe_bagli_yeni) %100 aynı
        net satış çıkış kutu sayısını hesaplayan SQL ifadesi.
        - s.satis_tip IN (2, 3): Reçeteli Satış (2: Kurum Reçetesi, 3: Medula Reçetesi)
        - s.satis_tip NOT IN (2, 3): Nakit / Elden Satış (1: Nakit Satış, 99: İadeli Satış vb.)
        """
        conds = []
        if date_cond:
            conds.append(f"({date_cond})")
        if mode == "recete":
            conds.append(f"COALESCE({s_alias}.satis_tip, 0) IN (2, 3)")
        elif mode == "nakit":
            conds.append(f"COALESCE({s_alias}.satis_tip, 1) NOT IN (2, 3)")
        if conds:
            when_sql = " AND ".join(conds)
            return f"GREATEST(0, COALESCE(SUM(CASE WHEN {when_sql} THEN (-1 * {sh_alias}.adet) ELSE 0 END), 0))"
        return f"GREATEST(0, COALESCE(SUM(-1 * {sh_alias}.adet), 0))"

    def _sql_net_sales_expr(self, date_cond: str = "", mode: str = "all", alias: str = "h") -> str:
        """İptal/silme/iade hareketlerini düşerek net satış çıkış kutu sayısını hesaplayan SQL ifadesi."""
        if mode == "recete":
            out_tips = self.RECETE_CIKIS_TIPLERI
            ret_tips = self.RECETE_IPTAL_TIPLERI
        elif mode == "nakit":
            out_tips = self.NAKIT_CIKIS_TIPLERI
            ret_tips = self.NAKIT_IPTAL_TIPLERI
        else:
            out_tips = self.TUM_SATIS_CIKIS_TIPLERI
            ret_tips = self.TUM_SATIS_IPTAL_TIPLERI

        cond_prefix = f"{date_cond} AND " if date_cond else ""
        return (
            f"GREATEST(0, COALESCE(SUM(CASE "
            f"WHEN {cond_prefix}{alias}.urun_hareket_tip_id IN {out_tips} THEN ABS({alias}.adet) "
            f"WHEN {cond_prefix}{alias}.urun_hareket_tip_id IN {ret_tips} THEN -ABS({alias}.adet) "
            f"ELSE 0 END), 0))"
        )

    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self._discovered_host: Optional[str] = None

    def get_config(self) -> Dict[str, Any]:
        host = os.environ.get("TEBEOS_DB_HOST", "").strip()
        port_str = os.environ.get("TEBEOS_DB_PORT", "5454").strip()
        database = os.environ.get("TEBEOS_DB_DATABASE", "tebeos_db").strip()
        user = os.environ.get("TEBEOS_DB_USER", "tebeos").strip()
        password = os.environ.get("TEBEOS_DB_PASSWORD", "123").strip()

        try:
            port = int(port_str or 5454)
        except Exception:
            port = 5454

        return {
            "host": host or self._discovered_host or "127.0.0.1",
            "port": port,
            "database": database or "tebeos_db",
            "user": user or "tebeos",
            "password": password or "123"
        }

    def _get_local_subnet_ips(self) -> List[str]:
        ips = []
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            parts = local_ip.split(".")
            if len(parts) == 4 and parts[0] in ("192", "10", "172"):
                prefix = f"{parts[0]}.{parts[1]}.{parts[2]}."
                ips = [f"{prefix}{i}" for i in range(1, 255) if f"{prefix}{i}" != local_ip]
        except Exception:
            pass
        return ips

    def _is_local_host(self, host: str) -> bool:
        h = (host or "").strip().lower()
        if h in ("", "127.0.0.1", "localhost", "::1", "0.0.0.0"):
            return True
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            if h == local_ip:
                return True
        except Exception:
            pass
        try:
            for info in socket.getaddrinfo(socket.gethostname(), None):
                if info[4] and info[4][0] == h:
                    return True
        except Exception:
            pass
        return False

    def ensure_local_tebeos_pg_trust(self) -> Dict[str, Any]:
        """
        Bu bilgisayar TEBEOS Ana Makinesi ise (yerelde PostgreSQL 5454 kuruluysa),
        pg_hba.conf dosyasını otomatik bulup 'md5' yerine 'trust' (şifresiz ağ erişimi)
        ayarını uygular, 5454 güvenlik duvarı portunu açar ve PostgreSQL ayarlarını
        TEBEOS'u kapatmadan canlı olarak yeniden yükler (pg_ctl reload).
        """
        import glob
        import subprocess
        import tempfile

        candidate_files: List[str] = []

        def _add_candidate(path_str: str):
            p = (path_str or "").strip().strip('"').strip("'")
            if not p:
                return
            if os.path.isdir(p):
                p = os.path.join(p, "pg_hba.conf")
            if os.path.exists(p) and p not in candidate_files:
                candidate_files.append(p)

        # 1. Windows Registry (Services) üzerinden tüm PostgreSQL / TEBEOS servislerinin -D (data) ve bin yollarını oku (Yetki gerektirmez, 5ms sürer)
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services") as srv_key:
                num_subkeys = winreg.QueryInfoKey(srv_key)[0]
                for i in range(num_subkeys):
                    sub_name = winreg.EnumKey(srv_key, i)
                    try:
                        with winreg.OpenKey(srv_key, sub_name) as sk:
                            img_path, _ = winreg.QueryValueEx(sk, "ImagePath")
                            img_str = str(img_path or "")
                            if any(k in img_str.lower() for k in ("postgres", "pg_ctl", "tebeos", "5454")):
                                for m in re.finditer(r'-D\s+"([^"]+)"|-D\s+(\S+)', img_str):
                                    _add_candidate(m.group(1) or m.group(2) or "")
                                exe_m = re.search(r'"([^"]+(?:postgres|pg_ctl)\.exe)"|(\S+(?:postgres|pg_ctl)\.exe)', img_str, re.I)
                                if exe_m:
                                    exe_p = exe_m.group(1) or exe_m.group(2)
                                    base_dir = os.path.dirname(os.path.dirname(exe_p))
                                    _add_candidate(os.path.join(base_dir, "data", "pg_hba.conf"))
                    except Exception:
                        pass
        except Exception:
            pass

        # 2. Çalışan postgres.exe sürecinin dosya konumundan ve komut satırından yakala
        _no_win_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000) if os.name == "nt" else 0
        try:
            ps_find = (
                "Get-Process postgres -ErrorAction SilentlyContinue | ForEach-Object { "
                "if ($_.Path) { Split-Path (Split-Path $_.Path -Parent) -Parent } }; "
                "Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'postgres' } | ForEach-Object { $_.CommandLine }"
            )
            out = subprocess.check_output(
                ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps_find],
                creationflags=_no_win_flags,
                stdin=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                text=True,
                errors="replace",
                timeout=5
            )
            for line in out.splitlines():
                line_s = line.strip()
                if not line_s:
                    continue
                if os.path.isdir(line_s):
                    _add_candidate(os.path.join(line_s, "data", "pg_hba.conf"))
                for m in re.finditer(r'-D\s+"([^"]+)"|-D\s+(\S+)', line_s):
                    _add_candidate(m.group(1) or m.group(2) or "")
        except Exception:
            pass

        # 3. Bilinen TEBEOS ve PostgreSQL kurulum dizinlerini tara
        for drive in ("C:", "D:", "E:"):
            if not os.path.exists(drive + "\\"):
                continue
            patterns = [
                f"{drive}\\Program Files (x86)\\TebeosPlus\\data\\pg_hba.conf",
                f"{drive}\\Program Files\\TebeosPlus\\data\\pg_hba.conf",
                f"{drive}\\Program Files (x86)\\TebeosPlus\\*\\data\\pg_hba.conf",
                f"{drive}\\Program Files (x86)\\TebeosPlus\\pgsql\\data\\pg_hba.conf",
                f"{drive}\\Program Files (x86)\\Tebeos*\\data\\pg_hba.conf",
                f"{drive}\\Program Files (x86)\\Tebeos*\\*\\data\\pg_hba.conf",
                f"{drive}\\Program Files\\Tebeos*\\data\\pg_hba.conf",
                f"{drive}\\Program Files\\Tebeos*\\*\\data\\pg_hba.conf",
                f"{drive}\\Tebeos*\\data\\pg_hba.conf",
                f"{drive}\\Tebeos*\\*\\data\\pg_hba.conf",
                f"{drive}\\TEBEOS*\\data\\pg_hba.conf",
                f"{drive}\\TEBEOS*\\*\\data\\pg_hba.conf",
                f"{drive}\\Program Files\\PostgreSQL\\*\\data\\pg_hba.conf",
                f"{drive}\\Program Files (x86)\\PostgreSQL\\*\\data\\pg_hba.conf",
                f"{drive}\\PostgreSQL\\*\\data\\pg_hba.conf",
            ]
            for pat in patterns:
                for p in glob.glob(pat):
                    _add_candidate(p)

        if not candidate_files:
            return {
                "success": False,
                "found": False,
                "message": "Bu bilgisayarda yerel TEBEOS PostgreSQL (pg_hba.conf) kurulumu bulunamadı. Lütfen bu işlemi TEBEOS Ana Makinesinde (192.168.1.24) çalıştırın."
            }

        ps_lines = [
            "$ErrorActionPreference = 'Continue'",
            "netsh advfirewall firewall add rule name=\"TEBEOS PostgreSQL 5454\" dir=in action=allow protocol=TCP localport=5454 | Out-Null",
        ]
        for hba_path in candidate_files:
            data_dir = os.path.dirname(hba_path)
            pg_bin = os.path.join(os.path.dirname(data_dir), "bin", "pg_ctl.exe")
            ps_lines.append(f"$hba = '{hba_path}'")
            ps_lines.append("if (Test-Path -LiteralPath $hba) {")
            ps_lines.append(f"  Copy-Item -LiteralPath $hba -Destination '{hba_path}.yedek' -Force -ErrorAction SilentlyContinue")
            ps_lines.append("  $c = Get-Content -LiteralPath $hba -Raw")
            ps_lines.append("  $c = $c -replace '(?m)^(\\s*(?:host|local)\\s+\\S+\\s+\\S+\\s+(?:\\S+\\s+)?)(md5|scram-sha-256|password|reject)', '$1trust'")
            ps_lines.append("  if ($c -notmatch '0\\.0\\.0\\.0/0\\s+trust') { $c += \"`r`nhost    all             all             0.0.0.0/0               trust`r`n\" }")
            ps_lines.append("  if ($c -notmatch '127\\.0\\.0\\.1/32\\s+trust') { $c += \"`r`nhost    all             all             127.0.0.1/32            trust`r`n\" }")
            ps_lines.append("  Set-Content -LiteralPath $hba -Value $c -Encoding ASCII -Force")
            if os.path.exists(pg_bin):
                ps_lines.append(f"  & '{pg_bin}' reload -D '{data_dir}' | Out-Null")
            ps_lines.append("}")
        ps_lines.append("Get-Service | Where-Object { $_.Name -match 'pgsql|postgres|tebeos' -and $_.Status -eq 'Running' } | ForEach-Object { Restart-Service $_.Name -Force -ErrorAction SilentlyContinue }")

        script_path = os.path.join(tempfile.gettempdir(), "tebeos_unlock_trust.ps1")
        with open(script_path, "w", encoding="utf-8") as fp:
            fp.write("\n".join(ps_lines))

        try:
            subprocess.run(
                ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", script_path],
                creationflags=_no_win_flags,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=8,
                check=False
            )
            with open(candidate_files[0], "r", encoding="utf-8", errors="ignore") as f_chk:
                txt_after = f_chk.read()
            if "0.0.0.0/0" not in txt_after or "md5" in txt_after:
                subprocess.run(
                    [
                        "powershell",
                        "-NoProfile",
                        "-WindowStyle",
                        "Hidden",
                        "-Command",
                        f"Start-Process powershell -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File \"{script_path}\"' -Verb RunAs -WindowStyle Hidden -Wait"
                    ],
                    creationflags=_no_win_flags,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=25,
                    check=False
                )
        except Exception as e:
            return {
                "success": False,
                "found": True,
                "files": candidate_files,
                "message": f"pg_hba.conf güncellenirken yetki hatası oluştu: {e}"
            }

        return {
            "success": True,
            "found": True,
            "files": candidate_files,
            "message": f"TEBEOS PostgreSQL ağ erişimi (pg_hba.conf -> trust) başarıyla açıldı: {candidate_files[0]}"
        }

    def discover_tebeos_host(self, port: int = 5454) -> Dict[str, Any]:
        """
        Yerel makinede (127.0.0.1) veya eczane yerel ağında (LAN) Port 5454 üzerinden
        çalışan TEBEOS PostgreSQL ana bilgisayarını otomatik tespit eder.
        """
        t0 = time.time()
        cfg = self.get_config()
        target_port = int(port or cfg.get("port") or 5454)

        def _probe(ip: str, timeout: float = 0.65) -> Optional[str]:
            try:
                with socket.create_connection((ip, target_port), timeout=timeout):
                    return ip
            except Exception:
                return None

        # 1. Önce yerel ve bilinen adayları hızlıca kontrol et
        priority_candidates = ["127.0.0.1"]
        if cfg.get("host") and cfg["host"] not in priority_candidates:
            priority_candidates.insert(0, cfg["host"])

        found_ip = None
        for cand in priority_candidates:
            if _probe(cand, timeout=0.6):
                found_ip = cand
                break

        # 1b. ARP tablosundaki aktif yerel ağ komşularını öncelikli kontrol et (Wi-Fi paket tıkanmasını önler)
        if not found_ip:
            try:
                import subprocess
                arp_kw: Dict[str, Any] = {"text": True, "errors": "ignore", "timeout": 2.0, "stdin": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
                if os.name == "nt":
                    si = subprocess.STARTUPINFO()
                    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                    si.wShowWindow = getattr(subprocess, "SW_HIDE", 0)
                    arp_kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
                    arp_kw["startupinfo"] = si
                arp_out = subprocess.check_output(["arp", "-a"], **arp_kw)
                arp_ips = []
                for m in re.finditer(r"\b((?:192\.168|10\.|172\.(?:1[6-9]|2\d|3[01]))\.[0-9.]+)\b", arp_out):
                    ip_str = m.group(1)
                    if not ip_str.endswith(".255") and not ip_str.endswith(".1") and ip_str not in arp_ips:
                        arp_ips.append(ip_str)
                if arp_ips:
                    with ThreadPoolExecutor(max_workers=16) as ex:
                        futs = {ex.submit(_probe, ip, 1.25): ip for ip in arp_ips}
                        for fut in as_completed(futs):
                            res_ip = fut.result()
                            if res_ip:
                                found_ip = res_ip
                                break
            except Exception:
                pass

        # 2. Bulunamadıysa tüm yerel alt ağı (/24) paralel tara
        if not found_ip:
            subnet_ips = self._get_local_subnet_ips()
            if subnet_ips:
                with ThreadPoolExecutor(max_workers=36) as ex:
                    futures = {ex.submit(_probe, ip, 1.35): ip for ip in subnet_ips}
                    for fut in as_completed(futures):
                        res_ip = fut.result()
                        if res_ip:
                            found_ip = res_ip
                            break

        elapsed_ms = round((time.time() - t0) * 1000, 1)
        if found_ip:
            self._discovered_host = found_ip
            os.environ["TEBEOS_DB_HOST"] = found_ip
            try:
                from backend.config_manager import save_credentials_to_env
                save_credentials_to_env({
                    "tebeos": {
                        "host": found_ip,
                        "port": str(target_port),
                        "database": cfg.get("database") or "tebeos_db",
                        "user": cfg.get("user") or "tebeos",
                        "password": cfg.get("password") or "123",
                    }
                })
            except Exception:
                pass
            return {
                "success": True,
                "found": True,
                "host": found_ip,
                "port": target_port,
                "database": cfg.get("database") or "tebeos_db",
                "user": cfg.get("user") or "tebeos",
                "password": cfg.get("password") or "123",
                "elapsed_ms": elapsed_ms,
                "message": f"TEBEOS sunucusu bulundu: {found_ip}:{target_port} ({elapsed_ms} ms)"
            }

        return {
            "success": False,
            "found": False,
            "elapsed_ms": elapsed_ms,
            "message": f"Yerel ağda Port {target_port} üzerinde açık TEBEOS PostgreSQL sunucusu bulunamadı."
        }

    def get_connection(self, custom_cfg: Optional[Dict[str, Any]] = None, timeout: float = 4.0) -> TebeosWireConnection:
        cfg = custom_cfg or self.get_config()
        try:
            conn = TebeosWireConnection(
                host=cfg["host"],
                port=int(cfg.get("port") or 5454),
                user=cfg.get("user") or "tebeos",
                password=cfg.get("password") or "123",
                database=cfg.get("database") or "tebeos_db",
                timeout=timeout
            )
            return conn.connect()
        except Exception as first_err:
            err_l = str(first_err).lower()
            if any(k in err_l for k in ("şifre doğrulaması", "password authentication", "pg_hba.conf", "28p01", "28000")):
                if self._is_local_host(cfg.get("host", "")):
                    fix_res = self.ensure_local_tebeos_pg_trust()
                    if fix_res.get("success"):
                        time.sleep(0.4)
                        conn = TebeosWireConnection(
                            host=cfg["host"],
                            port=int(cfg.get("port") or 5454),
                            user=cfg.get("user") or "tebeos",
                            password=cfg.get("password") or "123",
                            database=cfg.get("database") or "tebeos_db",
                            timeout=timeout
                        )
                        return conn.connect()
            if custom_cfg is None:
                disc = self.discover_tebeos_host(port=int(cfg.get("port") or 5454))
                if disc.get("found") and disc.get("host") != cfg["host"]:
                    conn = TebeosWireConnection(
                        host=disc["host"],
                        port=int(disc["port"]),
                        user=cfg.get("user") or "tebeos",
                        password=cfg.get("password") or "123",
                        database=cfg.get("database") or "tebeos_db",
                        timeout=timeout
                    )
                    return conn.connect()
            raise first_err

    def ping(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        database: Optional[str] = None,
        user: Optional[str] = None,
        password: Optional[str] = None
    ) -> Dict[str, Any]:
        """TEBEOS PostgreSQL veritabanına ping atar ve canlı istatistikleri döner."""
        base_cfg = self.get_config()
        custom_cfg = None
        if any(v is not None and str(v).strip() != "" for v in [host, port, database, user, password]):
            custom_cfg = {
                "host": (host or base_cfg["host"]).strip(),
                "port": int(port or base_cfg["port"] or 5454),
                "database": (database or base_cfg["database"]).strip(),
                "user": (user if user is not None else base_cfg["user"]).strip(),
                "password": (password if password is not None else base_cfg["password"]).strip()
            }
        cfg = custom_cfg or base_cfg
        t0 = time.time()
        try:
            with self.get_connection(custom_cfg=custom_cfg, timeout=3.5) as conn:
                active_cfg = custom_cfg or self.get_config()
                latency_ms = round((time.time() - t0) * 1000, 2)

                _, ver_rows = conn.query("SELECT version()")
                ver_raw = ver_rows[0][0] if ver_rows and ver_rows[0] else "PostgreSQL"
                version_short = ver_raw.split(",")[0] if ver_raw else "PostgreSQL 12"

                _, u_rows = conn.query("SELECT (SELECT COUNT(*) FROM ilac.urun_ms) + (SELECT COUNT(*) FROM public.idu_bilgi_ms)")
                urun_count = int(u_rows[0][0] or 0) if u_rows else 0

                _, f_rows = conn.query("SELECT COUNT(*) FROM public.fatura_ms WHERE COALESCE(aktif::text, '1') != '0'")
                fatura_count = int(f_rows[0][0] or 0) if f_rows else 0

                try:
                    _, h_rows = conn.query(f"SELECT COUNT(*) {self.SATIS_MS_FROM_SQL} WHERE {self.SATIS_MS_ACTIVE_WHERE}")
                    satis_count = int(h_rows[0][0] or 0) if h_rows else 0
                    _, t_rows = conn.query(f"SELECT COUNT(*) {self.SATIS_MS_FROM_SQL} WHERE {self.SATIS_MS_ACTIVE_WHERE} AND s.satis_tarih >= CURRENT_DATE")
                    today_satis = int(t_rows[0][0] or 0) if t_rows else 0
                except Exception:
                    _, h_rows = conn.query(f"SELECT COUNT(*) FROM stok.stok_hareket_ms WHERE urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}")
                    satis_count = int(h_rows[0][0] or 0) if h_rows else 0
                    _, t_rows = conn.query(f"SELECT COUNT(*) FROM stok.stok_hareket_ms WHERE hareket_tarih >= CURRENT_DATE AND urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}")
                    today_satis = int(t_rows[0][0] or 0) if t_rows else 0

                return {
                    "success": True,
                    "connected": True,
                    "message": f"TEBEOS PostgreSQL bağlantısı başarılı ({latency_ms} ms)",
                    "latency_ms": latency_ms,
                    "version": version_short,
                    "host": active_cfg["host"],
                    "port": active_cfg["port"],
                    "database": active_cfg["database"],
                    "user": active_cfg["user"],
                    "stats": {
                        "kayitli_urun_sayisi": urun_count,
                        "toplam_satis_hareketi": satis_count,
                        "fatura_sayisi": fatura_count,
                        "bugun_satis_sayisi": today_satis
                    }
                }
        except Exception as e:
            latency_ms = round((time.time() - t0) * 1000, 2)
            err_str = str(e)
            needs_trust = any(k in err_str.lower() for k in ("şifre doğrulaması", "password authentication", "pg_hba.conf"))
            hint = ""
            if needs_trust:
                hint = (
                    f" (ÇÖZÜM: TEBEOS Ana Makinesi [{cfg['host']}] üzerinde pg_hba.conf dosyasında 'md5' ayarı 'trust' yapılmalıdır. "
                    f"Ana makinede TEBEOS_Baglanti_Ac.bat aracını çalıştırın veya pg_hba.conf sonundaki 'md5' ifadelerini 'trust' yapıp PostgreSQL servisini yeniden başlatın.)"
                )
            return {
                "success": False,
                "connected": False,
                "needs_pg_hba_trust": needs_trust,
                "message": f"TEBEOS PostgreSQL bağlantı hatası: {err_str}{hint}",
                "latency_ms": latency_ms,
                "host": cfg["host"],
                "port": cfg["port"],
                "database": cfg["database"],
                "user": cfg["user"],
                "error": err_str
            }

    def _find_product_in_tebeos(self, conn: TebeosWireConnection, clean_q: str, barcode: str = "") -> Optional[Dict[str, Any]]:
        """
        Ürünü hem ilac.urun_ms (İlaç) hem de public.idu_bilgi_ms (İlaç Dışı Ürün / OTC / Dermo / Takviye)
        tablolarında arar. Başındaki 0 (UPC-12 / EAN-13 / GTIN-14) format farklarını normalize eder ve
        TEBEOS'un kendi stok.barkod_ile_adet_getir_fnc mantığıyla birebir aynı aktif kartı seçer.
        """
        direct_seeds: List[str] = []
        if barcode and barcode.strip().isdigit() and len(barcode.strip()) >= 7:
            direct_seeds.append(barcode.strip())
        if clean_q and clean_q.isdigit() and len(clean_q) >= 7 and clean_q not in direct_seeds:
            direct_seeds.append(clean_q)

        def _lookup_cards_by_barcodes(bc_list: List[str], exact_set: set) -> Optional[Dict[str, Any]]:
            if not bc_list:
                return None
            in_bcs = _sql_in(bc_list)
            candidates = []

            # A) İlaç kartları (ilac.urun_barkod_ms -> ilac.urun_ms)
            _, u_rows = conn.query(f"""
                SELECT u.urun_id,
                       u.urun_adi,
                       b.barkod,
                       COALESCE(f.psf, 0),
                       COALESCE(f.kdv, 10),
                       COALESCE(b.aktif::text, '1'),
                       COALESCE((SELECT SUM(h.adet) FROM stok.stok_hareket_ms h WHERE h.urun_id = u.urun_id), 0) AS stok,
                       COALESCE((SELECT COUNT(*) FROM stok.stok_hareket_ms h WHERE h.urun_id = u.urun_id), 0) AS mov_cnt
                FROM ilac.urun_barkod_ms b
                JOIN ilac.urun_ms u ON u.urun_id = b.urun_id
                LEFT JOIN LATERAL (
                    SELECT psf, kdv FROM ilac.urun_fiyat_ms uf
                    WHERE uf.urun_id = u.urun_id
                    ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                    LIMIT 1
                ) f ON true
                WHERE b.barkod IN {in_bcs}
                  AND b.urun_id > 0
            """)
            for r in u_rows:
                b_str = str(r[2] or "").strip()
                st_val = int(float(r[6] or 0))
                mv_cnt = int(r[7] or 0)
                candidates.append({
                    "is_idu": False,
                    "id": int(r[0]),
                    "name": str(r[1] or "").strip(),
                    "barkod": b_str,
                    "psf": float(r[3] or 0.0),
                    "kdv": float(r[4] or 10.0),
                    "aktif": 1 if str(r[5] or "1") != "0" else 0,
                    "stok": st_val,
                    "mov_cnt": mv_cnt,
                    "is_exact": 1 if b_str in exact_set else 0,
                })

            # B) İlaç Dışı / OTC / Takviye kartları (public.idu_barkod_ms -> public.idu_bilgi_ms)
            try:
                _, idu_rows = conn.query(f"""
                    SELECT i.idu_bilgi_id,
                           i.idu_tanim,
                           b.barkod,
                           COALESCE(f.eczane_satis_fiyat, 0),
                           COALESCE(f.idu_kdv, 10),
                           COALESCE((SELECT SUM(h.adet) FROM stok.stok_hareket_ms h WHERE h.idu_bilgi_id = i.idu_bilgi_id), 0) AS stok,
                           COALESCE((SELECT COUNT(*) FROM stok.stok_hareket_ms h WHERE h.idu_bilgi_id = i.idu_bilgi_id), 0) AS mov_cnt
                    FROM public.idu_barkod_ms b
                    JOIN public.idu_bilgi_ms i ON i.idu_bilgi_id = b.idu_bilgi_id
                    LEFT JOIN LATERAL (
                        SELECT eczane_satis_fiyat, idu_kdv FROM public.idu_fiyat_ms uf
                        WHERE uf.idu_bilgi_id = i.idu_bilgi_id
                        ORDER BY uf.idu_fiyat_id DESC
                        LIMIT 1
                    ) f ON true
                    WHERE b.barkod IN {in_bcs}
                      AND b.idu_bilgi_id > 0
                """)
                for r in idu_rows:
                    b_str = str(r[2] or "").strip()
                    st_val = int(float(r[5] or 0))
                    mv_cnt = int(r[6] or 0)
                    candidates.append({
                        "is_idu": True,
                        "id": int(r[0]),
                        "name": str(r[1] or "").strip(),
                        "barkod": b_str,
                        "psf": float(r[3] or 0.0),
                        "kdv": float(r[4] or 10.0),
                        "aktif": 1,
                        "stok": st_val,
                        "mov_cnt": mv_cnt,
                        "is_exact": 1 if b_str in exact_set else 0,
                    })
            except Exception:
                pass

            if not candidates:
                return None

            # TEBEOS önceliği: pozitif stok > tam barkod eşleşmesi > hareket görmüş kart > ilaç kartı (barkod_ile_adet_getir_fnc uyumu)
            candidates.sort(
                key=lambda c: (
                    1 if c["stok"] > 0 else (0 if c["stok"] == 0 else -1),
                    c["is_exact"],
                    1 if c["mov_cnt"] > 0 else 0,
                    0 if not c["is_idu"] else -1,
                    c["aktif"],
                    c["stok"],
                    c["id"],
                ),
                reverse=True,
            )
            best = candidates[0]
            if best["is_idu"]:
                _, bc_rows = conn.query(f"SELECT barkod FROM public.idu_barkod_ms WHERE idu_bilgi_id = {best['id']} AND barkod IS NOT NULL AND barkod <> ''")
            else:
                _, bc_rows = conn.query(f"SELECT barkod FROM ilac.urun_barkod_ms WHERE urun_id = {best['id']} AND barkod IS NOT NULL AND barkod <> ''")

            card_bcs = [x[0].strip() for x in bc_rows if x[0] and str(x[0]).strip()]
            expanded_card_bcs = set(card_bcs)
            for _, vlist in _expand_barcode_variants(card_bcs).items():
                expanded_card_bcs.update(vlist)

            return {
                "is_idu": best["is_idu"],
                "id": best["id"],
                "name": best["name"],
                "barkod": best["barkod"],
                "psf": best["psf"],
                "kdv": best["kdv"],
                "stok": best["stok"],
                "all_barcodes": list(expanded_card_bcs) or [best["barkod"]],
            }

        # 1. Önce doğrudan aranan barkod (ve başındaki 0 format varyasyonları) ile TEBEOS'ta ara
        if direct_seeds:
            var_map = _expand_barcode_variants(direct_seeds)
            direct_variants = []
            for vlist in var_map.values():
                for v in vlist:
                    if v not in direct_variants:
                        direct_variants.append(v)
            found_direct = _lookup_cards_by_barcodes(direct_variants, set(direct_seeds))
            if found_direct:
                return found_direct

            # 2. Yalnızca doğrudan barkod TEBEOS'ta HİÇ yoksa katalogdaki kardeş barkodlara (eski barkod vb.) bak
            sibling_seeds = []
            try:
                from backend.catalog import catalog
                for b in direct_seeds:
                    cat_p = catalog.get_by_barcode(b)
                    if cat_p:
                        for ab in (cat_p.get("all_barcodes") or []):
                            ab_s = str(ab or "").strip()
                            if ab_s and ab_s not in direct_variants and ab_s not in sibling_seeds:
                                sibling_seeds.append(ab_s)
            except Exception:
                pass
            if sibling_seeds:
                sib_map = _expand_barcode_variants(sibling_seeds)
                sib_variants = []
                for vlist in sib_map.values():
                    for v in vlist:
                        if v not in sib_variants:
                            sib_variants.append(v)
                found_sib = _lookup_cards_by_barcodes(sib_variants, set(sibling_seeds))
                if found_sib and (found_sib.get("stok", 0) > 0 or len(sibling_seeds) == 1):
                    return found_sib

        # 3. İsim ile arama (Hem İlaç hem OTC tablolarında, stoğu/hareketi olan aktif kart öncelikli)
        search_text = clean_q.strip()
        if search_text and not (search_text.isdigit() and len(search_text) >= 7):
            tr_q = search_text.replace("i", "İ").replace("ı", "I").upper()
            p1 = _sql_lit(f"%{search_text}%")
            p2 = _sql_lit(f"%{tr_q}%")
            name_candidates = []

            _, rows = conn.query(f"""
                SELECT u.urun_id,
                       u.urun_adi,
                       (SELECT b.barkod FROM ilac.urun_barkod_ms b WHERE b.urun_id = u.urun_id AND b.barkod IS NOT NULL AND b.barkod <> '' ORDER BY COALESCE(b.aktif::text, '1') DESC, b.urun_barkod_id DESC LIMIT 1) as barkod,
                       COALESCE(f.psf, 0),
                       COALESCE(f.kdv, 10),
                       COALESCE((SELECT SUM(h.adet) FROM stok.stok_hareket_ms h WHERE h.urun_id = u.urun_id), 0) as stok,
                       COALESCE((SELECT COUNT(*) FROM stok.stok_hareket_ms h WHERE h.urun_id = u.urun_id), 0) as mov_cnt
                FROM ilac.urun_ms u
                LEFT JOIN LATERAL (
                    SELECT psf, kdv FROM ilac.urun_fiyat_ms uf
                    WHERE uf.urun_id = u.urun_id
                    ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                    LIMIT 1
                ) f ON true
                WHERE u.urun_adi ILIKE {p1} OR u.urun_adi ILIKE {p2}
                ORDER BY (CASE WHEN COALESCE((SELECT SUM(h.adet) FROM stok.stok_hareket_ms h WHERE h.urun_id = u.urun_id), 0) > 0 THEN 1 ELSE 0 END) DESC,
                         (SELECT COUNT(*) FROM stok.stok_hareket_ms h WHERE h.urun_id = u.urun_id) DESC,
                         u.urun_id DESC
                LIMIT 3
            """)
            for r in rows:
                if r[2]:
                    name_candidates.append({
                        "is_idu": False,
                        "id": int(r[0]),
                        "name": str(r[1] or "").strip(),
                        "barkod": str(r[2] or "").strip(),
                        "psf": float(r[3] or 0.0),
                        "kdv": float(r[4] or 10.0),
                        "stok": int(float(r[5] or 0)),
                        "mov_cnt": int(r[6] or 0),
                    })

            try:
                _, idu_rows = conn.query(f"""
                    SELECT i.idu_bilgi_id,
                           i.idu_tanim,
                           (SELECT b.barkod FROM public.idu_barkod_ms b WHERE b.idu_bilgi_id = i.idu_bilgi_id AND b.barkod IS NOT NULL AND b.barkod <> '' ORDER BY b.idu_barkod_id DESC LIMIT 1) as barkod,
                           COALESCE(f.eczane_satis_fiyat, 0),
                           COALESCE(f.idu_kdv, 10),
                           COALESCE((SELECT SUM(h.adet) FROM stok.stok_hareket_ms h WHERE h.idu_bilgi_id = i.idu_bilgi_id), 0) as stok,
                           COALESCE((SELECT COUNT(*) FROM stok.stok_hareket_ms h WHERE h.idu_bilgi_id = i.idu_bilgi_id), 0) as mov_cnt
                    FROM public.idu_bilgi_ms i
                    LEFT JOIN LATERAL (
                        SELECT eczane_satis_fiyat, idu_kdv FROM public.idu_fiyat_ms uf
                        WHERE uf.idu_bilgi_id = i.idu_bilgi_id
                        ORDER BY uf.idu_fiyat_id DESC
                        LIMIT 1
                    ) f ON true
                    WHERE i.idu_tanim ILIKE {p1} OR i.idu_tanim ILIKE {p2}
                    ORDER BY (CASE WHEN COALESCE((SELECT SUM(h.adet) FROM stok.stok_hareket_ms h WHERE h.idu_bilgi_id = i.idu_bilgi_id), 0) > 0 THEN 1 ELSE 0 END) DESC,
                             (SELECT COUNT(*) FROM stok.stok_hareket_ms h WHERE h.idu_bilgi_id = i.idu_bilgi_id) DESC,
                             i.idu_bilgi_id DESC
                    LIMIT 3
                """)
                for r in idu_rows:
                    if r[2]:
                        name_candidates.append({
                            "is_idu": True,
                            "id": int(r[0]),
                            "name": str(r[1] or "").strip(),
                            "barkod": str(r[2] or "").strip(),
                            "psf": float(r[3] or 0.0),
                            "kdv": float(r[4] or 10.0),
                            "stok": int(float(r[5] or 0)),
                            "mov_cnt": int(r[6] or 0),
                        })
            except Exception:
                pass

            if name_candidates:
                name_candidates.sort(
                    key=lambda c: (
                        1 if c["stok"] > 0 else 0,
                        1 if c["mov_cnt"] > 0 else 0,
                        c["stok"],
                        c["mov_cnt"],
                    ),
                    reverse=True,
                )
                best = name_candidates[0]
                if best["is_idu"]:
                    _, bc_rows = conn.query(f"SELECT barkod FROM public.idu_barkod_ms WHERE idu_bilgi_id = {best['id']} AND barkod IS NOT NULL AND barkod <> ''")
                else:
                    _, bc_rows = conn.query(f"SELECT barkod FROM ilac.urun_barkod_ms WHERE urun_id = {best['id']} AND barkod IS NOT NULL AND barkod <> ''")
                card_bcs = [x[0].strip() for x in bc_rows if x[0] and str(x[0]).strip()]
                expanded_card_bcs = set(card_bcs)
                for _, vlist in _expand_barcode_variants(card_bcs).items():
                    expanded_card_bcs.update(vlist)
                return {
                    "is_idu": best["is_idu"],
                    "id": best["id"],
                    "name": best["name"],
                    "barkod": best["barkod"],
                    "psf": best["psf"],
                    "kdv": best["kdv"],
                    "stok": best["stok"],
                    "all_barcodes": list(expanded_card_bcs) or [best["barkod"]],
                }

        return None

    def get_product_analysis(self, query: str, barcode: str = "") -> Dict[str, Any]:
        """
        Belirtilen barkod veya ürün adı için TEBEOS PostgreSQL veritabanından:
        1. Anlık raf stoğu (TEBEOS stok.barkod_ile_adet_getir_fnc ile birebir kart bazlı net toplam)
        2. Son 6 takvim ayı Nakit (Elden) ve Reçeteli (SGK/Medula) net çıkış adetleri (iptaller düşülmüş)
        3. Son depolardan gelen alış faturaları (GİRİŞ - public.fatura_hareket_ms)
        4. Aylık ortalama çıkış hızı, günlük çıkış, kalan gün tahmini ve akıllı sipariş önerisi
        döndürür.
        """
        clean_q = (barcode or query or "").strip()
        if not clean_q:
            return {"found": False, "message": "Barkod veya ürün belirtilmedi."}

        try:
            with self.get_connection() as conn:
                prod = self._find_product_in_tebeos(conn, query or clean_q, barcode=barcode or clean_q)
                if not prod:
                    return {
                        "found": False,
                        "connected": True,
                        "kaynak": "TEBEOS",
                        "message": f"'{clean_q}' TEBEOS kayıtlarında bulunamadı."
                    }

                u_id = int(prod["id"])
                u_adi = prod["name"]
                found_barkod = prod["barkod"]
                all_bcs = prod["all_barcodes"] or ([found_barkod] if found_barkod else [clean_q])
                in_bcs = _sql_in(all_bcs)

                # 1. Güncel Net Raf Stoğu: TEBEOS'un kendi ekranları gibi YALNIZCA kart ID (urun_id / idu_bilgi_id) üzerinden!
                # (Orphan urun_id IS NULL / idu_bilgi_id IS NULL satırlarını dahil etmez; TEBEOS arayüzüyle %100 aynı kutu sayısını verir)
                if prod["is_idu"]:
                    where_card = f"h.idu_bilgi_id = {u_id}"
                else:
                    where_card = f"h.urun_id = {u_id}"

                _, stok_rows = conn.query(f"SELECT COALESCE(SUM(h.adet), 0) FROM stok.stok_hareket_ms h WHERE {where_card}")
                stok = int(float(stok_rows[0][0] or 0)) if stok_rows else 0

                # 2. Son 6 Aylık Net Satış / Çıkış Trendi:
                # TEBEOS'un kendi ürün ekranıyla (raporlama.alis_satis_raporu_tarihe_bagli_yeni) %100 birebir!
                # s.satis_tarih baz alındığından emanet kapama veya ay başı Medula reçete/karekod düzeltmeleri ayları kaydırmaz.
                where_card_sh = f"sh.idu_bilgi_id = {u_id}" if prod["is_idu"] else f"sh.urun_id = {u_id}"
                rec_sm_expr = self._sql_satis_ms_expr(mode="recete")
                nak_sm_expr = self._sql_satis_ms_expr(mode="nakit")
                _, mov_rows = conn.query(f"""
                    SELECT TO_CHAR(s.satis_tarih, 'YYYY-MM') as ay,
                           {rec_sm_expr} as receteli_adet,
                           {nak_sm_expr} as nakit_adet
                    {self.SATIS_MS_FROM_SQL}
                    WHERE {self.SATIS_MS_ACTIVE_WHERE}
                      AND {where_card_sh}
                      AND s.satis_tarih >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '5 months')
                    GROUP BY TO_CHAR(s.satis_tarih, 'YYYY-MM')
                    ORDER BY ay ASC
                """)
                recete_map = {}
                elden_map = {}
                for mr in mov_rows:
                    ym = str(mr[0] or "")
                    recete_map[ym] = int(float(mr[1] or 0))
                    elden_map[ym] = int(float(mr[2] or 0))

                ay_isimleri = {
                    "01": "Ocak", "02": "Şubat", "03": "Mart", "04": "Nisan",
                    "05": "Mayıs", "06": "Haziran", "07": "Temmuz", "08": "Ağustos",
                    "09": "Eylül", "10": "Ekim", "11": "Kasım", "12": "Aralık"
                }

                today = datetime.date.today()
                aylik_cikislar = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    m_str = f"{m_calc:02d}"
                    ym_key = f"{y_calc}-{m_str}"
                    is_current_month = (i == 0)
                    suffix = " (Bu Ay)" if is_current_month else ""
                    ay_label = f"{ay_isimleri.get(m_str, m_str)} '{str(y_calc)[-2:]}{suffix}"

                    nakit_val = elden_map.get(ym_key, 0)
                    recete_val = recete_map.get(ym_key, 0)
                    top_cikis = nakit_val + recete_val

                    aylik_cikislar.append({
                        "ay": ym_key,
                        "label": ay_label,
                        "is_current": is_current_month,
                        "nakit": nakit_val,
                        "receteli": recete_val,
                        "toplam": top_cikis
                    })

                gecmis_aylar = aylik_cikislar[:-1] if len(aylik_cikislar) > 1 else aylik_cikislar
                gecmis_sum = sum(x["toplam"] for x in gecmis_aylar)
                if gecmis_sum > 0:
                    ort_aylik = round(gecmis_sum / max(1, len(gecmis_aylar)), 1)
                else:
                    ort_aylik = round(sum(x["toplam"] for x in aylik_cikislar) / max(1, len(aylik_cikislar)), 1)

                ort_gunluk = round(ort_aylik / 30.0, 2)
                if ort_gunluk > 0:
                    kalan_gun = int(round(max(0, stok) / ort_gunluk))
                else:
                    kalan_gun = 999 if stok > 0 else 0

                toplam_6_aylik_cikis = sum(x["toplam"] for x in aylik_cikislar)
                is_hareketsiz = (stok <= 0 and toplam_6_aylik_cikis == 0)

                if is_hareketsiz:
                    stok_status = "HAREKET YOK"
                    stok_status_color = "slate"
                    onerilen_siparis = 1
                elif stok <= 0:
                    stok_status = "TÜKENDİ"
                    stok_status_color = "red"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(1, hedef_stok - max(0, stok))
                elif kalan_gun < 10:
                    stok_status = "KRİTİK AZ"
                    stok_status_color = "amber"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                elif kalan_gun <= 30:
                    stok_status = "YETERLİ"
                    stok_status_color = "emerald"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                else:
                    stok_status = "YÜKSEK STOK"
                    stok_status_color = "sky"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)

                # 3. Son Alış Faturaları / Depo Girişleri (GİRİŞ)
                _, giris_rows = conn.query(f"""
                    SELECT TO_CHAR(fm.fatura_tarih, 'YYYY-MM-DD') as tarih,
                           COALESCE(d.depo, 'DİĞER DEPO') as depo,
                           COALESCE(fh.adet, 0) as adet,
                           COALESCE(fh.mf, 0) as mf,
                           COALESCE(NULLIF(fh.dsf, 0), NULLIF(fh.psf, 0), 0) as birim_fiyat,
                           COALESCE(NULLIF(fh.gecerli_maliyet, 0), NULLIF(fh.maliyet, 0), NULLIF(fh.dsf, 0), 0) as maliyet,
                           COALESCE(fm.fatura_no, '') as fatura_no
                    FROM public.fatura_hareket_ms fh
                    JOIN public.fatura_ms fm ON fm.fatura_id = fh.fatura_id
                    LEFT JOIN public.depo_ms d ON d.depo_id = fm.depo_id
                    WHERE fh.barkod IN {in_bcs}
                      AND COALESCE(fm.aktif::text, '1') != '0'
                    ORDER BY fm.fatura_tarih DESC NULLS LAST, fm.fatura_id DESC
                    LIMIT 6
                """)

                son_girisler = []
                toplam_giren_kutu = 0
                for gr in giris_rows:
                    g_adet = int(float(gr[2] or 0))
                    g_mf = int(float(gr[3] or 0))
                    g_birim = round(float(gr[4] or 0.0), 2)
                    g_maliyet = round(float(gr[5] or 0.0), 2)
                    top_satir = g_adet + g_mf
                    toplam_giren_kutu += top_satir
                    son_girisler.append({
                        "tarih": str(gr[0] or ""),
                        "depo": str(gr[1] or "DİĞER DEPO"),
                        "adet": g_adet,
                        "mf": g_mf,
                        "toplam_adet": top_satir,
                        "birim_fiyat": g_birim,
                        "maliyet": g_maliyet,
                        "fatura_no": str(gr[6] or "")
                    })

                final_barcode = barcode or found_barkod or clean_q
                try:
                    from backend.catalog import catalog
                    can_final = catalog.resolve_canonical_barcode(final_barcode)
                    if can_final:
                        final_barcode = can_final
                except Exception:
                    pass

                return {
                    "found": True,
                    "connected": True,
                    "kaynak": "TEBEOS",
                    "otomasyon_adi": "TEBEOS Eczane",
                    "urun_id": u_id,
                    "mal_id": u_id,
                    "mal_kodu": str(u_id),
                    "mal_adi": u_adi,
                    "barkod": final_barcode,
                    "stok": stok,
                    "stok_depo": 0,
                    "stok_raf": stok,
                    "stok_acik": 0,
                    "kalan_gun": kalan_gun,
                    "stok_status": stok_status,
                    "stok_status_color": stok_status_color,
                    "ort_aylik_cikis": ort_aylik,
                    "ort_gunluk_cikis": ort_gunluk,
                    "onerilen_siparis": onerilen_siparis,
                    "aylik_cikislar": aylik_cikislar,
                    "son_girisler": son_girisler,
                    "toplam_giren_kutu": toplam_giren_kutu,
                    "hareketsiz_kart": is_hareketsiz,
                    "hareketsiz_aciklama": "Eczanenizde bu ürün için son 6 aydır çıkış hareketi bulunmuyor."
                }
        except Exception as e:
            return {
                "found": False,
                "connected": False,
                "kaynak": "TEBEOS",
                "error": str(e),
                "message": f"TEBEOS stok ve hareket sorgusu hatası: {str(e)}"
            }

    def _card_key_sql(self, alias: str = "h") -> str:
        return (
            f"CASE "
            f"WHEN COALESCE({alias}.idu_bilgi_id, 0) > 0 THEN 'I:' || {alias}.idu_bilgi_id::text "
            f"WHEN COALESCE({alias}.urun_id, 0) > 0 THEN 'U:' || {alias}.urun_id::text "
            f"ELSE 'B:' || COALESCE({alias}.barkod, '') END"
        )

    def _fetch_cards_metadata_and_stats(
        self,
        conn: TebeosWireConnection,
        card_keys: List[str],
    ) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Tuple[int, int]], Dict[str, List[str]]]:
        """
        Verilen kart anahtarları ('U:<urun_id>', 'I:<idu_bilgi_id>', 'B:<barkod>') için:
        1. info_map: {ckey: {'urun_id': int, 'urun_adi': str, 'barkod': str, 'psf': float}}
        2. stat_map: {ckey: (toplam_stok, son_30_gun_net_satis)} — %100 TEBEOS kart bazlı stok!
        3. card_barcodes_map: {ckey: [barkod1, barkod2, ...]} (fatura/MF geçmişi eşleştirmesi için)
        döndürür.
        """
        u_ids: List[int] = []
        i_ids: List[int] = []
        b_codes: List[str] = []
        for ck in card_keys:
            if ck.startswith("U:"):
                u_ids.append(int(ck[2:]))
            elif ck.startswith("I:"):
                i_ids.append(int(ck[2:]))
            elif ck.startswith("B:") and ck[2:]:
                b_codes.append(ck[2:])

        info_map: Dict[str, Dict[str, Any]] = {}
        stat_map: Dict[str, Tuple[int, int]] = {}
        card_barcodes_map: Dict[str, List[str]] = {}
        sm_expr = self._sql_satis_ms_expr(mode="all")

        if u_ids:
            in_uids = "(" + ",".join(str(x) for x in u_ids) + ")"
            _, u_info = conn.query(f"""
                SELECT u.urun_id,
                       u.urun_adi,
                       (SELECT b.barkod FROM ilac.urun_barkod_ms b WHERE b.urun_id = u.urun_id AND b.barkod IS NOT NULL AND b.barkod <> '' ORDER BY COALESCE(b.aktif::text, '1') DESC, b.urun_barkod_id DESC LIMIT 1) as main_bc,
                       COALESCE(f.psf, 0) as psf
                FROM ilac.urun_ms u
                LEFT JOIN LATERAL (
                    SELECT psf FROM ilac.urun_fiyat_ms uf
                    WHERE uf.urun_id = u.urun_id
                    ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                    LIMIT 1
                ) f ON true
                WHERE u.urun_id IN {in_uids}
            """)
            for r in u_info:
                uid = int(r[0])
                ck = f"U:{uid}"
                mbc = str(r[2] or "").strip()
                info_map[ck] = {
                    "urun_id": uid,
                    "urun_adi": str(r[1] or mbc or uid).strip(),
                    "barkod": mbc,
                    "psf": round(float(r[3] or 0.0), 2),
                }

            _, u_bcs = conn.query(f"SELECT urun_id, barkod FROM ilac.urun_barkod_ms WHERE urun_id IN {in_uids} AND barkod IS NOT NULL AND barkod <> ''")
            for r in u_bcs:
                ck = f"U:{int(r[0])}"
                bs = str(r[1] or "").strip()
                if bs:
                    card_barcodes_map.setdefault(ck, []).append(bs)

            u_stok_map: Dict[int, int] = {}
            _, u_st = conn.query(f"""
                SELECT h.urun_id, COALESCE(SUM(h.adet), 0) as toplam_stok
                FROM stok.stok_hareket_ms h
                WHERE h.urun_id IN {in_uids}
                GROUP BY h.urun_id
            """)
            for r in u_st:
                u_stok_map[int(r[0])] = int(float(r[1] or 0))

            u_c30_map: Dict[int, int] = {}
            _, u_sl = conn.query(f"""
                SELECT sh.urun_id, {sm_expr} as ay_adet
                {self.SATIS_MS_FROM_SQL}
                WHERE {self.SATIS_MS_ACTIVE_WHERE}
                  AND s.satis_tarih >= (CURRENT_DATE - INTERVAL '30 days')
                  AND sh.urun_id IN {in_uids}
                GROUP BY sh.urun_id
            """)
            for r in u_sl:
                u_c30_map[int(r[0])] = int(float(r[1] or 0))

            for uid in u_ids:
                stat_map[f"U:{uid}"] = (u_stok_map.get(uid, 0), u_c30_map.get(uid, 0))

        if i_ids:
            in_iids = "(" + ",".join(str(x) for x in i_ids) + ")"
            try:
                _, i_info = conn.query(f"""
                    SELECT i.idu_bilgi_id,
                           i.idu_tanim,
                           (SELECT b.barkod FROM public.idu_barkod_ms b WHERE b.idu_bilgi_id = i.idu_bilgi_id AND b.barkod IS NOT NULL AND b.barkod <> '' ORDER BY b.idu_barkod_id DESC LIMIT 1) as main_bc,
                           COALESCE(f.eczane_satis_fiyat, 0) as psf
                    FROM public.idu_bilgi_ms i
                    LEFT JOIN LATERAL (
                        SELECT eczane_satis_fiyat FROM public.idu_fiyat_ms uf2
                        WHERE uf2.idu_bilgi_id = i.idu_bilgi_id
                        ORDER BY uf2.idu_fiyat_id DESC
                        LIMIT 1
                    ) f ON true
                    WHERE i.idu_bilgi_id IN {in_iids}
                """)
                for r in i_info:
                    iid = int(r[0])
                    ck = f"I:{iid}"
                    mbc = str(r[2] or "").strip()
                    info_map[ck] = {
                        "urun_id": iid,
                        "urun_adi": str(r[1] or mbc or iid).strip(),
                        "barkod": mbc,
                        "psf": round(float(r[3] or 0.0), 2),
                    }

                _, i_bcs = conn.query(f"SELECT idu_bilgi_id, barkod FROM public.idu_barkod_ms WHERE idu_bilgi_id IN {in_iids} AND barkod IS NOT NULL AND barkod <> ''")
                for r in i_bcs:
                    ck = f"I:{int(r[0])}"
                    bs = str(r[1] or "").strip()
                    if bs:
                        card_barcodes_map.setdefault(ck, []).append(bs)

                i_stok_map: Dict[int, int] = {}
                _, i_st = conn.query(f"""
                    SELECT h.idu_bilgi_id, COALESCE(SUM(h.adet), 0) as toplam_stok
                    FROM stok.stok_hareket_ms h
                    WHERE h.idu_bilgi_id IN {in_iids}
                    GROUP BY h.idu_bilgi_id
                """)
                for r in i_st:
                    i_stok_map[int(r[0])] = int(float(r[1] or 0))

                i_c30_map: Dict[int, int] = {}
                _, i_sl = conn.query(f"""
                    SELECT sh.idu_bilgi_id, {sm_expr} as ay_adet
                    {self.SATIS_MS_FROM_SQL}
                    WHERE {self.SATIS_MS_ACTIVE_WHERE}
                      AND s.satis_tarih >= (CURRENT_DATE - INTERVAL '30 days')
                      AND sh.idu_bilgi_id IN {in_iids}
                    GROUP BY sh.idu_bilgi_id
                """)
                for r in i_sl:
                    i_c30_map[int(r[0])] = int(float(r[1] or 0))

                for iid in i_ids:
                    stat_map[f"I:{iid}"] = (i_stok_map.get(iid, 0), i_c30_map.get(iid, 0))
            except Exception:
                pass

        if b_codes:
            in_bcs = _sql_in(b_codes)
            b_stok_map: Dict[str, int] = {}
            _, b_st = conn.query(f"""
                SELECT h.barkod, COALESCE(SUM(h.adet), 0) as toplam_stok
                FROM stok.stok_hareket_ms h
                WHERE COALESCE(h.urun_id, 0) <= 0
                  AND COALESCE(h.idu_bilgi_id, 0) <= 0
                  AND h.barkod IN {in_bcs}
                GROUP BY h.barkod
            """)
            for r in b_st:
                b_stok_map[str(r[0] or "").strip()] = int(float(r[1] or 0))

            b_c30_map: Dict[str, int] = {}
            _, b_sl = conn.query(f"""
                SELECT sh.barkod, {sm_expr} as ay_adet
                {self.SATIS_MS_FROM_SQL}
                WHERE {self.SATIS_MS_ACTIVE_WHERE}
                  AND s.satis_tarih >= (CURRENT_DATE - INTERVAL '30 days')
                  AND COALESCE(sh.urun_id, 0) <= 0
                  AND COALESCE(sh.idu_bilgi_id, 0) <= 0
                  AND sh.barkod IN {in_bcs}
                GROUP BY sh.barkod
            """)
            for r in b_sl:
                b_c30_map[str(r[0] or "").strip()] = int(float(r[1] or 0))

            for bc in b_codes:
                ck = f"B:{bc}"
                stat_map[ck] = (b_stok_map.get(bc, 0), b_c30_map.get(bc, 0))
                card_barcodes_map[ck] = [bc]
                info_map[ck] = {"urun_id": 0, "urun_adi": "", "barkod": bc, "psf": 0.0}

        return info_map, stat_map, card_barcodes_map

    def get_critical_stock_sales(self, limit: int = 0, max_stock_threshold: int = 5, max_stock_days: int = 21) -> List[Dict[str, Any]]:
        """
        Bugün TEBEOS üzerinden net çıkışı olan (reçeteli veya nakit, iptaller düşülmüş) ve stoğu azalan / kritik ürünleri
        %100 kart bazlı gerçek TEBEOS stoğuyla listeler.
        """
        try:
            with self.get_connection() as conn:
                ck_sql = self._card_key_sql("sh")
                net_expr = self._sql_satis_ms_expr(mode="all")

                # 1. Bugün net çıkışı olan kartları ve son okutulan barkodunu çek (TEBEOS aktif satis_ms üzerinden)
                _, today_rows = conn.query(f"""
                    SELECT {ck_sql} as ckey,
                           {net_expr} as bugun_adet,
                           MAX(NULLIF(TRIM(sh.barkod), '')) as sample_bc
                    {self.SATIS_MS_FROM_SQL}
                    WHERE {self.SATIS_MS_ACTIVE_WHERE}
                      AND s.satis_tarih >= CURRENT_DATE
                    GROUP BY {ck_sql}
                    HAVING {net_expr} > 0
                """)

                if not today_rows:
                    _, today_rows = conn.query(f"""
                        SELECT {ck_sql} as ckey,
                               {net_expr} as bugun_adet,
                               MAX(NULLIF(TRIM(sh.barkod), '')) as sample_bc
                        {self.SATIS_MS_FROM_SQL}
                        WHERE {self.SATIS_MS_ACTIVE_WHERE}
                          AND s.satis_tarih >= (
                            SELECT COALESCE(DATE_TRUNC('day', MAX(s2.satis_tarih)), CURRENT_DATE)
                            FROM satis.satis_ms s2
                            WHERE s2.satis_aktif = 1::bit AND s2.degistirme_tarihi IS NULL
                        )
                        GROUP BY {ck_sql}
                        HAVING {net_expr} > 0
                    """)

                if not today_rows:
                    return []

                today_map: Dict[str, int] = {}
                sample_bc_map: Dict[str, str] = {}
                for r in today_rows:
                    ck = str(r[0] or "").strip()
                    cnt = int(float(r[1] or 0))
                    sbc = str(r[2] or "").strip()
                    if ck and ck != "B:" and cnt > 0:
                        today_map[ck] = cnt
                        if sbc:
                            sample_bc_map[ck] = sbc

                card_keys = list(today_map.keys())
                if not card_keys:
                    return []

                # 2. Kart bazlı %100 doğru TEBEOS stoğu, son 30 gün net çıkışı, isim ve PSF
                info_map, stat_map, card_bcs_map = self._fetch_cards_metadata_and_stats(conn, card_keys)

                # 3. Geçmiş MF'li alım kontrolü (kartın tüm bağlı barkodları üzerinden)
                bc_to_ckeys: Dict[str, List[str]] = {}
                for ck in card_keys:
                    bcs_for_card = list(card_bcs_map.get(ck, []))
                    if sample_bc_map.get(ck) and sample_bc_map[ck] not in bcs_for_card:
                        bcs_for_card.append(sample_bc_map[ck])
                    for _, vlist in _expand_barcode_variants(bcs_for_card).items():
                        for v in vlist:
                            bc_to_ckeys.setdefault(v, []).append(ck)

                mf_history_by_ckey: Dict[str, Dict[str, Any]] = {}
                all_mf_bcs = list(bc_to_ckeys.keys())
                if all_mf_bcs:
                    try:
                        in_mf_bcs = _sql_in(all_mf_bcs[:1200])
                        _, mf_rows = conn.query(f"""
                            SELECT fh.barkod,
                                   COALESCE(fh.adet, 0) as adet,
                                   COALESCE(fh.mf, 0) as mf,
                                   TO_CHAR(fm.fatura_tarih, 'DD.MM.YYYY') as tarih,
                                   fm.fatura_tarih,
                                   fm.fatura_id
                            FROM public.fatura_hareket_ms fh
                            JOIN public.fatura_ms fm ON fm.fatura_id = fh.fatura_id
                            WHERE fh.barkod IN {in_mf_bcs}
                              AND COALESCE(fm.aktif::text, '1') != '0'
                              AND COALESCE(fh.mf, 0) > 0
                            ORDER BY fm.fatura_tarih DESC NULLS LAST, fm.fatura_id DESC
                        """)
                        raw_mf_per_ck: Dict[str, list] = {}
                        for mr in mf_rows:
                            mbc = str(mr[0] or "").strip()
                            for ck in bc_to_ckeys.get(mbc, []):
                                raw_mf_per_ck.setdefault(ck, []).append(mr)
                        for ck, mlist in raw_mf_per_ck.items():
                            top = mlist[0]
                            m_adet = int(float(top[1] or 0))
                            m_mf = int(float(top[2] or 0))
                            fmt_date = str(top[3] or "")
                            alim_count = len(mlist)
                            mf_kisa = f"Son: {m_adet}+{m_mf} MF" if m_adet > 0 else f"Son: +{m_mf} MF"
                            mf_bilgi = f"Geçmişte {alim_count} kez MF ile alındı (Son Alım: {m_adet}+{m_mf} MF, {fmt_date})"
                            mf_history_by_ckey[ck] = {
                                "var": True,
                                "sayisi": alim_count,
                                "son_adet": m_adet,
                                "son_mf": m_mf,
                                "son_tarih": fmt_date,
                                "kisa": mf_kisa,
                                "bilgi": mf_bilgi,
                            }
                    except Exception:
                        pass

                candidate_items = []
                for ck, bugun_val in today_map.items():
                    stok_val, ay_val = stat_map.get(ck, (0, bugun_val))
                    inf = info_map.get(ck, {})
                    u_id = inf.get("urun_id") or 0
                    u_adi = inf.get("urun_adi") or ""
                    psf_val = inf.get("psf") or 0.0
                    bc = inf.get("barkod") or sample_bc_map.get(ck) or ""
                    if not bc:
                        continue

                    if not u_adi:
                        try:
                            from backend.catalog import catalog
                            cat_item = catalog.get_by_barcode(bc)
                            if cat_item:
                                u_adi = cat_item.get("name") or bc
                                psf_val = psf_val or float(cat_item.get("price") or 0.0)
                        except Exception:
                            pass
                    if not u_adi:
                        u_adi = f"Ürün ({bc})"

                    effective_aylik = max(int(ay_val or 0), int(bugun_val or 1))
                    gunluk_ort = max(0.1, round(effective_aylik / 30.0, 2))
                    stok_gun = round((stok_val * 30.0) / effective_aylik, 1) if stok_val > 0 else 0.0

                    if max_stock_days > 0 and stok_val > 0 and stok_gun > max_stock_days:
                        continue

                    onerilen = max(bugun_val, int(gunluk_ort * 7) - max(0, stok_val))
                    if onerilen <= 0:
                        onerilen = max(1, bugun_val)

                    mf_hist = mf_history_by_ckey.get(ck, {})
                    has_past_mf = bool(mf_hist.get("var", False))

                    candidate_items.append({
                        "urun_id": u_id or bc,
                        "mal_kodu": str(u_id or bc),
                        "urun_adi": u_adi,
                        "barkod": bc,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": ay_val,
                        "psf": psf_val,
                        "onerilen_siparis": max(1, onerilen),
                        "gecmis_mf_var": has_past_mf,
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", "")
                    })

                candidate_items.sort(key=lambda x: (
                    0 if x["stok"] <= 0 else 1,
                    x["stok_gun"],
                    -x["bugun_cikis"]
                ))

                if limit and limit > 0:
                    return candidate_items[:limit]
                return candidate_items
        except Exception as e:
            print(f"[TEBEOS] get_critical_stock_sales hatası: {e}")
            return []

    def get_six_month_smart_order_list(
        self,
        scope: str = "today",
        search_query: str = "",
        target_days: int = 15,
        limit: int = 250
    ) -> Dict[str, Any]:
        """
        TEBEOS PostgreSQL veritabanından toplu sipariş ve 6 aylık çıkış analizi için
        son 6 takvim ayının ay-ay net çıkışlarını (hem İlaç hem OTC kartları dahil),
        trend analizini, %100 kart bazlı stok ve geçmiş MF bilgilerini döndürür.
        """
        import math
        t0 = time.time()
        try:
            with self.get_connection() as conn:
                ay_kisa = {
                    1: "Oca", 2: "Şub", 3: "Mar", 4: "Nis",
                    5: "May", 6: "Haz", 7: "Tem", 8: "Ağu",
                    9: "Eyl", 10: "Eki", 11: "Kas", 12: "Ara"
                }
                today = datetime.date.today()
                months_meta = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    ym_int = y_calc * 100 + m_calc
                    ym_str = f"{y_calc}-{m_calc:02d}"
                    short_lbl = ay_kisa.get(m_calc, str(m_calc))
                    lbl = f"{short_lbl} '{str(y_calc)[-2:]}"
                    months_meta.append({
                        "ym_int": ym_int,
                        "ym": ym_str,
                        "short": short_lbl,
                        "label": lbl,
                        "is_current": (i == 0)
                    })

                start_ym = months_meta[0]["ym_int"]
                start_date_str = f"{start_ym // 100}-{start_ym % 100:02d}-01"
                lim = max(10, int(limit or 250))

                ck_sql = self._card_key_sql("sh")
                net_all_expr = self._sql_satis_ms_expr(mode="all")
                net_rec_expr = self._sql_satis_ms_expr(mode="recete")
                net_nak_expr = self._sql_satis_ms_expr(mode="nakit")

                _, today_rows = conn.query(f"""
                    SELECT {ck_sql} as ckey,
                           {net_all_expr} as bugun_adet,
                           MAX(NULLIF(TRIM(sh.barkod), '')) as sample_bc
                    {self.SATIS_MS_FROM_SQL}
                    WHERE {self.SATIS_MS_ACTIVE_WHERE}
                      AND s.satis_tarih >= CURRENT_DATE
                    GROUP BY {ck_sql}
                    HAVING {net_all_expr} > 0
                """)
                today_map: Dict[str, int] = {}
                sample_bc_map: Dict[str, str] = {}
                for r in today_rows:
                    ck = str(r[0] or "").strip()
                    cnt = int(float(r[1] or 0))
                    sbc = str(r[2] or "").strip()
                    if ck and ck != "B:" and cnt > 0:
                        today_map[ck] = cnt
                        if sbc:
                            sample_bc_map[ck] = sbc

                clean_q = (search_query or "").strip()
                scope_norm = (scope or "today").strip().lower()
                card_keys: List[str] = []

                if clean_q:
                    p1 = _sql_quote(f"%{clean_q}%")
                    p2 = _sql_quote(f"%{clean_q.replace('i', 'İ').replace('ı', 'I').upper()}%")
                    bc_in_clause = ""
                    if clean_q.isdigit() and len(clean_q) >= 7:
                        v_list = _expand_barcode_variants([clean_q]).get(clean_q, [clean_q])
                        bc_in_clause = f" OR b.barkod IN {_sql_in(v_list)}"
                    _, s_rows = conn.query(f"""
                        SELECT DISTINCT 'U:' || u.urun_id::text as ckey, u.urun_id as sort_id
                        FROM ilac.urun_ms u
                        JOIN ilac.urun_barkod_ms b ON b.urun_id = u.urun_id
                        WHERE (u.urun_adi ILIKE {p1} OR u.urun_adi ILIKE {p2} OR b.barkod ILIKE {p1}{bc_in_clause})
                          AND b.barkod IS NOT NULL AND b.barkod <> '' AND u.urun_id > 0
                        LIMIT {lim}
                    """)
                    card_keys.extend(str(r[0]) for r in s_rows if r[0])
                    try:
                        _, si_rows = conn.query(f"""
                            SELECT DISTINCT 'I:' || i.idu_bilgi_id::text as ckey, i.idu_bilgi_id as sort_id
                            FROM public.idu_bilgi_ms i
                            JOIN public.idu_barkod_ms b ON b.idu_bilgi_id = i.idu_bilgi_id
                            WHERE (i.idu_tanim ILIKE {p1} OR i.idu_tanim ILIKE {p2} OR b.barkod ILIKE {p1}{bc_in_clause})
                              AND b.barkod IS NOT NULL AND b.barkod <> '' AND i.idu_bilgi_id > 0
                            LIMIT {lim}
                        """)
                        card_keys.extend(str(r[0]) for r in si_rows if r[0])
                    except Exception:
                        pass
                elif scope_norm in ("week", "days_7"):
                    _, w_rows = conn.query(f"""
                        SELECT {ck_sql} as ckey, {net_all_expr} as top_adet, MAX(NULLIF(TRIM(sh.barkod), ''))
                        {self.SATIS_MS_FROM_SQL}
                        WHERE {self.SATIS_MS_ACTIVE_WHERE}
                          AND s.satis_tarih >= (CURRENT_DATE - INTERVAL '7 days')
                        GROUP BY {ck_sql}
                        HAVING {net_all_expr} > 0
                        ORDER BY top_adet DESC
                        LIMIT {lim}
                    """)
                    for r in w_rows:
                        ck = str(r[0] or "").strip()
                        if ck and ck != "B:":
                            card_keys.append(ck)
                            if r[2]:
                                sample_bc_map.setdefault(ck, str(r[2]).strip())
                elif scope_norm in ("top6m", "top_6m"):
                    _, m6_rows = conn.query(f"""
                        SELECT {ck_sql} as ckey, {net_all_expr} as top_adet, MAX(NULLIF(TRIM(sh.barkod), ''))
                        {self.SATIS_MS_FROM_SQL}
                        WHERE {self.SATIS_MS_ACTIVE_WHERE}
                          AND s.satis_tarih >= {_sql_quote(start_date_str)}::date
                        GROUP BY {ck_sql}
                        HAVING {net_all_expr} > 0
                        ORDER BY top_adet DESC
                        LIMIT {lim}
                    """)
                    for r in m6_rows:
                        ck = str(r[0] or "").strip()
                        if ck and ck != "B:":
                            card_keys.append(ck)
                            if r[2]:
                                sample_bc_map.setdefault(ck, str(r[2]).strip())
                else:
                    card_keys = list(today_map.keys())
                    if not card_keys:
                        _, d3_rows = conn.query(f"""
                            SELECT {ck_sql} as ckey, {net_all_expr} as top_adet, MAX(NULLIF(TRIM(sh.barkod), ''))
                            {self.SATIS_MS_FROM_SQL}
                            WHERE {self.SATIS_MS_ACTIVE_WHERE}
                              AND s.satis_tarih >= (CURRENT_DATE - INTERVAL '3 days')
                            GROUP BY {ck_sql}
                            HAVING {net_all_expr} > 0
                            ORDER BY top_adet DESC
                            LIMIT {lim}
                        """)
                        for r in d3_rows:
                            ck = str(r[0] or "").strip()
                            if ck and ck != "B:":
                                card_keys.append(ck)
                                if r[2]:
                                    sample_bc_map.setdefault(ck, str(r[2]).strip())

                card_keys = [ck for ck in dict.fromkeys(card_keys) if ck and ck != "B:"][:lim]
                if not card_keys:
                    return {
                        "success": True,
                        "source": "TEBEOS",
                        "scope": scope,
                        "months": months_meta,
                        "items": [],
                        "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
                    }

                # Kart bazlı %100 doğru TEBEOS stoğu, son 30 gün net çıkışı, isim ve PSF
                info_map, stat_map, card_bcs_map = self._fetch_cards_metadata_and_stats(conn, card_keys)

                # Ay-Ay 6 aylık net çıkışlar: TEBEOS raporlama.alis_satis_raporu_tarihe_bagli_yeni ile %100 birebir!
                u_ids = [int(ck[2:]) for ck in card_keys if ck.startswith("U:")]
                i_ids = [int(ck[2:]) for ck in card_keys if ck.startswith("I:")]
                b_codes = [ck[2:] for ck in card_keys if ck.startswith("B:") and ck[2:]]

                per_item_months: Dict[str, Dict[int, Dict[str, int]]] = {}
                if u_ids:
                    in_uids = "(" + ",".join(str(x) for x in u_ids) + ")"
                    _, mu_rows = conn.query(f"""
                        SELECT sh.urun_id,
                               CAST(TO_CHAR(s.satis_tarih, 'YYYYMM') AS INTEGER) as ym,
                               {net_all_expr} as top_adet,
                               {net_rec_expr} as rec_adet,
                               {net_nak_expr} as nak_adet
                        {self.SATIS_MS_FROM_SQL}
                        WHERE {self.SATIS_MS_ACTIVE_WHERE}
                          AND sh.urun_id IN {in_uids}
                          AND s.satis_tarih >= {_sql_quote(start_date_str)}::date
                        GROUP BY sh.urun_id, CAST(TO_CHAR(s.satis_tarih, 'YYYYMM') AS INTEGER)
                    """)
                    for r_id, r_ym, r_top, r_rec, r_nak in mu_rows:
                        if r_id and r_ym:
                            per_item_months.setdefault(f"U:{int(r_id)}", {})[int(r_ym)] = {
                                "toplam": int(float(r_top or 0)),
                                "receteli": int(float(r_rec or 0)),
                                "nakit": int(float(r_nak or 0)),
                            }

                if i_ids:
                    in_iids = "(" + ",".join(str(x) for x in i_ids) + ")"
                    try:
                        _, mi_rows = conn.query(f"""
                            SELECT sh.idu_bilgi_id,
                                   CAST(TO_CHAR(s.satis_tarih, 'YYYYMM') AS INTEGER) as ym,
                                   {net_all_expr} as top_adet,
                                   {net_rec_expr} as rec_adet,
                                   {net_nak_expr} as nak_adet
                            {self.SATIS_MS_FROM_SQL}
                            WHERE {self.SATIS_MS_ACTIVE_WHERE}
                              AND sh.idu_bilgi_id IN {in_iids}
                              AND s.satis_tarih >= {_sql_quote(start_date_str)}::date
                            GROUP BY sh.idu_bilgi_id, CAST(TO_CHAR(s.satis_tarih, 'YYYYMM') AS INTEGER)
                        """)
                        for r_id, r_ym, r_top, r_rec, r_nak in mi_rows:
                            if r_id and r_ym:
                                per_item_months.setdefault(f"I:{int(r_id)}", {})[int(r_ym)] = {
                                    "toplam": int(float(r_top or 0)),
                                    "receteli": int(float(r_rec or 0)),
                                    "nakit": int(float(r_nak or 0)),
                                }
                    except Exception:
                        pass

                if b_codes:
                    in_bcs = _sql_in(b_codes)
                    _, mb_rows = conn.query(f"""
                        SELECT sh.barkod,
                               CAST(TO_CHAR(s.satis_tarih, 'YYYYMM') AS INTEGER) as ym,
                               {net_all_expr} as top_adet,
                               {net_rec_expr} as rec_adet,
                               {net_nak_expr} as nak_adet
                        {self.SATIS_MS_FROM_SQL}
                        WHERE {self.SATIS_MS_ACTIVE_WHERE}
                          AND COALESCE(sh.urun_id, 0) <= 0
                          AND COALESCE(sh.idu_bilgi_id, 0) <= 0
                          AND sh.barkod IN {in_bcs}
                          AND s.satis_tarih >= {_sql_quote(start_date_str)}::date
                        GROUP BY sh.barkod, CAST(TO_CHAR(s.satis_tarih, 'YYYYMM') AS INTEGER)
                    """)
                    for r_bc, r_ym, r_top, r_rec, r_nak in mb_rows:
                        if r_bc and r_ym:
                            per_item_months.setdefault(f"B:{str(r_bc).strip()}", {})[int(r_ym)] = {
                                "toplam": int(float(r_top or 0)),
                                "receteli": int(float(r_rec or 0)),
                                "nakit": int(float(r_nak or 0)),
                            }

                # Geçmiş MF'li alım kontrolü (public.fatura_hareket_ms — kartın tüm barkodlarıyla)
                bc_to_ckeys: Dict[str, List[str]] = {}
                for ck in card_keys:
                    bcs_for_card = list(card_bcs_map.get(ck, []))
                    if sample_bc_map.get(ck) and sample_bc_map[ck] not in bcs_for_card:
                        bcs_for_card.append(sample_bc_map[ck])
                    for _, vlist in _expand_barcode_variants(bcs_for_card).items():
                        for v in vlist:
                            bc_to_ckeys.setdefault(v, []).append(ck)

                mf_history_by_ckey: Dict[str, Dict[str, Any]] = {}
                all_mf_bcs = list(bc_to_ckeys.keys())
                if all_mf_bcs:
                    try:
                        in_mf_bcs = _sql_in(all_mf_bcs[:1500])
                        _, mf_rows = conn.query(f"""
                            SELECT fh.barkod,
                                   COALESCE(fh.adet, 0) as adet,
                                   COALESCE(fh.mf, 0) as mf,
                                   TO_CHAR(fm.fatura_tarih, 'DD.MM.YYYY') as tarih,
                                   COALESCE(d.depo, 'DİĞER DEPO') as depo,
                                   fm.fatura_tarih,
                                   fm.fatura_id
                            FROM public.fatura_hareket_ms fh
                            JOIN public.fatura_ms fm ON fm.fatura_id = fh.fatura_id
                            LEFT JOIN public.depo_ms d ON d.depo_id = fm.depo_id
                            WHERE fh.barkod IN {in_mf_bcs}
                              AND COALESCE(fm.aktif::text, '1') != '0'
                              AND COALESCE(fh.mf, 0) > 0
                            ORDER BY fm.fatura_tarih DESC NULLS LAST, fm.fatura_id DESC
                        """)
                        raw_mf_per_ck: Dict[str, list] = {}
                        for mr in mf_rows:
                            mbc = str(mr[0] or "").strip()
                            for ck in bc_to_ckeys.get(mbc, []):
                                raw_mf_per_ck.setdefault(ck, []).append(mr)
                        for ck, mlist in raw_mf_per_ck.items():
                            top = mlist[0]
                            m_adet = int(float(top[1] or 0))
                            m_mf = int(float(top[2] or 0))
                            fmt_date = str(top[3] or "")
                            m_depo = str(top[4] or "")
                            alim_count = len(mlist)
                            mf_kisa = f"Son: {m_adet}+{m_mf} MF" if m_adet > 0 else f"Son: +{m_mf} MF"
                            mf_bilgi = f"Geçmişte {alim_count} kez MF ile alındı (Son Alım: {m_adet}+{m_mf} MF, {fmt_date})"
                            mf_history_by_ckey[ck] = {
                                "var": True,
                                "sayisi": alim_count,
                                "son_adet": m_adet,
                                "son_mf": m_mf,
                                "son_tarih": fmt_date,
                                "son_depo": m_depo,
                                "kisa": mf_kisa,
                                "bilgi": mf_bilgi,
                            }
                    except Exception:
                        pass

                items = []
                stabil_count = 0
                azalan_count = 0
                artan_count = 0
                tukenen_count = 0
                target_days_clean = max(1, int(target_days or 15))

                for ck in card_keys:
                    inf = info_map.get(ck, {})
                    bc = inf.get("barkod") or sample_bc_map.get(ck) or ""
                    if not bc:
                        continue
                    u_id = inf.get("urun_id") or 0
                    u_adi = inf.get("urun_adi") or f"Ürün ({bc})"
                    psf_val = inf.get("psf") or 0.0
                    stok_val, son30_val = stat_map.get(ck, (0, 0))
                    bugun_val = today_map.get(ck, 0)

                    m_dict = per_item_months.get(ck, {})
                    aylik_detay = []
                    toplam_6ay = 0
                    toplam_6ay_recete = 0
                    toplam_6ay_nakit = 0
                    aktif_ay_sayisi = 0

                    for m_meta in months_meta:
                        ym_i = m_meta["ym_int"]
                        cell = m_dict.get(ym_i, {"toplam": 0, "receteli": 0, "nakit": 0})
                        c_top = cell["toplam"]
                        c_rec = cell["receteli"]
                        c_nak = cell["nakit"]
                        toplam_6ay += c_top
                        toplam_6ay_recete += c_rec
                        toplam_6ay_nakit += c_nak
                        if c_top > 0:
                            aktif_ay_sayisi += 1
                        aylik_detay.append({
                            "ym": m_meta["ym"],
                            "short": m_meta["short"],
                            "label": m_meta["label"],
                            "is_current": m_meta["is_current"],
                            "toplam": c_top,
                            "receteli": c_rec,
                            "recete": c_rec,
                            "nakit": c_nak
                        })

                    m_vals = [x["toplam"] for x in aylik_detay]
                    gecmis_5_toplam = sum(m_vals[:5])
                    ort_aylik_6m = round(gecmis_5_toplam / 5.0, 1) if gecmis_5_toplam > 0 else round(toplam_6ay / 6.0, 1)
                    onceki_4_ort = sum(m_vals[:4]) / 4.0
                    gecen_ay_val = m_vals[4] if len(m_vals) >= 5 else 0
                    son_donem_hiz = round((gecen_ay_val + son30_val) / 2.0, 1) if gecen_ay_val > 0 else float(son30_val)

                    degisim_yuzde = 0
                    if onceki_4_ort >= 1.5:
                        degisim_yuzde = int(round(((son_donem_hiz - onceki_4_ort) / onceki_4_ort) * 100))

                    if onceki_4_ort >= 2.0 and son_donem_hiz < onceki_4_ort * 0.65:
                        trend_kodu = "AZALAN"
                        trend_etiket = f"📉 Çıkışı Azalan (%{abs(degisim_yuzde)}↓)"
                        trend_renk = "amber"
                        trend_uyari = f"Son dönemde çıkış hızı {onceki_4_ort:.1f}/ay'dan {son_donem_hiz:.1f}/ay'a geriledi."
                        azalan_count += 1
                    elif onceki_4_ort >= 1.5 and son_donem_hiz > onceki_4_ort * 1.35 and son_donem_hiz >= 3.0:
                        trend_kodu = "ARTAN"
                        trend_etiket = f"📈 Çıkışı Artan (+%{abs(degisim_yuzde)}↑)"
                        trend_renk = "sky"
                        trend_uyari = f"Son dönemde talep hızlandı ({onceki_4_ort:.1f} → {son_donem_hiz:.1f}/ay)."
                        artan_count += 1
                    elif aktif_ay_sayisi >= 4 and toplam_6ay >= 5:
                        trend_kodu = "STABIL"
                        trend_etiket = f"🟢 Stabil Çıkan ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "emerald"
                        trend_uyari = f"Her ay düzenli satıyor (Ort. {ort_aylik_6m:.1f} kt/ay)."
                        stabil_count += 1
                    else:
                        trend_kodu = "DUZENSIZ"
                        trend_etiket = f"⚡ Aralıklı ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "slate"
                        trend_uyari = f"Son 6 ayın {aktif_ay_sayisi} ayında çıkış yaptı."

                    if stok_val <= 0:
                        tukenen_count += 1

                    if trend_kodu == "AZALAN":
                        etkin_aylik_hiz = max(0.5, min(ort_aylik_6m, max(1.0, son_donem_hiz)))
                    elif trend_kodu == "ARTAN":
                        etkin_aylik_hiz = max(ort_aylik_6m, son_donem_hiz, float(bugun_val))
                    else:
                        etkin_aylik_hiz = max(ort_aylik_6m, float(son30_val), float(bugun_val))

                    gunluk_hiz = round(max(0.05, etkin_aylik_hiz / 30.0), 2)
                    stok_gun = round(stok_val / gunluk_hiz, 1) if stok_val > 0 else 0.0
                    hedef_kutu = math.ceil(gunluk_hiz * target_days_clean)
                    onerilen = max(0, hedef_kutu - max(0, stok_val))
                    if stok_val <= 0 and onerilen <= 0:
                        onerilen = max(1, bugun_val or 1)

                    mf_hist = mf_history_by_ckey.get(ck, {})
                    has_past_mf = bool(mf_hist.get("var", False))

                    items.append({
                        "urun_id": u_id or bc,
                        "mal_kodu": str(u_id or bc),
                        "urun_kodu": str(u_id or bc),
                        "urun_adi": u_adi,
                        "barkod": bc,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "psf": psf_val,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": son30_val,
                        "toplam_6ay": toplam_6ay,
                        "toplam_6ay_recete": toplam_6ay_recete,
                        "toplam_6ay_nakit": toplam_6ay_nakit,
                        "ort_aylik_6m": ort_aylik_6m,
                        "onceki_4_ort": round(onceki_4_ort, 1),
                        "ilk4_ort": round(onceki_4_ort, 1),
                        "son_donem_hiz": round(son_donem_hiz, 1),
                        "son2_ort": round(son_donem_hiz, 1),
                        "gunluk_hiz": gunluk_hiz,
                        "aktif_ay_sayisi": aktif_ay_sayisi,
                        "aylik_detay": aylik_detay,
                        "trend_kodu": trend_kodu,
                        "trend_etiket": trend_etiket,
                        "trend_renk": trend_renk,
                        "trend_uyari": trend_uyari,
                        "degisim_yuzde": degisim_yuzde,
                        "onerilen_siparis": max(1, onerilen) if (stok_val <= 0 or bugun_val > 0 or onerilen > 0) else 0,
                        "ham_ihtiyac": max(0, hedef_kutu - max(0, stok_val)),
                        "oneri_metni": f"Aylık ~{ort_aylik_6m} kt ({target_days_clean}G hedef)",
                        "gecmis_mf_var": has_past_mf,
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_min_alim": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_bedelsiz": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_son_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", "")
                    })

                items.sort(key=lambda x: (
                    0 if (x["stok"] <= 0 and x["bugun_cikis"] > 0) else (1 if x["bugun_cikis"] > 0 else 2),
                    x["stok_gun"],
                    -x["toplam_6ay"]
                ))

                return {
                    "success": True,
                    "source": "TEBEOS",
                    "scope": scope,
                    "target_days": target_days_clean,
                    "elapsed_ms": round((time.time() - t0) * 1000, 1),
                    "months": months_meta,
                    "items": items,
                    "stats": {
                        "total_items": len(items),
                        "stabil_count": stabil_count,
                        "azalan_count": azalan_count,
                        "artan_count": artan_count,
                        "tukenen_count": tukenen_count
                    }
                }
        except Exception as e:
            print(f"[TEBEOS] get_six_month_smart_order_list hatası: {e}")
            return {
                "success": False,
                "source": "TEBEOS",
                "scope": scope,
                "error": str(e),
                "months": [],
                "items": [],
                "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
            }

    def get_product_vat(self, barcode_or_code: str) -> Optional[float]:
        """Ürünün TEBEOS veritabanındaki resmi KDV oranını döner."""
        q = str(barcode_or_code or "").strip()
        if not q:
            return None
        try:
            with self.get_connection() as conn:
                prod = self._find_product_in_tebeos(conn, q, barcode=q)
                if prod and prod.get("kdv") is not None and float(prod["kdv"]) > 0:
                    return float(prod["kdv"])
        except Exception as e:
            print(f"[TEBEOS] get_product_vat hatası: {e}")
        return None

    def get_product_equivalents(self, barcode_or_code: str) -> Dict[str, Any]:
        """TEBEOS veritabanındaki SGK eşdeğer ilaçları (ilac.urun_sgk_esdeger_ms) stok ve kârlılık verileriyle listeler."""
        q = str(barcode_or_code or "").strip()
        if not q:
            return {"found": False, "esdeger_kodu": None, "muadiller": []}

        try:
            with self.get_connection() as conn:
                prod = self._find_product_in_tebeos(conn, q, barcode=q)
                if not prod or prod.get("is_idu"):
                    return {"found": False, "esdeger_kodu": None, "muadiller": []}

                u_id = int(prod["id"])
                _, eq_rows = conn.query(f"""
                    SELECT urun_esdeger_kod
                    FROM ilac.urun_sgk_esdeger_ms
                    WHERE urun_id = {u_id}
                      AND urun_esdeger_kod IS NOT NULL AND urun_esdeger_kod <> ''
                    ORDER BY son_islem DESC NULLS LAST
                    LIMIT 1
                """)
                if not eq_rows or not eq_rows[0][0]:
                    return {"found": False, "esdeger_kodu": None, "muadiller": []}

                esdeger_kod = str(eq_rows[0][0]).strip()
                lit_eq = _sql_lit(esdeger_kod)

                _, all_rows = conn.query(f"""
                    SELECT u.urun_id,
                           u.urun_adi,
                           (SELECT b.barkod FROM ilac.urun_barkod_ms b WHERE b.urun_id = u.urun_id AND b.barkod IS NOT NULL AND b.barkod <> '' ORDER BY COALESCE(b.aktif::text, '1') DESC, b.urun_barkod_id DESC LIMIT 1) as barkod,
                           COALESCE(f.psf, 0) as psf,
                           COALESCE(f.dsf, 0) as dsf,
                           COALESCE(f.esf, 0) as esf,
                           COALESCE(f.isf, 0) as isf,
                           COALESCE(f.kdv, 10) as kdv,
                           COALESCE(st.stok, 0) as stok,
                           COALESCE(sl.cikis30, 0) as cikis30
                    FROM ilac.urun_sgk_esdeger_ms ue
                    JOIN ilac.urun_ms u ON u.urun_id = ue.urun_id
                    LEFT JOIN LATERAL (
                        SELECT psf, dsf, esf, isf, kdv FROM ilac.urun_fiyat_ms uf
                        WHERE uf.urun_id = u.urun_id
                        ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                        LIMIT 1
                    ) f ON true
                    LEFT JOIN LATERAL (
                        SELECT COALESCE(SUM(h.adet), 0) as stok
                        FROM stok.stok_hareket_ms h
                        WHERE h.urun_id = u.urun_id
                    ) st ON true
                    LEFT JOIN LATERAL (
                        SELECT {self._sql_satis_ms_expr(mode="all")} as cikis30
                        {self.SATIS_MS_FROM_SQL}
                        WHERE {self.SATIS_MS_ACTIVE_WHERE}
                          AND sh.urun_id = u.urun_id
                          AND s.satis_tarih >= (CURRENT_DATE - INTERVAL '30 days')
                    ) sl ON true
                    WHERE ue.urun_esdeger_kod = {lit_eq}
                    ORDER BY st.stok DESC NULLS LAST, u.urun_id DESC
                """)

                items = []
                current_kamu_kari = 0.0
                for row in all_rows:
                    r_uid = int(row[0] or 0)
                    r_name = str(row[1] or "").strip()
                    r_bc = str(row[2] or r_uid).strip()
                    psf = round(float(row[3] or 0.0), 2)
                    dsf = round(float(row[4] or 0.0), 2)
                    esf = round(float(row[5] or 0.0), 2)
                    isf = round(float(row[6] or 0.0), 2)
                    kdv_oran = float(row[7] or 10.0)
                    stok = int(float(row[8] or 0))
                    cikis_30 = int(float(row[9] or 0))

                    # KSF (Kamu Satış Fiyatı) ve Maliyet hesabı
                    ksf = psf
                    kamu_isk = 0.0
                    try:
                        from backend.catalog import catalog
                        cat_p = catalog.get_by_barcode(r_bc)
                        if cat_p and float(cat_p.get("institution_discount") or 0.0) > 0:
                            kamu_isk = float(cat_p["institution_discount"])
                            ksf = round(psf * (1.0 - (kamu_isk / 100.0)), 2)
                    except Exception:
                        pass

                    net_maliyet_kdvsiz = dsf if dsf > 0 else round((psf / (1.0 + kdv_oran / 100.0)) * 0.71, 2)
                    net_maliyet_kdvli = round(net_maliyet_kdvsiz * (1.0 + kdv_oran / 100.0), 2)

                    kamu_kari = round(max(0.0, ksf - net_maliyet_kdvli), 2) if ksf > 0 else 0.0
                    perakende_kari = round(max(0.0, psf - net_maliyet_kdvli), 2) if psf > 0 else 0.0

                    is_curr = (r_uid == u_id)
                    if is_curr:
                        current_kamu_kari = kamu_kari

                    items.append({
                        "kod": str(r_uid),
                        "mal_kodu": str(r_uid),
                        "ad": r_name,
                        "urun_adi": r_name,
                        "barkod": r_bc,
                        "psf": psf,
                        "ksf": ksf,
                        "kamu_iskontosu": kamu_isk,
                        "net_birim_maliyet": net_maliyet_kdvsiz,
                        "net_birim_maliyet_kdvli": net_maliyet_kdvli,
                        "kamu_kari": kamu_kari,
                        "perakende_kari": perakende_kari,
                        "stok": stok,
                        "cikis_30gun": cikis_30,
                        "gecmis_mf_var": False,
                        "gecmis_mf_bilgi": "",
                        "is_current": is_curr
                    })

                for it in items:
                    kf = round(it["kamu_kari"] - current_kamu_kari, 2)
                    it["kar_farki"] = kf
                    it["is_more_profitable"] = (kf > 0)
                    it["kar_artis_yuzdesi"] = round((kf / current_kamu_kari * 100.0), 1) if (current_kamu_kari > 0 and kf > 0) else 0.0

                items.sort(key=lambda x: (x.get("kamu_kari") or 0.0, x.get("stok") or 0), reverse=True)

                en_karli = None
                muadil_kar_avantaji = 0.0
                for it in items:
                    if it.get("kar_farki", 0.0) > 0 and not it.get("is_current"):
                        it["is_best_deal"] = True
                        en_karli = it
                        muadil_kar_avantaji = it["kar_farki"]
                        break

                return {
                    "found": True,
                    "esdeger_kodu": esdeger_kod,
                    "count": len(items),
                    "en_karli_muadil": en_karli,
                    "muadil_kar_avantaji": muadil_kar_avantaji,
                    "current_kamu_kari": current_kamu_kari,
                    "muadiller": items
                }
        except Exception as e:
            print(f"[TEBEOS] get_product_equivalents hatası: {e}")
            return {"found": False, "error": str(e), "esdeger_kodu": None, "muadiller": []}

    def get_bulk_stock_and_sales_map(self, barcodes: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Verilen barkod listesi için TEBEOS PostgreSQL veritabanından tek seferde (toplu/bulk)
        anlık eczane stoğu, son 1 aylık (30 gün) net çıkış ve son 3 aylık (90 gün) net çıkış
        sayılarını döndürür.

        Kritik İlkeler:
        - Barkod format farklarını (8/11/12/13/14 hane, başındaki '0' farkları) otomatik çözer.
        - TEBEOS'ta zaten kayıtlı olan barkodları katalogdaki başka kartlarla (setli/setsiz, muadil vb.) ASLA karıştırmaz.
        - Katalogdaki kardeş barkodlara yalnızca aranan barkod TEBEOS'ta HİÇ bulunamadığında (yeni depo barkodu) yedek olarak bakar.
        - Stoğu TEBEOS'un kendi stok.barkod_ile_adet_getir_fnc fonksiyonuyla %100 aynı kart ID bazında hesaplar.
        """
        result: Dict[str, Dict[str, Any]] = {}
        clean_inputs = list(dict.fromkeys(str(b or "").strip() for b in (barcodes or []) if str(b or "").strip()))
        if not clean_inputs:
            return result

        for orig_bc in clean_inputs:
            result[orig_bc] = {"stok": 0, "cikis_1ay": 0, "cikis_3ay": 0, "found": False}

        # Aşama 1: Yalnızca başındaki 0 / hane sayısı format varyasyonları (katalog kirliliği olmadan!)
        direct_var_map = _expand_barcode_variants(clean_inputs)
        variant_to_orig_info: Dict[str, List[Tuple[str, int]]] = {}  # variant -> [(orig_bc, match_tier: 2=exact, 1=format_var, 0=catalog_sib)]
        for orig_bc, vlist in direct_var_map.items():
            for v in vlist:
                tier = 2 if v == orig_bc else 1
                variant_to_orig_info.setdefault(v, []).append((orig_bc, tier))

        try:
            with self.get_connection() as conn:
                chunk_size = 400
                # orig_bc -> List[(tier, is_idu, card_id)]
                orig_candidates: Dict[str, List[Tuple[int, bool, int]]] = {}

                def _query_barcode_mapping(var_dict: Dict[str, List[Tuple[str, int]]]):
                    v_keys = list(var_dict.keys())
                    for idx in range(0, len(v_keys), chunk_size):
                        chunk = v_keys[idx:idx + chunk_size]
                        in_bcs = _sql_in(chunk)

                        _, u_rows = conn.query(f"""
                            SELECT b.barkod, b.urun_id
                            FROM ilac.urun_barkod_ms b
                            WHERE b.barkod IN {in_bcs}
                              AND b.urun_id > 0
                        """)
                        for r in u_rows:
                            b_str = str(r[0] or "").strip()
                            u_id = int(r[1] or 0)
                            if u_id > 0 and b_str in var_dict:
                                for obc, tier in var_dict[b_str]:
                                    orig_candidates.setdefault(obc, []).append((tier, False, u_id))

                        try:
                            _, idu_rows = conn.query(f"""
                                SELECT b.barkod, b.idu_bilgi_id
                                FROM public.idu_barkod_ms b
                                WHERE b.barkod IN {in_bcs}
                                  AND b.idu_bilgi_id > 0
                            """)
                            for r in idu_rows:
                                b_str = str(r[0] or "").strip()
                                i_id = int(r[1] or 0)
                                if i_id > 0 and b_str in var_dict:
                                    for obc, tier in var_dict[b_str]:
                                        orig_candidates.setdefault(obc, []).append((tier, True, i_id))
                        except Exception:
                            pass

                _query_barcode_mapping(variant_to_orig_info)

                # Aşama 1b: TEBEOS'ta doğrudan veya format varyasyonuyla HİÇ bulunamayan barkodlar için katalog yedeklemesi
                unmatched_origs = [obc for obc in clean_inputs if obc not in orig_candidates]
                if unmatched_origs:
                    sib_var_to_orig: Dict[str, List[Tuple[str, int]]] = {}
                    try:
                        from backend.catalog import catalog
                        for obc in unmatched_origs:
                            c_item = catalog.get_by_barcode(obc)
                            if not c_item:
                                continue
                            sib_seeds = []
                            if c_item.get("barcode"):
                                sib_seeds.append(str(c_item["barcode"]).strip())
                            for ab in (c_item.get("all_barcodes") or []):
                                if str(ab).strip():
                                    sib_seeds.append(str(ab).strip())
                            already = set(direct_var_map.get(obc, []))
                            for _, sv_list in _expand_barcode_variants(sib_seeds).items():
                                for sv in sv_list:
                                    if sv and sv not in already:
                                        sib_var_to_orig.setdefault(sv, []).append((obc, 0))
                    except Exception:
                        pass
                    if sib_var_to_orig:
                        _query_barcode_mapping(sib_var_to_orig)

                all_uids = sorted({cid for cands in orig_candidates.values() for (_, is_idu, cid) in cands if not is_idu})
                all_idus = sorted({cid for cands in orig_candidates.values() for (_, is_idu, cid) in cands if is_idu})

                c30_sm_expr = self._sql_satis_ms_expr("s.satis_tarih >= (CURRENT_DATE - INTERVAL '30 days')", mode="all")
                c90_sm_expr = self._sql_satis_ms_expr(mode="all")

                uid_metrics: Dict[int, Tuple[int, int, int, int]] = {}
                for idx in range(0, len(all_uids), chunk_size):
                    u_chunk = all_uids[idx:idx + chunk_size]
                    in_uids = "(" + ",".join(str(x) for x in u_chunk) + ")"
                    u_st_map: Dict[int, Tuple[int, int]] = {}
                    _, s_rows = conn.query(f"""
                        SELECT h.urun_id,
                               COALESCE(SUM(h.adet), 0) AS stok,
                               COUNT(*) AS mov_cnt
                        FROM stok.stok_hareket_ms h
                        WHERE h.urun_id IN {in_uids}
                        GROUP BY h.urun_id
                    """)
                    for r in s_rows:
                        u_st_map[int(r[0] or 0)] = (int(float(r[1] or 0)), int(r[2] or 0))

                    u_sl_map: Dict[int, Tuple[int, int]] = {}
                    _, sl_rows = conn.query(f"""
                        SELECT sh.urun_id,
                               {c30_sm_expr} AS c30,
                               {c90_sm_expr} AS c90
                        {self.SATIS_MS_FROM_SQL}
                        WHERE {self.SATIS_MS_ACTIVE_WHERE}
                          AND s.satis_tarih >= (CURRENT_DATE - INTERVAL '90 days')
                          AND sh.urun_id IN {in_uids}
                        GROUP BY sh.urun_id
                    """)
                    for r in sl_rows:
                        u_sl_map[int(r[0] or 0)] = (int(float(r[1] or 0)), int(float(r[2] or 0)))

                    for uid in u_chunk:
                        st_v, mc_v = u_st_map.get(uid, (0, 0))
                        c30_v, c90_v = u_sl_map.get(uid, (0, 0))
                        uid_metrics[uid] = (st_v, c30_v, c90_v, mc_v)

                idu_metrics: Dict[int, Tuple[int, int, int, int]] = {}
                for idx in range(0, len(all_idus), chunk_size):
                    i_chunk = all_idus[idx:idx + chunk_size]
                    in_idus = "(" + ",".join(str(x) for x in i_chunk) + ")"
                    i_st_map: Dict[int, Tuple[int, int]] = {}
                    _, s_rows = conn.query(f"""
                        SELECT h.idu_bilgi_id,
                               COALESCE(SUM(h.adet), 0) AS stok,
                               COUNT(*) AS mov_cnt
                        FROM stok.stok_hareket_ms h
                        WHERE h.idu_bilgi_id IN {in_idus}
                        GROUP BY h.idu_bilgi_id
                    """)
                    for r in s_rows:
                        i_st_map[int(r[0] or 0)] = (int(float(r[1] or 0)), int(r[2] or 0))

                    i_sl_map: Dict[int, Tuple[int, int]] = {}
                    _, sl_rows = conn.query(f"""
                        SELECT sh.idu_bilgi_id,
                               {c30_sm_expr} AS c30,
                               {c90_sm_expr} AS c90
                        {self.SATIS_MS_FROM_SQL}
                        WHERE {self.SATIS_MS_ACTIVE_WHERE}
                          AND s.satis_tarih >= (CURRENT_DATE - INTERVAL '90 days')
                          AND sh.idu_bilgi_id IN {in_idus}
                        GROUP BY sh.idu_bilgi_id
                    """)
                    for r in sl_rows:
                        i_sl_map[int(r[0] or 0)] = (int(float(r[1] or 0)), int(float(r[2] or 0)))

                    for iid in i_chunk:
                        st_v, mc_v = i_st_map.get(iid, (0, 0))
                        c30_v, c90_v = i_sl_map.get(iid, (0, 0))
                        idu_metrics[iid] = (st_v, c30_v, c90_v, mc_v)

                for obc, cands in orig_candidates.items():
                    if not cands:
                        continue
                    # Aynı kart birden fazla varyasyonla eşleştiyse en yüksek tier'ı koru
                    dedup_map: Dict[Tuple[bool, int], int] = {}
                    for tier, is_idu, cid in cands:
                        key = (is_idu, cid)
                        if tier > dedup_map.get(key, -1):
                            dedup_map[key] = tier

                    scored = []
                    for (is_idu, cid), tier in dedup_map.items():
                        st, c30, c90, mcnt = idu_metrics.get(cid, (0, 0, 0, 0)) if is_idu else uid_metrics.get(cid, (0, 0, 0, 0))
                        # Katalog kardeş yedeğinden (tier=0) eksi stoklu alakasız kart gelirse yoksay
                        if tier == 0 and st < 0 and len(dedup_map) > 1:
                            continue
                        scored.append((tier, is_idu, cid, st, c30, c90, mcnt))

                    if not scored:
                        continue

                    # Tam barkod eşleşmesi (tier=2) varsa ve kart hareket görmüşse (veya pozitif stoklu alternatif yoksa) tam eşleşmeyi seç.
                    # TEBEOS stok.barkod_ile_adet_getir_fnc uyumu: aynı barkod hem ilac hem idu'da varsa ilac önceliklidir (ilac stoğu 0 iken idu > 0 değilse).
                    scored.sort(
                        key=lambda x: (
                            1 if x[0] >= 1 else 0,                                  # Doğrudan / sıfır-format eşleşmesi katalog yedeğinden üstündür
                            1 if (x[0] == 2 and (x[3] != 0 or x[6] > 0)) else 0,    # Tam barkod + aktif kart en üstündür
                            1 if x[3] > 0 else (0 if x[3] == 0 else -1),            # Pozitif stoklu kart, 0 veya eksi stoklu karttan üstündür
                            x[0],                                                   # Tam barkod (2) > Sıfır-format varyasyonu (1) > Katalog (0)
                            0 if not x[1] else -1,                                  # ilac (False) > idu (True) (barkod_ile_adet_getir_fnc uyumu)
                            1 if x[6] > 0 else 0,                                   # Hareket görmüş kart
                            x[3],                                                   # Stok miktarı
                            x[2],                                                   # Kart ID
                        ),
                        reverse=True,
                    )
                    best_tier, _, _, best_st, best_c30, best_c90, _ = scored[0]
                    if best_tier == 0 and best_st < 0:
                        best_st = 0

                    result[obc] = {
                        "stok": int(best_st),
                        "cikis_1ay": int(best_c30),
                        "cikis_3ay": int(best_c90),
                        "found": True,
                    }

        except Exception as e:
            print(f"[TEBEOS] get_bulk_stock_and_sales_map hatası: {e}")

        return result

    def get_pharmacy_info_by_gln(self, gln_no: str = "") -> Dict[str, Any]:
        """
        TEBEOS PostgreSQL veritabanındaki `isletme_tanim_lp`, `eczane_ms` ve `depo_ms`
        tablolarından eczanenin kendi GLN, Eczane Adı, Eczacı Adı, Telefon, İl/İlçe
        ve Ecza Deposu şifrelerini (veya verilen GLN'ye ait eczane kaydını) okur.
        """
        clean_gln = "".join(ch for ch in str(gln_no or "") if ch.isdigit())
        out: Dict[str, Any] = {"found": False}
        try:
            with self.get_connection(timeout=3.5) as conn:
                # 1. Önce isletme_tanim_lp (Bu TEBEOS veritabanının kendi eczane kimliği)
                _, rows = conn.query(
                    "SELECT tanim, deger FROM isletme_tanim_lp WHERE deger IS NOT NULL AND deger != ''"
                )
                kv = {str(r[0] or "").strip(): str(r[1] or "").strip() for r in rows}
                own_gln = "".join(ch for ch in (kv.get("GLN No") or kv.get("ITS Kullanici Adi", "")[:13]) if ch.isdigit())[:13]
                own_name = (kv.get("Eczane_Adi") or kv.get("EczaneAdi") or "").strip().upper()
                if own_name and "ECZANE" not in own_name:
                    own_name = f"{own_name} ECZANESİ"
                fn_first = (kv.get("Eczaci_Adi") or "").strip()
                fn_last = (kv.get("Eczaci_Soyadi") or "").strip()
                own_pharmacist = (kv.get("Eczaci_Adi_Soyadi") or kv.get("Tebrp Kullanici Adi") or f"{fn_first} {fn_last}").strip().upper()
                own_phone = (kv.get("GSM") or kv.get("_Telefon") or "").strip()
                sehir_kod = (kv.get("Sehir") or "").strip()
                city_map = {"55": "SAMSUN", "34": "İSTANBUL", "06": "ANKARA", "35": "İZMİR", "16": "BURSA", "07": "ANTALYA", "57": "SİNOP", "52": "ORDU", "28": "GİRESUN", "61": "TRABZON", "05": "AMASYA", "19": "ÇORUM", "60": "TOKAT"}
                own_city = city_map.get(sehir_kod, (kv.get("Ilce") or sehir_kod).upper())

                if not clean_gln or (own_gln and clean_gln == own_gln):
                    if own_gln and own_name:
                        out = {
                            "found": True,
                            "gln_no": own_gln,
                            "pharmacy_name": own_name,
                            "pharmacist_name": own_pharmacist,
                            "phone": own_phone,
                            "city": own_city,
                            "otomasyon": "TEBEOS",
                            "source": "tebeos_isletme_tanim",
                        }

                # 2. Eğer belirli bir GLN arandıysa ve isletme_tanim_lp ile eşleşmediyse eczane_ms tablosuna bak
                if not out.get("found") and len(clean_gln) >= 8:
                    _, erows = conn.query(
                        f"SELECT eczane_ad, eczane_gln, eczane_yetkili_ad_soyad, eczane_gsm, eczane_telefon, eczane_il, eczane_ilce "
                        f"FROM eczane_ms WHERE eczane_gln = {_sql_lit(clean_gln)} LIMIT 1"
                    )
                    if erows:
                        er = erows[0]
                        ename = str(er[0] or "").strip().upper()
                        if ename and "ECZANE" not in ename:
                            ename = f"{ename} ECZANESİ"
                        eil = str(er[5] or "").strip().upper()
                        eilce = str(er[6] or "").strip().upper()
                        ecity = f"{eil} / {eilce}".strip(" /")
                        out = {
                            "found": True,
                            "gln_no": str(er[1] or clean_gln).strip(),
                            "pharmacy_name": ename,
                            "pharmacist_name": str(er[2] or "").strip().upper(),
                            "phone": str(er[3] or er[4] or "").strip(),
                            "city": ecity,
                            "otomasyon": "TEBEOS",
                            "source": "tebeos_eczane_ms",
                        }
        except Exception:
            pass
        return out


# Singleton instance
tebeos_client = TebeosPGClient()
