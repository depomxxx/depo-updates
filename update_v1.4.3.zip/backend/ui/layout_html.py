# -*- coding: utf-8 -*-
LAYOUT_HTML = """<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farma Radar — Eczane Depo Şart & Net Maliyet Karşılaştırma</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .depo-alliance { border-left-color: #0284c7; }
        .depo-selcuk { border-left-color: #16a34a; }
        .depo-nevzat { border-left-color: #ea580c; }
        .depo-iskoop { border-left-color: #dc2626; }
        .depo-bek { border-left-color: #0d9488; }
        .depo-ecza1 { border-left-color: #9333ea; }
        .depo-farmazon { border-left-color: #ea580c; }
        .depo-dna { border-left-color: #06b6d4; }
        .depo-eczatrend { border-left-color: #f97316; }
        .depo-eczanetakas { border-left-color: #0284c7; }
        .badge-pulse { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: .5; } }
    </style>
    <script>
        (function() {
            var _initVer = null;
            setInterval(function() {
                fetch('/api/version?t=' + Date.now()).then(function(r) { return r.json(); }).then(function(d) {
                    if (d && d.version) {
                        if (!_initVer) _initVer = d.version;
                        else if (d.version !== _initVer) window.location.reload();
                    }
                }).catch(function() {});
            }, 15000);
        })();
    </script>
</head>
<body class="min-h-screen text-slate-800">
    <!-- Toast Notifications Container -->
    <div id="toastContainer" class="fixed top-5 right-5 z-[9999] flex flex-col space-y-2 pointer-events-none"></div>

    <!-- Header (Kompakt Tek Satır - Kaydırma Çubuğu Yok) -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-2xs">
        <div class="max-w-7xl mx-auto px-3 sm:px-5 py-2 flex items-center justify-between gap-2 flex-nowrap">
            <div class="flex items-center space-x-2.5 min-w-0 shrink-0">
                <div class="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-xs shrink-0">
                    <i class="fa-solid fa-satellite-dish text-sm"></i>
                </div>
                <div class="min-w-0">
                    <h1 class="text-sm sm:text-base font-extrabold text-slate-900 leading-tight whitespace-nowrap">Farma Radar</h1>
                    <p class="text-[10px] text-slate-500 font-medium whitespace-nowrap">Depo Şart, MF & Net Maliyet Karşılaştırma</p>
                </div>
            </div>
            
            <div class="flex items-center space-x-1.5 text-[11px] shrink-0 whitespace-nowrap">
                <!-- Aktif Eczane Otomasyonu Durum Butonu (Botanik / TRIA / TEBEOS) -->
                <button type="button" onclick="openCurrentOtomasyonSettings()" id="headerActiveOtomasyonBtn" class="inline-flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 transition cursor-pointer whitespace-nowrap shrink-0" title="Eczane Otomasyonu Bağlantı & Ping Durumu">
                    <i id="headerOtomasyonIcon" class="fa-solid fa-leaf text-emerald-600"></i>
                    <span id="headerOtomasyonText">🌿 Botanik EOS: Kontrol Ediliyor...</span>
                    <span id="headerOtomasyonDot" class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse ml-0.5"></span>
                </button>

                <!-- Depolar Rozeti -->
                <button type="button" onclick="openSettingsModal('depolar')" id="headerDepoBadgeBtn" class="inline-flex items-center space-x-1 px-2.5 py-1.5 rounded-lg font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition cursor-pointer whitespace-nowrap shrink-0" title="Ecza depoları giriş şifrelerini ve aktiflik durumunu aç">
                    <span id="headerDepoDot" class="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span id="headerDepoText">6 Depo Aktif</span>
                </button>

                <!-- Depo Sepetlerim Butonu -->
                <button type="button" onclick="openMultiDepotCartModal()" id="headerCartBtn" class="inline-flex items-center space-x-1 px-2.5 py-1.5 rounded-lg font-extrabold bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-300 transition cursor-pointer whitespace-nowrap shrink-0" title="Depo Sepetlerim: Sepetteki ürünleri depolara göre ayrı ayrı inceleyin ve sepete gidin">
                    <i class="fa-solid fa-cart-shopping text-indigo-600"></i>
                    <span>Sepetlerim</span>
                    <span id="headerCartCountBadge" class="px-1.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-black leading-none">0</span>
                    <span id="headerCartDepotPills" class="hidden 2xl:inline-flex items-center gap-1 ml-0.5"></span>
                </button>

                <!-- Sürüm & Otomatik Güncelleme Rozeti -->
                <button type="button" onclick="openUpdateModal()" id="headerVersionBtn" class="inline-flex items-center space-x-1 px-2.5 py-1.5 rounded-lg font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition cursor-pointer whitespace-nowrap shrink-0" title="Program Sürümü ve Güncellemeleri Denetle">
                    <i class="fa-solid fa-cloud-arrow-down text-slate-500" id="headerVersionIcon"></i>
                    <span id="headerVersionText">v1.4.2</span>
                    <span id="headerUpdateDot" class="hidden w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                </button>

                <!-- Belirgin AYARLAR Butonu -->
                <button type="button" onclick="openSettingsModal()" id="headerSettingsBtn" class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-bold bg-slate-900 hover:bg-slate-800 text-white transition cursor-pointer whitespace-nowrap shrink-0" title="Eczane Otomasyonu (Botanik/TRIA), Depolar ve Sistem Ayarlarını Aç">
                    <i class="fa-solid fa-gear text-amber-400"></i>
                    <span>Ayarlar</span>
                </button>
            </div>
        </div>
    </header>

    <!-- Main View Switcher (Kompakt Tek Satır - Kaydırma Çubuğu Yok) -->
    <div class="bg-white border-b border-slate-200 sticky top-[49px] z-40 shadow-2xs">
        <div class="max-w-7xl mx-auto px-3 sm:px-5 flex items-center justify-between gap-2 flex-nowrap">
            <div class="flex items-center space-x-1 shrink-0 whitespace-nowrap">
                <button id="mainTabDepo" onclick="switchMainView('depo')" class="py-2.5 px-3 border-b-2 border-emerald-600 text-emerald-800 font-bold text-xs flex items-center space-x-1.5 transition cursor-pointer shrink-0 whitespace-nowrap">
                    <i class="fa-solid fa-boxes-stacked text-emerald-600"></i>
                    <span>🏢 Depo & MF Karşılaştırma</span>
                    <span class="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">6 Depo</span>
                </button>
                <button id="mainTabSmartOrder" onclick="switchMainView('smart_order')" class="py-2.5 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 font-bold text-xs flex items-center space-x-1.5 transition cursor-pointer shrink-0 whitespace-nowrap">
                    <i class="fa-solid fa-chart-column text-amber-600"></i>
                    <span id="mainTabSmartOrderLabel">📊 6 Aylık Çıkış & Toplu Sipariş</span>
                    <span id="smartOrderTabBadge" class="text-[10px] font-extrabold px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300">Akıllı MF</span>
                </button>
                <button id="mainTabMarket" onclick="switchMainView('market')" class="py-2.5 px-3 border-b-2 border-transparent text-slate-500 hover:text-slate-900 font-semibold text-xs flex items-center space-x-1.5 transition cursor-pointer shrink-0 whitespace-nowrap">
                    <i class="fa-solid fa-basket-shopping text-indigo-600"></i>
                    <span>🛍️ Pazaryeri & Piyasa Kıyaslama</span>
                    <span class="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">9 Platform</span>
                </button>
            </div>
            <div class="flex items-center gap-1.5 shrink-0 whitespace-nowrap py-1">
                <button type="button" onclick="openEndOfDaySummaryModal('summary')" class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg font-extrabold text-[11px] bg-slate-900 hover:bg-slate-800 text-white shadow-2xs transition cursor-pointer whitespace-nowrap shrink-0" title="Gün Sonu Depo Sipariş Özeti, Sipariş Verilmeyecekler ve Yok Listesi">
                    <i class="fa-solid fa-clipboard-list text-amber-400"></i>
                    <span>📋 Gün Sonu & Yok Listesi</span>
                    <span id="eodHeaderSummaryBadge" class="px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black leading-tight">0</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- VIEW 1: DEPO & MF KARŞILAŞTIRMA (Depo Modülü) -->
        <div id="viewDepo" class="space-y-8 relative">
        <!-- Search Box Container with Relative Positioning for Dropdown -->
        <div class="max-w-3xl mx-auto mb-8">
            <!-- Günün Verileri Durum Rozeti -->
            <div id="botanikDataStatusPill" class="mb-3.5 flex items-center justify-between px-3.5 py-2 rounded-xl text-xs transition-all duration-300 bg-amber-50/90 border border-amber-200/80 text-amber-900 shadow-xs backdrop-blur-xs">
                <div class="flex items-center space-x-2.5 min-w-0">
                    <span id="dataStatusIcon" class="inline-block w-2.5 h-2.5 rounded-full border-2 border-amber-500 border-t-transparent animate-spin shrink-0"></span>
                    <span id="dataStatusText" class="truncate font-medium">
                        Günün çıkışları & azalan stok verileri hazırlanıyor...
                    </span>
                </div>
                <div class="flex items-center space-x-1.5 text-[11px] shrink-0">
                    <button type="button" onclick="switchMainView('smart_order')" class="font-bold px-2.5 py-0.5 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer flex items-center space-x-1 shadow-2xs" title="6 Aylık Çıkış, Trend Analizi, Canlı MF ve Akıllı Toplu Sipariş Planlama Sayfasını Aç">
                        <i class="fa-solid fa-table-list text-xs"></i>
                        <span>6 Aylık Toplu Sipariş Planlama</span>
                    </button>
                    <button type="button" onclick="toggleSideWidget(true)" class="font-bold px-2.5 py-0.5 rounded-md bg-amber-200/70 hover:bg-amber-300/80 text-amber-950 transition cursor-pointer flex items-center space-x-1">
                        <i class="fa-solid fa-fire text-amber-600 text-xs"></i>
                        <span>Günün Çıkışları</span>
                    </button>
                </div>
            </div>

            <div class="relative">
                <div class="bg-white p-3 rounded-2xl shadow-lg shadow-slate-100 border border-slate-200 flex items-center space-x-3 relative z-30">
                    <div class="pl-3 text-slate-400">
                        <i class="fa-solid fa-barcode text-xl"></i>
                    </div>
                    <input 
                        type="text" 
                        id="searchInput" 
                        placeholder="İlaç Adı (Parol, Augmentin), Barkod (869...) veya OTC (Ocean, Solgar)..."
                        class="w-full py-2.5 text-base text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
                        autocomplete="off"
                        autofocus
                    >
                    <button 
                        id="searchBtn" 
                        onclick="handleSearchSubmit()"
                        class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-xl text-sm transition-all shadow-md shadow-emerald-200 flex items-center space-x-2 shrink-0 cursor-pointer"
                    >
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <span>Sorgula</span>
                    </button>
                </div>

                <!-- Auto-Suggest Dropdown (Anchored directly under the search bar) -->
                <div id="suggestBox" class="hidden absolute left-0 right-0 top-full mt-1.5 bg-white rounded-2xl border border-slate-200 shadow-2xl z-50 overflow-hidden divide-y divide-slate-100 max-h-96 overflow-y-auto">
                    <!-- Suggestions will be injected here -->
                </div>
            </div>
            
            <!-- Quick Chips -->
            <div class="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-500">
                <span class="font-medium">Hızlı Örnekler:</span>
                <button onclick="selectAndSearch('8699717010109', 'PAROL 500 MG 20 TB')" class="px-2.5 py-1 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 text-slate-600 transition">Parol 500 mg 20 Tb</button>
                <button onclick="selectAndSearch('8699522095650', 'AUGMENTIN BID 1000 MG 14 TB')" class="px-2.5 py-1 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 text-slate-600 transition">Augmentin BID 1g</button>
                <button onclick="handleSearchSubmit('OCEAN')" class="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 text-emerald-700 font-medium transition">Ocean (OTC Seçimi)</button>
                <button onclick="selectAndSearch('8697595872413', 'OCEAN ALFA LIPOIK ASIT 200 MG 30 CAP')" class="px-2.5 py-1 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 text-slate-600 transition">Ocean Alfa Lipoik 200mg</button>
                <button id="etQuickOffersChipBtn" onclick="openEczaneTakasOffersModal()" class="hidden px-2.5 py-1 bg-sky-50 hover:bg-sky-100 rounded-lg border border-sky-200 text-sky-700 font-semibold transition items-center space-x-1 cursor-pointer" title="EczaneTakas üzerindeki aktif teklifleri gör"><i class="fa-solid fa-arrow-right-arrow-left text-[10px]"></i><span>EczaneTakas Teklifleri</span></button>
                <button id="eczatrendQuickOffersChipBtn" onclick="openEczatrendOffersModal()" class="hidden px-2.5 py-1 bg-purple-50 hover:bg-purple-100 rounded-lg border border-purple-200 text-purple-700 font-semibold transition items-center space-x-1 cursor-pointer" title="Eczatrend ortak alım grubundaki aktif teklifleri gör"><i class="fa-solid fa-users-rectangle text-[10px]"></i><span>Eczatrend Teklifleri</span></button>
            </div>
        </div>

        <!-- Loading Spinner -->
        <div id="loading" class="hidden text-center py-16">
            <div class="inline-block animate-spin rounded-full h-12 w-12 border-4 border-emerald-500 border-t-transparent"></div>
            <p class="mt-4 text-base font-semibold text-slate-700" id="loadingText">Depo şartları taranıyor...</p>
            <p class="text-xs text-slate-400 mt-1">Alliance • Selçuk • Nevzat • İSKOOP • BEK • Ecza1 • Farmazon eşzamanlı sorgulanıyor...</p>
        </div>

        <!-- Product Selection Grid (When search query matches multiple products, e.g. OTC brand) -->
        <div id="productSelection" class="hidden mb-8 space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-lg font-bold text-slate-900" id="selectionTitle">Eşleşen Ürünler</h2>
                    <p class="text-xs text-slate-500">Ürünlerin karışmaması için lütfen karşılaştırmak istediğiniz spesifik ürünü seçin:</p>
                </div>
                <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-600" id="selectionCount">0 Ürün</span>
            </div>
            
            <div id="selectionGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- Injected dynamically -->
            </div>
        </div>

        <!-- Result Container -->
        <div id="results" class="hidden space-y-6">
            <!-- Bugün Sipariş Verildi / Sepette Uyarısı (Tüm Bilgisayarlarla Senkron) -->
            <div id="resTodayOrderedBanner" class="hidden"></div>

            <!-- Product Banner -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="text-xs font-bold px-2.5 py-1 rounded bg-slate-100 text-slate-700 font-mono" id="resBarcode">8699717010109</span>
                        <span class="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200" id="resStockCount">3 Depoda Stok Var</span>
                        <!-- Soğuk Zincir Rozeti -->
                        <span id="resColdChainBadge" class="hidden text-xs font-bold text-sky-800 bg-sky-50 px-2.5 py-0.5 rounded border border-sky-300 items-center shadow-xs">
                            <i class="fa-solid fa-snowflake text-sky-500 mr-1 animate-pulse"></i>Soğuk Zincir (+2°C / +8°C)
                        </span>
                        <!-- Muadiller / Eşdeğer Butonu -->
                        <button type="button" id="resEquivalentsBtn" onclick="scrollToMuadillerTab()" title="Aşağıdaki Eczane Analiz panelindeki Muadiller sekmesine git (Stok, Çıkış Hızı ve Geçmiş MF)" class="hidden text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-0.5 rounded border border-indigo-200 transition items-center space-x-1 cursor-pointer">
                            <i class="fa-solid fa-arrows-split-up-and-left mr-1 text-indigo-600"></i>
                            <span id="resEquivalentsBtnText">Muadiller</span>
                        </button>
                    </div>
                    <h2 class="text-xl font-bold text-slate-900 mt-1.5" id="resTitle">PAROL 500 MG 20 TB.</h2>
                    
                    <!-- SGK Kamu İskontosu & Eczacı Kâr Marjı Bilgi Şeridi -->
                    <div class="text-xs text-slate-500 mt-2 flex flex-wrap items-center gap-x-3 gap-y-1.5">
                        <span id="resVatInfo"><i class="fa-solid fa-receipt mr-1"></i>KDV: <strong>%10</strong></span>
                        <span class="text-slate-300">•</span>
                        <span id="resSgkInfo" title="SGK'ya verilen yasal kamu iskontosu"><i class="fa-solid fa-shield-halved mr-1 text-blue-600"></i>Kamu İsk: <strong id="resKamuIsk" class="text-slate-700 font-bold">%0.0</strong></span>
                        <span class="text-slate-300">•</span>
                        <span id="resKarInfo" title="Yasal bareme göre eczacı kâr oranı"><i class="fa-solid fa-coins mr-1 text-amber-600"></i>Yasal Kâr: <strong id="resEczaciKari" class="text-slate-700 font-bold">%0.0</strong></span>
                        <span class="text-slate-300">•</span>
                        <span id="resPsfInfo" title="Perakende Satış / Kutu Etiket Fiyatı"><i class="fa-solid fa-tag mr-1 text-slate-400"></i>Elden Satış (PSF): <strong id="resPsf" class="text-slate-800 font-bold">0.00 ₺</strong></span>
                        <span class="text-slate-300">•</span>
                        <span id="resKsfInfo" title="Kamu Satış Fiyatı = PSF * (1 - Kamu İskontosu)"><i class="fa-solid fa-building-columns mr-1 text-indigo-600"></i>Kamu Fiyatı (KSF): <strong id="resKsf" class="text-indigo-900 font-bold">0.00 ₺</strong></span>
                    </div>

                    <!-- Kâr Gösterge Rozetleri (SGK Kamu Satışı vs Elden Perakende Satışı) -->
                    <div class="mt-3 flex flex-wrap items-center gap-2.5" id="resProfitBadges">
                        <div class="inline-flex items-center px-3 py-1 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900 shadow-2xs" title="SGK reçeteli satışında kutu başına düşen tahmini net kâr (KSF - Alış)">
                            <i class="fa-solid fa-file-prescription mr-1.5 text-blue-600"></i>
                            <span>SGK Reçeteli Kutu Kârı: <strong id="resKamuProfit" class="font-extrabold text-blue-800 ml-1">0.00 ₺</strong></span>
                        </div>
                        <div class="inline-flex items-center px-3 py-1 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 shadow-2xs" title="Reçetesiz elden nakit/kredi kartı satışında kutu başına düşen tahmini net kâr (PSF - Alış)">
                            <i class="fa-solid fa-hand-holding-dollar mr-1.5 text-emerald-600"></i>
                            <span>Elden Satış Kutu Kârı: <strong id="resPerakendeProfit" class="font-extrabold text-emerald-800 ml-1">0.00 ₺</strong></span>
                        </div>
                        <!-- Daha Kârlı Muadil Rozeti (Tıklanınca doğrudan Muadiller sekmesine kayar) -->
                        <div id="resMuadilProfitOpportunity" onclick="scrollToMuadillerTab()" class="hidden cursor-pointer items-center px-3.5 py-1 rounded-xl bg-gradient-to-r from-amber-500/15 via-emerald-500/15 to-teal-500/15 border border-emerald-500/60 text-xs text-emerald-950 font-bold shadow-2xs hover:bg-emerald-100/60 transition" title="SGK eşdeğer grubunda daha kârlı muadil ilaç bulunuyor, görmek için tıklayın">
                            <i class="fa-solid fa-trophy mr-1.5 text-amber-500 animate-pulse"></i>
                            <span>Daha Kârlı Muadil Var: <strong id="resBestMuadilName" class="text-emerald-900 font-extrabold">--</strong> (Kutu başı <strong id="resBestMuadilGain" class="text-emerald-700 font-black">+0.00 ₺</strong> daha kârlı!) <span class="underline ml-1">İncele &rarr;</span></span>
                        </div>
                    </div>
                </div>
                
                <div id="bestDealBanner" class="hidden bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4 flex items-center space-x-4 shadow-sm">
                    <div class="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xl shadow-md shadow-emerald-200">
                        <i class="fa-solid fa-trophy"></i>
                    </div>
                    <div>
                        <div class="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">En Avantajlı Depo</div>
                        <div class="text-lg font-extrabold text-emerald-950" id="bestDepoName">NEVZAT ECZA</div>
                        <div class="text-xs text-emerald-700 mt-0.5">
                            Net Kutu: <strong class="text-sm font-bold text-emerald-800" id="bestCost">52.31 ₺</strong> (KDV Hariç)
                            <span class="text-emerald-600 ml-1">(KDV Dahil: <span id="bestCostKdvli">57.54 ₺</span>)</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TRIA Eczane Stok & Aylık Çıkış Hızı & Akıllı Sipariş Paneli -->
            <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl shadow-xl p-6 text-white border border-indigo-900/50">
                <!-- Üst Başlık & Anlık Raf Stoğu Rozeti -->
                <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-white/10">
                    <div class="space-y-1.5">
                        <div class="flex flex-wrap items-center gap-2">
                            <span id="otoBrandBadge" class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1.5"></span>
                                <span id="otoBrandText">ECZANE OTOMASYONU • CANLI ENTEGRASYON</span>
                            </span>
                            <span id="triaHostSubBadge" class="text-[11px] text-slate-400 font-mono">Canlı Bağlantı</span>
                            <button type="button" onclick="openCurrentOtomasyonSettings()" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 transition cursor-pointer flex items-center space-x-1" title="Otomasyon Veritabanı ve Şifre Ayarlarını Aç">
                                <i class="fa-solid fa-gear text-[10px]"></i>
                                <span>Veritabanı & Şifre Ayarları</span>
                            </button>
                        </div>
                        <h3 class="text-lg font-bold text-white flex items-center space-x-2">
                            <span>Eczane Raf Stoğu & Giriş - Çıkış Hareket Analizi</span>
                        </h3>
                        <p class="text-xs text-slate-300 max-w-2xl">
                            Aradığınız ilacın eczanenizdeki anlık raf stoğunu, son 6 aylık Nakit (elden) ve Reçeteli (SGK) çıkışlarını ve depolardan gelen son alış faturalarını (girişleri) gösterir.
                        </p>
                    </div>

                    <!-- Anlık Raf Stoğu Kartı -->
                    <div class="flex items-center space-x-3.5 bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/15">
                        <div class="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center text-xl shadow-lg shadow-emerald-950/40">
                            <i class="fa-solid fa-boxes-stacked"></i>
                        </div>
                        <div>
                            <div class="text-[11px] font-semibold text-slate-300 uppercase tracking-wider">Eczane Raf Stoğu</div>
                            <div class="flex items-baseline space-x-2">
                                <span class="text-2xl font-black text-white" id="triaStockQty">--</span>
                                <span class="text-xs font-semibold text-slate-300">Kutu</span>
                                <span id="triaStockStatusBadge" class="ml-1.5 px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-slate-700 text-slate-200">
                                    Hesaplanıyor...
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Giriş & Çıkış Görünüm Seçici ve Filtreler -->
                <div class="mt-5">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3 border-b border-white/10 pb-2.5">
                        <!-- Sekmeler (Çıkış / Giriş / Her İkisi / Muadiller) -->
                        <div class="flex flex-wrap items-center gap-1.5 bg-white/10 p-1 rounded-xl w-fit">
                            <button type="button" id="tabBtnCikislar" onclick="switchOtomasyonMovementsTab('cikis')" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-white/20 text-white transition flex items-center space-x-1.5 cursor-pointer shadow-xs">
                                <i class="fa-solid fa-chart-simple text-emerald-400"></i>
                                <span>📉 ÇIKIŞ: Satış Hızı (6 Ay)</span>
                            </button>
                            <button type="button" id="tabBtnGirisler" onclick="switchOtomasyonMovementsTab('giris')" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-white/10 transition flex items-center space-x-1.5 cursor-pointer">
                                <i class="fa-solid fa-truck-ramp-box text-cyan-400"></i>
                                <span>📥 GİRİŞ: Son Depo Alışları</span>
                                <span id="badgeGirisCount" class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-cyan-500/30 text-cyan-200">0</span>
                            </button>
                            <button type="button" id="tabBtnBoth" onclick="switchOtomasyonMovementsTab('both')" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-white/10 transition flex items-center space-x-1.5 cursor-pointer">
                                <i class="fa-solid fa-table-columns text-indigo-400"></i>
                                <span>📊 İkisi Birlikte</span>
                            </button>
                            <button type="button" id="tabBtnMuadiller" onclick="switchOtomasyonMovementsTab('muadil')" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-white/10 transition flex items-center space-x-1.5 cursor-pointer">
                                <i class="fa-solid fa-arrows-split-up-and-left text-amber-400"></i>
                                <span>🔄 MUADİLLER (SGK Eşdeğer)</span>
                                <span id="badgeMuadilCount" class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500/30 text-amber-200">0</span>
                            </button>
                        </div>

                        <!-- Legend & Ek Bilgi -->
                        <div id="cikisLegend" class="flex items-center space-x-3 text-[11px] text-slate-400">
                            <span class="flex items-center"><span class="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block mr-1"></span>Nakit / Elden Satış</span>
                            <span class="flex items-center"><span class="w-2.5 h-2.5 rounded-full bg-blue-400 inline-block mr-1"></span>SGK / Reçeteli Çıkış</span>
                        </div>
                        <div id="girisLegend" class="hidden flex items-center space-x-2 text-[11px] text-cyan-300">
                            <i class="fa-solid fa-file-invoice text-xs"></i>
                            <span>İskoop, Hedef, Selçuk, Nevzat vb. faturaları</span>
                        </div>
                        <div id="muadilLegend" class="hidden flex items-center space-x-2 text-[11px] text-amber-300">
                            <i class="fa-solid fa-shield-halved text-xs"></i>
                            <span>SGK Grubu: <strong id="darkEsdegerKodu" class="font-mono text-white">--</strong> • Raf Stoğu, 30 Günlük Çıkış & Geçmiş MF Durumu</span>
                        </div>
                    </div>

                    <!-- 1. Çıkışlar Görünümü (Dinamik Aylık Çıkış Kartları Grid) -->
                    <div id="boxCikislarView" class="space-y-2">
                        <div id="triaMonthlyGrid" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                            <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                                <i class="fa-solid fa-spinner animate-spin mr-1.5"></i>Otomasyon veritabanından aylık hareketler alınıyor...
                            </div>
                        </div>
                    </div>

                    <!-- 2. Girişler Görünümü (Son Depo Alış Faturaları) -->
                    <div id="boxGirislerView" class="hidden space-y-2">
                        <div id="otomasyonGirislerGrid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                            <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                                <i class="fa-solid fa-spinner animate-spin mr-1.5"></i>Depo alış faturaları taranıyor...
                            </div>
                        </div>
                    </div>

                    <!-- 3. Muadiller Görünümü (SGK Eşdeğer Grubu İlaçları, Anlık MF, Kârlılık ve Raf Stoğu) -->
                    <div id="boxMuadillerView" class="hidden space-y-3">
                        <!-- En Kârlı Muadil Üst Vurgu Bannerı -->
                        <div id="boxMuadilHighlightBanner" class="hidden"></div>

                        <div id="otomasyonMuadillerGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                            <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                                <i class="fa-solid fa-spinner animate-spin mr-1.5 text-amber-400"></i>Eşdeğer grup ilaçları ve canlı depo kârlılıkları taranıyor...
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Analiz Metrikleri ve Akıllı Sipariş Çubuğu -->
                <div class="mt-5 pt-4 border-t border-white/10 grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
                    <!-- Sol: Metrikler (3 Sütun) -->
                    <div class="lg:col-span-5 grid grid-cols-3 gap-2 text-center">
                        <div class="bg-white/5 rounded-xl p-2.5 border border-white/10">
                            <div class="text-[10px] text-slate-400">Aylık Ort. Çıkış</div>
                            <div class="text-base font-bold text-emerald-300 mt-0.5" id="triaAvgMonthly">--</div>
                            <div class="text-[9px] text-slate-400" id="triaAvgDaily">-- / Gün</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2.5 border border-white/10">
                            <div class="text-[10px] text-slate-400">Kalan Stok Süresi</div>
                            <div class="text-base font-bold text-cyan-300 mt-0.5" id="triaDaysLeft">--</div>
                            <div class="text-[9px] text-slate-400">Yeterlilik</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2.5 border border-white/10">
                            <div class="text-[10px] text-slate-400">30 Günlük İhtiyaç</div>
                            <div class="text-base font-bold text-amber-300 mt-0.5" id="triaOrderSuggested">--</div>
                            <div class="text-[9px] text-slate-400">Önerilen Sipariş</div>
                        </div>
                    </div>

                    <!-- Sağ: Entegre Hızlı Sipariş ve Sepete Ekleme Alanı -->
                    <div class="lg:col-span-7 bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/15 flex flex-col sm:flex-row items-center justify-between gap-3">
                        <div class="flex items-center space-x-3 w-full sm:w-auto">
                            <div>
                                <label class="text-[10px] font-semibold text-slate-300 block mb-0.5">Sipariş (Kutu)</label>
                                <input 
                                    type="number" 
                                    id="simQtyInput" 
                                    value="25" 
                                    min="1" 
                                    max="5000"
                                    oninput="onSimulatorChange()"
                                    class="w-24 bg-white text-slate-900 font-extrabold px-2.5 py-1.5 rounded-lg text-center text-base focus:outline-none focus:ring-2 focus:ring-emerald-400"
                                >
                            </div>
                            <div class="flex flex-wrap gap-1">
                                <button type="button" onclick="setSimulatorQty(10)" class="px-2 py-1 text-[11px] font-semibold rounded bg-white/10 hover:bg-white/20 text-white transition cursor-pointer">10</button>
                                <button type="button" onclick="setSimulatorQty(25)" class="px-2 py-1 text-[11px] font-semibold rounded bg-white/10 hover:bg-white/20 text-white transition cursor-pointer">25</button>
                                <button type="button" onclick="setSimulatorQty(50)" class="px-2 py-1 text-[11px] font-semibold rounded bg-white/10 hover:bg-white/20 text-white transition cursor-pointer">50</button>
                                <button type="button" id="btnQuickSuggested" onclick="setSuggestedQty()" class="px-2 py-1 text-[11px] font-semibold rounded bg-amber-500/30 hover:bg-amber-500/50 text-amber-200 border border-amber-400/40 transition cursor-pointer" title="Aylık ortalama satışa göre eksik kalan miktarı seçer">
                                    <i class="fa-solid fa-bullseye mr-1"></i>Önerilen
                                </button>
                            </div>
                        </div>

                        <div class="flex items-center space-x-3 w-full sm:w-auto justify-end">
                            <div class="text-right hidden sm:block">
                                <div class="text-[10px] text-slate-300 font-medium" id="simDepoNote">En Avantajlı Depo</div>
                                <div class="text-sm font-extrabold text-emerald-300" id="simTotalInvoice">0.00 ₺</div>
                                <div class="text-[9px] text-slate-400" id="simInvoiceKdvli">KDV Dahil: 0.00 ₺</div>
                            </div>
                            <button id="simAddToCartBtn" onclick="addSimulatedToCart(this)" class="px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-950/40 flex items-center space-x-2 cursor-pointer shrink-0">
                                <i class="fa-solid fa-cart-arrow-down text-sm"></i>
                                <span id="simAddToCartText">Sepete Ekle</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Detaylı MF & Baremler Açılır Akordeonu -->
                <div class="mt-3 pt-2 text-right">
                    <button type="button" onclick="toggleMfDetails()" class="text-[11px] text-indigo-300 hover:text-white transition inline-flex items-center space-x-1 cursor-pointer">
                        <i class="fa-solid fa-circle-chevron-down mr-1" id="mfToggleIcon"></i>
                        <span>MF Baremleri & Birim Kutu Maliyet Detayını Göster</span>
                    </button>
                    <div id="simResultsBox" class="hidden mt-3 pt-3 border-t border-white/10 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-center">
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Faturalanan Kutu</div>
                            <div class="text-base font-bold text-white mt-0.5" id="simPaidBoxes">--</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-emerald-400 font-semibold">Bedelsiz MF</div>
                            <div class="text-base font-bold text-emerald-400 mt-0.5" id="simFreeBoxes">--</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Teslim Alınan</div>
                            <div class="text-base font-bold text-white mt-0.5" id="simTotalBoxes">--</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Birim Net (KDV Hariç)</div>
                            <div class="text-base font-bold text-emerald-400 mt-0.5" id="simUnitNet">0.00 ₺</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Birim Net (KDV Dahil)</div>
                            <div class="text-base font-bold text-cyan-300 mt-0.5" id="simUnitKdvli">0.00 ₺</div>
                        </div>
                        <div class="bg-white/5 rounded-xl p-2 border border-white/10">
                            <div class="text-[10px] text-slate-400">Depo Şartı</div>
                            <div class="text-xs font-bold text-slate-200 mt-1 truncate" id="simMfText">--</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Table of Warehouse Conditions -->
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                    <div>
                        <h3 class="font-bold text-slate-900 text-sm">Depo Ticari Şartları ve Maliyet Karşılaştırması</h3>
                        <p class="text-xs text-slate-500">Tüm depolarda geçerli MF kademeleri, vadeler ve KDV hariç/dahil net fiyatlar</p>
                    </div>
                    <span class="text-xs text-slate-400"><i class="fa-solid fa-circle-info mr-1"></i>MF rozetlerine tıklayarak simülatörü güncelleyebilirsiniz</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-sm">
                        <thead>
                            <tr class="bg-slate-50/75 border-b border-slate-100 text-slate-500 text-xs uppercase tracking-wider font-semibold">
                                <th class="py-3 px-6">Depo / Platform</th>
                                <th class="py-3 px-6">Stok Durumu</th>
                                <th class="py-3 px-6">DSF (KDV Hariç)</th>
                                <th class="py-3 px-6">MF Kademeleri</th>
                                <th class="py-3 px-6">Vade & İskonto</th>
                                <th class="py-3 px-6">Net Kutu (KDV Hariç)</th>
                                <th class="py-3 px-6">Net Kutu (KDV Dahil)</th>
                                <th class="py-3 px-6 text-right">Sepet İşlemi</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody" class="divide-y divide-slate-100">
                            <!-- Injected dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- End of results -->

        <!-- ============================================================== -->
        <!-- SAĞ TARAFTA KOMPAKT GÜNLÜK ÇIKIŞ & AZALAN STOK ÇEKMECESİ      -->
        <!-- ============================================================== -->
        <!-- 1. Katlanmış Durum Butonu (Ekranın Sağ Kenarında Fazla Yer Kaplamayan Rozet) -->
        <button 
            id="criticalMiniBadgeBtn" 
            onclick="toggleSideWidget(true)" 
            class="fixed right-0 top-36 z-40 bg-slate-900/90 hover:bg-slate-900 text-white py-2.5 px-3 rounded-l-2xl shadow-2xl flex items-center space-x-2 border-l-2 border-amber-400 cursor-pointer transition transform hover:-translate-x-1 backdrop-blur-md" 
            title="Günün Çıkışları ve Azalan Stok Listesini Aç"
        >
            <i class="fa-solid fa-fire text-amber-400 text-sm animate-pulse"></i>
            <span class="text-xs font-bold tracking-tight">Günün Çıkışları</span>
            <span id="miniSideCriticalCount" class="bg-amber-400 text-slate-950 font-black text-[10px] px-1.5 py-0.5 rounded-full font-mono">0</span>
        </button>

        <!-- 2. Açılabilir Kompakt Sağ Panel (Ana Düzeni Bozmayan Floating Panel) -->
        <div 
            id="criticalSideWidget" 
            class="hidden fixed right-4 top-24 z-40 w-80 sm:w-[420px] bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200/90 shadow-2xl overflow-hidden flex flex-col transition-all duration-300"
            style="max-height: calc(100vh - 120px);"
        >
            <!-- Başlık Çubuğu -->
            <div class="px-3.5 py-2.5 bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white flex items-center justify-between">
                <div class="flex items-center space-x-2 min-w-0">
                    <div class="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs shrink-0">
                        <i class="fa-solid fa-fire text-amber-400"></i>
                    </div>
                    <div class="truncate">
                        <h4 class="font-extrabold text-xs text-white leading-tight">Günün Çıkışları</h4>
                        <p class="text-[9px] text-slate-300">Azalan Stok & Sipariş Dağıtıcı</p>
                    </div>
                </div>
                <div class="flex items-center space-x-1.5 shrink-0">
                    <span id="sideCriticalCountBadge" class="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-400 text-slate-950 font-mono">0</span>
                    <button onclick="loadCriticalStockList(true)" class="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white flex items-center justify-center transition cursor-pointer" title="Listeyi Yenile">
                        <i class="fa-solid fa-arrows-rotate text-[10px]" id="criticalRefreshIcon"></i>
                    </button>
                    <!-- Küçült / Kapat Butonu -->
                    <button onclick="toggleSideWidget(false)" class="w-6 h-6 rounded-lg bg-white/10 hover:bg-rose-500/30 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer" title="Kapat">
                        <i class="fa-solid fa-minus text-[10px]"></i>
                    </button>
                </div>
            </div>

            <!-- Filtreleme & Arama Çubuğu -->
            <div class="p-2 bg-slate-50 border-b border-slate-200/80 space-y-1.5">
                <div class="relative">
                    <i class="fa-solid fa-magnifying-glass absolute left-2.5 top-2 text-[10px] text-slate-400"></i>
                    <input 
                        type="text" 
                        id="criticalFilterInput" 
                        placeholder="Listede ara (ilaç / barkod)..." 
                        oninput="filterCriticalList()"
                        class="w-full pl-7 pr-2.5 py-1 text-[11px] bg-white border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:border-amber-400"
                    />
                </div>
                <!-- Tükenen (0) & Eksiye Düşen (<0) Özel Takip Panosu -->
                <div class="grid grid-cols-2 gap-1.5 pt-0.5" id="criticalZeroNegSummaryBar">
                    <button 
                        type="button" 
                        id="cardCritSummaryZero"
                        onclick="toggleCriticalZeroOrNegFilter('zero')" 
                        class="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100/80 border border-rose-200 text-left transition cursor-pointer group"
                        title="Stoğu tam 0'a inen (tükenen) ürünleri listele (Tekrar tıklayınca tüm kritik listeye döner)"
                    >
                        <div class="flex items-center space-x-1.5 min-w-0">
                            <span class="w-5 h-5 rounded-md bg-rose-600 text-white flex items-center justify-center text-[10px] font-black shrink-0 shadow-2xs">0</span>
                            <div class="truncate">
                                <div class="text-[9px] font-extrabold text-rose-950 leading-tight">Tükenen (0'a İnen)</div>
                                <div class="text-[8px] text-rose-600 font-semibold leading-tight" id="critZeroSubText">Stok Sıfırlandı</div>
                            </div>
                        </div>
                        <span id="critZeroCountBadge" class="px-1.5 py-0.5 rounded-md bg-white text-rose-800 border border-rose-200 font-black text-[10px] font-mono shrink-0">0</span>
                    </button>

                    <button 
                        type="button" 
                        id="cardCritSummaryNegative"
                        onclick="toggleCriticalZeroOrNegFilter('negative')" 
                        class="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-purple-50 hover:bg-purple-100/80 border border-purple-200 text-left transition cursor-pointer group"
                        title="Stoğu eksiye (-1, -2 vb.) düşen ürünleri listele (Tekrar tıklayınca tüm kritik listeye döner)"
                    >
                        <div class="flex items-center space-x-1.5 min-w-0">
                            <span class="w-5 h-5 rounded-md bg-purple-700 text-white flex items-center justify-center text-[10px] font-black shrink-0 shadow-2xs">-</span>
                            <div class="truncate">
                                <div class="text-[9px] font-extrabold text-purple-950 leading-tight">Eksiye Düşen (&lt;0)</div>
                                <div class="text-[8px] text-purple-700 font-semibold leading-tight" id="critNegativeSubText">0 Kutu Açık</div>
                            </div>
                        </div>
                        <span id="critNegativeCountBadge" class="px-1.5 py-0.5 rounded-md bg-white text-purple-900 border border-purple-200 font-black text-[10px] font-mono shrink-0">0</span>
                    </button>
                </div>

                <div class="flex items-center justify-between pt-0.5 gap-1">
                    <div class="flex flex-wrap items-center gap-1 text-[10px]">
                        <button type="button" onclick="setCriticalFilterMode('days_21')" id="btnCritFilter21" class="px-2 py-0.5 rounded-md font-bold bg-slate-900 text-white transition text-[9px] cursor-pointer" title="Stoğu 21 gün ve altı kalan kritik ürünler">≤21 Gün</button>
                        <button type="button" onclick="setCriticalFilterMode('zero')" id="btnCritFilterZero" class="px-2 py-0.5 rounded-md font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 transition text-[9px] cursor-pointer" title="Stoğu tam 0 olan tükenen ürünler">Tükenen (0)</button>
                        <button type="button" onclick="setCriticalFilterMode('negative')" id="btnCritFilterNegative" class="px-2 py-0.5 rounded-md font-bold bg-purple-100 hover:bg-purple-200 text-purple-900 transition text-[9px] cursor-pointer" title="Stoğu 0'ın altına (eksiye) düşen ürünler">Eksi (&lt;0)</button>
                        <button type="button" onclick="setCriticalFilterMode('mf_only')" id="btnCritFilterMf" class="px-2 py-0.5 rounded-md font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 transition text-[9px] cursor-pointer flex items-center space-x-1" title="Depolarda aktif MF'si olan veya geçmişte MF'li alınanları filtrele">
                            <i class="fa-solid fa-gift text-amber-600 text-[8px]"></i>
                            <span>MF'liler</span>
                        </button>
                        <button type="button" onclick="setCriticalFilterMode('all')" id="btnCritFilterAll" class="px-2 py-0.5 rounded-md font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 transition text-[9px] cursor-pointer" title="Tüm çıkışları göster">Tümü</button>
                    </div>
                    <button 
                        type="button" 
                        id="btnToggleMfBadges" 
                        onclick="toggleMfBadgesView()" 
                        class="px-2 py-0.5 rounded-md font-extrabold text-[9px] transition cursor-pointer flex items-center space-x-1 bg-amber-500 text-white shadow-2xs hover:bg-amber-600 shrink-0"
                        title="MF rozetlerini göster / gizle"
                    >
                        <i class="fa-solid fa-gift text-[8px]"></i>
                        <span id="btnToggleMfBadgesText">MF: Açık</span>
                    </button>
                </div>
                <!-- Çoklu Bilgisayar Sipariş Durumu & Gizleme Barı -->
                <div class="flex items-center justify-between pt-1 border-t border-slate-200/70 text-[9px] gap-1">
                    <div class="flex items-center space-x-1.5 text-slate-600 font-semibold min-w-0 truncate" title="Eczanedeki tüm bilgisayarlar Tria/Botanik ortak veritabanı üzerinden anlık senkronize edilir">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
                        <span class="truncate">Ortak Takip:</span>
                        <span id="orderedTodayCountBadge" class="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 font-extrabold border border-emerald-200 shrink-0">0 Sipariş</span>
                    </div>
                    <div class="flex items-center gap-1 shrink-0">
                        <button type="button" onclick="openEndOfDaySummaryModal('skipped')" class="px-2 py-0.5 rounded-md font-extrabold text-[9px] transition cursor-pointer flex items-center space-x-1 bg-indigo-50 text-indigo-800 border border-indigo-200 hover:bg-indigo-100" title="Gün Sonu Depo Sipariş Özeti ve Sipariş Verilmeyeceklerden Yok Listesi Oluşturma">
                            <i class="fa-solid fa-clipboard-list text-[8px] text-indigo-600"></i>
                            <span>Özet & Yok Listesi</span>
                        </button>
                        <button 
                            type="button" 
                            id="btnToggleHideOrdered" 
                            onclick="toggleHideOrderedItems()" 
                            class="px-2 py-0.5 rounded-md font-extrabold text-[9px] transition cursor-pointer flex items-center space-x-1 bg-slate-200 text-slate-700 hover:bg-slate-300"
                            title="Sipariş verilen ürünleri listeden tamamen gizle veya en altta uyarı rozetiyle göster"
                        >
                            <i class="fa-solid fa-eye-slash text-[8px]" id="btnToggleHideOrderedIcon"></i>
                            <span id="btnToggleHideOrderedText">Siparişlileri Gizle</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Toplu Sipariş Aksiyon Barı (Alliance Healthcare) -->
            <div class="p-2.5 bg-gradient-to-r from-sky-50 via-blue-50 to-indigo-50 border-b border-sky-200 space-y-2">
                <div class="flex items-center justify-between text-xs">
                    <div class="flex items-center space-x-2">
                        <label class="inline-flex items-center space-x-1.5 cursor-pointer select-none group" onclick="handleMasterSelectClick(event)">
                            <input type="checkbox" id="bulkSelectAllCheck" class="sr-only" checked>
                            <span id="bulkSelectAllVisualBox" class="w-4 h-4 rounded border-2 border-sky-600 bg-sky-600 text-white flex items-center justify-center transition-all shadow-2xs group-hover:ring-2 group-hover:ring-sky-300">
                                <i id="bulkSelectAllVisualIcon" class="fa-solid fa-check text-[10px] leading-none"></i>
                            </span>
                            <span class="font-bold text-[11px] text-slate-800 group-hover:text-sky-900">Tümünü Seç</span>
                        </label>
                        <span id="bulkSelectedBadge" class="text-[10px] font-black px-2 py-0.5 rounded-full bg-sky-200 text-sky-900 font-mono">0 Seçili</span>
                    </div>
                    <div class="flex items-center space-x-1 text-[10px]">
                        <button type="button" onclick="markSelectedCriticalItemsSkipped()" class="px-2 py-0.5 rounded bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 font-extrabold transition cursor-pointer flex items-center space-x-1" title="Seçili ilaçları bugün sipariş verilmeyecek olarak işaretle (tüm bilgisayarlarda alta iner ve seçilmez)">
                            <i class="fa-solid fa-ban text-[8px] text-rose-600"></i>
                            <span>Verilmeyecek</span>
                        </button>
                        <button type="button" onclick="selectTopNItems(40)" class="px-2 py-0.5 rounded bg-white hover:bg-sky-100 text-sky-800 border border-sky-200 font-bold transition cursor-pointer" title="Listenin ilk 40 kalemini seç">İlk 40'ı Seç</button>
                        <button type="button" onclick="clearBulkSelection()" class="px-1.5 py-0.5 rounded bg-white hover:bg-slate-100 text-slate-500 border border-slate-200 transition cursor-pointer" title="Seçimleri temizle">Temizle</button>
                    </div>
                </div>

                <!-- Toplu Depo Siparişi Gönderim Paneli -->
                <div class="space-y-1.5 pt-1">
                    <div class="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                        <span>🚀 Kalemleri Sepete Aktar (Tek Tık):</span>
                        <span class="text-[9px] text-sky-700 font-bold bg-sky-100 px-1.5 py-0.5 rounded">Hızlı Aktarım</span>
                    </div>

                    <div class="grid grid-cols-2 gap-1.5">
                        <!-- Alliance Butonu -->
                        <button 
                            type="button" 
                            id="btnSendToAlliance"
                            data-depo-btn="ALLIANCE"
                            onclick="triggerBulkOrder('ALLIANCE')" 
                            class="py-2 px-2 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-extrabold text-[11px] rounded-xl shadow-sm transition-all flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98"
                            title="Alliance Healthcare B2B sepetine ekle"
                        >
                            <i class="fa-solid fa-truck-fast text-sky-200 text-xs"></i>
                            <span id="btnSendToAllianceText">Alliance</span>
                        </button>

                        <!-- Selçuk Butonu -->
                        <button 
                            type="button" 
                            id="btnSendToSelcuk"
                            data-depo-btn="SELCUK"
                            onclick="triggerBulkOrder('SELCUK')" 
                            class="py-2 px-2 bg-gradient-to-r from-rose-600 to-red-700 hover:from-rose-700 hover:to-red-800 text-white font-extrabold text-[11px] rounded-xl shadow-sm transition-all flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98"
                            title="Selçuk Ecza Deposu sepetine ekle"
                        >
                            <i class="fa-solid fa-paper-plane text-rose-200 text-xs"></i>
                            <span id="btnSendToSelcukText">Selçuk</span>
                        </button>

                        <!-- İSKOOP Butonu -->
                        <button 
                            type="button" 
                            id="btnSendToIskoop"
                            data-depo-btn="ISKOOP"
                            onclick="triggerBulkOrder('ISKOOP')" 
                            class="py-2 px-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-extrabold text-[11px] rounded-xl shadow-sm transition-all flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98"
                            title="İSKOOP E-Şube taslak siparişine ekle"
                        >
                            <i class="fa-solid fa-cart-plus text-emerald-200 text-xs"></i>
                            <span id="btnSendToIskoopText">İSKOOP</span>
                        </button>

                        <!-- Nevzat Butonu -->
                        <button 
                            type="button" 
                            id="btnSendToNevzat"
                            data-depo-btn="NEVZAT"
                            onclick="triggerBulkOrder('NEVZAT')" 
                            class="py-2 px-2 bg-gradient-to-r from-amber-600 to-orange-700 hover:from-amber-700 hover:to-orange-800 text-white font-extrabold text-[11px] rounded-xl shadow-sm transition-all flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98"
                            title="Nevzat Ecza Deposu sepetine ekle"
                        >
                            <i class="fa-solid fa-boxes-packing text-amber-200 text-xs"></i>
                            <span id="btnSendToNevzatText">Nevzat</span>
                        </button>
                    </div>

                    <!-- Küçültülmüş / Kapatılmış Toplu Sepete Kaldığı Yerden Devam Et Çubuğu & Depo Sepetleri -->
                    <div id="drawerMiniBulkResumeBar" class="hidden pt-1.5 space-y-1.5">
                        <div class="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-indigo-700 via-violet-700 to-emerald-700 text-white shadow-md flex flex-col gap-1.5">
                            <div class="flex items-center justify-between">
                                <button type="button" onclick="openMultiDepotCartModal()" class="flex items-center space-x-1.5 font-black text-[11px] hover:text-amber-300 transition cursor-pointer">
                                    <i class="fa-solid fa-basket-shopping text-amber-300 text-xs"></i>
                                    <span id="drawerMiniBulkResumeLabel">🛒 Depo Sepetlerim (İncele & Sepete Git)</span>
                                </button>
                                <div class="flex items-center gap-1">
                                    <button type="button" id="drawerMissingBulkBtn" onclick="reopenBulkOrderModal()" class="hidden px-2 py-0.5 rounded-full bg-rose-500 hover:bg-rose-600 text-white text-[9px] font-black cursor-pointer">Eksikler</button>
                                    <span id="drawerMiniBulkResumeBadge" onclick="openMultiDepotCartModal()" class="px-2 py-0.5 rounded-full bg-white/20 text-white text-[10px] font-mono cursor-pointer">0 Kalem</span>
                                </div>
                            </div>
                            <div id="drawerDepotCartPills" class="flex flex-wrap items-center gap-1"></div>
                        </div>
                    </div>

                    <!-- Hızlı Depo Sipariş Sonlandırma Butonları -->
                    <div class="pt-2 border-t border-sky-100 flex items-center justify-between">
                        <span class="text-[9px] text-slate-500 font-extrabold uppercase tracking-wider">Siparişi Bitir & Gönder:</span>
                        <div class="flex items-center space-x-1">
                            <button type="button" data-depo-btn="SELCUK" onclick="openBulkFinalizeFlow('SELCUK')" class="px-2 py-0.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10px] font-black border border-rose-200 transition flex items-center space-x-1 cursor-pointer" title="Selçuk Ecza sepetini doğrula ve depoya gönder">
                                <i class="fa-solid fa-paper-plane text-[8px]"></i>
                                <span>Selçuk</span>
                            </button>
                            <button type="button" data-depo-btn="ALLIANCE" onclick="openBulkFinalizeFlow('ALLIANCE')" class="px-2 py-0.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 text-[10px] font-black border border-sky-200 transition flex items-center space-x-1 cursor-pointer" title="Alliance Healthcare sepetini doğrula ve depoya gönder">
                                <i class="fa-solid fa-paper-plane text-[8px]"></i>
                                <span>Alliance</span>
                            </button>
                            <button type="button" data-depo-btn="ISKOOP" onclick="openBulkFinalizeFlow('ISKOOP')" class="px-2 py-0.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-[10px] font-black border border-emerald-200 transition flex items-center space-x-1 cursor-pointer" title="İSKOOP E-Şube sepetini doğrula ve depoya gönder">
                                <i class="fa-solid fa-paper-plane text-[8px]"></i>
                                <span>İSKOOP</span>
                            </button>
                            <button type="button" data-depo-btn="NEVZAT" onclick="openBulkFinalizeFlow('NEVZAT')" class="px-2 py-0.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-700 text-[10px] font-black border border-amber-200 transition flex items-center space-x-1 cursor-pointer" title="Nevzat Ecza sepetini doğrula ve depoya gönder">
                                <i class="fa-solid fa-paper-plane text-[8px]"></i>
                                <span>Nevzat</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dikey / Alt Alta İlaç Kartları Listesi -->
            <div id="criticalStockListContainer" class="p-2 overflow-y-auto space-y-1.5 divide-y divide-slate-100 flex-1">
                <div class="p-4 text-center text-slate-400 text-xs">
                    <i class="fa-solid fa-spinner fa-spin text-amber-500 mr-1.5"></i>Yükleniyor...
                </div>
            </div>

            <!-- Panel Altı Kısa Bilgi -->
            <div class="px-2.5 py-1.5 bg-slate-50 border-t border-slate-200 text-center">
                <span class="text-[9px] text-slate-400">💡 İlacın üzerine tıklayarak hemen depolarda sorgulayın</span>
            </div>
        </div>
        </div> <!-- End of viewDepo -->

        <!-- ======================================================================= -->
        <!-- VIEW 1.5: BOTANİK 6 AYLIK ÇIKIŞ & AKILLI TOPLU SİPARİŞ PLANLAMA         -->
        <!-- ======================================================================= -->
        <div id="viewSmartOrder" class="hidden space-y-3">
            <!-- SADELEŞTİRİLMİŞ TEK KART KONTROL PANELİ (Başlık + Hızlı Filtreler + Arama + Rakam Belirleme) -->
            <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <!-- Üst Şerit: Başlık + Trend Filtre Hapları + MF Tara / Yenile -->
                <div class="bg-slate-900 px-4 py-3 text-white flex flex-wrap items-center justify-between gap-2">
                    <div class="flex flex-wrap items-center gap-2">
                        <span id="smartOrderSourceBadge" class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                            📊 Eczane Otomasyonu 6 Aylık Analiz
                        </span>
                        <h2 class="text-sm sm:text-base font-black text-white">6 Aylık Çıkış & Toplu Sipariş</h2>
                    </div>

                    <!-- Kompakt 6'lı Filtre Hapları -->
                    <div class="flex flex-wrap items-center gap-1.5">
                        <button type="button" onclick="setSmartTrendFilter('ALL')" id="smartKpiAll" class="px-2.5 py-1 rounded-lg bg-emerald-600 text-white border border-emerald-400 text-[11px] font-extrabold cursor-pointer transition flex items-center gap-1.5">
                            <span>Tümü</span>
                            <span class="px-1.5 py-0.2 rounded bg-black/25 font-mono text-[10px]" id="smartStatTotal">0</span>
                        </button>
                        <button type="button" onclick="setSmartTrendFilter('STABIL')" id="smartKpiStabil" class="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-emerald-300 border border-white/15 text-[11px] font-bold cursor-pointer transition flex items-center gap-1.5">
                            <span>🟢 Stabil</span>
                            <span class="px-1.5 py-0.2 rounded bg-black/25 font-mono text-[10px]" id="smartStatStabil">0</span>
                        </button>
                        <button type="button" onclick="setSmartTrendFilter('AZALAN')" id="smartKpiAzalan" class="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-rose-300 border border-white/15 text-[11px] font-bold cursor-pointer transition flex items-center gap-1.5">
                            <span>📉 Azalan</span>
                            <span class="px-1.5 py-0.2 rounded bg-black/25 font-mono text-[10px]" id="smartStatAzalan">0</span>
                        </button>
                        <button type="button" onclick="setSmartTrendFilter('ARTAN')" id="smartKpiArtan" class="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-sky-300 border border-white/15 text-[11px] font-bold cursor-pointer transition flex items-center gap-1.5">
                            <span>📈 Artan</span>
                            <span class="px-1.5 py-0.2 rounded bg-black/25 font-mono text-[10px]" id="smartStatArtan">0</span>
                        </button>
                        <button type="button" onclick="setSmartTrendFilter('MF_ONLY')" id="smartKpiMf" class="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-amber-300 border border-white/15 text-[11px] font-bold cursor-pointer transition flex items-center gap-1.5">
                            <span>🎁 MF'li</span>
                            <span class="px-1.5 py-0.2 rounded bg-black/25 font-mono text-[10px]" id="smartStatMf">0</span>
                        </button>
                        <button type="button" onclick="setSmartTrendFilter('ORDERED')" id="smartKpiOrdered" class="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-indigo-300 border border-white/15 text-[11px] font-bold cursor-pointer transition flex items-center gap-1.5">
                            <span>✅ Siparişli</span>
                            <span class="px-1.5 py-0.2 rounded bg-black/25 font-mono text-[10px]" id="smartStatOrdered">0</span>
                        </button>
                    </div>

                    <div class="flex items-center gap-1.5 shrink-0">
                        <button type="button" onclick="resolveAllSmartOrderMfs(true)" id="btnSmartResolveMf" class="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-[11px] transition flex items-center gap-1 cursor-pointer">
                            <i class="fa-solid fa-gift text-[10px]" id="smartResolveMfIcon"></i>
                            <span id="smartResolveMfText">Canlı MF Tara</span>
                        </button>
                        <button type="button" onclick="loadSmartOrderList(true)" class="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-[11px] border border-white/15 transition flex items-center gap-1 cursor-pointer">
                            <i class="fa-solid fa-arrows-rotate text-[10px]" id="smartOrderRefreshIcon"></i>
                            <span>Yenile</span>
                        </button>
                    </div>
                </div>

                <!-- Orta Şerit: Kapsam + Arama + Stok Filtresi -->
                <div class="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                    <div class="flex flex-wrap items-center gap-1.5">
                        <span class="text-[11px] font-extrabold text-slate-500">Kapsam:</span>
                        <button type="button" id="btnSmartScopeToday" onclick="changeSmartOrderScope('today')" class="px-2.5 py-1 rounded-lg text-xs font-extrabold bg-emerald-600 text-white transition cursor-pointer">🔥 Bugün Çıkanlar</button>
                        <button type="button" id="btnSmartScopeWeek" onclick="changeSmartOrderScope('week')" class="px-2.5 py-1 rounded-lg text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer">📅 Son 7 Gün</button>
                        <button type="button" id="btnSmartScopeTop6m" onclick="changeSmartOrderScope('top6m')" class="px-2.5 py-1 rounded-lg text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer">🏆 6 Ay En Çok</button>

                        <span class="text-slate-300 mx-1">|</span>
                        <span class="text-[11px] font-extrabold text-slate-500">Stok:</span>
                        <button type="button" id="btnSmartStock_21" onclick="setSmartStockMaxDays(21)" class="px-2 py-1 rounded-lg text-[11px] font-extrabold bg-slate-900 text-white transition cursor-pointer">≤21G</button>
                        <button type="button" id="btnSmartStock_14" onclick="setSmartStockMaxDays(14)" class="px-2 py-1 rounded-lg text-[11px] font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer">≤14G</button>
                        <button type="button" id="btnSmartStock_0" onclick="setSmartStockMaxDays(0)" class="px-2 py-1 rounded-lg text-[11px] font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer">≤0 (Yok)</button>
                        <button type="button" id="btnSmartStock_999" onclick="setSmartStockMaxDays(999)" class="px-2 py-1 rounded-lg text-[11px] font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer">Tümü</button>
                    </div>

                    <div class="flex flex-wrap items-center gap-2 flex-1 max-w-md justify-end">
                        <div class="relative flex-1 min-w-[180px]">
                            <i class="fa-solid fa-magnifying-glass absolute left-2.5 top-2 text-slate-400 text-[11px]"></i>
                            <input 
                                type="text" 
                                id="smartOrderSearchInput" 
                                placeholder="İlaç veya barkod ara (Enter)..." 
                                oninput="renderSmartOrderTable()"
                                onkeydown="if(event.key === 'Enter') searchBotanikInSmartOrder()"
                                class="w-full pl-7 pr-2 py-1 text-xs bg-white border border-slate-300 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                            />
                        </div>
                        <button type="button" onclick="searchBotanikInSmartOrder()" class="px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-lg transition cursor-pointer shrink-0">
                            Ara
                        </button>
                        <label class="inline-flex items-center space-x-1 cursor-pointer select-none text-[11px] font-bold text-slate-700 bg-white px-2 py-1 rounded-lg border border-slate-200 hover:bg-slate-100 transition shrink-0">
                            <input type="checkbox" id="smartHideOrderedCheck" onchange="renderSmartOrderTable()" class="rounded text-emerald-600 w-3.5 h-3.5 cursor-pointer">
                            <span>Siparişlileri Gizle</span>
                        </label>
                    </div>
                </div>

                <!-- Alt Şerit: Sipariş Rakamı Belirleme (Manuel Kendi Rakamım vs Akıllı Hedef Gün) -->
                <div class="px-4 py-2.5 bg-white flex flex-col lg:flex-row lg:items-center justify-between gap-2.5 text-xs">
                    <!-- Sol: Manuel Rakam Belirleme -->
                    <div id="smartModeCardManual" class="flex flex-wrap items-center gap-1.5 bg-indigo-50/70 px-3 py-1.5 rounded-xl border border-indigo-200">
                        <button type="button" id="btnSmartModeManual" onclick="setSmartOrderQtyMode('manual')" class="px-2 py-1 rounded-lg text-[11px] font-black bg-indigo-600 text-white cursor-pointer">
                            ✍️ Manuel Rakam:
                        </button>
                        <button type="button" onclick="startCleanManualSmartOrder()" class="px-2 py-1 rounded-lg bg-white hover:bg-rose-50 text-rose-700 border border-rose-200 text-[11px] font-extrabold transition cursor-pointer" title="Otomatik seçimleri kaldırır; sadece rakam yazdığınız satırlar seçilir">
                            Sıfırla (Kendim Seçeceğim)
                        </button>
                        <span class="text-indigo-300">|</span>
                        <span class="text-[11px] font-bold text-indigo-950">Sabit Ata:</span>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(1)" class="px-2 py-0.5 rounded bg-white hover:bg-indigo-600 hover:text-white text-indigo-900 border border-indigo-300 font-black text-[11px] cursor-pointer">1</button>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(2)" class="px-2 py-0.5 rounded bg-white hover:bg-indigo-600 hover:text-white text-indigo-900 border border-indigo-300 font-black text-[11px] cursor-pointer">2</button>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(3)" class="px-2 py-0.5 rounded bg-white hover:bg-indigo-600 hover:text-white text-indigo-900 border border-indigo-300 font-black text-[11px] cursor-pointer">3</button>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(5)" class="px-2 py-0.5 rounded bg-white hover:bg-indigo-600 hover:text-white text-indigo-900 border border-indigo-300 font-black text-[11px] cursor-pointer">5</button>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(10)" class="px-2 py-0.5 rounded bg-white hover:bg-indigo-600 hover:text-white text-indigo-900 border border-indigo-300 font-black text-[11px] cursor-pointer">10</button>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(20)" class="px-2 py-0.5 rounded bg-white hover:bg-indigo-600 hover:text-white text-indigo-900 border border-indigo-300 font-black text-[11px] cursor-pointer">20</button>
                        <div class="inline-flex items-center bg-white rounded border border-indigo-300 px-1">
                            <input type="number" id="smartBulkFixedQtyInput" value="1" min="1" max="999" onkeydown="if(event.key==='Enter') applyBulkCustomQtyToSmartOrder(this.value)" class="w-9 text-center font-black text-[11px] text-indigo-900 focus:outline-none" />
                            <button type="button" onclick="applyBulkCustomQtyToSmartOrder(document.getElementById('smartBulkFixedQtyInput').value)" class="text-[10px] font-extrabold text-indigo-700 hover:underline px-1 cursor-pointer">Uygula</button>
                        </div>
                    </div>

                    <!-- Sağ: Akıllı Hedef Gün Önerisi -->
                    <div id="smartModeCardAuto" class="flex flex-wrap items-center gap-1.5 bg-amber-50/70 px-3 py-1.5 rounded-xl border border-amber-200">
                        <button type="button" id="btnSmartModeAuto" onclick="setSmartOrderQtyMode('auto')" class="px-2 py-1 rounded-lg text-[11px] font-black bg-amber-600 text-white cursor-pointer">
                            🤖 Öneri Hedefi:
                        </button>
                        <button type="button" onclick="setSmartTargetDays(1)" id="btnSmartDays_1" class="px-2 py-0.5 rounded text-[11px] font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 cursor-pointer">1G</button>
                        <button type="button" onclick="setSmartTargetDays(7)" id="btnSmartDays_7" class="px-2 py-0.5 rounded text-[11px] font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 cursor-pointer">7G</button>
                        <button type="button" onclick="setSmartTargetDays(10)" id="btnSmartDays_10" class="px-2 py-0.5 rounded text-[11px] font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 cursor-pointer">10G</button>
                        <button type="button" onclick="setSmartTargetDays(15)" id="btnSmartDays_15" class="px-2 py-0.5 rounded text-[11px] font-black bg-amber-600 text-white border border-amber-700 cursor-pointer">15G</button>
                        <button type="button" onclick="setSmartTargetDays(21)" id="btnSmartDays_21" class="px-2 py-0.5 rounded text-[11px] font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 cursor-pointer">21G</button>
                        <button type="button" onclick="setSmartTargetDays(30)" id="btnSmartDays_30" class="px-2 py-0.5 rounded text-[11px] font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 cursor-pointer">30G</button>
                        <button type="button" onclick="setSmartTargetDays(45)" id="btnSmartDays_45" class="hidden sm:inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 cursor-pointer">45G</button>
                        <button type="button" onclick="setSmartTargetDays(60)" id="btnSmartDays_60" class="px-2 py-0.5 rounded text-[11px] font-bold bg-white hover:bg-amber-100 text-slate-700 border border-slate-200 cursor-pointer">60G</button>
                        <input type="number" id="smartCustomDaysInput" value="15" min="1" max="180" onchange="setSmartTargetDays(this.value)" class="hidden" />
                        <span id="smartTargetDaysLabel" class="hidden">15G</span>
                        <label class="inline-flex items-center space-x-1 cursor-pointer select-none text-[11px] font-bold text-amber-950 ml-1">
                            <input type="checkbox" id="smartAutoRoundMfCheck" checked onchange="recalculateSmartOrderClientSide(false); renderSmartOrderTable();" class="rounded text-amber-600 w-3.5 h-3.5 cursor-pointer">
                            <span>🎁MF Tamamla</span>
                        </label>
                        <button type="button" onclick="applyRecommendedToAllInputs()" class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold cursor-pointer">
                            Önerileri Uygula
                        </button>
                    </div>
                </div>
            </div>

            <!-- TOPLU SİPARİŞ AKTARIM BARI (Kompakt Tek Satır - Kaydırma Çubuğu Yok) -->
            <div class="bg-sky-50/95 border border-sky-200 rounded-xl px-2.5 py-1.5 shadow-2xs flex items-center justify-between gap-1.5 sticky top-[89px] z-30 backdrop-blur-md flex-nowrap whitespace-nowrap">
                <div class="flex items-center gap-1 shrink-0 whitespace-nowrap">
                    <div id="smartMasterLabel" onclick="handleSmartMasterCheckClick(event)" class="inline-flex items-center space-x-1 cursor-pointer select-none bg-white hover:bg-sky-50 px-2 py-1 rounded-lg border border-sky-400 transition shrink-0" title="Tıkladığınızda tümünü seçer, tekrar tıkladığınızda tüm seçimleri bırakır">
                        <input type="checkbox" id="smartMasterCheck" checked class="sr-only">
                        <span id="smartMasterVisualBox" class="w-3.5 h-3.5 rounded flex items-center justify-center border border-sky-600 bg-sky-600 text-white transition-all">
                            <i id="smartMasterVisualIcon" class="fa-solid fa-check text-[9px] font-black"></i>
                        </span>
                        <span class="font-extrabold text-[11px] text-slate-800" id="smartMasterText">Tümünü Seç</span>
                    </div>
                    <div class="flex items-center space-x-1 bg-white px-2 py-1 rounded-lg border border-slate-200 text-[11px] shrink-0">
                        <span class="font-black text-sky-900" id="smartSelectedCountBadge">0 Seçili</span>
                        <span class="text-slate-300">•</span>
                        <span class="font-extrabold text-emerald-700" id="smartSelectedBoxesBadge">0 Kutu</span>
                    </div>
                    <button type="button" onclick="selectSmartByTrend('MANUAL')" class="px-1.5 py-1 rounded-lg bg-white hover:bg-indigo-50 text-indigo-800 border border-indigo-200 text-[10px] font-bold cursor-pointer shrink-0">✍️ Manuel</button>
                    <button type="button" onclick="selectSmartByTrend('STABIL')" class="px-1.5 py-1 rounded-lg bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold cursor-pointer shrink-0">🟢 Stabil</button>
                    <button type="button" onclick="selectSmartByTrend('MF')" class="px-1.5 py-1 rounded-lg bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 text-[10px] font-bold cursor-pointer shrink-0">🎁 MF'li</button>
                    <button type="button" onclick="markSelectedSmartItemsOrdered()" class="px-1.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-[10px] font-bold cursor-pointer shrink-0">✓ Verildi</button>
                    <button type="button" onclick="markSelectedSmartItemsSkipped()" class="px-1.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 text-[10px] font-bold cursor-pointer shrink-0" title="Seçili ilaçları bugün sipariş verilmeyecek olarak tüm bilgisayarlarda işaretle">🚫 Verilmeyecek</button>
                    <span id="smartMfScanProgressBadge" class="hidden text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 shrink-0">
                        <i class="fa-solid fa-spinner fa-spin mr-1"></i>MF...
                    </span>
                </div>

                <div class="flex items-center gap-1 shrink-0 whitespace-nowrap">
                    <span class="text-[10px] font-extrabold text-slate-600">🚀 Sepete:</span>
                    <button type="button" data-depo-btn="ALLIANCE" onclick="triggerSmartBulkOrder('ALLIANCE')" class="px-2 py-1 bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-[11px] rounded-lg transition cursor-pointer shrink-0">Alliance</button>
                    <button type="button" data-depo-btn="SELCUK" onclick="triggerSmartBulkOrder('SELCUK')" class="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-[11px] rounded-lg transition cursor-pointer shrink-0">Selçuk</button>
                    <button type="button" data-depo-btn="ISKOOP" onclick="triggerSmartBulkOrder('ISKOOP')" class="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] rounded-lg transition cursor-pointer shrink-0">İSKOOP</button>
                    <button type="button" data-depo-btn="NEVZAT" onclick="triggerSmartBulkOrder('NEVZAT')" class="px-2 py-1 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-[11px] rounded-lg transition cursor-pointer shrink-0">Nevzat</button>
                    <button type="button" onclick="triggerSmartBulkOrderByRowDepo()" class="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-amber-300 font-black text-[11px] rounded-lg transition cursor-pointer shrink-0" title="Her ürünü satırında seçili olan kendi deposuna gönderir">
                        ✨ Seçili Depoya Dağıt
                    </button>
                </div>
            </div>

            <!-- SAĞA TAŞMAYAN, TAM HİZALI 7 SÜTUNLU SADE TABLO -->
            <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <table class="w-full table-fixed text-left border-collapse text-xs">
                    <thead>
                        <tr class="bg-slate-100 border-b border-slate-200 text-slate-600 text-[10px] uppercase font-extrabold" id="smartOrderTableHeadRow">
                            <th class="py-2.5 px-2 w-[4%] text-center">Seç</th>
                            <th class="py-2.5 px-2.5 w-[25%]">İlaç Adı / Barkod</th>
                            <th class="py-2.5 px-2 w-[11%] text-center">Stok & Bugün</th>
                            <th class="py-2.5 px-2 w-[23%] text-center">Son 6 Aylık Çıkış (Ay-Ay)</th>
                            <th class="py-2.5 px-2 w-[8%] text-center bg-slate-200/50 text-slate-900">6 Ay Top</th>
                            <th class="py-2.5 px-2 w-[11%]">Trend & MF</th>
                            <th class="py-2.5 px-3 w-[18%] text-right bg-indigo-50/50 text-indigo-950">Sipariş Adedi & Depo</th>
                        </tr>
                    </thead>
                    <tbody id="smartOrderTableBody" class="divide-y divide-slate-100">
                        <tr>
                            <td colspan="7" class="py-12 text-center text-slate-400 text-sm">
                                <i class="fa-solid fa-spinner fa-spin text-amber-500 mr-2 text-lg"></i>Eczane otomasyonu 6 aylık çıkış ve stok verileri analiz ediliyor...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ========================================== -->
        <!-- VIEW 2: E-TİCARET & PİYASA FİYAT KIYASLAMA -->
        <!-- ========================================== -->
        <div id="viewMarket" class="hidden space-y-8">
            <!-- Pazaryeri Kıyaslamasının Üstünde: 6 Aylık Çıkış & Toplu Sipariş Planlama Hızlı Geçiş Kartı -->
            <div class="bg-gradient-to-r from-slate-900 via-emerald-950 to-indigo-950 rounded-2xl p-4 text-white shadow-md border border-emerald-700/50 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div class="flex items-center space-x-3.5">
                    <div class="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-amber-300 flex items-center justify-center text-xl shrink-0">
                        <i class="fa-solid fa-chart-column"></i>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <span class="text-xs font-black uppercase tracking-wider text-emerald-300">🌿 Botanik 6 Aylık Çıkış & Akıllı Toplu Sipariş</span>
                            <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30">Stabil / Azalan Uyarılı + Canlı MF</span>
                        </div>
                        <p class="text-xs text-slate-300 mt-0.5">
                            6 aylık çıkış listesini görmek, günlük tahmini siparişi ayarlamak, mevcut MF'leri incelemek ve toplu siparişe aktarmak için tıklayın.
                        </p>
                    </div>
                </div>
                <button type="button" onclick="switchMainView('smart_order')" class="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs shadow-md transition flex items-center space-x-2 shrink-0 cursor-pointer">
                    <i class="fa-solid fa-table-list"></i>
                    <span>📊 6 Aylık Çıkış & Toplu Sipariş Sayfasını Aç</span>
                </button>
            </div>

            <!-- Market Search Box -->
            <div class="max-w-3xl mx-auto mb-8 relative">
                <div class="bg-white p-3 rounded-2xl shadow-lg shadow-indigo-100/60 border border-indigo-200 flex items-center space-x-3 relative z-30">
                    <div class="pl-3 text-indigo-500">
                        <i class="fa-solid fa-basket-shopping text-xl"></i>
                    </div>
                    <input 
                        type="text" 
                        id="marketSearchInput" 
                        placeholder="E-Ticaret İçin Barkod (869...) veya Ürün Adı (Ocean, Solgar, Bioderma, CeraVe)..."
                        class="w-full py-2.5 text-base text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
                        autocomplete="off"
                        onkeydown="if(event.key === 'Enter') handleMarketSearchSubmit()"
                    >
                    <button 
                        id="marketSearchBtn" 
                        onclick="handleMarketSearchSubmit()"
                        class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl text-sm transition-all shadow-md shadow-indigo-200 flex items-center space-x-2 shrink-0 cursor-pointer"
                    >
                        <i class="fa-solid fa-bolt"></i>
                        <span>Piyasayı Tara</span>
                    </button>
                </div>

                <!-- Auto-Suggest Dropdown for Market -->
                <div id="marketSuggestBox" class="hidden absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl border border-slate-200 shadow-2xl z-40 overflow-hidden divide-y divide-slate-100 max-h-96 overflow-y-auto">
                    <!-- Suggestions will be injected here -->
                </div>

                <!-- Market Quick Chips -->
                <div class="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-500">
                    <span class="font-medium">Popüler Ürünler:</span>
                    <button onclick="quickMarketSearch('8697595872413', 'Ocean Alfa Lipoik 200mg')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Ocean Alfa Lipoik 200mg</button>
                    <button onclick="quickMarketSearch('8697595872451', 'Ocean Alfa Lipoik 600mg')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Ocean Alfa Lipoik 600mg</button>
                    <button onclick="quickMarketSearch('8697595870020', 'Ocean Plus 1200mg 50 Kapsül')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Ocean Plus 1200mg</button>
                    <button onclick="quickMarketSearch('Bioderma Sebium', 'Bioderma Sebium')" class="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 rounded-lg border border-indigo-200 text-indigo-700 font-medium transition cursor-pointer">Bioderma Sebium</button>
                    <button onclick="quickMarketSearch('Solgar Alfa Lipoik', 'Solgar Alfa Lipoik')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Solgar Alfa Lipoik</button>
                    <button onclick="quickMarketSearch('CeraVe Nemlendirici Krem', 'CeraVe')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">CeraVe</button>
                </div>
            </div>

            <!-- Loading Spinner State -->
            <div id="marketLoading" class="hidden bg-white p-12 rounded-3xl border border-slate-200 shadow-sm text-center max-w-2xl mx-auto">
                <div class="relative w-16 h-16 mx-auto mb-4">
                    <div class="w-16 h-16 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin"></div>
                    <div class="absolute inset-0 flex items-center justify-center text-indigo-600">
                        <i class="fa-solid fa-shop text-xl"></i>
                    </div>
                </div>
                <h3 class="text-base font-bold text-slate-900 mb-1" id="marketLoadingTitle">9 E-Ticaret Platformu ve Depolar Eşzamanlı Taranıyor...</h3>
                <p class="text-xs text-slate-500 max-w-md mx-auto">Trendyol, Hepsiburada, Sachane, Dermoeczanem, Dermokozmetika, Kırmızıbeyaz, Dermojet, Kozvit ve Daffne canlı fiyatları toplanıyor...</p>
                <div class="flex items-center justify-center gap-2 mt-4 text-[11px] text-slate-400">
                    <span class="w-2 h-2 rounded-full bg-indigo-500 animate-ping"></span>
                    <span>Anti-bot güvenlik bypass aktif</span>
                </div>
            </div>

            <!-- Initial Empty State -->
            <div id="marketEmptyState" class="bg-white p-10 rounded-3xl border border-slate-200 shadow-sm text-center max-w-3xl mx-auto">
                <div class="w-16 h-16 mx-auto mb-4 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-2xl">
                    <i class="fa-solid fa-scale-balanced"></i>
                </div>
                <h3 class="text-lg font-bold text-slate-900 mb-2">E-Ticaret & Perakende Piyasa Fiyat Analizi</h3>
                <p class="text-sm text-slate-500 max-w-xl mx-auto mb-6">
                    Barkod veya ürün adı aratarak 9 büyük perakende e-ticaret platformunun anlık fiyatlarını görün, ecza depolarındaki net alış maliyetiniz ve kâr marjınızla karşılaştırın.
                </p>
                <div class="grid grid-cols-2 sm:grid-cols-5 gap-3 max-w-2xl mx-auto text-xs font-semibold text-slate-700">
                    <div class="p-2.5 rounded-xl bg-orange-50 border border-orange-200 text-orange-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-orange-600"></i> Trendyol</div>
                    <div class="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-amber-600"></i> Hepsiburada</div>
                    <div class="p-2.5 rounded-xl bg-pink-50 border border-pink-200 text-pink-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-pink-600"></i> Sachane</div>
                    <div class="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-emerald-600"></i> Dermoeczanem</div>
                    <div class="p-2.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-indigo-600"></i> Dermokozmetika</div>
                    <div class="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-rose-600"></i> Kırmızıbeyaz</div>
                    <div class="p-2.5 rounded-xl bg-cyan-50 border border-cyan-200 text-cyan-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-cyan-600"></i> Dermojet</div>
                    <div class="p-2.5 rounded-xl bg-purple-50 border border-purple-200 text-purple-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-purple-600"></i> Kozvit</div>
                    <div class="p-2.5 rounded-xl bg-teal-50 border border-teal-200 text-teal-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-teal-600"></i> Daffne</div>
                    <div class="p-2.5 rounded-xl bg-slate-100 border border-slate-300 text-slate-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-truck-ramp-box text-slate-600"></i> 6 Ecza Deposu</div>
                </div>
            </div>

            <!-- Market Results Container -->
            <div id="marketResults" class="hidden space-y-6">
                <!-- Header Title & Info -->
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <div class="flex items-center gap-2 mb-1">
                            <span class="px-2.5 py-0.5 rounded-md text-xs font-bold bg-indigo-100 text-indigo-800" id="marketResBadge">PİYASA RAPORU</span>
                            <span class="text-xs font-mono text-slate-500 font-semibold" id="marketResBarcode"></span>
                        </div>
                        <h2 class="text-xl font-extrabold text-slate-900" id="marketResTitle">Ürün Adı</h2>
                    </div>
                    <div class="flex items-center gap-3">
                        <button onclick="handleMarketSearchSubmit()" class="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1.5 cursor-pointer">
                            <i class="fa-solid fa-rotate-right"></i>
                            <span>Fiyatları Yenile</span>
                        </button>
                    </div>
                </div>

                <!-- Cheaper than Warehouse Warning Alert Banner -->
                <div id="marketCheaperWarning" class="hidden bg-gradient-to-r from-red-600 to-rose-700 text-white p-5 rounded-2xl shadow-lg shadow-red-200 flex items-start gap-4">
                    <div class="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-2xl shrink-0">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                    </div>
                    <div class="flex-1">
                        <h4 class="text-base font-black tracking-wide uppercase">KRİTİK UYARI: İnternet Satış Fiyatı Depo Maliyetinden Daha Düşük!</h4>
                        <p class="text-xs text-red-100 mt-1 leading-relaxed" id="marketCheaperText">
                            Bu ürünün internetteki en ucuz perakende satış fiyatı, eczane ecza deposu net alış maliyetinin altındadır. Piyasada damping veya serbest fiyat rekabeti bulunmaktadır.
                        </p>
                    </div>
                </div>

                <!-- KPI Stat Cards -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <!-- 1. En Ucuz Depo Alışı -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">En Ucuz Depo Alış</span>
                            <span class="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center"><i class="fa-solid fa-truck-ramp-box"></i></span>
                        </div>
                        <div>
                            <div class="text-2xl font-black text-slate-900" id="kpiDepoFiyat">- ₺</div>
                            <div class="text-xs text-slate-500 mt-1 truncate font-medium" id="kpiDepoAdi">-</div>
                        </div>
                    </div>

                    <!-- 2. En Ucuz İnternet Satışı -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">En Ucuz İnternet Satışı</span>
                            <span class="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center"><i class="fa-solid fa-cart-shopping"></i></span>
                        </div>
                        <div>
                            <div class="text-2xl font-black text-indigo-600" id="kpiInternetFiyat">- ₺</div>
                            <div class="text-xs text-slate-500 mt-1 truncate font-medium" id="kpiInternetPlatform">-</div>
                        </div>
                    </div>

                    <!-- 3. Kâr / Marj Analizi -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between" id="kpiKarCard">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">Potansiyel Brüt Kâr</span>
                            <span class="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center"><i class="fa-solid fa-chart-line"></i></span>
                        </div>
                        <div>
                            <div class="text-2xl font-black text-slate-900" id="kpiKarFark">- ₺</div>
                            <div class="text-xs text-slate-500 mt-1 font-medium" id="kpiKarYuzde">Marj: -%</div>
                        </div>
                    </div>

                    <!-- 4. Piyasa Derinliği -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">Piyasa Fiyat Dağılımı</span>
                            <span class="w-7 h-7 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center"><i class="fa-solid fa-scale-balanced"></i></span>
                        </div>
                        <div>
                            <div class="text-xs font-bold text-slate-700 flex justify-between">
                                <span>Ortalama:</span>
                                <span id="kpiOrtalamaFiyat">- ₺</span>
                            </div>
                            <div class="text-xs font-bold text-slate-700 flex justify-between mt-1">
                                <span>En Yüksek:</span>
                                <span id="kpiYuksekFiyat">- ₺</span>
                            </div>
                            <div class="text-[11px] text-slate-400 mt-1 font-medium" id="kpiToplamTeklif">- Teklif</div>
                        </div>
                    </div>
                </div>

                <!-- Main Content Split: Wholesale (Left) vs Retail Offers (Right) -->
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    <!-- LEFT COLUMN: Depo & Pazaryeri Alış Fiyatları (4/12) -->
                    <div class="lg:col-span-4 space-y-4">
                        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                            <div class="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                                <h3 class="font-bold text-sm text-slate-900 flex items-center gap-2">
                                    <i class="fa-solid fa-truck-ramp-box text-emerald-600"></i>
                                    <span>Depo Alış Fiyatları</span>
                                </h3>
                                <span class="text-xs text-slate-500 font-medium" id="depoOzetCount">6 Depo</span>
                            </div>
                            <div class="p-3 divide-y divide-slate-100" id="depoFiyatlariList">
                                <!-- Injected dynamically -->
                            </div>
                        </div>
                    </div>

                    <!-- RIGHT COLUMN: E-Ticaret Perakende Teklifleri (8/12) -->
                    <div class="lg:col-span-8 space-y-4">
                        <!-- Platform Filter Bar -->
                        <div class="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-2 overflow-x-auto" id="platformFilterBar">
                            <!-- Platform chips injected dynamically -->
                        </div>

                        <!-- Retail Offers Grid -->
                        <div class="space-y-3" id="retailOffersList">
                            <!-- Injected dynamically -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>

    <!-- Settings Modal -->
    <div id="settingsModal" style="display: none;" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div class="px-6 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div id="settingsModalIcon" class="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
                        <i class="fa-solid fa-database text-lg"></i>
                    </div>
                    <div>
                        <h3 id="settingsModalTitle" class="text-base font-bold text-white leading-snug">TRIA Eczane Veritabanı (Oracle) Bağlantı & Şifre Ayarları</h3>
                        <p id="settingsModalDesc" class="text-xs text-slate-300">Oracle sunucu IP, port, şema adı ve şifresini buradan girip canlı test edebilirsiniz.</p>
                    </div>
                </div>
                <button onclick="closeSettingsModal()" class="text-slate-400 hover:text-white transition p-1.5 rounded-lg hover:bg-white/10 cursor-pointer">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <!-- Modal Tabs Navigation -->
            <div class="flex border-b border-slate-200 px-6 pt-3 bg-slate-50 gap-2 overflow-x-auto">
                <button type="button" id="tabBtnBotanik" onclick="switchSettingsTab('botanik')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-emerald-600 text-emerald-900 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-leaf text-emerald-600"></i>
                    <span>🌿 Botanik Eczane (MS SQL)</span>
                    <span id="tabBotanikBadge" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">Canlı</span>
                </button>
                <button type="button" id="tabBtnTria" onclick="switchSettingsTab('tria')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-database text-amber-600"></i>
                    <span>⚡ TRIA Eczane (Oracle)</span>
                    <span id="tabTriaBadge" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-600 font-bold">Hazır</span>
                </button>
                <button type="button" id="tabBtnTebeos" onclick="switchSettingsTab('tebeos')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-mortar-pestle text-sky-600"></i>
                    <span>🔷 TEBEOS Eczane (PostgreSQL)</span>
                    <span id="tabTebeosBadge" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-sky-100 text-sky-800 font-bold">Canlı</span>
                </button>
                <button type="button" id="tabBtnDepolar" onclick="switchSettingsTab('depolar')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-truck-ramp-box text-slate-600"></i>
                    <span>🏢 Ecza Depoları & Pazaryeri</span>
                </button>
                <button type="button" id="tabBtnKatalog" onclick="switchSettingsTab('katalog')" class="hidden pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-barcode text-indigo-600"></i>
                    <span>📊 Ürün & Çoklu Barkod Kataloğu</span>
                </button>
                <button type="button" id="tabBtnDermo" onclick="switchSettingsTab('dermo')" class="hidden pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-wand-magic-sparkles text-pink-600"></i>
                    <span>✨ Dermo Barkod Eşleme</span>
                    <span class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-pink-100 text-pink-800 font-bold">Sihirbaz</span>
                </button>
                <button type="button" id="tabBtnGuncelleme" onclick="switchSettingsTab('guncelleme')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-cloud-arrow-down text-cyan-600"></i>
                    <span>🔄 Sürüm & Lisans</span>
                    <span id="tabUpdateBadge" class="hidden ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold">Yeni</span>
                </button>
                <button type="button" id="tabBtnYonetici" onclick="switchSettingsTab('yonetici')" class="ml-auto pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-400 hover:text-slate-800 flex items-center space-x-1.5 transition cursor-pointer shrink-0" title="Yönetici Paneli (Şifre Korumalı)">
                    <i class="fa-solid fa-user-shield text-rose-600"></i>
                    <span>🔒 Yönetici Paneli</span>
                </button>
            </div>

            <!-- Modal Body (Form Grid) -->
            <div class="p-6 max-h-[75vh] overflow-y-auto space-y-6">
                <!-- Eczane Otomasyon Yazılımı Tercihi (Kurulu Eczane Otomasyonu & Değiştirme) -->
                <div class="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-2xl p-4 shadow-sm space-y-3">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div class="flex items-center space-x-2.5">
                            <i class="fa-solid fa-hospital text-emerald-400 text-base"></i>
                            <div>
                                <span class="text-xs font-bold text-white uppercase tracking-wider">Aktif Eczane Otomasyon Sistemi:</span>
                                <span id="activeOtoBannerLabel" class="ml-1.5 text-xs font-black px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">Botanik Eczane (MS SQL)</span>
                            </div>
                        </div>
                        <button type="button" onclick="toggleOtomasyonSelector()" id="btnToggleOtoSelector" class="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white text-[11px] font-bold border border-white/15 transition flex items-center space-x-1.5 cursor-pointer self-start sm:self-auto">
                            <i class="fa-solid fa-sliders text-amber-400 text-[10px]"></i>
                            <span>Otomasyon Sistemini Değiştir</span>
                        </button>
                    </div>
                    <div id="otoSelectorCardsGrid" class="hidden grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-white/10">
                        <!-- Botanik Seçim Kartı -->
                        <div id="otoChoiceCardBotanik" onclick="selectActiveOtomasyon('BOTANIK')" class="p-3.5 rounded-xl border border-white/10 bg-white/5 cursor-pointer transition flex items-center justify-between group hover:bg-white/10">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-lg shadow-sm">
                                    <i class="fa-solid fa-leaf"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-white group-hover:text-emerald-300 transition">🌿 Botanik Eczane</div>
                                    <div class="text-[10px] text-slate-300 font-mono">MS SQL Server</div>
                                </div>
                            </div>
                            <span id="otoChoiceBadgeBotanik" class="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/10 text-slate-400">SEÇ</span>
                        </div>

                        <!-- TRIA Seçim Kartı -->
                        <div id="otoChoiceCardTria" onclick="selectActiveOtomasyon('TRIA')" class="p-3.5 rounded-xl border-2 border-amber-500 bg-amber-500/20 cursor-pointer transition flex items-center justify-between group hover:bg-amber-500/30 shadow-sm">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center text-lg shadow-sm">
                                    <i class="fa-solid fa-database"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-white group-hover:text-amber-300 transition">⚡ TRIA Eczane</div>
                                    <div class="text-[10px] text-slate-300 font-mono">Oracle Database</div>
                                </div>
                            </div>
                            <span id="otoChoiceBadgeTria" class="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-400 text-slate-950">✓ AKTİF SEÇİM</span>
                        </div>

                        <!-- TEBEOS Seçim Kartı -->
                        <div id="otoChoiceCardTebeos" onclick="selectActiveOtomasyon('TEBEOS')" class="p-3.5 rounded-xl border border-white/10 bg-white/5 cursor-pointer transition flex items-center justify-between group hover:bg-white/10">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-lg bg-sky-500 text-white flex items-center justify-center text-lg shadow-sm">
                                    <i class="fa-solid fa-mortar-pestle"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-white group-hover:text-sky-300 transition">🔷 TEBEOS Eczane</div>
                                    <div class="text-[10px] text-slate-300 font-mono">PostgreSQL (5454)</div>
                                </div>
                            </div>
                            <span id="otoChoiceBadgeTebeos" class="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/10 text-slate-400">SEÇ</span>
                        </div>
                    </div>
                    <input type="hidden" id="cfg_active_otomasyon" value="TRIA">
                </div>

                <!-- Tab: Botanik Eczane Veritabanı (MS SQL Server) -->
                <div id="tabContentBotanik" class="space-y-5">
                    <!-- Botanik Header Alert -->
                    <div class="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4 flex items-start space-x-3.5">
                        <div class="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-emerald-200">
                            <i class="fa-solid fa-leaf"></i>
                        </div>
                        <div class="text-xs text-emerald-950 leading-relaxed">
                            <div class="font-bold text-sm text-emerald-900 mb-0.5">Botanik Eczane Otomasyonu (MS SQL Server) Veri Bağlantısı</div>
                            Eczanenizin ana bilgisayarında veya yerel ağında çalışan Botanik MS SQL Server veritabanı bağlantı bilgilerini buradan yapılandırabilirsiniz.
                            Sorgulanan her ilacın güncel raf stoğu, son 6 aylık Nakit/Reçete satışları ve depolardan gelen son alış faturaları (girişleri) anında analiz edilir.
                        </div>
                    </div>

                    <!-- Hızlı Profil & Config'den Otomatik Oku -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                        <div class="text-xs font-bold text-slate-700 flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-bolt text-amber-500"></i><span>Otomatik Algılama & Hızlı Kurulum:</span></span>
                            <span class="text-[11px] text-slate-400 font-normal">Botanik ayarlarını otomatik bulur veya elle girebilirsiniz</span>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button type="button" onclick="autoReadBotanikConfigFile()" class="px-3.5 py-2 rounded-xl bg-white border border-emerald-400 hover:border-emerald-600 hover:bg-emerald-50 text-emerald-800 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-wand-magic-sparkles text-emerald-600"></i>
                                <span>🔍 Botanik Bağlantısını Otomatik Bul (Config Oku)</span>
                            </button>
                            <button type="button" onclick="setBotanikProfile('yerel')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>💻 Bu Bilgisayar / Yerel (.\\\\BOTANIKSQL)</span>
                            </button>
                        </div>
                    </div>

                    <!-- Botanik Bağlantı Parametreleri Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                        <!-- Sunucu / Server / Instance -->
                        <div class="md:col-span-2">
                            <label class="text-xs font-bold text-slate-700 flex items-center space-x-1 mb-1">
                                <i class="fa-solid fa-server text-emerald-600"></i>
                                <span>SQL Server Adı / Instance (Host):</span>
                            </label>
                            <input type="text" id="cfg_botanik_server" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="Örn: .\\\\BOTANIKSQL veya 192.168.1.10\\\\BOTANIKSQL">
                        </div>

                        <!-- Veritabanı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Veritabanı Adı (Database):</label>
                            <input type="text" id="cfg_botanik_db" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="eczane">
                        </div>

                        <!-- Kullanıcı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">SQL Kullanıcı Adı (UID):</label>
                            <input type="text" id="cfg_botanik_user" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="sa">
                        </div>

                        <!-- Şifre -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">SQL Şifresi (PWD):</label>
                            <div class="relative">
                                <input type="password" id="cfg_botanik_pwd" class="w-full text-xs px-3.5 py-2.5 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="••••••••">
                                <button type="button" onclick="togglePasswordVisibility('cfg_botanik_pwd', this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Windows Authentication Checkbox -->
                        <div class="flex items-center space-x-2 pt-6">
                            <input type="checkbox" id="cfg_botanik_trusted" class="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer">
                            <label for="cfg_botanik_trusted" class="text-xs font-bold text-slate-700 cursor-pointer">Windows Kimlik Doğrulama (Trusted Connection)</label>
                        </div>
                    </div>

                    <!-- Canlı Ping & Test Alanı -->
                    <div class="flex items-center justify-between pt-1">
                        <button type="button" id="btnPingBotanik" onclick="pingBotanikConnection()" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-200 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-bolt"></i>
                            <span>🔍 Botanik Bağlantısını Test Et & Ping</span>
                        </button>
                        <span class="text-[11px] text-slate-400">Canlı ping süresini, SQL Server sürümünü ve kayıtlı veri adetlerini doğrular.</span>
                    </div>
                    <div id="botanikPingResult" class="hidden mt-3 p-3.5 rounded-2xl text-xs"></div>
                </div>
                <!-- Tab 1: Depolar & Pazaryerleri -->
                <div id="tabContentDepolar" class="hidden space-y-6">
                    <!-- Info Alert with Active / Passive summary -->
                    <div class="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div class="flex items-start space-x-3">
                            <i class="fa-solid fa-shield-halved text-blue-600 text-lg mt-0.5"></i>
                            <div class="text-xs text-blue-900 leading-relaxed">
                                <strong>Depo Yönetimi & Otomatik Pasiflik:</strong> Çalışmadığınız depoları anahtarından <strong>Pasif</strong> yapabilirsiniz. <u>Kullanıcı adı veya şifresi girilmeyen depolar otomatik olarak devre dışı bırakılır</u> ve karşılaştırmada taranmaz.
                            </div>
                        </div>
                        <div id="depoTabSummaryBadge" class="shrink-0 px-3 py-1.5 rounded-xl bg-blue-100 text-blue-900 text-xs font-bold border border-blue-300">
                            Yükleniyor...
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <!-- 1. Alliance Healthcare Card -->
                        <div id="card_alliance" class="p-4 rounded-2xl border border-sky-100 bg-sky-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-sky-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-sky-800 font-bold text-sm">
                                    <i class="fa-solid fa-truck-medical text-sky-600"></i>
                                    <span>Alliance Healthcare</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Alliance Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_alliance_active" onchange="onDepoActiveToggle('alliance')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-600"></div>
                                    </label>
                                    <span id="badge_alliance_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Eczane Kodu (GLN / Şube)</label>
                                    <input type="text" id="cfg_alliance_pcode" oninput="onDepoCredInput('alliance')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="Eczane / Şube Kodu">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı</label>
                                    <input type="text" id="cfg_alliance_user" oninput="onDepoCredInput('alliance')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_alliance_pwd" oninput="onDepoCredInput('alliance')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_alliance_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 2. Selçuk Ecza Deposu Card -->
                        <div id="card_selcuk" class="p-4 rounded-2xl border border-emerald-100 bg-emerald-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-emerald-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-emerald-800 font-bold text-sm">
                                    <i class="fa-solid fa-building-columns text-emerald-600"></i>
                                    <span>Selçuk Ecza Deposu</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Selçuk Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_selcuk_active" onchange="onDepoActiveToggle('selcuk')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-emerald-600"></div>
                                    </label>
                                    <span id="badge_selcuk_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı (SEL...)</label>
                                    <input type="text" id="cfg_selcuk_user" oninput="onDepoCredInput('selcuk')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono" placeholder="Selçuk WebDepo Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_selcuk_pwd" oninput="onDepoCredInput('selcuk')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_selcuk_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 3. Nevzat Ecza Deposu Card -->
                        <div id="card_nevzat" class="p-4 rounded-2xl border border-orange-100 bg-orange-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-orange-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-orange-800 font-bold text-sm">
                                    <i class="fa-solid fa-truck-ramp-box text-orange-600"></i>
                                    <span>Nevzat Ecza Deposu</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Nevzat Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_nevzat_active" onchange="onDepoActiveToggle('nevzat')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-orange-600"></div>
                                    </label>
                                    <span id="badge_nevzat_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Hesap Kodu</label>
                                    <input type="text" id="cfg_nevzat_account" oninput="onDepoCredInput('nevzat')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="Nevzat Hesap Kodu">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı</label>
                                    <input type="text" id="cfg_nevzat_user" oninput="onDepoCredInput('nevzat')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_nevzat_pwd" oninput="onDepoCredInput('nevzat')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_nevzat_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 4. İSKOOP Card -->
                        <div id="card_iskoop" class="p-4 rounded-2xl border border-red-100 bg-red-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-red-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-red-800 font-bold text-sm">
                                    <i class="fa-solid fa-handshake-angle text-red-600"></i>
                                    <span>İSKOOP (İstanbul Ecza Koop)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="İSKOOP Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_iskoop_active" onchange="onDepoActiveToggle('iskoop')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-red-600"></div>
                                    </label>
                                    <span id="badge_iskoop_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı (i...)</label>
                                    <input type="text" id="cfg_iskoop_user" oninput="onDepoCredInput('iskoop')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-red-500 focus:outline-none bg-white font-mono" placeholder="İSKOOP E-Şube Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_iskoop_pwd" oninput="onDepoCredInput('iskoop')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-red-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_iskoop_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 5. BEK (Bursa Ecza Koop) Card -->
                        <div id="card_bek" class="p-4 rounded-2xl border border-teal-100 bg-teal-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-teal-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-teal-800 font-bold text-sm">
                                    <i class="fa-solid fa-handshake-simple text-teal-600"></i>
                                    <span>BEK (Bursa Eczacılar Kooperatifi)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="BEK Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_bek_active" onchange="onDepoActiveToggle('bek')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-teal-600"></div>
                                    </label>
                                    <span id="badge_bek_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı (b...)</label>
                                    <input type="text" id="cfg_bek_user" oninput="onDepoCredInput('bek')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white font-mono" placeholder="BEK Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_bek_pwd" oninput="onDepoCredInput('bek')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_bek_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 6. Ecza1 Pazaryeri Card -->
                        <div id="card_ecza1" class="p-4 rounded-2xl border border-purple-100 bg-purple-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-purple-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-purple-800 font-bold text-sm">
                                    <i class="fa-solid fa-cart-shopping text-purple-600"></i>
                                    <span>Ecza1 Pazaryeri</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Ecza1 Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_ecza1_active" onchange="onDepoActiveToggle('ecza1')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-purple-600"></div>
                                    </label>
                                    <span id="badge_ecza1_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / E-Posta</label>
                                    <input type="text" id="cfg_ecza1_user" oninput="onDepoCredInput('ecza1')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı veya E-Posta">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_ecza1_pwd" oninput="onDepoCredInput('ecza1')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_ecza1_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 7. Farmazon Pazaryeri Card -->
                        <div id="card_farmazon" class="p-4 rounded-2xl border border-amber-100 bg-amber-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-amber-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-amber-800 font-bold text-sm">
                                    <i class="fa-solid fa-store text-amber-600"></i>
                                    <span>Farmazon Pazaryeri</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Farmazon Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_farmazon_active" onchange="onDepoActiveToggle('farmazon')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-amber-600"></div>
                                    </label>
                                    <span id="badge_farmazon_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / Telefon / E-Posta</label>
                                    <input type="text" id="cfg_farmazon_user" oninput="onDepoCredInput('farmazon')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı veya E-Posta">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_farmazon_pwd" oninput="onDepoCredInput('farmazon')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_farmazon_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 8. DNA Ecza Deposu Card -->
                        <div id="card_dna" class="p-4 rounded-2xl border border-cyan-100 bg-cyan-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-cyan-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-cyan-800 font-bold text-sm">
                                    <i class="fa-solid fa-dna text-cyan-600"></i>
                                    <span>DNA Ecza Deposu</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="DNA Ecza Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_dna_active" onchange="onDepoActiveToggle('dna')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-cyan-600"></div>
                                    </label>
                                    <span id="badge_dna_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / E-Posta</label>
                                    <input type="text" id="cfg_dna_user" oninput="onDepoCredInput('dna')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-cyan-500 focus:outline-none bg-white font-mono" placeholder="DNA Ecza Kullanıcı Adı / E-Posta">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_dna_pwd" oninput="onDepoCredInput('dna')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-cyan-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_dna_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 9. Eczatrend Ortak Alım Grubu Card -->
                        <div id="card_eczatrend" class="p-4 rounded-2xl border border-orange-100 bg-orange-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-orange-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-orange-900 font-bold text-sm">
                                    <i class="fa-solid fa-people-group text-orange-600"></i>
                                    <span>Eczatrend (Alım Grubu)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Eczatrend Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_eczatrend_active" onchange="onDepoActiveToggle('eczatrend')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-orange-600"></div>
                                    </label>
                                    <span id="badge_eczatrend_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / E-Posta</label>
                                    <input type="text" id="cfg_eczatrend_user" oninput="onDepoCredInput('eczatrend')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="Eczatrend E-Posta / Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_eczatrend_pwd" oninput="onDepoCredInput('eczatrend')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_eczatrend_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 10. EczaneTakas Pazaryeri Card -->
                        <div id="card_eczanetakas" class="p-4 rounded-2xl border border-sky-100 bg-sky-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-sky-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-sky-900 font-bold text-sm">
                                    <i class="fa-solid fa-arrow-right-arrow-left text-sky-600"></i>
                                    <span>EczaneTakas (Pazaryeri)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="EczaneTakas Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_eczanetakas_active" onchange="onDepoActiveToggle('eczanetakas')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-600"></div>
                                    </label>
                                    <span id="badge_eczanetakas_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">E-Posta / Kullanıcı Adı</label>
                                    <input type="text" id="cfg_eczanetakas_user" oninput="onDepoCredInput('eczanetakas')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="EczaneTakas E-Posta / Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_eczanetakas_pwd" oninput="onDepoCredInput('eczanetakas')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_eczanetakas_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 2: Tria Eczane Veritabanı (Oracle) -->
                <div id="tabContentTria" class="space-y-5">
                    <div class="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-4 flex items-start space-x-3.5">
                        <div class="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-amber-200">
                            <i class="fa-solid fa-database"></i>
                        </div>
                        <div class="text-xs text-amber-950 leading-relaxed">
                            <div class="font-bold text-sm text-amber-900 mb-0.5">TRIA Eczane Otomasyonu (Oracle) Veri Bağlantısı</div>
                            Eczanenizin ana bilgisayarında veya yerel ağında çalışan TRIA Oracle bağlantı bilgilerini otomatik bulabilir veya elle girebilirsiniz.
                            Bu sayede sorgulanan her ilacın gerçek raf stoğu ve son 6 aylık Nakit/Reçete satış hızı anında analiz edilir.
                        </div>
                    </div>

                    <!-- Otomatik Algılama & Hızlı Kurulum -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                        <div class="text-xs font-bold text-slate-700 flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-bolt text-amber-500"></i><span>Otomatik Algılama & Hızlı Bağlantı:</span></span>
                            <span class="text-[11px] text-slate-400 font-normal">Ağdaki TRIA sunucusunu ve eczane şemasını otomatik bulur</span>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button type="button" onclick="discoverTriaHost()" class="px-3.5 py-2 rounded-xl bg-white border border-amber-400 hover:border-amber-600 hover:bg-amber-50 text-amber-900 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-wand-magic-sparkles text-amber-600"></i>
                                <span>🌐 Ağda TRIA Sunucusunu & Şemasını Otomatik Bul</span>
                            </button>
                            <button type="button" onclick="loadAvailableSchemas()" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-amber-500 hover:text-amber-800 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-list-check text-amber-600"></i>
                                <span>📋 Sunucudaki Eczane Şemalarını Listele</span>
                            </button>
                            <button type="button" onclick="setTriaProfile('yerel')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>💻 Bu Bilgisayar / Yerel (127.0.0.1)</span>
                            </button>
                        </div>
                    </div>

                    <!-- Tria Bağlantı Parametreleri Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                        <!-- Host + Otomatik Bul Butonu -->
                        <div class="md:col-span-2">
                            <div class="flex items-center justify-between mb-1">
                                <label class="text-xs font-bold text-slate-700 flex items-center space-x-1">
                                    <i class="fa-solid fa-network-wired text-indigo-600"></i>
                                    <span>TRIA Sunucu IP (Host):</span>
                                </label>
                                <button type="button" onclick="discoverTriaHost()" id="btnDiscoverHost" class="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 transition flex items-center space-x-1 cursor-pointer">
                                    <i class="fa-solid fa-globe"></i>
                                    <span>🌐 Ağda Otomatik Bul</span>
                                </button>
                            </div>
                            <input type="text" id="cfg_tria_host" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="Örn: 127.0.0.1 veya Ana Bilgisayar IP Adresi">
                            <div id="discoverResult" class="hidden text-[11px] mt-1 text-indigo-600 font-medium"></div>
                        </div>

                        <!-- Port -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Oracle Port:</label>
                            <input type="text" id="cfg_tria_port" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="1521">
                        </div>

                        <!-- SID / Servis -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Oracle SID / Servis:</label>
                            <input type="text" id="cfg_tria_sid" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="ORCL">
                        </div>

                        <!-- Şema / Kullanıcı Adı + Şemaları Listele Butonu -->
                        <div class="md:col-span-2">
                            <div class="flex items-center justify-between mb-1">
                                <label class="text-xs font-bold text-slate-700 flex items-center space-x-1">
                                    <i class="fa-solid fa-user-gear text-amber-600"></i>
                                    <span>TRIA Kullanıcı Adı (Eczane Şeması):</span>
                                </label>
                                <button type="button" onclick="loadAvailableSchemas()" id="btnListSchemas" class="text-[11px] font-bold text-amber-700 hover:text-amber-900 transition flex items-center space-x-1 cursor-pointer">
                                    <i class="fa-solid fa-list-check"></i>
                                    <span>📋 Eczane Şemalarını Listele</span>
                                </button>
                            </div>
                            <input type="text" id="cfg_tria_user" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-slate-50 font-mono font-bold uppercase" placeholder="Örn: ECZANE ŞEMA ADI">
                            <!-- Dinamik Şema Rozetleri Listesi -->
                            <div id="schemaListContainer" class="hidden mt-2 p-2.5 bg-amber-50/70 border border-amber-200 rounded-xl text-xs">
                                <div class="text-[11px] font-bold text-amber-900 mb-1.5 flex items-center space-x-1">
                                    <i class="fa-solid fa-server"></i>
                                    <span>Veritabanında Bulunan Eczane Şemaları (Tıklayarak Seçin):</span>
                                </div>
                                <div id="schemaPills" class="flex flex-wrap gap-1.5"></div>
                            </div>
                        </div>

                        <!-- Şifre -->
                        <div class="md:col-span-2">
                            <label class="text-xs font-bold text-slate-700 block mb-1">TRIA Oracle Şifresi:</label>
                            <div class="relative">
                                <input type="password" id="cfg_tria_pwd" class="w-full text-xs px-3.5 py-2.5 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="••••••••">
                                <button type="button" onclick="togglePasswordVisibility('cfg_tria_pwd', this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Bilgilendirme Kartı -->
                    <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-start space-x-3">
                        <i class="fa-solid fa-lightbulb text-emerald-600 text-lg mt-0.5"></i>
                        <div class="text-xs text-emerald-900 leading-relaxed">
                            <strong>💡 Otomatik Şema & Sunucu Bulma:</strong><br>
                            <strong>'Ağda TRIA Sunucusunu & Şemasını Otomatik Bul'</strong> veya <strong>'Eczane Şemalarını Listele'</strong> butonuna basarak Oracle sunucunuzdaki aktif eczane şemasını tek tıkla tespit edebilir ya da kendi TRIA kullanıcı adı/şifrenizi elle girebilirsiniz.
                        </div>
                    </div>

                    <!-- Canlı Ping & Test Alanı -->
                    <div class="flex items-center justify-between pt-1">
                        <button type="button" id="btnPingTria" onclick="pingTriaConnection()" class="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-xs font-bold shadow-md shadow-amber-200 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-bolt"></i>
                            <span>🔍 Bağlantıyı Test Et & Ping</span>
                        </button>
                        <span class="text-[11px] text-slate-400">Canlı ping süresini, Oracle sürümünü ve kayıtlı veri adetlerini doğrular.</span>
                    </div>
                    <div id="triaPingResult" class="hidden mt-3 p-3.5 rounded-2xl text-xs"></div>
                </div>

                <!-- Tab: TEBEOS Eczane Veritabanı (PostgreSQL - Port 5454) -->
                <div id="tabContentTebeos" class="hidden space-y-5">
                    <!-- TEBEOS Header Alert -->
                    <div class="bg-gradient-to-r from-sky-50 to-cyan-50 border border-sky-200 rounded-2xl p-4 flex items-start space-x-3.5">
                        <div class="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-sky-200">
                            <i class="fa-solid fa-mortar-pestle"></i>
                        </div>
                        <div class="text-xs text-sky-950 leading-relaxed">
                            <div class="font-bold text-sm text-sky-900 mb-0.5">TEBEOS Eczane Otomasyonu (PostgreSQL) Veri Bağlantısı</div>
                            Türk Eczacıları Birliği TEBEOS otomasyonunun PostgreSQL veritabanına (varsayılan port: <strong>5454</strong>) doğrudan bağlanır.
                            Sorgulanan her ilacın gerçek raf stoğu, son 6 aylık Reçeteli/Elden çıkışları, son depo alış faturaları ve muadil stokları anında analiz edilir.
                        </div>
                    </div>

                    <!-- Hızlı Profil & Otomatik Bul -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                        <div class="text-xs font-bold text-slate-700 flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-bolt text-sky-500"></i><span>Otomatik Algılama & Hızlı Bağlantı:</span></span>
                            <span class="text-[11px] text-slate-400 font-normal">Ağdaki TEBEOS sunucusunu otomatik bulur veya elle girebilirsiniz</span>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button type="button" onclick="discoverTebeosHost()" id="btnDiscoverTebeos" class="px-3.5 py-2 rounded-xl bg-white border border-sky-400 hover:border-sky-600 hover:bg-sky-50 text-sky-800 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-radar text-sky-600"></i>
                                <span>🌐 Ağda TEBEOS Sunucusunu Otomatik Bul (Port 5454)</span>
                            </button>
                            <button type="button" onclick="setTebeosProfile('yerel')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-sky-500 hover:text-sky-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>💻 Bu Bilgisayar / Yerel (127.0.0.1:5454)</span>
                            </button>
                        </div>
                        <div id="tebeosDiscoverResult" class="hidden text-[11px] mt-1 text-sky-700 font-medium"></div>
                    </div>

                    <!-- TEBEOS Bağlantı Parametreleri Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                        <!-- Host -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 flex items-center space-x-1 mb-1">
                                <i class="fa-solid fa-server text-sky-600"></i>
                                <span>TEBEOS Sunucu IP (Host):</span>
                            </label>
                            <input type="text" id="cfg_tebeos_host" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="Örn: 127.0.0.1 veya Ana Bilgisayar IP Adresi">
                        </div>

                        <!-- Port -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">PostgreSQL Port:</label>
                            <input type="text" id="cfg_tebeos_port" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="5454">
                        </div>

                        <!-- Veritabanı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Veritabanı Adı (Database):</label>
                            <input type="text" id="cfg_tebeos_db" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="tebeos_db">
                        </div>

                        <!-- Kullanıcı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">PostgreSQL Kullanıcı Adı:</label>
                            <input type="text" id="cfg_tebeos_user" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="tebeos">
                        </div>

                        <!-- Şifre -->
                        <div class="md:col-span-2">
                            <label class="text-xs font-bold text-slate-700 block mb-1">PostgreSQL Şifresi:</label>
                            <div class="relative">
                                <input type="password" id="cfg_tebeos_pwd" class="w-full text-xs px-3.5 py-2.5 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="••••••••">
                                <button type="button" onclick="togglePasswordVisibility('cfg_tebeos_pwd', this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Canlı Ping & Test Alanı -->
                    <div class="flex items-center justify-between pt-1">
                        <button type="button" id="btnPingTebeos" onclick="pingTebeosConnection()" class="px-5 py-2.5 bg-gradient-to-r from-sky-600 to-cyan-600 hover:from-sky-700 hover:to-cyan-700 text-white rounded-xl text-xs font-bold shadow-md shadow-sky-200 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-bolt"></i>
                            <span>🔍 TEBEOS Bağlantısını Test Et & Ping</span>
                        </button>
                        <span class="text-[11px] text-slate-400">Canlı ping süresini, PostgreSQL sürümünü ve kayıtlı veri adetlerini doğrular.</span>
                    </div>
                    <div id="tebeosPingResult" class="hidden mt-3 p-3.5 rounded-2xl text-xs"></div>
                </div>

                <!-- Tab: Otomatik Güncelleme & Sürüm / Lisans Yönetimi (Kullanıcı Görünümü) -->
                <div id="tabContentGuncelleme" class="hidden space-y-6">
                    <!-- Sürüm Bilgi Kartı -->
                    <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/60 rounded-2xl p-6 text-white shadow-md">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div class="flex items-center space-x-4">
                                <div class="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-2xl text-cyan-300 shadow-md">
                                    <i class="fa-solid fa-cloud-arrow-down"></i>
                                </div>
                                <div>
                                    <div class="flex items-center space-x-2">
                                        <h4 class="text-lg font-black text-white" id="updateLocalVersionTitle">Farma Radar v1.3.5</h4>
                                        <span class="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">Kararlı Sürüm</span>
                                    </div>
                                    <p class="text-xs text-slate-300 mt-1">Farma Radar Eczane Otomatik Güncelleme & Dağıtım Ağı</p>
                                    <p class="text-[11px] text-slate-400 font-mono mt-0.5" id="updateBuildDateText">Son Derleme: 2026-10-24</p>
                                </div>
                            </div>

                            <div class="flex flex-wrap items-center gap-2">
                                <button type="button" onclick="checkAppUpdate(true)" id="btnCheckUpdateNow" class="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold rounded-xl transition shadow-md shadow-cyan-900/40 flex items-center gap-2 cursor-pointer">
                                    <i class="fa-solid fa-arrows-rotate" id="checkUpdateIcon"></i>
                                    <span>Güncellemeleri Denetle</span>
                                </button>
                                <button type="button" onclick="restartAppServer()" class="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-bold rounded-xl transition border border-white/15 flex items-center gap-1.5 cursor-pointer" title="Sunucuyu yeniden başlatır">
                                    <i class="fa-solid fa-power-off text-amber-400"></i>
                                    <span>Yeniden Başlat</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Güncelleme Durum & Sonuç Kartı -->
                    <div id="updateStatusCard" class="hidden p-5 rounded-2xl border transition-all">
                        <!-- JS ile güncellenecek -->
                    </div>

                    <!-- Kurumsal Lisans & Abonelik Yönetimi -->
                    <div class="bg-white border-2 border-indigo-100 rounded-2xl p-5 space-y-4 shadow-xs">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600 text-lg">
                                    <i class="fa-solid fa-key"></i>
                                </div>
                                <div>
                                    <div class="flex items-center gap-2">
                                        <h5 class="text-sm font-black text-slate-900" id="licPharmacyTitle">Eczane Kurumsal Lisansı</h5>
                                        <span id="licStatusBadge" class="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">AKTİF</span>
                                    </div>
                                    <p class="text-[11px] text-slate-500 mt-0.5">Bu Bilgisayar Donanım Kimliği (HWID): <strong id="licMyHwid" class="font-mono text-indigo-700 select-all">----</strong></p>
                                </div>
                            </div>
                            <div class="text-right text-xs">
                                <div class="text-slate-500">Bitiş Tarihi: <strong id="licExpiresAt" class="text-slate-800 font-mono">--</strong></div>
                                <div class="text-[11px] text-emerald-700 font-bold" id="licDaysLeftText">-- gün kaldı</div>
                            </div>
                        </div>

                        <div class="space-y-2">
                            <div class="flex items-center justify-between">
                                <label class="block text-xs font-bold text-slate-700">Lisans Anahtarı (FR-... / EDP-...)</label>
                                <span id="licRemoteCheckedAt" class="text-[10px] text-slate-400 font-mono"></span>
                            </div>
                            <div class="flex flex-col sm:flex-row gap-2">
                                <input type="text" id="licKeyInput" placeholder="FR-... veya EDP-..." class="flex-1 text-xs font-mono p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white focus:outline-none focus:border-indigo-500">
                                <button type="button" onclick="activateNewLicense()" id="btnActivateLic" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition shadow-xs cursor-pointer shrink-0 flex items-center justify-center gap-1.5">
                                    <i class="fa-solid fa-shield-check"></i>
                                    <span>Lisansı Doğrula & Kaydet</span>
                                </button>
                                <button type="button" onclick="syncLicenseWithCloud(true)" id="btnSyncLicCloud" class="px-3.5 py-2.5 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold rounded-xl transition cursor-pointer shrink-0 flex items-center justify-center gap-1.5" title="Yönetici panelinden süreniz uzatıldıysa yeni anahtar girmeden online güncelleyin">
                                    <i class="fa-solid fa-cloud-arrow-down" id="syncLicCloudIcon"></i>
                                    <span>Online Kontrol Et</span>
                                </button>
                            </div>
                            <div id="licFeedbackMsg" class="hidden text-xs font-semibold p-2.5 rounded-xl"></div>
                        </div>
                    </div>
                </div>

                <!-- Tab: Şifre Korumalı Yönetici Paneli (GitHub Adresi, Kart Birleştirme, Katalog & Canlı Dağıtım) -->
                <div id="tabContentYonetici" class="hidden space-y-6">
                    <!-- Kilit Ekranı (Şifre Girişi) -->
                    <div id="adminSettingsLockBox" class="max-w-lg mx-auto my-6 bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 text-white rounded-3xl p-7 border border-rose-500/30 shadow-xl space-y-5">
                        <div class="flex items-center space-x-4">
                            <div class="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-400/40 flex items-center justify-center text-2xl text-rose-400 shrink-0 shadow-md">
                                <i class="fa-solid fa-user-shield"></i>
                            </div>
                            <div>
                                <span class="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-400/30">YETKİLİ ERİŞİMİ</span>
                                <h4 class="text-base font-black text-white mt-1">Sistem Yönetici Paneli</h4>
                                <p class="text-xs text-slate-300 mt-0.5">Bu bölümdeki gelişmiş sistem araçları son kullanıcıya kapalıdır.</p>
                            </div>
                        </div>

                        <div class="bg-white/5 border border-white/10 rounded-2xl p-3.5 text-[11px] text-slate-300 space-y-1.5 leading-relaxed">
                            <div class="font-bold text-amber-300 flex items-center gap-1.5">
                                <i class="fa-solid fa-screwdriver-wrench text-xs"></i>
                                <span>Bu Panelde Yer Alan Yönetici Araçları:</span>
                            </div>
                            <div>• <strong>Botanik Kart Birleştirme & Dermo/OTC Barkod Onarım Sihirbazı</strong></div>
                            <div>• <strong>Ürün Kataloğu & Botanik / TRIA / Excel Toplu Aktarım Merkezi</strong></div>
                            <div>• <strong>GitHub Manifest Adresi & Canlı Sürüm Yayınlama Portalı</strong></div>
                        </div>

                        <div class="space-y-2">
                            <label class="block text-xs font-bold text-slate-200">Yönetici Şifresi:</label>
                            <div class="flex gap-2">
                                <div class="relative flex-1">
                                    <input type="password" id="adminSettingsPwdInput" onkeydown="if(event.key==='Enter'){event.preventDefault();unlockAdminSettingsPanel();}" placeholder="Yönetici şifresini giriniz..." class="w-full text-xs font-mono px-3.5 py-2.5 pr-10 rounded-xl bg-slate-950/90 border border-slate-700 text-white focus:outline-none focus:border-rose-400">
                                    <button type="button" onclick="togglePasswordVisibility('adminSettingsPwdInput', this)" class="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200 text-xs cursor-pointer">
                                        <i class="fa-solid fa-eye"></i>
                                    </button>
                                </div>
                                <button type="button" onclick="unlockAdminSettingsPanel()" class="px-5 py-2.5 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white text-xs font-black rounded-xl shadow-lg shadow-rose-900/40 transition flex items-center gap-2 cursor-pointer shrink-0">
                                    <i class="fa-solid fa-unlock-keyhole"></i>
                                    <span>Paneli Aç</span>
                                </button>
                            </div>
                            <div id="adminSettingsLockError" class="hidden text-xs font-bold text-rose-400 pt-1"></div>
                        </div>
                    </div>

                    <!-- Kilidi Açılmış Yönetici İçeriği -->
                    <div id="adminSettingsUnlockedArea" class="hidden space-y-6">
                        <!-- Yönetici Alt Sekme & Kısayol Barı -->
                        <div class="bg-slate-900 text-white p-3.5 rounded-2xl border border-slate-700 flex flex-wrap items-center justify-between gap-3">
                            <div class="flex flex-wrap items-center gap-2">
                                <button type="button" id="adminSubBtnDermo" onclick="switchAdminSubTab('dermo')" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-pink-600 text-white shadow-sm transition flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-wand-magic-sparkles"></i>
                                    <span>✨ Botanik Kart Birleştirme & Barkod Eşleme</span>
                                </button>
                                <button type="button" id="adminSubBtnKatalog" onclick="switchAdminSubTab('katalog')" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 transition flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-barcode"></i>
                                    <span>📊 Katalog & Otomasyon Aktarımı</span>
                                </button>
                                <button type="button" id="adminSubBtnGithub" onclick="switchAdminSubTab('github')" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 transition flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-brands fa-github"></i>
                                    <span>🌐 GitHub Adresi & Canlı Yayınlama</span>
                                </button>
                            </div>
                            <div class="flex items-center gap-2">
                                <a href="http://127.0.0.1:8095" target="_blank" class="px-3 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition flex items-center gap-1.5 shadow-sm">
                                    <i class="fa-solid fa-key"></i>
                                    <span>Lisans CRM Paneli (:8095)</span>
                                </a>
                                <button type="button" onclick="lockAdminSettingsPanel()" class="px-3 py-2 rounded-xl text-xs font-bold bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition flex items-center gap-1.5 cursor-pointer" title="Yönetici panelini tekrar şifrele">
                                    <i class="fa-solid fa-lock"></i>
                                    <span>Kilitle</span>
                                </button>
                            </div>
                        </div>

                        <!-- Alt Sekme 1: Dermo Barkod Onarım & Kart Birleştirme Sihirbazı -->
                        <div id="tabContentDermo" class="space-y-6">
                            <!-- Üst Bilgi Kutusu -->
                            <div class="bg-gradient-to-r from-pink-50 via-rose-50 to-amber-50 border border-pink-200 rounded-2xl p-5 shadow-xs">
                                <div class="flex items-start space-x-3.5">
                                    <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-600 to-rose-500 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-pink-200">
                                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                                    </div>
                                    <div class="space-y-1">
                                        <h4 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                                            <span>🌿 Botanik Dermo & OTC Kart Birleştirme / Barkod Onarım Sihirbazı</span>
                                            <span class="text-[10px] bg-pink-100 text-pink-800 font-extrabold px-2 py-0.5 rounded-full border border-pink-200">Sıfır Riskli</span>
                                        </h4>
                                        <p class="text-xs text-slate-600 leading-relaxed">
                                            Botanik veritabanınızda elden sahte barkodla (<code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">869922...</code>, <code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">869000...</code>), harfli veya distribütörün geçici promosyon etiketleriyle (<code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">VTR...</code>, <code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">ÖZEL FİYAT</code>) açılmış kartları tarar ve gerçek barkodlarıyla birleştirir.
                                        </p>
                                        <p class="text-[11px] text-emerald-800 font-medium pt-1 flex items-center gap-1.5">
                                            <i class="fa-solid fa-shield-check text-emerald-600 text-sm"></i>
                                            <span><strong>Güvenlik Garantisi:</strong> Bu işlem Botanik'teki mevcut hiçbir barkodunuzu veya ürününüzü <strong>silmez</strong>. Orijinal üretici EAN barkodunu Botanik'e <strong>ikincil barkod olarak</strong> ekler.</span>
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <!-- Filtreler ve Tarama Barı -->
                            <div class="p-5 rounded-2xl border border-slate-200 bg-white space-y-4 shadow-2xs">
                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-700 mb-1">Marka Filtresi:</label>
                                        <select id="dermoBrandSelect" class="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:outline-none focus:border-pink-500">
                                            <option value="">Tüm Popüler Markalar (La Roche, Bioderma, CeraVe...)</option>
                                            <option value="LA ROCHE">La Roche-Posay</option>
                                            <option value="BIODERMA">Bioderma (Naos)</option>
                                            <option value="CERAVE">CeraVe</option>
                                            <option value="AVENE">Avene (Pierre Fabre)</option>
                                            <option value="VICHY">Vichy</option>
                                            <option value="SOLGAR">Solgar (OTC)</option>
                                            <option value="OCEAN">Ocean (Orzax)</option>
                                            <option value="BEPANTHOL">Bepanthol</option>
                                            <option value="DUCRAY">Ducray</option>
                                            <option value="CAUDALIE">Caudalie</option>
                                            <option value="MUSTELA">Mustela</option>
                                            <option value="ISDIN">ISDIN</option>
                                            <option value="SVR">SVR</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-700 mb-1">İnceleme Limiti:</label>
                                        <select id="dermoLimitSelect" class="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:outline-none focus:border-pink-500">
                                            <option value="30">İlk 30 Hatalı Kart</option>
                                            <option value="50" selected>İlk 50 Hatalı Kart</option>
                                            <option value="100">İlk 100 Hatalı Kart</option>
                                            <option value="150">İlk 150 Hatalı Kart</option>
                                        </select>
                                    </div>
                                    <div class="flex items-end">
                                        <button type="button" onclick="runDermoAudit()" id="btnRunDermoAudit" class="w-full py-2.5 px-4 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white text-xs font-bold rounded-xl transition shadow-md shadow-pink-200 flex items-center justify-center gap-2 cursor-pointer">
                                            <i class="fa-solid fa-magnifying-glass-arrow-right"></i>
                                            <span>Hatalı Barkodları Tara & Eşleştir</span>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Yükleniyor Göstergesi -->
                            <div id="dermoLoading" class="hidden text-center py-10 bg-white rounded-2xl border border-slate-200">
                                <div class="inline-block animate-spin rounded-full h-8 w-8 border-3 border-pink-500 border-t-transparent"></div>
                                <p class="mt-3 text-xs font-bold text-slate-700">Botanik veritabanı taranıyor ve uluslararası barkodlar eşleştiriliyor...</p>
                                <p class="text-[11px] text-slate-400 mt-0.5">Uluslararası katalog havuzuyla karşılaştırılıyor</p>
                            </div>

                            <!-- Sonuçlar ve Eşleme Tablosu -->
                            <div id="dermoResultsContainer" class="hidden space-y-4">
                                <!-- Özet Metrikler ve Toplu Aksiyon Barı -->
                                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-xl bg-slate-900 text-white shadow-sm">
                                    <div class="flex items-center space-x-4 text-xs">
                                        <div>
                                            <span class="text-slate-400">Taranan Kart:</span>
                                            <span class="font-black text-white ml-1" id="dermoStatScanned">0</span>
                                        </div>
                                        <div class="w-px h-4 bg-slate-700"></div>
                                        <div>
                                            <span class="text-slate-400">Eşleşen Gerçek EAN:</span>
                                            <span class="font-black text-emerald-400 ml-1" id="dermoStatMatched">0</span>
                                        </div>
                                        <div class="w-px h-4 bg-slate-700"></div>
                                        <div>
                                            <span class="text-slate-400">Süre:</span>
                                            <span class="font-mono text-slate-300 ml-1" id="dermoStatElapsed">0s</span>
                                        </div>
                                    </div>
                                    <div class="flex items-center space-x-3 w-full sm:w-auto justify-end">
                                        <label class="inline-flex items-center space-x-1.5 text-xs text-slate-300 cursor-pointer select-none">
                                            <input type="checkbox" id="dermoMasterCheck" onchange="toggleAllDermoCheckboxes(this)" checked class="rounded text-pink-600 focus:ring-0 w-4 h-4 cursor-pointer">
                                            <span>Tümünü Seç</span>
                                        </label>
                                        <button type="button" onclick="applyDermoSync()" id="btnApplyDermoSync" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition shadow-md shadow-emerald-900/40 flex items-center gap-1.5 cursor-pointer">
                                            <i class="fa-solid fa-floppy-disk"></i>
                                            <span>Seçilenleri Botanik'e Ekle</span>
                                        </button>
                                    </div>
                                </div>

                                <!-- Önizleme Tablosu -->
                                <div class="border border-slate-200 rounded-2xl bg-white overflow-hidden shadow-2xs">
                                    <div class="max-h-96 overflow-y-auto">
                                        <table class="w-full text-left text-xs divide-y divide-slate-100">
                                            <thead class="bg-slate-50 text-slate-600 font-bold sticky top-0 z-10 text-[11px] uppercase tracking-wider">
                                                <tr>
                                                    <th class="py-2.5 px-3 w-10 text-center">Seç</th>
                                                    <th class="py-2.5 px-3">Botanik Ürün Kartı</th>
                                                    <th class="py-2.5 px-3">Mevcut Kod (Hatalı/Geçici)</th>
                                                    <th class="py-2.5 px-3">Bulunan Gerçek EAN (Eklenecek)</th>
                                                    <th class="py-2.5 px-3">Katalog Eşleşmesi</th>
                                                    <th class="py-2.5 px-3 text-center">Durum</th>
                                                </tr>
                                            </thead>
                                            <tbody id="dermoAuditTableBody" class="divide-y divide-slate-100">
                                                <!-- Dinamik satırlar -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- Geri Bildirim Alanı -->
                            <div id="dermoSyncFeedback" class="hidden p-3.5 rounded-xl text-xs font-semibold"></div>
                        </div>

                        <!-- Alt Sekme 2: Ürün Kataloğu & Excel / Otomasyon Aktarımı -->
                        <div id="tabContentKatalog" class="hidden space-y-6">
                            <div class="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-2xl p-5">
                                <div class="flex items-center justify-between mb-3">
                                    <h4 class="font-bold text-sm text-indigo-900 flex items-center gap-2">
                                        <i class="fa-solid fa-layer-group text-indigo-600"></i>
                                        <span>Katalog ve Barkod İstatistikleri</span>
                                    </h4>
                                    <span class="text-xs bg-indigo-100 text-indigo-800 px-2.5 py-1 rounded-full font-bold">1-to-N Çoklu Barkod</span>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
                                    <div class="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                                        <div class="text-[11px] text-slate-500">Tekil Ürün Sayısı</div>
                                        <div class="text-xl font-black text-slate-800 mt-1" id="catStatProducts">--</div>
                                        <div class="text-[10px] text-slate-400">Katalog & Otomasyon & OTC</div>
                                    </div>
                                    <div class="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                                        <div class="text-[11px] text-slate-500">Toplam Kayıtlı Barkod</div>
                                        <div class="text-xl font-black text-indigo-700 mt-1" id="catStatBarcodes">--</div>
                                        <div class="text-[10px] text-indigo-500 font-medium">EAN-13 & Orijinal Barkodlar</div>
                                    </div>
                                    <div class="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                                        <div class="text-[11px] text-slate-500">Alternatif / Çoklu Barkod</div>
                                        <div class="text-xl font-black text-purple-700 mt-1" id="catStatSecondary">--</div>
                                        <div class="text-[10px] text-purple-500 font-medium">Bir ürüne bağlı ikincil kodlar</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Aksiyon 1: Botanik Senkronizasyon -->
                            <div id="syncCardBotanik" class="p-5 rounded-2xl border border-emerald-200 bg-emerald-50/30 space-y-3">
                                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h5 class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                                            <i class="fa-solid fa-leaf text-emerald-600"></i>
                                            <span>Botanik MS SQL Otomatik Senkronizasyonu</span>
                                        </h5>
                                        <p class="text-xs text-slate-500">Eczanenizin Botanik programındaki tüm kayıtlı ürünleri ve barkodlarını kataloğa anında aktarır.</p>
                                    </div>
                                    <button type="button" onclick="syncBotanikCatalog()" id="btnSyncBotanikCat" class="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0">
                                        <i class="fa-solid fa-rotate"></i>
                                        <span>Botanik'ten Şimdi Güncelle</span>
                                    </button>
                                </div>
                                <div id="botanikSyncStatus" class="hidden text-xs font-semibold p-3 rounded-xl"></div>
                            </div>

                            <!-- Aksiyon 2: TRIA Senkronizasyon -->
                            <div id="syncCardTria" class="p-5 rounded-2xl border border-slate-200 bg-white space-y-3">
                                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h5 class="text-sm font-bold text-slate-900">TRIA Oracle Otomatik Senkronizasyonu</h5>
                                        <p class="text-xs text-slate-500">Eczanenizin TRIA otomasyonundaki tüm aktif ürünleri ve çoklu barkodlarını kataloğa günceller.</p>
                                    </div>
                                    <button type="button" onclick="syncTriaCatalog()" id="btnSyncTriaCat" class="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0">
                                        <i class="fa-solid fa-rotate"></i>
                                        <span>TRIA'dan Şimdi Güncelle</span>
                                    </button>
                                </div>
                                <div id="triaSyncStatus" class="hidden text-xs font-semibold p-3 rounded-xl"></div>
                            </div>

                            <!-- Aksiyon 3: Excel Dosyası Yükleme -->
                            <div class="p-5 rounded-2xl border border-slate-200 bg-white space-y-3">
                                <div>
                                    <h5 class="text-sm font-bold text-slate-900">Özel Dermokozmetik / OTC Excel Listesi Yükle</h5>
                                    <p class="text-xs text-slate-500">Elinizdeki temiz bir Excel (.xlsx) dosyasını (Barkod, Ürün Adı, Fiyat, KDV vb.) doğrudan kataloğa ekleyebilirsiniz.</p>
                                </div>
                                <div class="flex flex-col sm:flex-row items-center gap-3 pt-1">
                                    <input type="file" id="excelCatalogFile" accept=".xlsx,.xls" class="text-xs text-slate-600 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer w-full sm:w-auto" />
                                    <button type="button" onclick="uploadCatalogExcel()" id="btnUploadCatExcel" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0">
                                        <i class="fa-solid fa-file-excel"></i>
                                        <span>Excel'i Kataloğa Aktar</span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Alt Sekme 3: GitHub Manifest URL & Canlı Güncelleme Yayınlama Portalı -->
                        <div id="adminSubContentGithub" class="hidden space-y-6">
                            <!-- Dağıtım & Manifest Bilgisi -->
                            <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center space-x-2">
                                        <i class="fa-solid fa-network-wired text-cyan-600 text-xs"></i>
                                        <span class="text-xs font-bold text-slate-800">Merkezi Canlı Dağıtım Sunucusu (GitHub Manifest URL)</span>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <a href="/portal" target="_blank" class="text-[11px] font-bold text-cyan-700 hover:text-cyan-900 underline flex items-center gap-1">
                                            <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>Canlı Portal Sayfası
                                        </a>
                                        <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">Canlı Otomatik Güncelleme Aktif</span>
                                    </div>
                                </div>
                                <p class="text-[11px] text-slate-500">Program her açılışta ve arka planda 5 dakikada bir bu GitHub adresini kontrol ederek yeni sürümleri otomatik kurar. Eczane şifreleriniz (.env), lisansınız ve yerel verileriniz asla ezilmez.</p>
                                <div class="flex flex-col sm:flex-row gap-2">
                                    <input type="text" id="cfg_update_manifest_url" class="flex-1 text-xs font-mono p-2.5 rounded-xl border border-slate-300 bg-white text-slate-700 focus:outline-none focus:border-cyan-600 select-all" value="https://raw.githubusercontent.com/depomxxx/depo-updates/main/version.json">
                                    <button type="button" onclick="saveManifestUrlConfig()" class="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl transition cursor-pointer shrink-0">
                                        <i class="fa-solid fa-floppy-disk mr-1"></i>Adresi Kaydet
                                    </button>
                                </div>
                            </div>

                            <!-- GitHub Canlı Güncelleme & Yayınlama Portalı (Admin) -->
                            <div id="githubAdminPortalBox" class="bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-cyan-500/30 rounded-2xl p-5 space-y-4 shadow-md">
                                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700/80 pb-3">
                                    <div class="flex items-center space-x-3">
                                        <div class="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-300 text-lg">
                                            <i class="fa-brands fa-github"></i>
                                        </div>
                                        <div>
                                            <h5 class="text-sm font-black text-white">GitHub Canlı Güncelleme & Yayınlama Portalı (Merkez)</h5>
                                            <p class="text-[11px] text-slate-300">Git kurulumu gerekmeden doğrudan GitHub bulutuna ve ağdaki tüm bilgisayarlara canlı sürüm gönderin.</p>
                                        </div>
                                    </div>
                                    <span id="ghPortalStatusBadge" class="text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">HAZIR</span>
                                </div>

                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">GitHub Token (ghp_...)</label>
                                        <input type="password" id="ghPortalToken" placeholder="ghp_... (Kayıtlıysa boş bırakın)" class="w-full font-mono text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-emerald-300 focus:outline-none focus:border-cyan-400">
                                    </div>
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">GitHub Kullanıcı Adı</label>
                                        <input type="text" id="ghPortalOwner" placeholder="depomxxx" value="depomxxx" class="w-full font-mono text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-white focus:outline-none focus:border-cyan-400">
                                    </div>
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">GitHub Depo (Repo) Adı</label>
                                        <div class="flex gap-1.5">
                                            <input type="text" id="ghPortalRepo" placeholder="depo-updates" value="depo-updates" class="w-full font-mono text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-white focus:outline-none focus:border-cyan-400">
                                            <button type="button" onclick="verifyAndSetupGithubPortal()" id="btnVerifyGhPortal" class="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[11px] rounded-xl transition cursor-pointer shrink-0" title="GitHub'da depoyu otomatik oluşturur ve bağlar">
                                                Bağla
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs pt-1">
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">Yayınlanacak Sürüm</label>
                                        <input type="text" id="ghPortalNewVersion" value="1.3.5" class="w-full font-mono font-bold text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-amber-300 focus:outline-none focus:border-cyan-400">
                                    </div>
                                    <div class="sm:col-span-3">
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">Sürüm Notları (Changelog)</label>
                                        <input type="text" id="ghPortalChangelog" value="Yönetici paneli şifre koruması ve kurumsal lisans senkronizasyonu iyileştirmesi." class="w-full text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-slate-200 focus:outline-none focus:border-cyan-400">
                                    </div>
                                </div>

                                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
                                    <div id="ghPortalResultText" class="text-[11px] text-slate-300 font-mono truncate max-w-md">
                                        Tek tıkla tüm eczane bilgisayarlarını ve GitHub portalını güncelleyebilirsiniz.
                                    </div>
                                    <button type="button" onclick="publishLiveReleaseFromPortal()" id="btnPublishGhPortal" class="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-900/40 transition flex items-center justify-center gap-2 cursor-pointer shrink-0">
                                        <i class="fa-solid fa-rocket"></i>
                                        <span>GitHub + Tüm Bilgisayarlara Canlı Yayınla</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="settingsFeedback" class="hidden p-3 rounded-xl text-xs font-semibold"></div>
            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span class="text-[11px] text-slate-500 text-center sm:text-left">Değişiklik yapmadığınız ayarlar mevcut halleriyle çalışmaya devam eder.</span>
                <div class="flex items-center space-x-2">
                    <button type="button" onclick="closeSettingsModal()" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200 transition cursor-pointer">Vazgeç</button>
                    <button type="button" id="saveSettingsBtn" onclick="saveSettings()" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-200 transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-check"></i>
                        <span>Tüm Ayarları Kaydet</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Eşdeğer / Muadil İlaçlar Modalı -->
    <div id="esdegerModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-3xl w-full max-h-[85vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div class="px-6 py-5 bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300">
                        <i class="fa-solid fa-code-compare text-lg"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-white flex items-center space-x-2">
                            <span>SGK Eşdeğer & Muadil İlaçlar</span>
                            <span id="modalEsdegerKodu" class="text-xs font-mono bg-indigo-500/30 text-indigo-200 px-2 py-0.5 rounded border border-indigo-400/40"></span>
                        </h3>
                        <p class="text-xs text-indigo-200/80">Bu ilacın yerine SGK kapsamında verilebilecek muadil ilaçlar ve Selçuk Ecza ticari şartları</p>
                    </div>
                </div>
                <button type="button" onclick="closeEsdegerModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Content (Cards) -->
            <div class="p-6 overflow-y-auto space-y-3 flex-1 bg-slate-50/50">
                <div class="text-xs text-slate-500 mb-2 flex items-center justify-between">
                    <span>Toplam <strong id="modalEsdegerCount" class="text-slate-800">0</strong> Muadil İlaç Bulundu</span>
                    <span class="text-[11px] text-indigo-600"><i class="fa-solid fa-circle-info mr-1"></i>Herhangi bir muadili seçerek 6 depoda anında karşılaştırabilirsiniz</span>
                </div>
                <div id="modalEsdegerList" class="space-y-2">
                    <!-- Dynamic Rows -->
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
                <button type="button" onclick="closeEsdegerModal()" class="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
            </div>
        </div>
    </div>

    <!-- ========================================== -->
    <!-- TEKLİ HIZLI SİPARİŞİ SONLANDIRMA MODALI    -->
    <!-- ========================================== -->
    <div id="quickFinalizeModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div id="quickFinHeader" class="px-6 py-5 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center text-yellow-200 text-lg">
                        <i class="fa-solid fa-bolt-lightning animate-pulse"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-black text-white flex items-center space-x-2">
                            <span>Tekli Siparişi Tamamla & Sonlandır</span>
                            <span id="quickFinDepoBadge" class="text-[10px] bg-white/20 text-white font-extrabold px-2.5 py-0.5 rounded-full border border-white/30">Selçuk Ecza</span>
                        </h3>
                        <p class="text-xs text-amber-100 font-medium">Doğrudan depoya iletim ve tek tıkla sipariş tamamlama</p>
                    </div>
                </div>
                <button type="button" onclick="closeQuickFinalizeModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Body -->
            <div id="quickFinBody" class="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
                <!-- Dynamic Content injected via JS -->
            </div>

            <!-- Modal Footer -->
            <div id="quickFinFooter" class="px-6 py-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
                <!-- Dynamic Buttons injected via JS -->
            </div>
        </div>
    </div>


    <!-- ========================================== -->
    <!-- TOPLU SİPARİŞ GÖNDERİCİ MODAL (ALLIANCE)   -->
    <!-- ========================================== -->
    <div id="bulkOrderModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div id="bulkModalHeader" class="px-6 py-5 bg-gradient-to-r from-sky-900 via-slate-900 to-indigo-950 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div id="bulkModalIconBox" class="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-300 text-lg">
                        <i id="bulkModalIcon" class="fa-solid fa-truck-ramp-box"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-white flex items-center space-x-2">
                            <span id="bulkModalTitle">🚀 Alliance Healthcare Toplu Sipariş Gönderici</span>
                            <span id="bulkModalBadge" class="text-[10px] bg-sky-500/30 text-sky-200 font-extrabold px-2.5 py-0.5 rounded-full border border-sky-400/40">B2B Canlı Sepet</span>
                        </h3>
                        <p id="bulkModalDesc" class="text-xs text-sky-200/80">Günün çıkışlarından seçilen ilaçlar otomatik taranarak sepetinize taslak sipariş olarak aktarılır.</p>
                    </div>
                </div>
                <button type="button" onclick="closeBulkOrderModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Content -->
            <div class="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
                <!-- Status & Progress Banner -->
                <div id="bulkProgressArea" class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2.5">
                    <div class="flex items-center justify-between text-xs font-bold text-slate-800">
                        <span id="bulkProgressStatus" class="flex items-center gap-2">
                            <i class="fa-solid fa-spinner fa-spin text-sky-600" id="bulkProgressSpinner"></i>
                            <span id="bulkProgressText">Alliance sepetine ürünler aktarılıyor...</span>
                        </span>
                        <span id="bulkProgressPercent" class="font-mono text-sky-700 font-extrabold">%0</span>
                    </div>
                    <!-- Progress Bar -->
                    <div class="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                        <div id="bulkProgressBar" class="bg-gradient-to-r from-sky-500 to-blue-600 h-2.5 rounded-full transition-all duration-300" style="width: 0%"></div>
                    </div>
                </div>

                <!-- 4 KPI Stat Boxes -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                        <div class="text-[11px] text-slate-500">Gönderilen Kalem</div>
                        <div class="text-lg font-black text-slate-900 mt-0.5" id="bulkStatTotal">0</div>
                    </div>
                    <div class="bg-white p-3 rounded-xl border border-emerald-100 shadow-2xs">
                        <div class="text-[11px] text-emerald-700">Başarıyla Eklenen</div>
                        <div class="text-lg font-black text-emerald-600 mt-0.5" id="bulkStatSuccess">0</div>
                    </div>
                    <div class="bg-white p-3 rounded-xl border border-rose-100 shadow-2xs">
                        <div class="text-[11px] text-rose-700" id="bulkStatFailedLabel">Depoda Bulunamayan</div>
                        <div class="text-lg font-black text-rose-600 mt-0.5" id="bulkStatFailed">0</div>
                    </div>
                    <div class="bg-white p-3 rounded-xl border border-sky-100 shadow-2xs">
                        <div class="text-[11px] text-sky-700">Taslak Sepet Tutarı</div>
                        <div class="text-lg font-black text-sky-800 mt-0.5 font-mono" id="bulkStatAmount">0.00 ₺</div>
                    </div>
                </div>

                <!-- Eksik Kalemleri Başka Depoya Aktarma Paneli (Hızlı ve Kontrollü) -->
                <div id="bulkTransferMissingBar" class="hidden p-3.5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl flex flex-col md:flex-row items-center justify-between gap-3 shadow-md border border-indigo-700/50">
                    <div class="flex items-center space-x-2.5 min-w-0">
                        <span class="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center font-bold text-sm shrink-0">
                            <i class="fa-solid fa-layer-group"></i>
                        </span>
                        <div class="min-w-0">
                            <div class="text-xs font-bold text-white flex items-center gap-1.5">
                                <span>Bu depoda olmayan <strong class="text-amber-300 font-extrabold" id="bulkMissingCount">0</strong> kalem toplandı!</span>
                            </div>
                            <div class="text-[11px] text-indigo-200/80">Bu eksik ürünleri istediğiniz depoya tek tıkla aktarın:</div>
                        </div>
                    </div>
                    <div class="flex flex-wrap items-center gap-1.5 shrink-0" id="bulkTransferButtonsContainer">
                        <!-- Dinamik doldurulacak: Alliance, Selçuk, İSKOOP, Nevzat -->
                    </div>
                </div>

                <!-- Depo Dağılım Hapları -->
                <div id="bulkModalDepoBreakdown" class="hidden grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <!-- Dinamik doldurulacak -->
                </div>

                <!-- Item Results Table with Tabs & Yok Listesi Export -->
                <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
                    <div class="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-slate-700">
                        <div class="flex items-center space-x-1.5" id="bulkResultTabsContainer">
                            <button type="button" id="bulkTabBtnAll" onclick="switchBulkResultTab('ALL')" class="px-2.5 py-1 rounded-lg text-xs font-black bg-white text-slate-900 shadow-2xs border border-slate-200 cursor-pointer">
                                Tüm Kalemler (<span id="bulkTabCountAll">0</span>)
                            </button>
                            <button type="button" id="bulkTabBtnYok" onclick="switchBulkResultTab('YOK')" class="px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 hover:bg-rose-50 border border-transparent cursor-pointer flex items-center space-x-1">
                                <i class="fa-solid fa-triangle-exclamation text-rose-500"></i>
                                <span>Bulunamayanlar (<span id="bulkTabCountYok">0</span>)</span>
                            </button>
                        </div>
                        <div class="flex items-center space-x-2">
                            <button type="button" id="btnCopyYokList" onclick="copyMissingItemsToClipboard()" class="hidden px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[11px] font-bold shadow-2xs transition flex items-center space-x-1.5 cursor-pointer active:scale-98" title="Bulunamayan ilaçları kopyala">
                                <i class="fa-solid fa-copy text-[10px]"></i>
                                <span>Eksikleri Kopyala</span>
                            </button>
                            <span id="bulkModalTargetDepo" class="text-[11px] text-slate-400 font-medium">B2B Canlı Sepet</span>
                        </div>
                    </div>
                    <div class="max-h-72 overflow-y-auto divide-y divide-slate-100 text-xs" id="bulkOrderItemsList">
                        <div class="p-6 text-center text-slate-400">İşlem başlatılıyor...</div>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div class="flex flex-wrap items-center gap-2" id="bulkModalFooterLinks">
                    <a 
                        id="bulkModalCartLink"
                        href="https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart" 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        class="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-md shadow-sky-200 transition flex items-center space-x-1.5 cursor-pointer"
                    >
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        <span id="bulkModalCartBtnText">Alliance eSipariş Sepetini Aç ↗</span>
                    </a>
                </div>
                <div class="flex items-center space-x-2">
                    <button type="button" id="btnBulkFinalize" onclick="openBulkFinalizeFlow()" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-500/20 transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-paper-plane text-xs"></i>
                        <span>Siparişi Sonlandır & Depoya Gönder</span>
                    </button>
                    <button type="button" onclick="closeBulkOrderModal()" class="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ========================================== -->
    <!-- GÜNLÜK TOPLU SİPARİŞİ SONLANDIRMA MODALI   -->
    <!-- ========================================== -->
    <div id="bulkFinalizeModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div id="bulkFinHeader" class="px-6 py-5 bg-gradient-to-r from-emerald-700 via-teal-700 to-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center text-emerald-200 text-lg">
                        <i class="fa-solid fa-clipboard-check"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-black text-white flex items-center space-x-2">
                            <span>Günlük Siparişi Sonlandır & Depoya Gönder</span>
                            <span id="bulkFinDepoBadge" class="text-[10px] bg-white/20 text-white font-extrabold px-2.5 py-0.5 rounded-full border border-white/30">Alliance</span>
                        </h3>
                        <p class="text-xs text-emerald-100 font-medium">Sepet kontrolü, farklı ürün analizi ve tek tıkla depoya gönderim</p>
                    </div>
                </div>
                <button type="button" onclick="closeBulkFinalizeModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Body -->
            <div id="bulkFinBody" class="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
                <!-- Dynamic Content injected via JS -->
            </div>

            <!-- Modal Footer -->
            <div id="bulkFinFooter" class="px-6 py-4 bg-slate-100 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2">
                <!-- Dynamic Buttons injected via JS -->
            </div>
        </div>
    </div>

    <!-- YÜZEN KÜÇÜK SEPET WIDGET'I (Çoklu Depo Sepetlerim & Kaldığım Yerden Devam Et) -->
    <div id="floatingMiniBulkCart" class="hidden fixed bottom-5 left-5 z-40 max-w-md w-auto">
        <div class="flex flex-col gap-2 px-4 py-3 rounded-2xl bg-gradient-to-r from-indigo-950 via-violet-950 to-slate-900 text-white shadow-2xl shadow-indigo-950/60 border-2 border-indigo-400/60 hover:border-amber-400 transition-all duration-200">
            <div onclick="openMultiDepotCartModal()" class="group flex items-center justify-between space-x-3.5 cursor-pointer">
                <div class="flex items-center space-x-3">
                    <div class="relative w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 text-slate-950 flex items-center justify-center text-lg font-black shadow-md shrink-0">
                        <i class="fa-solid fa-cart-shopping"></i>
                        <span id="floatingMiniBulkBadgeCount" class="absolute -top-2 -right-2 px-1.5 py-0.5 min-w-[22px] text-center rounded-full bg-rose-600 text-white text-[10px] font-black border-2 border-slate-900 shadow">0</span>
                    </div>
                    <div class="pr-1">
                        <div class="flex items-center space-x-1.5">
                            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                            <span class="text-[10px] font-black uppercase tracking-wider text-amber-300">Depo Sepetlerim Aktif</span>
                        </div>
                        <div id="floatingMiniBulkTitle" class="text-xs font-black text-white mt-0.5 leading-snug">Sepette Bekleyen Ürünleriniz Var</div>
                        <div id="floatingMiniBulkSub" class="text-[10px] text-indigo-200 font-semibold mt-0.5">Depolara göre ürünleri görmek ve sepete gitmek için tıklayın</div>
                    </div>
                </div>
                <div class="w-8 h-8 rounded-xl bg-white/10 group-hover:bg-amber-400 group-hover:text-slate-950 flex items-center justify-center transition shrink-0" title="Depo Sepetlerini Aç">
                    <i class="fa-solid fa-basket-shopping text-xs"></i>
                </div>
            </div>
            <!-- Depo Bazlı Hızlı Sepet Rozetleri (Alliance, Selçuk, İSKOOP, Nevzat ayrı ayrı tıklanabilir) -->
            <div id="floatingDepotCartPills" class="flex flex-wrap items-center gap-1.5 pt-1.5 border-t border-white/10"></div>
        </div>
    </div>

    <!-- ÇOKLU DEPO SEPETLERİM & SEPET DETAY MODALI (Farklı Depoları Ayrı Ayrı Gösteren Sepet Merkezi) -->
    <div id="multiDepotCartModal" class="hidden fixed inset-0 bg-slate-950/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-5xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <!-- Üst Başlık -->
            <div class="px-6 py-4 bg-gradient-to-r from-indigo-950 via-violet-900 to-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3.5">
                    <div class="w-11 h-11 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-300 text-lg font-black">
                        <i class="fa-solid fa-cart-shopping"></i>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="text-base font-black text-white">🛒 Depo Sepetlerim & Sipariş Kontrol Merkezi</h3>
                            <span id="multiCartTotalSummaryBadge" class="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[11px] font-black">0 Depo • 0 Kalem</span>
                        </div>
                        <p class="text-xs text-indigo-200 mt-0.5">Aramadan veya günlük/6 aylık siparişlerden eklediğiniz ürünleri depolara göre ayrı ayrı inceleyin ve ilgili deponun sepetine gidin.</p>
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <button type="button" id="multiCartMissingBulkBtn" onclick="closeMultiDepotCartModal(); reopenBulkOrderModal();" class="hidden px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/40 text-rose-200 text-xs font-extrabold cursor-pointer">
                        <i class="fa-solid fa-triangle-exclamation mr-1"></i>Eksik Ürünler Raporu
                    </button>
                    <button type="button" onclick="syncTodayOrdersAcrossPCs()" class="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition cursor-pointer" title="Sepetleri Yenile">
                        <i class="fa-solid fa-rotate mr-1"></i>Yenile
                    </button>
                    <button type="button" onclick="closeMultiDepotCartModal()" class="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition cursor-pointer">
                        <i class="fa-solid fa-xmark text-base"></i>
                    </button>
                </div>
            </div>

            <!-- Depo Sekmeleri (Tüm Depolar + Her Depo İçin Ayrı Sekme) -->
            <div id="multiDepotCartTabs" class="px-6 py-3 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center gap-2">
                <!-- JS tarafından doldurulur -->
            </div>

            <!-- Gövde: Depo Sepet Kartları ve Ürün Listeleri -->
            <div id="multiDepotCartBody" class="p-6 overflow-y-auto space-y-5 flex-1 bg-slate-50/70">
                <!-- JS tarafından doldurulur -->
            </div>

            <!-- Alt Bilgi ve Aksiyon Çubuğu -->
            <div class="px-6 py-3.5 bg-white border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
                <div class="text-slate-500 font-semibold flex items-center gap-2">
                    <i class="fa-solid fa-circle-info text-indigo-500"></i>
                    <span>Her deponun sepetindeki ürünleri kontrol ettikten sonra <b>"Depo Sepetine Git (Portal Aç)"</b> veya <b>"Siparişi Sonlandır & Gönder"</b> butonunu kullanabilirsiniz.</span>
                </div>
                <button type="button" onclick="closeMultiDepotCartModal()" class="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold transition cursor-pointer shrink-0">
                    Kapat & Aramaya Devam Et
                </button>
            </div>
        </div>
    </div>

    <!-- TAM EKRAN LİSANS KİLİDİ / UZAKTAN ASKIYA ALMA & SÜRE DOLUMU MODALI -->
    <div id="licenseLockOverlayModal" style="display: none;" class="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[9999] flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-lg w-full shadow-2xl border-2 border-rose-500/40 overflow-hidden animate-in fade-in zoom-in duration-200">
            <div class="px-6 py-5 bg-gradient-to-r from-rose-900 via-slate-900 to-indigo-950 text-white flex items-center space-x-3.5">
                <div class="w-12 h-12 rounded-2xl bg-rose-500/25 border border-rose-400/40 flex items-center justify-center text-rose-300 text-xl shrink-0">
                    <i class="fa-solid fa-lock"></i>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <h3 class="text-base font-black text-white">Kurumsal Lisans Doğrulaması Gerekli</h3>
                        <span id="lockModalStatusBadge" class="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-rose-500 text-white">ASKIDA / SÜRESİ DOLDU</span>
                    </div>
                    <p class="text-xs text-rose-200 mt-0.5" id="lockModalPharmacyName">Farma Radar Eczane Sistemi</p>
                </div>
            </div>

            <div class="p-6 space-y-4">
                <div id="lockModalReasonBox" class="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-bold leading-relaxed">
                    Lisans süreniz dolmuş veya yönetici tarafından askıya alınmıştır. Lütfen yöneticinizle iletişime geçin.
                </div>

                <div class="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                    <div>
                        <div class="text-[10px] font-bold text-slate-400 uppercase">Bu Bilgisayarın Donanım Kimliği (HWID)</div>
                        <div id="lockModalHwid" class="font-mono font-black text-sm text-indigo-700 mt-0.5 select-all">----</div>
                    </div>
                    <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('lockModalHwid').innerText); showToast('Kopyalandı', 'HWID panoya kopyalandı.', 'success');" class="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs border border-indigo-200 cursor-pointer">
                        <i class="fa-solid fa-copy mr-1"></i>Kopyala
                    </button>
                </div>

                <div class="space-y-2">
                    <label class="block text-xs font-extrabold text-slate-700">Yeni Lisans Anahtarınız Varsa Yapıştırın (FR-... / EDP-...):</label>
                    <div class="flex gap-2">
                        <input type="text" id="lockModalKeyInput" placeholder="FR-... veya EDP-..." class="flex-1 text-xs font-mono p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white focus:outline-none focus:border-indigo-500">
                        <button type="button" onclick="activateLicenseFromLockModal()" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl transition cursor-pointer shrink-0">
                            <i class="fa-solid fa-key mr-1"></i>Etkinleştir
                        </button>
                    </div>
                </div>

                <div class="pt-2 border-t border-slate-100">
                    <button type="button" onclick="syncLicenseWithCloud(true)" class="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs shadow-lg shadow-emerald-600/20 transition flex items-center justify-center gap-2 cursor-pointer">
                        <i class="fa-solid fa-cloud-arrow-down"></i>
                        <span>Sürem Uzatıldı / Kilidim Açıldı — Online Kontrol Et & Yenile</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- GÜN SONU DEPO SİPARİŞ ÖZETİ & VERİLMEYECEKLERDEN YOK LİSTESİ MERKEZİ (v1.4.2) -->
    <!-- ========================================================================= -->
    <div id="endOfDaySummaryModal" class="hidden fixed inset-0 bg-slate-950/75 backdrop-blur-sm z-50 flex items-center justify-center p-3">
        <div class="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[88vh]">
            <!-- Kompakt Üst Başlık + KPI Hapları -->
            <div class="px-4 py-2.5 bg-gradient-to-r from-slate-900 via-indigo-950 to-emerald-950 text-white flex items-center justify-between gap-3">
                <div class="flex items-center space-x-2.5 min-w-0">
                    <div class="w-8 h-8 rounded-xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-300 text-sm font-black shrink-0">
                        <i class="fa-solid fa-clipboard-list"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="flex items-center gap-2">
                            <h3 class="text-xs sm:text-sm font-black text-white">📋 Gün Sonu Depo Sipariş Özeti & Yok Listesi</h3>
                            <span id="eodModalDateBadge" class="px-2 py-0.5 rounded-full bg-white/15 text-amber-300 text-[10px] font-mono font-bold">--</span>
                        </div>
                    </div>
                </div>
                <div class="flex items-center gap-1.5 shrink-0">
                    <button type="button" onclick="loadEndOfDaySummary()" class="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[11px] font-bold transition cursor-pointer">
                        <i class="fa-solid fa-rotate mr-1"></i>Yenile
                    </button>
                    <button type="button" onclick="closeEndOfDaySummaryModal()" class="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition cursor-pointer">
                        <i class="fa-solid fa-xmark text-sm"></i>
                    </button>
                </div>
            </div>

            <!-- Kompakt KPI Şeridi (4'lü Tek Satır) -->
            <div class="px-4 py-2 bg-slate-50 border-b border-slate-200 grid grid-cols-4 gap-2 text-[11px]">
                <div onclick="switchEndOfDayTab('summary')" class="px-2.5 py-1.5 rounded-xl bg-white border border-emerald-200 flex items-center justify-between cursor-pointer hover:border-emerald-400 transition">
                    <div>
                        <div class="text-[9px] font-extrabold uppercase text-emerald-700">✅ Sipariş Verilen</div>
                        <div class="font-black text-slate-900"><span id="eodKpiOrderedCount">0</span> Kalem • <span id="eodKpiOrderedBoxes" class="text-emerald-700">0</span> Kt</div>
                    </div>
                    <i class="fa-solid fa-circle-check text-emerald-600 text-sm"></i>
                </div>
                <div onclick="switchEndOfDayTab('summary')" class="px-2.5 py-1.5 rounded-xl bg-white border border-amber-200 flex items-center justify-between cursor-pointer hover:border-amber-400 transition">
                    <div>
                        <div class="text-[9px] font-extrabold uppercase text-amber-700">🛒 Sepette Bekleyen</div>
                        <div class="font-black text-slate-900"><span id="eodKpiCartCount">0</span> Kalem • <span id="eodKpiCartBoxes" class="text-amber-700">0</span> Kt</div>
                    </div>
                    <i class="fa-solid fa-cart-shopping text-amber-600 text-sm"></i>
                </div>
                <div onclick="switchEndOfDayTab('skipped')" class="px-2.5 py-1.5 rounded-xl bg-white border border-slate-300 flex items-center justify-between cursor-pointer hover:border-slate-500 transition">
                    <div>
                        <div class="text-[9px] font-extrabold uppercase text-slate-600">🚫 Verilmeyecekler</div>
                        <div class="font-black text-slate-900"><span id="eodKpiSkippedCount">0</span> Kalem</div>
                    </div>
                    <i class="fa-solid fa-ban text-slate-500 text-sm"></i>
                </div>
                <div onclick="switchEndOfDayTab('yok')" class="px-2.5 py-1.5 rounded-xl bg-white border border-rose-200 flex items-center justify-between cursor-pointer hover:border-rose-400 transition">
                    <div>
                        <div class="text-[9px] font-extrabold uppercase text-rose-700">🚨 Yok Listesi</div>
                        <div class="font-black text-rose-700"><span id="eodKpiYokCount">0</span> Kalem <span id="eodKpiYokScanTime" class="text-[9px] font-normal text-rose-500"></span></div>
                    </div>
                    <i class="fa-solid fa-triangle-exclamation text-rose-600 text-sm"></i>
                </div>
            </div>

            <!-- Kompakt Alt Sekmeler (Tek Satır - Kaydırma Çubuğu Yok) -->
            <div class="px-4 bg-white border-b border-slate-200 flex items-center justify-between gap-2 whitespace-nowrap flex-nowrap">
                <div class="flex items-center space-x-1">
                    <button type="button" id="eodTabBtnSummary" onclick="switchEndOfDayTab('summary')" class="py-2 px-3 border-b-2 border-emerald-600 text-emerald-800 font-extrabold text-[11px] flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-boxes-packing"></i>
                        <span>📦 Depo Sipariş Özeti</span>
                    </button>
                    <button type="button" id="eodTabBtnSkipped" onclick="switchEndOfDayTab('skipped')" class="py-2 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 font-bold text-[11px] flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-magnifying-glass-chart text-indigo-600"></i>
                        <span>🚫 Verilmeyecekler & Yok Sorgula</span>
                    </button>
                    <button type="button" id="eodTabBtnYok" onclick="switchEndOfDayTab('yok')" class="py-2 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 font-bold text-[11px] flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-file-circle-exclamation text-rose-600"></i>
                        <span>🚨 Yok Listesi</span>
                    </button>
                </div>
                <div class="flex items-center gap-1.5 py-1">
                    <button type="button" onclick="scanSkippedItemsForYokList()" id="btnScanSkippedForYok" class="px-3 py-1 rounded-lg bg-gradient-to-r from-rose-600 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white font-black text-[11px] shadow-2xs transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-radar"></i>
                        <span>🔍 Verilmeyecekleri Depolarda Sorgula</span>
                    </button>
                </div>
            </div>

            <!-- Sekme İçerikleri -->
            <div class="p-4 overflow-y-auto flex-1 bg-slate-50/60 space-y-3">
                <div id="eodTabContentSummary" class="space-y-3"></div>
                <div id="eodTabContentSkipped" class="hidden space-y-3"></div>
                <div id="eodTabContentYok" class="hidden space-y-3"></div>
            </div>

            <!-- Modal Alt Çubuk -->
            <div class="px-4 py-2.5 bg-white border-t border-slate-200 flex items-center justify-between gap-2 text-[11px]">
                <div class="flex items-center gap-2">
                    <button type="button" onclick="copyEndOfDaySummaryReport()" class="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-extrabold transition cursor-pointer flex items-center gap-1.5">
                        <i class="fa-solid fa-copy"></i>
                        <span>📋 Gün Sonu Özetini Kopyala</span>
                    </button>
                    <button type="button" onclick="copyCompiledYokList()" class="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 font-extrabold transition cursor-pointer flex items-center gap-1.5">
                        <i class="fa-solid fa-clipboard-check"></i>
                        <span>🚨 Yok Listesini Kopyala</span>
                    </button>
                </div>
                <button type="button" onclick="closeEndOfDaySummaryModal()" class="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold transition cursor-pointer">
                    Kapat
                </button>
            </div>
        </div>
    </div>

    <script>
"""
