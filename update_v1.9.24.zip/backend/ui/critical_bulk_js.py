# -*- coding: utf-8 -*-
CRITICAL_BULK_JS = """        // ================= Günlük Çıkış & Azalan / Kritik Stok Paneli =================
        let criticalStockItems = [];
        let criticalFilterMode = 'days_21';
        window.criticalCheckedMap = window.criticalCheckedMap || {};
        window.criticalCustomQtyMap = window.criticalCustomQtyMap || {};
        window.criticalInitialSelectionDone = false;

        function getCriticalItemKey(item) {
            if (!item) return '';
            return String(item.barkod || item.urun_kodu || item.urun_adi || '').trim();
        }

        function syncCriticalDomStateToMaps() {
            window.criticalCheckedMap = window.criticalCheckedMap || {};
            window.criticalCustomQtyMap = window.criticalCustomQtyMap || {};
            const curList = window.currentFilteredCriticalItems || [];
            if (curList.length === 0) return;
            const checks = document.querySelectorAll('.bulkItemCheck');
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = curList[idx];
                const key = getCriticalItemKey(it);
                if (key) {
                    window.criticalCheckedMap[key] = !!c.checked;
                }
                const inp = document.getElementById(`bulkQtyInput_${idx}`);
                if (inp && key) {
                    const v = parseInt(inp.value);
                    if (!isNaN(v) && v >= 1) {
                        window.criticalCustomQtyMap[key] = v;
                    }
                }
            });
        }

        async function loadCriticalStockList(force = false) {
            syncCriticalDomStateToMaps();
            const container = document.getElementById('criticalStockListContainer');
            const countBadge = document.getElementById('sideCriticalCountBadge');
            const topBadge = document.getElementById('topBarCriticalCount');
            const refreshIcon = document.getElementById('criticalRefreshIcon');
            const statusPill = document.getElementById('botanikDataStatusPill');
            const statusIcon = document.getElementById('dataStatusIcon');
            const statusText = document.getElementById('dataStatusText');

            if (refreshIcon) refreshIcon.classList.add('fa-spin');
            if (container && force) {
                container.innerHTML = `
                    <div class="p-6 text-center text-slate-400 text-xs">
                        <i class="fa-solid fa-spinner fa-spin text-xl text-indigo-500 mb-2 block"></i>
                        Güncel stok ve çıkışlar taranıyor...
                    </div>
                `;
            }

            try {
                const res = await fetch(`/api/otomasyon/critical-stock?force=${force}`);
                if (!res.ok) throw new Error('API yanıt vermedi');
                const data = await res.json();
                criticalStockItems = data.items || [];
                if (data && data.success && criticalStockItems.length > 0) {
                    const srcUpper = String(data.source || '').toUpperCase();
                    if (srcUpper === 'TEBEOS' && typeof updateHeaderTebeosStatus === 'function' && (!window.tebeosStatus || !window.tebeosStatus.connected)) {
                        updateHeaderTebeosStatus(true, data);
                    } else if (srcUpper === 'BOTANIK' && typeof updateHeaderBotanikStatus === 'function' && (!window.botanikStatus || !window.botanikStatus.connected)) {
                        updateHeaderBotanikStatus(true, data);
                    }
                }

                // Başlangıçta hiçbir ürün seçili gelmesin; kullanıcı isterse Tümünü Seç veya tek tek seçsin
                criticalStockItems.forEach(it => {
                    const key = getCriticalItemKey(it);
                    if (!key) return;
                    if (it.siparis_durumu) {
                        window.criticalCheckedMap[key] = false;
                    } else if (window.criticalCheckedMap[key] === undefined) {
                        window.criticalCheckedMap[key] = false;
                    }
                });
                window.criticalInitialSelectionDone = true;

                const countStr = `${criticalStockItems.length}`;
                if (countBadge) countBadge.innerText = countStr;
                if (topBadge) topBadge.innerText = countStr;
                const miniBadge = document.getElementById('miniSideCriticalCount');
                if (miniBadge) miniBadge.innerText = countStr;

                renderCriticalList();
            } catch (err) {
                console.error("Critical stock fetch error:", err);
                if (container) {
                    container.innerHTML = `
                        <div class="p-4 text-center text-rose-500 text-xs bg-rose-50 rounded-xl border border-rose-200">
                            <i class="fa-solid fa-circle-exclamation text-base mb-1 block"></i>
                            Kritik stok bilgisi alınamadı: ${err.message}
                        </div>
                    `;
                }
            } finally {
                if (refreshIcon) refreshIcon.classList.remove('fa-spin');
            }
        }

        let showMfBadges = localStorage.getItem('showMfBadges') !== 'false';
        let hideOrderedItems = localStorage.getItem('hideOrderedItems') === 'true';
        let isMfResolutionRunning = false;

        function updateHideOrderedButtonUI() {
            const btn = document.getElementById('btnToggleHideOrdered');
            const txt = document.getElementById('btnToggleHideOrderedText');
            const icn = document.getElementById('btnToggleHideOrderedIcon');
            if (!btn) return;
            if (hideOrderedItems) {
                btn.className = 'px-1.5 py-1 rounded-md font-bold text-[10px] transition cursor-pointer flex items-center space-x-1 bg-emerald-600 text-white shrink-0';
                if (txt) txt.innerText = 'Gizli';
                if (icn) icn.className = 'fa-solid fa-eye text-[9px]';
            } else {
                btn.className = 'px-1.5 py-1 rounded-md font-bold text-[10px] transition cursor-pointer flex items-center space-x-1 bg-slate-100 text-slate-600 hover:bg-slate-200 shrink-0';
                if (txt) txt.innerText = 'Gizle';
                if (icn) icn.className = 'fa-solid fa-eye-slash text-[9px]';
            }
        }

        function toggleHideOrderedItems() {
            hideOrderedItems = !hideOrderedItems;
            localStorage.setItem('hideOrderedItems', hideOrderedItems ? 'true' : 'false');
            updateHideOrderedButtonUI();
            renderCriticalList();
        }

        async function syncTodayOrdersAcrossPCs() {
            try {
                const res = await fetch('/api/orders/today');
                if (!res.ok) return;
                const data = await res.json();
                if (!data.success || !data.orders) return;
                const prevOrdersMap = window.todayOrdersMap || null;
                const ordersMap = data.orders || {};
                if (data.pc_name) {
                    window.currentPcName = data.pc_name;
                }

                // Başka bir bilgisayardan yeni sepete eklenen ürün varsa mavi uyarı göster
                if (prevOrdersMap && window.currentPcName) {
                    const seenNotifNames = new Set();
                    for (const [k, ord] of Object.entries(ordersMap)) {
                        if (!ord || ord.durum !== 'SEPETTE' || k.startsWith('NAME:')) continue;
                        const prev = prevOrdersMap[k];
                        const masa = String(ord.masa_adi || ord.masa || '').trim();
                        const uAdi = String(ord.urun_adi || ord.barkod || k).trim();
                        if ((!prev || prev.durum !== 'SEPETTE') && masa && masa !== window.currentPcName && !seenNotifNames.has(uAdi)) {
                            seenNotifNames.add(uAdi);
                            if (typeof showToast === 'function') {
                                showToast('🛒 Ortak Eczane Sepeti Güncellendi', `${masa} bilgisayarından ${ord.depo || 'Depo'} sepetine ${ord.miktar || 1} kutu ${uAdi} eklendi.`, 'info');
                            }
                        }
                    }
                }

                window.todayOrdersMap = ordersMap;
                const recentTakasMap = data.recent_takas || window.recentTakasMap || {};
                window.recentTakasMap = recentTakasMap;

                // Ortak Yok Listesi (YOK_LISTESI) başka bir bilgisayarda değiştiyse Gün Sonu & Yok Listesi panelini anında yenile
                try {
                    const yokKeys = [];
                    for (const k of Object.keys(ordersMap)) {
                        if (k.startsWith('NAME:')) continue;
                        const o = ordersMap[k];
                        if (o && o.durum === 'SIPARIS_VERILMEYECEK' && String(o.depo || '').toUpperCase() === 'YOK_LISTESI') {
                            yokKeys.push(`${o.barkod || k}:${o.urun_adi || ''}`);
                        }
                    }
                    yokKeys.sort();
                    const yokSig = yokKeys.join('|');
                    if (typeof window._lastSyncedYokSig !== 'undefined' && window._lastSyncedYokSig !== yokSig) {
                        window._lastSyncedYokSig = yokSig;
                        if (typeof loadEndOfDaySummary === 'function') loadEndOfDaySummary();
                    } else {
                        window._lastSyncedYokSig = yokSig;
                    }
                } catch (e) {}

                let changed = false;
                let orderedTotal = 0;

                if (criticalStockItems && criticalStockItems.length > 0) {
                    criticalStockItems.forEach(it => {
                        const bc = (it.barkod || '').toString().trim();
                        const bcNoZero = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;
                        const bcWithZero = (bc.length === 13 && /^\\d+$/.test(bc)) ? ('0' + bc) : '';
                        const nm = (it.urun_adi || '').toString().trim().toLowerCase();
                        const nmUpper = (it.urun_adi || '').toString().trim().toUpperCase();
                        const match = (bc && ordersMap[bc])
                            || (bcNoZero && ordersMap[bcNoZero])
                            || (bcWithZero && ordersMap[bcWithZero])
                            || (nmUpper && ordersMap[nmUpper])
                            || (nmUpper && ordersMap[`NAME:${nmUpper.slice(0, 26)}`])
                            || (nm && ordersMap[`NAME:${nm}`]);

                        const takasMatch = (bc && recentTakasMap[bc])
                            || (bcNoZero && recentTakasMap[bcNoZero])
                            || (bcWithZero && recentTakasMap[bcWithZero])
                            || (nmUpper && recentTakasMap[nmUpper])
                            || (nmUpper && recentTakasMap[`NAME:${nmUpper.slice(0, 26)}`])
                            || null;

                        const prevTakasKey = it.takas_7gun_uyari ? `${it.takas_7gun_uyari.depo}_${it.takas_7gun_uyari.miktar}_${it.takas_7gun_uyari.tarih}` : '';
                        const nextTakasKey = takasMatch ? `${takasMatch.depo}_${takasMatch.miktar}_${takasMatch.tarih}` : '';
                        if (prevTakasKey !== nextTakasKey) {
                            it.takas_7gun_uyari = takasMatch;
                            changed = true;
                        }

                        const newStatus = match ? match.durum : null;
                        const newDepo = match ? match.depo : null;
                        const newMiktar = match ? match.miktar : null;
                        const newMasa = match ? (match.masa_adi || match.masa) : null;
                        const newSaat = match ? match.saat : null;

                        if (newStatus) orderedTotal++;

                        if (it.siparis_durumu !== newStatus || it.siparis_depo !== newDepo || it.siparis_miktar !== newMiktar) {
                            it.siparis_durumu = newStatus;
                            it.siparis_depo = newDepo;
                            it.siparis_miktar = newMiktar;
                            it.siparis_masa = newMasa;
                            it.siparis_saat = newSaat;
                            if (newStatus && window.criticalCheckedMap) {
                                const cKey = getCriticalItemKey(it);
                                if (cKey) window.criticalCheckedMap[cKey] = false;
                            }
                            changed = true;
                        }
                    });
                }

                // 6 Aylık Çıkış & Toplu Sipariş listesini de senkronize et
                let smartChanged = false;
                if (window.smartOrderItems && window.smartOrderItems.length > 0) {
                    window.smartOrderItems.forEach(it => {
                        const bc = (it.barkod || '').toString().trim();
                        const bcNoZero = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;
                        const bcWithZero = (bc.length === 13 && /^\\d+$/.test(bc)) ? ('0' + bc) : '';
                        const nm = (it.urun_adi || '').toString().trim().toLowerCase();
                        const nmUpper = (it.urun_adi || '').toString().trim().toUpperCase();
                        const match = (bc && ordersMap[bc])
                            || (bcNoZero && ordersMap[bcNoZero])
                            || (bcWithZero && ordersMap[bcWithZero])
                            || (nmUpper && ordersMap[nmUpper])
                            || (nmUpper && ordersMap[`NAME:${nmUpper.slice(0, 26)}`])
                            || (nm && ordersMap[`NAME:${nm}`]);

                        const takasMatch = (bc && recentTakasMap[bc])
                            || (bcNoZero && recentTakasMap[bcNoZero])
                            || (bcWithZero && recentTakasMap[bcWithZero])
                            || (nmUpper && recentTakasMap[nmUpper])
                            || (nmUpper && recentTakasMap[`NAME:${nmUpper.slice(0, 26)}`])
                            || null;

                        const prevTakasKey = it.takas_7gun_uyari ? `${it.takas_7gun_uyari.depo}_${it.takas_7gun_uyari.miktar}_${it.takas_7gun_uyari.tarih}` : '';
                        const nextTakasKey = takasMatch ? `${takasMatch.depo}_${takasMatch.miktar}_${takasMatch.tarih}` : '';
                        if (prevTakasKey !== nextTakasKey) {
                            it.takas_7gun_uyari = takasMatch;
                            smartChanged = true;
                        }

                        const newStatus = match ? match.durum : null;
                        const newDepo = match ? match.depo : null;
                        const newMiktar = match ? match.miktar : null;
                        const newMasa = match ? (match.masa_adi || match.masa) : null;
                        const newSaat = match ? match.saat : null;

                        if (it.siparis_durumu !== newStatus || it.siparis_depo !== newDepo || it.siparis_miktar !== newMiktar) {
                            it.siparis_durumu = newStatus;
                            it.siparis_depo = newDepo;
                            it.siparis_miktar = newMiktar;
                            it.siparis_masa = newMasa;
                            it.siparis_saat = newSaat;
                            if ((newStatus === 'SIPARIS_VERILDI' || newStatus === 'SIPARIS_VERILMEYECEK') && window.smartRowCheckedMap) {
                                const key = it.barkod || it.urun_kodu || it.urun_adi;
                                window.smartRowCheckedMap[key] = false;
                            }
                            smartChanged = true;
                        }
                    });
                }

                const ordBadge = document.getElementById('orderedTodayCountBadge');
                if (ordBadge) {
                    ordBadge.innerText = `${orderedTotal} İşlem`;
                }
                const eodHdrBadge = document.getElementById('eodHeaderSummaryBadge');
                if (eodHdrBadge) {
                    eodHdrBadge.innerText = String(orderedTotal);
                }

                if (changed) {
                    // Sipariş verilenleri en alta taşı; aktiflerde normal satışları üstte, sadece emanetle düşenleri kendi ayrı bloğunda tut
                    criticalStockItems.sort((a, b) => {
                        const aOrd = (a.siparis_durumu === 'SIPARIS_VERILDI' || a.siparis_durumu === 'SIPARIS_VERILMEYECEK' || a.siparis_durumu === 'SEPETTE') ? 1 : 0;
                        const bOrd = (b.siparis_durumu === 'SIPARIS_VERILDI' || b.siparis_durumu === 'SIPARIS_VERILMEYECEK' || b.siparis_durumu === 'SEPETTE') ? 1 : 0;
                        if (aOrd !== bOrd) return aOrd - bOrd;
                        const aEm = a.sadece_emanet ? 1 : 0;
                        const bEm = b.sadece_emanet ? 1 : 0;
                        if (aEm !== bEm) return aEm - bEm;
                        return ((b.bugun_cikis || 0) + (b.bugun_emanet || 0)) - ((a.bugun_cikis || 0) + (a.bugun_emanet || 0));
                    });
                    renderCriticalList();
                }

                if (smartChanged && typeof renderSmartOrderTable === 'function') {
                    if (typeof updateSmartKpiCounters === 'function') updateSmartKpiCounters();
                    renderSmartOrderTable();
                }

                if (typeof refreshCurrentSearchOrderBanner === 'function') {
                    refreshCurrentSearchOrderBanner();
                }

                if (typeof updateMultiDepotCartUI === 'function') {
                    updateMultiDepotCartUI();
                }

                const _ordersSig = Object.keys(window.todayOrdersMap || {}).sort().map(k => {
                    const v = (window.todayOrdersMap || {})[k] || {};
                    return `${k}:${v.durum || ''}:${v.depo || ''}:${v.miktar || ''}`;
                }).join('|');
                const _ordersMapChanged = (window._lastTodayOrdersSyncSig !== undefined && window._lastTodayOrdersSyncSig !== _ordersSig);
                window._lastTodayOrdersSyncSig = _ordersSig;

                const _activeEl = document.activeElement;
                const _editingOfferQty = Boolean(_activeEl && _activeEl.matches && _activeEl.matches('input[data-offer-qty-key]'));

                const etModal = document.getElementById('eczanetakasOffersModal');
                if (_ordersMapChanged && !_editingOfferQty && etModal && !etModal.classList.contains('hidden') && (window.etModalActiveTab || 'offers') === 'offers' && typeof renderEczaneTakasOffersModal === 'function') {
                    renderEczaneTakasOffersModal();
                }
                const etrModal = document.getElementById('eczatrendOffersModal');
                if (_ordersMapChanged && !_editingOfferQty && etrModal && !etrModal.classList.contains('hidden') && (window.etrModalActiveTab || 'offers') === 'offers' && typeof renderEczatrendOffersModal === 'function') {
                    renderEczatrendOffersModal();
                }
            } catch (e) {
                // Sessizce geç
            }
        }

        // Her 10 saniyede bir eczanedeki diğer bilgisayarlarla sipariş durumunu senkronize et
        setInterval(syncTodayOrdersAcrossPCs, 10000);
        setTimeout(() => { updateHideOrderedButtonUI(); syncTodayOrdersAcrossPCs(); }, 1500);

        async function markItemOrderedManually(idx, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            syncCriticalDomStateToMaps();
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;
            const cKey = getCriticalItemKey(item);
            if (cKey && window.criticalCheckedMap) {
                window.criticalCheckedMap[cKey] = false;
            }
            const depo = (window.cardSelectedDepos && window.cardSelectedDepos[idx]) || window.defaultQuickDepo || 'SELCUK';
            const input = document.getElementById(`bulkQtyInput_${idx}`);
            const qty = input ? (parseInt(input.value) || 1) : (item.onerilen_siparis || 1);
            await markItemOrderedDirect(item.barkod || '', item.urun_adi || '', depo, qty);
        }

        function applyOptimisticOrderStatus(itemsList, durum, depo) {
            try {
                const nowStr = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                const pcLabel = window.currentPcName || 'Bu PC';
                window.todayOrdersMap = window.todayOrdersMap || {};
                const mergeSepetDepo = (oldDurum, oldDepoStr, newDurum, newDepoStr) => {
                    const nd = String(newDepoStr || 'MANUEL').trim().toUpperCase();
                    if (newDurum === 'SEPETTE' && oldDurum === 'SEPETTE' && oldDepoStr) {
                        const parts = String(oldDepoStr).toUpperCase().split('+').map(p => p.trim()).filter(Boolean);
                        if (!parts.includes(nd)) parts.push(nd);
                        return parts.join(' + ');
                    }
                    return nd;
                };
                itemsList.forEach(target => {
                    const bc = String(target.barkod || '').trim();
                    const nm = String(target.urun_adi || '').trim().toUpperCase();
                    const offerKey = String(target.offer_key || '').trim();
                    const targetDepo = String(depo || target.depo || 'MANUEL').trim().toUpperCase();
                    if (durum) {
                        const prevEntry = (bc && window.todayOrdersMap[bc]) || (nm && window.todayOrdersMap[nm]) || null;
                        const mergedDepo = prevEntry
                            ? mergeSepetDepo(prevEntry.durum, prevEntry.depo, durum, targetDepo)
                            : targetDepo;
                        const entry = {
                            barkod: bc,
                            urun_adi: target.urun_adi || '',
                            durum: durum,
                            depo: mergedDepo,
                            miktar: target.miktar || 1,
                            masa_adi: pcLabel,
                            masa: pcLabel,
                            saat: nowStr
                        };
                        if (bc) window.todayOrdersMap[bc] = entry;
                        if (nm) {
                            window.todayOrdersMap[nm] = entry;
                            window.todayOrdersMap['NAME:' + nm.slice(0, 24)] = entry;
                        }
                        if (offerKey) window.todayOrdersMap[offerKey] = entry;
                    } else {
                        if (bc) delete window.todayOrdersMap[bc];
                        if (nm) {
                            delete window.todayOrdersMap[nm];
                            delete window.todayOrdersMap['NAME:' + nm.slice(0, 24)];
                        }
                        if (offerKey) delete window.todayOrdersMap[offerKey];
                    }
                    if (Array.isArray(criticalStockItems)) {
                        criticalStockItems.forEach(it => {
                            const itBc = String(it.barkod || '').trim();
                            const itNm = String(it.urun_adi || '').trim().toUpperCase();
                            if ((bc && itBc === bc) || (nm && itNm === nm)) {
                                const mergedDepo = durum ? mergeSepetDepo(it.siparis_durumu, it.siparis_depo, durum, targetDepo) : null;
                                it.siparis_durumu = durum || null;
                                it.siparis_depo = mergedDepo;
                                it.siparis_miktar = durum ? (target.miktar || 1) : null;
                                it.siparis_masa = durum ? pcLabel : null;
                                it.siparis_saat = durum ? nowStr : null;
                            }
                        });
                    }
                    if (Array.isArray(window.smartOrderItems)) {
                        window.smartOrderItems.forEach(it => {
                            const itBc = String(it.barkod || '').trim();
                            const itNm = String(it.urun_adi || '').trim().toUpperCase();
                            if ((bc && itBc === bc) || (nm && itNm === nm)) {
                                const mergedDepo = durum ? mergeSepetDepo(it.siparis_durumu, it.siparis_depo, durum, targetDepo) : null;
                                it.siparis_durumu = durum || null;
                                it.siparis_depo = mergedDepo;
                                it.siparis_miktar = durum ? (target.miktar || 1) : null;
                                it.siparis_masa = durum ? pcLabel : null;
                                it.siparis_saat = durum ? nowStr : null;
                                if (durum && window.smartRowCheckedMap) {
                                    const sKey = it.barkod || it.urun_kodu || it.urun_adi;
                                    if (sKey) window.smartRowCheckedMap[sKey] = false;
                                }
                            }
                        });
                    }
                    const activeRep = (typeof currentReport !== 'undefined' && currentReport) ? currentReport : null;
                    if (activeRep) {
                        const curBc = String(activeRep.barkod || '').trim();
                        const curNm = String(activeRep.urun_adi || '').trim().toUpperCase();
                        if ((bc && curBc === bc) || (nm && curNm === nm)) {
                            if (durum) {
                                const prevRepOrd = activeRep.bugun_siparis;
                                const mergedDepo = prevRepOrd
                                    ? mergeSepetDepo(prevRepOrd.durum, prevRepOrd.depo, durum, targetDepo)
                                    : targetDepo;
                                activeRep.bugun_siparis = {
                                    barkod: bc,
                                    urun_adi: target.urun_adi || '',
                                    durum: durum,
                                    depo: mergedDepo,
                                    miktar: target.miktar || 1,
                                    masa_adi: pcLabel,
                                    saat: nowStr
                                };
                            } else {
                                delete activeRep.bugun_siparis;
                            }
                            if (typeof renderResults === 'function') renderResults(activeRep);
                        }
                    }
                });
                if (Array.isArray(criticalStockItems) && criticalStockItems.length > 0) {
                    criticalStockItems.sort((a, b) => {
                        const aDone = (a.siparis_durumu === 'SIPARIS_VERILDI' || a.siparis_durumu === 'SIPARIS_VERILMEYECEK' || a.siparis_durumu === 'SEPETTE') ? 1 : 0;
                        const bDone = (b.siparis_durumu === 'SIPARIS_VERILDI' || b.siparis_durumu === 'SIPARIS_VERILMEYECEK' || b.siparis_durumu === 'SEPETTE') ? 1 : 0;
                        return aDone - bDone;
                    });
                    renderCriticalList();
                }
                if (Array.isArray(window.smartOrderItems) && window.smartOrderItems.length > 0 && typeof renderSmartOrderTable === 'function') {
                    if (typeof updateSmartKpiCounters === 'function') updateSmartKpiCounters();
                    renderSmartOrderTable();
                }
                if (typeof updateMultiDepotCartUI === 'function') updateMultiDepotCartUI();
                if (typeof refreshCurrentSearchOrderBanner === 'function') refreshCurrentSearchOrderBanner();
            } catch (optErr) {
                console.warn('Optimistic UI update warning:', optErr);
            }
        }

        async function markItemOrderedDirect(barkod, urunAdi, depo, miktar) {
            try {
                const realDepos = ['ALLIANCE', 'SELCUK', 'SELÇUK', 'ISKOOP', 'İSKOOP', 'NEVZAT'];
                const normDepo = String(depo || '').toUpperCase().trim();
                if (realDepos.some(d => normDepo.includes(d))) {
                    const ok = window.confirm(
                        `DİKKAT: Bu buton ${normDepo} sepetindeki ürünü DEPOYA GÖNDERMEZ; yalnızca yerel listede 'Sipariş Verildi' olarak işaretler.\\n\\n` +
                        `Ürünü gerçekten depoya göndermek için 'İptal' deyip 'Sepeti Gör / Sepeti Onayla' ekranından sepeti sonlandırınız.\\n\\n` +
                        `Yine de sadece manuel olarak 'Sipariş Verildi' işaretlemek istiyor musunuz?`
                    );
                    if (!ok) return;
                }
                syncCriticalDomStateToMaps();
                const cKey = getCriticalItemKey({ barkod: barkod, urun_adi: urunAdi });
                if (cKey && window.criticalCheckedMap) {
                    window.criticalCheckedMap[cKey] = false;
                }
                applyOptimisticOrderStatus([{ barkod: barkod, urun_adi: urunAdi, depo: depo || 'MANUEL', miktar: miktar || 1 }], 'SIPARIS_VERILDI', depo || 'MANUEL');
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        durum: 'SIPARIS_VERILDI',
                        depo: depo || 'MANUEL',
                        items: [{ barkod: barkod, urun_adi: urunAdi, depo: depo || 'MANUEL', miktar: miktar || 1 }]
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Sipariş Verildi İşaretlendi', `${urunAdi || barkod} tüm bilgisayarlarda 'Sipariş Verildi' olarak işaretlendi.`, 'success');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markItemSkippedManually(idx, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            syncCriticalDomStateToMaps();
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;
            const cKey = getCriticalItemKey(item);
            if (cKey && window.criticalCheckedMap) {
                window.criticalCheckedMap[cKey] = false;
            }
            await markItemSkippedDirect(item.barkod || '', item.urun_adi || '');
        }

        async function markItemSkippedDirect(barkod, urunAdi) {
            try {
                syncCriticalDomStateToMaps();
                const cKey = getCriticalItemKey({ barkod: barkod, urun_adi: urunAdi });
                if (cKey && window.criticalCheckedMap) {
                    window.criticalCheckedMap[cKey] = false;
                }
                applyOptimisticOrderStatus([{ barkod: barkod, urun_adi: urunAdi, depo: 'VERILMEYECEK', miktar: 1 }], 'SIPARIS_VERILMEYECEK', 'VERILMEYECEK');
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        durum: 'SIPARIS_VERILMEYECEK',
                        depo: 'VERILMEYECEK',
                        items: [{ barkod: barkod, urun_adi: urunAdi, depo: 'VERILMEYECEK', miktar: 1 }]
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Sipariş Verilmeyecek İşaretlendi', `${urunAdi || barkod} bugün sipariş verilmeyecek olarak işaretlendi ve listenin altına alındı.`, 'info');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markSelectedCriticalItemsSkipped() {
            syncCriticalDomStateToMaps();
            const checks = document.querySelectorAll('.bulkItemCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', 'Lütfen bugün sipariş verilmeyecek olarak işaretlemek istediğiniz ilaçları seçiniz.', 'info');
                return;
            }
            const itemsToSkip = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
                if (it) {
                    const cKey = getCriticalItemKey(it);
                    if (cKey && window.criticalCheckedMap) {
                        window.criticalCheckedMap[cKey] = false;
                    }
                    itemsToSkip.push({
                        barkod: it.barkod || '',
                        urun_adi: it.urun_adi || '',
                        depo: 'VERILMEYECEK',
                        miktar: 1
                    });
                }
            });
            if (itemsToSkip.length === 0) return;
            try {
                applyOptimisticOrderStatus(itemsToSkip, 'SIPARIS_VERILMEYECEK', 'VERILMEYECEK');
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        durum: 'SIPARIS_VERILMEYECEK',
                        depo: 'VERILMEYECEK',
                        items: itemsToSkip
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Toplu Verilmeyecek İşaretlendi', `${itemsToSkip.length} kalem ürün bugün sipariş verilmeyecek olarak işaretlendi.`, 'info');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markItemYokManually(idx, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            syncCriticalDomStateToMaps();
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;
            const cKey = getCriticalItemKey(item);
            if (cKey && window.criticalCheckedMap) {
                window.criticalCheckedMap[cKey] = false;
            }
            await markItemYokDirect(item.barkod || '', item.urun_adi || '');
        }

        async function markItemYokDirect(barkod, urunAdi) {
            try {
                syncCriticalDomStateToMaps();
                const cKey = getCriticalItemKey({ barkod: barkod, urun_adi: urunAdi });
                if (cKey && window.criticalCheckedMap) {
                    window.criticalCheckedMap[cKey] = false;
                }
                window.persistentYokUserClosed = false;
                applyOptimisticOrderStatus([{ barkod: barkod, urun_adi: urunAdi, depo: 'YOK_LISTESI', miktar: 1 }], 'SIPARIS_VERILMEYECEK', 'YOK_LISTESI');
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        items: [{ barkod: barkod || '', urun_adi: urunAdi || '', kaynak: 'Günün Çıkışları' }]
                    })
                });
                const data = await res.json();
                if (data.success) {
                    if (Array.isArray(data.yok_items) && typeof renderPersistentYokWidgets === 'function') {
                        renderPersistentYokWidgets(data.yok_items, Array.isArray(data.var_items) ? data.var_items : [], null);
                    }
                    showToast('🚨 Yok Listesine Eklendi', `${urunAdi || barkod} doğrudan Yok Listesine eklendi ve işaretlendi.`, 'info');
                    await loadEndOfDaySummary();
                    await syncTodayOrdersAcrossPCs();
                } else {
                    showToast('Uyarı', data.error || 'Yok listesine eklenemedi.', 'error');
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markSelectedCriticalItemsYok() {
            syncCriticalDomStateToMaps();
            const checks = document.querySelectorAll('.bulkItemCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', 'Lütfen Yok Listesine eklemek istediğiniz ilaçları seçiniz.', 'info');
                return;
            }
            const itemsToYok = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
                if (it) {
                    const cKey = getCriticalItemKey(it);
                    if (cKey && window.criticalCheckedMap) {
                        window.criticalCheckedMap[cKey] = false;
                    }
                    itemsToYok.push({
                        barkod: it.barkod || '',
                        urun_adi: it.urun_adi || '',
                        depo: 'YOK_LISTESI',
                        miktar: 1,
                        kaynak: 'Günün Çıkışları (Toplu)'
                    });
                }
            });
            if (itemsToYok.length === 0) return;
            try {
                window.persistentYokUserClosed = false;
                applyOptimisticOrderStatus(itemsToYok, 'SIPARIS_VERILMEYECEK', 'YOK_LISTESI');
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ items: itemsToYok })
                });
                const data = await res.json();
                if (data.success) {
                    if (Array.isArray(data.yok_items) && typeof renderPersistentYokWidgets === 'function') {
                        renderPersistentYokWidgets(data.yok_items, Array.isArray(data.var_items) ? data.var_items : [], null);
                    }
                    showToast('🚨 Toplu Yok Listesine Eklendi', `${itemsToYok.length} kalem ürün Yok Listesine eklendi.`, 'info');
                    await loadEndOfDaySummary();
                    await syncTodayOrdersAcrossPCs();
                } else {
                    showToast('Uyarı', data.error || 'Yok listesine eklenemedi.', 'error');
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function unmarkItemOrderStatus(barkod, urunAdi, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            try {
                syncCriticalDomStateToMaps();
                applyOptimisticOrderStatus([{ barkod: barkod, urun_adi: urunAdi }], null, null);
                const res = await fetch('/api/orders/unmark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barkod: barkod, urun_adi: urunAdi })
                });
                try {
                    await fetch('/api/orders/today/yok-list/remove', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ barkod: barkod || '', urun_adi: urunAdi || '' })
                    });
                } catch (_) {}
                const data = await res.json();
                if (data.success) {
                    showToast('Sipariş İşareti Kaldırıldı', `${urunAdi || barkod} tekrar sipariş listesine alındı.`, 'info');
                    await loadEndOfDaySummary();
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function dismissTakas7DayWarning(barkod, urunAdi, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            try {
                syncCriticalDomStateToMaps();
                const cleanBc = String(barkod || '').trim();
                const cleanNm = String(urunAdi || '').trim().toUpperCase();
                if (Array.isArray(criticalStockItems)) {
                    criticalStockItems.forEach(it => {
                        if ((cleanBc && String(it.barkod || '').trim() === cleanBc) || (cleanNm && String(it.urun_adi || '').trim().toUpperCase() === cleanNm)) {
                            it.takas_7gun_uyari = null;
                        }
                    });
                }
                if (Array.isArray(window.smartOrderItems)) {
                    window.smartOrderItems.forEach(it => {
                        if ((cleanBc && String(it.barkod || '').trim() === cleanBc) || (cleanNm && String(it.urun_adi || '').trim().toUpperCase() === cleanNm)) {
                            it.takas_7gun_uyari = null;
                        }
                    });
                }
                renderCriticalList();
                if (typeof renderSmartOrderTable === 'function') renderSmartOrderTable();

                await fetch('/api/orders/unmark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barkod: barkod, urun_adi: urunAdi, clear_takas_7d: true })
                });
                showToast('Takas/Kargo Uyarısı Kapatıldı', `${urunAdi || barkod} için 7 günlük Eczatrend/EczaneTakas katılım uyarısı kaldırıldı.`, 'info');
                await syncTodayOrdersAcrossPCs();
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }
        window.dismissTakas7DayWarning = dismissTakas7DayWarning;

        function toggleCriticalZeroOrNegFilter(targetMode) {
            if (criticalFilterMode === targetMode) {
                setCriticalFilterMode('days_21');
            } else {
                setCriticalFilterMode(targetMode);
            }
        }

        function setCriticalFilterMode(mode) {
            criticalFilterMode = mode;
            const btn21 = document.getElementById('btnCritFilter21');
            const btnAll = document.getElementById('btnCritFilterAll');
            const btnZero = document.getElementById('btnCritFilterZero');
            const btnNegative = document.getElementById('btnCritFilterNegative');
            const btnMf = document.getElementById('btnCritFilterMf');
            const btnEmanet = document.getElementById('btnCritFilterEmanet');

            const activeClass = 'px-2 py-1 rounded-md font-bold bg-indigo-600 text-white transition text-[10px] cursor-pointer shrink-0';
            const passiveClass = 'px-2 py-1 rounded-md font-semibold bg-slate-100 hover:bg-slate-200 text-slate-600 transition text-[10px] cursor-pointer shrink-0';

            if (btn21) btn21.className = mode === 'days_21' ? activeClass : passiveClass;
            if (btnAll) btnAll.className = mode === 'all' ? activeClass : passiveClass;
            if (btnZero) {
                btnZero.className = mode === 'zero'
                    ? 'px-2 py-1 rounded-md font-bold bg-rose-600 text-white transition text-[10px] cursor-pointer shrink-0 flex items-center space-x-1'
                    : 'px-2 py-1 rounded-md font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition text-[10px] cursor-pointer shrink-0 flex items-center space-x-1';
            }
            if (btnNegative) {
                btnNegative.className = mode === 'negative'
                    ? 'px-2 py-1 rounded-md font-bold bg-rose-700 text-white transition text-[10px] cursor-pointer shrink-0 flex items-center space-x-1'
                    : 'px-2 py-1 rounded-md font-bold bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 transition text-[10px] cursor-pointer shrink-0 flex items-center space-x-1';
            }
            if (btnMf) {
                btnMf.className = mode === 'mf_only' 
                    ? 'px-2 py-1 rounded-md font-bold bg-amber-500 text-white transition text-[10px] cursor-pointer flex items-center space-x-1 shrink-0'
                    : 'px-2 py-1 rounded-md font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 transition text-[10px] cursor-pointer flex items-center space-x-1 shrink-0';
            }
            if (btnEmanet) {
                const isHiddenNow = btnEmanet.dataset.hasItems !== '1' && mode !== 'emanet_only';
                btnEmanet.className = isHiddenNow
                    ? 'hidden'
                    : (mode === 'emanet_only'
                        ? 'px-2 py-1 rounded-md font-bold bg-orange-600 text-white transition text-[10px] cursor-pointer inline-flex items-center space-x-1 shrink-0'
                        : 'px-2 py-1 rounded-md font-bold bg-orange-50 hover:bg-orange-100 text-orange-900 border border-orange-300 transition text-[10px] cursor-pointer inline-flex items-center space-x-1 shrink-0');
            }

            renderCriticalList();
        }

        function filterCriticalList() {
            renderCriticalList();
        }

        function toggleMfBadgesView() {
            showMfBadges = !showMfBadges;
            localStorage.setItem('showMfBadges', showMfBadges ? 'true' : 'false');
            const btn = document.getElementById('btnToggleMfBadges');
            const txt = document.getElementById('btnToggleMfBadgesText');
            if (showMfBadges) {
                if (btn) btn.className = 'px-1.5 py-1 rounded-md font-bold text-[10px] transition cursor-pointer flex items-center space-x-1 bg-amber-500 text-white hover:bg-amber-600 shrink-0';
                if (txt) txt.innerText = 'MF';
                updateMfBadgesInDom();
                triggerBackgroundMfResolution();
            } else {
                if (btn) btn.className = 'px-1.5 py-1 rounded-md font-bold text-[10px] transition cursor-pointer flex items-center space-x-1 bg-slate-200 text-slate-600 hover:bg-slate-300 shrink-0';
                if (txt) txt.innerText = 'MF';
                updateMfBadgesInDom();
            }
        }

        function buildCriticalMfTierBadgesHtml(item, index) {
            if (!item || !item.mf_metni || item.mf_metni === 'YOK') return '';
            const rawDepo = item.mf_depo || 'Depo';
            const dUp = String(rawDepo).toUpperCase();
            let depoCode = 'ALLIANCE';
            if (dUp.includes('SELCUK') || dUp.includes('SELÇUK')) depoCode = 'SELCUK';
            else if (dUp.includes('ISKOOP') || dUp.includes('İSKOOP')) depoCode = 'ISKOOP';
            else if (dUp.includes('NEVZAT')) depoCode = 'NEVZAT';
            else if (dUp.includes('ALLIANCE')) depoCode = 'ALLIANCE';

            const tiers = [];
            const seen = new Set();
            const regex = /([0-9]+)\\s*\\+\\s*([0-9]+)/g;
            let m;
            while ((m = regex.exec(String(item.mf_metni))) !== null) {
                const alinan = parseInt(m[1], 10) || 0;
                const hediye = parseInt(m[2], 10) || 0;
                if (alinan > 0 && hediye > 0) {
                    const text = `${alinan}+${hediye}`;
                    if (!seen.has(text)) {
                        seen.add(text);
                        tiers.push({ alinan, hediye, text });
                    }
                }
            }
            tiers.sort((a, b) => a.alinan - b.alinan);
            const depoShort = String(rawDepo).substring(0, 6);
            if (tiers.length === 0) {
                return `
                    <span class="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[9px] font-black bg-amber-500 text-white" title="${rawDepo}: ${item.mf_metni} MF">
                        <i class="fa-solid fa-gift text-[8px]"></i>
                        <span>${item.mf_metni}</span>
                        <span class="opacity-85 text-[8px]">(${depoShort})</span>
                    </span>
                `;
            }
            const btns = tiers.map(t => `
                <button type="button" onclick="applyCriticalMfTier(${index}, ${t.alinan}, '${depoCode}', '${t.text}', event)" class="inline-flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9.5px] leading-none font-black bg-amber-500 hover:bg-amber-600 text-slate-950 transition cursor-pointer shadow-2xs" title="Tıklayın: Adedi ${t.alinan} kutu yap (${rawDepo} • ${t.text} MF)">
                    <i class="fa-solid fa-gift text-[8px]"></i>
                    <span>${t.text}</span>
                </button>
            `).join('');
            return `<span class="inline-flex flex-wrap items-center gap-1" onclick="event.stopPropagation()">${btns}<span class="text-[8.5px] font-extrabold text-amber-800 bg-amber-100 px-1 py-0.2 rounded">(${depoShort})</span></span>`;
        }
        window.buildCriticalMfTierBadgesHtml = buildCriticalMfTierBadgesHtml;

        function applyCriticalMfTier(index, targetQty, depoCode, mfLabel, ev) {
            if (ev) {
                ev.stopPropagation();
                ev.preventDefault();
            }
            const input = document.getElementById(`bulkQtyInput_${index}`);
            if (input) input.value = targetQty;
            const chk = document.querySelector(`.bulkItemCheck[data-idx="${index}"]`);
            if (chk) chk.checked = true;
            if (depoCode && typeof setCardDepo === 'function') {
                setCardDepo(index, depoCode, false, null);
            }
            syncCriticalDomStateToMaps();
            updateBulkSelectionCount();
            if (typeof refreshCriticalRowMfAssistant === 'function') {
                refreshCriticalRowMfAssistant(index);
            }
            showToast('MF Kademesi Seçildi', `Sipariş adedi ${mfLabel} MF şartı için ${targetQty} kutu (${depoCode}) olarak ayarlandı.`, 'success');
        }
        window.applyCriticalMfTier = applyCriticalMfTier;

        function updateMfBadgesInDom() {
            if (!window.currentFilteredCriticalItems) return;
            window.currentFilteredCriticalItems.forEach((item, index) => {
                const badgeSlot = document.getElementById(`criticalMfBadge_${index}`);
                if (!badgeSlot) return;
                const hasMf = showMfBadges && item.mf_metni && item.mf_metni !== 'YOK';
                if (hasMf) {
                    badgeSlot.className = 'inline-flex flex-wrap items-center gap-1';
                    badgeSlot.innerHTML = buildCriticalMfTierBadgesHtml(item, index);
                } else {
                    badgeSlot.className = 'hidden';
                    badgeSlot.innerHTML = '';
                }
                if (typeof refreshCriticalRowMfAssistant === 'function') {
                    refreshCriticalRowMfAssistant(index);
                }
            });
        }

        function computeSmartMfBaremAdvice(item, currentQty) {
            if (!item || item.siparis_durumu === 'SIPARIS_VERILDI' || item.siparis_durumu === 'SIPARIS_VERILMEYECEK') {
                return null;
            }
            const qty = Math.max(1, parseInt(currentQty) || 1);
            // SADECE güncel (anlık) depo MF'si varsa MF tamamlama uyarısı ver; eski geçmiş fatura MF'sine (G.MF) göre asla uyarı verme!
            const rawMf = (item.mf_metni && item.mf_metni !== 'YOK')
                ? String(item.mf_metni)
                : '';
            if (!rawMf) return null;

            const rawDepo = item.mf_depo || 'SELCUK';
            let depoCode = 'ALLIANCE';
            const dUp = String(rawDepo).toUpperCase();
            if (dUp.includes('SELCUK') || dUp.includes('SELÇUK')) depoCode = 'SELCUK';
            else if (dUp.includes('ISKOOP') || dUp.includes('İSKOOP')) depoCode = 'ISKOOP';
            else if (dUp.includes('NEVZAT')) depoCode = 'NEVZAT';
            else if (dUp.includes('ALLIANCE')) depoCode = 'ALLIANCE';

            const tiers = [];
            const regex = /([0-9]+)\\s*\\+\\s*([0-9]+)/g;
            let m;
            while ((m = regex.exec(rawMf)) !== null) {
                const alinan = parseInt(m[1], 10);
                const hediye = parseInt(m[2], 10);
                if (alinan > 1 && hediye >= 1) {
                    tiers.push({ alinan, hediye, label: `${alinan}+${hediye}` });
                }
            }
            if (tiers.length === 0) return null;
            tiers.sort((a, b) => a.alinan - b.alinan);

            const aylik = Number(item.aylik_cikis || item.ort_aylik_6m || item.bugun_cikis || 1);
            let matchedTier = null;
            for (const t of tiers) {
                const diff = t.alinan - qty;
                if (diff <= 0) continue;
                const maxDiff = t.alinan <= 5 ? 2 : (t.alinan <= 10 ? 4 : Math.ceil(t.alinan * 0.35));
                const isCloseByQty = diff <= maxDiff && qty >= Math.max(1, t.alinan - maxDiff);
                const isHighVelocityNear = (aylik >= t.alinan * 0.6) && (diff <= Math.max(2, Math.ceil(t.alinan * 0.4)));
                if (isCloseByQty || isHighVelocityNear) {
                    matchedTier = { ...t, diff };
                    break;
                }
            }
            if (!matchedTier) return null;

            const basePrice = Number(item.psf || item.depocu_fiyat || item.net_fiyat || 0);
            const estUnitGain = basePrice > 0 ? Math.round(basePrice * 0.82) : 185;
            const totalExtraProfit = Math.max(25, Math.round(estUnitGain * matchedTier.hediye));

            return {
                diff: matchedTier.diff,
                targetQty: matchedTier.alinan,
                hediye: matchedTier.hediye,
                mfLabel: matchedTier.label,
                depoCode: depoCode,
                depoLabel: rawDepo,
                extraProfit: totalExtraProfit
            };
        }
        window.computeSmartMfBaremAdvice = computeSmartMfBaremAdvice;

        function buildSmartMfBaremAssistantHtml(item, currentQty, contextType, rowIndex) {
            if (window.isLicenseRestricted && window.isLicenseRestricted()) {
                return `
                    <button
                        type="button"
                        onclick="if(window.checkLicenseBeforeAction) window.checkLicenseBeforeAction('MF Asistanı'); event.stopPropagation();"
                        class="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-200 hover:bg-rose-100 text-slate-600 hover:text-rose-800 border border-slate-300 text-[9px] font-extrabold transition cursor-pointer"
                        title="Lisans kısıtlı olduğu için MF Asistanı kilitlidir. Aktif etmek için tıklayın."
                    >
                        <span>🔒 MF Asistanı (Lisans Kısıtlı)</span>
                    </button>
                `;
            }
            const adv = computeSmartMfBaremAdvice(item, currentQty);
            if (!adv) return '';
            const safeMf = String(adv.mfLabel || '').replace(/'/g, "\\'");
            return `
                <button
                    type="button"
                    onclick="applySmartMfBaremSuggestion('${contextType}', ${rowIndex}, ${adv.targetQty}, '${adv.depoCode}', '${safeMf}', ${adv.extraProfit}, event)"
                    class="mt-1 inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white text-[9.5px] font-black shadow-2xs badge-pulse transition cursor-pointer"
                    title="Tıklayın: Sipariş adedini ${adv.targetQty} kutuya tamamla ve ${adv.depoLabel} (${adv.mfLabel} MF) ile +${adv.extraProfit} ₺ ekstra bedelsiz kâr yakala!"
                >
                    <span>💡 +${adv.diff} adet ekle -> ${adv.mfLabel} MF yakala (+${adv.extraProfit} ₺ ekstra kâr)</span>
                </button>
            `;
        }
        window.buildSmartMfBaremAssistantHtml = buildSmartMfBaremAssistantHtml;

        function applySmartMfBaremSuggestion(contextType, rowIndex, targetQty, depoCode, mfLabel, extraProfit, ev) {
            if (ev) {
                ev.stopPropagation();
                ev.preventDefault();
            }
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('MF Asistanı')) return;
            if (contextType === 'critical') {
                const input = document.getElementById(`bulkQtyInput_${rowIndex}`);
                if (input) input.value = targetQty;
                const chk = document.querySelector(`.bulkItemCheck[data-idx="${rowIndex}"]`);
                if (chk) chk.checked = true;
                if (depoCode && typeof setCardDepo === 'function') {
                    setCardDepo(rowIndex, depoCode, false, null);
                }
                syncCriticalDomStateToMaps();
                updateBulkSelectionCount();
                refreshCriticalRowMfAssistant(rowIndex);
                showToast('🎯 MF Baremi Tamamlandı!', `Sipariş adedi ${targetQty} kutu (${depoCode} • ${mfLabel} MF) yapıldı. Tahmini +${extraProfit} ₺ ekstra kâr!`, 'success');
            } else if (contextType === 'smart') {
                if (typeof applySmartMfToRow === 'function') {
                    applySmartMfToRow(rowIndex, targetQty, depoCode, mfLabel);
                }
            }
        }
        window.applySmartMfBaremSuggestion = applySmartMfBaremSuggestion;

        function refreshCriticalRowMfAssistant(index) {
            const slot = document.getElementById(`criticalMfAssistant_${index}`);
            if (!slot) return;
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[index] : null;
            if (!item) {
                slot.innerHTML = '';
                return;
            }
            const input = document.getElementById(`bulkQtyInput_${index}`);
            const curQty = input ? (parseInt(input.value) || 1) : (item.onerilen_siparis || item.bugun_cikis || 1);
            slot.innerHTML = buildSmartMfBaremAssistantHtml(item, curQty, 'critical', index);
        }
        window.refreshCriticalRowMfAssistant = refreshCriticalRowMfAssistant;

        async function triggerBackgroundMfResolution() {
            if (window.isLicenseRestricted && window.isLicenseRestricted()) return;
            if (!showMfBadges || isMfResolutionRunning) return;
            if (!criticalStockItems || criticalStockItems.length === 0) return;

            const uncachedBarcodes = [];
            const seenBc = new Set();
            const priorityList = (window.currentFilteredCriticalItems && window.currentFilteredCriticalItems.length > 0)
                ? window.currentFilteredCriticalItems.concat(criticalStockItems)
                : criticalStockItems;

            priorityList.forEach(it => {
                if (!it) return;
                const bc = (it.barkod || '').toString().trim();
                if (!bc || seenBc.has(bc)) return;
                if (!it.mf_checked && !it.mf_metni && uncachedBarcodes.length < 30) {
                    seenBc.add(bc);
                    uncachedBarcodes.push(bc);
                }
            });

            if (uncachedBarcodes.length === 0) return;

            isMfResolutionRunning = true;
            let hasMoreUnchecked = false;
            try {
                const res = await fetch('/api/otomasyon/resolve-mf', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barcodes: uncachedBarcodes })
                });
                if (res.ok) {
                    const data = await res.json();
                    const results = data.results || {};
                    criticalStockItems.forEach(it => {
                        const bc = (it.barkod || '').toString().trim();
                        if (bc && (bc in results)) {
                            it.mf_checked = true;
                            const mfObj = results[bc];
                            if (mfObj && mfObj.mf) {
                                it.mf_metni = mfObj.mf;
                                it.mf_depo = mfObj.depo || 'Depo';
                                if (mfObj.fiyat && !it.psf) it.psf = Number(mfObj.fiyat);
                            } else {
                                it.mf_metni = null;
                                it.mf_depo = null;
                            }
                        } else if (bc && !it.mf_checked && !it.mf_metni) {
                            hasMoreUnchecked = true;
                        }
                    });
                    updateMfBadgesInDom();
                }
            } catch(e) {
                console.error('MF resolution error:', e);
            } finally {
                isMfResolutionRunning = false;
                if (hasMoreUnchecked && showMfBadges) {
                    setTimeout(() => triggerBackgroundMfResolution(), 350);
                }
            }
        }

        function renderCriticalList() {
            const container = document.getElementById('criticalStockListContainer');
            if (!container) return;
            document.querySelectorAll('body > [id^="cardDepoMenu_"]').forEach(el => el.remove());

            syncCriticalDomStateToMaps();
            window.criticalCheckedMap = window.criticalCheckedMap || {};
            window.criticalCustomQtyMap = window.criticalCustomQtyMap || {};

            const searchInput = document.getElementById('criticalFilterInput');
            const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

            // Sipariş sayacını güncelle
            const totalOrderedCount = (criticalStockItems || []).filter(x => !!x.siparis_durumu).length;
            const ordBadge = document.getElementById('orderedTodayCountBadge');
            if (ordBadge) ordBadge.innerText = `${totalOrderedCount} İşlem`;

            // Tükenen (==0) ve Eksiye Düşen (<0) sayaçlarını güncelle
            const baseForCounts = (criticalStockItems || []).filter(item => {
                if (hideOrderedItems && (item.siparis_durumu === 'SIPARIS_VERILDI' || item.siparis_durumu === 'SIPARIS_VERILMEYECEK')) return false;
                if (q) {
                    const name = (item.urun_adi || '').toLowerCase();
                    const barcode = (item.barkod || '').toLowerCase();
                    if (!name.includes(q) && !barcode.includes(q)) return false;
                }
                return true;
            });
            const zeroCount = baseForCounts.filter(x => Number(x.stok || 0) === 0).length;
            const negativeList = baseForCounts.filter(x => Number(x.stok || 0) < 0);
            const negativeCount = negativeList.length;
            const emanetCount = baseForCounts.filter(x => Number(x.bugun_emanet || 0) > 0).length;

            const zeroBadgeEl = document.getElementById('critZeroCountBadge');
            const negBadgeEl = document.getElementById('critNegativeCountBadge');
            const emBtnEl = document.getElementById('btnCritFilterEmanet');
            const emBadgeEl = document.getElementById('critEmanetCountBadge');
            if (zeroBadgeEl) zeroBadgeEl.innerText = `${zeroCount}`;
            if (negBadgeEl) negBadgeEl.innerText = `${negativeCount}`;
            if (emBadgeEl) emBadgeEl.innerText = `${emanetCount}`;
            if (emBtnEl) {
                emBtnEl.dataset.hasItems = emanetCount > 0 ? '1' : '0';
                if (emanetCount > 0 || criticalFilterMode === 'emanet_only') {
                    emBtnEl.className = criticalFilterMode === 'emanet_only'
                        ? 'px-2 py-1 rounded-md font-bold bg-orange-600 text-white transition text-[10px] cursor-pointer inline-flex items-center space-x-1 shrink-0'
                        : 'px-2 py-0.5 rounded-md font-bold bg-orange-50 hover:bg-orange-100 text-orange-900 border border-orange-300 transition text-[10px] cursor-pointer inline-flex items-center space-x-1 shrink-0';
                } else {
                    emBtnEl.className = 'hidden';
                }
            }

            let filtered = criticalStockItems.filter(item => {
                if (hideOrderedItems && (item.siparis_durumu === 'SIPARIS_VERILDI' || item.siparis_durumu === 'SIPARIS_VERILMEYECEK')) return false;
                const stokVal = Number(item.stok || 0);
                const emanetAdet = Number(item.bugun_emanet || 0);
                const effectiveAylik = Math.max(item.aylik_cikis || 0, (item.bugun_cikis || 0) + emanetAdet || 1);
                const stokGun = item.stok_gun !== undefined ? item.stok_gun : (stokVal <= 0 ? 0 : Math.round((stokVal * 300.0) / effectiveAylik) / 10);
                if (criticalFilterMode === 'days_21' && stokVal > 0 && stokGun > 21) return false;
                if (criticalFilterMode === 'zero' && stokVal !== 0) return false;
                if (criticalFilterMode === 'negative' && stokVal >= 0) return false;
                if (criticalFilterMode === 'emanet_only' && emanetAdet <= 0) return false;
                const hasAnyMf = (item.mf_metni && item.mf_metni !== 'YOK') || !!item.gecmis_mf_var;
                if (criticalFilterMode === 'mf_only' && !hasAnyMf) return false;
                if (q) {
                    const name = (item.urun_adi || '').toLowerCase();
                    const barcode = (item.barkod || '').toLowerCase();
                    return name.includes(q) || barcode.includes(q);
                }
                return true;
            });

            // Normal satışları üstte, sadece emanet verildiği için düşenleri ayrı bir grup halinde altta sırala; işlem görenler en altta kalsın
            filtered.sort((a, b) => {
                const aDone = (a.siparis_durumu === 'SIPARIS_VERILDI' || a.siparis_durumu === 'SIPARIS_VERILMEYECEK' || a.siparis_durumu === 'SEPETTE') ? 1 : 0;
                const bDone = (b.siparis_durumu === 'SIPARIS_VERILDI' || b.siparis_durumu === 'SIPARIS_VERILMEYECEK' || b.siparis_durumu === 'SEPETTE') ? 1 : 0;
                if (aDone !== bDone) return aDone - bDone;
                const aOnlyEm = a.sadece_emanet ? 1 : 0;
                const bOnlyEm = b.sadece_emanet ? 1 : 0;
                if (aOnlyEm !== bOnlyEm) return aOnlyEm - bOnlyEm;
                const aRank = Number(a.stok || 0) < 0 ? 0 : (Number(a.stok || 0) === 0 ? 1 : 2);
                const bRank = Number(b.stok || 0) < 0 ? 0 : (Number(b.stok || 0) === 0 ? 1 : 2);
                if (aRank !== bRank) return aRank - bRank;
                return Number(a.stok_gun || 0) - Number(b.stok_gun || 0);
            });

            if (filtered.length === 0) {
                window.currentFilteredCriticalItems = [];
                let emptyMsg = 'Kriterlere uyan kritik ürün bulunamadı.';
                if (criticalFilterMode === 'negative') emptyMsg = "Bugün çıkışı olup stoğu eksiye (<0) düşen ürün bulunmuyor.";
                else if (criticalFilterMode === 'zero') emptyMsg = "Bugün çıkışı olup stoğu tam 0'a inen ürün bulunmuyor.";
                container.innerHTML = `
                    <div class="p-6 text-center text-slate-400 text-xs bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
                        <i class="fa-solid fa-box-open text-xl text-slate-300 mb-1.5 block"></i>
                        ${emptyMsg}
                    </div>
                `;
                updateBulkSelectionCount();
                return;
            }

            window.currentFilteredCriticalItems = filtered;
            const activeEmanetOnlyCount = filtered.filter(x => x.sadece_emanet && !x.siparis_durumu).length;
            let emanetHeaderRendered = false;

            container.innerHTML = filtered.map((item, index) => {
                const stokVal = Number(item.stok || 0);
                const emanetVal = Number(item.bugun_emanet || 0);
                const isOnlyEmanet = Boolean(item.sadece_emanet || (emanetVal > 0 && Number(item.bugun_cikis || 0) === 0));
                const effectiveAylik = Math.max(item.aylik_cikis || 0, (item.bugun_cikis || 0) + emanetVal || 1);
                const stokGun = item.stok_gun !== undefined ? item.stok_gun : (stokVal <= 0 ? 0 : Math.round((stokVal * 300.0) / effectiveAylik) / 10);
                
                // 3 Renk Kuralına Uygun Büyük & Net Stok Rozeti (Kırmızı / Kehribar / Yeşil)
                let stockBadgeClass = 'bg-slate-100 text-slate-800 border-slate-300';
                let stockLabelHtml = `<span class="text-[10px] font-bold uppercase opacity-75">STOK:</span><span class="text-[13.5px] font-black font-mono leading-none">${stokVal} Kt</span>`;

                if (stokVal < 0) {
                    stockBadgeClass = 'bg-rose-600 text-white border-rose-700 shadow-2xs';
                    stockLabelHtml = `<span class="text-[10px] font-extrabold uppercase opacity-95">STOK:</span><span class="text-[13.5px] font-black font-mono leading-none">${stokVal}</span><span class="text-[10px] font-black leading-none">(EKSİ)</span>`;
                } else if (stokVal === 0) {
                    stockBadgeClass = 'bg-rose-100 text-rose-800 border-rose-300';
                    stockLabelHtml = `<span class="text-[10px] font-extrabold uppercase">STOK:</span><span class="text-[13.5px] font-black font-mono leading-none">0</span><span class="text-[10px] font-black leading-none">(TÜKENDİ)</span>`;
                } else if (stokGun <= 7) {
                    stockBadgeClass = 'bg-rose-50 text-rose-800 border-rose-300';
                    stockLabelHtml = `<span class="text-[10px] font-extrabold uppercase opacity-80">STOK:</span><span class="text-[13.5px] font-black font-mono leading-none">${stokVal} Kt</span><span class="text-[10px] font-bold leading-none opacity-85">(${stokGun}G)</span>`;
                } else if (stokGun <= 14) {
                    stockBadgeClass = 'bg-amber-50 text-amber-900 border-amber-300';
                    stockLabelHtml = `<span class="text-[10px] font-extrabold uppercase opacity-80">STOK:</span><span class="text-[13.5px] font-black font-mono leading-none">${stokVal} Kt</span><span class="text-[10px] font-bold leading-none opacity-85">(${stokGun}G)</span>`;
                } else {
                    stockBadgeClass = 'bg-emerald-50 text-emerald-800 border-emerald-300';
                    stockLabelHtml = `<span class="text-[10px] font-extrabold uppercase opacity-80">STOK:</span><span class="text-[13.5px] font-black font-mono leading-none">${stokVal} Kt</span><span class="text-[10px] font-bold leading-none opacity-85">(${stokGun}G)</span>`;
                }

                const safeName = (item.urun_adi || '').replace(/'/g, "\\\\'");
                const safeBc = (item.barkod || '').replace(/'/g, "\\\\'");
                const itemKey = getCriticalItemKey(item);
                const isAlreadyOrderedOrInCart = !!item.siparis_durumu;

                // Varsayılan olarak hiçbir ürün seçili gelmez; sadece kullanıcının işaretledikleri seçili kalır
                let isInitialSelected = false;
                if (itemKey && window.criticalCheckedMap && typeof window.criticalCheckedMap[itemKey] === 'boolean') {
                    isInitialSelected = isAlreadyOrderedOrInCart ? false : window.criticalCheckedMap[itemKey];
                } else if (itemKey && window.criticalCheckedMap) {
                    window.criticalCheckedMap[itemKey] = false;
                }

                const savedQty = (itemKey && window.criticalCustomQtyMap && window.criticalCustomQtyMap[itemKey])
                    ? window.criticalCustomQtyMap[itemKey]
                    : (item.onerilen_siparis || item.bugun_cikis || 1);
                const hasMf = showMfBadges && item.mf_metni && item.mf_metni !== 'YOK';

                // Kompakt Sipariş Durumu Şeridi
                let orderStatusHtml = '';
                let cardWrapperClass = stokVal < 0
                    ? 'bg-rose-50/30 hover:bg-rose-50/60 border border-rose-200 border-l-4 border-l-rose-600'
                    : (isOnlyEmanet
                        ? 'bg-orange-50/25 hover:bg-orange-50/50 border border-orange-200/90 border-l-4 border-l-orange-500'
                        : 'bg-white hover:bg-slate-50/80 border border-slate-200/90 hover:border-indigo-300');
                if (item.siparis_durumu === 'SIPARIS_VERILDI') {
                    cardWrapperClass = 'bg-emerald-50/40 border border-emerald-300 opacity-80';
                    orderStatusHtml = `
                        <div class="flex items-center justify-between px-2 py-0.5 mb-1 rounded bg-emerald-600 text-white text-[9px] font-bold" onclick="event.stopPropagation()">
                            <span class="truncate"><i class="fa-solid fa-check mr-1"></i>SİPARİŞ VERİLDİ • ${item.siparis_depo || 'DEPO'} (${item.siparis_miktar || 1} Kt)</span>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event)" class="ml-1 px-1 rounded bg-white/20 hover:bg-white/30 text-white text-[8px] cursor-pointer shrink-0">İptal ×</button>
                        </div>
                    `;
                } else if (item.siparis_durumu === 'SIPARIS_VERILMEYECEK') {
                    const isYokList = String(item.siparis_depo || '').toUpperCase() === 'YOK_LISTESI';
                    cardWrapperClass = isYokList
                        ? 'bg-rose-50/40 border border-rose-300 opacity-85'
                        : 'bg-slate-100/70 border border-slate-200 opacity-75';
                    orderStatusHtml = `
                        <div class="flex items-center justify-between px-2 py-0.5 mb-1 rounded ${isYokList ? 'bg-rose-600' : 'bg-slate-600'} text-white text-[9px] font-bold" onclick="event.stopPropagation()">
                            <span class="truncate"><i class="fa-solid ${isYokList ? 'fa-triangle-exclamation' : 'fa-ban'} mr-1"></i>${isYokList ? '🚨 YOK LİSTESİNDE (DEPOLARDA YOK)' : 'SİPARİŞ VERİLMEYECEK'}</span>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event)" class="ml-1 px-1 rounded bg-white/20 hover:bg-white/30 text-white text-[8px] cursor-pointer shrink-0">İptal ×</button>
                        </div>
                    `;
                } else if (item.siparis_durumu === 'SEPETTE') {
                    const firstCartDepo = String(item.siparis_depo || 'ALLIANCE').split('+')[0].trim() || 'ALLIANCE';
                    cardWrapperClass = 'bg-amber-50/40 border border-amber-300';
                    orderStatusHtml = `
                        <div class="flex items-center justify-between px-2 py-0.5 mb-1 rounded bg-amber-100 border border-amber-300 text-amber-950 text-[9px] font-bold" onclick="event.stopPropagation()">
                            <span class="truncate"><i class="fa-solid fa-cart-shopping text-amber-600 mr-1"></i>SEPETTE • ${item.siparis_depo || 'DEPO'} (${item.siparis_miktar || 1} Kt)</span>
                            <div class="flex items-center space-x-1 shrink-0 ml-1">
                                <button type="button" onclick="openMultiDepotCartModal('${firstCartDepo}')" title="Depo sepetini aç ve siparişi depoya gönder" class="px-1.5 py-0.2 rounded bg-indigo-600 hover:bg-indigo-700 text-white text-[8px] font-bold cursor-pointer">🛒 Sepeti Onayla</button>
                                <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event)" class="px-1 py-0.2 rounded bg-white text-slate-600 border border-amber-300 text-[8px] font-bold cursor-pointer">×</button>
                            </div>
                        </div>
                    `;
                }

                // Depo seçimi
                window.cardSelectedDepos = window.cardSelectedDepos || {};
                const activeDeposList = (typeof getActiveBulkDepos === 'function') ? getActiveBulkDepos() : ['ALLIANCE', 'SELCUK', 'ISKOOP', 'NEVZAT'];
                const defaultActiveDepo = activeDeposList[0] || window.defaultQuickDepo || 'ALLIANCE';
                let cardDepo = window.cardSelectedDepos[index];
                if (!cardDepo && item.mf_depo) {
                    const dUpper = String(item.mf_depo).toUpperCase();
                    if (dUpper.includes('ALLIANCE')) cardDepo = 'ALLIANCE';
                    else if (dUpper.includes('SELCUK') || dUpper.includes('SELÇUK')) cardDepo = 'SELCUK';
                    else if (dUpper.includes('ISKOOP') || dUpper.includes('İSKOOP')) cardDepo = 'ISKOOP';
                    else if (dUpper.includes('NEVZAT')) cardDepo = 'NEVZAT';
                }
                if (!cardDepo || !activeDeposList.includes(cardDepo)) {
                    cardDepo = defaultActiveDepo;
                }
                window.cardSelectedDepos[index] = cardDepo;

                const curDepoCfg = (typeof QUICK_DEPO_CONFIGS !== 'undefined' && QUICK_DEPO_CONFIGS[cardDepo]) 
                    ? QUICK_DEPO_CONFIGS[cardDepo] 
                    : { name: 'Alliance Healthcare', shortName: 'Alliance', actionText: "Alliance'a At", bgClass: 'bg-sky-600 hover:bg-sky-700', chevronClass: 'bg-sky-700 hover:bg-sky-800', icon: 'fa-solid fa-truck-fast' };

                // Son 7 Günlük Eczatrend / EczaneTakas Katılım (Kargo/Takas Bekleniyor) Uyarı Şeridi
                let takas7GunHtml = '';
                if (item.takas_7gun_uyari) {
                    const tw = item.takas_7gun_uyari;
                    const twDepo = tw.depo_etiket || tw.depo || 'Takas/Ortak Alım';
                    const twQty = tw.miktar || 1;
                    const twGunLbl = tw.gun_etiketi || 'Son 7 gün içinde katıldı';
                    const twKalan = tw.kalan_gun || 7;
                    takas7GunHtml = `
                        <div class="flex items-center justify-between px-2 py-0.5 mb-1 rounded bg-violet-100 border border-violet-300 text-violet-950 text-[9.5px] font-extrabold shadow-2xs" onclick="event.stopPropagation()" title="${twDepo} üzerinden katılınan ürünler kargo/takas sürecinde olduğu için hemen stoğa girmez (7 gün boyunca uyarı verir). Ürün teslim alındıysa sağdaki × butonuna tıklayarak kapatabilirsiniz.">
                            <span class="truncate"><i class="fa-solid fa-truck-clock text-violet-700 mr-1"></i>⏳ ${twDepo} KATILIMI VAR: ${twQty} Kutu (${twGunLbl} • Yolda, ${twKalan}G)</span>
                            <button type="button" onclick="dismissTakas7DayWarning('${safeBc}', '${safeName}', event)" class="ml-1 px-1 rounded bg-violet-200 hover:bg-rose-500 hover:text-white text-violet-900 text-[8px] font-black cursor-pointer shrink-0 transition" title="Ürün teslim alındıysa veya uyarıyı gizlemek için tıklayın">Geldi/Kapat ×</button>
                        </div>
                    `;
                }

                // Sadece emanet verilerek ≤21 güne düşen ürünler için ayrı bölüm başlığı (normal satışlarla karışmaması için)
                let emanetSectionDividerHtml = '';
                if (isOnlyEmanet && !isAlreadyOrderedOrInCart && !emanetHeaderRendered && criticalFilterMode !== 'emanet_only') {
                    emanetHeaderRendered = true;
                    emanetSectionDividerHtml = `
                        <div class="mt-2.5 mb-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-orange-100/90 via-amber-50 to-white border border-orange-300 flex items-center justify-between shadow-2xs">
                            <div class="flex items-center gap-1.5 text-[10.5px] font-black text-orange-950 tracking-tight">
                                <i class="fa-solid fa-hand-holding-medical text-orange-600"></i>
                                <span>EMANET VERİLEREK KRİTİK STOĞA DÜŞENLER (≤21 GÜN)</span>
                            </div>
                            <span class="px-2 py-0.5 rounded-full bg-orange-600 text-white text-[9.5px] font-black font-mono">${activeEmanetOnlyCount} Kalem</span>
                        </div>
                    `;
                }

                // Çıkış rozetleri: Normal ürünlerde hiçbir emanet ibaresi gösterilmez; yalnızca emanet verilenlerde özel gösterilir
                let todayExitBoxesHtml = '';
                if (isOnlyEmanet) {
                    todayExitBoxesHtml = `
                        <div class="px-2 py-0.5 rounded-lg bg-orange-100 border border-orange-300 inline-flex items-center gap-1" title="Bugün hastaya ${emanetVal} kutu açık emanet verildi (henüz reçetelendirilmedi) ve kalan stok 21 günün altına düştü">
                            <i class="fa-solid fa-hand-holding-medical text-orange-700 text-[10px]"></i>
                            <span class="text-[10px] font-extrabold text-orange-900 uppercase">Emanet Çıkışı:</span>
                            <span class="text-[13px] font-black font-mono text-orange-950 leading-none">${emanetVal}</span>
                        </div>
                    `;
                } else if (emanetVal > 0) {
                    todayExitBoxesHtml = `
                        <div class="px-2 py-0.5 rounded-lg bg-amber-50 border border-amber-200/90 inline-flex items-center gap-1" title="Bugünkü Kesin Satış Adedi: ${item.bugun_cikis} Kutu">
                            <span class="text-[10px] font-extrabold text-amber-800 uppercase">Bugün:</span>
                            <span class="text-[13px] font-black font-mono text-amber-950 leading-none">${item.bugun_cikis}</span>
                        </div>
                        <div class="px-2 py-0.5 rounded-lg bg-orange-100 border border-orange-300 inline-flex items-center gap-1" title="Ek olarak bugün ${emanetVal} kutu açık emanet verildi">
                            <i class="fa-solid fa-hand-holding-medical text-orange-700 text-[9px]"></i>
                            <span class="text-[10px] font-extrabold text-orange-900">+${emanetVal} Emanet</span>
                        </div>
                    `;
                } else {
                    todayExitBoxesHtml = `
                        <div class="px-2 py-0.5 rounded-lg bg-amber-50 border border-amber-200/90 inline-flex items-center gap-1" title="Bugünkü Çıkış / Satış Adedi: ${item.bugun_cikis} Kutu">
                            <span class="text-[10px] font-extrabold text-amber-800 uppercase">Bugün:</span>
                            <span class="text-[13px] font-black font-mono text-amber-950 leading-none">${item.bugun_cikis}</span>
                        </div>
                    `;
                }

                // 2-KATMANLI KOMPAKT SATIR — Üstte Tam İlaç İsmi + BÜYÜK STOK Kutusu, Altta BÜYÜK Bugün/Aylık Çıkış + Sipariş İşlemleri
                return `
                    ${emanetSectionDividerHtml}
                    <div class="${cardWrapperClass} rounded-xl px-3 py-2 transition group">
                        ${orderStatusHtml}
                        ${takas7GunHtml}
                        <!-- 1. KATMAN: Sol: Checkbox + Tam İlaç İsmi + MF — Sağ: BÜYÜK & NET STOK KUTUSU -->
                        <div class="flex items-start justify-between gap-2">
                            <div class="flex items-start space-x-2 min-w-0 flex-1">
                                <input 
                                    type="checkbox" 
                                    style="accent-color: #4f46e5;"
                                    class="bulkItemCheck rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 mt-0.5 cursor-pointer shrink-0" 
                                    data-idx="${index}" 
                                    data-ordered="${isAlreadyOrderedOrInCart ? '1' : '0'}"
                                    onchange="updateBulkSelectionCount()" 
                                    ${isInitialSelected ? 'checked' : ''} 
                                />
                                <div class="cursor-pointer flex-1 min-w-0" onclick="searchFromCriticalByIndex(${index})">
                                    <div class="flex flex-wrap items-center gap-1.5">
                                        <h4 class="font-extrabold text-[13px] leading-snug ${item.siparis_durumu === 'SIPARIS_VERILDI' || item.siparis_durumu === 'SIPARIS_VERILMEYECEK' || item.siparis_durumu === 'SEPETTE' ? 'line-through text-slate-400' : 'text-slate-900 group-hover:text-indigo-700'} break-words" title="Barkod: ${item.barkod || '-'} • Tıklayıp tüm depolarda karşılaştırın">
                                            ${item.urun_adi}
                                        </h4>
                                        <!-- Canlı MF Rozeti (Her Kademe Ayrı Tıklanabilir) -->
                                        <span id="criticalMfBadge_${index}" class="${hasMf ? 'inline-flex flex-wrap items-center gap-1' : 'hidden'}" onclick="event.stopPropagation()">
                                            ${hasMf ? buildCriticalMfTierBadgesHtml(item, index) : ''}
                                        </span>
                                        <!-- Geçmiş MF İkonu (Bilgi amaçlıdır, anlık MF değildir) -->
                                        ${item.gecmis_mf_var ? `
                                            <span class="inline-flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9.5px] leading-none font-bold bg-slate-100 text-slate-600 border border-slate-200 cursor-help" title="${item.gecmis_mf_bilgi || 'Geçmiş faturada MF ile alım yapılmış (Anlık depo MF şartı değildir).'}">
                                                <i class="fa-solid fa-clock-rotate-left text-slate-400 text-[8px]"></i>
                                                <span>G.MF:${item.gecmis_mf_kisa || 'MF'}</span>
                                            </span>
                                        ` : ''}
                                        ${Number(item.son_alis_maliyet || 0) > 0 ? `
                                            <span class="inline-flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9.5px] leading-none font-extrabold bg-emerald-50 text-emerald-800 border border-emerald-200 font-mono" title="Son fatura KDV dahil birim maliyet${item.son_alis_depo ? ' • ' + item.son_alis_depo : ''}${item.son_alis_tarih ? ' (' + item.son_alis_tarih + ')' : ''}${item.son_alis_mf ? ' • ' + item.son_alis_mf : ''}">
                                                <span>Alış:${Number(item.son_alis_maliyet).toFixed(2)}₺</span>
                                            </span>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>

                            <!-- Sağ Üst: BÜYÜK & NET STOK ROZETİ -->
                            <div onclick="searchFromCriticalByIndex(${index})" class="shrink-0 px-2.5 py-1 rounded-lg border ${stockBadgeClass} inline-flex items-center gap-1 cursor-pointer select-none" title="Mevcut Raf Stoğu: ${item.stok} Kutu • Kalan Stok Süresi: ${stokGun} Gün">
                                ${stockLabelHtml}
                            </div>
                        </div>

                        <!-- 2. KATMAN: Sol: BÜYÜK Bugün & Aylık Çıkış Kutuları — Sağ: - [Adet] + & Hızlı Aksiyonlar -->
                        <div class="flex items-center justify-between gap-1.5 mt-1.5 flex-wrap">
                            <!-- Sol: Net Çıkış Kutuları (Bugün / Emanet Çıkışı & Aylık) -->
                            <div class="flex items-center gap-1 cursor-pointer shrink-0 flex-wrap" onclick="searchFromCriticalByIndex(${index})">
                                ${todayExitBoxesHtml}
                                <div class="px-2 py-0.5 rounded-lg bg-slate-100 border border-slate-200/90 inline-flex items-center gap-1" title="Son 30 Günlük Kesin Satış Adedi: ${item.aylik_cikis} Kutu">
                                    <span class="text-[10px] font-bold text-slate-600 uppercase">Aylık:</span>
                                    <span class="text-[13px] font-black font-mono text-slate-900 leading-none">${item.aylik_cikis}</span>
                                </div>
                            </div>

                            <!-- Sağ: - [Adet] + Stepper & Tek Tık Aksiyon Butonları (Taşma Yapmaz) -->
                            <div class="flex items-center gap-1 shrink-0 ml-auto" onclick="event.stopPropagation()">
                                <!-- - [Adet] + -->
                                <div class="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200" title="Sipariş Adedi">
                                    <button type="button" onclick="changeBulkItemQty(${index}, -1)" class="w-5 h-5 rounded bg-white hover:bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-[10px] cursor-pointer">-</button>
                                    <input 
                                        type="number" 
                                        id="bulkQtyInput_${index}" 
                                        value="${savedQty}" 
                                        min="1" 
                                        max="999" 
                                        oninput="onBulkItemQtyInput(${index})" 
                                        class="w-6 text-center text-xs font-black font-mono py-0 border-0 bg-transparent focus:ring-0 text-slate-900" 
                                    />
                                    <button type="button" onclick="changeBulkItemQty(${index}, 1)" class="w-5 h-5 rounded bg-white hover:bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-[10px] cursor-pointer">+</button>
                                </div>

                                <!-- Seçimli Depoya At Split Butonu -->
                                <div class="relative flex items-stretch rounded-lg" id="quickAddWrapper_${index}">
                                    <button 
                                        type="button" 
                                        onclick="sendSingleCriticalToDepo(${index})" 
                                        id="btnQuickAdd_${index}" 
                                        class="h-6 px-1.5 ${curDepoCfg.bgClass} text-white font-bold text-[10px] rounded-l-lg transition flex items-center space-x-1 cursor-pointer"
                                        title="Bu ilacı ${curDepoCfg.name} sepetine ekle"
                                    >
                                        <i class="${curDepoCfg.icon} text-[9px]" id="btnQuickAddIcon_${index}"></i>
                                        <span id="btnQuickAddText_${index}">${curDepoCfg.shortName}</span>
                                    </button>
                                    <button 
                                        type="button" 
                                        onclick="toggleCardDepoMenu(${index}, event)" 
                                        id="btnQuickAddChevron_${index}" 
                                        class="w-3.5 h-6 ${curDepoCfg.chevronClass} text-white/90 hover:text-white border-l border-white/20 rounded-r-lg transition flex items-center justify-center cursor-pointer"
                                        title="Hedef depoyu değiştir"
                                    >
                                        <i class="fa-solid fa-caret-down text-[8px]"></i>
                                    </button>

                                    <!-- Açılır Depo Menüsü -->
                                    <div id="cardDepoMenu_${index}" class="hidden fixed z-[9999] w-44 bg-white border border-slate-200 rounded-xl shadow-2xl py-1 text-xs divide-y divide-slate-100">
                                        <div class="py-0.5">
                                            ${activeDeposList.includes('ALLIANCE') ? `
                                            <button type="button" onclick="setCardDepo(${index}, 'ALLIANCE', false, event)" class="w-full text-left px-2.5 py-1 flex items-center space-x-2 hover:bg-sky-50 text-slate-700 font-semibold cursor-pointer">
                                                <span class="w-2 h-2 rounded-full bg-sky-500 shrink-0"></span>
                                                <span class="flex-1 text-[11px]">Alliance</span>
                                                ${cardDepo === 'ALLIANCE' ? '<i class="fa-solid fa-check text-[10px] text-sky-600"></i>' : ''}
                                            </button>` : ''}
                                            ${activeDeposList.includes('SELCUK') ? `
                                            <button type="button" onclick="setCardDepo(${index}, 'SELCUK', false, event)" class="w-full text-left px-2.5 py-1 flex items-center space-x-2 hover:bg-rose-50 text-slate-700 font-semibold cursor-pointer">
                                                <span class="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
                                                <span class="flex-1 text-[11px]">Selçuk</span>
                                                ${cardDepo === 'SELCUK' ? '<i class="fa-solid fa-check text-[10px] text-rose-600"></i>' : ''}
                                            </button>` : ''}
                                            ${activeDeposList.includes('ISKOOP') ? `
                                            <button type="button" onclick="setCardDepo(${index}, 'ISKOOP', false, event)" class="w-full text-left px-2.5 py-1 flex items-center space-x-2 hover:bg-emerald-50 text-slate-700 font-semibold cursor-pointer">
                                                <span class="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                                                <span class="flex-1 text-[11px]">İSKOOP</span>
                                                ${cardDepo === 'ISKOOP' ? '<i class="fa-solid fa-check text-[10px] text-emerald-600"></i>' : ''}
                                            </button>` : ''}
                                            ${activeDeposList.includes('NEVZAT') ? `
                                            <button type="button" onclick="setCardDepo(${index}, 'NEVZAT', false, event)" class="w-full text-left px-2.5 py-1 flex items-center space-x-2 hover:bg-amber-50 text-slate-700 font-semibold cursor-pointer">
                                                <span class="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                                                <span class="flex-1 text-[11px]">Nevzat</span>
                                                ${cardDepo === 'NEVZAT' ? '<i class="fa-solid fa-check text-[10px] text-amber-600"></i>' : ''}
                                            </button>` : ''}
                                        </div>
                                        <div class="py-0.5">
                                            <button type="button" onclick="setCardDepo(${index}, '${cardDepo}', true, event)" class="w-full text-left px-2.5 py-1 text-[10px] text-slate-600 hover:bg-slate-100 cursor-pointer flex items-center space-x-1 font-bold">
                                                <i class="fa-solid fa-check-double text-[9px] text-indigo-600"></i>
                                                <span>Tümünü buna ayarla</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tek Tık Durum Butonları (Sipariş Verildi / Verilmeyecek / Doğrudan Yok Listesi) -->
                                ${!item.siparis_durumu ? `
                                    <button type="button" onclick="markItemOrderedManually(${index}, event)" class="w-6 h-6 rounded-lg bg-slate-50 hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 border border-slate-200/80 transition flex items-center justify-center cursor-pointer shrink-0" title="Başka yerden sipariş verildi olarak işaretle">
                                        <i class="fa-solid fa-check text-[10px]"></i>
                                    </button>
                                    <button type="button" onclick="markItemSkippedManually(${index}, event)" class="w-6 h-6 rounded-lg bg-slate-50 hover:bg-slate-200 text-slate-500 hover:text-slate-700 border border-slate-200/80 transition flex items-center justify-center cursor-pointer shrink-0" title="Bugün sipariş verilmeyecek olarak işaretle">
                                        <i class="fa-solid fa-ban text-[10px]"></i>
                                    </button>
                                    <button type="button" onclick="markItemYokManually(${index}, event)" class="px-2 h-6 rounded-lg bg-rose-600 hover:bg-rose-700 text-white transition flex items-center gap-1 text-[10px] font-extrabold cursor-pointer shrink-0 shadow-2xs" title="Doğrudan Yok Listesine ekle">
                                        <i class="fa-solid fa-triangle-exclamation text-[9px]"></i>
                                        <span>Yok</span>
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                        <div id="criticalMfAssistant_${index}" onclick="event.stopPropagation()">
                            ${buildSmartMfBaremAssistantHtml(item, savedQty, 'critical', index)}
                        </div>
                    </div>
                `;
            }).join('');

            window.criticalInitialSelectionDone = true;
            updateBulkSelectionCount();
            triggerBackgroundMfResolution();
        }

        function searchFromCriticalByIndex(idx) {
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;

            // 1. Depo sekmesine geç
            if (typeof switchMainView === 'function') {
                switchMainView('depo');
            }

            // 2. Sağ çekmeceyi hemen kapat
            if (typeof toggleSideWidget === 'function') {
                toggleSideWidget(false);
            }

            // 3. Arama inputuna ürün adını veya barkodu yaz
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.value = item.urun_adi || item.barkod;
            }

            // 4. Öneri ve ara seçim kutularını kapat
            const suggestBox = document.getElementById('suggestBox');
            if (suggestBox) suggestBox.classList.add('hidden');
            const productSelection = document.getElementById('productSelection');
            if (productSelection) productSelection.classList.add('hidden');

            // 5. Sayfanın en üstüne yumuşakça kaydır
            window.scrollTo({ top: 0, behavior: 'smooth' });

            // 6. ANINDA CANLI DEPO SORGULAMASINI BAŞLAT
            const barcode = (item.barkod || '').toString().trim();
            const uid = (item.urun_id || item.mal_kodu || '').toString().trim();
            if (barcode && /^\\d{8,14}$/.test(barcode)) {
                performBarcodeSearch(barcode, item.urun_adi || '', uid);
            } else {
                handleSearchSubmit(item.urun_adi || barcode);
            }
        }

        function searchFromCritical(barcodeOrName, title) {
            if (typeof switchMainView === 'function') {
                switchMainView('depo');
            }
            if (typeof toggleSideWidget === 'function') {
                toggleSideWidget(false);
            }
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.value = title || barcodeOrName;
            }
            const suggestBox = document.getElementById('suggestBox');
            if (suggestBox) suggestBox.classList.add('hidden');
            const productSelection = document.getElementById('productSelection');
            if (productSelection) productSelection.classList.add('hidden');
            window.scrollTo({ top: 0, behavior: 'smooth' });

            const q = (barcodeOrName || '').toString().trim();
            if (q && /^\\d{8,14}$/.test(q)) {
                performBarcodeSearch(q, title || '');
            } else {
                handleSearchSubmit(title || q);
            }
        }

        // Global switchTab fonksiyonu (tam uyumluluk)
        function switchTab(t) {
            if (typeof switchMainView === 'function') switchMainView(t);
        }

        function toggleSideWidget(open) {
            const widget = document.getElementById('criticalSideWidget');
            const miniBtn = document.getElementById('criticalMiniBadgeBtn');
            if (!widget || !miniBtn) return;
            if (open) {
                widget.classList.remove('hidden');
                miniBtn.classList.add('hidden');
            } else {
                widget.classList.add('hidden');
                miniBtn.classList.remove('hidden');
            }
        }

        // ================= Toplu Sipariş Gönderici & Akıllı Şelale Dağıtıcısı =================
        function syncMasterCheckboxVisual(isChecked) {
            const masterCheck = document.getElementById('bulkSelectAllCheck');
            const box = document.getElementById('bulkSelectAllVisualBox');
            const icon = document.getElementById('bulkSelectAllVisualIcon');
            if (masterCheck) {
                masterCheck.checked = !!isChecked;
                masterCheck.indeterminate = false;
            }
            if (box) {
                box.className = isChecked
                    ? 'w-4 h-4 rounded border-2 border-sky-600 bg-sky-600 text-white flex items-center justify-center transition-all shadow-2xs group-hover:ring-2 group-hover:ring-sky-300'
                    : 'w-4 h-4 rounded border-2 border-slate-400 bg-white text-transparent flex items-center justify-center transition-all shadow-2xs group-hover:border-sky-500';
            }
            if (icon) {
                icon.className = isChecked
                    ? 'fa-solid fa-check text-[10px] leading-none text-white opacity-100'
                    : 'fa-solid fa-check text-[10px] leading-none text-transparent opacity-0';
            }
        }

        function handleMasterSelectClick(ev) {
            if (ev) {
                ev.preventDefault();
                ev.stopPropagation();
            }
            const masterCheck = document.getElementById('bulkSelectAllCheck');
            const allChecks = Array.from(document.querySelectorAll('.bulkItemCheck'));
            if (allChecks.length === 0) {
                syncMasterCheckboxVisual(false);
                return;
            }
            const currentlyChecked = masterCheck ? !!masterCheck.checked : false;
            const nextState = !currentlyChecked;
            if (masterCheck) masterCheck.checked = nextState;
            toggleBulkSelectAll(masterCheck || { checked: nextState });
        }

        function updateBulkSelectionCount(preserveMaster = false) {
            syncCriticalDomStateToMaps();
            const allChecks = Array.from(document.querySelectorAll('.bulkItemCheck'));
            const checkedChecks = allChecks.filter(c => c.checked);
            const count = checkedChecks.length;
            const badge = document.getElementById('bulkSelectedBadge');
            const masterCheck = document.getElementById('bulkSelectAllCheck');

            if (badge) badge.innerText = `${count} Seçili`;
            const distText = document.getElementById('btnDistributeCriticalText');
            if (distText) {
                if (count > 0) {
                    const selDepos = new Set();
                    checkedChecks.forEach(c => {
                        const idx = parseInt(c.dataset.idx);
                        const d = (window.cardSelectedDepos && window.cardSelectedDepos[idx]) || window.defaultQuickDepo || 'ALLIANCE';
                        selDepos.add(d);
                    });
                    distText.innerText = selDepos.size > 1
                        ? `Seçili Depolara Dağıt (${selDepos.size} Depo • ${count})`
                        : `Seçili Depolara Dağıt (${count})`;
                } else {
                    distText.innerText = 'Seçili Depolara Dağıt';
                }
            }
            if (masterCheck) {
                if (!preserveMaster) {
                    const unorderedChecks = allChecks.filter(c => c.dataset.ordered !== '1');
                    const targetPool = unorderedChecks.length > 0 ? unorderedChecks : allChecks;
                    const isAllSelected = targetPool.length > 0 && targetPool.every(c => c.checked);
                    syncMasterCheckboxVisual(isAllSelected);
                } else {
                    syncMasterCheckboxVisual(!!masterCheck.checked);
                }
            }
        }

        function toggleBulkSelectAll(master) {
            const allChecks = Array.from(document.querySelectorAll('.bulkItemCheck'));
            const shouldSelect = !!(master && master.checked);
            if (shouldSelect) {
                const unorderedChecks = allChecks.filter(c => c.dataset.ordered !== '1');
                if (unorderedChecks.length > 0) {
                    allChecks.forEach(c => {
                        c.checked = (c.dataset.ordered !== '1');
                    });
                } else {
                    allChecks.forEach(c => {
                        c.checked = true;
                    });
                }
                syncMasterCheckboxVisual(true);
            } else {
                allChecks.forEach(c => {
                    c.checked = false;
                });
                syncMasterCheckboxVisual(false);
            }
            syncCriticalDomStateToMaps();
            updateBulkSelectionCount(true);
        }

        function selectTopNItems(n = 40) {
            const checks = document.querySelectorAll('.bulkItemCheck');
            let selectedSoFar = 0;
            checks.forEach((c) => {
                if (c.dataset.ordered !== '1' && selectedSoFar < n) {
                    c.checked = true;
                    selectedSoFar++;
                } else {
                    c.checked = false;
                }
            });
            syncCriticalDomStateToMaps();
            updateBulkSelectionCount(false);
        }

        function clearBulkSelection() {
            const checks = document.querySelectorAll('.bulkItemCheck');
            checks.forEach(c => c.checked = false);
            if (window.criticalCheckedMap) {
                Object.keys(window.criticalCheckedMap).forEach(k => {
                    window.criticalCheckedMap[k] = false;
                });
            }
            syncCriticalDomStateToMaps();
            syncMasterCheckboxVisual(false);
            updateBulkSelectionCount(true);
        }

        function changeBulkItemQty(idx, delta) {
            const input = document.getElementById(`bulkQtyInput_${idx}`);
            if (!input) return;
            let val = parseInt(input.value) || 1;
            val = Math.max(1, val + delta);
            input.value = val;
            const chk = document.querySelector(`.bulkItemCheck[data-idx="${idx}"]`);
            if (chk) {
                chk.checked = true;
            }
            syncCriticalDomStateToMaps();
            updateBulkSelectionCount();
            if (typeof refreshCriticalRowMfAssistant === 'function') refreshCriticalRowMfAssistant(idx);
        }

        function onBulkItemQtyInput(idx) {
            const chk = document.querySelector(`.bulkItemCheck[data-idx="${idx}"]`);
            if (chk) {
                chk.checked = true;
            }
            syncCriticalDomStateToMaps();
            updateBulkSelectionCount();
            if (typeof refreshCriticalRowMfAssistant === 'function') refreshCriticalRowMfAssistant(idx);
        }

        const DEPO_CART_META = {
            'ALLIANCE': {
                code: 'ALLIANCE',
                name: 'Alliance Healthcare',
                shortName: 'Alliance',
                portalUrl: 'https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart',
                pillClass: 'bg-sky-500/25 hover:bg-sky-500/40 text-sky-200 border-sky-400/40',
                headerPillClass: 'bg-sky-100 text-sky-800 border-sky-300',
                cardHeaderClass: 'from-sky-900 via-sky-800 to-slate-900',
                badgeClass: 'bg-sky-600 text-white'
            },
            'SELCUK': {
                code: 'SELCUK',
                name: 'Selçuk Ecza Deposu',
                shortName: 'Selçuk',
                portalUrl: 'https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx',
                pillClass: 'bg-rose-500/25 hover:bg-rose-500/40 text-rose-200 border-rose-400/40',
                headerPillClass: 'bg-rose-100 text-rose-800 border-rose-300',
                cardHeaderClass: 'from-rose-900 via-rose-800 to-slate-900',
                badgeClass: 'bg-rose-600 text-white'
            },
            'ISKOOP': {
                code: 'ISKOOP',
                name: 'İstanbul Ecza Koop (İSKOOP)',
                shortName: 'İSKOOP',
                portalUrl: 'https://esube.iskoop.org/FrameWorkT1/#/baskets',
                pillClass: 'bg-emerald-500/25 hover:bg-emerald-500/40 text-emerald-200 border-emerald-400/40',
                headerPillClass: 'bg-emerald-100 text-emerald-800 border-emerald-300',
                cardHeaderClass: 'from-emerald-900 via-teal-800 to-slate-900',
                badgeClass: 'bg-emerald-600 text-white'
            },
            'NEVZAT': {
                code: 'NEVZAT',
                name: 'Nevzat Ecza Deposu',
                shortName: 'Nevzat',
                portalUrl: 'http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx',
                pillClass: 'bg-amber-500/25 hover:bg-amber-500/40 text-amber-200 border-amber-400/40',
                headerPillClass: 'bg-amber-100 text-amber-900 border-amber-300',
                cardHeaderClass: 'from-amber-900 via-orange-800 to-slate-900',
                badgeClass: 'bg-amber-600 text-white'
            },
            'BEK': {
                code: 'BEK',
                name: 'Bursa Ecza Koop (BEK)',
                shortName: 'BEK',
                portalUrl: 'https://eticaret.bek.org.tr/',
                pillClass: 'bg-indigo-500/25 hover:bg-indigo-500/40 text-indigo-200 border-indigo-400/40',
                headerPillClass: 'bg-indigo-100 text-indigo-800 border-indigo-300',
                cardHeaderClass: 'from-indigo-900 via-indigo-800 to-slate-900',
                badgeClass: 'bg-indigo-600 text-white'
            },
            'DNA': {
                code: 'DNA',
                name: 'DNA Ecza Deposu',
                shortName: 'DNA',
                portalUrl: '#',
                pillClass: 'bg-purple-500/25 hover:bg-purple-500/40 text-purple-200 border-purple-400/40',
                headerPillClass: 'bg-purple-100 text-purple-800 border-purple-300',
                cardHeaderClass: 'from-purple-900 via-purple-800 to-slate-900',
                badgeClass: 'bg-purple-600 text-white'
            }
        };

        window.singleAddDepoMeta = window.singleAddDepoMeta || {};
        window.activeMultiDepotCartTab = window.activeMultiDepotCartTab || 'ALL';

        function recordDepotSessionFromSingleAdd(depo, sepetTutari, sepetNo, portalUrl, addedItem = null) {
            const dKey = (depo || 'SELCUK').toUpperCase();
            window.singleAddDepoMeta = window.singleAddDepoMeta || {};
            const prev = window.singleAddDepoMeta[dKey] || {};
            const effPortal = portalUrl || prev.portalUrl || (DEPO_CART_META[dKey] && DEPO_CART_META[dKey].portalUrl) || '';
            window.singleAddDepoMeta[dKey] = {
                sepetTutari: sepetTutari || prev.sepetTutari || '',
                sepetNo: sepetNo || prev.sepetNo || '',
                portalUrl: effPortal
            };
            if (!window.currentBulkState) {
                window.currentBulkState = {
                    depo: dKey,
                    initialDepo: dKey,
                    triedDepos: [dKey],
                    requestedItems: [],
                    depoSessions: {},
                    missingItems: [],
                    preservedResults: [],
                    allResults: []
                };
            }
            window.currentBulkState.depoSessions = window.currentBulkState.depoSessions || {};
            window.currentBulkState.allResults = Array.isArray(window.currentBulkState.allResults) ? window.currentBulkState.allResults : [];
            if (addedItem && (addedItem.barcode || addedItem.name)) {
                const bc = String(addedItem.barcode || '').trim();
                const nm = String(addedItem.name || '').trim();
                const qty = Math.max(1, parseInt(addedItem.miktar, 10) || 1);
                const uid = String(addedItem.urun_id || '').trim();
                const existingIdx = window.currentBulkState.allResults.findIndex(r =>
                    r && String(r.assigned_depo || '').toUpperCase() === dKey &&
                    ((bc && r.barcode && String(r.barcode).trim() === bc) || (!bc && nm && String(r.name || '').trim().toUpperCase() === nm.toUpperCase()))
                );
                const entryObj = {
                    barcode: bc,
                    name: nm || bc,
                    miktar: qty,
                    urun_id: uid,
                    target_depo: dKey,
                    status: 'ADDED',
                    assigned_depo: dKey,
                    net_fiyat: parseFloat(addedItem.net_fiyat || 0) || 0,
                    vade: parseInt(addedItem.vade || 30, 10) || 30,
                    message: 'Sepete Eklendi'
                };
                if (existingIdx >= 0) {
                    window.currentBulkState.allResults[existingIdx] = entryObj;
                } else {
                    window.currentBulkState.allResults.push(entryObj);
                }
            }
            const metaCfg = DEPO_CART_META[dKey] || { name: dKey };
            const activeForDepo = [
                ...(window.currentBulkState.preservedResults || []),
                ...(window.currentBulkState.allResults || [])
            ].filter(r => r && r.status === 'ADDED' && String(r.assigned_depo || '').toUpperCase() === dKey).length;
            const parsedAmt = parseFloat(String(sepetTutari || '0').replace(/\\./g, '').replace(',', '.')) || 0;
            const prevSess = window.currentBulkState.depoSessions[dKey] || {};
            window.currentBulkState.depoSessions[dKey] = {
                count: Math.max(activeForDepo, (prevSess.finalized || prevSess.cleared) ? 0 : (prevSess.count || 0), addedItem ? 1 : 0),
                amount: parsedAmt > 0 ? parsedAmt : ((prevSess.finalized || prevSess.cleared) ? 0 : (prevSess.amount || 0)),
                name: prevSess.name || metaCfg.name || dKey,
                cartUrl: effPortal || prevSess.cartUrl || '#',
                finalized: false,
                cleared: false
            };
        }

        function getActiveCartGroupsByDepo() {
            const ordersMap = window.todayOrdersMap || {};
            const groups = {};
            const seenPerDepo = {};

            function ensureDepoGroup(depoCode) {
                const dKey = (depoCode || 'SELCUK').toUpperCase();
                if (!groups[dKey]) {
                    const meta = DEPO_CART_META[dKey] || {
                        code: dKey,
                        name: dKey,
                        shortName: dKey,
                        portalUrl: '#',
                        pillClass: 'bg-indigo-500/25 hover:bg-indigo-500/40 text-indigo-200 border-indigo-300/40',
                        headerPillClass: 'bg-indigo-100 text-indigo-800 border-indigo-300',
                        cardHeaderClass: 'from-indigo-900 via-slate-800 to-slate-900',
                        badgeClass: 'bg-indigo-600 text-white'
                    };
                    const bulkSess = (window.currentBulkState && window.currentBulkState.depoSessions && window.currentBulkState.depoSessions[dKey]) || {};
                    const singleMeta = (window.singleAddDepoMeta && window.singleAddDepoMeta[dKey]) || {};
                    groups[dKey] = {
                        ...meta,
                        portalUrl: bulkSess.portal_url || singleMeta.portalUrl || meta.portalUrl,
                        sepetTutari: singleMeta.sepetTutari || (bulkSess.amount ? bulkSess.amount.toFixed(2) : ''),
                        sepetNo: singleMeta.sepetNo || '',
                        items: [],
                        totalBoxes: 0
                    };
                    seenPerDepo[dKey] = new Set();
                }
                return groups[dKey];
            }

            // 1. /api/orders/today üzerindeki SEPETTE kayıtları (Hem tekli aramadan hem günlük/6 aylık siparişten eklenenler)
            for (const [rawKey, entry] of Object.entries(ordersMap)) {
                if (!entry || entry.durum !== 'SEPETTE') continue;
                if (rawKey.startsWith('NAME:') || rawKey.startsWith('CART:')) continue;
                const rawDepoStr = String(entry.depo || 'SELCUK').trim().toUpperCase();
                const depoParts = rawDepoStr.split('+').map(s => s.trim()).filter(Boolean);
                if (depoParts.length === 0) continue;

                const rawBc = (entry.barkod || '').toString().trim();
                const bc = rawBc || (!rawKey.includes(' ') && /^\d+$/.test(rawKey) ? rawKey : '');
                const nm = (entry.urun_adi || '').toString().trim();
                const normName = nm.toUpperCase();
                const normBc = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;

                for (const dKey of depoParts) {
                    const grp = ensureDepoGroup(dKey);
                    const dedupKey = normName || normBc || rawKey;
                    if (seenPerDepo[dKey].has(dedupKey) || (normBc && seenPerDepo[dKey].has(`BC:${normBc}`))) {
                        continue;
                    }
                    seenPerDepo[dKey].add(dedupKey);
                    if (normBc) seenPerDepo[dKey].add(`BC:${normBc}`);

                    const qty = parseInt(entry.miktar) || 1;
                    grp.items.push({
                        barkod: bc,
                        urun_adi: nm || bc || rawKey,
                        miktar: qty,
                        saat: entry.saat || '--:--',
                        masa_adi: entry.masa_adi || entry.masa || 'Eczane PC'
                    });
                    grp.totalBoxes += qty;
                }
            }

            // 2. Henüz senkronize olmamış anlık toplu/tekli sepet hafızası varsa onu da dahil et
            const state = window.currentBulkState || {};
            const sessions = state.depoSessions || {};
            const localMemItems = [
                ...(Array.isArray(state.preservedResults) ? state.preservedResults : []),
                ...(Array.isArray(state.allResults) ? state.allResults : [])
            ];
            if (localMemItems.length > 0) {
                localMemItems.forEach(r => {
                    if (!r || r.status !== 'ADDED') return;
                    const dKey = (r.assigned_depo || state.depo || 'SELCUK').toUpperCase();
                    const sess = sessions[dKey];
                    if (sess && (sess.finalized || sess.cleared)) return;
                    const grp = ensureDepoGroup(dKey);
                    const bc = (r.barcode || '').toString().trim();
                    const nm = (r.name || '').toString().trim();
                    const normName = nm.toUpperCase();
                    const normBc = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;
                    const dedupKey = normName || normBc;
                    if (!dedupKey) return;
                    if (seenPerDepo[dKey].has(dedupKey) || (normBc && seenPerDepo[dKey].has(`BC:${normBc}`))) return;
                    seenPerDepo[dKey].add(dedupKey);
                    if (normBc) seenPerDepo[dKey].add(`BC:${normBc}`);
                    const qty = parseInt(r.miktar) || 1;
                    grp.items.push({
                        barkod: bc,
                        urun_adi: nm || bc,
                        urun_id: r.urun_id || '',
                        miktar: qty,
                        saat: 'Az Önce',
                        masa_adi: window.currentPcName || 'Bu PC'
                    });
                    grp.totalBoxes += qty;
                });
            }

            // Boş grupları temizle
            Object.keys(groups).forEach(k => {
                if (!groups[k].items || groups[k].items.length === 0) {
                    delete groups[k];
                }
            });

            return groups;
        }

        function updateMultiDepotCartUI() {
            const floatEl = document.getElementById('floatingMiniBulkCart');
            const drawerBar = document.getElementById('drawerMiniBulkResumeBar');
            const multiModal = document.getElementById('multiDepotCartModal');
            const isMultiModalOpen = multiModal && !multiModal.classList.contains('hidden') && multiModal.style.display !== 'none';

            if (drawerBar) drawerBar.classList.add('hidden');

            const groups = getActiveCartGroupsByDepo();
            const depoKeys = Object.keys(groups);
            let totalCartItems = 0;
            let totalCartBoxes = 0;
            const masaSet = new Set();
            depoKeys.forEach(k => {
                totalCartItems += groups[k].items.length;
                totalCartBoxes += groups[k].totalBoxes;
                groups[k].items.forEach(it => {
                    if (it.masa_adi && it.masa_adi !== 'Toplu Sipariş') {
                        masaSet.add(it.masa_adi);
                    }
                });
            });

            // Sol Alt Mavi Çoklu-PC & Depo Sepet Bildirim Çubuğu (#floatingMiniBulkCart)
            if (floatEl) {
                if (totalCartItems > 0 && !isMultiModalOpen) {
                    floatEl.classList.remove('hidden');
                    const fBadge = document.getElementById('floatingMiniBulkBadgeCount');
                    const fTitle = document.getElementById('floatingMiniBulkTitle');
                    const fSub = document.getElementById('floatingMiniBulkSub');
                    const fPills = document.getElementById('floatingDepotCartPills');
                    if (fBadge) fBadge.innerText = String(totalCartItems);
                    if (fTitle) {
                        fTitle.innerText = `${depoKeys.length} Depoda ${totalCartItems} Kalem (${totalCartBoxes} Kutu) Sepette Bekliyor`;
                    }
                    if (fSub) {
                        const masaArr = Array.from(masaSet);
                        const masaTxt = masaArr.length > 0 ? `🖥️ ${masaArr.join(', ')} tarafından eklendi • ` : '';
                        fSub.innerText = `${masaTxt}Sepeti incelemek veya siparişi onaylamak için tıklayın`;
                    }
                    if (fPills) {
                        fPills.innerHTML = depoKeys.map(k => {
                            const g = groups[k];
                            return `
                                <div class="inline-flex items-center rounded-lg overflow-hidden border border-sky-400/40 bg-white/10">
                                    <button type="button" onclick="event.stopPropagation(); openMultiDepotCartModal('${k}');" class="px-2 py-1 text-[10px] font-black text-white hover:bg-white/15 transition cursor-pointer flex items-center space-x-1" title="${g.name} sepetindeki ürünleri gör">
                                        <span>${g.shortName}: ${g.items.length} Kalem (${g.totalBoxes} Kt)</span>
                                    </button>
                                    <button type="button" onclick="event.stopPropagation(); openBulkFinalizeFlow('${k}');" class="px-2 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-[9.5px] font-black transition cursor-pointer" title="${g.name} siparişini sonlandır ve depoya gönder">
                                        ✓ Onayla
                                    </button>
                                </div>
                            `;
                        }).join('');
                    }
                } else {
                    floatEl.classList.add('hidden');
                }
            }

            // Tek ve Şık Üst Bar Sepet Butonu (#headerCartBtn) Güncellemesi
            const hdrBadge = document.getElementById('headerCartCountBadge');
            const hdrPills = document.getElementById('headerCartDepotPills');
            const hdrBtn = document.getElementById('headerCartBtn');
            if (hdrBadge) {
                hdrBadge.innerText = totalCartItems;
                hdrBadge.className = totalCartItems > 0
                    ? 'px-1.5 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black leading-none'
                    : 'px-1.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-black leading-none';
            }
            if (hdrBtn) {
                hdrBtn.className = totalCartItems > 0
                    ? 'inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl font-bold bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-400 transition cursor-pointer whitespace-nowrap shrink-0'
                    : 'inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 transition cursor-pointer whitespace-nowrap shrink-0';
                if (depoKeys.length > 0) {
                    const summaryTip = depoKeys.map(k => `${groups[k].shortName}: ${groups[k].items.length} kalem`).join(' • ');
                    hdrBtn.title = `Depo Sepetlerim (${summaryTip}) — Detaylar için tıklayın`;
                } else {
                    hdrBtn.title = 'Depo Sepetlerim: Sepetteki ürünleri depolara göre inceleyin ve sepete gidin';
                }
            }
            if (hdrPills) {
                if (depoKeys.length > 0) {
                    hdrPills.className = 'hidden 2xl:inline-flex items-center gap-1 ml-0.5';
                    hdrPills.innerHTML = depoKeys.map(k => {
                        const g = groups[k];
                        return `<span onclick="event.stopPropagation(); openMultiDepotCartModal('${k}');" class="px-1.5 py-0.5 rounded-md border text-[9px] font-black ${g.headerPillClass} hover:opacity-80 cursor-pointer" title="${g.name} sepetinde ${g.items.length} kalem (${g.totalBoxes} kutu) ürün var">${g.shortName}:${g.items.length}</span>`;
                    }).join('');
                } else {
                    hdrPills.innerHTML = '';
                    hdrPills.className = 'hidden';
                }
            }

            if (isMultiModalOpen) {
                renderMultiDepotCartModal();
            }
        }

        const updateMiniBulkCartUI = updateMultiDepotCartUI;

        function openMultiDepotCartModal(focusDepo = null) {
            const modal = document.getElementById('multiDepotCartModal');
            if (!modal) return;
            const groups = getActiveCartGroupsByDepo();
            const depoKeys = Object.keys(groups);
            if (focusDepo && groups[focusDepo.toUpperCase()]) {
                window.activeMultiDepotCartTab = focusDepo.toUpperCase();
            } else if (window.activeMultiDepotCartTab !== 'ALL' && !groups[window.activeMultiDepotCartTab]) {
                window.activeMultiDepotCartTab = 'ALL';
            } else if (!focusDepo) {
                window.activeMultiDepotCartTab = 'ALL';
            }
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
            renderMultiDepotCartModal();
            const floatEl = document.getElementById('floatingMiniBulkCart');
            if (floatEl) floatEl.classList.add('hidden');
        }

        function closeMultiDepotCartModal() {
            const modal = document.getElementById('multiDepotCartModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
            updateMultiDepotCartUI();
        }

        function switchMultiDepotCartTab(tabKey) {
            window.activeMultiDepotCartTab = tabKey || 'ALL';
            renderMultiDepotCartModal();
        }

        function renderMultiDepotCartModal() {
            const tabsEl = document.getElementById('multiDepotCartTabs');
            const bodyEl = document.getElementById('multiDepotCartBody');
            const summaryBadge = document.getElementById('multiCartTotalSummaryBadge');
            const missingBtn = document.getElementById('multiCartMissingBulkBtn');
            if (!tabsEl || !bodyEl) return;

            const groups = getActiveCartGroupsByDepo();
            const depoKeys = Object.keys(groups);
            let totalItems = 0;
            let totalBoxes = 0;
            depoKeys.forEach(k => {
                totalItems += groups[k].items.length;
                totalBoxes += groups[k].totalBoxes;
            });

            if (summaryBadge) {
                summaryBadge.innerText = `${depoKeys.length} Depo • ${totalItems} Kalem (${totalBoxes} Kutu)`;
            }

            const missingList = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];
            if (missingBtn) {
                if (missingList.length > 0) {
                    missingBtn.classList.remove('hidden');
                    missingBtn.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1"></i>${missingList.length} Eksik Ürün Raporu`;
                } else {
                    missingBtn.classList.add('hidden');
                }
            }

            if (depoKeys.length === 0) {
                tabsEl.innerHTML = `<span class="text-xs font-bold text-slate-500">Şu anda hiçbir deponun sepetinde bekleyen ürün bulunmuyor.</span>`;
                bodyEl.innerHTML = `
                    <div class="text-center py-14 bg-white rounded-3xl border border-slate-200 shadow-2xs">
                        <div class="w-16 h-16 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto text-2xl mb-3">
                            <i class="fa-solid fa-cart-shopping"></i>
                        </div>
                        <h4 class="text-base font-black text-slate-800">Depo Sepetleriniz Şu An Boş</h4>
                        <p class="text-xs text-slate-500 mt-1 max-w-md mx-auto">Tekli ürün aramasından, Günün Çıkışlarından veya 6 Aylık Çıkış listesinden herhangi bir depoya ürün eklediğinizde burada depolara göre ayrı ayrı listelenir.</p>
                    </div>
                `;
                return;
            }

            const activeTab = (window.activeMultiDepotCartTab !== 'ALL' && groups[window.activeMultiDepotCartTab])
                ? window.activeMultiDepotCartTab
                : 'ALL';

            // Sekmeleri oluştur
            let tabsHtml = `
                <button type="button" onclick="switchMultiDepotCartTab('ALL')" class="px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${activeTab === 'ALL' ? 'bg-slate-900 text-white shadow-sm' : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-300'}">
                    <i class="fa-solid fa-layer-group"></i>
                    <span>Tüm Depo Sepetleri</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] ${activeTab === 'ALL' ? 'bg-amber-400 text-slate-950' : 'bg-slate-200 text-slate-700'}">${totalItems} Kalem</span>
                </button>
            `;
            depoKeys.forEach(k => {
                const g = groups[k];
                const isAct = activeTab === k;
                tabsHtml += `
                    <button type="button" onclick="switchMultiDepotCartTab('${k}')" class="px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${isAct ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-300'}">
                        <i class="fa-solid fa-cart-shopping"></i>
                        <span>${g.name}</span>
                        <span class="px-2 py-0.5 rounded-full text-[10px] ${isAct ? 'bg-white text-indigo-900' : 'bg-indigo-50 text-indigo-700'}">${g.items.length} Kalem (${g.totalBoxes} Kutu)</span>
                    </button>
                `;
            });
            tabsEl.innerHTML = tabsHtml;

            // Gösterilecek depolar
            const displayKeys = activeTab === 'ALL' ? depoKeys : [activeTab];
            bodyEl.innerHTML = displayKeys.map(k => {
                const g = groups[k];
                const rowsHtml = g.items.map((it, idx) => {
                    const safeBc = (it.barkod || '').replace(/'/g, "\\'");
                    const safeNm = (it.urun_adi || '').replace(/'/g, "\\'");
                    return `
                        <tr class="hover:bg-slate-50 transition border-b border-slate-100 last:border-0">
                            <td class="py-2 px-3 text-xs font-bold text-slate-400 w-8">${idx + 1}</td>
                            <td class="py-2 px-3">
                                <div onclick="closeMultiDepotCartModal(); searchProductByBarcode('${safeBc || safeNm}');" class="text-xs font-black text-slate-800 hover:text-indigo-600 cursor-pointer transition" title="Fiyatları görmek için tıklayın">${it.urun_adi}</div>
                                <div class="text-[10px] text-slate-400 font-mono">${it.barkod ? `${it.barkod}` : 'İsimle Eşleşti'} • ${it.saat} (${it.masa_adi})</div>
                            </td>
                            <td class="py-2 px-3 text-center">
                                <span class="inline-flex items-center px-2 py-0.5 rounded-lg bg-amber-100 text-amber-900 font-black text-xs border border-amber-300">
                                    ${it.miktar} Kutu
                                </span>
                            </td>
                            <td class="py-2 px-3 text-right">
                                <button type="button" onclick="removeCartItemFromModal('${safeBc}', '${safeNm}', '${g.code}')" class="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-[11px] font-bold border border-rose-200 transition cursor-pointer" title="Listeden çıkar">
                                    <i class="fa-solid fa-xmark mr-0.5"></i>Çıkar
                                </button>
                            </td>
                        </tr>
                    `;
                }).join('');

                return `
                    <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                        <!-- Depo Kart Başlığı (Tek Satır Sade Aksiyon Çubuğu) -->
                        <div class="px-4 py-3 bg-gradient-to-r ${g.cardHeaderClass} text-white flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                            <div class="flex items-center space-x-2.5">
                                <div class="w-9 h-9 rounded-xl bg-white/15 border border-white/25 flex items-center justify-center text-sm font-black shrink-0">
                                    <i class="fa-solid fa-truck-medical"></i>
                                </div>
                                <div>
                                    <div class="flex flex-wrap items-center gap-1.5">
                                        <h4 class="text-sm font-black text-white">${g.name} Sepeti</h4>
                                        <span class="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black">${g.items.length} Kalem • ${g.totalBoxes} Kutu</span>
                                        ${g.sepetTutari ? `<span class="px-2 py-0.5 rounded-full bg-white/15 text-white text-[10px] font-mono font-bold">${g.sepetTutari} ₺</span>` : ''}
                                    </div>
                                </div>
                            </div>
                            <div class="flex flex-wrap items-center gap-1.5 shrink-0">
                                <button type="button" onclick="clearDepotCartFromModal('${g.code}')" class="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-rose-500/80 text-white/90 hover:text-white border border-white/20 text-[11px] font-bold transition flex items-center gap-1 cursor-pointer" title="${g.shortName} sepetini boşalt">
                                    <i class="fa-solid fa-trash-can text-[10px]"></i>
                                    <span>Boşalt</span>
                                </button>
                                ${g.portalUrl && g.portalUrl !== '#' ? `
                                    <button type="button" onclick="openAuthenticatedPortal('${g.code}', '${g.portalUrl}')" class="px-2.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-[11px] border border-white/20 transition flex items-center gap-1 cursor-pointer" title="Hazır oturumla ${g.shortName} web sepetini aç">
                                        <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                                        <span>Portal ↗</span>
                                    </button>
                                ` : ''}
                                <button type="button" onclick="openBulkFinalizeFlow('${g.code}')" class="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs shadow-sm transition flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-paper-plane text-[10px]"></i>
                                    <span>Siparişi Sonlandır & Gönder</span>
                                </button>
                            </div>
                        </div>

                        <!-- Ürün Tablosu -->
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="bg-slate-50 border-b border-slate-200 text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">
                                        <th class="py-1.5 px-3 w-8">#</th>
                                        <th class="py-1.5 px-3">Sepetteki Ürün Adı & Barkod</th>
                                        <th class="py-1.5 px-3 text-center w-28">Miktar</th>
                                        <th class="py-1.5 px-3 text-right w-24">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${rowsHtml}
                                </tbody>
                            </table>
                        </div>
                    </div>
                `;
            }).join('');
        }

        async function removeCartItemFromModal(barkod, urunAdi, depo = '') {
            try {
                await fetch('/api/orders/today/unmark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barkod: barkod || '', urun_adi: urunAdi || '', depo: depo || '' })
                });
                // Toplu/tekli sepet hafızasında varsa oradan da düş
                if (window.currentBulkState) {
                    const targetDepoUp = String(depo || '').toUpperCase();
                    [window.currentBulkState.allResults, window.currentBulkState.preservedResults].forEach(arr => {
                        if (!Array.isArray(arr)) return;
                        arr.forEach(r => {
                            if (!r) return;
                            const matchItem = (barkod && r.barcode === barkod) || (urunAdi && String(r.name || '').toUpperCase() === String(urunAdi).toUpperCase());
                            const matchDepo = !targetDepoUp || String(r.assigned_depo || '').toUpperCase() === targetDepoUp;
                            if (matchItem && matchDepo) {
                                r.status = 'CLEARED';
                            }
                        });
                    });
                }
                await syncTodayOrdersAcrossPCs();
                showToast('Sepet Listesinden Çıkarıldı', `${urunAdi || barkod} sepet takip listesinden kaldırıldı.`, 'info');
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markDepotCartItemsOrdered(depoCode) {
            const groups = getActiveCartGroupsByDepo();
            const grp = groups[(depoCode || '').toUpperCase()];
            if (!grp || !grp.items || grp.items.length === 0) return;
            try {
                const payloadItems = grp.items.map(it => ({
                    barkod: it.barkod || '',
                    urun_adi: it.urun_adi || '',
                    miktar: it.miktar || 1
                }));
                await fetch('/api/orders/today/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: grp.code,
                        durum: 'SIPARIS_VERILDI',
                        clear_depo_cart: true,
                        items: payloadItems
                    })
                });
                if (typeof markBulkSessionFinalizedInUI === 'function') {
                    markBulkSessionFinalizedInUI(grp.code);
                }
                await syncTodayOrdersAcrossPCs();
                showToast('Sipariş Verildi İşaretlendi', `${grp.name} sepetindeki ${grp.items.length} kalem ürün sipariş verildi olarak işaretlendi.`, 'success');
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function clearDepotCartFromModal(depoCode) {
            const dKey = (depoCode || 'SELCUK').toUpperCase();
            const meta = DEPO_CART_META[dKey] || { name: dKey };
            if (!confirm(`${meta.name} sepetindeki tüm ürünleri hem canlı depo sepetinden hem de bugünkü sepet listenizden temizlemek istediğinize emin misiniz?`)) {
                return;
            }
            try {
                const res = await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: dKey })
                });
                const data = await res.json();
                if (typeof markBulkSessionClearedInUI === 'function') {
                    markBulkSessionClearedInUI(dKey);
                }
                await syncTodayOrdersAcrossPCs();
                if (data.success) {
                    showToast('Depo Sepeti Boşaltıldı', data.message || `${meta.name} sepeti temizlendi.`, 'info');
                } else {
                    showToast('Bilgi', data.message || `${meta.name} sepeti temizlenirken uyarı oluştu.`, 'info');
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        function reopenBulkOrderModal() {
            const modal = document.getElementById('bulkOrderModal');
            if (!modal) return;
            // Eğer sepette sonlandırılmamış ürün kalmadıysa ve sadece sipariş verilmeyen eksik ürünler varsa doğrudan Eksikler sekmesini aç
            const unfin = getUnfinalizedBulkDepos();
            const missing = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];
            if (unfin.length === 0 && missing.length > 0 && typeof switchBulkResultTab === 'function') {
                switchBulkResultTab('YOK');
            }
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
            updateMultiDepotCartUI();
        }

        function closeBulkOrderModal() {
            const modal = document.getElementById('bulkOrderModal');
            if (modal) {
                modal.style.display = 'none';
                modal.classList.add('hidden');
            }
            updateMultiDepotCartUI();
        }

        // ================= Kart Bazlı Seçimli Depo Hızlı Ekleme =================
        const QUICK_DEPO_CONFIGS = {
            'ALLIANCE': {
                code: 'ALLIANCE',
                name: 'Alliance Healthcare',
                shortName: 'Alliance',
                actionText: "Alliance'a At",
                bgClass: 'bg-sky-600 hover:bg-sky-700',
                chevronClass: 'bg-sky-700 hover:bg-sky-800',
                dotColor: 'bg-sky-500',
                icon: 'fa-solid fa-truck-fast'
            },
            'SELCUK': {
                code: 'SELCUK',
                name: 'Selçuk Ecza',
                shortName: 'Selçuk',
                actionText: "Selçuk'a At",
                bgClass: 'bg-rose-600 hover:bg-rose-700',
                chevronClass: 'bg-rose-700 hover:bg-rose-800',
                dotColor: 'bg-rose-500',
                icon: 'fa-solid fa-paper-plane'
            },
            'ISKOOP': {
                code: 'ISKOOP',
                name: 'İSKOOP E-Şube',
                shortName: 'İSKOOP',
                actionText: "İSKOOP'a At",
                bgClass: 'bg-emerald-600 hover:bg-emerald-700',
                chevronClass: 'bg-emerald-700 hover:bg-emerald-800',
                dotColor: 'bg-emerald-500',
                icon: 'fa-solid fa-cart-plus'
            },
            'NEVZAT': {
                code: 'NEVZAT',
                name: 'Nevzat Ecza',
                shortName: 'Nevzat',
                actionText: "Nevzat'a At",
                bgClass: 'bg-amber-600 hover:bg-amber-700',
                chevronClass: 'bg-amber-700 hover:bg-amber-800',
                dotColor: 'bg-amber-500',
                icon: 'fa-solid fa-boxes-packing'
            }
        };

        window.cardSelectedDepos = window.cardSelectedDepos || {};
        window.defaultQuickDepo = 'ALLIANCE';

        function toggleCardDepoMenu(idx, ev) {
            if (ev) {
                ev.stopPropagation();
                ev.preventDefault();
            }
            const menu = document.getElementById(`cardDepoMenu_${idx}`);
            if (!menu) return;
            const isHidden = menu.classList.contains('hidden');
            document.querySelectorAll('[id^="cardDepoMenu_"]').forEach(el => el.classList.add('hidden'));
            if (isHidden) {
                const curDepo = (window.cardSelectedDepos && window.cardSelectedDepos[idx]) || window.defaultQuickDepo || 'ALLIANCE';
                refreshCardDepoMenuContent(idx, curDepo);
                if (menu.parentElement !== document.body) {
                    document.body.appendChild(menu);
                }
                menu.classList.remove('hidden');
                const anchor = document.getElementById(`quickAddWrapper_${idx}`) || document.getElementById(`btnQuickAddChevron_${idx}`);
                if (anchor) {
                    const rect = anchor.getBoundingClientRect();
                    const menuH = menu.offsetHeight || 195;
                    const menuW = menu.offsetWidth || 176;
                    const spaceBelow = window.innerHeight - rect.bottom;
                    let targetTop = rect.bottom + 4;
                    if (spaceBelow < menuH + 12 && rect.top > menuH + 12) {
                        targetTop = rect.top - menuH - 4;
                    }
                    targetTop = Math.max(8, Math.min(window.innerHeight - menuH - 8, targetTop));
                    const targetLeft = Math.max(8, Math.min(window.innerWidth - menuW - 8, rect.right - menuW));
                    menu.style.position = 'fixed';
                    menu.style.top = `${targetTop}px`;
                    menu.style.left = `${targetLeft}px`;
                    menu.style.right = 'auto';
                    menu.style.bottom = 'auto';
                    menu.style.zIndex = '99999';
                }
                if (!window._cardDepoScrollBound) {
                    window._cardDepoScrollBound = true;
                    window.addEventListener('scroll', () => {
                        document.querySelectorAll('[id^="cardDepoMenu_"]').forEach(el => el.classList.add('hidden'));
                    }, true);
                }
            }
        }

        function setCardDepo(idx, depoCode, applyToAll = false, ev = null) {
            if (ev) {
                ev.stopPropagation();
                ev.preventDefault();
            }
            window.cardSelectedDepos = window.cardSelectedDepos || {};
            const cfg = QUICK_DEPO_CONFIGS[depoCode] || QUICK_DEPO_CONFIGS['ALLIANCE'];

            if (applyToAll) {
                window.defaultQuickDepo = depoCode;
                const total = (window.currentFilteredCriticalItems || []).length;
                for (let i = 0; i < total; i++) {
                    window.cardSelectedDepos[i] = depoCode;
                    updateSingleCardDepoUI(i, depoCode);
                }
                updateBulkSelectionCount();
                showToast('Tüm Kartlar Güncellendi', `Tüm ilaçlar için hedef depo ${cfg.shortName} olarak belirlendi.`, 'success');
            } else {
                window.cardSelectedDepos[idx] = depoCode;
                updateSingleCardDepoUI(idx, depoCode);
                const chk = document.querySelector(`.bulkItemCheck[data-idx="${idx}"]`);
                if (chk) {
                    chk.checked = true;
                }
                syncCriticalDomStateToMaps();
                updateBulkSelectionCount();
                showToast('Depo Seçildi & İşaretlendi', `Bu ilaç için ${cfg.shortName} seçildi ve toplu dağıtım için işaretlendi.`, 'success');
            }

            const menu = document.getElementById(`cardDepoMenu_${idx}`);
            if (menu) menu.classList.add('hidden');
        }

        function refreshCardDepoMenuContent(idx, currentDepo) {
            const menu = document.getElementById(`cardDepoMenu_${idx}`);
            if (!menu) return;
            const activeDeposList = (typeof getActiveBulkDepos === 'function') ? getActiveBulkDepos() : ['ALLIANCE', 'SELCUK', 'ISKOOP', 'NEVZAT'];
            menu.innerHTML = `
                <div class="px-2.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Hedef Depo Seç
                </div>
                <div class="py-0.5">
                    ${activeDeposList.includes('ALLIANCE') ? `
                    <button type="button" onclick="setCardDepo(${idx}, 'ALLIANCE', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-sky-50 text-slate-700 hover:text-sky-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-sky-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">Alliance</span>
                        ${currentDepo === 'ALLIANCE' ? '<i class="fa-solid fa-check text-[10px] text-sky-600"></i>' : ''}
                    </button>` : ''}
                    ${activeDeposList.includes('SELCUK') ? `
                    <button type="button" onclick="setCardDepo(${idx}, 'SELCUK', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-rose-50 text-slate-700 hover:text-rose-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">Selçuk</span>
                        ${currentDepo === 'SELCUK' ? '<i class="fa-solid fa-check text-[10px] text-rose-600"></i>' : ''}
                    </button>` : ''}
                    ${activeDeposList.includes('ISKOOP') ? `
                    <button type="button" onclick="setCardDepo(${idx}, 'ISKOOP', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">İSKOOP</span>
                        ${currentDepo === 'ISKOOP' ? '<i class="fa-solid fa-check text-[10px] text-emerald-600"></i>' : ''}
                    </button>` : ''}
                    ${activeDeposList.includes('NEVZAT') ? `
                    <button type="button" onclick="setCardDepo(${idx}, 'NEVZAT', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-amber-50 text-slate-700 hover:text-amber-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">Nevzat</span>
                        ${currentDepo === 'NEVZAT' ? '<i class="fa-solid fa-check text-[10px] text-amber-600"></i>' : ''}
                    </button>` : ''}
                </div>
                <div class="py-0.5 border-t border-slate-100">
                    <button type="button" onclick="setCardDepo(${idx}, '${currentDepo}', true, event)" class="w-full text-left px-2.5 py-1.5 text-[10px] text-slate-600 hover:bg-slate-100 hover:text-slate-900 cursor-pointer flex items-center space-x-1.5 font-bold">
                        <i class="fa-solid fa-check-double text-[9px] text-sky-600"></i>
                        <span>Tüm kartları buna ayarla</span>
                    </button>
                </div>
            `;
        }

        function updateSingleCardDepoUI(idx, depoCode) {
            const cfg = QUICK_DEPO_CONFIGS[depoCode] || QUICK_DEPO_CONFIGS['ALLIANCE'];
            const btn = document.getElementById(`btnQuickAdd_${idx}`);
            const chevron = document.getElementById(`btnQuickAddChevron_${idx}`);
            const icon = document.getElementById(`btnQuickAddIcon_${idx}`);
            const text = document.getElementById(`btnQuickAddText_${idx}`);

            if (btn) {
                btn.className = `h-7 px-2 ${cfg.bgClass} text-white font-bold text-[10px] rounded-l-lg transition flex items-center space-x-1 cursor-pointer`;
                btn.title = `Bu ilacı ${cfg.name} sepetine ekle`;
            }
            if (chevron) {
                chevron.className = `w-4 h-7 ${cfg.chevronClass} text-white/90 hover:text-white border-l border-white/20 rounded-r-lg transition flex items-center justify-center cursor-pointer`;
            }
            if (icon) {
                icon.className = `${cfg.icon} text-[9px]`;
            }
            if (text) {
                text.innerText = cfg.shortName;
            }
            refreshCardDepoMenuContent(idx, depoCode);
        }

        // Dışarı tıklanınca tüm depo menülerini kapat
        document.addEventListener('click', function(e) {
            if (!e.target.closest('[id^="quickAddWrapper_"]') && !e.target.closest('[id^="cardDepoMenu_"]')) {
                document.querySelectorAll('[id^="cardDepoMenu_"]').forEach(el => el.classList.add('hidden'));
            }
        });

        async function sendSingleCriticalToDepo(idx) {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Sepete Ekleme')) return;
            syncCriticalDomStateToMaps();
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;

            window.cardSelectedDepos = window.cardSelectedDepos || {};
            const depoCode = window.cardSelectedDepos[idx] || window.defaultQuickDepo || 'ALLIANCE';
            const cfg = QUICK_DEPO_CONFIGS[depoCode] || QUICK_DEPO_CONFIGS['ALLIANCE'];

            const btn = document.getElementById(`btnQuickAdd_${idx}`);
            const chevron = document.getElementById(`btnQuickAddChevron_${idx}`);
            
            if (btn) {
                btn.disabled = true;
                if (chevron) chevron.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin text-[9px]"></i>`;
            }

            const input = document.getElementById(`bulkQtyInput_${idx}`);
            const qty = input ? (parseInt(input.value) || 1) : 1;

            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depoCode,
                        barkod: item.barkod,
                        urun_id: '',
                        miktar: qty,
                        name: item.urun_adi || ''
                    })
                });
                const data = await res.json();
                if (data.success) {
                    const cKey = getCriticalItemKey(item);
                    if (cKey && window.criticalCheckedMap) {
                        window.criticalCheckedMap[cKey] = false;
                    }
                    const effBc = data.barkod || item.barkod || '';
                    const effUid = data.urun_id || data.urun_kodu || data.matnr || '';
                    let extra = '';
                    if (data.sepet_no) extra += ` (Belge No: ${data.sepet_no})`;
                    if (data.sepet_tutari) extra += ` (Tutar: ${data.sepet_tutari} ₺)`;
                    if (typeof recordDepotSessionFromSingleAdd === 'function') {
                        recordDepotSessionFromSingleAdd(depoCode, data.sepet_tutari, data.sepet_no, data.portal_url, {
                            barcode: effBc,
                            name: item.urun_adi || data.urun_adi || '',
                            miktar: qty,
                            urun_id: effUid,
                            net_fiyat: data.net_fiyat || 0,
                            vade: data.vade || 30
                        });
                    }
                    const dUp = String(depoCode || 'ALLIANCE').toUpperCase();
                    if (typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus([{ barkod: effBc, urun_adi: item.urun_adi || data.urun_adi || '', miktar: qty, depo: dUp }], 'SEPETTE', dUp);
                    }
                    if (typeof updateMultiDepotCartUI === 'function') updateMultiDepotCartUI();
                    showToast(`${cfg.shortName} Sepetine Eklendi`, `${item.urun_adi} x${qty} kutu ${cfg.name} sepetinize aktarıldı.${extra}`, 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') await syncTodayOrdersAcrossPCs();
                    if (btn) {
                        btn.className = 'h-7 px-2 bg-emerald-600 text-white font-bold text-[10px] rounded-l-lg flex items-center space-x-1';
                        btn.innerHTML = `<i class="fa-solid fa-check text-[9px]"></i><span>OK</span>`;
                        setTimeout(() => {
                            btn.innerHTML = `<i class="${cfg.icon} text-[9px]" id="btnQuickAddIcon_${idx}"></i><span id="btnQuickAddText_${idx}">${cfg.shortName}</span>`;
                            updateSingleCardDepoUI(idx, depoCode);
                            btn.disabled = false;
                            if (chevron) chevron.disabled = false;
                        }, 2000);
                    }
                } else {
                    showToast(`${cfg.shortName} Hatası`, data.message || 'Ürün sepete eklenemedi.', 'error');
                    if (btn) {
                        btn.innerHTML = `<i class="${cfg.icon} text-[9px]" id="btnQuickAddIcon_${idx}"></i><span id="btnQuickAddText_${idx}">${cfg.shortName}</span>`;
                        updateSingleCardDepoUI(idx, depoCode);
                        btn.disabled = false;
                        if (chevron) chevron.disabled = false;
                    }
                }
            } catch(e) {
                showToast('Bağlantı Hatası', e.message, 'error');
                if (btn) {
                    btn.innerHTML = `<i class="${cfg.icon} text-[9px]" id="btnQuickAddIcon_${idx}"></i><span id="btnQuickAddText_${idx}">${cfg.shortName}</span>`;
                    updateSingleCardDepoUI(idx, depoCode);
                    btn.disabled = false;
                    if (chevron) chevron.disabled = false;
                }
            }
        }

        // Geriye dönük uyumluluk
        window.sendSingleCriticalToAlliance = sendSingleCriticalToDepo;

        const DEPO_BULK_CONFIGS = {
            'ALLIANCE': {
                name: 'Alliance Healthcare',
                title: '🚀 Alliance Healthcare Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar otomatik taranarak Alliance Healthcare sepetinize aktarılır.',
                cartUrl: 'https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart',
                cartBtnText: 'Alliance eSipariş Sepetini Aç ↗',
                icon: 'fa-solid fa-truck-fast',
                color: 'sky'
            },
            'SELCUK': {
                name: 'Selçuk Ecza',
                title: '🚀 Selçuk Ecza Deposu Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar Selçuk WebDepo sepetinize aktarılır.',
                cartUrl: 'https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx',
                cartBtnText: 'Selçuk WebDepo Sepetini Aç ↗',
                icon: 'fa-solid fa-paper-plane',
                color: 'rose'
            },
            'ISKOOP': {
                name: 'İSKOOP E-Şube',
                title: '🚀 İSKOOP E-Şube Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar İSKOOP E-Şube taslak siparişinize aktarılır.',
                cartUrl: 'https://esube.iskoop.org/FrameWorkT1/#/baskets',
                cartBtnText: 'İSKOOP E-Şube Sepetini Aç ↗',
                icon: 'fa-solid fa-cart-plus',
                color: 'emerald'
            },
            'NEVZAT': {
                name: 'Nevzat Ecza',
                title: '🚀 Nevzat Ecza Deposu Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar Nevzat WebDepo sepetinize aktarılır.',
                cartUrl: 'http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx',
                cartBtnText: 'Nevzat WebDepo Sepetini Aç ↗',
                icon: 'fa-solid fa-boxes-packing',
                color: 'amber'
            }
        };

        // ================= Toplu Sipariş Gönderici (Tek Depo Ultra Hızlı + Eksikleri Topla & Aktar) =================
        window.currentBulkState = {
            initialDepo: null,
            requestedItems: [],
            depoSessions: {}, // { 'ALLIANCE': { count: X, amount: Y, name: '...', cartUrl: '...' } }
            missingItems: [], // items still missing across tried depots
            allResults: []    // trace array for table rendering
        };
        window.activeBulkResultTab = 'ALL';

        function switchBulkResultTab(tab = 'ALL') {
            window.activeBulkResultTab = tab;
            const btnAll = document.getElementById('bulkTabBtnAll');
            const btnYok = document.getElementById('bulkTabBtnYok');

            if (tab === 'ALL') {
                if (btnAll) btnAll.className = 'px-2.5 py-1 rounded-lg text-xs font-black bg-white text-slate-900 shadow-2xs border border-slate-200 cursor-pointer';
                if (btnYok) btnYok.className = 'px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 hover:bg-rose-50 border border-transparent cursor-pointer flex items-center space-x-1';
            } else {
                if (btnAll) btnAll.className = 'px-2.5 py-1 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-100 border border-transparent cursor-pointer';
                if (btnYok) btnYok.className = 'px-2.5 py-1 rounded-lg text-xs font-black bg-rose-600 text-white shadow-2xs border border-rose-700 cursor-pointer flex items-center space-x-1';
            }

            renderBulkItemsTable();
        }

        function renderBulkItemsTable() {
            const listEl = document.getElementById('bulkOrderItemsList');
            if (!listEl) return;

            const state = window.currentBulkState;
            if (!state) return;

            const itemsToShow = (window.activeBulkResultTab === 'YOK') 
                ? (state.missingItems || []) 
                : (state.allResults || []);

            if (itemsToShow.length === 0) {
                listEl.innerHTML = window.activeBulkResultTab === 'YOK'
                    ? `<div class="p-8 text-center text-emerald-600 font-bold"><i class="fa-solid fa-circle-check text-2xl block mb-2 text-emerald-500"></i>Harika! Tüm ürünler sepete eklendi, eksik ürün bulunmuyor.</div>`
                    : `<div class="p-8 text-center text-slate-400">Listelenecek ürün bulunamadı.</div>`;
                return;
            }

            const depoColors = {
                'ALLIANCE': { badge: 'bg-sky-100 text-sky-800 border-sky-200', text: 'Alliance' },
                'SELCUK': { badge: 'bg-rose-100 text-rose-800 border-rose-200', text: 'Selçuk' },
                'ISKOOP': { badge: 'bg-emerald-100 text-emerald-800 border-emerald-200', text: 'İSKOOP' },
                'NEVZAT': { badge: 'bg-amber-100 text-amber-800 border-amber-200', text: 'Nevzat' }
            };

            listEl.innerHTML = itemsToShow.map((it, i) => {
                const isProcessing = it.status === 'PROCESSING';
                const isPending = it.status === 'PENDING';
                const isYok = it.status === 'YOK' || (!it.assigned_depo && !isPending && !isProcessing && it.status !== 'SKIPPED' && it.status !== 'YOK_LISTESI' && it.status !== 'CLEARED');
                const dCfg = depoColors[it.assigned_depo] || depoColors[it.target_depo] || { badge: 'bg-slate-100 text-slate-800', text: it.assigned_depo || it.target_depo || 'Depo' };
                const netFiyatStr = it.net_fiyat > 0 ? `${it.net_fiyat.toFixed(2)} ₺` : '';
                const vadeStr = it.vade ? `${it.vade} Gün` : '';
                const subDetail = [netFiyatStr, vadeStr].filter(Boolean).join(' • ');
                const safeBc = (it.barcode || '').replace(/'/g, "\\\\'");
                const safeNm = (it.name || '').replace(/'/g, "\\\\'");

                let badgeHtml = '';
                if (it.status === 'ORDERED') {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-600 text-white border border-emerald-700 shadow-2xs">
                            <i class="fa-solid fa-circle-check text-[9px] mr-1"></i>
                            <span>✓ ${dCfg.text} Siparişi Verildi</span>
                            ${subDetail ? `<span class="opacity-90 font-mono">(${subDetail})</span>` : ''}
                        </span>
                    `;
                } else if (isProcessing) {
                    const procMsg = (it.message && it.message !== 'İşleniyor...') ? it.message : `${dCfg.text} sepetine ekleniyor...`;
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-sky-100 text-sky-800 border border-sky-300 shadow-2xs">
                            <i class="fa-solid fa-spinner fa-spin text-[9px] text-sky-600"></i>
                            <span>${procMsg}</span>
                        </span>
                    `;
                } else if (isPending) {
                    const pendMsg = (it.message && it.message !== 'İşleniyor...') ? it.message : 'Sırada bekliyor';
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-500 border border-slate-200">
                            <i class="fa-regular fa-clock text-[9px] mr-0.5"></i>
                            <span>${pendMsg}</span>
                        </span>
                    `;
                } else if (it.status === 'YOK_LISTESI') {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-rose-700 text-white border border-rose-800 shadow-2xs">
                            <i class="fa-solid fa-ban text-rose-200 text-[9px] mr-1"></i>
                            <span>🚨 Yok Listesine Eklendi</span>
                        </span>
                    `;
                } else if (it.status === 'SKIPPED') {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-slate-700 text-white border border-slate-800 shadow-2xs">
                            <i class="fa-solid fa-ban text-rose-300 text-[9px] mr-1"></i>
                            <span>🚫 Sipariş Verilmeyecek</span>
                        </span>
                    `;
                } else if (it.status === 'CLEARED') {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-700 border border-slate-300">
                            <i class="fa-solid fa-trash-can text-[9px] mr-1"></i>
                            <span>${dCfg.text} Sepetinden Silindi</span>
                        </span>
                    `;
                } else if (!isYok) {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${dCfg.badge}">
                            <i class="fa-solid fa-cart-shopping text-[9px] mr-1"></i>
                            <span>✓ ${dCfg.text} Sepetinde</span>
                            ${subDetail ? `<span class="opacity-80 font-mono">(${subDetail})</span>` : ''}
                        </span>
                    `;
                } else {
                    const failMsg = it.message || 'Depoda Yok / Teklif Yok';
                    badgeHtml = `
                        <div class="inline-flex flex-wrap items-center justify-end gap-1.5">
                            <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                                <i class="fa-solid fa-circle-exclamation text-[9px] mr-1"></i>
                                <span>${failMsg}</span>
                            </span>
                            <button type="button" onclick="moveSingleBulkModalItemToYok('${safeBc}', '${safeNm}')" class="px-2 py-0.5 rounded-lg bg-rose-700 hover:bg-rose-800 text-white text-[10px] font-extrabold transition cursor-pointer flex items-center space-x-1 shadow-2xs" title="Bu ürünü tüm bilgisayarlarda görünen ortak Yok Listesi'ne ekle">
                                <i class="fa-solid fa-ban text-rose-200 text-[9px]"></i>
                                <span>Yok'a At</span>
                            </button>
                            <button type="button" onclick="skipBulkModalItem('${safeBc}', '${safeNm}')" class="px-2 py-0.5 rounded-lg bg-slate-700 hover:bg-slate-800 text-white text-[10px] font-extrabold transition cursor-pointer flex items-center space-x-1 shadow-2xs" title="Bu ürünü bugün sipariş verilmeyecek olarak işaretle ve eksik listesinden çıkar">
                                <i class="fa-solid fa-ban text-rose-300 text-[9px]"></i>
                                <span>Verilmeyecek</span>
                            </button>
                        </div>
                    `;
                }

                const rowBgCls = (it.status === 'SKIPPED' || it.status === 'YOK_LISTESI')
                    ? 'bg-slate-100/60 opacity-80'
                    : isProcessing
                        ? 'bg-sky-50/90 ring-1 ring-inset ring-sky-200'
                        : isPending
                            ? 'bg-white opacity-80'
                            : isYok
                                ? 'bg-rose-50/20'
                                : 'bg-emerald-50/20';

                const idxBadgeCls = isProcessing
                    ? 'bg-sky-600 text-white animate-pulse'
                    : isPending
                        ? 'bg-slate-100 text-slate-400'
                        : isYok
                            ? 'bg-rose-100 text-rose-700'
                            : 'bg-emerald-100 text-emerald-700';

                return `
                    <div class="px-4 py-2.5 flex items-center justify-between transition hover:bg-slate-50 ${rowBgCls}" id="bulkRow_${i}">
                        <div class="flex items-center space-x-2.5 min-w-0">
                            <span class="w-5 h-5 rounded-full ${idxBadgeCls} font-mono text-[10px] font-bold flex items-center justify-center shrink-0">${i + 1}</span>
                            <div class="min-w-0">
                                <div class="font-bold ${it.status === 'SKIPPED' ? 'line-through text-slate-500' : 'text-slate-800'} truncate">${it.name}</div>
                                <div class="text-[10px] text-slate-400 font-mono">${it.barcode} • Sipariş: <strong class="text-sky-700 font-bold">${it.miktar} Kutu</strong></div>
                            </div>
                        </div>
                        <div class="shrink-0 text-right">
                            ${badgeHtml}
                        </div>
                    </div>
                `;
            }).join('');
        }

        async function skipBulkModalItem(barcode, name) {
            await markItemSkippedDirect(barcode, name);
            const state = window.currentBulkState;
            if (!state) return;
            if (Array.isArray(state.missingItems)) {
                state.missingItems = state.missingItems.filter(m => !(m.barcode === barcode || (name && m.name === name)));
            }
            if (Array.isArray(state.allResults)) {
                state.allResults.forEach(r => {
                    if (r.barcode === barcode || (name && r.name === name)) {
                        r.status = 'SKIPPED';
                        r.assigned_depo = null;
                        r.message = 'Bugün Sipariş Verilmeyecek';
                    }
                });
            }
            const statFailed = document.getElementById('bulkStatFailed');
            if (statFailed) statFailed.innerText = `${(state.missingItems || []).length} Kalem`;
            const tabYok = document.getElementById('bulkTabCountYok');
            if (tabYok) tabYok.innerText = (state.missingItems || []).length;
            const copyBtn = document.getElementById('btnCopyYokList');
            const moveYokBtn = document.getElementById('btnMoveAllYokList');
            if (!state.missingItems || state.missingItems.length === 0) {
                if (copyBtn) copyBtn.classList.add('hidden');
                if (moveYokBtn) moveYokBtn.classList.add('hidden');
            }
            renderBulkItemsTable();
            renderTransferMissingBar(state.depo || 'ALLIANCE');
            if (typeof updateBulkMainFinalizeButtonUI === 'function') updateBulkMainFinalizeButtonUI();
            if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
        }

        async function moveSingleBulkModalItemToYok(barcode, name) {
            try {
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ items: [{ barkod: barcode || '', urun_adi: name || barcode || '' }] })
                });
                const data = await res.json();
                if (!data.success) {
                    showToast('Uyarı', data.message || 'Yok listesine eklenemedi.', 'error');
                    return;
                }
                showToast('🚨 Yok Listesine Eklendi', `${name || barcode} ortak Yok Listesi'ne aktarıldı.`, 'info');
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
                return;
            }
            const state = window.currentBulkState;
            if (!state) return;
            if (Array.isArray(state.missingItems)) {
                state.missingItems = state.missingItems.filter(m => !(m.barcode === barcode || (name && m.name === name)));
            }
            if (Array.isArray(state.allResults)) {
                state.allResults.forEach(r => {
                    if (r.barcode === barcode || (name && r.name === name)) {
                        r.status = 'YOK_LISTESI';
                        r.assigned_depo = null;
                        r.message = 'Yok Listesine Eklendi';
                    }
                });
            }
            const statFailed = document.getElementById('bulkStatFailed');
            if (statFailed) statFailed.innerText = `${(state.missingItems || []).length} Kalem`;
            const tabYok = document.getElementById('bulkTabCountYok');
            if (tabYok) tabYok.innerText = (state.missingItems || []).length;
            const copyBtn = document.getElementById('btnCopyYokList');
            const moveYokBtn = document.getElementById('btnMoveAllYokList');
            if (!state.missingItems || state.missingItems.length === 0) {
                if (copyBtn) copyBtn.classList.add('hidden');
                if (moveYokBtn) moveYokBtn.classList.add('hidden');
            }
            renderBulkItemsTable();
            renderTransferMissingBar(state.depo || 'ALLIANCE');
            if (typeof updateBulkMainFinalizeButtonUI === 'function') updateBulkMainFinalizeButtonUI();
            if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
            if (typeof loadEndOfDaySummary === 'function') loadEndOfDaySummary();
            if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
        }

        async function moveAllMissingBulkItemsToYok(fromFinalizeModal = false) {
            const state = window.currentBulkState;
            const missing = (state && Array.isArray(state.missingItems)) ? [...state.missingItems] : [];
            if (missing.length === 0) {
                showToast('Eksik Ürün Yok', 'Yok listesine aktarılacak eksik ürün kalmadı.', 'info');
                return;
            }
            const payloadItems = missing.map(m => ({
                barkod: m.barcode || '',
                urun_adi: m.name || m.barcode || ''
            }));
            const finYokBtn = document.getElementById('btnFinModalMoveAllYok');
            if (finYokBtn) {
                finYokBtn.disabled = true;
                finYokBtn.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin text-xs"></i><span>Yok Listesine Aktarılıyor...</span>`;
            }
            try {
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ items: payloadItems })
                });
                const data = await res.json();
                if (!data.success) {
                    showToast('Hata', data.message || 'Eksikler Yok Listesine eklenemedi.', 'error');
                    if (finYokBtn) {
                        finYokBtn.disabled = false;
                        finYokBtn.innerHTML = `<i class="fa-solid fa-ban text-xs"></i><span>Tekrar Dene (${missing.length} Ürün)</span>`;
                    }
                    return;
                }
                const missingBarcodes = new Set(missing.map(m => m.barcode).filter(Boolean));
                const missingNames = new Set(missing.map(m => m.name).filter(Boolean));
                state.missingItems = [];
                if (Array.isArray(state.allResults)) {
                    state.allResults.forEach(r => {
                        if ((r.barcode && missingBarcodes.has(r.barcode)) || (r.name && missingNames.has(r.name)) || r.status === 'YOK') {
                            r.status = 'YOK_LISTESI';
                            r.assigned_depo = null;
                            r.message = 'Yok Listesine Eklendi';
                        }
                    });
                }
                const statFailed = document.getElementById('bulkStatFailed');
                if (statFailed) statFailed.innerText = '0 Kalem';
                const tabYok = document.getElementById('bulkTabCountYok');
                if (tabYok) tabYok.innerText = '0';
                const copyBtn = document.getElementById('btnCopyYokList');
                const moveYokBtn = document.getElementById('btnMoveAllYokList');
                if (copyBtn) copyBtn.classList.add('hidden');
                if (moveYokBtn) moveYokBtn.classList.add('hidden');
                const pText = document.getElementById('bulkProgressText');
                if (pText) {
                    pText.innerHTML = `<strong class="text-emerald-700">Tamamlandı ✅:</strong> Depolarda bulunamayan <strong>${missing.length} kalem</strong> ürün ortak <strong>Yok Listesi</strong>'ne aktarıldı!`;
                }
                if (fromFinalizeModal) {
                    const finYokBox = document.getElementById('bulkFinMissingYokBox');
                    if (finYokBox) {
                        finYokBox.className = 'p-3.5 rounded-2xl bg-emerald-50 border-2 border-emerald-300 text-emerald-900 text-xs font-bold max-w-lg mx-auto mt-3 flex items-center justify-center space-x-2 shadow-2xs';
                        finYokBox.innerHTML = `<i class="fa-solid fa-circle-check text-emerald-600 text-base"></i><span>✅ Depolarda olmayan ${missing.length} eksik ürün ortak Yok Listesi'ne aktarıldı!</span>`;
                    }
                    if (finYokBtn) {
                        finYokBtn.classList.add('hidden');
                    }
                }
                renderBulkItemsTable();
                renderTransferMissingBar(state.depo || 'ALLIANCE');
                if (typeof updateBulkMainFinalizeButtonUI === 'function') updateBulkMainFinalizeButtonUI();
                if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
                showToast('🚨 Yok Listesine Aktarıldı', `${missing.length} eksik ürün tüm bilgisayarlarda görünen ortak Yok Listesi'ne eklendi.`, 'success');
                if (typeof loadEndOfDaySummary === 'function') loadEndOfDaySummary();
                if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
                if (finYokBtn) {
                    finYokBtn.disabled = false;
                    finYokBtn.innerHTML = `<i class="fa-solid fa-ban text-xs"></i><span>Tüm Eksikleri Yok Listesine At (${missing.length})</span>`;
                }
            }
        }

        function copyMissingItemsToClipboard() {
            const missing = window.currentBulkState ? window.currentBulkState.missingItems : [];
            if (!missing || missing.length === 0) {
                showToast('Eksik Yok', 'Tüm ürünler sepete başarıyla eklendi, eksik ürün bulunmuyor.', 'info');
                return;
            }
            const now = new Date();
            const dateStr = now.toLocaleDateString('tr-TR') + ' ' + now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
            
            let text = `📋 ECZANE DEPO EKSİK / YOK LİSTESİ (${dateStr})\\n`;
            text += `Aşağıdaki ${missing.length} kalem ürün depolarda bulunamamıştır:\\n`;
            text += `--------------------------------------------------\\n`;
            missing.forEach((it, idx) => {
                text += `${idx + 1}. ${it.name} (${it.barcode}) - ${it.miktar} Kutu\\n`;
            });
            text += `--------------------------------------------------\\n`;
            text += `Toplam: ${missing.length} Kalem • Eksik / Yok\\n`;

            const finishCopy = () => {
                showToast('Eksik Listesi Kopyalandı!', `${missing.length} kalemlik eksik listesi panoya kopyalandı. WhatsApp veya notlara yapıştırabilirsiniz.`, 'success');
            };

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(finishCopy).catch(() => {
                    fallbackCopyText(text);
                    finishCopy();
                });
            } else {
                fallbackCopyText(text);
                finishCopy();
            }
        }

        function fallbackCopyText(text) {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
        }

        function renderTransferMissingBar(currentDepo) {
            const bar = document.getElementById('bulkTransferMissingBar');
            const countEl = document.getElementById('bulkMissingCount');
            const btnsContainer = document.getElementById('bulkTransferButtonsContainer');
            const copyBtn = document.getElementById('btnCopyYokList');
            const moveYokBtn = document.getElementById('btnMoveAllYokList');
            if (!bar || !countEl || !btnsContainer) return;

            const missing = window.currentBulkState ? window.currentBulkState.missingItems : [];
            if (!missing || missing.length === 0) {
                bar.classList.add('hidden');
                if (copyBtn) copyBtn.classList.add('hidden');
                if (moveYokBtn) moveYokBtn.classList.add('hidden');
                return;
            }

            bar.classList.remove('hidden');
            if (copyBtn) copyBtn.classList.remove('hidden');
            if (moveYokBtn) moveYokBtn.classList.remove('hidden');
            countEl.innerText = missing.length;

            const allDepos = [
                { key: 'ALLIANCE', name: 'Alliance', color: 'bg-sky-600 hover:bg-sky-700', icon: 'fa-solid fa-truck-fast' },
                { key: 'SELCUK', name: 'Selçuk', color: 'bg-rose-600 hover:bg-rose-700', icon: 'fa-solid fa-paper-plane' },
                { key: 'ISKOOP', name: 'İSKOOP', color: 'bg-emerald-600 hover:bg-emerald-700', icon: 'fa-solid fa-cart-plus' },
                { key: 'NEVZAT', name: 'Nevzat', color: 'bg-amber-600 hover:bg-amber-700', icon: 'fa-solid fa-boxes-packing' }
            ];
            const depos = allDepos.filter(d => typeof isBulkDepoActive !== 'function' || isBulkDepoActive(d.key));

            // Denenmiş depoları hariç tutarak sıradaki aktif depoları göster (tümü denendiyse mevcut depo hariç aktifleri göster)
            const triedDepos = (window.currentBulkState && Array.isArray(window.currentBulkState.triedDepos)) ? window.currentBulkState.triedDepos : [currentDepo];
            let availableDepos = depos.filter(d => !triedDepos.includes(d.key));
            if (availableDepos.length === 0) {
                availableDepos = depos.filter(d => d.key !== currentDepo);
            }

            btnsContainer.innerHTML = availableDepos.map(d => `
                <button 
                    type="button" 
                    onclick="transferMissingItemsTo('${d.key}')" 
                    class="px-3 py-1.5 ${d.color} text-white rounded-xl text-xs font-extrabold transition flex items-center space-x-1.5 cursor-pointer shadow-xs active:scale-98"
                    title="Bu ${missing.length} eksik ilacı ${d.name} deposunda sorgulayıp sepete ekle"
                >
                    <i class="${d.icon} text-[10px]"></i>
                    <span>${d.name}'a Gönder (${missing.length})</span>
                </button>
            `).join('') + `
                <button 
                    type="button" 
                    onclick="moveAllMissingBulkItemsToYok(false)" 
                    class="px-3 py-1.5 bg-gradient-to-r from-rose-700 to-red-700 hover:from-rose-800 hover:to-red-800 text-white border border-rose-500 rounded-xl text-xs font-black transition flex items-center space-x-1.5 cursor-pointer shadow-sm active:scale-98" 
                    title="Depolarda bulunamayan kalan ${missing.length} ilacı ortak Yok Listesi'ne aktar"
                >
                    <i class="fa-solid fa-ban text-rose-200 text-[10px]"></i>
                    <span>🚨 Yok Listesine At (${missing.length})</span>
                </button>
                <button 
                    type="button" 
                    onclick="copyMissingItemsToClipboard()" 
                    class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer active:scale-98" 
                    title="Eksik ürünleri panoya kopyala"
                >
                    <i class="fa-solid fa-copy text-[10px]"></i>
                    <span>Kopyala</span>
                </button>
            `;
        }

        function getPreservedBulkCartState() {
            const prevState = window.currentBulkState || {};
            const prevSessions = prevState.depoSessions || {};
            const preservedSessions = {};
            const preservedResults = [];
            const seenDepoBc = new Set();

            if (Array.isArray(prevState.allResults)) {
                prevState.allResults.forEach(r => {
                    if (!r || r.status !== 'ADDED' || !r.assigned_depo) return;
                    const dKey = String(r.assigned_depo).toUpperCase();
                    const s = prevSessions[dKey];
                    if (s && (s.finalized || s.cleared)) return;
                    const bc = String(r.barcode || '').trim();
                    const nm = String(r.name || '').trim().toUpperCase();
                    const key = `${dKey}:${bc || nm}`;
                    if (seenDepoBc.has(key)) return;
                    seenDepoBc.add(key);
                    preservedResults.push({ ...r });
                });
            }

            if (typeof getActiveCartGroupsByDepo === 'function') {
                const activeGroups = getActiveCartGroupsByDepo();
                Object.keys(activeGroups).forEach(dKey => {
                    const grp = activeGroups[dKey];
                    if (!grp || !Array.isArray(grp.items)) return;
                    grp.items.forEach(it => {
                        const bc = String(it.barkod || '').trim();
                        const nm = String(it.urun_adi || '').trim();
                        const key = `${dKey}:${bc || nm.toUpperCase()}`;
                        if (seenDepoBc.has(key)) return;
                        seenDepoBc.add(key);
                        preservedResults.push({
                            barcode: bc,
                            name: nm,
                            miktar: parseInt(it.miktar) || 1,
                            target_depo: dKey,
                            status: 'ADDED',
                            assigned_depo: dKey,
                            net_fiyat: 0,
                            vade: 30,
                            message: 'Sepette Mevcut'
                        });
                    });
                });
            }

            Object.keys(prevSessions).forEach(dKey => {
                const s = prevSessions[dKey];
                if (s && !s.finalized && !s.cleared && (s.count || 0) > 0) {
                    preservedSessions[dKey] = { ...s };
                }
            });

            preservedResults.forEach(r => {
                const dKey = String(r.assigned_depo || '').toUpperCase();
                if (!dKey) return;
                const dCfg = (typeof DEPO_BULK_CONFIGS !== 'undefined' && DEPO_BULK_CONFIGS[dKey]) || (typeof DEPO_CART_META !== 'undefined' && DEPO_CART_META[dKey]) || { name: dKey, cartUrl: '#' };
                if (!preservedSessions[dKey]) {
                    preservedSessions[dKey] = {
                        count: 0,
                        amount: 0,
                        name: dCfg.name || dKey,
                        cartUrl: dCfg.cartUrl || dCfg.portalUrl || '#',
                        finalized: false,
                        cleared: false
                    };
                }
            });

            Object.keys(preservedSessions).forEach(dKey => {
                const itemsForDepo = preservedResults.filter(r => String(r.assigned_depo || '').toUpperCase() === dKey);
                if (itemsForDepo.length > (preservedSessions[dKey].count || 0)) {
                    preservedSessions[dKey].count = itemsForDepo.length;
                }
            });

            return {
                depoSessions: preservedSessions,
                allResults: preservedResults,
                triedDepos: Object.keys(preservedSessions)
            };
        }

        function renderDepoBreakdownPills() {
            if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
            const breakdownEl = document.getElementById('bulkModalDepoBreakdown');
            if (!breakdownEl) return;

            const sessions = (window.currentBulkState && window.currentBulkState.depoSessions) ? { ...window.currentBulkState.depoSessions } : {};
            if (typeof getActiveCartGroupsByDepo === 'function') {
                const activeGroups = getActiveCartGroupsByDepo();
                Object.keys(activeGroups).forEach(dKey => {
                    const grp = activeGroups[dKey];
                    if (!grp || !grp.items || grp.items.length === 0) return;
                    const cfg = (typeof DEPO_BULK_CONFIGS !== 'undefined' && DEPO_BULK_CONFIGS[dKey]) || {};
                    const parsedAmt = parseFloat(String(grp.sepetTutari || '0').replace(/\./g, '').replace(',', '.')) || 0;
                    if (!sessions[dKey]) {
                        sessions[dKey] = {
                            count: grp.items.length,
                            amount: parsedAmt,
                            name: grp.name || cfg.name || dKey,
                            cartUrl: grp.portalUrl || cfg.cartUrl || '#',
                            finalized: false,
                            cleared: false
                        };
                    } else if (!sessions[dKey].finalized && !sessions[dKey].cleared) {
                        if (grp.items.length > (sessions[dKey].count || 0)) {
                            sessions[dKey].count = grp.items.length;
                        }
                        if (parsedAmt > 0 && !(sessions[dKey].amount > 0)) {
                            sessions[dKey].amount = parsedAmt;
                        }
                    }
                });
            }
            const keys = Object.keys(sessions);
            if (keys.length === 0) {
                breakdownEl.classList.add('hidden');
                return;
            }

            breakdownEl.classList.remove('hidden');
            const colors = {
                'ALLIANCE': 'bg-sky-50 border-sky-300 text-sky-900',
                'SELCUK': 'bg-rose-50 border-rose-300 text-rose-900',
                'ISKOOP': 'bg-emerald-50 border-emerald-300 text-emerald-900',
                'NEVZAT': 'bg-amber-50 border-amber-300 text-amber-900'
            };

            breakdownEl.innerHTML = keys.map(k => {
                const s = sessions[k];
                const cStyle = colors[k] || 'bg-slate-50 border-slate-300 text-slate-900';
                let btnHtml = '';
                if (s.finalized) {
                    btnHtml = `<div class="mt-2 w-full py-1.5 px-2 rounded-lg bg-emerald-100 border border-emerald-300 text-emerald-900 font-black text-[10px] flex items-center justify-center space-x-1">
                           <i class="fa-solid fa-circle-check text-emerald-600 text-[10px]"></i>
                           <span>✓ ${s.name} Siparişi İletildi</span>
                       </div>`;
                } else if (s.cleared) {
                    btnHtml = `<div class="mt-2 w-full py-1.5 px-2 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 font-bold text-[10px] flex items-center justify-center space-x-1">
                           <i class="fa-solid fa-trash-can text-rose-500 text-[10px]"></i>
                           <span>Sepet Boşaltıldı</span>
                       </div>`;
                } else if ((s.count || 0) <= 0) {
                    btnHtml = `<div class="mt-2 w-full py-1.5 px-2 rounded-lg bg-slate-100 border border-slate-200 text-slate-500 font-bold text-[10px] text-center">
                           Bu Depoda Yok (0 Kalem)
                       </div>`;
                } else {
                    btnHtml = `<button type="button" onclick="openBulkFinalizeFlow('${k}')" class="mt-2 w-full py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[10px] transition flex items-center justify-center space-x-1 cursor-pointer shadow-xs">
                           <i class="fa-solid fa-paper-plane text-[9px]"></i>
                           <span>${s.name} Siparişini Sonlandır</span>
                       </button>`;
                }
                return `
                    <div class="p-2.5 rounded-xl border ${cStyle} flex flex-col justify-between shadow-2xs">
                        <div class="flex items-center justify-between text-[11px] font-bold">
                            <span>${s.name}</span>
                            <a href="${s.cartUrl}" target="_blank" rel="noopener noreferrer" class="text-[10px] underline font-extrabold hover:opacity-80">Sepeti Aç ↗</a>
                        </div>
                        <div class="mt-1 flex items-baseline justify-between">
                            <span class="text-xs font-black">${s.finalized ? `${s.count} Kalem Sipariş Verildi` : `${s.count} Kalem Eklendi`}</span>
                            <span class="text-[10px] font-mono font-bold">${(s.amount || 0).toFixed(2)} ₺</span>
                        </div>
                        ${btnHtml}
                    </div>
                `;
            }).join('');
        }

        function uncheckCompletedCriticalItems(addedBarcodes) {
            if (!Array.isArray(addedBarcodes) || addedBarcodes.length === 0) return;
            const bcSet = new Set(addedBarcodes.map(b => String(b || '').trim()).filter(Boolean));
            if (bcSet.size === 0) return;
            if (window.criticalCheckedMap) {
                bcSet.forEach(bc => {
                    window.criticalCheckedMap[bc] = false;
                });
            }
            document.querySelectorAll('.bulkItemCheck:checked').forEach(chk => {
                const idx = parseInt(chk.dataset.idx);
                const it = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
                if (it && bcSet.has(String(it.barkod || '').trim())) {
                    chk.checked = false;
                }
            });
            if (typeof updateBulkSelectionCount === 'function') updateBulkSelectionCount();
        }

        function resetBulkOrderModalUIForNewRun(totalItemsCount) {
            const finModal = document.getElementById('bulkFinalizeModal');
            if (finModal) {
                finModal.classList.add('hidden');
                finModal.style.display = 'none';
            }
            window.activeBulkResultTab = 'ALL';
            if (typeof switchBulkResultTab === 'function') {
                switchBulkResultTab('ALL');
            }
            const missingBar = document.getElementById('bulkTransferMissingBar');
            if (missingBar) missingBar.classList.add('hidden');
            const breakdownEl = document.getElementById('bulkModalDepoBreakdown');
            if (breakdownEl) breakdownEl.classList.add('hidden');
            const btnMoveAllYok = document.getElementById('btnMoveAllYokList');
            const btnCopyYok = document.getElementById('btnCopyYokList');
            if (btnMoveAllYok) { btnMoveAllYok.classList.add('hidden'); btnMoveAllYok.classList.remove('flex'); }
            if (btnCopyYok) { btnCopyYok.classList.add('hidden'); btnCopyYok.classList.remove('flex'); }
            const tabAllCount = document.getElementById('bulkTabCountAll');
            const tabYokCount = document.getElementById('bulkTabCountYok');
            if (tabAllCount) tabAllCount.innerText = String(totalItemsCount || 0);
            if (tabYokCount) tabYokCount.innerText = '0';
            const finBtn = document.getElementById('btnBulkFinalize');
            if (finBtn) {
                finBtn.disabled = true;
                finBtn.className = 'px-5 py-2.5 bg-slate-400 text-white rounded-xl font-black text-xs transition flex items-center space-x-2 opacity-80 cursor-wait';
                finBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Sepete Ekleniyor...</span>`;
            }
        }

        window.scrollBulkActiveRowIntoView = function(rowRef) {
            try {
                if (!rowRef || window.activeBulkResultTab === 'YOK') return;
                const listEl = document.getElementById('bulkOrderItemsList');
                if (!listEl || !window.currentBulkState || !Array.isArray(window.currentBulkState.allResults)) return;
                const rowIdx = window.currentBulkState.allResults.indexOf(rowRef);
                if (rowIdx < 0) return;
                const rowEl = document.getElementById(`bulkRow_${rowIdx}`);
                if (!rowEl) return;
                const rowTop = rowEl.offsetTop - listEl.offsetTop;
                const rowBottom = rowTop + rowEl.offsetHeight;
                const viewTop = listEl.scrollTop;
                const viewBottom = viewTop + listEl.clientHeight;
                if (rowBottom > viewBottom - 16) {
                    listEl.scrollTo({ top: Math.max(0, rowBottom - listEl.clientHeight + 28), behavior: 'smooth' });
                } else if (rowTop < viewTop) {
                    listEl.scrollTo({ top: Math.max(0, rowTop - 12), behavior: 'smooth' });
                }
            } catch (_e) {}
        };

        window.findMatchingBulkRow = function(rows, rObj, depo, usedSet) {
            if (!Array.isArray(rows) || !rObj) return null;
            const cIdx = (rObj.client_idx !== undefined && rObj.client_idx !== null) ? Number(rObj.client_idx) : -1;
            if (cIdx >= 0 && cIdx < rows.length && rows[cIdx] && (!usedSet || !usedSet.has(rows[cIdx]))) {
                if (usedSet) usedSet.add(rows[cIdx]);
                return rows[cIdx];
            }
            const normBc = (b) => {
                const s = String(b || '').trim();
                return (s.length === 14 && s.startsWith('0')) ? s.slice(1) : s;
            };
            const targetBc = normBc(rObj.barcode || rObj.barkod);
            if (targetBc) {
                const byBc = rows.find(it => it && (!usedSet || !usedSet.has(it)) && normBc(it.barcode) === targetBc && (!depo || !it.target_depo || it.target_depo === depo));
                if (byBc) {
                    if (usedSet) usedSet.add(byBc);
                    return byBc;
                }
            }
            const targetNm = String(rObj.name || rObj.urun_adi || '').trim().toUpperCase();
            if (targetNm) {
                const byNm = rows.find(it => it && (!usedSet || !usedSet.has(it)) && String(it.name || '').trim().toUpperCase() === targetNm);
                if (byNm) {
                    if (usedSet) usedSet.add(byNm);
                    return byNm;
                }
            }
            return null;
        };

        window.runBulkAddWithLiveProgress = async function(opts) {
            const depo = String(opts.depo || 'ALLIANCE').toUpperCase();
            const items = Array.isArray(opts.items) ? opts.items : [];
            const cfg = opts.cfg || DEPO_BULK_CONFIGS[depo] || DEPO_BULK_CONFIGS['ALLIANCE'];
            const rowRefs = Array.isArray(opts.rowRefs) ? opts.rowRefs : [];
            const rangeStart = typeof opts.rangeStartPct === 'number' ? opts.rangeStartPct : 6;
            const rangeEnd = typeof opts.rangeEndPct === 'number' ? opts.rangeEndPct : 98;
            const prefixLabel = opts.prefixLabel || '';
            const baseSuccess = Number(opts.baseSuccessCount || 0);
            const baseFailed = Number(opts.baseFailedCount || 0);
            const baseAmount = Number(opts.baseAmount || 0);

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');
            const statSuccess = document.getElementById('bulkStatSuccess');
            const statFailed = document.getElementById('bulkStatFailed');
            const statAmount = document.getElementById('bulkStatAmount');
            const tabYokCount = document.getElementById('bulkTabCountYok');

            const mapPct = (rawPct) => {
                const clamped = Math.max(0, Math.min(100, Number(rawPct || 0)));
                return Math.round(rangeStart + (clamped / 100) * (rangeEnd - rangeStart));
            };

            let displayedPct = mapPct(6);
            if (pBar) pBar.style.width = `${displayedPct}%`;
            if (pPercent) pPercent.innerText = `%${displayedPct}`;
            if (pSpinner) pSpinner.className = 'fa-solid fa-spinner fa-spin text-sky-600';
            if (pText) {
                pText.innerText = `${prefixLabel}${cfg.name} oturumu doğrulanıyor (${items.length} kalem)...`;
            }

            if (rowRefs.length > 0) {
                rowRefs.forEach((r, idx) => {
                    if (!r) return;
                    if (idx === 0) {
                        r.status = 'PROCESSING';
                        r.message = `${cfg.shortName || cfg.name} sepetine ekleniyor...`;
                    } else {
                        r.status = 'PENDING';
                        r.message = 'Sırada bekliyor';
                    }
                });
                renderBulkItemsTable();
                window.scrollBulkActiveRowIntoView(rowRefs[0]);
            }

            const jobId = `bulk_${depo}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
            const payloadItems = items.map((it, idx) => ({ ...it, client_idx: idx }));

            let isDone = false;
            let sinceIdx = 0;
            let lastActiveRef = rowRefs[0] || null;

            const pollLoopPromise = (async () => {
                while (!isDone) {
                    await new Promise(r => setTimeout(r, 210));
                    if (isDone) break;
                    try {
                        const pRes = await fetch(`/api/cart/bulk-progress?job_id=${encodeURIComponent(jobId)}&since=${sinceIdx}`, { cache: 'no-store' });
                        if (!pRes.ok || isDone) continue;
                        const prog = await pRes.json();
                        if (!prog || !prog.found || isDone) continue;

                        if (typeof prog.next_since === 'number') {
                            sinceIdx = prog.next_since;
                        }

                        let rowsChanged = false;
                        const evs = Array.isArray(prog.events) ? prog.events : [];
                        for (const ev of evs) {
                            const idx = Number(ev.index);
                            const targetRow = (idx >= 0 && idx < rowRefs.length && rowRefs[idx])
                                ? rowRefs[idx]
                                : window.findMatchingBulkRow(rowRefs, ev, depo, null);
                            if (targetRow) {
                                rowsChanged = true;
                                if (ev.success) {
                                    targetRow.status = 'ADDED';
                                    targetRow.assigned_depo = depo;
                                    targetRow.urun_id = ev.urun_id || targetRow.urun_id || '';
                                    targetRow.net_fiyat = Number(ev.net_fiyat || 0);
                                    targetRow.vade = Number(ev.vade || 30);
                                    targetRow.message = ev.message || 'Sepete eklendi';
                                } else {
                                    targetRow.status = 'YOK';
                                    targetRow.assigned_depo = null;
                                    targetRow.message = ev.message || `${cfg.shortName || cfg.name}'ta Stok Yok`;
                                }
                            }
                        }

                        // Sıradaki işlenen satırı canlı vurgula
                        const nextPending = rowRefs.find(r => r && (r.status === 'PENDING' || r.status === 'PROCESSING'));
                        rowRefs.forEach(r => {
                            if (r && r.status === 'PROCESSING' && r !== nextPending) {
                                r.status = 'PENDING';
                                r.message = 'Sırada bekliyor';
                                rowsChanged = true;
                            }
                        });
                        if (nextPending && nextPending.status !== 'PROCESSING') {
                            nextPending.status = 'PROCESSING';
                            nextPending.message = `${cfg.shortName || cfg.name} sepetine ekleniyor...`;
                            rowsChanged = true;
                        }

                        const targetPct = mapPct(prog.percent || 8);
                        const ceilingPct = mapPct(prog.phase_ceiling || 95);
                        if (targetPct > displayedPct) {
                            displayedPct = targetPct;
                        } else if (displayedPct < ceilingPct) {
                            displayedPct = Math.min(ceilingPct, displayedPct + 1);
                        }
                        if (pBar) pBar.style.width = `${displayedPct}%`;
                        if (pPercent) pPercent.innerText = `%${displayedPct}`;
                        if (prog.status_text && pText) {
                            pText.innerText = `${prefixLabel}${prog.status_text}`;
                        }

                        if (prog.done > 0) {
                            const liveSucc = baseSuccess + Number(prog.success_count || 0);
                            const liveFail = baseFailed + Number(prog.failed_count || 0);
                            const liveAmt = baseAmount + Number(prog.running_amount || 0);
                            if (statSuccess) statSuccess.innerText = `${liveSucc} Kalem`;
                            if (statFailed) statFailed.innerText = `${liveFail} Kalem`;
                            if (tabYokCount) tabYokCount.innerText = String(liveFail);
                            if (liveAmt > 0 && statAmount) {
                                statAmount.innerText = `${liveAmt.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;
                            }
                        }

                        if (rowsChanged) {
                            renderBulkItemsTable();
                            if (nextPending && nextPending !== lastActiveRef) {
                                lastActiveRef = nextPending;
                                window.scrollBulkActiveRowIntoView(nextPending);
                            }
                        }
                    } catch (_pollErr) {}
                }
            })();

            try {
                const res = await fetch('/api/cart/bulk-add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        items: payloadItems,
                        cascade: false,
                        job_id: jobId
                    })
                });
                isDone = true;
                try { await pollLoopPromise; } catch (_e) {}
                return await res.json();
            } catch (err) {
                isDone = true;
                try { await pollLoopPromise; } catch (_e) {}
                throw err;
            }
        };

        async function triggerBulkOrder(depoKodu = 'ALLIANCE') {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Toplu Sipariş Gönderimi')) return;
            const depo = (depoKodu || 'ALLIANCE').toUpperCase();
            const cfg = DEPO_BULK_CONFIGS[depo] || DEPO_BULK_CONFIGS['ALLIANCE'];

            const checks = document.querySelectorAll('.bulkItemCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', `Lütfen sepete aktarmak için en az bir ilaç seçiniz.`, 'info');
                return;
            }

            const itemsToOrder = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
                if (it) {
                    const input = document.getElementById(`bulkQtyInput_${idx}`);
                    const qty = input ? (parseInt(input.value) || 1) : 1;
                    itemsToOrder.push({
                        barcode: it.barkod,
                        name: it.urun_adi,
                        miktar: qty
                    });
                }
            });

            // Önceki sonlandırılmamış sepet oturumlarını koruyarak yeni gönderimi ekle
            const preserved = getPreservedBulkCartState();
            const newPendingResults = itemsToOrder.map(it => ({
                barcode: it.barcode,
                name: it.name,
                miktar: it.miktar,
                target_depo: depo,
                status: 'PENDING',
                assigned_depo: null,
                net_fiyat: 0,
                vade: 30,
                message: 'Sırada bekliyor'
            }));
            const filteredPreservedResults = preserved.allResults.filter(pr => {
                if (String(pr.assigned_depo || '').toUpperCase() !== depo) return true;
                return !itemsToOrder.some(nt => nt.barcode && pr.barcode && nt.barcode === pr.barcode);
            });
            window.currentBulkState = {
                depo: depo,
                initialDepo: depo,
                triedDepos: Array.from(new Set([...preserved.triedDepos, depo])),
                requestedItems: itemsToOrder,
                depoSessions: { ...preserved.depoSessions },
                missingItems: [],
                preservedResults: filteredPreservedResults,
                allResults: [...newPendingResults]
            };

            // Modalı aç ve önceki sipariş ekranı kalıntılarını temizle
            const modal = document.getElementById('bulkOrderModal');
            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
            }
            resetBulkOrderModalUIForNewRun(itemsToOrder.length);

            const modalTitle = document.getElementById('bulkModalTitle');
            const modalDesc = document.getElementById('bulkModalDesc');
            const modalIcon = document.getElementById('bulkModalIcon');
            const modalTargetDepo = document.getElementById('bulkModalTargetDepo');
            const modalCartLink = document.getElementById('bulkModalCartLink');
            const modalCartText = document.getElementById('bulkModalCartBtnText');

            if (modalTitle) modalTitle.innerText = cfg.title;
            if (modalDesc) modalDesc.innerText = cfg.desc;
            if (modalTargetDepo) modalTargetDepo.innerText = `${cfg.name} B2B`;
            if (modalIcon) modalIcon.className = cfg.icon;
            if (modalCartLink) {
                modalCartLink.href = cfg.cartUrl;
                modalCartLink.onclick = function(e) {
                    e.preventDefault();
                    if (typeof window.openAuthenticatedPortal === 'function') {
                        window.openAuthenticatedPortal(depo, cfg.cartUrl);
                    } else {
                        window.open(cfg.cartUrl, '_blank', 'noopener,noreferrer');
                    }
                    return false;
                };
            }
            if (modalCartText) modalCartText.innerText = cfg.cartBtnText;

            // Gizle
            const missingBar = document.getElementById('bulkTransferMissingBar');
            if (missingBar) missingBar.classList.add('hidden');
            const breakdownEl = document.getElementById('bulkModalDepoBreakdown');
            if (breakdownEl) breakdownEl.classList.add('hidden');

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');
            const statTotal = document.getElementById('bulkStatTotal');
            const statSuccess = document.getElementById('bulkStatSuccess');
            const statFailed = document.getElementById('bulkStatFailed');
            const statAmount = document.getElementById('bulkStatAmount');

            if (statTotal) statTotal.innerText = itemsToOrder.length;
            if (statSuccess) statSuccess.innerText = '0';
            if (statFailed) statFailed.innerText = '0';
            if (statAmount) statAmount.innerText = '0.00 ₺';

            try {
                const data = await window.runBulkAddWithLiveProgress({
                    depo: depo,
                    items: itemsToOrder,
                    cfg: cfg,
                    rowRefs: newPendingResults,
                    rangeStartPct: 6,
                    rangeEndPct: 98
                });

                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '%100';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-check text-emerald-600';

                if (data.success || data.success_count > 0 || data.items) {
                    const successCount = data.success_count || 0;
                    const totalAmount = data.total_amount || 0;

                    // Eksik ürünleri topla
                    const missing = [];
                    const addedBarcodes = [];
                    const addedOptimistic = [];
                    const results = data.items || [];
                    const usedRows = new Set();
                    results.forEach(r => {
                        const target = window.findMatchingBulkRow(newPendingResults, r, depo, usedRows)
                                    || window.findMatchingBulkRow(window.currentBulkState.allResults, r, depo, null);
                        if (r.success) {
                            if (r.barcode) addedBarcodes.push(r.barcode);
                            addedOptimistic.push({
                                barkod: r.barcode || (target && target.barcode) || '',
                                urun_adi: r.name || (target && target.name) || '',
                                miktar: r.miktar || (target && target.miktar) || 1,
                                depo: depo
                            });
                            if (target) {
                                target.status = 'ADDED';
                                target.assigned_depo = depo;
                                target.urun_id = r.urun_id || target.urun_id || '';
                                target.net_fiyat = r.net_fiyat || 0;
                                target.vade = r.vade || 30;
                                target.message = r.message || 'Eklendi';
                            }
                        } else {
                            if (target) {
                                target.status = 'YOK';
                                target.assigned_depo = null;
                                target.message = r.message || `${cfg.shortName}'ta Stok Yok`;
                            }
                            missing.push({
                                barcode: r.barcode,
                                name: r.name || (target ? target.name : r.barcode),
                                miktar: r.miktar || (target ? target.miktar : 1),
                                message: r.message || `${cfg.shortName}'ta Yok`
                            });
                        }
                    });
                    if (addedOptimistic.length > 0 && typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus(addedOptimistic, 'SEPETTE', depo);
                    }
                    uncheckCompletedCriticalItems(addedBarcodes);

                    // Depo sepet oturumunu kaydet (önceki aynı depo sepet kalemleri varsa birleştir)
                    const prevPreservedForDepo = (window.currentBulkState.preservedResults || []).filter(it => it.status === 'ADDED' && it.assigned_depo === depo).length;
                    const curForThisDepo = window.currentBulkState.allResults.filter(it => it.status === 'ADDED' && it.assigned_depo === depo).length;
                    const totalForThisDepo = prevPreservedForDepo + curForThisDepo;
                    const prevSessAmt = (window.currentBulkState.depoSessions[depo] && window.currentBulkState.depoSessions[depo].amount) || 0;
                    window.currentBulkState.depoSessions[depo] = {
                        count: Math.max(successCount, totalForThisDepo),
                        amount: totalAmount > 0 ? totalAmount : prevSessAmt,
                        name: cfg.name,
                        cartUrl: cfg.cartUrl,
                        finalized: false,
                        cleared: false
                    };

                    window.currentBulkState.missingItems = missing;

                    // UI Güncelle
                    if (statSuccess) statSuccess.innerText = `${successCount} Kalem`;
                    if (statFailed) statFailed.innerText = `${missing.length} Kalem`;
                    if (statAmount) statAmount.innerText = `${totalAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;
                    
                    const tabAllCount = document.getElementById('bulkTabCountAll');
                    const tabYokCount = document.getElementById('bulkTabCountYok');
                    if (tabAllCount) tabAllCount.innerText = itemsToOrder.length;
                    if (tabYokCount) tabYokCount.innerText = missing.length;

                    if (pText) {
                        pText.innerHTML = `<strong>Tamamlandı:</strong> ${successCount} Kalem ${cfg.name} sepetine eklendi! ${missing.length > 0 ? `<span class="text-rose-600 font-bold ml-1">(${missing.length} kalem bu depoda bulunamadı)</span>` : ''}`;
                    }

                    renderDepoBreakdownPills();
                    updateBulkMainFinalizeButtonUI();
                    renderTransferMissingBar(depo);
                    renderBulkItemsTable();

                    showToast(`${cfg.name} Sepetine Eklendi`, `${successCount} kalem sepete yüklendi. ${missing.length > 0 ? `${missing.length} eksik kalem toplandı.` : ''}`, 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    newPendingResults.forEach(r => {
                        if (r.status === 'PENDING' || r.status === 'PROCESSING') {
                            r.status = 'YOK';
                            r.message = data.message || 'Sepete eklenemedi';
                        }
                    });
                    renderBulkItemsTable();
                    if (pText) pText.innerText = `Aktarım uyarısı: ${data.message || 'Ürünler sepete eklenemedi'}`;
                    if (pSpinner) pSpinner.className = 'fa-solid fa-triangle-exclamation text-rose-600';
                    updateBulkMainFinalizeButtonUI();
                    showToast('Aktarım Uyarısı', data.message || 'İşlem tamamlanamadı.', 'error');
                }
            } catch(e) {
                newPendingResults.forEach(r => {
                    if (r.status === 'PENDING' || r.status === 'PROCESSING') {
                        r.status = 'YOK';
                        r.message = `Bağlantı hatası: ${e.message}`;
                    }
                });
                renderBulkItemsTable();
                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '!';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-xmark text-rose-600';
                if (pText) pText.innerText = `Bağlantı hatası: ${e.message}`;
                updateBulkMainFinalizeButtonUI();
                showToast('Hata', e.message, 'error');
            }
        }

        async function transferMissingItemsTo(targetDepo) {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Toplu Sipariş Aktarımı')) return;
            const targetDepoClean = (targetDepo || '').toUpperCase();
            const cfg = DEPO_BULK_CONFIGS[targetDepoClean];
            if (!cfg) return;

            const missing = window.currentBulkState ? window.currentBulkState.missingItems : [];
            if (!missing || missing.length === 0) {
                showToast('Eksik Yok', 'Tüm ürünler depolara eklendi!', 'info');
                return;
            }

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');

            const toSend = [...missing];
            const usedLookup = new Set();
            const transferRowRefs = toSend.map(m => {
                const row = window.findMatchingBulkRow(window.currentBulkState.allResults, m, null, usedLookup);
                if (row) {
                    row.target_depo = targetDepoClean;
                    row.status = 'PENDING';
                    row.message = 'Sırada bekliyor';
                }
                return row;
            });

            let prevAddedCount = 0;
            let prevAddedAmt = 0;
            Object.values((window.currentBulkState && window.currentBulkState.depoSessions) || {}).forEach(s => {
                prevAddedCount += Number(s.count || 0);
                prevAddedAmt += Number(s.amount || 0);
            });

            try {
                const data = await window.runBulkAddWithLiveProgress({
                    depo: targetDepoClean,
                    items: toSend,
                    cfg: cfg,
                    rowRefs: transferRowRefs,
                    rangeStartPct: 6,
                    rangeEndPct: 98,
                    baseSuccessCount: prevAddedCount,
                    baseAmount: prevAddedAmt
                });

                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '%100';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-check text-emerald-600';

                if (data.success || data.success_count > 0 || data.items) {
                    const newSuccess = data.success_count || 0;
                    const newAmount = data.total_amount || 0;

                    // Hedef depo istatistiğini kaydet / güncelle
                    if (!Array.isArray(window.currentBulkState.triedDepos)) {
                        window.currentBulkState.triedDepos = [window.currentBulkState.initialDepo || targetDepoClean];
                    }
                    if (!window.currentBulkState.triedDepos.includes(targetDepoClean)) {
                        window.currentBulkState.triedDepos.push(targetDepoClean);
                    }
                    if (!window.currentBulkState.depoSessions[targetDepoClean]) {
                        window.currentBulkState.depoSessions[targetDepoClean] = {
                            count: newSuccess,
                            amount: newAmount,
                            name: cfg.name,
                            cartUrl: cfg.cartUrl,
                            finalized: false
                        };
                    } else {
                        window.currentBulkState.depoSessions[targetDepoClean].count += newSuccess;
                        window.currentBulkState.depoSessions[targetDepoClean].amount += newAmount;
                        if (newSuccess > 0) window.currentBulkState.depoSessions[targetDepoClean].finalized = false;
                    }

                    // Kalan eksikleri hesapla
                    const stillMissing = [];
                    const addedBarcodes = [];
                    const addedOptimistic = [];
                    const results = data.items || [];
                    const usedRows = new Set();
                    results.forEach(r => {
                        const target = window.findMatchingBulkRow(transferRowRefs, r, targetDepoClean, usedRows)
                                    || window.findMatchingBulkRow(window.currentBulkState.allResults, r, null, null);
                        if (r.success) {
                            if (r.barcode) addedBarcodes.push(r.barcode);
                            addedOptimistic.push({
                                barkod: r.barcode || (target && target.barcode) || '',
                                urun_adi: r.name || (target && target.name) || '',
                                miktar: r.miktar || (target && target.miktar) || 1,
                                depo: targetDepoClean
                            });
                            if (target) {
                                target.status = 'ADDED';
                                target.assigned_depo = targetDepoClean;
                                target.urun_id = r.urun_id || r.matnr || r.urun_kodu || target.urun_id || '';
                                target.net_fiyat = r.net_fiyat || 0;
                                target.vade = r.vade || 30;
                                target.message = r.message || 'Eklendi';
                            }
                        } else {
                            if (target && target.status !== 'ADDED') {
                                target.status = 'YOK';
                                target.assigned_depo = null;
                                target.message = r.message || `${cfg.shortName}'ta da Yok`;
                            }
                            stillMissing.push({
                                barcode: r.barcode,
                                name: r.name || (target ? target.name : r.barcode),
                                miktar: r.miktar || (target ? target.miktar : 1),
                                message: r.message || `${cfg.shortName}'ta da Yok`
                            });
                        }
                    });
                    if (addedOptimistic.length > 0 && typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus(addedOptimistic, 'SEPETTE', targetDepoClean);
                    }
                    uncheckCompletedCriticalItems(addedBarcodes);

                    window.currentBulkState.missingItems = stillMissing;

                    // Toplam başarı ve tutar hesapla
                    let totalAdded = 0;
                    let totalAmount = 0;
                    Object.values(window.currentBulkState.depoSessions).forEach(s => {
                        totalAdded += s.count;
                        totalAmount += s.amount;
                    });

                    const statSuccess = document.getElementById('bulkStatSuccess');
                    const statFailed = document.getElementById('bulkStatFailed');
                    const statAmount = document.getElementById('bulkStatAmount');
                    const tabYokCount = document.getElementById('bulkTabCountYok');

                    if (statSuccess) statSuccess.innerText = `${totalAdded} Kalem`;
                    if (statFailed) statFailed.innerText = `${stillMissing.length} Kalem`;
                    if (statAmount) statAmount.innerText = `${totalAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;
                    if (tabYokCount) tabYokCount.innerText = stillMissing.length;

                    if (pText) {
                        pText.innerHTML = `<strong>${cfg.name} Tamamlandı:</strong> ${newSuccess} Kalem sepete eklendi! ${stillMissing.length > 0 ? `<span class="text-rose-600 font-bold">(${stillMissing.length} kalem halen bulunamadı)</span>` : '<span class="text-emerald-600 font-bold">(Tüm eksikler tamamlandı!)</span>'}`;
                    }

                    renderDepoBreakdownPills();
                    updateBulkMainFinalizeButtonUI();
                    renderTransferMissingBar(targetDepoClean);
                    renderBulkItemsTable();

                    showToast(`${cfg.name} Aktarımı Yapıldı`, `${newSuccess} kalem ${cfg.name} sepetine eklendi. ${stillMissing.length > 0 ? `${stillMissing.length} kalem kaldı.` : 'Tüm ürünler tamamlandı!'}`, 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    transferRowRefs.forEach(r => {
                        if (r && (r.status === 'PENDING' || r.status === 'PROCESSING')) {
                            r.status = 'YOK';
                            r.message = data.message || `${cfg.shortName}'ta da Yok`;
                        }
                    });
                    renderBulkItemsTable();
                    if (pText) pText.innerText = `Aktarım uyarısı: ${data.message || 'Ürünler sepete eklenemedi'}`;
                    updateBulkMainFinalizeButtonUI();
                    showToast('Aktarım Uyarısı', data.message || 'İşlem tamamlanamadı.', 'error');
                }
            } catch(e) {
                transferRowRefs.forEach(r => {
                    if (r && (r.status === 'PENDING' || r.status === 'PROCESSING')) {
                        r.status = 'YOK';
                        r.message = `Bağlantı hatası: ${e.message}`;
                    }
                });
                renderBulkItemsTable();
                if (pText) pText.innerText = `Bağlantı hatası: ${e.message}`;
                updateBulkMainFinalizeButtonUI();
                showToast('Hata', e.message, 'error');
            }
        }

        // Geriye dönük uyumluluk için alias
        const triggerBulkAllianceOrder = () => triggerBulkOrder('ALLIANCE');

        async function distributeSelectedCriticalToCardDepos() {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Toplu Sipariş Dağıtımı')) return;
            syncCriticalDomStateToMaps();
            const checks = document.querySelectorAll('.bulkItemCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', 'Lütfen seçili depolara dağıtmak için en az bir ilaç seçiniz (veya kart üzerinden adet/depo değiştiriniz).', 'info');
                return;
            }

            const groupsByDepo = {};
            const allOrderedItems = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
                if (!it) return;
                const input = document.getElementById(`bulkQtyInput_${idx}`);
                const qty = input ? (parseInt(input.value) || 1) : 1;
                const depo = ((window.cardSelectedDepos && window.cardSelectedDepos[idx]) || window.defaultQuickDepo || 'ALLIANCE').toUpperCase();
                if (!groupsByDepo[depo]) groupsByDepo[depo] = [];
                const itemObj = {
                    barcode: it.barkod || '',
                    name: it.urun_adi || '',
                    miktar: qty,
                    target_depo: depo
                };
                groupsByDepo[depo].push(itemObj);
                allOrderedItems.push(itemObj);
            });

            if (allOrderedItems.length === 0) {
                showToast('Seçim Yapılmadı', 'Dağıtılacak geçerli ilaç bulunamadı.', 'info');
                return;
            }

            await executeMultiDepotBulkDistribution(groupsByDepo, allOrderedItems);
        }

        async function executeMultiDepotBulkDistribution(groupsByDepo, allOrderedItems) {
            const depoKeys = Object.keys(groupsByDepo).filter(k => Array.isArray(groupsByDepo[k]) && groupsByDepo[k].length > 0);
            if (depoKeys.length === 0) return;

            const firstDepo = depoKeys[0];
            const firstCfg = DEPO_BULK_CONFIGS[firstDepo] || DEPO_BULK_CONFIGS['ALLIANCE'];

            const preserved = getPreservedBulkCartState();
            const newPendingDistResults = allOrderedItems.map(it => {
                const dCfg = DEPO_BULK_CONFIGS[it.target_depo] || firstCfg;
                return {
                    barcode: it.barcode,
                    name: it.name,
                    miktar: it.miktar,
                    target_depo: it.target_depo,
                    status: 'PENDING',
                    assigned_depo: null,
                    net_fiyat: 0,
                    vade: 30,
                    message: `${dCfg.shortName || dCfg.name} sırasında bekliyor`
                };
            });
            const filteredPreservedDist = preserved.allResults.filter(pr => {
                return !allOrderedItems.some(nt => nt.barcode && pr.barcode && nt.barcode === pr.barcode && String(nt.target_depo || '').toUpperCase() === String(pr.assigned_depo || '').toUpperCase());
            });
            window.currentBulkState = {
                depo: firstDepo,
                initialDepo: firstDepo,
                triedDepos: Array.from(new Set([...preserved.triedDepos, ...depoKeys])),
                requestedItems: allOrderedItems,
                depoSessions: { ...preserved.depoSessions },
                missingItems: [],
                preservedResults: filteredPreservedDist,
                allResults: [...newPendingDistResults]
            };

            const modal = document.getElementById('bulkOrderModal');
            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
            }
            resetBulkOrderModalUIForNewRun(allOrderedItems.length);

            const modalTitle = document.getElementById('bulkModalTitle');
            const modalDesc = document.getElementById('bulkModalDesc');
            const modalIcon = document.getElementById('bulkModalIcon');
            const modalTargetDepo = document.getElementById('bulkModalTargetDepo');
            const modalCartLink = document.getElementById('bulkModalCartLink');
            const modalCartText = document.getElementById('bulkModalCartBtnText');

            if (depoKeys.length > 1) {
                if (modalTitle) modalTitle.innerText = `🔀 Seçili Depolara Otomatik Sipariş Dağıtımı (${depoKeys.length} Depo)`;
                if (modalDesc) modalDesc.innerText = `Seçtiğiniz ${allOrderedItems.length} kalem ilaç, kartlarda belirlediğiniz depolara (${depoKeys.join(', ')}) ayrı ayrı aktarılıyor.`;
                if (modalTargetDepo) modalTargetDepo.innerText = `${depoKeys.length} Depo B2B`;
                if (modalIcon) modalIcon.className = 'fa-solid fa-arrows-split-up-and-left';
            } else {
                if (modalTitle) modalTitle.innerText = firstCfg.title;
                if (modalDesc) modalDesc.innerText = firstCfg.desc;
                if (modalTargetDepo) modalTargetDepo.innerText = `${firstCfg.name} B2B`;
                if (modalIcon) modalIcon.className = firstCfg.icon;
            }
            if (modalCartLink) {
                modalCartLink.href = firstCfg.cartUrl;
                modalCartLink.onclick = function(e) {
                    e.preventDefault();
                    if (typeof window.openAuthenticatedPortal === 'function') {
                        window.openAuthenticatedPortal(firstDepo, firstCfg.cartUrl);
                    } else {
                        window.open(firstCfg.cartUrl, '_blank', 'noopener,noreferrer');
                    }
                    return false;
                };
            }
            if (modalCartText) modalCartText.innerText = firstCfg.cartBtnText;

            const missingBar = document.getElementById('bulkTransferMissingBar');
            if (missingBar) missingBar.classList.add('hidden');
            const breakdownEl = document.getElementById('bulkModalDepoBreakdown');
            if (breakdownEl) breakdownEl.classList.add('hidden');

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');
            const statTotal = document.getElementById('bulkStatTotal');
            const statSuccess = document.getElementById('bulkStatSuccess');
            const statFailed = document.getElementById('bulkStatFailed');
            const statAmount = document.getElementById('bulkStatAmount');

            if (statTotal) statTotal.innerText = allOrderedItems.length;
            if (statSuccess) statSuccess.innerText = '0';
            if (statFailed) statFailed.innerText = '0';
            if (statAmount) statAmount.innerText = '0.00 ₺';

            renderBulkItemsTable();

            const allMissing = [];
            let totalAddedCount = 0;
            let totalAddedAmount = 0;
            const grandTotalCnt = Math.max(1, allOrderedItems.length);
            let completedSoFarCnt = 0;

            for (let i = 0; i < depoKeys.length; i++) {
                const dKey = depoKeys[i];
                const dItems = groupsByDepo[dKey];
                const cfg = DEPO_BULK_CONFIGS[dKey] || DEPO_BULK_CONFIGS['ALLIANCE'];
                const startPct = Math.max(4, Math.round((completedSoFarCnt / grandTotalCnt) * 94) + 4);
                const endPct = Math.min(98, Math.round(((completedSoFarCnt + dItems.length) / grandTotalCnt) * 94) + 4);
                const usedGroupLookup = new Set();
                const groupRowRefs = dItems.map(dit => window.findMatchingBulkRow(newPendingDistResults, dit, dKey, usedGroupLookup));

                try {
                    const data = await window.runBulkAddWithLiveProgress({
                        depo: dKey,
                        items: dItems,
                        cfg: cfg,
                        rowRefs: groupRowRefs,
                        rangeStartPct: startPct,
                        rangeEndPct: endPct,
                        prefixLabel: depoKeys.length > 1 ? `[${i + 1}/${depoKeys.length} • ${cfg.shortName || cfg.name}] ` : '',
                        baseSuccessCount: totalAddedCount,
                        baseFailedCount: allMissing.length,
                        baseAmount: totalAddedAmount
                    });
                    const successCount = data.success_count || 0;
                    const dAmount = data.total_amount || 0;

                    window.currentBulkState.depoSessions[dKey] = {
                        count: successCount,
                        amount: dAmount,
                        name: cfg.name,
                        cartUrl: cfg.cartUrl,
                        finalized: false
                    };

                    totalAddedCount += successCount;
                    totalAddedAmount += dAmount;

                    const results = data.items || [];
                    const distAddedBarcodes = [];
                    const distAddedOptimistic = [];
                    const usedRows = new Set();
                    results.forEach(r => {
                        const target = window.findMatchingBulkRow(groupRowRefs, r, dKey, usedRows)
                                    || window.findMatchingBulkRow(window.currentBulkState.allResults, r, dKey, null);

                        if (r.success) {
                            if (r.barcode) distAddedBarcodes.push(r.barcode);
                            distAddedOptimistic.push({
                                barkod: r.barcode || (target && target.barcode) || '',
                                urun_adi: r.name || (target && target.name) || '',
                                miktar: r.miktar || (target && target.miktar) || 1,
                                depo: dKey
                            });
                            if (target) {
                                target.status = 'ADDED';
                                target.assigned_depo = dKey;
                                target.urun_id = r.urun_id || r.matnr || r.urun_kodu || target.urun_id || '';
                                target.net_fiyat = r.net_fiyat || 0;
                                target.vade = r.vade || 30;
                                target.message = r.message || 'Eklendi';
                            }
                        } else {
                            if (target) {
                                target.status = 'YOK';
                                target.assigned_depo = null;
                                target.message = r.message || `${cfg.name} deposunda stok yok`;
                            }
                            allMissing.push({
                                barcode: r.barcode,
                                name: r.name || (target ? target.name : r.barcode),
                                miktar: r.miktar || (target ? target.miktar : 1),
                                message: r.message || `${cfg.name} deposunda stok yok`
                            });
                        }
                    });
                    if (distAddedOptimistic.length > 0 && typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus(distAddedOptimistic, 'SEPETTE', dKey);
                    }
                    uncheckCompletedCriticalItems(distAddedBarcodes);
                } catch (e) {
                    dItems.forEach((dit, idxD) => {
                        const target = groupRowRefs[idxD] || window.currentBulkState.allResults.find(
                            it => it.barcode === dit.barcode && (!it.target_depo || it.target_depo === dKey)
                        );
                        if (target) {
                            target.status = 'YOK';
                            target.assigned_depo = null;
                            target.message = `${cfg.name} bağlantı hatası: ${e.message}`;
                        }
                        allMissing.push({
                            barcode: dit.barcode,
                            name: dit.name || dit.barcode,
                            miktar: dit.miktar || 1,
                            message: `${cfg.name} bağlantı hatası`
                        });
                    });
                }
                completedSoFarCnt += dItems.length;

                window.currentBulkState.missingItems = [...allMissing];
                renderDepoBreakdownPills();
                renderBulkItemsTable();
            }

            if (pBar) pBar.style.width = '100%';
            if (pPercent) pPercent.innerText = '%100';
            if (pSpinner) pSpinner.className = 'fa-solid fa-circle-check text-emerald-600';

            if (statSuccess) statSuccess.innerText = `${totalAddedCount} Kalem`;
            if (statFailed) statFailed.innerText = `${allMissing.length} Kalem`;
            if (statAmount) statAmount.innerText = `${totalAddedAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;

            const tabAllCount = document.getElementById('bulkTabCountAll');
            const tabYokCount = document.getElementById('bulkTabCountYok');
            if (tabAllCount) tabAllCount.innerText = allOrderedItems.length;
            if (tabYokCount) tabYokCount.innerText = allMissing.length;

            if (pText) {
                pText.innerHTML = `<strong>Dağıtım Tamamlandı:</strong> ${depoKeys.length} depoya toplam <strong>${totalAddedCount} kalem</strong> ürün eklendi! ${allMissing.length > 0 ? `<span class="text-rose-600 font-bold ml-1">(${allMissing.length} kalem seçilen depoda bulunamadı)</span>` : '<span class="text-emerald-600 font-bold ml-1">(Tüm ürünler eksiksiz eklendi!)</span>'}`;
            }

            renderDepoBreakdownPills();
            updateBulkMainFinalizeButtonUI();
            renderTransferMissingBar(depoKeys[depoKeys.length - 1]);
            renderBulkItemsTable();

            showToast('Seçili Depolara Dağıtıldı', `${depoKeys.length} depo sepetine toplam ${totalAddedCount} kalem ürün aktarıldı.`, totalAddedCount > 0 ? 'success' : 'error');
            if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
        }

        // ================= Otomatik Girişli Portal Açıcı & Doğrudan Teklife Katılma =================
        window.openAuthenticatedPortal = async function(depo, targetUrl = '') {
            const cleanDepo = String(depo || 'ECZANETAKAS').toUpperCase();
            if (typeof showToast === 'function') {
                showToast('Otomatik Giriş', `${cleanDepo} portalı kayıtlı oturumunuzla (şifresiz) açılıyor...`, 'info');
            }
            try {
                const res = await fetch('/api/portal/open-browser', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: cleanDepo, target_url: targetUrl || '' })
                });
                const data = await res.json();
                if (data && data.success) {
                    if (typeof showToast === 'function') {
                        showToast('Portal Hazır', `${cleanDepo} penceresi otomatik giriş yapılmış halde açıldı.`, 'success');
                    }
                    return;
                }
            } catch (e) {
                console.warn('Portal open-browser uyarısı:', e);
            }
            const fbUrl = `/api/portal/auto-login?depo=${encodeURIComponent(cleanDepo)}&target=${encodeURIComponent(targetUrl || '')}`;
            window.open(fbUrl, '_blank');
        };

        window.offerJoinQtyDrafts = window.offerJoinQtyDrafts || {};

        window._normalizeOfferQty = function(rawVal, minVal = 1, maxVal = 999, stepVal = 1, snapStep = true) {
            const minN = Math.max(1, parseInt(minVal, 10) || 1);
            const maxN = Math.max(minN, parseInt(maxVal, 10) || 999);
            const stepN = Math.max(1, parseInt(stepVal, 10) || 1);
            let v = parseInt(rawVal, 10);
            if (isNaN(v) || v < minN) v = minN;
            if (v > maxN) v = maxN;
            if (snapStep && stepN > 1) {
                const snapped = Math.round(v / stepN) * stepN;
                v = Math.max(minN, Math.min(maxN, snapped || stepN));
                if (v % stepN !== 0) {
                    const up = Math.ceil(minN / stepN) * stepN;
                    const down = Math.floor(maxN / stepN) * stepN;
                    if (up <= maxN) v = up;
                    else if (down >= minN) v = down;
                }
            }
            return v;
        };

        window.getOfferJoinInitialQty = function(draftKey, minVal = 1, maxVal = 999, stepVal = 1, existingQty = 0) {
            const key = String(draftKey || '').trim();
            const minN = Math.max(1, parseInt(minVal, 10) || 1);
            const maxN = Math.max(minN, parseInt(maxVal, 10) || 999);
            const stepN = Math.max(1, parseInt(stepVal, 10) || 1);
            if (key && window.offerJoinQtyDrafts && window.offerJoinQtyDrafts[key] !== undefined) {
                return window._normalizeOfferQty(window.offerJoinQtyDrafts[key], minN, maxN, stepN, false);
            }
            const baseDefault = (parseInt(existingQty, 10) || 0) > 0
                ? parseInt(existingQty, 10)
                : (stepN > 1 ? Math.ceil(minN / stepN) * stepN : minN);
            return window._normalizeOfferQty(baseDefault, minN, maxN, stepN, true);
        };

        window.syncOfferQtyInputsForKey = function(draftKey, val, sourceEl = null) {
            if (!draftKey) return;
            window.offerJoinQtyDrafts[draftKey] = val;
            document.querySelectorAll(`input[data-offer-qty-key="${draftKey}"]`).forEach(inp => {
                if (inp !== sourceEl) inp.value = String(val);
            });
        };

        window.onOfferQtyInputChange = function(inputEl, draftKey, minVal = 1, maxVal = 999, stepVal = 1, commitClamp = false) {
            if (!inputEl) return;
            const rawStr = String(inputEl.value || '').trim();
            if (!commitClamp && rawStr === '') return;
            const parsed = parseInt(rawStr, 10);
            if (isNaN(parsed)) {
                if (commitClamp) {
                    const fixed = window._normalizeOfferQty(minVal, minVal, maxVal, stepVal, true);
                    inputEl.value = String(fixed);
                    window.syncOfferQtyInputsForKey(draftKey, fixed, inputEl);
                }
                return;
            }
            if (commitClamp) {
                const fixed = window._normalizeOfferQty(parsed, minVal, maxVal, stepVal, true);
                inputEl.value = String(fixed);
                window.syncOfferQtyInputsForKey(draftKey, fixed, inputEl);
            } else {
                window.syncOfferQtyInputsForKey(draftKey, Math.max(1, parsed), inputEl);
            }
        };

        window.stepOfferJoinQty = function(btnOrId, delta, maxVal = 999, minVal = 1, stepVal = 1) {
            let el = null;
            if (btnOrId && typeof btnOrId === 'object' && btnOrId.closest) {
                const wrap = btnOrId.closest('[data-qty-stepper]') || btnOrId.parentElement;
                if (wrap) el = wrap.querySelector('input[type="number"], input[data-offer-qty-key]');
            } else if (typeof btnOrId === 'string') {
                el = document.getElementById(btnOrId) || document.querySelector(`input[data-offer-qty-key="${btnOrId}"]`);
            }
            if (!el) return;
            const minN = Math.max(1, parseInt(minVal, 10) || parseInt(el.min, 10) || 1);
            const maxN = Math.max(minN, parseInt(maxVal, 10) || parseInt(el.max, 10) || 999);
            const stepN = Math.max(1, parseInt(stepVal, 10) || parseInt(el.step, 10) || 1);
            const dir = (parseInt(delta, 10) || 0) >= 0 ? 1 : -1;
            const cur = parseInt(el.value, 10) || minN;
            let next = cur + (dir * stepN);
            if (stepN > 1) {
                if (dir > 0) {
                    next = (Math.floor(cur / stepN) + 1) * stepN;
                } else {
                    next = (Math.ceil(cur / stepN) - 1) * stepN;
                }
            }
            next = window._normalizeOfferQty(next, minN, maxN, stepN, true);
            el.value = String(next);
            const dKey = el.getAttribute('data-offer-qty-key') || '';
            if (dKey) {
                window.syncOfferQtyInputsForKey(dKey, next, el);
            }
        };

        window._resolveOfferJoinQty = function(btnEl, draftKey, fallbackId = '') {
            if (btnEl && typeof btnEl === 'object' && btnEl.closest) {
                const grp = btnEl.closest('[data-join-group]') || btnEl.parentElement;
                if (grp) {
                    const localInp = grp.querySelector('input[data-offer-qty-key], input[type="number"]');
                    if (localInp) {
                        const lv = parseInt(localInp.value, 10);
                        if (!isNaN(lv) && lv >= 1) return lv;
                    }
                }
            }
            if (draftKey && window.offerJoinQtyDrafts && window.offerJoinQtyDrafts[draftKey] !== undefined) {
                const dv = parseInt(window.offerJoinQtyDrafts[draftKey], 10);
                if (!isNaN(dv) && dv >= 1) return dv;
            }
            if (fallbackId) {
                const fEl = document.getElementById(fallbackId);
                if (fEl) {
                    const fv = parseInt(fEl.value, 10);
                    if (!isNaN(fv) && fv >= 1) return fv;
                }
            }
            return 1;
        };

        window.findTodayOrderMatchForOffer = function(o, depoCode = 'ECZANETAKAS') {
            if (!o) return null;
            const dCode = String(depoCode || 'ECZANETAKAS').toUpperCase();
            const map = window.todayOrdersMap || {};
            const oid = String(o.teklif_no || o.offer_id || '').trim();
            const offerKey = oid
                ? (dCode === 'ECZANETAKAS' ? ('ET_' + oid) : ('ETR_' + oid.slice(0, 24)))
                : '';
            const bc = String(o.barcode || o.barkod || '').trim();
            const bcNoZero = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;
            const bcWithZero = (bc.length === 13 && /^\\d+$/.test(bc)) ? ('0' + bc) : '';
            const nmUpper = String(o.urun_adi || '').trim().toUpperCase();

            const byOfferKey = offerKey ? map[offerKey] : null;
            const byBc = (bc && map[bc]) || (bcNoZero && map[bcNoZero]) || (bcWithZero && map[bcWithZero]) || null;
            const byNm = (nmUpper && map[nmUpper]) || (nmUpper && map['NAME:' + nmUpper.slice(0, 24)]) || null;
            const mapHit = byOfferKey || byBc || byNm || null;
            const liveMevcut = dCode === 'ECZATREND' ? (parseInt(o.mevcut_alim || 0, 10) || 0) : 0;

            const isThisOfferJoined = Boolean(
                liveMevcut > 0
                || o.katilindi
                || byOfferKey
                || (o.siparis_durumu === 'SIPARIS_VERILDI' && String(o.siparis_depo || '').toUpperCase() === dCode)
                || (mapHit && mapHit.durum === 'SIPARIS_VERILDI' && String(mapHit.depo || '').toUpperCase() === dCode)
            );
            const sipDurumu = o.siparis_durumu || (mapHit ? mapHit.durum : null);
            const sipDepo = o.siparis_depo || (mapHit ? mapHit.depo : null);
            const sipMiktar = liveMevcut > 0
                ? liveMevcut
                : (parseInt(o.katilinan_miktar || o.siparis_miktar || (mapHit ? mapHit.miktar : 0) || 0, 10) || 0);
            const sipSaat = o.siparis_saat || (mapHit ? mapHit.saat : '') || '';
            const sipMasa = o.siparis_masa || (mapHit ? (mapHit.masa_adi || mapHit.masa) : '') || '';

            if (!isThisOfferJoined && !sipDurumu) return null;
            return {
                isThisOfferJoined: isThisOfferJoined,
                siparis_durumu: isThisOfferJoined ? 'SIPARIS_VERILDI' : sipDurumu,
                siparis_depo: isThisOfferJoined ? dCode : (sipDepo || dCode),
                siparis_miktar: Math.max(1, sipMiktar || 1),
                siparis_saat: sipSaat,
                siparis_masa: sipMasa
            };
        };

        window.joinEczaneTakasOfferDirect = async function(teklifNo, barcode, urunAdi, maxStok = 999, btnEl = null) {
            const dKey = `ET_${teklifNo}`;
            const miktar = window._resolveOfferJoinQty(btnEl, dKey, `etJoinQty_${teklifNo}`);
            const cachedOffer = (window.etActiveOffersCache || []).find(x => String(x.teklif_no) === String(teklifNo));
            const maxLim = Math.max(1, parseInt(maxStok || (cachedOffer ? cachedOffer.kalan_stok : 999), 10) || 999);
            if (miktar > maxLim) {
                if (typeof showToast === 'function') {
                    showToast('Stok Sınırı', `Bu teklifte kalan stok ${maxLim} kutudur (girilen: ${miktar}).`, 'error');
                }
                return;
            }
            const existingOrd = window.findTodayOrderMatchForOffer(
                cachedOffer || { teklif_no: teklifNo, barcode: barcode, urun_adi: urunAdi },
                'ECZANETAKAS'
            );
            if (existingOrd && (existingOrd.siparis_durumu === 'SIPARIS_VERILDI' || existingOrd.isThisOfferJoined)) {
                const warnMsg = `⚠️ DİKKAT: BUGÜN SİPARİŞ / KATILIM KAYDI VAR!\\n\\n`
                    + `"${urunAdi || barcode}" ürünü için bugün zaten işlem yapılmış:\\n`
                    + `• Platform / Depo: ${existingOrd.siparis_depo || 'ECZANETAKAS'}\\n`
                    + `• Sipariş / Katılım Adedi: ${existingOrd.siparis_miktar || 1} Kutu\\n`
                    + (existingOrd.siparis_saat ? `• Saat / Bilgisayar: ${existingOrd.siparis_saat} ${existingOrd.siparis_masa ? '(' + existingOrd.siparis_masa + ')' : ''}\\n` : '')
                    + `\\nYine de EczaneTakas (#${teklifNo}) teklifine ${miktar} kutu daha katılmak istiyor musunuz?`;
                if (!window.confirm(warnMsg)) {
                    return;
                }
            }
            const origHtml = btnEl ? btnEl.innerHTML : '';
            if (btnEl) {
                btnEl.disabled = true;
                btnEl.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1"></i>Katılıyor...`;
            }
            try {
                const res = await fetch('/api/eczanetakas/join', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        teklif_no: String(teklifNo),
                        barcode: String(barcode || ''),
                        urun_adi: String(urunAdi || ''),
                        miktar: miktar
                    })
                });
                const data = await res.json();
                if (data && data.success && !data.simulated) {
                    const nowStr = data.siparis_saat || new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                    const pcLabel = data.siparis_masa || window.currentPcName || 'Bu PC';
                    const prevQty = existingOrd && existingOrd.isThisOfferJoined ? (parseInt(existingOrd.siparis_miktar, 10) || 0) : 0;
                    const totalQty = parseInt(data.siparis_miktar, 10) || (prevQty + miktar);

                    if (typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus([{
                            barkod: String(barcode || ''),
                            urun_adi: String(urunAdi || ''),
                            miktar: totalQty,
                            depo: 'ECZANETAKAS',
                            offer_key: 'ET_' + String(teklifNo)
                        }], 'SIPARIS_VERILDI', 'ECZANETAKAS');
                    }

                    // Önbellekteki kalan stoğu ve katılım durumunu güncelle
                    const cached = (window.etActiveOffersCache || []).find(x => String(x.teklif_no) === String(teklifNo));
                    if (cached) {
                        if (data.kalan !== undefined && data.kalan !== null && !isNaN(parseInt(data.kalan, 10))) {
                            cached.kalan_stok = parseInt(data.kalan, 10);
                        } else {
                            cached.kalan_stok = Math.max(0, (parseInt(cached.kalan_stok, 10) || 0) - miktar);
                        }
                        cached.katilindi = true;
                        cached.katilinan_miktar = totalQty;
                        cached.siparis_durumu = 'SIPARIS_VERILDI';
                        cached.siparis_depo = 'ECZANETAKAS';
                        cached.siparis_miktar = totalQty;
                        cached.siparis_saat = nowStr;
                        cached.siparis_masa = pcLabel;
                        const stokBadge = document.getElementById(`etKalanStok_${teklifNo}`);
                        if (stokBadge) stokBadge.innerText = `${cached.kalan_stok} Kt`;
                    }
                    delete window.offerJoinQtyDrafts[dKey];

                    if (btnEl) {
                        btnEl.disabled = false;
                        btnEl.className = 'px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[11px] flex items-center space-x-1 cursor-pointer shadow-xs';
                        btnEl.innerHTML = `<i class="fa-solid fa-circle-check mr-1"></i><span>Katılındı (${totalQty} Kt)</span>`;
                    }

                    // Aktif arama raporu (currentReport) açıksa içindeki ECZANETAKAS satırını ve tekliflerini de güncelle
                    if (typeof currentReport !== 'undefined' && currentReport && Array.isArray(currentReport.sonuclar)) {
                        currentReport.sonuclar.forEach(s => {
                            if (String(s.depo || '').toUpperCase() === 'ECZANETAKAS') {
                                s.katilindi = true;
                                s.katilinan_miktar = totalQty;
                                s.siparis_durumu = 'SIPARIS_VERILDI';
                                s.siparis_depo = 'ECZANETAKAS';
                                s.siparis_miktar = totalQty;
                                s.siparis_saat = nowStr;
                                s.siparis_masa = pcLabel;
                                (s.pazaryeri_teklifleri || []).forEach(pt => {
                                    if (String(pt.teklif_no) === String(teklifNo)) {
                                        pt.katilindi = true;
                                        pt.katilinan_miktar = totalQty;
                                        pt.siparis_durumu = 'SIPARIS_VERILDI';
                                        pt.siparis_depo = 'ECZANETAKAS';
                                        pt.siparis_miktar = totalQty;
                                        pt.siparis_saat = nowStr;
                                        pt.siparis_masa = pcLabel;
                                        pt.stok = Math.max(0, (parseInt(pt.stok, 10) || 0) - miktar);
                                    }
                                });
                            }
                        });
                        if (typeof renderResults === 'function') renderResults(currentReport);
                    }
                    if (typeof refreshCurrentSearchOrderBanner === 'function') {
                        refreshCurrentSearchOrderBanner();
                    }
                    const etModal = document.getElementById('eczanetakasOffersModal');
                    if (etModal && !etModal.classList.contains('hidden') && (window.etModalActiveTab || 'offers') === 'offers') {
                        renderEczaneTakasOffersModal();
                    }
                    if (typeof showToast === 'function') {
                        showToast('Teklife Katıldınız! 🎉', data.message || `${urunAdi} (#${teklifNo}) teklifine ${miktar} kutu ile katıldınız.`, 'success');
                    }
                    setTimeout(() => {
                        if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                        if (typeof loadEndOfDaySummary === 'function') loadEndOfDaySummary();
                    }, 300);
                } else {
                    if (btnEl) {
                        btnEl.disabled = false;
                        btnEl.innerHTML = origHtml;
                    }
                    if (typeof showToast === 'function') {
                        showToast('Katılım Uyarısı', (data && data.message) || 'Teklife doğrudan katılınamadı.', 'error');
                    }
                }
            } catch (e) {
                if (btnEl) {
                    btnEl.disabled = false;
                    btnEl.innerHTML = origHtml;
                }
                if (typeof showToast === 'function') {
                    showToast('Bağlantı Hatası', e.message || 'Sunucuya ulaşılamadı.', 'error');
                }
            }
        };

        window.joinEczatrendOfferDirect = async function(offerId, barcode, urunAdi, maxStok = 999, btnEl = null, minAlim = 1, alimKati = 1, mevcutAlim = 0, isPaidOffer = false) {
            const dKey = `ETR_${offerId}`;
            const miktar = window._resolveOfferJoinQty(btnEl, dKey, `etrJoinQty_${offerId}`);
            const cachedOffer = (window.eczatrendActiveOffersCache || []).find(x => String(x.offer_id) === String(offerId));

            const effMin = Math.max(1, parseInt(minAlim || (cachedOffer ? cachedOffer.min_alim : 1), 10) || 1);
            const effKat = Math.max(1, parseInt(alimKati || (cachedOffer ? cachedOffer.alim_kati : 1), 10) || 1);
            const effMax = Math.max(effMin, parseInt(maxStok || (cachedOffer ? (cachedOffer.max_katilim || cachedOffer.kalan) : 999), 10) || 999);
            const effPaid = Boolean(isPaidOffer || (cachedOffer && cachedOffer.is_paid_offer));
            const effMevcut = Math.max(0, parseInt(mevcutAlim || (cachedOffer ? cachedOffer.mevcut_alim : 0), 10) || 0);

            if (effPaid) {
                if (typeof showToast === 'function') {
                    showToast('Ödemeli Teklif', 'Bu teklif ödemeli (kart/bakiye) teklif türündedir; Eczatrend portalı üzerinden tamamlanmalıdır.', 'info');
                }
                window.openAuthenticatedPortal('ECZATREND', 'https://eczatrend.com/eczanet/panelNew/main.html');
                return;
            }
            if (effKat > 1 && (miktar % effKat !== 0)) {
                if (typeof showToast === 'function') {
                    showToast('Alım Katı Kuralı', `Bu teklifte ${effKat} ve katları (${effKat}, ${effKat * 2}, ${effKat * 3}...) şeklinde katılım yapılabilir. Girilen: ${miktar}`, 'error');
                }
                return;
            }
            if (miktar < effMin) {
                if (typeof showToast === 'function') {
                    showToast('Minimum Alım Sınırı', `Bu teklif için en az ${effMin} kutu katılım yapılabilir (girilen: ${miktar}).`, 'error');
                }
                return;
            }
            if (miktar > effMax) {
                if (typeof showToast === 'function') {
                    showToast('Maksimum Alım Sınırı', `Bu teklif için en fazla ${effMax} kutu katılım yapılabilir (girilen: ${miktar}).`, 'error');
                }
                return;
            }

            const existingOrd = window.findTodayOrderMatchForOffer(
                cachedOffer || { offer_id: offerId, barcode: barcode, urun_adi: urunAdi, mevcut_alim: effMevcut },
                'ECZATREND'
            );
            const prevJoinedQty = effMevcut > 0
                ? effMevcut
                : ((existingOrd && existingOrd.isThisOfferJoined) ? (parseInt(existingOrd.siparis_miktar, 10) || 0) : 0);

            if (prevJoinedQty > 0) {
                const updMsg = `🔄 ECZATREND ALIM GÜNCELLEME ONAYI\\n\\n`
                    + `"${urunAdi || barcode}" teklifinde mevcut alımınız: ${prevJoinedQty} Kutu.\\n`
                    + `Eczatrend kuralı gereği girdiğiniz ${miktar} Kutu, bu teklifteki TOPLAM alımınız olarak güncellenecektir (${prevJoinedQty} Kutu ➔ ${miktar} Kutu).\\n\\n`
                    + `Toplam alımınızı ${miktar} Kutu olarak güncellemek istiyor musunuz?`;
                if (!window.confirm(updMsg)) {
                    return;
                }
            } else if (existingOrd && existingOrd.siparis_durumu === 'SIPARIS_VERILDI') {
                const warnMsg = `⚠️ DİKKAT: BUGÜN SİPARİŞ KAYDI VAR!\\n\\n`
                    + `"${urunAdi || barcode}" ürünü için bugün başka bir depodan/tekliften işlem yapılmış:\\n`
                    + `• Platform / Depo: ${existingOrd.siparis_depo || 'DEPO'}\\n`
                    + `• Adet: ${existingOrd.siparis_miktar || 1} Kutu\\n`
                    + (existingOrd.siparis_saat ? `• Saat / Bilgisayar: ${existingOrd.siparis_saat} ${existingOrd.siparis_masa ? '(' + existingOrd.siparis_masa + ')' : ''}\\n` : '')
                    + `\\nYine de bu Eczatrend ortak alımına ${miktar} kutu ile katılmak istiyor musunuz?`;
                if (!window.confirm(warnMsg)) {
                    return;
                }
            }

            const origHtml = btnEl ? btnEl.innerHTML : '';
            if (btnEl) {
                btnEl.disabled = true;
                btnEl.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1"></i>${prevJoinedQty > 0 ? 'Güncelleniyor...' : 'Katılıyor...'}`;
            }
            try {
                const res = await fetch('/api/eczatrend/join', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        offer_id: String(offerId),
                        barcode: String(barcode || ''),
                        urun_adi: String(urunAdi || ''),
                        miktar: miktar
                    })
                });
                const data = await res.json();
                if (data && data.success) {
                    const nowStr = data.siparis_saat || new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                    const pcLabel = data.siparis_masa || window.currentPcName || 'Bu PC';
                    const totalQty = parseInt(data.mevcut_alim || data.siparis_miktar || miktar, 10) || miktar;

                    if (typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus([{
                            barkod: String(barcode || ''),
                            urun_adi: String(urunAdi || ''),
                            miktar: totalQty,
                            depo: 'ECZATREND',
                            offer_key: 'ETR_' + String(offerId).slice(0, 24)
                        }], 'SIPARIS_VERILDI', 'ECZATREND');
                    }

                    const cached = (window.eczatrendActiveOffersCache || []).find(x => String(x.offer_id) === String(offerId));
                    if (cached) {
                        const oldMev = parseInt(cached.mevcut_alim || prevJoinedQty || 0, 10) || 0;
                        if (data.kalan !== undefined && data.kalan !== null && !isNaN(parseInt(data.kalan, 10))) {
                            cached.kalan = parseInt(data.kalan, 10);
                        } else {
                            cached.kalan = Math.max(0, (parseInt(cached.kalan, 10) || 0) + oldMev - totalQty);
                        }
                        cached.alinan = Math.max(0, (parseInt(cached.alinan, 10) || 0) - oldMev + totalQty);
                        cached.mevcut_alim = totalQty;
                        cached.katilindi = true;
                        cached.katilinan_miktar = totalQty;
                        cached.siparis_durumu = 'SIPARIS_VERILDI';
                        cached.siparis_depo = 'ECZATREND';
                        cached.siparis_miktar = totalQty;
                        cached.siparis_saat = nowStr;
                        cached.siparis_masa = pcLabel;
                        const kalanBadge = document.getElementById(`etrKalanStok_${offerId}`);
                        if (kalanBadge) kalanBadge.innerText = `Kalan: ${cached.kalan}`;
                    }
                    window.syncOfferQtyInputsForKey(dKey, totalQty, null);

                    if (btnEl) {
                        btnEl.disabled = false;
                        btnEl.className = 'px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[11px] flex items-center space-x-1 cursor-pointer shadow-xs';
                        btnEl.innerHTML = `<i class="fa-solid fa-circle-check mr-1"></i><span>Güncelle (${totalQty} Kt)</span>`;
                    }

                    if (typeof currentReport !== 'undefined' && currentReport && Array.isArray(currentReport.sonuclar)) {
                        currentReport.sonuclar.forEach(s => {
                            if (String(s.depo || '').toUpperCase() === 'ECZATREND') {
                                s.katilindi = true;
                                s.katilinan_miktar = totalQty;
                                s.siparis_durumu = 'SIPARIS_VERILDI';
                                s.siparis_depo = 'ECZATREND';
                                s.siparis_miktar = totalQty;
                                s.siparis_saat = nowStr;
                                s.siparis_masa = pcLabel;
                                (s.pazaryeri_teklifleri || []).forEach(pt => {
                                    if (String(pt.offer_id) === String(offerId)) {
                                        const oldPtMev = parseInt(pt.mevcut_alim || prevJoinedQty || 0, 10) || 0;
                                        pt.mevcut_alim = totalQty;
                                        pt.katilindi = true;
                                        pt.katilinan_miktar = totalQty;
                                        pt.siparis_durumu = 'SIPARIS_VERILDI';
                                        pt.siparis_depo = 'ECZATREND';
                                        pt.siparis_miktar = totalQty;
                                        pt.siparis_saat = nowStr;
                                        pt.siparis_masa = pcLabel;
                                        pt.kalan = (data.kalan !== undefined && data.kalan !== null && !isNaN(parseInt(data.kalan, 10)))
                                            ? parseInt(data.kalan, 10)
                                            : Math.max(0, (parseInt(pt.kalan, 10) || 0) + oldPtMev - totalQty);
                                    }
                                });
                            }
                        });
                        if (typeof renderResults === 'function') renderResults(currentReport);
                    }
                    if (typeof refreshCurrentSearchOrderBanner === 'function') {
                        refreshCurrentSearchOrderBanner();
                    }
                    const etrModal = document.getElementById('eczatrendOffersModal');
                    if (etrModal && !etrModal.classList.contains('hidden') && (window.etrModalActiveTab || 'offers') === 'offers') {
                        renderEczatrendOffersModal();
                    }
                    if (typeof showToast === 'function') {
                        showToast(
                            prevJoinedQty > 0 ? 'Eczatrend Alımı Güncellendi ✅' : 'Ortak Alıma Katıldınız! 🎉',
                            data.message || `${urunAdi} ortak alımı ${totalQty} kutu olarak kaydedildi.`,
                            'success'
                        );
                    }
                    setTimeout(() => {
                        if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                        if (typeof loadEndOfDaySummary === 'function') loadEndOfDaySummary();
                    }, 300);
                } else {
                    if (btnEl) {
                        btnEl.disabled = false;
                        btnEl.innerHTML = origHtml;
                    }
                    if (typeof showToast === 'function') {
                        showToast('Katılım Uyarısı', (data && data.message) || 'Ortak alıma katılınamadı.', 'error');
                    }
                    if (data && data.requires_portal) {
                        window.openAuthenticatedPortal('ECZATREND', 'https://eczatrend.com/eczanet/panelNew/main.html');
                    }
                }
            } catch (e) {
                if (btnEl) {
                    btnEl.disabled = false;
                    btnEl.innerHTML = origHtml;
                }
                if (typeof showToast === 'function') {
                    showToast('Bağlantı Hatası', e.message || 'Sunucuya ulaşılamadı.', 'error');
                }
            }
        };

        window.cancelEczatrendJoinDirect = async function(offerId, barcode, urunAdi, btnEl = null) {
            if (!window.confirm(`"${urunAdi || barcode}" teklifindeki Eczatrend katılımınızı İPTAL ETMEK istediğinize emin misiniz?`)) return;
            const origHtml = btnEl ? btnEl.innerHTML : '';
            if (btnEl) { btnEl.disabled = true; btnEl.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>'; }
            try {
                const res = await fetch('/api/eczatrend/cancel-join', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ offer_id: String(offerId), barcode: String(barcode || ''), urun_adi: String(urunAdi || '') })
                });
                const data = await res.json();
                if (data && data.success) {
                    const cached = (window.eczatrendActiveOffersCache || []).find(x => String(x.offer_id) === String(offerId));
                    if (cached) {
                        const oldM = parseInt(cached.mevcut_alim || cached.katilinan_miktar || 0, 10) || 0;
                        cached.kalan = (parseInt(cached.kalan, 10) || 0) + oldM;
                        cached.alinan = Math.max(0, (parseInt(cached.alinan, 10) || 0) - oldM);
                        cached.mevcut_alim = 0;
                        cached.katilindi = false;
                        cached.katilinan_miktar = 0;
                        cached.siparis_durumu = null;
                        cached.siparis_miktar = null;
                    }
                    delete window.offerJoinQtyDrafts[`ETR_${offerId}`];
                    if (typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus([{ barkod: String(barcode || ''), urun_adi: String(urunAdi || ''), offer_key: 'ETR_' + String(offerId).slice(0, 24) }], null, 'ECZATREND');
                    }
                    if (typeof showToast === 'function') showToast('Katılım İptal Edildi', data.message || 'Eczatrend katılımınız iptal edildi.', 'info');
                    const etrModal = document.getElementById('eczatrendOffersModal');
                    if (etrModal && !etrModal.classList.contains('hidden')) renderEczatrendOffersModal();
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    if (btnEl) { btnEl.disabled = false; btnEl.innerHTML = origHtml; }
                    if (typeof showToast === 'function') showToast('İptal Edilemedi', (data && data.message) || 'Katılım iptal edilemedi.', 'error');
                }
            } catch (e) {
                if (btnEl) { btnEl.disabled = false; btnEl.innerHTML = origHtml; }
                if (typeof showToast === 'function') showToast('Bağlantı Hatası', e.message, 'error');
            }
        };

        // ================= EczaneTakas Canlı Açık Teklifler & Teklif Açma Modalı =================
        window.etActiveOffersCache = [];
        window.etActiveOtomasyonName = '';
        window.etModalActiveTab = 'offers'; // 'offers' | 'create'
        window.etModalCreateState = {
            urunId: 0,
            urunAdi: '',
            barcode: '',
            portalPrice: 0,
            unitCost: 0,
            psf: 0,
            recPrice: 0,
            kdvOrani: 10,
            candidates: [],
            pharmacies: [],
            catalogCount: 0
        };
        let _etMdlSearchTimer = null;

        function ensureEczaneTakasModalDom() {
            if (document.getElementById('eczanetakasOffersModal')) return;
            const modalHtml = `
                <div id="eczanetakasOffersModal" class="hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
                    <div class="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-7xl max-h-[92vh] flex flex-col overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-sky-700 to-cyan-600 text-white flex flex-wrap items-center justify-between gap-2">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center">
                                    <i class="fa-solid fa-arrow-right-arrow-left text-lg"></i>
                                </div>
                                <div>
                                    <h3 class="text-base font-black leading-tight flex flex-wrap items-center gap-2">
                                        <span>EczaneTakas — Açık Teklifler & Teklif Merkezi</span>
                                        <span id="etModalCountBadge" class="px-2 py-0.5 rounded-full text-xs font-extrabold bg-white/20">0 Teklif</span>
                                        <span id="etModalOtoBadge" class="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-emerald-400/25 border border-emerald-300/40 text-emerald-50">🌿 Eczane Stok & 1A/3A Çıkış Entegreli</span>
                                    </h3>
                                    <p class="text-xs text-sky-100">Grup tekliflerine katılın veya raf stoğunuzdan doğrudan uygulama içinden yeni EczaneTakas teklifi yayınlayın</p>
                                </div>
                            </div>
                            <div class="flex items-center space-x-2">
                                <button type="button" onclick="refreshActiveEczaneTakasModalTab()" class="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer">
                                    <i class="fa-solid fa-rotate text-[11px]"></i>
                                    <span>Yenile</span>
                                </button>
                                <button type="button" onclick="openAuthenticatedPortal('ECZANETAKAS', 'https://eczanetakas.com/teklifler/1')" class="px-3 py-1.5 rounded-xl bg-white text-sky-800 hover:bg-sky-50 text-xs font-extrabold transition flex items-center space-x-1.5 cursor-pointer" title="Şifre girmeden doğrudan açık oturumla EczaneTakas portalını aç">
                                    <span>Portalı Aç ↗</span>
                                </button>
                                <button type="button" onclick="closeEczaneTakasOffersModal()" class="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                        </div>

                        <!-- 3 Ana Sekme Çubuğu -->
                        <div class="px-6 pt-2.5 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                            <div class="flex items-center gap-1.5">
                                <button type="button" id="etTabBtnOffers" onclick="switchEczaneTakasModalTab('offers')" class="px-3.5 py-2 rounded-t-xl text-xs font-extrabold bg-white text-sky-900 border border-b-0 border-slate-200 flex items-center gap-1.5 cursor-pointer shadow-2xs">
                                    <i class="fa-solid fa-cart-plus text-sky-600"></i>
                                    <span>Canlı Açık Teklifler (Katıl)</span>
                                </button>
                                <button type="button" id="etTabBtnCreate" onclick="switchEczaneTakasModalTab('create')" class="px-3.5 py-2 rounded-t-xl text-xs font-bold text-slate-600 hover:text-sky-800 flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-bullhorn text-emerald-600"></i>
                                    <span>➕ Yeni Teklif Aç (Uygulama İçi)</span>
                                </button>
                                <button type="button" id="etTabBtnMyOffers" onclick="switchEczaneTakasModalTab('my_offers')" class="px-3.5 py-2 rounded-t-xl text-xs font-bold text-slate-600 hover:text-sky-800 flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-clipboard-list text-indigo-600"></i>
                                    <span>📋 Tekliflerim</span>
                                    <span id="etMyOffersCountBadge" class="hidden px-1.5 py-0.2 rounded-full text-[10px] font-black bg-indigo-100 text-indigo-800">0</span>
                                </button>
                            </div>
                            <div id="etModalCatalogBadge" class="text-[11px] font-bold text-slate-500 pb-1.5"></div>
                        </div>

                        <!-- Sekme 1 Arama Çubuğu -->
                        <div id="etModalOffersToolbar" class="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3">
                            <div class="relative flex-1">
                                <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-2.5 text-slate-400 text-xs"></i>
                                <input type="search" role="searchbox" name="fr_et_modal_q" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" data-lpignore="true" data-1p-ignore="true" data-bwignore="true" data-form-type="other" id="etModalSearchInput" oninput="renderEczaneTakasOffersModal()" placeholder="İlaç adı, barkod veya teklif veren eczane ara..." class="w-full pl-9 pr-4 py-2 text-xs font-semibold rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white" />
                            </div>
                            <span class="text-[11px] text-slate-500 font-medium hidden sm:inline">⚡ Adet seçip <strong>"Katıl"</strong> ile anında katılabilir veya <strong>"➕ Yeni Teklif Aç"</strong> / <strong>"📋 Tekliflerim"</strong> sekmelerini kullanabilirsiniz</span>
                        </div>

                        <!-- Sekme 1 Gövde: Açık Teklifler -->
                        <div id="etModalBody" class="flex-1 overflow-y-auto p-4">
                            <div class="p-8 text-center text-slate-400 text-sm">Yükleniyor...</div>
                        </div>

                        <!-- Sekme 2 Gövde: Yeni EczaneTakas Teklifi Aç -->
                        <div id="etModalCreateBody" class="hidden flex-1 overflow-y-auto p-5 bg-slate-50/70 space-y-4"></div>

                        <!-- Sekme 3 Gövde: EczaneTakas Tekliflerim Yönetimi -->
                        <div id="etModalMyOffersBody" class="hidden flex-1 overflow-y-auto p-4 bg-slate-50/70 space-y-3"></div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHtml);
        }

        function refreshActiveEczaneTakasModalTab() {
            if (window.etModalActiveTab === 'create') {
                initEtModalCreateTab(true);
            } else if (window.etModalActiveTab === 'my_offers') {
                loadEczaneTakasMyOffers(true);
            } else {
                openEczaneTakasOffersModal(true, 'offers');
            }
        }

        async function switchEczaneTakasModalTab(tab) {
            ensureEczaneTakasModalDom();
            const t = (tab === 'create' || tab === 'my_offers') ? tab : 'offers';
            window.etModalActiveTab = t;

            const toolbar = document.getElementById('etModalOffersToolbar');
            const bodyOffers = document.getElementById('etModalBody');
            const bodyCreate = document.getElementById('etModalCreateBody');
            const bodyMy = document.getElementById('etModalMyOffersBody');
            const btnO = document.getElementById('etTabBtnOffers');
            const btnC = document.getElementById('etTabBtnCreate');
            const btnM = document.getElementById('etTabBtnMyOffers');
            const actCls = 'px-3.5 py-2 rounded-t-xl text-xs font-extrabold bg-white text-slate-900 border border-b-0 border-slate-200 flex items-center gap-1.5 cursor-pointer shadow-2xs';
            const pasCls = 'px-3.5 py-2 rounded-t-xl text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer';

            if (btnO) btnO.className = (t === 'offers') ? actCls : pasCls;
            if (btnC) btnC.className = (t === 'create') ? actCls : pasCls;
            if (btnM) btnM.className = (t === 'my_offers') ? actCls : pasCls;
            if (toolbar) toolbar.classList.toggle('hidden', t !== 'offers');
            if (bodyOffers) bodyOffers.classList.toggle('hidden', t !== 'offers');
            if (bodyCreate) bodyCreate.classList.toggle('hidden', t !== 'create');
            if (bodyMy) bodyMy.classList.toggle('hidden', t !== 'my_offers');

            if (t === 'create') {
                await initEtModalCreateTab(false);
            } else if (t === 'my_offers') {
                await loadEczaneTakasMyOffers(false);
            }
        }

        window.etMyOffersCache = [];
        window.etMyOffersFilter = 'ALL'; // ALL | AKTIF | PASIF

        async function loadEczaneTakasMyOffers(forceRefresh = false) {
            const box = document.getElementById('etModalMyOffersBody');
            if (!box) return;
            if (!forceRefresh && Array.isArray(window.etMyOffersCache) && window.etMyOffersCache.length > 0) {
                renderEczaneTakasMyOffers();
                return;
            }
            box.innerHTML = `<div class="p-10 text-center text-sky-700 font-bold text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl mb-2 block"></i>EczaneTakas'taki kendi teklifleriniz çekiliyor...</div>`;
            try {
                const res = await fetch('/api/eczanetakas/my-offers?max_pages=3');
                const data = await res.json();
                if (!data.success) {
                    box.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-xs">${data.message || 'Tekliflerim yüklenemedi.'}</div>`;
                    return;
                }
                window.etMyOffersCache = Array.isArray(data.offers) ? data.offers : [];
                window.etMyOffersMeta = data;
                const bdg = document.getElementById('etMyOffersCountBadge');
                if (bdg) {
                    bdg.innerText = String(data.aktif_count || window.etMyOffersCache.length);
                    bdg.classList.remove('hidden');
                }
                renderEczaneTakasMyOffers();
            } catch (e) {
                box.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-xs">Bağlantı hatası: ${e.message}</div>`;
            }
        }

        function setEtMyOffersFilter(mode) {
            window.etMyOffersFilter = mode || 'ALL';
            renderEczaneTakasMyOffers();
        }

        function renderEczaneTakasMyOffers() {
            const box = document.getElementById('etModalMyOffersBody');
            if (!box) return;
            const list = Array.isArray(window.etMyOffersCache) ? window.etMyOffersCache : [];
            const meta = window.etMyOffersMeta || {};
            const fMode = window.etMyOffersFilter || 'ALL';
            const qVal = (document.getElementById('etMyOffersSearchInput')?.value || '').trim().toLowerCase();

            const filtered = list.filter(o => {
                if (fMode === 'AKTIF' && !o.is_active) return false;
                if (fMode === 'PASIF' && o.is_active) return false;
                if (qVal && !(`${o.urun_adi || ''} ${o.teklif_no || ''}`).toLowerCase().includes(qVal)) return false;
                return true;
            });

            const summaryHtml = `
                <div class="bg-white rounded-2xl border border-slate-200 p-3 flex flex-wrap items-center justify-between gap-2.5 shadow-2xs">
                    <div class="flex flex-wrap items-center gap-2 text-xs">
                        <span class="px-2.5 py-1 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 font-extrabold">🟢 Aktif: ${meta.aktif_count || 0}</span>
                        <span class="px-2.5 py-1 rounded-xl bg-slate-100 text-slate-700 border border-slate-200 font-bold">⏸️ Pasif: ${meta.pasif_count || 0}</span>
                        <span class="px-2.5 py-1 rounded-xl bg-sky-50 text-sky-800 border border-sky-200 font-bold">📦 Rezerve: ${meta.total_rezerve || 0} • Tamamlanan: ${meta.total_tamamlanan || 0}</span>
                        ${meta.balance_str ? `<span class="px-2.5 py-1 rounded-xl bg-indigo-50 text-indigo-800 border border-indigo-200 font-black font-mono">Bakiye: ${meta.balance_str} ₺</span>` : ''}
                    </div>
                    <div class="flex flex-wrap items-center gap-1.5 text-[11px]">
                        <button type="button" onclick="setEtMyOffersFilter('ALL')" class="px-2.5 py-1 rounded-lg font-bold cursor-pointer ${fMode === 'ALL' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}">Tümü (${list.length})</button>
                        <button type="button" onclick="setEtMyOffersFilter('AKTIF')" class="px-2.5 py-1 rounded-lg font-bold cursor-pointer ${fMode === 'AKTIF' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'}">Aktif (${meta.aktif_count || 0})</button>
                        <button type="button" onclick="setEtMyOffersFilter('PASIF')" class="px-2.5 py-1 rounded-lg font-bold cursor-pointer ${fMode === 'PASIF' ? 'bg-slate-700 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}">Pasif (${meta.pasif_count || 0})</button>
                        <input type="search" id="etMyOffersSearchInput" value="${qVal.replace(/"/g, '&quot;')}" oninput="renderEczaneTakasMyOffers()" placeholder="Tekliflerimde ara..." class="px-2.5 py-1 rounded-lg border border-slate-300 text-xs bg-white w-40 focus:outline-none focus:border-sky-500" />
                    </div>
                </div>
            `;

            if (filtered.length === 0) {
                box.innerHTML = summaryHtml + `<div class="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-500 text-xs font-semibold">Bu filtrede EczaneTakas teklifiniz bulunmuyor.</div>`;
                return;
            }

            const rowsHtml = filtered.map(o => {
                const safeNm = String(o.urun_adi || '').replace(/'/g, "\\\\'");
                const stCls = o.is_active ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-slate-100 text-slate-600 border-slate-300';
                const toggleBtnCls = o.is_active
                    ? 'bg-amber-50 hover:bg-amber-500 text-amber-800 hover:text-white border-amber-300'
                    : 'bg-emerald-50 hover:bg-emerald-600 text-emerald-800 hover:text-white border-emerald-300';
                const toggleLbl = o.is_active ? '⏸️ Pasife Çek' : '▶️ Aktif Et';
                return `
                    <tr class="hover:bg-slate-50/90 transition text-xs">
                        <td class="py-2.5 px-3 font-mono font-bold text-slate-500">#${o.teklif_no}</td>
                        <td class="py-2.5 px-3">
                            <div class="font-extrabold text-slate-900">${o.urun_adi}</div>
                            <div class="text-[10px] text-slate-400">Eklendi: ${o.eklenme_tarihi || '-'} • Miad: <strong class="text-slate-600">${o.miad_tr || '-'}</strong> ${o.miad_kalan_gun !== null ? '(' + o.miad_kalan_gun + ' Gün)' : ''}</div>
                        </td>
                        <td class="py-2.5 px-2 text-center">
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-black border ${stCls}">${o.durum}</span>
                        </td>
                        <td class="py-2.5 px-2 text-center font-mono">
                            <div class="font-black text-slate-900">Kalan: <span class="text-sky-700">${o.kalan}</span> / ${o.acilan}</div>
                            <div class="text-[10px] text-slate-500">Rez: <strong>${o.rezerve}</strong> • Gönd: <strong>${o.gonderilen}</strong> • Tam: <strong class="text-emerald-700">${o.tamamlanan}</strong></div>
                        </td>
                        <td class="py-2.5 px-3 text-right font-mono">
                            <div class="font-black text-emerald-700">${Number(o.satis_fiyat || 0).toFixed(2)} ₺ <span class="text-[10px] font-bold text-slate-500">(${o.mf || '1+0'})</span></div>
                            <div class="text-[10px] text-slate-400">Depo: ${Number(o.depo_fiyat || 0).toFixed(2)} ₺</div>
                        </td>
                        <td class="py-2.5 px-3 text-right">
                            <div class="inline-flex items-center gap-1.5">
                                <button type="button" onclick="toggleEczaneTakasMyOfferStatus('${o.teklif_no}', this)" class="px-2.5 py-1 rounded-lg border text-[10.5px] font-extrabold transition cursor-pointer ${toggleBtnCls}">${toggleLbl}</button>
                                <button type="button" onclick="deleteEczaneTakasMyOffer('${o.teklif_no}', '${safeNm}', this)" class="px-2 py-1 rounded-lg bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 text-[10.5px] font-extrabold transition cursor-pointer" title="Teklifi EczaneTakas'tan sil">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');

            box.innerHTML = summaryHtml + `
                <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-slate-50 border-b border-slate-200 text-[10px] font-extrabold text-slate-500 uppercase">
                                <th class="py-2 px-3 w-16">No</th>
                                <th class="py-2 px-3">Ürün &amp; Miad</th>
                                <th class="py-2 px-2 text-center w-24">Durum</th>
                                <th class="py-2 px-2 text-center w-44">Kalan / Katılım</th>
                                <th class="py-2 px-3 text-right w-36">Satış Fiyatı</th>
                                <th class="py-2 px-3 text-right w-40">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">${rowsHtml}</tbody>
                    </table>
                </div>
            `;
        }

        async function toggleEczaneTakasMyOfferStatus(teklifNo, btnEl) {
            const orig = btnEl ? btnEl.innerHTML : '';
            if (btnEl) { btnEl.disabled = true; btnEl.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>'; }
            try {
                const res = await fetch('/api/eczanetakas/offer-status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ teklif_no: teklifNo })
                });
                const data = await res.json();
                if (data.success) {
                    if (typeof showToast === 'function') showToast('Durum Güncellendi', data.message || `#${teklifNo} güncellendi.`, 'success');
                    await loadEczaneTakasMyOffers(true);
                } else {
                    if (btnEl) { btnEl.disabled = false; btnEl.innerHTML = orig; }
                    if (typeof showToast === 'function') showToast('İşlem Başarısız', data.message || 'Durum değiştirilemedi.', 'error');
                }
            } catch (e) {
                if (btnEl) { btnEl.disabled = false; btnEl.innerHTML = orig; }
                if (typeof showToast === 'function') showToast('Bağlantı Hatası', e.message, 'error');
            }
        }

        async function deleteEczaneTakasMyOffer(teklifNo, urunAdi, btnEl) {
            if (!window.confirm(`#${teklifNo} (${urunAdi}) EczaneTakas teklifinizi KALICI OLARAK silmek istediğinize emin misiniz?`)) return;
            const orig = btnEl ? btnEl.innerHTML : '';
            if (btnEl) { btnEl.disabled = true; btnEl.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>'; }
            try {
                const res = await fetch('/api/eczanetakas/offer-delete', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ teklif_no: teklifNo })
                });
                const data = await res.json();
                if (data.success) {
                    if (typeof showToast === 'function') showToast('Teklif Silindi', data.message || `#${teklifNo} silindi.`, 'info');
                    await loadEczaneTakasMyOffers(true);
                } else {
                    if (btnEl) { btnEl.disabled = false; btnEl.innerHTML = orig; }
                    if (typeof showToast === 'function') showToast('Silinemedi', data.message || 'Teklif silinemedi.', 'error');
                }
            } catch (e) {
                if (btnEl) { btnEl.disabled = false; btnEl.innerHTML = orig; }
                if (typeof showToast === 'function') showToast('Bağlantı Hatası', e.message, 'error');
            }
        }

        async function openEczaneTakasOffersModal(forceRefresh = false, initialTab = 'offers') {
            ensureEczaneTakasModalDom();
            const modal = document.getElementById('eczanetakasOffersModal');
            const body = document.getElementById('etModalBody');
            if (modal) modal.classList.remove('hidden');

            const targetTab = initialTab || 'offers';
            await switchEczaneTakasModalTab(targetTab);
            if (targetTab !== 'offers') return;

            const hasCache = Array.isArray(window.etActiveOffersCache) && window.etActiveOffersCache.length > 0;
            if (hasCache && !forceRefresh) {
                renderEczaneTakasOffersModal();
            } else if (body) {
                body.innerHTML = `<div class="p-10 text-center text-sky-700 font-bold text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl mb-2 block"></i>EczaneTakas aktif teklifleri ve eczane stok / 1A-3A çıkış verileri çekiliyor...</div>`;
            }
            try {
                if (typeof syncTodayOrdersAcrossPCs === 'function') {
                    await syncTodayOrdersAcrossPCs();
                }
                const res = await fetch('/api/eczanetakas/offers' + (forceRefresh ? '?refresh=true' : ''));
                const data = await res.json();
                if (data.success) {
                    window.etActiveOffersCache = data.offers || [];
                    window.etActiveOtomasyonName = data.otomasyon || '';
                    const topBadge = document.getElementById('etTopOffersCountBadge');
                    if (topBadge) topBadge.innerText = `${window.etActiveOffersCache.length} Teklif`;
                    const otoBadge = document.getElementById('etModalOtoBadge');
                    if (otoBadge && data.otomasyon) {
                        otoBadge.innerText = `🏥 ${data.otomasyon} Stok & 1A/3A Çıkış Aktif`;
                    }
                    if (window.etModalActiveTab === 'offers') renderEczaneTakasOffersModal();
                } else if (!hasCache && body) {
                    body.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-sm">${data.message || 'Teklifler alınamadı.'}</div>`;
                }
            } catch (e) {
                if (!hasCache && body) {
                    body.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-sm">Bağlantı hatası: ${e.message}</div>`;
                }
            }
        }

        function closeEczaneTakasOffersModal() {
            const modal = document.getElementById('eczanetakasOffersModal');
            if (modal) modal.classList.add('hidden');
        }

        // -------- SEKME 2: UYGULAMA İÇİ ECZANETAKAS TEKLİF AÇMA --------
        window.openEtModalCreateForProduct = async function(barcode, name, opts = {}) {
            ensureEczaneTakasModalDom();
            const modal = document.getElementById('eczanetakasOffersModal');
            if (modal) modal.classList.remove('hidden');

            const st = window.etModalCreateState;
            st.urunId = 0;
            st.urunAdi = String(name || '').trim();
            st.barcode = String(barcode || '').trim();
            st.portalPrice = 0;
            st.unitCost = Math.max(0, parseFloat(opts.unitCost || 0) || 0);
            st.psf = Math.max(0, parseFloat(opts.psf || 0) || 0);
            st.recPrice = Math.max(0, parseFloat(opts.recPrice || 0) || 0);

            await switchEczaneTakasModalTab('create');

            const fb = document.getElementById('etMdlCreateFeedback');
            if (fb) { fb.classList.add('hidden'); fb.innerHTML = ''; }

            const sellQty = Math.max(1, parseInt(opts.sellQty || 10, 10) || 10);
            const adetEl = document.getElementById('etMdlAdet');
            const minEl = document.getElementById('etMdlMin');
            const s1El = document.getElementById('etMdlSart1');
            const s2El = document.getElementById('etMdlSart2');
            const komEl = document.getElementById('etMdlKomisyon');
            const tgtNetEl = document.getElementById('etMdlTargetNet');
            const infoEl = document.getElementById('etMdlAciklama');
            const searchEl = document.getElementById('etMdlProdSearch');

            if (adetEl) adetEl.value = String(sellQty);
            if (minEl) minEl.value = '1';
            if (s1El) s1El.value = '1';
            if (s2El) s2El.value = '0';
            if (komEl) komEl.value = '0';
            if (tgtNetEl) tgtNetEl.value = '';
            if (infoEl) infoEl.value = opts.info !== undefined ? String(opts.info) : 'Raf fazlası takas';
            const miadEl = document.getElementById('etMdlMiad');
            if (miadEl && opts.miad && /^\\d{4}-\\d{2}-\\d{2}$/.test(String(opts.miad))) {
                miadEl.value = String(opts.miad);
            }

            const qVal = String(name || barcode || '').trim();
            if (searchEl) searchEl.value = qVal;

            _renderEtModalRefPills();
            await searchEtModalCatalog(qVal, barcode, name);

            // Eğer Atıl Stoktan önerilen takas fiyatı geldiyse ve baz fiyatın altındaysa hedef net kutusunu doldur
            const bazVal = parseFloat((document.getElementById('etMdlBazFiyat') || {}).value) || 0;
            if (st.recPrice > 0 && bazVal > 0 && st.recPrice < bazVal && tgtNetEl) {
                tgtNetEl.value = st.recPrice.toFixed(2);
                applyEtModalTargetNet(st.recPrice.toFixed(2));
            } else {
                recalcEtModalNet();
            }
        };

        async function initEtModalCreateTab(forceReload = false) {
            const box = document.getElementById('etModalCreateBody');
            if (!box) return;
            const st = window.etModalCreateState;
            const defMiad = (typeof _formatIsoDatePlusMonths === 'function') ? _formatIsoDatePlusMonths(12) : '';
            const defEnd = (typeof _formatIsoDatePlusDays === 'function') ? _formatIsoDatePlusDays(15) : '';

            if (!box.dataset.rendered || forceReload) {
                box.innerHTML = `
                    <!-- Ürün Arama & Seçim -->
                    <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <span class="text-xs font-black text-sky-900 flex items-center gap-1.5">
                                <i class="fa-solid fa-pills text-sky-600"></i>
                                <span>1. EczaneTakas Kataloğundan Ürün Seçimi</span>
                            </span>
                            <span id="etMdlMatchBadge" class="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-600 border border-slate-200">Hazır</span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
                            <div class="md:col-span-5">
                                <label class="text-[11px] font-extrabold text-slate-700 block mb-1">Ürün Adı veya Barkod Ara (En az 2 harf)</label>
                                <div class="flex gap-1.5">
                                    <input type="text" id="etMdlProdSearch" autocomplete="off" oninput="debouncedEtModalCatalogSearch(this.value)" onkeydown="if(event.key==='Enter') searchEtModalCatalog(this.value)" placeholder="İlaç adı veya barkod yazın..." class="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-sky-500" />
                                    <button type="button" onclick="searchEtModalCatalog(document.getElementById('etMdlProdSearch').value)" class="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-extrabold cursor-pointer">Ara</button>
                                </div>
                            </div>
                            <div class="md:col-span-7">
                                <label class="text-[11px] font-extrabold text-slate-700 block mb-1">Eşleşen EczaneTakas Ürünü <span class="text-rose-500">*</span></label>
                                <select id="etMdlProdSelect" onchange="onEtModalProdSelectChange()" class="w-full bg-white border border-sky-300 text-slate-900 font-bold text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-sky-600">
                                    <option value="0">-- Soldan ürün adı aratarak seçin --</option>
                                </select>
                            </div>
                        </div>
                        <div id="etMdlRefPills" class="flex flex-wrap items-center gap-1.5 text-[10.5px]"></div>
                    </div>

                    <!-- Adet, Barem, İskonto ve Net Fiyat -->
                    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                        <div class="bg-white p-3 rounded-2xl border border-slate-200">
                            <div class="flex items-center justify-between">
                                <label class="text-[10px] font-extrabold text-slate-500 uppercase">Satılacak Adet *</label>
                                <div class="flex gap-1">
                                    <button type="button" onclick="setEtModalQuickAdet(5)" class="px-1 py-0.2 rounded bg-slate-100 hover:bg-sky-100 text-[9px] font-bold text-slate-600 cursor-pointer">5</button>
                                    <button type="button" onclick="setEtModalQuickAdet(10)" class="px-1 py-0.2 rounded bg-slate-100 hover:bg-sky-100 text-[9px] font-bold text-slate-600 cursor-pointer">10</button>
                                    <button type="button" onclick="setEtModalQuickAdet(20)" class="px-1 py-0.2 rounded bg-slate-100 hover:bg-sky-100 text-[9px] font-bold text-slate-600 cursor-pointer">20</button>
                                </div>
                            </div>
                            <input type="number" id="etMdlAdet" value="10" min="1" oninput="syncEtModalMinMax(); recalcEtModalNet();" class="mt-1 w-full bg-slate-50 border border-slate-300 font-black text-sm rounded-xl px-2 py-1.5 text-center" />
                        </div>
                        <div class="bg-white p-3 rounded-2xl border border-slate-200">
                            <div class="flex items-center justify-between">
                                <label class="text-[10px] font-extrabold text-slate-500 uppercase">Min. Alım *</label>
                                <button type="button" onclick="document.getElementById('etMdlMin').value=document.getElementById('etMdlAdet').value" class="px-1.5 py-0.2 rounded bg-slate-100 hover:bg-sky-100 text-[9px] font-bold text-slate-600 cursor-pointer" title="Tümünü tek seferde sat">Tümü</button>
                            </div>
                            <input type="number" id="etMdlMin" value="1" min="1" oninput="syncEtModalMinMax();" class="mt-1 w-full bg-slate-50 border border-slate-300 font-black text-sm rounded-xl px-2 py-1.5 text-center" />
                        </div>
                        <div class="bg-white p-3 rounded-2xl border border-slate-200">
                            <label class="text-[10px] font-extrabold text-slate-500 uppercase block">Alım Şartı (MF)</label>
                            <div class="mt-1 flex items-center gap-1">
                                <input type="number" id="etMdlSart1" value="1" min="1" oninput="recalcEtModalNet()" class="w-full bg-slate-50 border border-slate-300 font-black text-sm rounded-xl px-1 py-1.5 text-center" title="Alınan" />
                                <span class="font-black text-sky-600">+</span>
                                <input type="number" id="etMdlSart2" value="0" min="0" oninput="recalcEtModalNet()" class="w-full bg-amber-50 border border-amber-300 text-amber-950 font-black text-sm rounded-xl px-1 py-1.5 text-center" title="Mal Fazlası" />
                            </div>
                        </div>
                        <div class="bg-white p-3 rounded-2xl border border-slate-200">
                            <label class="text-[10px] font-extrabold text-slate-500 uppercase block">Baz Depo Fiyatı *</label>
                            <input type="number" id="etMdlBazFiyat" value="0.00" step="0.01" oninput="recalcEtModalNet()" class="mt-1 w-full bg-slate-50 border border-slate-300 font-mono font-black text-sm rounded-xl px-2 py-1.5 text-center" />
                        </div>
                        <div class="bg-white p-3 rounded-2xl border border-slate-200">
                            <label class="text-[10px] font-extrabold text-slate-500 uppercase block">Ek İskonto / Kom (%)</label>
                            <input type="number" id="etMdlKomisyon" value="0" min="0" max="99" step="0.1" oninput="recalcEtModalNet()" class="mt-1 w-full bg-slate-50 border border-slate-300 font-mono font-black text-sm rounded-xl px-2 py-1.5 text-center" />
                        </div>
                        <div class="bg-amber-50/80 p-3 rounded-2xl border border-amber-300">
                            <label class="text-[10px] font-extrabold text-amber-900 uppercase block">⚡ Hedef Net Satış (₺)</label>
                            <input type="number" id="etMdlTargetNet" placeholder="Örn: 185" step="0.01" oninput="applyEtModalTargetNet(this.value)" class="mt-1 w-full bg-white border border-amber-400 font-mono font-black text-sm rounded-xl px-2 py-1.5 text-center" />
                        </div>
                    </div>

                    <!-- Hızlı Barem / İskonto & Net Fiyat Özet Barı -->
                    <div class="bg-white p-4 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-3">
                        <div class="flex flex-wrap items-center gap-1.5">
                            <span class="text-[10.5px] font-extrabold text-slate-500 mr-1">Hızlı Barem / İskonto:</span>
                            <button type="button" onclick="applyEtModalPreset(1, 0, 0)" class="px-2 py-1 rounded-lg bg-slate-100 hover:bg-sky-600 hover:text-white text-slate-700 text-[11px] font-bold cursor-pointer">1+0 (%0)</button>
                            <button type="button" onclick="applyEtModalPreset(1, 0, 5)" class="px-2 py-1 rounded-lg bg-sky-50 hover:bg-sky-600 hover:text-white text-sky-900 border border-sky-200 text-[11px] font-bold cursor-pointer">1+0 (-%5)</button>
                            <button type="button" onclick="applyEtModalPreset(1, 0, 10)" class="px-2 py-1 rounded-lg bg-sky-50 hover:bg-sky-600 hover:text-white text-sky-900 border border-sky-200 text-[11px] font-bold cursor-pointer">1+0 (-%10)</button>
                            <button type="button" onclick="applyEtModalPreset(1, 0, 15)" class="px-2 py-1 rounded-lg bg-sky-50 hover:bg-sky-600 hover:text-white text-sky-900 border border-sky-200 text-[11px] font-bold cursor-pointer">1+0 (-%15)</button>
                            <button type="button" onclick="applyEtModalPreset(5, 1, 0)" class="px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-900 border border-emerald-200 text-[11px] font-bold cursor-pointer">5+1</button>
                            <button type="button" onclick="applyEtModalPreset(10, 1, 0)" class="px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-900 border border-emerald-200 text-[11px] font-bold cursor-pointer">10+1</button>
                            <button type="button" onclick="applyEtModalPreset(10, 2, 0)" class="px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-900 border border-emerald-200 text-[11px] font-bold cursor-pointer">10+2</button>
                            <button type="button" onclick="applyEtModalPreset(20, 5, 0)" class="px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-900 border border-emerald-200 text-[11px] font-bold cursor-pointer">20+5</button>
                        </div>
                        <div class="flex items-center gap-3 bg-emerald-50 border border-emerald-300 rounded-xl px-4 py-2">
                            <div>
                                <div class="text-[10px] font-extrabold text-emerald-800 uppercase">Net Satış (KDV Dahil)</div>
                                <div id="etMdlNetKdvli" class="text-lg font-black font-mono text-emerald-700 leading-tight">0.00 ₺</div>
                            </div>
                            <div class="border-l border-emerald-200 pl-3 text-[10.5px] font-mono text-slate-600">
                                <div id="etMdlNetKdvsiz">KDV H: 0.00 ₺</div>
                                <div id="etMdlMarginInfo" class="font-sans font-bold text-slate-500"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Miad, Hedef Eczaneler, Bitiş & Açıklama -->
                    <div class="bg-white p-4 rounded-2xl border border-slate-200 space-y-3">
                        <div class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                            <div class="sm:col-span-3">
                                <div class="flex items-center justify-between mb-1">
                                    <label class="text-[11px] font-extrabold text-slate-700">Miad Tarihi <span class="text-rose-500">*</span></label>
                                    <div class="flex gap-1">
                                        <button type="button" onclick="setEtModalMiadMonths(6)" class="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-sky-100 text-[9.5px] font-bold text-slate-600 cursor-pointer">+6A</button>
                                        <button type="button" onclick="setEtModalMiadMonths(12)" class="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-sky-100 text-[9.5px] font-bold text-slate-600 cursor-pointer">+12A</button>
                                        <button type="button" onclick="setEtModalMiadMonths(24)" class="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-sky-100 text-[9.5px] font-bold text-slate-600 cursor-pointer">+24A</button>
                                    </div>
                                </div>
                                <input type="date" id="etMdlMiad" value="${defMiad}" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold" />
                            </div>
                            <div class="sm:col-span-3">
                                <label class="text-[11px] font-extrabold text-slate-700 block mb-1">Hedef Kitle</label>
                                <select id="etMdlHedef" onchange="onEtModalHedefChange()" class="w-full bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl px-3 py-2">
                                    <option value="0">🌐 Tüm Grup Eczaneleri</option>
                                    <option value="1">🎯 Seçili Özel Eczaneler</option>
                                </select>
                            </div>
                            <div class="sm:col-span-3">
                                <label class="flex items-center gap-1.5 text-[11px] font-extrabold text-slate-700 mb-1 cursor-pointer">
                                    <input type="checkbox" id="etMdlEndSwitch" onchange="onEtModalEndSwitchChange()" class="rounded text-sky-600" />
                                    <span>Teklif Bitiş Tarihi Belirle</span>
                                </label>
                                <input type="date" id="etMdlEndDate" value="${defEnd}" disabled class="w-full bg-slate-100 border border-slate-200 text-slate-500 rounded-xl px-3 py-2 text-xs font-bold disabled:opacity-60" />
                            </div>
                            <div class="sm:col-span-3 flex gap-2">
                                <button type="button" id="etMdlSubmitBtn" onclick="submitEtModalCreate()" class="w-full px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-emerald-600 hover:from-sky-700 hover:to-emerald-700 text-white text-xs font-black shadow-sm cursor-pointer flex items-center justify-center gap-1.5">
                                    <i class="fa-solid fa-paper-plane"></i>
                                    <span>Teklifi Yayınla</span>
                                </button>
                            </div>
                        </div>

                        <div id="etMdlPharmaciesBox" class="hidden pt-2 border-t border-slate-100 space-y-2">
                            <div class="flex flex-wrap items-center justify-between gap-2">
                                <span class="text-[11px] font-extrabold text-sky-900">Hedef Eczaneleri Seçin:</span>
                                <div class="flex items-center gap-2">
                                    <input type="text" id="etMdlPharmSearch" oninput="filterEtModalPharmacies(this.value)" placeholder="Eczane ara..." class="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1 text-[11px]" />
                                    <button type="button" onclick="toggleAllEtModalPharmacies()" class="px-2 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-[10.5px] font-bold cursor-pointer">Tümünü Seç / Kaldır</button>
                                </div>
                            </div>
                            <div id="etMdlPharmaciesList" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-1.5 max-h-36 overflow-y-auto p-1"></div>
                        </div>

                        <div>
                            <label class="text-[11px] font-extrabold text-slate-700 block mb-1">Açıklama / Not (İsteğe bağlı)</label>
                            <input type="text" id="etMdlAciklama" maxlength="140" placeholder="Örn: Raf fazlası, orijinal ambalaj, uzun miadlı..." class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs" />
                        </div>
                    </div>

                    <div id="etMdlCreateFeedback" class="hidden rounded-2xl px-4 py-3 text-xs font-bold border"></div>
                `;
                box.dataset.rendered = '1';
            }

            // Grup eczanelerini & katalog bilgisini yükle
            if (!st.pharmacies.length || forceReload) {
                try {
                    const r = await fetch('/api/eczanetakas/campaign/prepare');
                    const j = await r.json();
                    if (j && j.success) {
                        st.pharmacies = j.pharmacies || [];
                        st.catalogCount = j.total_catalog_count || 0;
                        const catBdg = document.getElementById('etModalCatalogBadge');
                        if (catBdg && st.catalogCount) {
                            catBdg.innerHTML = `<i class="fa-solid fa-database text-sky-600 mr-1"></i>EczaneTakas Kataloğu: <strong class="text-sky-900">${st.catalogCount} ürün</strong>`;
                        }
                        renderEtModalPharmaciesList('');
                    } else if (j && j.message) {
                        const fb = document.getElementById('etMdlCreateFeedback');
                        if (fb) {
                            fb.className = 'rounded-2xl px-4 py-3 text-xs font-bold border bg-rose-50 border-rose-300 text-rose-800';
                            fb.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${j.message}`;
                            fb.classList.remove('hidden');
                        }
                    }
                } catch (e) {}
            } else {
                renderEtModalPharmaciesList('');
            }
            _renderEtModalRefPills();
            recalcEtModalNet();
        }

        function renderEtModalPharmaciesList(filterQ = '') {
            const box = document.getElementById('etMdlPharmaciesList');
            if (!box) return;
            const q = String(filterQ || '').trim().toLowerCase();
            const list = (window.etModalCreateState.pharmacies || []).filter(p => !q || (p.name || '').toLowerCase().includes(q));
            box.innerHTML = list.map(ph => `
                <label class="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-50 hover:bg-sky-50 border border-slate-200 cursor-pointer text-[11px] truncate">
                    <input type="checkbox" value="${ph.id}" class="et-mdl-pharm-chk rounded text-sky-600" />
                    <span class="truncate font-semibold text-slate-700" title="${ph.name}">${ph.name}</span>
                </label>
            `).join('') || '<span class="text-xs text-slate-400">Eczane bulunamadı</span>';
        }

        function filterEtModalPharmacies(q) { renderEtModalPharmaciesList(q); }

        function toggleAllEtModalPharmacies() {
            const chks = document.querySelectorAll('.et-mdl-pharm-chk');
            const anyOff = Array.from(chks).some(c => !c.checked);
            chks.forEach(c => { c.checked = anyOff; });
        }

        function onEtModalHedefChange() {
            const sel = document.getElementById('etMdlHedef');
            const box = document.getElementById('etMdlPharmaciesBox');
            if (sel && box) box.classList.toggle('hidden', sel.value !== '1');
        }

        function onEtModalEndSwitchChange() {
            const chk = document.getElementById('etMdlEndSwitch');
            const dt = document.getElementById('etMdlEndDate');
            if (!chk || !dt) return;
            dt.disabled = !chk.checked;
            if (chk.checked && !dt.value && typeof _formatIsoDatePlusDays === 'function') {
                dt.value = _formatIsoDatePlusDays(15);
            }
        }

        function setEtModalQuickAdet(v) {
            const el = document.getElementById('etMdlAdet');
            if (el) el.value = String(Math.max(1, parseInt(v, 10) || 1));
            syncEtModalMinMax();
            recalcEtModalNet();
        }

        function syncEtModalMinMax() {
            const aEl = document.getElementById('etMdlAdet');
            const mEl = document.getElementById('etMdlMin');
            if (!aEl || !mEl) return;
            const a = Math.max(1, parseInt(aEl.value, 10) || 1);
            const m = Math.max(1, parseInt(mEl.value, 10) || 1);
            if (m > a) mEl.value = String(a);
        }

        function setEtModalMiadMonths(m) {
            const el = document.getElementById('etMdlMiad');
            if (el && typeof _formatIsoDatePlusMonths === 'function') el.value = _formatIsoDatePlusMonths(m);
        }

        function applyEtModalPreset(a, h, kom = 0) {
            const s1 = document.getElementById('etMdlSart1');
            const s2 = document.getElementById('etMdlSart2');
            const k = document.getElementById('etMdlKomisyon');
            const tn = document.getElementById('etMdlTargetNet');
            if (s1) s1.value = String(Math.max(1, a));
            if (s2) s2.value = String(Math.max(0, h));
            if (k) k.value = String(Math.max(0, kom));
            if (tn) tn.value = '';
            recalcEtModalNet();
        }

        function applyEtModalTargetNet(rawVal) {
            const targetNet = parseFloat(rawVal) || 0;
            const baz = parseFloat((document.getElementById('etMdlBazFiyat') || {}).value) || 0;
            if (targetNet <= 0 || baz <= 0) return;
            const s1 = Math.max(1, parseInt((document.getElementById('etMdlSart1') || {}).value, 10) || 1);
            const s2 = Math.max(0, parseInt((document.getElementById('etMdlSart2') || {}).value, 10) || 0);
            const afterMf = (baz * s1) / (s1 + s2);
            if (targetNet >= afterMf) {
                // Hedef fiyat baz fiyattan yüksekse doğrudan baz fiyatı hedef fiyata çek ve komisyonu 0 yap
                const komEl = document.getElementById('etMdlKomisyon');
                if (komEl) komEl.value = '0';
                recalcEtModalNet();
                return;
            }
            const kom = Number((((afterMf - targetNet) / afterMf) * 100.0).toFixed(2));
            const komEl = document.getElementById('etMdlKomisyon');
            if (komEl) komEl.value = String(Math.max(0, Math.min(99, kom)));
            recalcEtModalNet();
        }

        function _renderEtModalRefPills() {
            const box = document.getElementById('etMdlRefPills');
            if (!box) return;
            const st = window.etModalCreateState;
            const pills = [];
            if (st.portalPrice > 0) {
                pills.push(`<button type="button" onclick="document.getElementById('etMdlBazFiyat').value='${st.portalPrice.toFixed(2)}'; recalcEtModalNet();" class="px-2 py-0.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-200 font-bold cursor-pointer">Portal Baz Fiyat: ${st.portalPrice.toFixed(2)} ₺</button>`);
            }
            if (st.unitCost > 0) {
                pills.push(`<button type="button" onclick="document.getElementById('etMdlTargetNet').value='${st.unitCost.toFixed(2)}'; applyEtModalTargetNet('${st.unitCost.toFixed(2)}');" class="px-2 py-0.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 font-bold cursor-pointer" title="Son birim alış maliyetinizi hedef net satış olarak uygula">Son Alışım: ${st.unitCost.toFixed(2)} ₺</button>`);
            }
            if (st.recPrice > 0) {
                pills.push(`<button type="button" onclick="document.getElementById('etMdlTargetNet').value='${st.recPrice.toFixed(2)}'; applyEtModalTargetNet('${st.recPrice.toFixed(2)}');" class="px-2 py-0.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold cursor-pointer" title="Önerilen takas fiyatını hedef net satış olarak uygula">Önerilen Takas: ${st.recPrice.toFixed(2)} ₺</button>`);
            }
            if (st.psf > 0) {
                pills.push(`<span class="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-600 border border-slate-200 font-semibold">PSF: ${st.psf.toFixed(2)} ₺</span>`);
            }
            box.innerHTML = pills.length
                ? `<span class="text-slate-400 font-bold">Referanslar:</span> ` + pills.join('')
                : '';
        }

        function recalcEtModalNet() {
            const st = window.etModalCreateState;
            const s1 = Math.max(1, parseInt((document.getElementById('etMdlSart1') || {}).value, 10) || 1);
            const s2 = Math.max(0, parseInt((document.getElementById('etMdlSart2') || {}).value, 10) || 0);
            const kom = Math.max(0, Math.min(99, parseFloat((document.getElementById('etMdlKomisyon') || {}).value) || 0));
            const baz = Math.max(0, parseFloat((document.getElementById('etMdlBazFiyat') || {}).value) || 0);
            const netKdvli = baz > 0 ? (((baz * s1) / (s1 + s2)) * (1.0 - (kom / 100.0))) : 0;
            const kdvMult = 1.0 + ((st.kdvOrani || 10) / 100.0);
            const netKdvsiz = kdvMult > 0 ? (netKdvli / kdvMult) : netKdvli;
            const nEl = document.getElementById('etMdlNetKdvli');
            const hEl = document.getElementById('etMdlNetKdvsiz');
            const mEl = document.getElementById('etMdlMarginInfo');
            if (nEl) nEl.innerText = `${netKdvli.toFixed(2)} ₺`;
            if (hEl) hEl.innerText = `KDV H: ${netKdvsiz.toFixed(2)} ₺`;
            if (mEl) {
                if (st.unitCost > 0 && netKdvli > 0) {
                    const diff = netKdvli - st.unitCost;
                    mEl.className = diff >= 0 ? 'font-sans font-extrabold text-emerald-700' : 'font-sans font-extrabold text-rose-700';
                    mEl.innerText = diff >= 0 ? `Alışa göre +${diff.toFixed(2)} ₺/kt` : `Alışa göre ${diff.toFixed(2)} ₺/kt`;
                } else {
                    mEl.innerText = s2 > 0 ? `${s1}+${s2} Barem` : (kom > 0 ? `-%${kom.toFixed(1)} İsk.` : '1+0 Net');
                    mEl.className = 'font-sans font-bold text-slate-500';
                }
            }
        }

        function debouncedEtModalCatalogSearch(val) {
            if (_etMdlSearchTimer) clearTimeout(_etMdlSearchTimer);
            if (String(val || '').trim().length < 2) return;
            _etMdlSearchTimer = setTimeout(() => searchEtModalCatalog(val), 260);
        }

        async function searchEtModalCatalog(q, bcHint = '', nameHint = '') {
            const clean = String(q || '').trim();
            if (clean.length < 2 && !bcHint) return;
            const sel = document.getElementById('etMdlProdSelect');
            const bdg = document.getElementById('etMdlMatchBadge');
            if (sel) sel.innerHTML = '<option value="0">EczaneTakas kataloğu taranıyor...</option>';
            if (bdg) {
                bdg.className = 'px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200';
                bdg.innerText = 'Aranıyor...';
            }
            try {
                const url = bcHint
                    ? `/api/eczanetakas/campaign/prepare?barcode=${encodeURIComponent(bcHint)}&name=${encodeURIComponent(nameHint || clean)}`
                    : `/api/eczanetakas/campaign/prepare?q=${encodeURIComponent(clean)}`;
                const r = await fetch(url);
                const j = await r.json();
                const st = window.etModalCreateState;
                if (!j.success) {
                    if (sel) sel.innerHTML = `<option value="0">${j.message || 'Bağlantı hatası'}</option>`;
                    if (bdg) { bdg.className = 'px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800'; bdg.innerText = 'Oturum Hatası'; }
                    return;
                }
                if (Array.isArray(j.pharmacies) && j.pharmacies.length) {
                    st.pharmacies = j.pharmacies;
                    renderEtModalPharmaciesList('');
                }
                const cands = Array.isArray(j.candidates) ? j.candidates : [];
                st.candidates = cands;
                if (!cands.length) {
                    if (sel) sel.innerHTML = `<option value="0">"${clean}" için EczaneTakas'ta ürün bulunamadı (farklı kelime deneyin)</option>`;
                    if (bdg) { bdg.className = 'px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900'; bdg.innerText = 'Eşleşme Yok'; }
                    return;
                }
                const pickId = (j.matched && j.urun_id > 0) ? j.urun_id : cands[0].id;
                if (sel) {
                    sel.innerHTML = cands.map(c =>
                        `<option value="${c.id}" ${c.id === pickId ? 'selected' : ''}>${c.name}</option>`
                    ).join('');
                }
                if (j.portal_price > 0) {
                    st.portalPrice = Number(j.portal_price);
                    const bazEl = document.getElementById('etMdlBazFiyat');
                    if (bazEl) bazEl.value = st.portalPrice.toFixed(2);
                }
                await onEtModalProdSelectChange(j.portal_price > 0);
            } catch (e) {
                if (sel) sel.innerHTML = `<option value="0">Arama hatası: ${e.message}</option>`;
            }
        }

        async function onEtModalProdSelectChange(skipPriceFetch = false) {
            const sel = document.getElementById('etMdlProdSelect');
            const bdg = document.getElementById('etMdlMatchBadge');
            if (!sel) return;
            const uid = parseInt(sel.value, 10) || 0;
            const txt = (sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : '').trim();
            const st = window.etModalCreateState;
            st.urunId = uid;
            st.urunAdi = uid > 0 ? txt : '';
            if (uid > 0) {
                if (bdg) {
                    bdg.className = 'px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300';
                    bdg.innerText = '✓ Ürün Eşleşti';
                }
                if (!skipPriceFetch) {
                    try {
                        const r = await fetch(`/api/eczanetakas/campaign/product-price?urun_id=${uid}`);
                        if (r.ok) {
                            const j = await r.json();
                            if (j && j.portal_price > 0) {
                                st.portalPrice = Number(j.portal_price);
                                const bazEl = document.getElementById('etMdlBazFiyat');
                                if (bazEl) bazEl.value = st.portalPrice.toFixed(2);
                            }
                        }
                    } catch (e) {}
                }
                const bazEl = document.getElementById('etMdlBazFiyat');
                if (bazEl && (parseFloat(bazEl.value) || 0) <= 0 && st.psf > 0) {
                    bazEl.value = (st.psf / 1.25).toFixed(2);
                }
            } else if (bdg) {
                bdg.className = 'px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800';
                bdg.innerText = 'Ürün Seçiniz';
            }
            _renderEtModalRefPills();
            recalcEtModalNet();
        }

        async function submitEtModalCreate() {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('EczaneTakas Teklif Açma')) return;
            const fb = document.getElementById('etMdlCreateFeedback');
            const showFb = (msg, ok) => {
                if (!fb) return;
                fb.classList.remove('hidden');
                fb.className = ok
                    ? 'rounded-2xl px-4 py-3 text-xs font-bold border bg-emerald-50 border-emerald-300 text-emerald-900 flex flex-wrap items-center justify-between gap-2'
                    : 'rounded-2xl px-4 py-3 text-xs font-bold border bg-rose-50 border-rose-300 text-rose-800';
                fb.innerHTML = msg;
            };

            const sel = document.getElementById('etMdlProdSelect');
            const urunId = sel ? (parseInt(sel.value, 10) || 0) : 0;
            const urunAdi = (sel && sel.options[sel.selectedIndex]) ? sel.options[sel.selectedIndex].text.trim() : '';
            const adet = parseInt((document.getElementById('etMdlAdet') || {}).value, 10) || 0;
            const minAlim = parseInt((document.getElementById('etMdlMin') || {}).value, 10) || 1;
            const sart1 = parseInt((document.getElementById('etMdlSart1') || {}).value, 10) || 1;
            const sart2 = parseInt((document.getElementById('etMdlSart2') || {}).value, 10) || 0;
            const komisyon = parseFloat((document.getElementById('etMdlKomisyon') || {}).value) || 0;
            const bazFiyat = parseFloat((document.getElementById('etMdlBazFiyat') || {}).value) || 0;
            const miad = String((document.getElementById('etMdlMiad') || {}).value || '').trim();
            const hedef = String((document.getElementById('etMdlHedef') || {}).value || '0');
            const aciklama = String((document.getElementById('etMdlAciklama') || {}).value || '').trim();
            const bitisAktif = Boolean((document.getElementById('etMdlEndSwitch') || {}).checked);
            const bitisTarihi = String((document.getElementById('etMdlEndDate') || {}).value || '').trim();

            if (urunId < 1) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Lütfen önce ürün arayıp EczaneTakas ürün listesinden seçim yapın.', false);
                return;
            }
            if (adet < 1) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Satılacak kutu adedi en az 1 olmalıdır.', false);
                return;
            }
            if (minAlim < 1 || minAlim > adet) {
                showFb(`<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Minimum alım adedi (${minAlim}), toplam adetten (${adet}) büyük olamaz.`, false);
                return;
            }
            if (bazFiyat <= 0) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Geçerli bir Baz Depo Fiyatı girin.', false);
                return;
            }
            if (!/^\\d{4}-\\d{2}-\\d{2}$/.test(miad)) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Lütfen geçerli bir Miad Tarihi seçin.', false);
                return;
            }
            const uyeler = [];
            if (hedef === '1') {
                document.querySelectorAll('.et-mdl-pharm-chk:checked').forEach(chk => {
                    if (chk.value) uyeler.push(chk.value);
                });
                if (!uyeler.length) {
                    showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Özel hedef seçildiğinde listeden en az 1 eczane işaretlemelisiniz.', false);
                    return;
                }
            }

            const netPreview = (((bazFiyat * sart1) / (sart1 + sart2)) * (1.0 - (komisyon / 100.0))).toFixed(2);
            const mfLabel = sart2 > 0 ? `${sart1}+${sart2}` : '1+0 (MF Yok)';
            const confirmTxt = `EczaneTakas'ta aşağıdaki teklifi YAYINA ALMAK istediğinize emin misiniz?\\n\\n`
                + `• Ürün: ${urunAdi}\\n`
                + `• Adet: ${adet} Kutu (Min. Alım: ${minAlim})\\n`
                + `• Şart: ${mfLabel}${komisyon > 0 ? ' + -%' + komisyon : ''}\\n`
                + `• Baz Fiyat: ${bazFiyat.toFixed(2)} ₺ ➔ Net Satış: ${netPreview} ₺ (KDV Dahil)\\n`
                + `• Miad: ${miad}`;
            if (!window.confirm(confirmTxt)) return;

            const btn = document.getElementById('etMdlSubmitBtn');
            const orig = btn ? btn.innerHTML : '';
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i>Yayınlanıyor...'; }
            try {
                const res = await fetch('/api/eczanetakas/campaign/create', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        urun_id: urunId,
                        urun_adi: urunAdi,
                        adet: adet,
                        minumum: minAlim,
                        alimsarti1: sart1,
                        alimsarti2: sart2,
                        komisyon: komisyon,
                        baz_fiyat: bazFiyat,
                        miad: miad,
                        hedef: hedef,
                        uyeler: uyeler,
                        aciklama: aciklama,
                        bitis_aktif: bitisAktif,
                        teklifbitis: bitisTarihi
                    })
                });
                const result = await res.json();
                if (result.success) {
                    showFb(
                        `<span><i class="fa-solid fa-circle-check text-emerald-600 mr-1.5"></i><strong>${urunAdi}</strong> için <strong>${adet} kutu (${mfLabel} • Net: ${result.netfiyat || netPreview} ₺)</strong> teklifiniz EczaneTakas'ta yayına alındı!</span>`
                        + `<button type="button" onclick="openEczaneTakasOffersModal(true, 'offers')" class="px-3 py-1 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-[11px] font-black cursor-pointer">Açık Teklifleri Gör →</button>`,
                        true
                    );
                    if (typeof showToast === 'function') showToast('EczaneTakas Teklifi Yayınlandı 🎉', `${urunAdi} teklifiniz yayına alındı!`, 'success');
                } else {
                    showFb(`<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${result.message || 'Teklif oluşturulamadı.'}`, false);
                    if (typeof showToast === 'function') showToast('Teklif Açılamadı', result.message || 'EczaneTakas teklifi kaydedilemedi.', 'error');
                }
            } catch (e) {
                showFb(`<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>Bağlantı hatası: ${e.message}`, false);
            } finally {
                if (btn) { btn.disabled = false; btn.innerHTML = orig; }
            }
        }

        function compareFromEczaneTakasOffer(barcode, name) {
            closeEczaneTakasOffersModal();
            if (typeof switchMainView === 'function') switchMainView('depo');
            const q = (barcode && barcode.length >= 8) ? barcode : name;
            const searchInput = document.getElementById('searchInput');
            if (searchInput) searchInput.value = name || q;
            if (barcode && /^\\d{8,14}$/.test(barcode) && typeof performBarcodeSearch === 'function') {
                performBarcodeSearch(barcode);
            } else if (typeof handleSearchSubmit === 'function') {
                handleSearchSubmit(q);
            }
        }

        function renderEczaneTakasOffersModal() {
            const body = document.getElementById('etModalBody');
            const badge = document.getElementById('etModalCountBadge');
            const inp = document.getElementById('etModalSearchInput');
            if (!body) return;
            const q = inp ? inp.value.trim().toLowerCase() : '';
            const all = window.etActiveOffersCache || [];
            const filtered = all.filter(o => {
                if (!q) return true;
                return (o.urun_adi || '').toLowerCase().includes(q)
                    || (o.barcode || '').toLowerCase().includes(q)
                    || (o.ekleyen || '').toLowerCase().includes(q);
            });
            // Bugün katılınan teklifleri en üstte göster
            filtered.sort((a, b) => {
                const aOrd = window.findTodayOrderMatchForOffer(a, 'ECZANETAKAS');
                const bOrd = window.findTodayOrderMatchForOffer(b, 'ECZANETAKAS');
                const aJ = (aOrd && aOrd.isThisOfferJoined) ? 1 : 0;
                const bJ = (bOrd && bOrd.isThisOfferJoined) ? 1 : 0;
                return bJ - aJ;
            });
            if (badge) badge.innerText = `${filtered.length} Teklif`;
            if (filtered.length === 0) {
                body.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs font-bold">Aramanıza uygun açık teklif bulunamadı.</div>`;
                return;
            }
            const joinedOffers = all.filter(o => {
                const m = window.findTodayOrderMatchForOffer(o, 'ECZANETAKAS');
                return m && m.isThisOfferJoined;
            });
            const joinedBannerHtml = joinedOffers.length > 0 ? `
                <div class="mb-3 p-3 rounded-2xl bg-emerald-50 border-2 border-emerald-400 shadow-xs">
                    <div class="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                        <div class="flex items-center space-x-2 text-emerald-900 font-black text-xs">
                            <i class="fa-solid fa-circle-check text-emerald-600 text-sm"></i>
                            <span>BUGÜN ECZANETAKAS'TAN KATILDIĞINIZ / SİPARİŞ VERDİĞİNİZ TEKLİFLER (${joinedOffers.length} Kalem)</span>
                        </div>
                        <span class="text-[10px] font-bold text-emerald-700">Sayfadan çıkıp tekrar girseniz de katıldığınız ürünler burada sabit kalır</span>
                    </div>
                    <div class="flex flex-wrap gap-1.5">
                        ${joinedOffers.map(jo => {
                            const jm = window.findTodayOrderMatchForOffer(jo, 'ECZANETAKAS') || {};
                            const qty = jm.siparis_miktar || jo.katilinan_miktar || 1;
                            const tm = jm.siparis_saat || jo.siparis_saat || '';
                            return `<span class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-white border border-emerald-300 text-emerald-950 text-[11px] font-extrabold shadow-2xs">
                                <i class="fa-solid fa-check text-emerald-600 text-[10px]"></i>
                                <span>${jo.urun_adi}</span>
                                <span class="px-1.5 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-black">${qty} Kutu</span>
                                ${tm ? `<span class="text-[10px] text-slate-500 font-mono">${tm}</span>` : ''}
                            </span>`;
                        }).join('')}
                    </div>
                </div>
            ` : '';
            const otoLabel = window.etActiveOtomasyonName || 'Eczane';
            body.innerHTML = `
                ${joinedBannerHtml}
                <div class="overflow-x-auto rounded-2xl border border-slate-200">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-slate-100 text-slate-600 font-extrabold uppercase text-[10px] border-b border-slate-200">
                            <tr>
                                <th class="py-2.5 px-3">Ürün Adı & Barkod</th>
                                <th class="py-2.5 px-2.5 text-center bg-emerald-50/70 text-emerald-900 border-x border-emerald-100" title="${otoLabel} Anlık Raf Stoğu">Anlık Stok</th>
                                <th class="py-2.5 px-2.5 text-center bg-blue-50/70 text-blue-900 border-r border-blue-100" title="${otoLabel} Son 1 Aylık (30 Gün) Toplam Çıkış">1 Aylık Çıkış</th>
                                <th class="py-2.5 px-2.5 text-center bg-violet-50/70 text-violet-900 border-r border-violet-100" title="${otoLabel} Son 3 Aylık (90 Gün) Toplam Çıkış">3 Aylık Çıkış</th>
                                <th class="py-2.5 px-3">Teklif Veren Eczane</th>
                                <th class="py-2.5 px-2.5 text-center">Takas Stoğu</th>
                                <th class="py-2.5 px-2.5 text-center">Barem / MF</th>
                                <th class="py-2.5 px-2.5 text-right">Depo Fiyatı</th>
                                <th class="py-2.5 px-2.5 text-right">Net Satış (KDV'li)</th>
                                <th class="py-2.5 px-2.5 text-center">Miad</th>
                                <th class="py-2.5 px-3 text-right">Hızlı Katıl & İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            ${filtered.map(o => {
                                const safeName = (o.urun_adi || '').replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
                                const safeBc = (o.barcode || '').replace(/'/g, "\\\\'");
                                const eczStok = parseInt(o.eczane_stok ?? 0, 10) || 0;
                                const cikis1A = parseInt(o.cikis_1ay ?? 0, 10) || 0;
                                const cikis3A = parseInt(o.cikis_3ay ?? 0, 10) || 0;
                                const maxKalan = Math.max(1, parseInt(o.kalan_stok ?? 1, 10) || 1);
                                const dKey = `ET_${o.teklif_no}`;
                                const initQty = window.getOfferJoinInitialQty(dKey, 1, maxKalan, 1, 0);
                                const ordMatch = window.findTodayOrderMatchForOffer(o, 'ECZANETAKAS');
                                const isJoined = Boolean(ordMatch && ordMatch.isThisOfferJoined);
                                const isOtherOrdered = Boolean(ordMatch && !isJoined && ordMatch.siparis_durumu);
                                const joinedQty = ordMatch ? (ordMatch.siparis_miktar || 1) : 0;
                                const ordSaat = ordMatch ? (ordMatch.siparis_saat || '') : '';
                                const ordMasa = ordMatch ? (ordMatch.siparis_masa || '') : '';
                                const ordDepo = ordMatch ? (ordMatch.siparis_depo || 'DEPO') : '';
                                const rowClass = isJoined
                                    ? 'bg-emerald-50/80 hover:bg-emerald-100/70 border-l-4 border-l-emerald-600 transition'
                                    : (isOtherOrdered ? 'bg-amber-50/60 hover:bg-amber-100/50 border-l-4 border-l-amber-500 transition' : 'hover:bg-sky-50/40 transition');
                                const orderBadgeHtml = isJoined
                                    ? `<div class="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-black shadow-2xs">
                                           <i class="fa-solid fa-circle-check"></i>
                                           <span>SİPARİŞ VERİLDİ / KATILINDI: ${joinedQty} KUTU${ordSaat ? ' (' + ordSaat + (ordMasa ? ' • ' + ordMasa : '') + ')' : ''}</span>
                                       </div>`
                                    : (isOtherOrdered
                                        ? `<div class="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500 text-white text-[10px] font-black shadow-2xs">
                                               <i class="fa-solid fa-triangle-exclamation"></i>
                                               <span>BUGÜN ${ordMatch.siparis_durumu === 'SEPETTE' ? 'SEPETTE' : 'SİPARİŞ VERİLDİ'}: ${ordDepo} (${joinedQty} KUTU${ordSaat ? ' • ' + ordSaat : ''})</span>
                                           </div>`
                                        : '');
                                const stokClass = eczStok <= 0
                                    ? 'bg-rose-100 text-rose-800 border-rose-200'
                                    : (eczStok <= 2 ? 'bg-amber-100 text-amber-900 border-amber-200' : 'bg-emerald-100 text-emerald-900 border-emerald-200');
                                const c1Class = cikis1A > 0
                                    ? 'bg-blue-100 text-blue-900 border-blue-200'
                                    : 'bg-slate-100 text-slate-500 border-slate-200';
                                const c3Class = cikis3A > 0
                                    ? 'bg-violet-100 text-violet-900 border-violet-200'
                                    : 'bg-slate-100 text-slate-500 border-slate-200';
                                const katilUrl = o.katil_url || ('https://eczanetakas.com/katil/' + o.teklif_no);
                                return `
                                    <tr class="${rowClass}">
                                        <td class="py-2.5 px-3">
                                            <div class="font-extrabold text-slate-900">${o.urun_adi}</div>
                                            <div class="text-[10px] font-mono text-slate-400">${o.barcode || 'Barkod Eşleşti'} • #${o.teklif_no}</div>
                                            ${orderBadgeHtml}
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center bg-emerald-50/25 border-x border-slate-100">
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-lg font-black text-[11px] border ${stokClass}">${eczStok} Kt</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center bg-blue-50/20 border-r border-slate-100">
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-lg font-black text-[11px] border ${c1Class}">${cikis1A} Ad</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center bg-violet-50/20 border-r border-slate-100">
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-lg font-black text-[11px] border ${c3Class}">${cikis3A} Ad</span>
                                        </td>
                                        <td class="py-2.5 px-3 font-bold text-slate-700">
                                            <i class="fa-solid fa-hospital text-sky-600 mr-1 text-[10px]"></i>${o.ekleyen || '-'}
                                            ${o.not ? `<div class="text-[10px] text-amber-700 font-normal italic">${o.not}</div>` : ''}
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center">
                                            <span id="etKalanStok_${o.teklif_no}" class="px-2 py-0.5 rounded-lg font-black bg-sky-100 text-sky-900 border border-sky-200">${o.kalan_stok} Kt</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center">
                                            <span class="px-2 py-0.5 rounded font-black bg-indigo-50 text-indigo-900 border border-indigo-200 font-mono">${o.mf || 'YOK'}</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-right font-mono text-slate-500">${Number(o.depo_fiyati || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-2.5 text-right font-mono font-extrabold text-emerald-700">${Number(o.satis_fiyati || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-2.5 text-center font-mono text-[11px] text-slate-700">${o.miad || '-'}</td>
                                        <td class="py-2.5 px-3 text-right">
                                            <div class="flex items-center justify-end space-x-1" data-join-group="1">
                                                <div class="inline-flex items-center rounded-lg border border-slate-300 bg-white overflow-hidden" data-qty-stepper="1">
                                                    <button type="button" onclick="stepOfferJoinQty(this, -1, ${maxKalan}, 1, 1)" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">-</button>
                                                    <input type="number" data-offer-qty-key="${dKey}" value="${initQty}" min="1" max="${maxKalan}" oninput="onOfferQtyInputChange(this, '${dKey}', 1, ${maxKalan}, 1, false)" onchange="onOfferQtyInputChange(this, '${dKey}', 1, ${maxKalan}, 1, true)" class="w-11 text-center text-[11px] font-black text-slate-800 focus:outline-none py-0.5" />
                                                    <button type="button" onclick="stepOfferJoinQty(this, 1, ${maxKalan}, 1, 1)" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">+</button>
                                                </div>
                                                ${isJoined ? `
                                                    <button type="button" onclick="joinEczaneTakasOfferDirect('${o.teklif_no}', '${safeBc}', '${safeName}', ${maxKalan}, this)" class="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[11px] cursor-pointer transition flex items-center space-x-1 shadow-xs" title="Bu teklife bugün ${joinedQty} kutu katıldınız. İlave kutu eklemek için tıklayın.">
                                                        <i class="fa-solid fa-circle-check text-[10px]"></i>
                                                        <span>Katılındı (${joinedQty} Kt)</span>
                                                    </button>
                                                ` : `
                                                    <button type="button" onclick="joinEczaneTakasOfferDirect('${o.teklif_no}', '${safeBc}', '${safeName}', ${maxKalan}, this)" class="px-2.5 py-1 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-black text-[11px] cursor-pointer transition flex items-center space-x-1 shadow-xs" title="Şifre girmeden doğrudan bu teklife katıl">
                                                        <i class="fa-solid fa-bolt text-[10px] text-amber-200"></i>
                                                        <span>Katıl</span>
                                                    </button>
                                                `}
                                                <button type="button" onclick="compareFromEczaneTakasOffer('${safeBc}', '${safeName}')" class="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] cursor-pointer transition" title="Tüm depolarla karşılaştır">
                                                    Kıyasla
                                                </button>
                                                <button type="button" onclick="openEtModalCreateForProduct('${safeBc}', '${safeName}', { sellQty: ${Math.max(1, eczStok || 10)} })" class="px-2 py-1 rounded-lg bg-sky-100 hover:bg-sky-200 text-sky-900 border border-sky-200 font-bold text-[11px] cursor-pointer transition" title="Bu ürün için sen de EczaneTakas teklifi aç">
                                                    Teklif Aç
                                                </button>
                                                <button type="button" onclick="openAuthenticatedPortal('ECZANETAKAS', '${katilUrl}')" class="px-1.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-[10px] cursor-pointer transition" title="Hazır oturumla tarayıcıda aç">
                                                    ↗
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        }

        // ============================================================
        // ECZATREND CANLI ORTAK ALIM, TAKAS AÇMA & TEKLİF YÖNETİMİ MODALI
        // ============================================================
        window.eczatrendActiveOffersCache = [];
        window.eczatrendActiveOtomasyonName = '';
        window.etrModalActiveTab = 'offers'; // 'offers' | 'create' | 'my_offers'
        window.etrModalMyOffersCache = [];
        window.etrModalBuyersOpenMap = {};
        window.etrModalCreateState = {
            editOfferPk: '',
            editOriginalStatus: '',
            mode: '2',
            productPk: '',
            productName: '',
            barcode: '',
            vat: 10,
            groups: [],
            selectedGroupKey: '',
            pharmacies: [],
            candidates: [],
            canCreateOffer: true,
            preflightWarning: '',
            conditions: [{ amount: 1, extra: 0, depoiskonto: 0, depoiskontoTL: 0, conditionPK: '' }]
        };

        function ensureEczatrendModalDom() {
            if (document.getElementById('eczatrendOffersModal')) return;
            const modalHtml = `
                <div id="eczatrendOffersModal" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4">
                    <div class="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-7xl max-h-[92vh] flex flex-col overflow-hidden">
                        <div class="bg-gradient-to-r from-purple-800 via-fuchsia-800 to-orange-700 px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 text-white">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center font-black text-lg">
                                    <i class="fa-solid fa-users-rectangle"></i>
                                </div>
                                <div>
                                    <h3 class="text-base font-extrabold tracking-tight flex flex-wrap items-center gap-2">
                                        <span>Eczatrend — Ortak Alım, Takas Açma & Teklif Merkezi</span>
                                        <span id="etrModalCountBadge" class="text-[11px] bg-white/20 px-2.5 py-0.5 rounded-full font-bold">0 Teklif</span>
                                        <span id="etrModalOtoBadge" class="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-emerald-400/25 border border-emerald-300/40 text-emerald-50">🌿 Eczane Stok & 1A/3A Çıkış Entegreli</span>
                                    </h3>
                                    <p class="text-xs text-purple-100">Grup tekliflerine katılın, raf stoğunuzdan takas / depo kampanyası açın ve açtığınız teklifleri yönetin.</p>
                                </div>
                            </div>
                            <div class="flex items-center space-x-2">
                                <button type="button" onclick="refreshActiveEczatrendModalTab()" class="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-xs font-bold transition cursor-pointer flex items-center space-x-1.5">
                                    <i class="fa-solid fa-rotate"></i>
                                    <span>Yenile</span>
                                </button>
                                <button type="button" onclick="openAuthenticatedPortal('ECZATREND', 'https://eczatrend.com/eczanet/panelNew/main.html')" class="px-3 py-1.5 rounded-xl bg-white text-purple-900 hover:bg-purple-50 text-xs font-extrabold transition flex items-center space-x-1.5 cursor-pointer" title="Şifre girmeden doğrudan açık oturumla Eczatrend portalını aç">
                                    <span>Siteyi Aç (Hazır Oturum)</span>
                                    <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                                </button>
                                <button type="button" onclick="closeEczatrendOffersModal()" class="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                        </div>

                        <!-- 3 Ana Sekme Çubuğu -->
                        <div class="px-6 pt-2.5 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                            <div class="flex items-center gap-1.5">
                                <button type="button" id="etrTabBtnOffers" onclick="switchEczatrendModalTab('offers')" class="px-3.5 py-2 rounded-t-xl text-xs font-extrabold bg-white text-purple-900 border border-b-0 border-slate-200 flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-cart-plus text-purple-600"></i>
                                    <span>Grup Teklifleri (Alıma Katıl)</span>
                                </button>
                                <button type="button" id="etrTabBtnCreate" onclick="switchEczatrendModalTab('create')" class="px-3.5 py-2 rounded-t-xl text-xs font-bold text-slate-600 hover:text-orange-800 flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-bullhorn text-orange-600"></i>
                                    <span id="etrTabBtnCreateLabel">➕ Yeni Takas / Kampanya Aç</span>
                                </button>
                                <button type="button" id="etrTabBtnMyOffers" onclick="switchEczatrendModalTab('my_offers')" class="px-3.5 py-2 rounded-t-xl text-xs font-bold text-slate-600 hover:text-indigo-800 flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-list-check text-indigo-600"></i>
                                    <span>Açtığım Tekliflerim & Yönet</span>
                                </button>
                            </div>
                            <div id="etrModalActiveGroupInfo" class="text-[11px] font-bold text-slate-500 pb-1.5"></div>
                        </div>

                        <!-- Sekme 1 Arama Çubuğu -->
                        <div id="etrModalOffersToolbar" class="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3">
                            <div class="relative flex-1 flex items-center gap-2">
                                <div class="relative flex-1">
                                    <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-2.5 text-slate-400 text-xs"></i>
                                    <input type="search" role="searchbox" name="fr_etr_modal_q" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" data-lpignore="true" data-1p-ignore="true" data-bwignore="true" data-form-type="other" id="etrModalSearchInput" oninput="renderEczatrendOffersModal()" onkeydown="if(event.key==='Enter') searchEczatrendModalServer()" placeholder="İlaç adı, barkod, grup veya eczane ara... (Tüm sitede aramak için Enter'a basın)" class="w-full pl-9 pr-4 py-2 text-xs font-semibold rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white" />
                                </div>
                                <button type="button" onclick="searchEczatrendModalServer()" class="px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition cursor-pointer whitespace-nowrap">
                                    Portalda Ara
                                </button>
                            </div>
                            <span class="text-[11px] text-slate-500 font-medium hidden md:inline">⚡ Adet seçip <strong>"Katıl"</strong> ile anında katılabilir, <strong>"Takas Aç"</strong> ile kendi ürününüzü satışa çıkarabilirsiniz</span>
                        </div>

                        <!-- Sekme 1 Gövde: Grup Teklifleri -->
                        <div id="etrModalBody" class="flex-1 overflow-y-auto p-4">
                            <div class="p-8 text-center text-slate-400 text-sm">Yükleniyor...</div>
                        </div>

                        <!-- Sekme 2 Gövde: Yeni Takas / Kampanya Aç & Düzenle -->
                        <div id="etrModalCreateBody" class="hidden flex-1 overflow-y-auto p-5 bg-slate-50/70 space-y-4"></div>

                        <!-- Sekme 3 Gövde: Açtığım Tekliflerim & Yönet -->
                        <div id="etrModalMyOffersBody" class="hidden flex-1 overflow-y-auto p-5 bg-slate-50/70 space-y-3"></div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHtml);
        }

        function refreshActiveEczatrendModalTab() {
            if (window.etrModalActiveTab === 'my_offers') {
                loadEtrMyOffersList(true);
            } else if (window.etrModalActiveTab === 'create') {
                initEtrModalCreateTab(true);
            } else {
                openEczatrendOffersModal(true, '', 'offers');
            }
        }

        async function switchEczatrendModalTab(tab) {
            ensureEczatrendModalDom();
            const t = ['offers', 'create', 'my_offers'].includes(tab) ? tab : 'offers';
            window.etrModalActiveTab = t;

            const toolbar = document.getElementById('etrModalOffersToolbar');
            const bodyOffers = document.getElementById('etrModalBody');
            const bodyCreate = document.getElementById('etrModalCreateBody');
            const bodyMy = document.getElementById('etrModalMyOffersBody');

            const btnO = document.getElementById('etrTabBtnOffers');
            const btnC = document.getElementById('etrTabBtnCreate');
            const btnM = document.getElementById('etrTabBtnMyOffers');
            const actCls = 'px-3.5 py-2 rounded-t-xl text-xs font-extrabold bg-white text-slate-900 border border-b-0 border-slate-200 flex items-center gap-1.5 cursor-pointer shadow-2xs';
            const pasCls = 'px-3.5 py-2 rounded-t-xl text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer';

            if (btnO) btnO.className = (t === 'offers') ? actCls : pasCls;
            if (btnC) btnC.className = (t === 'create') ? actCls : pasCls;
            if (btnM) btnM.className = (t === 'my_offers') ? actCls : pasCls;

            if (toolbar) toolbar.classList.toggle('hidden', t !== 'offers');
            if (bodyOffers) bodyOffers.classList.toggle('hidden', t !== 'offers');
            if (bodyCreate) bodyCreate.classList.toggle('hidden', t !== 'create');
            if (bodyMy) bodyMy.classList.toggle('hidden', t !== 'my_offers');

            if (t === 'create') {
                await initEtrModalCreateTab(false);
            } else if (t === 'my_offers') {
                await loadEtrMyOffersList(false);
            }
        }

        async function openEczatrendOffersModal(forceRefresh = false, serverQuery = '', initialTab = null) {
            ensureEczatrendModalDom();
            const modal = document.getElementById('eczatrendOffersModal');
            const body = document.getElementById('etrModalBody');
            if (modal) modal.classList.remove('hidden');

            const targetTab = initialTab || window.etrModalActiveTab || 'offers';
            await switchEczatrendModalTab(targetTab);
            if (targetTab !== 'offers') return;

            const hasCache = Array.isArray(window.eczatrendActiveOffersCache) && window.eczatrendActiveOffersCache.length > 0;
            if (hasCache && !forceRefresh && !serverQuery) {
                renderEczatrendOffersModal();
            } else if (body) {
                body.innerHTML = `<div class="p-10 text-center text-purple-700 font-bold text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl mb-2 block"></i>Eczatrend ortak alım teklifleri ve eczane stok / 1A-3A çıkış verileri çekiliyor...</div>`;
            }
            try {
                if (typeof syncTodayOrdersAcrossPCs === 'function') {
                    await syncTodayOrdersAcrossPCs();
                }
                const params = new URLSearchParams();
                if (forceRefresh) params.set('refresh', 'true');
                if (serverQuery) params.set('q', serverQuery);
                const qs = params.toString() ? ('?' + params.toString()) : '';
                const res = await fetch('/api/eczatrend/offers' + qs);
                const data = await res.json();
                if (data.success) {
                    window.eczatrendActiveOffersCache = data.offers || [];
                    window.eczatrendActiveOtomasyonName = data.otomasyon || '';
                    const otoBadge = document.getElementById('etrModalOtoBadge');
                    if (otoBadge && data.otomasyon) {
                        otoBadge.innerText = `🏥 ${data.otomasyon} Stok & 1A/3A Çıkış Aktif`;
                    }
                    if (window.etrModalActiveTab === 'offers') renderEczatrendOffersModal();
                } else if (!hasCache && body) {
                    body.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-sm">${data.message || 'Teklifler alınamadı.'}</div>`;
                }
            } catch (e) {
                if (!hasCache && body) {
                    body.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-sm">Bağlantı hatası: ${e.message}</div>`;
                }
            }
        }

        function searchEczatrendModalServer() {
            const inp = document.getElementById('etrModalSearchInput');
            const q = inp ? inp.value.trim() : '';
            openEczatrendOffersModal(true, q, 'offers');
        }

        function closeEczatrendOffersModal() {
            const modal = document.getElementById('eczatrendOffersModal');
            if (modal) modal.classList.add('hidden');
        }

        // ============================================================
        // SEKME 2: MODAL İÇİ TAKAS / KAMPANYA OLUŞTURMA & DÜZENLEME
        // ============================================================
        let _etrMdlSearchTimer = null;

        window.openEtrModalCreateForProduct = async function(barcode, name, opts = {}) {
            ensureEczatrendModalDom();
            const st = window.etrModalCreateState;
            st.editOfferPk = '';
            st.editOriginalStatus = '';
            st.mode = opts.mode || '2';
            st.unitCost = Math.max(0, parseFloat(opts.unitCost || 0) || 0);
            st.hintPsf = Math.max(0, parseFloat(opts.psf || 0) || 0);
            st.recPrice = Math.max(0, parseFloat(opts.recPrice || 0) || 0);
            st.hasActiveGroupOffer = false;
            st.activeOfferWarning = '';
            st.conditions = [{ amount: 1, extra: 0, depoiskonto: 0, depoiskontoTL: 0, conditionPK: '' }];

            const lbl = document.getElementById('etrTabBtnCreateLabel');
            if (lbl) lbl.innerText = '➕ Yeni Takas / Kampanya Aç';
            const modal = document.getElementById('eczatrendOffersModal');
            if (modal) modal.classList.remove('hidden');

            await switchEczatrendModalTab('create');
            resetEtrModalCreateToNew();
            setEtrModalCreateMode(st.mode);

            const sellQty = Math.max(1, parseInt(opts.sellQty || 10, 10) || 10);
            const tInp = document.getElementById('etrMdlTarget');
            const minInp = document.getElementById('etrMdlMin');
            const maxInp = document.getElementById('etrMdlMax');
            const infoInp = document.getElementById('etrMdlInfo');
            const tgtNetInp = document.getElementById('etrMdlTargetNet');
            const sInp = document.getElementById('etrMdlProdSearch');
            const fb = document.getElementById('etrMdlCreateFeedback');

            if (fb) { fb.classList.add('hidden'); fb.innerHTML = ''; }
            if (tInp) tInp.value = String(sellQty);
            if (minInp) minInp.value = '1';
            if (maxInp) maxInp.value = String(sellQty);
            if (tgtNetInp) tgtNetInp.value = '';
            if (infoInp) infoInp.value = opts.info !== undefined ? String(opts.info) : '';
            const expInp = document.getElementById('etrMdlExpire');
            if (expInp && opts.miad && /^\\d{4}-\\d{2}-\\d{2}$/.test(String(opts.miad))) {
                expInp.value = String(opts.miad);
            }

            const q = String(barcode || name || '').trim();
            if (sInp) sInp.value = String(name || barcode || '').trim();

            _renderEtrModalRefPills();
            if (q) {
                await searchEtrModalCatalog(q, barcode, name);
            }
            // Eğer Atıl Stoktan önerilen takas fiyatı geldiyse hedef net olarak uygula
            const mktNow = parseFloat((document.getElementById('etrMdlMarketPrice') || {}).value) || 0;
            if (st.recPrice > 0 && mktNow > 0 && st.recPrice < mktNow && tgtNetInp) {
                tgtNetInp.value = st.recPrice.toFixed(2);
                applyEtrModalTargetNet(st.recPrice.toFixed(2));
            } else {
                recalcEtrModalNet();
            }
        };

        async function initEtrModalCreateTab(forceBootstrap = false) {
            const box = document.getElementById('etrModalCreateBody');
            if (!box) return;
            const st = window.etrModalCreateState;

            if (!box.dataset.rendered || forceBootstrap) {
                const defMiad = (typeof _formatIsoDatePlusMonths === 'function') ? _formatIsoDatePlusMonths(12) : '';
                const defEnd = (typeof _formatIsoDatePlusDays === 'function') ? _formatIsoDatePlusDays(30) : '';
                box.innerHTML = `
                    <div id="etrMdlPreflightWarn" class="hidden rounded-2xl px-4 py-2.5 text-xs font-bold border bg-amber-50 border-amber-300 text-amber-950"></div>

                    <div id="etrMdlEditBanner" class="hidden rounded-2xl px-4 py-2.5 text-xs font-extrabold bg-indigo-50 border border-indigo-300 text-indigo-950 flex items-center justify-between gap-2">
                        <span><i class="fa-solid fa-pen-to-square mr-1.5 text-indigo-600"></i>Mevcut Teklifi Düzenliyorsunuz: <strong id="etrMdlEditTitle"></strong></span>
                        <button type="button" onclick="resetEtrModalCreateToNew()" class="px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-[11px] font-bold cursor-pointer">Yeni Teklife Dön ✕</button>
                    </div>

                    <!-- Mod ve Yayın Ayarları -->
                    <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <div class="flex flex-wrap items-center gap-1.5">
                                <button type="button" id="etrMdlMode2" onclick="setEtrModalCreateMode('2')" class="px-3.5 py-2 rounded-xl text-xs font-extrabold bg-orange-600 text-white cursor-pointer">📦 Raf Stoğumdan Takas (Stoğumdaki Ürün)</button>
                                <button type="button" id="etrMdlMode0" onclick="setEtrModalCreateMode('0')" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-purple-50 cursor-pointer">🏷️ Depodan Genel Kampanya</button>
                                <button type="button" id="etrMdlMode1" onclick="setEtrModalCreateMode('1')" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-indigo-50 cursor-pointer">✨ Deponun Bana Özel Teklifi</button>
                            </div>
                            <div class="flex flex-wrap items-center gap-2">
                                <select id="etrMdlSpecType" onchange="onEtrModalSpecTypeChange()" class="bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl px-3 py-2">
                                    <option value="0">Grubuma Özel Yayınla</option>
                                    <option value="1">Birebir Eczaneye Özel (Takas)</option>
                                    <option value="2">Tüm Gruplarımda Yayınla</option>
                                </select>
                                <select id="etrMdlGroupSelect" onchange="onEtrModalGroupChange(this.value)" class="bg-orange-50 border border-orange-300 text-orange-950 font-extrabold text-xs rounded-xl px-3 py-2 max-w-[240px]">
                                    <option value="">Grup Yükleniyor...</option>
                                </select>
                            </div>
                        </div>

                        <div id="etrMdlSpecPharmRow" class="hidden pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <input type="text" id="etrMdlPharmFilter" oninput="renderEtrModalPharmOptions(this.value)" placeholder="Eczane ara..." class="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs" />
                            <select id="etrMdlPharmSelect" class="bg-white border border-purple-300 font-bold text-slate-900 rounded-xl px-3 py-2 text-xs">
                                <option value="">-- Hedef Eczaneyi Seçiniz --</option>
                            </select>
                        </div>

                        <!-- Depo Kampanyası Ek Ayarları (Mod 0 ve Mod 1'de açılır) -->
                        <div id="etrMdlDepoExtraRow" class="hidden pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                            <div>
                                <label class="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Hedeflenen Alım Aşımı</label>
                                <select id="etrMdlAcceptRecord" class="w-full bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl px-2.5 py-1.5">
                                    <option value="2">Hedef Geçilebilsin</option>
                                    <option value="1">Hedef Geçilmesin</option>
                                </select>
                            </div>
                            <div>
                                <label class="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Alım Katı (İsteğe Bağlı)</label>
                                <input type="number" id="etrMdlMultiplier" min="1" placeholder="Örn: 5 (5'er kat)" class="w-full bg-slate-50 border border-slate-300 font-bold text-xs rounded-xl px-2.5 py-1.5" />
                            </div>
                            <div>
                                <label class="text-[10px] font-extrabold text-slate-500 uppercase block mb-1">Kendi Alımım (Kutu)</label>
                                <input type="number" id="etrMdlSelfPurchase" min="0" value="0" class="w-full bg-slate-50 border border-slate-300 font-bold text-xs rounded-xl px-2.5 py-1.5 text-center" />
                            </div>
                        </div>
                    </div>

                    <!-- Ürün Arama & Seçim -->
                    <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-2.5">
                        <div class="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
                            <div class="md:col-span-5">
                                <label class="text-[11px] font-extrabold text-slate-700 block mb-1">1. Barkod veya Ürün Adı Ara (En az 3 harf)</label>
                                <div class="flex gap-1.5">
                                    <input type="text" id="etrMdlProdSearch" autocomplete="off" oninput="debouncedEtrModalCatalogSearch(this.value)" onkeydown="if(event.key==='Enter') searchEtrModalCatalog(this.value)" placeholder="869... veya ilaç adı yazın..." class="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-orange-500" />
                                    <button type="button" onclick="searchEtrModalCatalog(document.getElementById('etrMdlProdSearch').value)" class="px-3 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-extrabold cursor-pointer">Ara</button>
                                </div>
                            </div>
                            <div class="md:col-span-7">
                                <label class="text-[11px] font-extrabold text-slate-700 block mb-1">2. Eşleşen Eczatrend Ürünü <span class="text-rose-500">*</span></label>
                                <select id="etrMdlProdSelect" onchange="onEtrModalProdSelectChange()" class="w-full bg-white border border-orange-300 text-slate-900 font-bold text-xs rounded-xl px-3 py-2">
                                    <option value="">-- Soldan barkod veya ilaç adı aratın --</option>
                                </select>
                            </div>
                        </div>
                        <div id="etrMdlRefPills" class="flex flex-wrap items-center gap-1.5 text-[10.5px]"></div>
                    </div>

                    <!-- Fiyat, Adet ve Net Hesaplama -->
                    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                        <div class="bg-white p-3 rounded-2xl border border-slate-200">
                            <label id="etrMdlTargetLabel" class="text-[10px] font-extrabold text-slate-500 uppercase block">Takas Adedi *</label>
                            <input type="number" id="etrMdlTarget" value="10" min="1" oninput="syncEtrModalTargetMinMax('target')" class="mt-1 w-full bg-slate-50 border border-slate-300 font-black text-sm rounded-xl px-2 py-1.5 text-center" />
                        </div>
                        <div class="bg-white p-3 rounded-2xl border border-slate-200">
                            <div class="flex items-center justify-between">
                                <label class="text-[10px] font-extrabold text-slate-500 uppercase">Min / Maks *</label>
                                <button type="button" onclick="setEtrModalAllOrSingle(true)" class="px-1 py-0.2 rounded bg-slate-100 hover:bg-orange-100 text-[9px] font-bold text-slate-600 cursor-pointer" title="Tümünü tek seferde sat (Min=Maks=Hedef)">Tümü</button>
                            </div>
                            <div class="mt-1 flex items-center gap-1">
                                <input type="number" id="etrMdlMin" value="1" min="1" onchange="syncEtrModalTargetMinMax('min')" class="w-full bg-slate-50 border border-slate-300 font-black text-sm rounded-xl px-1.5 py-1.5 text-center" />
                                <span>/</span>
                                <input type="number" id="etrMdlMax" value="10" min="1" onchange="syncEtrModalTargetMinMax('max')" class="w-full bg-slate-50 border border-slate-300 font-black text-sm rounded-xl px-1.5 py-1.5 text-center" />
                            </div>
                        </div>
                        <div class="bg-white p-3 rounded-2xl border border-slate-200">
                            <label class="text-[10px] font-extrabold text-slate-500 uppercase block">Depo Fiyatı (KDV'li) *</label>
                            <input type="number" id="etrMdlMarketPrice" value="0.00" step="0.01" oninput="recalcEtrModalNet()" class="mt-1 w-full bg-slate-50 border border-slate-300 font-mono font-black text-sm rounded-xl px-2 py-1.5 text-center" />
                        </div>
                        <div class="bg-white p-3 rounded-2xl border border-slate-200">
                            <label class="text-[10px] font-extrabold text-slate-500 uppercase block">Etiket Fiyatı (PSF) *</label>
                            <input type="number" id="etrMdlProductPrice" value="0.00" step="0.01" class="mt-1 w-full bg-slate-50 border border-slate-300 font-mono font-black text-sm rounded-xl px-2 py-1.5 text-center" />
                        </div>
                        <div class="bg-amber-50/80 p-3 rounded-2xl border border-amber-300">
                            <label class="text-[10px] font-extrabold text-amber-900 uppercase block">⚡ Hedef Net Fiyat (₺)</label>
                            <input type="number" id="etrMdlTargetNet" placeholder="Örn: 250" step="0.01" oninput="applyEtrModalTargetNet(this.value)" class="mt-1 w-full bg-white border border-amber-400 font-mono font-black text-sm rounded-xl px-2 py-1.5 text-center" />
                        </div>
                        <div class="bg-emerald-50 p-3 rounded-2xl border border-emerald-300 text-center flex flex-col justify-center">
                            <div class="text-[10px] font-extrabold text-emerald-800 uppercase">En İyi Net Fiyat</div>
                            <div id="etrMdlBestNet" class="text-base font-black font-mono text-emerald-700 mt-0.5">0.00 ₺</div>
                            <div id="etrMdlBestKdvsiz" class="text-[10px] font-mono text-slate-600">KDV H: 0.00 ₺</div>
                        </div>
                    </div>

                    <!-- Barem Satırları -->
                    <div class="bg-white p-4 rounded-2xl border border-slate-200 space-y-2">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <span class="text-xs font-extrabold text-slate-800"><i class="fa-solid fa-layer-group text-orange-600 mr-1"></i>Teklif Şartları / MF Baremleri (1. satır 1+0 zorunludur)</span>
                            <div class="flex flex-wrap items-center gap-1.5">
                                <button type="button" onclick="applyEtrModalQuickIsk(5)" class="px-2 py-1 rounded-lg bg-orange-50 hover:bg-orange-600 hover:text-white text-orange-900 border border-orange-200 text-[11px] font-bold cursor-pointer">-%5</button>
                                <button type="button" onclick="applyEtrModalQuickIsk(10)" class="px-2 py-1 rounded-lg bg-orange-50 hover:bg-orange-600 hover:text-white text-orange-900 border border-orange-200 text-[11px] font-bold cursor-pointer">-%10</button>
                                <button type="button" onclick="applyEtrModalQuickIsk(15)" class="px-2 py-1 rounded-lg bg-orange-50 hover:bg-orange-600 hover:text-white text-orange-900 border border-orange-200 text-[11px] font-bold cursor-pointer">-%15</button>
                                <button type="button" onclick="addEtrModalCondRow()" class="px-2.5 py-1 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-300 text-xs font-extrabold cursor-pointer">+ MF Baremi Ekle</button>
                            </div>
                        </div>
                        <div id="etrMdlCondRows" class="space-y-1.5"></div>
                    </div>

                    <!-- Tarih, Not ve Kaydet -->
                    <div class="bg-white p-4 rounded-2xl border border-slate-200 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                        <div class="sm:col-span-3">
                            <div class="flex items-center justify-between mb-1">
                                <label class="text-[11px] font-extrabold text-slate-700">Miad <span id="etrMdlMiadStar" class="text-rose-500">*</span></label>
                                <div class="flex gap-1">
                                    <button type="button" onclick="setEtrModalMiadMonths(6)" class="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-orange-100 text-[9.5px] font-bold text-slate-600 cursor-pointer">+6A</button>
                                    <button type="button" onclick="setEtrModalMiadMonths(12)" class="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-orange-100 text-[9.5px] font-bold text-slate-600 cursor-pointer">+12A</button>
                                    <button type="button" onclick="setEtrModalMiadMonths(24)" class="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-orange-100 text-[9.5px] font-bold text-slate-600 cursor-pointer">+24A</button>
                                </div>
                            </div>
                            <input type="date" id="etrMdlMiad" value="${defMiad}" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold" />
                        </div>
                        <div class="sm:col-span-2">
                            <label class="text-[11px] font-extrabold text-slate-700 block mb-1">Teklif Bitiş *</label>
                            <input type="date" id="etrMdlEndDt" value="${defEnd}" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold" />
                        </div>
                        <div class="sm:col-span-4">
                            <label class="text-[11px] font-extrabold text-slate-700 block mb-1">Açıklama (Maks. 100 krk)</label>
                            <input type="text" id="etrMdlInfo" maxlength="100" placeholder="Örn: Raf fazlası takas, uzun miadlı..." class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs" />
                        </div>
                        <div class="sm:col-span-3 flex gap-2">
                            <button type="button" id="etrMdlDraftBtn" onclick="submitEtrModalCreate(true)" class="px-3 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-extrabold cursor-pointer">Taslak</button>
                            <button type="button" id="etrMdlSaveBtn" onclick="submitEtrModalCreate(false)" class="flex-1 px-4 py-2.5 rounded-xl bg-gradient-to-r from-orange-600 to-purple-600 hover:from-orange-700 hover:to-purple-700 text-white text-xs font-black shadow-sm cursor-pointer">Yayınla</button>
                        </div>
                    </div>

                    <div id="etrMdlCreateFeedback" class="hidden rounded-2xl px-4 py-3 text-xs font-bold border"></div>
                `;
                box.dataset.rendered = '1';
            }

            setEtrModalCreateMode(st.mode || '2');
            renderEtrModalCondRows();

            // Grup ve eczane önbelleğini yükle
            if (!st.groups.length || forceBootstrap) {
                try {
                    const r = await fetch(`/api/eczatrend/campaign/prepare?force_bootstrap=${forceBootstrap ? 'true' : 'false'}`);
                    const j = await r.json();
                    if (j && j.success) {
                        st.groups = j.groups || [];
                        st.selectedGroupKey = j.selected_group_key || '';
                        st.pharmacies = j.pharmacies || [];
                        st.canCreateOffer = Boolean(j.can_create_offer !== false);
                        st.preflightWarning = j.preflight_warning || '';
                        const grpInfo = document.getElementById('etrModalActiveGroupInfo');
                        if (grpInfo && j.selected_group_name) {
                            grpInfo.innerHTML = `<i class="fa-solid fa-users text-purple-600 mr-1"></i>Aktif Grup: <strong class="text-purple-900">${j.selected_group_name}</strong>`;
                        }
                    }
                } catch (e) {}
            }

            const gSel = document.getElementById('etrMdlGroupSelect');
            if (gSel) {
                gSel.innerHTML = st.groups.length
                    ? st.groups.map(g => `<option value="${g.id}" ${g.id === st.selectedGroupKey ? 'selected' : ''}>${g.name}</option>`).join('')
                    : '<option value="0">Varsayılan Grup</option>';
            }
            renderEtrModalPharmOptions('');
            _renderEtrModalPreflightWarn();
        }

        function _renderEtrModalPreflightWarn() {
            const st = window.etrModalCreateState;
            const warnEl = document.getElementById('etrMdlPreflightWarn');
            if (!warnEl) return;
            const msgs = [];
            if (!st.canCreateOffer && st.preflightWarning) {
                msgs.push(`<span class="text-rose-800"><i class="fa-solid fa-circle-exclamation text-rose-600 mr-1.5"></i><strong>Eczatrend Sistem / Grup Uyarısı:</strong> ${st.preflightWarning}</span>`);
            }
            if (st.hasActiveGroupOffer && st.activeOfferWarning) {
                msgs.push(`<span class="text-amber-900"><i class="fa-solid fa-bell text-amber-600 mr-1.5"></i><strong>Grupta Açık Teklif Var:</strong> ${st.activeOfferWarning}</span>`);
            }
            if (msgs.length) {
                warnEl.innerHTML = msgs.join('<div class="my-1 border-t border-amber-200"></div>');
                warnEl.classList.remove('hidden');
            } else {
                warnEl.classList.add('hidden');
                warnEl.innerHTML = '';
            }
        }

        function _renderEtrModalRefPills() {
            const box = document.getElementById('etrMdlRefPills');
            if (!box) return;
            const st = window.etrModalCreateState;
            const pills = [];
            if (st.portalMarketPrice > 0) {
                pills.push(`<button type="button" onclick="document.getElementById('etrMdlMarketPrice').value='${st.portalMarketPrice.toFixed(2)}'; recalcEtrModalNet();" class="px-2 py-0.5 rounded-lg bg-orange-50 hover:bg-orange-100 text-orange-900 border border-orange-200 font-bold cursor-pointer">Portal Depo: ${st.portalMarketPrice.toFixed(2)} ₺</button>`);
            }
            if (st.unitCost > 0) {
                pills.push(`<button type="button" onclick="document.getElementById('etrMdlTargetNet').value='${st.unitCost.toFixed(2)}'; applyEtrModalTargetNet('${st.unitCost.toFixed(2)}');" class="px-2 py-0.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 font-bold cursor-pointer" title="Son birim alış maliyetinizi hedef net olarak uygula">Son Alışım: ${st.unitCost.toFixed(2)} ₺</button>`);
            }
            if (st.recPrice > 0) {
                pills.push(`<button type="button" onclick="document.getElementById('etrMdlTargetNet').value='${st.recPrice.toFixed(2)}'; applyEtrModalTargetNet('${st.recPrice.toFixed(2)}');" class="px-2 py-0.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold cursor-pointer" title="Önerilen takas fiyatını hedef net olarak uygula">Önerilen Takas: ${st.recPrice.toFixed(2)} ₺</button>`);
            }
            box.innerHTML = pills.length
                ? `<span class="text-slate-400 font-bold">Referanslar:</span> ` + pills.join('')
                : '';
        }

        async function onEtrModalGroupChange(gid) {
            const groupId = String(gid || '').trim();
            if (!groupId || groupId === '0') return;
            const st = window.etrModalCreateState;
            st.selectedGroupKey = groupId;
            try {
                const res = await fetch('/api/eczatrend/campaign/switch-group', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ group_id: groupId })
                });
                const j = await res.json();
                if (j && j.success) {
                    st.canCreateOffer = Boolean(j.can_create_offer !== false);
                    st.preflightWarning = j.preflight_warning || '';
                    if (Array.isArray(j.pharmacies)) {
                        st.pharmacies = j.pharmacies;
                        renderEtrModalPharmOptions('');
                    }
                    const grpInfo = document.getElementById('etrModalActiveGroupInfo');
                    if (grpInfo && j.selected_group_name) {
                        grpInfo.innerHTML = `<i class="fa-solid fa-users text-purple-600 mr-1"></i>Aktif Grup: <strong class="text-purple-900">${j.selected_group_name}</strong>`;
                    }
                    _renderEtrModalPreflightWarn();
                    if (typeof showToast === 'function') showToast('Grup Değiştirildi', `Aktif grup: ${j.selected_group_name || 'Güncellendi'}`, 'success');
                }
            } catch (e) {}
        }

        function syncEtrModalTargetMinMax(changedField = 'target') {
            const tEl = document.getElementById('etrMdlTarget');
            const minEl = document.getElementById('etrMdlMin');
            const maxEl = document.getElementById('etrMdlMax');
            if (!tEl || !minEl || !maxEl) return;
            const t = Math.max(1, parseInt(tEl.value, 10) || 1);
            let minV = Math.max(1, parseInt(minEl.value, 10) || 1);
            let maxV = Math.max(1, parseInt(maxEl.value, 10) || t);
            if (changedField === 'target') {
                maxV = t;
                if (minV > maxV) minV = maxV;
                maxEl.value = String(maxV);
                minEl.value = String(minV);
            } else if (changedField === 'min') {
                if (minV > t) minV = t;
                if (minV > maxV) maxV = minV;
                minEl.value = String(minV);
                maxEl.value = String(maxV);
            } else if (changedField === 'max') {
                if (maxV > t) maxV = t;
                if (maxV < minV) minV = maxV;
                maxEl.value = String(maxV);
                minEl.value = String(minV);
            }
            recalcEtrModalNet();
        }

        function setEtrModalAllOrSingle(allAtOnce = true) {
            const t = Math.max(1, parseInt((document.getElementById('etrMdlTarget') || {}).value, 10) || 1);
            const minEl = document.getElementById('etrMdlMin');
            const maxEl = document.getElementById('etrMdlMax');
            if (minEl) minEl.value = String(allAtOnce ? t : 1);
            if (maxEl) maxEl.value = String(t);
        }

        function setEtrModalMiadMonths(m) {
            const el = document.getElementById('etrMdlMiad');
            if (el && typeof _formatIsoDatePlusMonths === 'function') el.value = _formatIsoDatePlusMonths(m);
        }

        function applyEtrModalQuickIsk(pct) {
            const st = window.etrModalCreateState;
            if (!st.conditions.length) st.conditions = [{ amount: 1, extra: 0, depoiskonto: 0, depoiskontoTL: 0, conditionPK: '' }];
            st.conditions[0].depoiskonto = Math.max(0, Math.min(99, parseFloat(pct) || 0));
            const el = document.getElementById('etrMdlCondIsk_0');
            if (el) el.value = String(st.conditions[0].depoiskonto);
            const tn = document.getElementById('etrMdlTargetNet');
            if (tn) tn.value = '';
            recalcEtrModalNet();
        }

        function resetEtrModalCreateToNew() {
            const st = window.etrModalCreateState;
            st.editOfferPk = '';
            st.editOriginalStatus = '';
            st.conditions = [{ amount: 1, extra: 0, depoiskonto: 0, depoiskontoTL: 0, conditionPK: '' }];
            const banner = document.getElementById('etrMdlEditBanner');
            if (banner) banner.classList.add('hidden');
            const lbl = document.getElementById('etrTabBtnCreateLabel');
            if (lbl) lbl.innerText = '➕ Yeni Takas / Kampanya Aç';
            const saveBtn = document.getElementById('etrMdlSaveBtn');
            if (saveBtn) saveBtn.innerText = 'Yayınla';
            const tn = document.getElementById('etrMdlTargetNet');
            if (tn) tn.value = '';
            renderEtrModalCondRows();
        }

        function setEtrModalCreateMode(m) {
            const st = window.etrModalCreateState;
            st.mode = ['0', '1', '2'].includes(String(m)) ? String(m) : '2';
            const b2 = document.getElementById('etrMdlMode2');
            const b0 = document.getElementById('etrMdlMode0');
            const b1 = document.getElementById('etrMdlMode1');
            if (b2) b2.className = st.mode === '2' ? 'px-3.5 py-2 rounded-xl text-xs font-extrabold bg-orange-600 text-white cursor-pointer' : 'px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-orange-50 cursor-pointer';
            if (b0) b0.className = st.mode === '0' ? 'px-3.5 py-2 rounded-xl text-xs font-extrabold bg-purple-600 text-white cursor-pointer' : 'px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-purple-50 cursor-pointer';
            if (b1) b1.className = st.mode === '1' ? 'px-3.5 py-2 rounded-xl text-xs font-extrabold bg-indigo-600 text-white cursor-pointer' : 'px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-indigo-50 cursor-pointer';
            const star = document.getElementById('etrMdlMiadStar');
            if (star) star.classList.toggle('hidden', st.mode !== '2');
            const extraRow = document.getElementById('etrMdlDepoExtraRow');
            if (extraRow) extraRow.classList.toggle('hidden', st.mode === '2');
            const tgtLbl = document.getElementById('etrMdlTargetLabel');
            if (tgtLbl) tgtLbl.innerText = st.mode === '2' ? 'Takas Adedi *' : 'Hedeflenen Alım *';
        }

        function onEtrModalSpecTypeChange() {
            const v = (document.getElementById('etrMdlSpecType') || {}).value || '0';
            const row = document.getElementById('etrMdlSpecPharmRow');
            const gSel = document.getElementById('etrMdlGroupSelect');
            if (row) row.classList.toggle('hidden', v !== '1');
            if (gSel) gSel.classList.toggle('hidden', v !== '0');
        }

        function renderEtrModalPharmOptions(q) {
            const sel = document.getElementById('etrMdlPharmSelect');
            if (!sel) return;
            const clean = String(q || '').trim().toLowerCase();
            const list = (window.etrModalCreateState.pharmacies || []).filter(p => !clean || (p.name || '').toLowerCase().includes(clean));
            sel.innerHTML = ['<option value="">-- Hedef Eczaneyi Seçiniz --</option>'].concat(
                list.map(p => `<option value="${p.id}">${p.name}</option>`)
            ).join('');
        }

        function debouncedEtrModalCatalogSearch(val) {
            if (_etrMdlSearchTimer) clearTimeout(_etrMdlSearchTimer);
            if (String(val || '').trim().length < 3) return;
            _etrMdlSearchTimer = setTimeout(() => searchEtrModalCatalog(val), 300);
        }

        async function searchEtrModalCatalog(q, bcHint = '', nameHint = '') {
            const clean = String(q || '').trim();
            if (clean.length < 3 && !bcHint) return;
            const sel = document.getElementById('etrMdlProdSelect');
            if (sel) sel.innerHTML = '<option value="">Eczatrend kataloğu aranıyor...</option>';
            try {
                const url = bcHint
                    ? `/api/eczatrend/campaign/prepare?barcode=${encodeURIComponent(bcHint)}&name=${encodeURIComponent(nameHint || '')}`
                    : `/api/eczatrend/campaign/prepare?q=${encodeURIComponent(clean)}`;
                const r = await fetch(url);
                const j = await r.json();
                const st = window.etrModalCreateState;
                if (j && j.success === false && j.message) {
                    if (sel) sel.innerHTML = `<option value="">${j.message}</option>`;
                    return;
                }
                st.candidates = j.candidates || [];
                st.hasActiveGroupOffer = Boolean(j.has_active_group_offer);
                st.activeOfferWarning = j.active_offer_warning || '';
                if (!st.candidates.length) {
                    if (sel) sel.innerHTML = `<option value="">"${clean}" için Eczatrend'de ürün bulunamadı</option>`;
                    _renderEtrModalPreflightWarn();
                    return;
                }
                if (sel) {
                    sel.innerHTML = st.candidates.map((c, idx) =>
                        `<option value="${c.product_pk}" ${(j.product_pk ? c.product_pk === j.product_pk : idx === 0) ? 'selected' : ''}>${c.full_label || c.name}</option>`
                    ).join('');
                }
                await onEtrModalProdSelectChange(true);
            } catch (e) {
                if (sel) sel.innerHTML = `<option value="">Arama hatası: ${e.message}</option>`;
            }
        }

        async function onEtrModalProdSelectChange(skipInsights = false) {
            const sel = document.getElementById('etrMdlProdSelect');
            if (!sel) return;
            const pk = sel.value;
            const st = window.etrModalCreateState;
            const fb = document.getElementById('etrMdlCreateFeedback');
            if (fb) { fb.classList.add('hidden'); fb.innerHTML = ''; }
            const c = (st.candidates || []).find(x => x.product_pk === pk);
            if (c) {
                st.productPk = c.product_pk;
                st.productName = c.name;
                st.barcode = c.barcode;
                st.vat = c.vat || 10;
                st.portalMarketPrice = Number(c.market_price || 0);
                const mEl = document.getElementById('etrMdlMarketPrice');
                const pEl = document.getElementById('etrMdlProductPrice');
                if (mEl) {
                    if (c.market_price > 0) mEl.value = Number(c.market_price).toFixed(2);
                    else if (st.hintPsf > 0) mEl.value = (st.hintPsf / 1.25).toFixed(2);
                }
                if (pEl) {
                    if (c.retail_price > 0) pEl.value = Number(c.retail_price).toFixed(2);
                    else if (st.hintPsf > 0) pEl.value = Number(st.hintPsf).toFixed(2);
                }
                _renderEtrModalRefPills();
                recalcEtrModalNet();

                if (!skipInsights && pk && pk.length === 32) {
                    try {
                        const ir = await fetch(`/api/eczatrend/campaign/product-insights?product_pk=${encodeURIComponent(pk)}&group_key=${encodeURIComponent(st.selectedGroupKey || '')}`);
                        if (ir.ok) {
                            const ins = await ir.json();
                            st.hasActiveGroupOffer = Boolean(ins.has_active_group_offer);
                            st.activeOfferWarning = ins.active_offer_warning || '';
                        }
                    } catch (e) {}
                }
                _renderEtrModalPreflightWarn();
            }
        }

        function renderEtrModalCondRows() {
            const box = document.getElementById('etrMdlCondRows');
            if (!box) return;
            const st = window.etrModalCreateState;
            if (!st.conditions.length) st.conditions = [{ amount: 1, extra: 0, depoiskonto: 0, depoiskontoTL: 0, conditionPK: '' }];
            st.conditions[0].amount = 1;
            st.conditions[0].extra = 0;
            box.innerHTML = st.conditions.map((c, idx) => {
                const base = idx === 0;
                return `
                    <div class="grid grid-cols-12 gap-2 items-center p-2 rounded-xl border ${base ? 'bg-slate-50 border-slate-200' : 'bg-orange-50/40 border-orange-200'} text-xs">
                        <div class="col-span-3 sm:col-span-2 flex items-center gap-1">
                            <span class="font-bold text-slate-400">${idx + 1}.</span>
                            <input type="number" value="${c.amount}" min="1" ${base ? 'disabled' : ''} oninput="window.etrModalCreateState.conditions[${idx}].amount=Math.max(1,parseInt(this.value)||1); recalcEtrModalNet();" class="w-full border border-slate-300 rounded-lg px-2 py-1 text-center font-black ${base ? 'bg-slate-200/70' : 'bg-white'}" />
                        </div>
                        <div class="col-span-3 sm:col-span-2 flex items-center gap-1">
                            <span class="font-black text-orange-600">+</span>
                            <input type="number" value="${c.extra}" min="0" ${base ? 'disabled' : ''} oninput="window.etrModalCreateState.conditions[${idx}].extra=Math.max(0,parseInt(this.value)||0); recalcEtrModalNet();" class="w-full border border-slate-300 rounded-lg px-2 py-1 text-center font-black ${base ? 'bg-slate-200/70' : 'bg-amber-50'}" />
                        </div>
                        <div class="col-span-3 sm:col-span-3 flex items-center gap-1">
                            <span class="text-[10px] font-bold text-slate-500">İsk%</span>
                            <input type="number" id="etrMdlCondIsk_${idx}" value="${c.depoiskonto}" min="0" max="99" step="0.1" oninput="window.etrModalCreateState.conditions[${idx}].depoiskonto=Math.max(0,parseFloat(this.value)||0); recalcEtrModalNet();" class="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 text-center font-black" />
                        </div>
                        <div class="hidden sm:flex sm:col-span-2 items-center gap-1">
                            <span class="text-[10px] font-bold text-slate-500">TL</span>
                            <input type="number" value="${c.depoiskontoTL || 0}" min="0" oninput="window.etrModalCreateState.conditions[${idx}].depoiskontoTL=Math.max(0,parseFloat(this.value)||0); recalcEtrModalNet();" class="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 text-center font-bold" />
                        </div>
                        <div class="col-span-3 sm:col-span-3 flex items-center justify-end gap-2">
                            <span id="etrMdlCondNet_${idx}" class="font-mono font-black text-emerald-700">0.00 ₺</span>
                            ${base ? '<i class="fa-solid fa-lock text-slate-400 text-[10px]"></i>' : `<button type="button" onclick="window.etrModalCreateState.conditions.splice(${idx},1); renderEtrModalCondRows();" class="text-rose-600 hover:text-rose-800 cursor-pointer"><i class="fa-solid fa-trash-can"></i></button>`}
                        </div>
                    </div>
                `;
            }).join('');
            recalcEtrModalNet();
        }

        function addEtrModalCondRow() {
            const st = window.etrModalCreateState;
            if (st.conditions.length >= 8) return;
            st.conditions.push({ amount: 10, extra: 1, depoiskonto: 0, depoiskontoTL: 0, conditionPK: '' });
            renderEtrModalCondRows();
        }

        function applyEtrModalTargetNet(val) {
            const net = parseFloat(val) || 0;
            const mkt = parseFloat((document.getElementById('etrMdlMarketPrice') || {}).value) || 0;
            if (net <= 0 || mkt <= 0 || net >= mkt) return;
            const isk = Number((((mkt - net) / mkt) * 100.0).toFixed(3));
            window.etrModalCreateState.conditions[0].depoiskonto = isk;
            const el = document.getElementById('etrMdlCondIsk_0');
            if (el) el.value = isk;
            recalcEtrModalNet();
        }

        function recalcEtrModalNet() {
            const st = window.etrModalCreateState;
            const mkt = parseFloat((document.getElementById('etrMdlMarketPrice') || {}).value) || 0;
            const tgt = Math.max(1, parseInt((document.getElementById('etrMdlTarget') || {}).value) || 1);
            let best = mkt > 0 ? mkt : 0;
            (st.conditions || []).forEach((c, idx) => {
                const a = Math.max(1, parseInt(c.amount) || 1);
                const b = Math.max(0, parseInt(c.extra) || 0);
                const isk = Math.max(0, parseFloat(c.depoiskonto) || 0);
                const tl = Math.max(0, parseFloat(c.depoiskontoTL) || 0);
                const baseU = mkt > 0 ? ((mkt * a) / (a + b)) : 0;
                const net = Math.max(0, baseU - (baseU * isk / 100.0) - (tl / tgt));
                if (idx === 0 || (net > 0 && net < best)) best = net;
                const nEl = document.getElementById(`etrMdlCondNet_${idx}`);
                if (nEl) nEl.innerText = `${net.toFixed(2)} ₺`;
            });
            const kdvMult = 1.0 + ((st.vat || 10) / 100.0);
            const bEl = document.getElementById('etrMdlBestNet');
            const kEl = document.getElementById('etrMdlBestKdvsiz');
            if (bEl) bEl.innerText = `${best.toFixed(2)} ₺`;
            if (kEl) kEl.innerText = `KDV H: ${(best / kdvMult).toFixed(2)} ₺`;
        }

        async function submitEtrModalCreate(asDraft = false) {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Eczatrend Takas / Kampanya Açma')) return;
            const st = window.etrModalCreateState;
            const fb = document.getElementById('etrMdlCreateFeedback');
            const showFb = (msg, ok) => {
                if (!fb) return;
                fb.classList.remove('hidden');
                fb.className = ok
                    ? 'rounded-2xl px-4 py-3 text-xs font-bold border bg-emerald-50 border-emerald-300 text-emerald-900 flex flex-wrap items-center justify-between gap-2'
                    : 'rounded-2xl px-4 py-3 text-xs font-bold border bg-rose-50 border-rose-300 text-rose-800';
                fb.innerHTML = msg;
            };

            const pk = String((document.getElementById('etrMdlProdSelect') || {}).value || st.productPk || '').trim();
            if (pk.length !== 32) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Lütfen önce barkod/isim aratarak geçerli bir Eczatrend ürünü seçin.', false);
                return;
            }
            const target = parseInt((document.getElementById('etrMdlTarget') || {}).value, 10) || 0;
            const minV = parseInt((document.getElementById('etrMdlMin') || {}).value, 10) || 1;
            const maxV = parseInt((document.getElementById('etrMdlMax') || {}).value, 10) || target;
            const mkt = parseFloat((document.getElementById('etrMdlMarketPrice') || {}).value) || 0;
            const psf = parseFloat((document.getElementById('etrMdlProductPrice') || {}).value) || 0;
            const miad = String((document.getElementById('etrMdlMiad') || {}).value || '').trim();
            const endDt = String((document.getElementById('etrMdlEndDt') || {}).value || '').trim();
            const specType = String((document.getElementById('etrMdlSpecType') || {}).value || '0');
            const specPharm = String((document.getElementById('etrMdlPharmSelect') || {}).value || '').trim();
            const grpId = String((document.getElementById('etrMdlGroupSelect') || {}).value || st.selectedGroupKey || '').trim();
            const info = String((document.getElementById('etrMdlInfo') || {}).value || '').trim();
            const acceptRec = st.mode === '2' ? '1' : String((document.getElementById('etrMdlAcceptRecord') || {}).value || '2');
            const multStr = st.mode === '2' ? '' : String((document.getElementById('etrMdlMultiplier') || {}).value || '').trim();
            const selfPurch = st.mode === '2' ? 0 : (parseInt((document.getElementById('etrMdlSelfPurchase') || {}).value, 10) || 0);

            if (target < 1) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Hedeflenen / satılacak kutu adedi en az 1 olmalıdır.', false);
                return;
            }
            if (minV < 1 || minV > maxV || maxV > target) {
                showFb(`<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Adet sınırları hatalı: Min (${minV}) ≤ Maks (${maxV}) ≤ Hedef (${target}) olmalıdır.`, false);
                return;
            }
            if (mkt <= 0) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Geçerli bir Depo Fiyatı (KDV Dahil) girilmelidir.', false);
                return;
            }
            if (st.mode === '2' && !miad) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Raf Stoğumdan Takas modunda Miad Tarihi girilmesi zorunludur!', false);
                return;
            }
            if (!endDt) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Lütfen Teklif Bitiş Tarihini seçin.', false);
                return;
            }
            if (specType === '1' && specPharm.length !== 32) {
                showFb('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Birebir Eczaneye Özel Takas seçildiğinde listeden hedef eczaneyi seçmelisiniz.', false);
                return;
            }
            if (st.mode !== '2') {
                const maxCondTot = Math.max(1, ...(st.conditions || []).map(c => (parseInt(c.amount, 10) || 1) + (parseInt(c.extra, 10) || 0)));
                if (maxCondTot > target) {
                    showFb(`<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Depo kampanyasında en yüksek barem toplamı (${maxCondTot} kt), hedef adetten (${target} kt) büyük olamaz.`, false);
                    return;
                }
            }

            recalcEtrModalNet();
            const bestNetTxt = (document.getElementById('etrMdlBestNet') || {}).innerText || '';
            const modeLbl = st.mode === '2' ? '📦 Raf Stoğumdan Takas' : (st.mode === '0' ? '🏷️ Depodan Genel Kampanya' : '✨ Deponun Bana Özel Teklifi');
            const dupNotice = st.hasActiveGroupOffer ? `\\n⚠️ DİKKAT: Grubunuzda bu ürün için açık teklif bulunmaktadır!\\n` : '';
            const confirmMsg = `Eczatrend üzerinde aşağıdaki teklifi ${asDraft ? 'TASLAK OLARAK KAYDETMEK' : (st.editOfferPk ? 'GÜNCELLEMEK' : 'YAYINA ALMAK')} istediğinize emin misiniz?\\n${dupNotice}\\n`
                + `• Tür: ${modeLbl}\\n`
                + `• Ürün: ${st.productName || 'Seçili Ürün'}\\n`
                + `• Adet: ${target} Kutu (Min: ${minV} / Maks: ${maxV})\\n`
                + `• En İyi Net Fiyat: ${bestNetTxt} (KDV Dahil)`
                + (miad ? `\\n• Miad: ${miad}` : '');
            if (!window.confirm(confirmMsg)) return;

            const btn = document.getElementById(asDraft ? 'etrMdlDraftBtn' : 'etrMdlSaveBtn');
            const orig = btn ? btn.innerHTML : '';
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i>Kaydediliyor...'; }
            try {
                const payload = {
                    offer_pk: st.editOfferPk || '',
                    publish_draft: Boolean(st.editOfferPk && st.editOriginalStatus === 'Taslak' && !asDraft),
                    product_pk: pk,
                    urun_adi: st.productName || 'Ürün',
                    offer_publish_status: st.mode,
                    market_price: mkt,
                    product_price: psf > 0 ? psf : Number((mkt * 1.25).toFixed(2)),
                    vat: st.vat || 10,
                    offertarget: target,
                    min: minV,
                    max: maxV,
                    accept_record: acceptRec,
                    purchase_multiplier: multStr,
                    self_purchase: selfPurch,
                    expire_dt: miad,
                    end_dt: endDt,
                    specific_pharmacy_type: specType,
                    specific_pharmacy_fk: specPharm,
                    group_id: grpId,
                    information: info,
                    as_draft: Boolean(asDraft),
                    conditions: st.conditions
                };
                const res = await fetch('/api/eczatrend/campaign/save', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const data = await res.json();
                if (data.success) {
                    showFb(
                        `<span>✅ ${data.message} (${data.mf} • Net: ${Number(data.net_price || 0).toFixed(2)} ₺)</span>`
                        + `<button type="button" onclick="switchEczatrendModalTab('my_offers'); loadEtrMyOffersList(true);" class="px-3 py-1 rounded-lg bg-indigo-600 text-white font-extrabold cursor-pointer">Tekliflerime Git →</button>`,
                        true
                    );
                    showToast('Başarılı', data.message, 'success');
                } else {
                    showFb(`⚠️ ${data.message || 'Teklif kaydedilemedi.'}`, false);
                }
            } catch (e) {
                showFb(`Bağlantı hatası: ${e.message}`, false);
            } finally {
                if (btn) { btn.disabled = false; btn.innerHTML = orig; }
            }
        }

        // ============================================================
        // SEKME 3: AÇTIĞIM ECZATREND TEKLİFLERİM & YÖNETİM PANELİ
        // ============================================================
        async function loadEtrMyOffersList(force = false) {
            const box = document.getElementById('etrModalMyOffersBody');
            if (!box) return;

            if (!box.dataset.toolbarReady) {
                box.innerHTML = `
                    <div class="bg-white p-3.5 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
                        <div class="flex flex-wrap items-center gap-2">
                            <select id="etrMyStatusFilter" onchange="loadEtrMyOffersList(true)" class="bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl px-3 py-2">
                                <option value="0">Durum: Tümü</option>
                                <option value="1">🟢 Aktif (Yayında)</option>
                                <option value="6">🎯 Hedefe Ulaşıldı</option>
                                <option value="4">📝 Taslak</option>
                                <option value="2">⏸️ Pasif</option>
                                <option value="3">🔒 Kapandı / Onaylandı</option>
                            </select>
                            <select id="etrMyTypeFilter" onchange="loadEtrMyOffersList(true)" class="bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl px-3 py-2">
                                <option value="9">Tür: Tümü</option>
                                <option value="2">📦 Raf Stoğumdan Takas</option>
                                <option value="0">🏷️ Depodan Genel Kampanya</option>
                                <option value="1">✨ Deponun Bana Özel Teklifi</option>
                            </select>
                            <input type="text" id="etrMyQueryInput" onkeydown="if(event.key==='Enter') loadEtrMyOffersList(true)" placeholder="Ürün adı ara..." class="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold" />
                            <button type="button" onclick="loadEtrMyOffersList(true)" class="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold cursor-pointer">Filtrele</button>
                        </div>
                        <button type="button" onclick="resetEtrModalCreateToNew(); switchEczatrendModalTab('create');" class="px-3.5 py-2 rounded-xl bg-gradient-to-r from-orange-600 to-purple-600 text-white text-xs font-extrabold cursor-pointer">
                            + Yeni Takas / Kampanya Aç
                        </button>
                    </div>
                    <div id="etrMyOffersTableWrap" class="bg-white rounded-2xl border border-slate-200 overflow-hidden"></div>
                `;
                box.dataset.toolbarReady = '1';
            }

            const wrap = document.getElementById('etrMyOffersTableWrap');
            if (!wrap) return;
            wrap.innerHTML = '<div class="p-8 text-center text-indigo-700 font-bold text-xs"><i class="fa-solid fa-spinner fa-spin text-xl mb-2 block"></i>Açtığınız Eczatrend teklifleri yükleniyor...</div>';

            try {
                const stVal = (document.getElementById('etrMyStatusFilter') || {}).value || '0';
                const tpVal = (document.getElementById('etrMyTypeFilter') || {}).value || '9';
                const qVal = String((document.getElementById('etrMyQueryInput') || {}).value || '').trim();
                const res = await fetch(`/api/eczatrend/my-offers?status=${encodeURIComponent(stVal)}&publish_type=${encodeURIComponent(tpVal)}&q=${encodeURIComponent(qVal)}&rows=50`);
                const data = await res.json();
                if (!data.success) {
                    wrap.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-xs">${data.message || 'Teklifleriniz alınamadı.'}</div>`;
                    return;
                }
                window.etrModalMyOffersCache = data.offers || [];
                renderEtrMyOffersTable();
            } catch (e) {
                wrap.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-xs">Bağlantı hatası: ${e.message}</div>`;
            }
        }

        function renderEtrMyOffersTable() {
            const wrap = document.getElementById('etrMyOffersTableWrap');
            if (!wrap) return;
            const list = window.etrModalMyOffersCache || [];
            if (!list.length) {
                wrap.innerHTML = '<div class="p-10 text-center text-slate-400 text-xs font-bold">Seçili filtrede açtığınız Eczatrend takas veya kampanya teklifi bulunamadı.</div>';
                return;
            }
            wrap.innerHTML = `
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-slate-100 text-slate-600 font-extrabold uppercase text-[10px] border-b border-slate-200">
                            <tr>
                                <th class="py-2.5 px-3">Ürün & Grup</th>
                                <th class="py-2.5 px-2.5 text-center">Tür</th>
                                <th class="py-2.5 px-2.5 text-center">Barem / MF</th>
                                <th class="py-2.5 px-2.5 text-right">Depo / Net Fiyat</th>
                                <th class="py-2.5 px-2.5 text-center">Alınan / Hedef</th>
                                <th class="py-2.5 px-2.5 text-center">Durum</th>
                                <th class="py-2.5 px-2.5 text-center">Bitiş / Miad</th>
                                <th class="py-2.5 px-3 text-right">Yönetim İşlemleri</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            ${list.map((o, idx) => {
                                const st = String(o.status || '');
                                const stLow = st.toLowerCase();
                                const isAct = stLow.includes('aktif') || stLow === 'teklif' || stLow.includes('yayın');
                                const isDraft = stLow.includes('taslak');
                                const isPas = stLow.includes('pasif');
                                const isTakas = o.publish_status_fk === '2' || (o.publish_status_label || '').toLowerCase().includes('stoğum');
                                const stCls = isAct ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                    : (isDraft ? 'bg-amber-100 text-amber-900 border-amber-300'
                                    : (isPas ? 'bg-slate-200 text-slate-700 border-slate-300' : 'bg-indigo-100 text-indigo-900 border-indigo-300'));
                                return `
                                    <tr class="hover:bg-slate-50/80 transition">
                                        <td class="py-2.5 px-3">
                                            <div class="font-extrabold text-slate-900">${o.product_name}</div>
                                            <div class="text-[10px] text-slate-500 font-mono">${o.barcode || '-'} • ${o.group_name || ''}</div>
                                            ${o.information ? `<div class="text-[10px] text-orange-700 italic mt-0.5">"${o.information}"</div>` : ''}
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center">
                                            <span class="px-2 py-0.5 rounded-lg text-[10px] font-extrabold ${isTakas ? 'bg-orange-100 text-orange-900 border border-orange-200' : 'bg-purple-100 text-purple-900 border border-purple-200'}">${isTakas ? '📦 Stoktan Takas' : o.publish_status_label}</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center font-mono font-black text-purple-900">${o.mf || '1+0'}</td>
                                        <td class="py-2.5 px-2.5 text-right font-mono">
                                            <div class="text-[10px] text-slate-400 line-through">${Number(o.market_price || 0).toFixed(2)} ₺</div>
                                            <div class="font-black text-emerald-700">${Number(o.net_price || 0).toFixed(2)} ₺</div>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center font-mono font-bold">
                                            <span class="px-2 py-0.5 rounded bg-sky-50 text-sky-900 border border-sky-200">${o.purchased} / ${o.target} Kt</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center">
                                            <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${stCls}">${st || '-'}</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center font-mono text-[10.5px] text-slate-600">
                                            <div>Son: ${o.end_dt || '-'}</div>
                                            ${o.expire_dt ? `<div class="text-[10px] text-amber-800">Miad: ${o.expire_dt}</div>` : ''}
                                        </td>
                                        <td class="py-2.5 px-3 text-right">
                                            <div class="flex flex-wrap items-center justify-end gap-1">
                                                <button type="button" onclick="toggleEtrOfferBuyers('${o.offer_pk}')" class="px-2 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-200 font-bold text-[11px] cursor-pointer" title="Alım yapan eczaneleri gör">👥 Alımlar (${o.purchased})</button>
                                                <button type="button" onclick="editEtrMyOffer(${idx})" class="px-2 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 font-bold text-[11px] cursor-pointer" title="Teklif şartlarını düzenle">✏️ Düzenle</button>
                                                ${isAct ? `<button type="button" onclick="changeEtrMyOfferStatus('${o.offer_pk}', 'passive')" class="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 font-bold text-[11px] cursor-pointer">⏸️ Pasif</button>` : ''}
                                                ${(isDraft || isPas) ? `<button type="button" onclick="changeEtrMyOfferStatus('${o.offer_pk}', 'active')" class="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] cursor-pointer">▶️ Yayınla</button>` : ''}
                                                ${(isAct || st.includes('Hedef')) ? `<button type="button" onclick="changeEtrMyOfferStatus('${o.offer_pk}', 'close')" class="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-bold text-[11px] cursor-pointer" title="Teklifi kapat / onayla">✅ Kapat/Onayla</button>` : ''}
                                            </div>
                                        </td>
                                    </tr>
                                    <tr id="etrBuyersRow_${o.offer_pk}" class="hidden bg-sky-50/40">
                                        <td colspan="8" class="p-3" id="etrBuyersCell_${o.offer_pk}"></td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        }

        async function toggleEtrOfferBuyers(offerPk) {
            const row = document.getElementById(`etrBuyersRow_${offerPk}`);
            const cell = document.getElementById(`etrBuyersCell_${offerPk}`);
            if (!row || !cell) return;
            if (!row.classList.contains('hidden')) {
                row.classList.add('hidden');
                return;
            }
            row.classList.remove('hidden');
            cell.innerHTML = '<div class="text-xs text-sky-800 font-bold"><i class="fa-solid fa-spinner fa-spin mr-1.5"></i>Alım yapan eczaneler getiriliyor...</div>';
            try {
                const r = await fetch(`/api/eczatrend/offer-detail?offer_pk=${encodeURIComponent(offerPk)}`);
                const d = await r.json();
                const buyers = d.buyers || [];
                if (!buyers.length) {
                    cell.innerHTML = '<div class="text-xs text-slate-500 font-semibold">Bu teklife henüz alım yapan eczane bulunmuyor.</div>';
                    return;
                }
                cell.innerHTML = `
                    <div class="bg-white rounded-xl border border-sky-200 p-2.5">
                        <div class="text-[11px] font-extrabold text-sky-950 mb-1.5">👥 Alım Yapan Eczaneler (${buyers.length} Kayıt)</div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                            ${buyers.map(b => `
                                <div class="p-2 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                                    <div>
                                        <div class="font-extrabold text-slate-900">${b.pharmacy || 'Eczane'}</div>
                                        <div class="text-[10px] text-slate-500">${b.city || ''} ${b.created_at ? '• ' + b.created_at : ''}</div>
                                    </div>
                                    <span class="px-2 py-0.5 rounded bg-emerald-600 text-white font-mono font-black">${b.amount} Kutu</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
            } catch (e) {
                cell.innerHTML = `<div class="text-xs text-rose-600">Hata: ${e.message}</div>`;
            }
        }

        async function editEtrMyOffer(idx) {
            const o = (window.etrModalMyOffersCache || [])[idx];
            if (!o) return;
            if (String(o.status || '') === 'Onaylandı') {
                showToast('Bilgi', 'Onaylanmış / tamamlanmış teklifler üzerinde düzenleme yapılamaz.', 'info');
                return;
            }
            await switchEczatrendModalTab('create');

            const st = window.etrModalCreateState;
            st.editOfferPk = o.offer_pk;
            st.editOriginalStatus = o.status || '';
            st.productPk = o.product_pk;
            st.productName = o.product_name;
            st.barcode = o.barcode;
            st.vat = o.vat || 10;
            setEtrModalCreateMode(o.publish_status_fk || '2');

            const banner = document.getElementById('etrMdlEditBanner');
            const titleEl = document.getElementById('etrMdlEditTitle');
            const saveBtn = document.getElementById('etrMdlSaveBtn');
            if (banner) banner.classList.remove('hidden');
            if (titleEl) titleEl.innerText = `${o.product_name} (${o.status})`;
            if (saveBtn) saveBtn.innerText = (o.status === 'Taslak') ? 'Taslağı Yayınla' : 'Değişiklikleri Kaydet';

            const sel = document.getElementById('etrMdlProdSelect');
            if (sel && o.product_pk) {
                st.candidates = [{ product_pk: o.product_pk, name: o.product_name, full_label: `${o.product_name} (${o.barcode || ''})`, barcode: o.barcode, vat: o.vat || 10, market_price: o.market_price, retail_price: o.product_price }];
                sel.innerHTML = `<option value="${o.product_pk}" selected>${o.product_name}</option>`;
            }
            const mmNums = String(o.min_max || '').match(/\\d+/g) || [];
            if (document.getElementById('etrMdlTarget')) document.getElementById('etrMdlTarget').value = o.target || 10;
            if (document.getElementById('etrMdlMin')) document.getElementById('etrMdlMin').value = parseInt(mmNums[0], 10) || 1;
            if (document.getElementById('etrMdlMax')) document.getElementById('etrMdlMax').value = parseInt(mmNums[1], 10) || o.target || 10;
            if (document.getElementById('etrMdlMarketPrice')) document.getElementById('etrMdlMarketPrice').value = Number(o.market_price || 0).toFixed(2);
            if (document.getElementById('etrMdlProductPrice')) document.getElementById('etrMdlProductPrice').value = Number(o.product_price || 0).toFixed(2);
            if (document.getElementById('etrMdlInfo')) document.getElementById('etrMdlInfo').value = o.information || '';

            const toIso = (s) => {
                const p = String(s || '').split(' ')[0].replace(/\\./g, '-').split('-');
                if (p.length === 3 && p[2].length === 4) return `${p[2]}-${p[1].padStart(2, '0')}-${p[0].padStart(2, '0')}`;
                return '';
            };
            if (o.expire_dt && document.getElementById('etrMdlMiad')) document.getElementById('etrMdlMiad').value = toIso(o.expire_dt);
            if (o.end_dt && document.getElementById('etrMdlEndDt')) document.getElementById('etrMdlEndDt').value = toIso(o.end_dt);

            try {
                const r = await fetch(`/api/eczatrend/offer-detail?offer_pk=${encodeURIComponent(o.offer_pk)}`);
                const det = await r.json();
                if (det.success && Array.isArray(det.conditions) && det.conditions.length) {
                    st.conditions = det.conditions;
                }
            } catch (e) {}
            renderEtrModalCondRows();
        }

        async function changeEtrMyOfferStatus(offerPk, op) {
            const labels = {
                passive: 'Bu teklifi PASİFE çekmek istediğinize emin misiniz?',
                active: 'Bu teklifi YAYINA ALMAK istediğinize emin misiniz?',
                close: 'Bu teklifi KAPATIP ONAYLAMAK istediğinize emin misiniz?'
            };
            if (!window.confirm(labels[op] || 'İşlemi onaylıyor musunuz?')) return;
            try {
                const r = await fetch('/api/eczatrend/offer-status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ offer_pk: offerPk, operation: op, approve_and_send: false })
                });
                const j = await r.json();
                if (j.success) {
                    showToast('İşlem Tamamlandı', j.message || 'Teklif durumu güncellendi.', 'success');
                    await loadEtrMyOffersList(true);
                } else {
                    showToast('Uyarı', j.message || 'İşlem gerçekleştirilemedi.', 'error');
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        function compareFromEczatrendOffer(barcode, name) {
            closeEczatrendOffersModal();
            compareFromEczaneTakasOffer(barcode, name);
        }

        function renderEczatrendOffersModal() {
            const body = document.getElementById('etrModalBody');
            const badge = document.getElementById('etrModalCountBadge');
            const inp = document.getElementById('etrModalSearchInput');
            if (!body) return;
            const q = inp ? inp.value.trim().toLowerCase() : '';
            const all = window.eczatrendActiveOffersCache || [];
            const filtered = all.filter(o => {
                if (!q) return true;
                return (o.urun_adi || '').toLowerCase().includes(q)
                    || (o.barcode || '').toLowerCase().includes(q)
                    || (o.satici || '').toLowerCase().includes(q)
                    || (o.groupName || '').toLowerCase().includes(q);
            });
            // Bugün katılınan teklifleri en üstte göster
            filtered.sort((a, b) => {
                const aOrd = window.findTodayOrderMatchForOffer(a, 'ECZATREND');
                const bOrd = window.findTodayOrderMatchForOffer(b, 'ECZATREND');
                const aJ = (aOrd && aOrd.isThisOfferJoined) ? 1 : 0;
                const bJ = (bOrd && bOrd.isThisOfferJoined) ? 1 : 0;
                return bJ - aJ;
            });
            if (badge) badge.innerText = `${filtered.length} Teklif`;
            if (filtered.length === 0) {
                body.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs font-bold">Aramanıza uygun açık ortak alım teklifi bulunamadı. Dilerseniz "Portalda Ara" butonuna basarak tüm Eczatrend sayfalarında arayabilirsiniz.</div>`;
                return;
            }
            const joinedOffers = all.filter(o => {
                const m = window.findTodayOrderMatchForOffer(o, 'ECZATREND');
                return m && m.isThisOfferJoined;
            });
            const joinedBannerHtml = joinedOffers.length > 0 ? `
                <div class="mb-3 p-3 rounded-2xl bg-emerald-50 border-2 border-emerald-400 shadow-xs">
                    <div class="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                        <div class="flex items-center space-x-2 text-emerald-900 font-black text-xs">
                            <i class="fa-solid fa-circle-check text-emerald-600 text-sm"></i>
                            <span>BUGÜN ECZATREND'DEN KATILDIĞINIZ / SİPARİŞ VERDİĞİNİZ TEKLİFLER (${joinedOffers.length} Kalem)</span>
                        </div>
                        <span class="text-[10px] font-bold text-emerald-700">Sayfadan çıkıp tekrar girseniz de katıldığınız ürünler burada sabit kalır</span>
                    </div>
                    <div class="flex flex-wrap gap-1.5">
                        ${joinedOffers.map(jo => {
                            const jm = window.findTodayOrderMatchForOffer(jo, 'ECZATREND') || {};
                            const qty = jm.siparis_miktar || jo.katilinan_miktar || 1;
                            const tm = jm.siparis_saat || jo.siparis_saat || '';
                            return `<span class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-white border border-emerald-300 text-emerald-950 text-[11px] font-extrabold shadow-2xs">
                                <i class="fa-solid fa-check text-emerald-600 text-[10px]"></i>
                                <span>${jo.urun_adi}</span>
                                <span class="px-1.5 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-black">${qty} Kutu</span>
                                ${tm ? `<span class="text-[10px] text-slate-500 font-mono">${tm}</span>` : ''}
                            </span>`;
                        }).join('')}
                    </div>
                </div>
            ` : '';
            const otoLabel = window.eczatrendActiveOtomasyonName || 'Eczane';
            body.innerHTML = `
                ${joinedBannerHtml}
                <div class="overflow-x-auto rounded-2xl border border-slate-200">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-slate-100 text-slate-600 font-extrabold uppercase text-[10px] border-b border-slate-200">
                            <tr>
                                <th class="py-2.5 px-3">Ürün Adı & Barkod</th>
                                <th class="py-2.5 px-2.5 text-center bg-emerald-50/70 text-emerald-900 border-x border-emerald-100" title="${otoLabel} Anlık Raf Stoğu">Anlık Stok</th>
                                <th class="py-2.5 px-2.5 text-center bg-blue-50/70 text-blue-900 border-r border-blue-100" title="${otoLabel} Son 1 Aylık (30 Gün) Toplam Çıkış">1 Aylık Çıkış</th>
                                <th class="py-2.5 px-2.5 text-center bg-violet-50/70 text-violet-900 border-r border-violet-100" title="${otoLabel} Son 3 Aylık (90 Gün) Toplam Çıkış">3 Aylık Çıkış</th>
                                <th class="py-2.5 px-3">Grup & Teklif Veren Eczane</th>
                                <th class="py-2.5 px-2.5 text-center">Barem / MF</th>
                                <th class="py-2.5 px-2.5 text-center">Hedef / Kalan</th>
                                <th class="py-2.5 px-2.5 text-right">Depo Fiyatı</th>
                                <th class="py-2.5 px-2.5 text-right">Net (KDV Hariç)</th>
                                <th class="py-2.5 px-2.5 text-right">Net (KDV Dahil)</th>
                                <th class="py-2.5 px-2.5 text-center">Bitiş</th>
                                <th class="py-2.5 px-3 text-right">Hızlı Katıl & İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            ${filtered.map(o => {
                                const safeName = (o.urun_adi || '').replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
                                const safeBc = (o.barcode || '').replace(/'/g, "\\\\'");
                                const eczStok = parseInt(o.eczane_stok ?? 0, 10) || 0;
                                const cikis1A = parseInt(o.cikis_1ay ?? 0, 10) || 0;
                                const cikis3A = parseInt(o.cikis_3ay ?? 0, 10) || 0;
                                const minAlim = Math.max(1, parseInt(o.min_alim ?? 1, 10) || 1);
                                const alimKati = Math.max(1, parseInt(o.alim_kati ?? 1, 10) || 1);
                                const mevcutAlim = Math.max(0, parseInt(o.mevcut_alim ?? 0, 10) || 0);
                                const maxKalan = Math.max(minAlim, parseInt(o.max_katilim ?? o.kalan ?? 1, 10) || 1);
                                const isPaid = Boolean(o.is_paid_offer);
                                const ordMatch = window.findTodayOrderMatchForOffer(o, 'ECZATREND');
                                const isJoined = Boolean((ordMatch && ordMatch.isThisOfferJoined) || mevcutAlim > 0);
                                const isOtherOrdered = Boolean(ordMatch && !isJoined && ordMatch.siparis_durumu);
                                const joinedQty = mevcutAlim > 0 ? mevcutAlim : (ordMatch ? (ordMatch.siparis_miktar || 1) : 0);
                                const ordSaat = ordMatch ? (ordMatch.siparis_saat || '') : '';
                                const ordMasa = ordMatch ? (ordMatch.siparis_masa || '') : '';
                                const ordDepo = ordMatch ? (ordMatch.siparis_depo || 'DEPO') : '';
                                const dKey = `ETR_${o.offer_id}`;
                                const initQty = window.getOfferJoinInitialQty(dKey, minAlim, maxKalan, alimKati, joinedQty);
                                const ruleTags = [];
                                if (minAlim > 1 || (o.max_alim && o.max_alim > 0 && o.max_alim < 999)) {
                                    ruleTags.push(`Min:${minAlim}${o.max_alim ? '/Maks:' + o.max_alim : ''}`);
                                }
                                if (alimKati > 1) ruleTags.push(`${alimKati}'er kat`);
                                if (o.hedef_gecilebilir) ruleTags.push('Hedef geçilebilir');
                                const rowClass = isJoined
                                    ? 'bg-emerald-50/80 hover:bg-emerald-100/70 border-l-4 border-l-emerald-600 transition'
                                    : (isOtherOrdered ? 'bg-amber-50/60 hover:bg-amber-100/50 border-l-4 border-l-amber-500 transition' : 'hover:bg-purple-50/40 transition');
                                const orderBadgeHtml = isJoined
                                    ? `<div class="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-black shadow-2xs">
                                           <i class="fa-solid fa-circle-check"></i>
                                           <span>ALIMINIZ: ${joinedQty} KUTU${ordSaat ? ' (' + ordSaat + (ordMasa ? ' • ' + ordMasa : '') + ')' : ''}</span>
                                       </div>`
                                    : (isOtherOrdered
                                        ? `<div class="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500 text-white text-[10px] font-black shadow-2xs">
                                               <i class="fa-solid fa-triangle-exclamation"></i>
                                               <span>BUGÜN ${ordMatch.siparis_durumu === 'SEPETTE' ? 'SEPETTE' : 'SİPARİŞ VERİLDİ'}: ${ordDepo} (${joinedQty} KUTU${ordSaat ? ' • ' + ordSaat : ''})</span>
                                           </div>`
                                        : '');
                                const stokClass = eczStok <= 0
                                    ? 'bg-rose-100 text-rose-800 border-rose-200'
                                    : (eczStok <= 2 ? 'bg-amber-100 text-amber-900 border-amber-200' : 'bg-emerald-100 text-emerald-900 border-emerald-200');
                                const c1Class = cikis1A > 0
                                    ? 'bg-blue-100 text-blue-900 border-blue-200'
                                    : 'bg-slate-100 text-slate-500 border-slate-200';
                                const c3Class = cikis3A > 0
                                    ? 'bg-violet-100 text-violet-900 border-violet-200'
                                    : 'bg-slate-100 text-slate-500 border-slate-200';
                                return `
                                    <tr class="${rowClass}">
                                        <td class="py-2.5 px-3">
                                            <div class="font-extrabold text-slate-900 flex flex-wrap items-center gap-1">
                                                <span>${o.urun_adi}</span>
                                                ${isPaid ? '<span class="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 text-[9.5px] font-black">💳 Ödemeli</span>' : ''}
                                            </div>
                                            <div class="text-[10px] font-mono text-slate-400">${o.barcode || '-'} • #${(o.offer_id || '').slice(0, 8)}${o.miad ? ' • Miad: ' + o.miad : ''}</div>
                                            ${o.aciklama ? `<div class="text-[10px] text-purple-800 italic mt-0.5">${o.aciklama}</div>` : ''}
                                            ${orderBadgeHtml}
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center bg-emerald-50/25 border-x border-slate-100">
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-lg font-black text-[11px] border ${stokClass}">${eczStok} Kt</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center bg-blue-50/20 border-r border-slate-100">
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-lg font-black text-[11px] border ${c1Class}">${cikis1A} Ad</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center bg-violet-50/20 border-r border-slate-100">
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-lg font-black text-[11px] border ${c3Class}">${cikis3A} Ad</span>
                                        </td>
                                        <td class="py-2.5 px-3 font-bold text-slate-700">
                                            <div><i class="fa-solid fa-hospital text-purple-600 mr-1 text-[10px]"></i>${o.satici || '-'}</div>
                                            <div class="text-[10px] text-purple-700 font-semibold">${o.groupName || ''}</div>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center">
                                            <span class="px-2 py-0.5 rounded font-black bg-purple-50 text-purple-900 border border-purple-200 font-mono">${o.mf || 'BAREM'}</span>
                                        </td>
                                        <td class="py-2.5 px-2.5 text-center">
                                            <span id="etrKalanStok_${o.offer_id}" class="px-2 py-0.5 rounded-lg font-black bg-amber-100 text-amber-900 border border-amber-200">Kalan: ${o.kalan}</span>
                                            <div class="text-[10px] text-slate-500 mt-0.5">Hedef: ${o.hedef} (${o.doluluk})</div>
                                            ${ruleTags.length ? `<div class="text-[9.5px] font-bold text-orange-800 mt-0.5">${ruleTags.join(' • ')}</div>` : ''}
                                        </td>
                                        <td class="py-2.5 px-2.5 text-right font-mono text-slate-500">${Number(o.depo_fiyati || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-2.5 text-right font-mono font-bold text-slate-700">${Number(o.fiyat_kdvsiz || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-2.5 text-right font-mono font-extrabold text-emerald-700">${Number(o.fiyat_kdvli || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-2.5 text-center font-mono text-[11px] text-slate-600">${o.kalan_sure || '-'}</td>
                                        <td class="py-2.5 px-3 text-right">
                                            <div class="flex items-center justify-end space-x-1" data-join-group="1">
                                                <div class="inline-flex items-center rounded-lg border border-slate-300 bg-white overflow-hidden" data-qty-stepper="1">
                                                    <button type="button" onclick="stepOfferJoinQty(this, -1, ${maxKalan}, ${minAlim}, ${alimKati})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">-</button>
                                                    <input type="number" data-offer-qty-key="${dKey}" value="${initQty}" min="${minAlim}" max="${maxKalan}" step="${alimKati}" oninput="onOfferQtyInputChange(this, '${dKey}', ${minAlim}, ${maxKalan}, ${alimKati}, false)" onchange="onOfferQtyInputChange(this, '${dKey}', ${minAlim}, ${maxKalan}, ${alimKati}, true)" class="w-11 text-center text-[11px] font-black text-slate-800 focus:outline-none py-0.5" />
                                                    <button type="button" onclick="stepOfferJoinQty(this, 1, ${maxKalan}, ${minAlim}, ${alimKati})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">+</button>
                                                </div>
                                                ${isJoined ? `
                                                    <button type="button" onclick="joinEczatrendOfferDirect('${o.offer_id}', '${safeBc}', '${safeName}', ${maxKalan}, this, ${minAlim}, ${alimKati}, ${joinedQty}, ${isPaid ? 'true' : 'false'})" class="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[11px] cursor-pointer transition flex items-center space-x-1 shadow-xs" title="Mevcut alımınız ${joinedQty} kutu. Yeni toplam adedi yazıp tıklayarak güncelleyebilirsiniz.">
                                                        <i class="fa-solid fa-circle-check text-[10px]"></i>
                                                        <span>Güncelle (${joinedQty} Kt)</span>
                                                    </button>
                                                    <button type="button" onclick="cancelEczatrendJoinDirect('${o.offer_id}', '${safeBc}', '${safeName}', this)" class="px-1.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 font-bold text-[10px] cursor-pointer transition" title="Bu teklifteki Eczatrend katılımınızı iptal et">
                                                        İptal
                                                    </button>
                                                ` : `
                                                    <button type="button" onclick="joinEczatrendOfferDirect('${o.offer_id}', '${safeBc}', '${safeName}', ${maxKalan}, this, ${minAlim}, ${alimKati}, 0, ${isPaid ? 'true' : 'false'})" class="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-black text-[11px] cursor-pointer transition flex items-center space-x-1 shadow-xs" title="Şifre girmeden doğrudan bu ortak alıma katıl">
                                                        <i class="fa-solid fa-bolt text-[10px] text-amber-200"></i>
                                                        <span>${isPaid ? 'Portalda Al' : 'Katıl'}</span>
                                                    </button>
                                                `}
                                                <button type="button" onclick="compareFromEczatrendOffer('${safeBc}', '${safeName}')" class="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] cursor-pointer transition" title="Tüm depolarla karşılaştır">
                                                    Kıyasla
                                                </button>
                                                <button type="button" onclick="openEtrModalCreateForProduct('${safeBc}', '${safeName}', { sellQty: ${Math.max(1, eczStok || 10)} })" class="px-2 py-1 rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-800 border border-purple-200 font-bold text-[11px] cursor-pointer transition" title="Bu ürün için sen de Eczatrend takas / kampanya aç">
                                                    Takas Aç
                                                </button>
                                                <button type="button" onclick="openAuthenticatedPortal('ECZATREND', 'https://eczatrend.com/eczanet/panelNew/main.html')" class="px-1.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-[10px] cursor-pointer transition" title="Hazır oturumla tarayıcıda aç">
                                                    ↗
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        }

        // =========================================================================
        // GÜN SONU DEPO SİPARİŞ ÖZETİ & VERİLMEYECEKLERDEN YOK LİSTESİ SİSTEMİ (v1.4.1)
        // =========================================================================
        window.currentEndOfDayData = null;
        window.activeEndOfDayTab = 'summary';

        async function openEndOfDaySummaryModal(initialTab = 'summary') {
            const modal = document.getElementById('endOfDaySummaryModal');
            if (!modal) return;
            modal.classList.remove('hidden');
            switchEndOfDayTab(initialTab || 'summary');
            await loadEndOfDaySummary();
        }

        function closeEndOfDaySummaryModal() {
            const modal = document.getElementById('endOfDaySummaryModal');
            if (modal) modal.classList.add('hidden');
        }

        function switchEndOfDayTab(tab) {
            window.activeEndOfDayTab = tab || 'summary';
            const tabs = ['summary', 'skipped', 'yok', 'savings'];
            tabs.forEach(t => {
                const btn = document.getElementById('eodTabBtn' + t.charAt(0).toUpperCase() + t.slice(1));
                const content = document.getElementById('eodTabContent' + t.charAt(0).toUpperCase() + t.slice(1));
                if (btn) {
                    if (t === window.activeEndOfDayTab) {
                        btn.className = 'py-2 px-3 border-b-2 border-emerald-600 text-emerald-800 font-extrabold text-[11px] flex items-center space-x-1.5 cursor-pointer';
                    } else {
                        btn.className = 'py-2 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 font-bold text-[11px] flex items-center space-x-1.5 cursor-pointer';
                    }
                }
                if (content) {
                    if (t === window.activeEndOfDayTab) content.classList.remove('hidden');
                    else content.classList.add('hidden');
                }
            });
            if (window.activeEndOfDayTab === 'savings') {
                loadEndOfDaySavingsSummary();
            }
        }

        async function loadEndOfDaySavingsSummary(days = 30) {
            const box = document.getElementById('eodTabContentSavings');
            if (!box) return;
            box.innerHTML = `<div class="p-8 text-center text-emerald-700 font-bold text-xs"><i class="fa-solid fa-spinner fa-spin text-xl mb-2 block"></i>Farma Radar tasarruf özeti hesaplanıyor...</div>`;
            try {
                const res = await fetch(`/api/orders/savings-summary?days=${encodeURIComponent(days)}`);
                const d = await res.json();
                if (!d || !d.success) {
                    box.innerHTML = `<div class="p-6 text-center text-rose-600 font-bold text-xs">${(d && d.error) || 'Tasarruf özeti alınamadı.'}</div>`;
                    return;
                }
                const fmtTl = (v) => Number(v || 0).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ₺';
                const td = d.today || {};
                const wk = d.week || {};
                const mo = d.month_summary || {};
                const all = d.all_time || {};
                const byDepo = Array.isArray(d.by_depo) ? d.by_depo : [];
                const topItems = Array.isArray(d.top_items) ? d.top_items : [];
                const trend = Array.isArray(d.daily_trend) ? d.daily_trend : [];
                const maxDaySave = Math.max(1, ...trend.map(x => Number(x.savings || 0)));

                const trendBarsHtml = trend.map(day => {
                    const sv = Number(day.savings || 0);
                    const pctH = sv > 0 ? Math.max(8, Math.round((sv / maxDaySave) * 100)) : 4;
                    return `
                        <div class="flex-1 flex flex-col items-center justify-end gap-1 h-24" title="${day.label}: ${fmtTl(sv)} (${day.orders} işlem)">
                            <div class="w-full rounded-t-md ${sv > 0 ? 'bg-gradient-to-t from-emerald-600 to-teal-400' : 'bg-slate-200'}" style="height:${pctH}%;"></div>
                            <span class="text-[9px] font-mono text-slate-500">${day.label}</span>
                        </div>
                    `;
                }).join('');

                const depoRowsHtml = byDepo.length > 0 ? byDepo.map(dp => `
                    <tr class="border-b border-slate-100 text-[11px]">
                        <td class="py-1.5 px-2.5 font-extrabold text-slate-900">${dp.depo}</td>
                        <td class="py-1.5 px-2 text-center font-mono text-slate-600">${dp.orders} kalem / ${dp.boxes} kt</td>
                        <td class="py-1.5 px-2.5 text-right font-mono text-slate-700">${fmtTl(dp.spend)}</td>
                        <td class="py-1.5 px-2.5 text-right font-mono font-black text-emerald-700">+${fmtTl(dp.savings)}</td>
                    </tr>
                `).join('') : `<tr><td colspan="4" class="py-5 text-center text-slate-400 text-xs">Henüz fiyat karşılaştırmalı sipariş kaydı oluşmadı. Depo Sorgu'dan sepete ekledikçe ve ortak alımlara katıldıkça tasarrufunuz otomatik birikir.</td></tr>`;

                const topHtml = topItems.length > 0 ? topItems.slice(0, 8).map((it, i) => `
                    <div class="flex items-center justify-between gap-2 py-1.5 border-b border-slate-100 last:border-0 text-[11px]">
                        <div class="min-w-0">
                            <span class="font-bold text-slate-800">${i + 1}. ${it.urun_adi}</span>
                            <span class="text-[10px] text-slate-400 ml-1">${it.depo} • ${it.miktar} Kt • ${it.tarih}</span>
                        </div>
                        <div class="text-right shrink-0 font-mono">
                            <span class="text-[10px] text-slate-400 line-through mr-1">${Number(it.referans_birim || 0).toFixed(2)}₺</span>
                            <span class="text-[10.5px] font-bold text-slate-700 mr-1.5">${Number(it.secilen_birim || 0).toFixed(2)}₺</span>
                            <span class="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-black">+${fmtTl(it.tasarruf_toplam)}</span>
                        </div>
                    </div>
                `).join('') : `<div class="py-4 text-center text-slate-400 text-xs">Son 30 günde tasarruf sağlayan işlem kaydı henüz yok.</div>`;

                box.innerHTML = `
                    <!-- 4 Dönem KPI Kartı -->
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        <div class="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-2xl p-3.5 shadow-sm">
                            <div class="text-[10px] font-bold uppercase text-emerald-100">Bugünkü Tasarruf</div>
                            <div class="text-lg font-black font-mono mt-0.5">${fmtTl(td.savings_total)}</div>
                            <div class="text-[10px] text-emerald-100/90 mt-0.5">${td.order_count || 0} işlem • ${td.boxes_total || 0} kt ${td.savings_pct > 0 ? '(ort. %' + td.savings_pct + ')' : ''}</div>
                        </div>
                        <div class="bg-white rounded-2xl p-3.5 border border-emerald-200 shadow-2xs">
                            <div class="text-[10px] font-extrabold uppercase text-slate-500">Son 7 Gün</div>
                            <div class="text-lg font-black font-mono text-emerald-700 mt-0.5">${fmtTl(wk.savings_total)}</div>
                            <div class="text-[10px] text-slate-500 mt-0.5">${wk.order_count || 0} işlem • ${wk.boxes_total || 0} kutu</div>
                        </div>
                        <div class="bg-white rounded-2xl p-3.5 border border-indigo-200 shadow-2xs">
                            <div class="text-[10px] font-extrabold uppercase text-indigo-600">Bu Ay Net Tasarruf</div>
                            <div class="text-lg font-black font-mono text-indigo-800 mt-0.5">${fmtTl(mo.savings_total)}</div>
                            <div class="text-[10px] text-slate-500 mt-0.5">Depo: ${fmtTl(mo.depo_savings)} • Takas: ${fmtTl(mo.takas_savings)}</div>
                        </div>
                        <div class="bg-slate-900 text-white rounded-2xl p-3.5 shadow-sm">
                            <div class="text-[10px] font-bold uppercase text-amber-300">Toplam Kümülatif</div>
                            <div class="text-lg font-black font-mono text-amber-300 mt-0.5">${fmtTl(all.savings_total)}</div>
                            <div class="text-[10px] text-slate-300 mt-0.5">${all.order_count || 0} kayıtlı sipariş (${all.boxes_total || 0} kt)</div>
                        </div>
                    </div>

                    <!-- 14 Günlük Trend Grafiği -->
                    <div class="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-2xs">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-xs font-black text-slate-800"><i class="fa-solid fa-chart-column text-emerald-600 mr-1.5"></i>Son 14 Günlük Tasarruf Trendi (₺)</span>
                            <span class="text-[10px] text-slate-400">Standart depo referans fiyatına göre kazanılan net fark</span>
                        </div>
                        <div class="flex items-end gap-1.5 pt-2">${trendBarsHtml}</div>
                    </div>

                    <!-- Depo Kırılımı & En Çok Kazandıranlar -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
                            <div class="px-3.5 py-2 bg-slate-50 border-b border-slate-200 text-xs font-black text-slate-800">Depo &amp; Platform Bazlı Tasarruf (30 Gün)</div>
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="text-[10px] font-bold text-slate-400 uppercase border-b border-slate-100">
                                        <th class="py-1.5 px-2.5">Platform</th>
                                        <th class="py-1.5 px-2 text-center">Hacim</th>
                                        <th class="py-1.5 px-2.5 text-right">Alım</th>
                                        <th class="py-1.5 px-2.5 text-right">Tasarruf</th>
                                    </tr>
                                </thead>
                                <tbody>${depoRowsHtml}</tbody>
                            </table>
                        </div>
                        <div class="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-2xs">
                            <div class="text-xs font-black text-slate-800 mb-2">🏆 En Çok Tasarruf Sağlayan Alımlar</div>
                            <div>${topHtml}</div>
                        </div>
                    </div>
                `;
            } catch (e) {
                box.innerHTML = `<div class="p-6 text-center text-rose-600 font-bold text-xs">Bağlantı hatası: ${e.message}</div>`;
            }
        }

        async function loadEndOfDaySummary() {
            try {
                const res = await fetch('/api/orders/today/summary');
                if (!res.ok) return;
                const data = await res.json();
                if (!data.success) return;
                window.currentEndOfDayData = data;
                renderEndOfDaySummaryUI(data);
                renderPersistentYokWidgets(data);
            } catch (e) {
                console.warn('Gün sonu özeti yüklenemedi:', e);
            }
        }

        function togglePersistentYokBar(forceOpen = null) {
            const panel = document.getElementById('persistentYokTopPanel');
            if (!panel) return;
            const isHidden = panel.classList.contains('hidden');
            const shouldShow = (forceOpen === true) ? true : (forceOpen === false ? false : isHidden);
            if (shouldShow) {
                panel.classList.remove('hidden');
                window.persistentYokUserClosed = false;
                window.persistentYokUserOpened = true;
                if (!window.currentEndOfDayData) loadEndOfDaySummary();
            } else {
                panel.classList.add('hidden');
                window.persistentYokUserClosed = true;
                window.persistentYokUserOpened = false;
            }
        }
        window.togglePersistentYokBar = togglePersistentYokBar;

        async function addQuickItemToYokListFromBar() {
            const inp = document.getElementById('quickPinYokInput');
            const val = inp ? inp.value.trim() : '';
            if (!val) {
                showToast('Eksik Bilgi', 'Lütfen Yok Listesine eklemek istediğiniz ilacın adını veya barkodunu yazın.', 'info');
                if (inp) inp.focus();
                return;
            }
            const isBc = /^\d{8,14}$/.test(val);
            try {
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        items: [{
                            barkod: isBc ? val : '',
                            urun_adi: val,
                            kaynak: 'Sabit Yok Paneli'
                        }]
                    })
                });
                const data = await res.json();
                if (data.success) {
                    if (inp) inp.value = '';
                    window.persistentYokUserClosed = false;
                    showToast('📌 Sabit Yok Listesine Eklendi', `${val} Yok Listesine kaydedildi.`, 'success');
                    await loadEndOfDaySummary();
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message || 'Yok listesine eklenemedi.', 'error');
            }
        }
        window.addQuickItemToYokListFromBar = addQuickItemToYokListFromBar;

        function renderPersistentYokWidgets(data) {
            if (!data) return;
            const yokScan = data.yok_scan || {};
            const yokList = Array.isArray(yokScan.yok_items) ? yokScan.yok_items : [];
            const varList = Array.isArray(yokScan.var_items) ? yokScan.var_items : [];

            const hdrBadge = document.getElementById('headerYokCountBadge');
            if (hdrBadge) hdrBadge.innerText = String(yokList.length);

            const topPanel = document.getElementById('persistentYokTopPanel');
            const topBody = document.getElementById('persistentYokBody');
            const yokCountPill = document.getElementById('persistentYokCountPill');
            const varCountPill = document.getElementById('persistentVarCountPill');

            if (yokCountPill) yokCountPill.innerText = `${yokList.length} Kalem Yok`;
            if (varCountPill) {
                if (varList.length > 0) {
                    varCountPill.classList.remove('hidden');
                    varCountPill.innerText = `🎉 ${varList.length} Ürün Stoğa Girdi!`;
                } else {
                    varCountPill.classList.add('hidden');
                }
            }

            if (topPanel && topBody) {
                if ((yokList.length > 0 || varList.length > 0) && !window.persistentYokUserClosed) {
                    topPanel.classList.remove('hidden');
                } else if (yokList.length === 0 && varList.length === 0 && !window.persistentYokUserOpened) {
                    topPanel.classList.add('hidden');
                }
                let html = '';
                if (varList.length > 0) {
                    html += `
                        <div class="p-2 rounded-xl bg-emerald-50 border border-emerald-300 flex flex-wrap items-center justify-between gap-1.5">
                            <div class="flex flex-wrap items-center gap-1.5">
                                <span class="text-[10px] font-black text-emerald-800 mr-1"><i class="fa-solid fa-circle-check mr-1"></i>STOĞA GİRENLER:</span>
                                ${varList.map(v => {
                                    const sBc = (v.barkod || '').replace(/'/g, "\\'");
                                    const sNm = (v.urun_adi || '').replace(/'/g, "\\'");
                                    const bestDepo = v.en_uygun_depo || 'SELCUK';
                                    return `
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-white border border-emerald-300 text-[10px] font-extrabold text-emerald-950 shadow-2xs">
                                            <span>${v.urun_adi || v.barkod}</span>
                                            <span class="text-emerald-700 font-mono">(${bestDepo}${v.en_uygun_fiyat ? ' ' + v.en_uygun_fiyat.toFixed(0) + '₺' : ''})</span>
                                            <button type="button" onclick="quickOrderFromYokScan('${bestDepo}', '${sBc}', '${sNm}')" class="px-1.5 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-black cursor-pointer" title="En uygun depoya sepete at ve listeden düşür">🛒 Sepete At</button>
                                            <button type="button" onclick="removeFromTodayYokList('${sBc}', '${sNm}')" class="px-1.5 py-0.5 rounded bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white border border-rose-200 text-[9px] font-black cursor-pointer transition" title="Bu ürünü listeden çıkar">✕ Çıkar</button>
                                        </span>
                                    `;
                                }).join('')}
                            </div>
                            <button type="button" onclick="clearTodayYokList('var')" class="px-2 py-0.5 rounded-lg bg-white hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 text-[10px] font-extrabold cursor-pointer transition shrink-0" title="Stoğa girenler bildirim listesini tamamen temizle">
                                <i class="fa-solid fa-trash-can mr-1"></i>Stoğa Girenleri Temizle
                            </button>
                        </div>
                    `;
                }
                if (yokList.length > 0) {
                    html += `
                        <div class="flex flex-wrap items-center justify-between gap-1.5">
                            <div class="flex flex-wrap items-center gap-1.5">
                                ${yokList.map(it => {
                                    const sBc = (it.barkod || '').replace(/'/g, "\\'");
                                    const sNm = (it.urun_adi || '').replace(/'/g, "\\'");
                                    return `
                                        <div class="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-white border border-rose-200 hover:border-rose-400 text-[11px] font-bold text-slate-800 shadow-2xs">
                                            <span class="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0"></span>
                                            <span onclick="searchFromCritical('${sBc}', '${sNm}')" class="cursor-pointer hover:text-indigo-700 truncate max-w-[230px]" title="Tıklayın: Tüm depolarda ve muadillerde canlı sorgula">${it.urun_adi || it.barkod}</span>
                                            <button type="button" onclick="searchFromCritical('${sBc}', '${sNm}')" class="px-1 text-indigo-600 hover:text-indigo-800 text-[10px] cursor-pointer" title="Canlı Sorgula"><i class="fa-solid fa-magnifying-glass"></i></button>
                                            <button type="button" onclick="removeFromTodayYokList('${sBc}', '${sNm}')" class="px-1.5 py-0.5 rounded bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white text-[10px] font-black cursor-pointer transition" title="Yok listesinden manuel çıkar">✕</button>
                                        </div>
                                    `;
                                }).join('')}
                            </div>
                            <button type="button" onclick="clearTodayYokList('yok')" class="px-2 py-0.5 rounded-lg bg-white hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 text-[10px] font-extrabold cursor-pointer transition shrink-0" title="Yok listesindeki tüm ürünleri temizle">
                                <i class="fa-solid fa-trash-can mr-1"></i>Listeyi Temizle
                            </button>
                        </div>
                    `;
                } else if (varList.length === 0) {
                    html = `<div class="text-xs text-slate-500 font-semibold py-1">📌 Sabit Yok Listesi şu anda boş. Üstteki kutudan veya Günün Çıkışlarındaki 🚨 butonuyla bulunamayan ilaçları buraya sabitleyebilirsiniz.</div>`;
                }
                topBody.innerHTML = html;
            }

            // Günün Çıkışları çekmecesi içindeki Sabit Yok Listesi şeridi (Karışıklığı önlemek için gizli tutuldu)
            const drawerSec = document.getElementById('drawerPinnedYokSection');
            const drawerCnt = document.getElementById('drawerPinnedYokCount');
            const drawerPills = document.getElementById('drawerPinnedYokPills');
            if (drawerCnt) drawerCnt.innerText = String(yokList.length);
            if (drawerSec) {
                drawerSec.classList.add('hidden');
                drawerSec.style.display = 'none';
            }
            if (drawerPills) {
                drawerPills.innerHTML = '';
            }
        }
        window.renderPersistentYokWidgets = renderPersistentYokWidgets;

        function renderEndOfDaySummaryUI(data) {
            if (!data) return;
            const totals = data.totals || {};
            const dateBadge = document.getElementById('eodModalDateBadge');
            if (dateBadge) dateBadge.innerText = `${data.date || ''} • ${data.pc_name || 'Eczane PC'}`;

            const elOrdCnt = document.getElementById('eodKpiOrderedCount');
            const elOrdBox = document.getElementById('eodKpiOrderedBoxes');
            const elCartCnt = document.getElementById('eodKpiCartCount');
            const elCartBox = document.getElementById('eodKpiCartBoxes');
            const elSkipCnt = document.getElementById('eodKpiSkippedCount');
            const elYokCnt = document.getElementById('eodKpiYokCount');
            const elYokTime = document.getElementById('eodKpiYokScanTime');

            if (elOrdCnt) elOrdCnt.innerText = totals.ordered_count || 0;
            if (elOrdBox) elOrdBox.innerText = totals.ordered_boxes || 0;
            if (elCartCnt) elCartCnt.innerText = totals.cart_count || 0;
            if (elCartBox) elCartBox.innerText = totals.cart_boxes || 0;
            if (elSkipCnt) elSkipCnt.innerText = totals.skipped_count || 0;

            const yokScan = data.yok_scan || {};
            const yokList = Array.isArray(yokScan.yok_items) ? yokScan.yok_items : [];
            const varList = Array.isArray(yokScan.var_items) ? yokScan.var_items : [];
            if (elYokCnt) elYokCnt.innerText = yokList.length;
            if (elYokTime) {
                elYokTime.innerText = yokScan.last_scan_time
                    ? `Sorgu: ${yokScan.last_scan_time}`
                    : 'Depolarda Yok';
            }

            // 1. SEKME: DEPO BAZLI GÜN SONU SİPARİŞ ÖZETİ
            const sumContainer = document.getElementById('eodTabContentSummary');
            if (sumContainer) {
                const depots = Array.isArray(data.depots) ? data.depots : [];
                if (depots.length === 0) {
                    sumContainer.innerHTML = `
                        <div class="p-6 text-center bg-white rounded-xl border border-slate-200 text-slate-500 text-xs space-y-1.5">
                            <i class="fa-solid fa-box-open text-2xl text-slate-300 block"></i>
                            <div class="font-extrabold text-xs text-slate-700">Bugün Henüz Depo Siparişi veya Sepet Kaydı Yok</div>
                            <p class="text-[11px]">Gün içinde arama ekranından, günün çıkışlarından veya 6 aylık listeden verdiğiniz siparişler burada depo bazında özetlenir.</p>
                        </div>
                    `;
                } else {
                    sumContainer.innerHTML = depots.map(d => {
                        const rows = (d.items || []).map((it, idx) => {
                            const isOrd = it.durum === 'SIPARIS_VERILDI';
                            const sBc = (it.barkod || '').replace(/'/g, "\\\\'");
                            const sNm = (it.urun_adi || '').replace(/'/g, "\\\\'");
                            return `
                                <tr class="border-b border-slate-100 hover:bg-slate-50/80 text-[11px]">
                                    <td class="py-1.5 px-2.5 font-mono text-slate-400">${idx + 1}</td>
                                    <td class="py-1.5 px-2.5">
                                        <span class="font-extrabold text-slate-900">${it.urun_adi || '-'}</span>
                                        <span class="text-[10px] font-mono text-slate-400 ml-1.5">${it.barkod || ''}</span>
                                    </td>
                                    <td class="py-1.5 px-2.5 text-center">
                                        <span class="px-2 py-0.5 rounded-full font-black ${isOrd ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'} text-[10px]">
                                            ${isOrd ? '✓ VERİLDİ' : '🛒 SEPETTE'}
                                        </span>
                                    </td>
                                    <td class="py-1.5 px-2.5 text-center font-black text-slate-800">${it.miktar || 1} Kt</td>
                                    <td class="py-1.5 px-2.5 text-center text-[10px] text-slate-500">${it.masa_adi || '-'} • ${it.saat || '--:--'}</td>
                                    <td class="py-1.5 px-2.5 text-right">
                                        <button type="button" onclick="unmarkItemOrderStatus('${sBc}', '${sNm}', event); setTimeout(loadEndOfDaySummary, 350);" class="px-2 py-0.5 rounded bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 text-[10px] font-bold cursor-pointer" title="Kaydı geri al">
                                            İptal ×
                                        </button>
                                    </td>
                                </tr>
                            `;
                        }).join('');

                        return `
                            <div class="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
                                <div class="px-3.5 py-2 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-2">
                                    <div class="flex items-center space-x-2">
                                        <i class="fa-solid fa-truck-medical text-emerald-400 text-xs"></i>
                                        <span class="font-black text-xs">${d.depo} DEPOSU ÖZETİ</span>
                                    </div>
                                    <div class="flex items-center gap-1.5 text-[11px]">
                                        <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 font-extrabold">
                                            ✓ Verilen: ${d.ordered_count} Kalem (${d.ordered_boxes} Kt)
                                        </span>
                                        ${d.cart_count > 0 ? `
                                            <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 font-extrabold">
                                                🛒 Sepette: ${d.cart_count} Kalem (${d.cart_boxes} Kt)
                                            </span>
                                        ` : ''}
                                    </div>
                                </div>
                                <table class="w-full text-left border-collapse">
                                    <thead>
                                        <tr class="bg-slate-50 border-b border-slate-200 text-[10px] font-extrabold text-slate-500 uppercase">
                                            <th class="py-1.5 px-2.5 w-8">#</th>
                                            <th class="py-1.5 px-2.5">Ürün Adı & Barkod</th>
                                            <th class="py-1.5 px-2.5 text-center w-24">Durum</th>
                                            <th class="py-1.5 px-2.5 text-center w-16">Adet</th>
                                            <th class="py-1.5 px-2.5 text-center w-32">PC & Saat</th>
                                            <th class="py-1.5 px-2.5 text-right w-20">İşlem</th>
                                        </tr>
                                    </thead>
                                    <tbody>${rows}</tbody>
                                </table>
                            </div>
                        `;
                    }).join('');
                }
            }

            // 2. SEKME: SİPARİŞ VERİLMEYECEKLER
            const skipContainer = document.getElementById('eodTabContentSkipped');
            if (skipContainer) {
                const skipped = Array.isArray(data.skipped_items) ? data.skipped_items : [];

                if (skipped.length === 0) {
                    skipContainer.innerHTML = `
                        <div class="p-6 text-center bg-white rounded-xl border border-slate-200 text-slate-500 text-xs space-y-1.5">
                            <i class="fa-solid fa-ban text-2xl text-slate-300 block"></i>
                            <div class="font-extrabold text-xs text-slate-700">Bugün "Sipariş Verilmeyecek" Olarak İşaretlenen Ürün Yok</div>
                            <p class="text-[11px]">Günün çıkışlarında veya 6 aylık listede bugün sipariş etmeyeceğiniz ("🚫 Verilmeyecek") ilaçlar burada listelenir.</p>
                        </div>
                    `;
                } else {
                    const skipRows = skipped.map((it, idx) => {
                        const sBc = (it.barkod || '').replace(/'/g, "\\\\'");
                        const sNm = (it.urun_adi || '').replace(/'/g, "\\\\'");

                        return `
                            <tr class="border-b border-slate-100 hover:bg-slate-50 text-[11px]">
                                <td class="py-1.5 px-2.5 font-mono text-slate-400">${idx + 1}</td>
                                <td class="py-1.5 px-2.5">
                                    <div class="font-extrabold text-slate-900">${it.urun_adi || '-'}</div>
                                    <div class="text-[10px] font-mono text-slate-400">${it.barkod || 'Barkodsuz'} • ${it.masa_adi || ''} (${it.saat || ''})</div>
                                </td>
                                <td class="py-1.5 px-2.5 text-center">
                                    <span class="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 text-[10px] font-bold">🚫 Sipariş Verilmeyecek</span>
                                </td>
                                <td class="py-1.5 px-2.5 text-right">
                                    <div class="inline-flex items-center gap-1">
                                        <button type="button" onclick="closeEndOfDaySummaryModal(); searchFromCritical('${sBc}', '${sNm}');" class="px-2 py-0.5 rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-[10px] font-bold cursor-pointer">
                                            🔍 Kıyasla
                                        </button>
                                        <button type="button" onclick="unmarkItemOrderStatus('${sBc}', '${sNm}', event); setTimeout(loadEndOfDaySummary, 350);" class="px-2 py-0.5 rounded bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 text-[10px] font-bold cursor-pointer" title="Sipariş verilmeyecek işaretini kaldır">
                                            Kaldır ×
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('');

                    skipContainer.innerHTML = `
                        <div class="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="bg-slate-100 border-b border-slate-200 text-[10px] font-extrabold text-slate-500 uppercase">
                                        <th class="py-1.5 px-2.5 w-8">#</th>
                                        <th class="py-1.5 px-2.5">Ürün Adı & Barkod</th>
                                        <th class="py-1.5 px-2.5 text-center">Durum</th>
                                        <th class="py-1.5 px-2.5 text-right">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>${skipRows}</tbody>
                            </table>
                        </div>
                    `;
                }
            }

            // 3. SEKME: YOK LİSTESİ (HİÇBİR DEPODA BULUNAMAYAN ÜRÜNLER)
            const yokContainer = document.getElementById('eodTabContentYok');
            if (yokContainer) {
                const manualAddBarHtml = `
                    <div class="bg-white rounded-xl border border-rose-200 p-3 shadow-2xs flex flex-wrap items-center gap-2">
                        <div class="flex items-center space-x-1.5 text-rose-700 font-extrabold text-[11px] shrink-0">
                            <i class="fa-solid fa-plus-circle"></i>
                            <span>Manuel Yok Ekle:</span>
                        </div>
                        <input type="text" id="manualYokNameInput" onkeydown="if(event.key==='Enter') addManualItemToYokList()" placeholder="İlaç adı veya barkod yazın (Örn: PAROL 500 MG 20 TB veya 8699...)" class="flex-1 min-w-[220px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-rose-500 focus:outline-none" />
                        <input type="text" id="manualYokBarcodeInput" onkeydown="if(event.key==='Enter') addManualItemToYokList()" placeholder="Barkod (Opsiyonel)" class="w-36 px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-mono text-slate-700 focus:ring-2 focus:ring-rose-500 focus:outline-none" />
                        <button type="button" onclick="addManualItemToYokList()" class="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-[11px] shadow-2xs transition cursor-pointer shrink-0">
                            <i class="fa-solid fa-plus mr-1"></i>Yok Listesine Ekle
                        </button>
                    </div>
                `;

                const foundInStockHtml = varList.length > 0 ? `
                    <div class="bg-emerald-50/70 rounded-xl border border-emerald-300 overflow-hidden shadow-2xs">
                        <div class="px-3.5 py-2 bg-emerald-600 text-white flex flex-wrap items-center justify-between gap-2">
                            <span class="text-[11px] font-black"><i class="fa-solid fa-circle-check mr-1.5"></i>Yok Listesinden Stoğa Giren Ürünler (${varList.length} Kalem)</span>
                            <div class="flex items-center gap-2">
                                <span class="text-[10px] text-emerald-100 font-semibold">Tek tıkla sepete atabilir veya listeden çıkarabilirsiniz</span>
                                <button type="button" onclick="clearTodayYokList('var')" class="px-2 py-0.5 rounded bg-white/20 hover:bg-rose-600 text-white text-[10px] font-extrabold cursor-pointer transition">
                                    <i class="fa-solid fa-trash-can mr-1"></i>Tümünü Temizle
                                </button>
                            </div>
                        </div>
                        <div class="divide-y divide-emerald-200/70">
                            ${varList.map(v => {
                                const sBc = (v.barkod || '').replace(/'/g, "\\\\'");
                                const sNm = (v.urun_adi || '').replace(/'/g, "\\\\'");
                                const depBadges = (v.bulunan_depolar || []).map(bd =>
                                    `<span class="px-1.5 py-0.5 rounded bg-white text-emerald-800 border border-emerald-300 text-[10px] font-extrabold">${bd.depo}: ${bd.net_maliyet ? bd.net_maliyet.toFixed(2) + '₺' : 'VAR'} ${bd.mf && bd.mf !== 'YOK' ? '(' + bd.mf + ')' : ''}</span>`
                                ).join(' ');
                                return `
                                    <div class="px-3.5 py-2 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                                        <div>
                                            <span class="font-extrabold text-slate-900">${v.urun_adi || '-'}</span>
                                            <span class="text-[10px] font-mono text-slate-500 ml-1.5">${v.barkod || ''}</span>
                                        </div>
                                        <div class="flex flex-wrap items-center gap-1.5">
                                            ${depBadges}
                                            ${v.en_uygun_depo ? `
                                                <button type="button" onclick="quickOrderFromYokScan('${v.en_uygun_depo}', '${sBc}', '${sNm}')" class="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold cursor-pointer">
                                                    🛒 ${v.en_uygun_depo}'a At
                                                </button>
                                            ` : ''}
                                            <button type="button" onclick="closeEndOfDaySummaryModal(); searchFromCritical('${sBc}', '${sNm}');" class="px-2 py-1 rounded-lg bg-white hover:bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold cursor-pointer">
                                                🔍 Kıyasla
                                            </button>
                                            <button type="button" onclick="removeFromTodayYokList('${sBc}', '${sNm}')" class="px-2 py-1 rounded-lg bg-white hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 text-[10px] font-extrabold cursor-pointer transition" title="Bu ürünü listeden çıkar">
                                                ✕ Çıkar
                                            </button>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                ` : '';

                if (yokList.length === 0) {
                    yokContainer.innerHTML = `
                        ${manualAddBarHtml}
                        ${foundInStockHtml}
                        <div class="p-6 text-center bg-white rounded-xl border border-slate-200 text-slate-500 text-xs space-y-2">
                            <i class="fa-solid fa-clipboard-check text-2xl text-emerald-400 block"></i>
                            <div class="font-extrabold text-xs text-slate-700">Yok Listesi Şu Anda Boş</div>
                            <p class="text-[11px]">Yukarıdaki kutudan manuel ilaç ekleyebilir veya Günün Çıkışları / Toplu Sipariş ekranında <b>🚨 Yok</b> butonuna tıklayarak depolarda bulunamayan ilaçları buraya sabitleyebilirsiniz.</p>
                        </div>
                    `;
                } else {
                    const yokRows = yokList.map((it, idx) => {
                        const sBc = (it.barkod || '').replace(/'/g, "\\\\'");
                        const sNm = (it.urun_adi || '').replace(/'/g, "\\\\'");
                        const checkedDepos = Array.isArray(it.yok_depolar) && it.yok_depolar.length > 0
                            ? it.yok_depolar.join(', ')
                            : 'Tüm Aktif Depolar';
                        return `
                            <tr class="border-b border-rose-100 bg-rose-50/20 hover:bg-rose-50/50 text-[11px]">
                                <td class="py-1.5 px-2.5 font-mono font-bold text-rose-700">${idx + 1}</td>
                                <td class="py-1.5 px-2.5">
                                    <span class="font-black text-slate-900">${it.urun_adi || '-'}</span>
                                    <span class="text-[10px] font-mono text-slate-500 ml-1.5">${it.barkod || ''}</span>
                                </td>
                                <td class="py-1.5 px-2.5 text-center">
                                    <span class="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black">
                                        🛑 YOK (${checkedDepos})
                                    </span>
                                </td>
                                <td class="py-1.5 px-2.5 text-right">
                                    <div class="inline-flex items-center gap-1">
                                        <button type="button" onclick="closeEndOfDaySummaryModal(); searchFromCritical('${sBc}', '${sNm}');" class="px-2 py-0.5 rounded bg-white hover:bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold cursor-pointer" title="Tüm depolarda, pazaryerlerinde veya muadillerinde ara">
                                            🔍 Depo / Muadil Ara
                                        </button>
                                        <button type="button" onclick="removeFromTodayYokList('${sBc}', '${sNm}')" class="px-2 py-0.5 rounded bg-white hover:bg-rose-100 text-rose-700 border border-rose-200 text-[10px] font-bold cursor-pointer" title="Yok listesinden çıkar">
                                            Çıkar ×
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('');

                    yokContainer.innerHTML = `
                        ${manualAddBarHtml}
                        ${foundInStockHtml}
                        <div class="px-3.5 py-2.5 rounded-xl bg-rose-50 border border-rose-300 text-rose-950 flex flex-wrap items-center justify-between gap-2">
                            <div class="text-[11px] font-bold text-rose-800">
                                🚨 <b>Yok Listesi (${yokList.length} Kalem):</b> Depolarda bulunamayan veya manuel eklenen yok ürünleri.
                            </div>
                            <div class="flex items-center gap-1.5 shrink-0">
                                <button type="button" onclick="scanYokListItemsInDepots()" class="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[11px] shadow-xs transition cursor-pointer flex items-center space-x-1" title="Yok listesindeki ilaçları tüm aktif depolarda tekrar sorgula; stoğa giren varsa yeşil listede göster">
                                    <i class="fa-solid fa-magnifying-glass-chart"></i>
                                    <span>Yokları Depoda Sorgula</span>
                                </button>
                                <button type="button" onclick="copyCompiledYokList()" class="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-black text-[11px] shadow-xs transition cursor-pointer flex items-center space-x-1">
                                    <i class="fa-solid fa-copy"></i>
                                    <span>Yok Listesini Kopyala</span>
                                </button>
                                <button type="button" onclick="clearTodayYokList('yok')" class="px-3 py-1 rounded-lg bg-white hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-300 font-black text-[11px] shadow-xs transition cursor-pointer flex items-center space-x-1" title="Yok listesindeki tüm ürünleri temizle">
                                    <i class="fa-solid fa-trash-can"></i>
                                    <span>Listeyi Temizle</span>
                                </button>
                            </div>
                        </div>
                        <div class="bg-white rounded-xl border border-rose-200 overflow-hidden shadow-2xs">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="bg-rose-100/70 border-b border-rose-200 text-[10px] font-extrabold text-rose-900 uppercase">
                                        <th class="py-1.5 px-2.5 w-8">#</th>
                                        <th class="py-1.5 px-2.5">Bulunamayan Ürün Adı & Barkod</th>
                                        <th class="py-1.5 px-2.5 text-center">Durum / Sorgulanan Depolar</th>
                                        <th class="py-1.5 px-2.5 text-right">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>${yokRows}</tbody>
                            </table>
                        </div>
                    `;
                }
            }
        }

        async function addManualItemToYokList() {
            const nameInput = document.getElementById('manualYokNameInput');
            const bcInput = document.getElementById('manualYokBarcodeInput');
            let rawName = nameInput ? nameInput.value.trim() : '';
            let rawBc = bcInput ? bcInput.value.trim() : '';

            if (!rawName && !rawBc) {
                showToast('Eksik Bilgi', 'Lütfen Yok Listesine eklemek istediğiniz ilacın adını veya barkodunu yazın.', 'info');
                if (nameInput) nameInput.focus();
                return;
            }

            // Eğer ilk kutuya sadece 8-14 haneli barkod yazıldıysa barkod olarak da ata
            if (!rawBc && /^\\d{8,14}$/.test(rawName)) {
                rawBc = rawName;
            }

            try {
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        items: [{
                            barkod: rawBc,
                            urun_adi: rawName || rawBc,
                            kaynak: 'Manuel Ekleme'
                        }]
                    })
                });
                const data = await res.json();
                if (!data.success) {
                    showToast('Uyarı', data.error || 'Yok listesine eklenemedi.', 'error');
                    return;
                }
                if (nameInput) nameInput.value = '';
                if (bcInput) bcInput.value = '';
                showToast('🚨 Yok Listesine Eklendi', `${rawName || rawBc} Yok Listesine eklendi.`, 'success');
                await loadEndOfDaySummary();
                await syncTodayOrdersAcrossPCs();
            } catch (e) {
                showToast('Hata', e.message || 'Yok listesine ekleme hatası', 'error');
            }
        }

        async function scanYokListItemsInDepots() {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Yok Listesi Depo Sorgulama')) return;
            const btn = document.getElementById('btnScanYokInDepots');
            const origHtml = btn ? btn.innerHTML : '';
            try {
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Yoklar Sorgulanıyor...</span>`;
                }
                showToast('Yok Listesi Depolarda Sorgulanıyor', 'Yok listesindeki ürünler tüm aktif depolarda canlı olarak kontrol ediliyor...', 'info');
                const res = await fetch('/api/orders/today/check-yok-list', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: 'yok_only' })
                });
                const data = await res.json();
                if (!data.success) {
                    showToast('Uyarı', data.error || data.message || 'Sorgulama yapılamadı.', 'error');
                    return;
                }
                if (data.checked_count === 0) {
                    showToast('Yok Listesi Boş', 'Sorgulanacak Yok Listesi ürünü bulunmuyor.', 'info');
                    return;
                }
                await loadEndOfDaySummary();
                switchEndOfDayTab('yok');
                if ((data.var_count || 0) > 0) {
                    showToast('🎉 Stoğa Giren Ürün Bulundu!', `Sorgulanan ${data.checked_count} üründen ${data.var_count} tanesi depolarda stokta bulundu! Yeşil listeden hemen sipariş verebilirsiniz.`, 'success');
                } else {
                    showToast('Sorgulama Tamamlandı', `Yok listesindeki ${data.checked_count} ürünün tamamı aktif depolarda tekrar sorgulandı; henüz stoğa giren ürün yok.`, 'info');
                }
            } catch (e) {
                showToast('Hata', e.message || 'Yok listesi sorgulama hatası', 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = origHtml;
                }
            }
        }

        async function scanSkippedItemsForYokList() {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Depo Sorgulama')) return;
            const btn = document.getElementById('btnScanSkippedForYok');
            const origHtml = btn ? btn.innerHTML : '';
            try {
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Sorgulanıyor...</span>`;
                }
                showToast('Depolar Sorgulanıyor', 'Sipariş verilmeyecek olarak işaretlenen ürünler aktif depolarda taranıyor, lütfen bekleyin...', 'info');
                const res = await fetch('/api/orders/today/check-yok-list', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: 'skipped' })
                });
                const data = await res.json();
                if (!data.success) {
                    showToast('Uyarı', data.error || data.message || 'Sorgulama yapılamadı.', 'error');
                    return;
                }
                if (data.checked_count === 0) {
                    showToast('Bilgi', 'Bugün "Sipariş Verilmeyecek" olarak işaretlenmiş ürün bulunamadı.', 'info');
                    return;
                }
                await loadEndOfDaySummary();
                if ((data.yok_count || 0) > 0) {
                    switchEndOfDayTab('yok');
                    showToast('Yok Listesi Oluşturuldu', `${data.checked_count} ürün tarandı: ${data.yok_count} ürün hiçbir depoda bulunamadı ve Yok Listesine eklendi, ${data.var_count} ürün depolarda mevcut.`, 'success');
                } else {
                    switchEndOfDayTab('skipped');
                    showToast('Tüm Ürünler Depolarda Mevcut!', `Taranan ${data.checked_count} ürünün tamamı en az bir depoda stokta bulundu.`, 'success');
                }
            } catch (e) {
                showToast('Hata', e.message || 'Depo sorgulama hatası', 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = origHtml;
                }
            }
        }

        async function removeFromTodayYokList(barkod, urunAdi) {
            try {
                await fetch('/api/orders/today/yok-list/remove', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barkod: barkod || '', urun_adi: urunAdi || '' })
                });
                await loadEndOfDaySummary();
                await syncTodayOrdersAcrossPCs();
                showToast('Yok Listesinden Çıkarıldı', `${urunAdi || barkod} listeden kaldırıldı.`, 'info');
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }
        window.removeFromTodayYokList = removeFromTodayYokList;

        async function clearTodayYokList(mode = 'all') {
            try {
                await fetch('/api/orders/today/yok-list/remove', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ clear_mode: mode })
                });
                await loadEndOfDaySummary();
                await syncTodayOrdersAcrossPCs();
                const msg = mode === 'var'
                    ? 'Stoğa girenler bildirim listesi temizlendi.'
                    : (mode === 'yok' ? 'Yok listesi temizlendi.' : 'Yok ve stoğa girenler listesi temizlendi.');
                showToast('Liste Temizlendi', msg, 'info');
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }
        window.clearTodayYokList = clearTodayYokList;

        async function quickOrderFromYokScan(depo, barkod, urunAdi) {
            if (!depo) return;
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Sepete Ekleme')) return;
            if (typeof executeBulkOrderWithItems === 'function') {
                await executeBulkOrderWithItems(depo, [{ barcode: barkod, name: urunAdi, miktar: 1 }]);
            } else {
                const groups = {};
                groups[depo.toUpperCase()] = [{ barcode: barkod, name: urunAdi, miktar: 1, target_depo: depo.toUpperCase() }];
                await executeMultiDepotBulkDistribution(groups, groups[depo.toUpperCase()]);
            }
            try {
                await fetch('/api/orders/today/yok-list/remove', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barkod: barkod || '', urun_adi: urunAdi || '', unmark_order: false })
                });
            } catch (e) {}
            setTimeout(loadEndOfDaySummary, 600);
        }
        window.quickOrderFromYokScan = quickOrderFromYokScan;

        function copyEndOfDaySummaryReport() {
            const data = window.currentEndOfDayData;
            if (!data) return;
            const lines = [];
            lines.push(`📋 FARMA RADAR — GÜN SONU DEPO SİPARİŞ ÖZETİ (${data.date || ''})`);
            lines.push(`==========================================================`);
            const depots = data.depots || [];
            if (depots.length === 0) {
                lines.push(`Bugün sipariş verilen ürün bulunmamaktadır.`);
            } else {
                depots.forEach(d => {
                    lines.push(`\\n🏢 ${d.depo} DEPOSU (Verilen: ${d.ordered_count} Kalem / ${d.ordered_boxes} Kutu | Sepette: ${d.cart_count} Kalem / ${d.cart_boxes} Kutu)`);
                    (d.items || []).forEach((it, idx) => {
                        const st = it.durum === 'SIPARIS_VERILDI' ? 'SİPARİŞ VERİLDİ' : 'SEPETTE';
                        lines.push(`  ${idx + 1}. ${it.urun_adi} [${it.barkod || '-'}] — ${it.miktar || 1} Kutu (${st} • ${it.masa_adi || ''} ${it.saat || ''})`);
                    });
                });
            }
            const yokItems = (data.yok_scan && data.yok_scan.yok_items) ? data.yok_scan.yok_items : [];
            if (yokItems.length > 0) {
                lines.push(`\\n🚨 DEPOLARDA BULUNAMAYANLAR (YOK LİSTESİ — ${yokItems.length} Kalem):`);
                yokItems.forEach((y, i) => {
                    lines.push(`  ${i + 1}. ${y.urun_adi} (${y.barkod || '-'})`);
                });
            }
            navigator.clipboard.writeText(lines.join('\\n'));
            showToast('Gün Sonu Özeti Kopyalandı', 'Depo sipariş özeti ve yok listesi panoya kopyalandı.', 'success');
        }

        function copyCompiledYokList() {
            const data = window.currentEndOfDayData;
            const yokItems = (data && data.yok_scan && Array.isArray(data.yok_scan.yok_items)) ? data.yok_scan.yok_items : [];
            if (yokItems.length === 0) {
                showToast('Yok Listesi Boş', 'Kopyalanacak yok listesi ürünü bulunmuyor.', 'info');
                return;
            }
            const lines = [`🚨 ECZANE DEPO YOK LİSTESİ (${data.date || ''}) — Toplam ${yokItems.length} Kalem:`];
            yokItems.forEach((it, i) => {
                lines.push(`${i + 1}. ${it.urun_adi} ${it.barkod ? '[' + it.barkod + ']' : ''}`);
            });
            navigator.clipboard.writeText(lines.join('\\n'));
            showToast('Yok Listesi Kopyalandı', `${yokItems.length} kalemlik Yok Listesi panoya kopyalandı.`, 'success');
        }

        // Sayfa yüklendiğinde aktif otomasyonu çek ve SADECE aktif otomasyonun bağlantısını test et
        document.addEventListener('DOMContentLoaded', async () => {
            try {
                const res = await fetch('/api/settings/credentials');
                if (res.ok) {
                    const c = await res.json();
                    if (c.active_otomasyon) {
                        window.activeOtomasyon = c.active_otomasyon.toUpperCase();
                    }
                }
            } catch(e) {}
            selectActiveOtomasyon(window.activeOtomasyon || 'BOTANIK', false);
            refreshHeaderActiveOtomasyon();
            refreshDepoStatusBadge();
            const activeOto = (window.activeOtomasyon || 'BOTANIK').toUpperCase();
            if (activeOto === 'BOTANIK') {
                checkBotanikStatusOnLoad();
            } else if (activeOto === 'TEBEOS') {
                checkTebeosStatusOnLoad();
            } else {
                checkTriaStatusOnLoad();
            }
            initMarketSuggest();
            loadCriticalStockList(false);
            loadEndOfDaySummary();
            setInterval(() => loadEndOfDaySummary(), 20000);
        });
    </script>
</body>
</html>
"""
