# -*- coding: utf-8 -*-
"""
backend/tria_client.py
-----------------------
Tria Eczane Otomasyon Sistemi (Oracle 11g/12c/19c) Veri Erişim & Analiz Modülü.
Eczane raf stoğu, aylık nakit fişli ve SGK reçeteli satış hareketlerini (ÇIKIŞ),
depolardan gelen alış faturalarını (GİRİŞ) ve günün kritik/azalan stok çıkışlarını sorgular.
"""

import os
import re
import sys
import time
import datetime
import threading
from typing import Dict, Any, List, Optional, Tuple

try:
    import oracledb
except ImportError:
    oracledb = None

_ORACLE_CLIENT_INITIALIZED = False
_ORACLE_INIT_LOCK = threading.Lock()

TRIA_KDV_ID_MAP: Dict[int, float] = {
    1: 0.0,
    2: 1.0,
    3: 10.0,
    4: 20.0,
    5: 10.0,
    6: 20.0,
}


def _kdv_from_satis_kdv_id(val: Any) -> float:
    """TRIA SATIS_KDV_ID kodunu (1..6) güncel KDV yüzdesine dönüştürür (TBL_KDV_TANIM bağımsız)."""
    if val is None:
        return 10.0
    try:
        iv = int(round(float(val)))
    except Exception:
        return 10.0
    if iv in TRIA_KDV_ID_MAP:
        return TRIA_KDV_ID_MAP[iv]
    if iv == 8:
        return 10.0
    if iv == 18:
        return 20.0
    if iv in (0, 1, 10, 20):
        return float(iv)
    return 10.0


def _mal_kodu_variants(pcode: str) -> List[str]:
    """
    LTRIM(MAL_KODU, '0') tam tablo taramasını (Full Table Scan) önlemek için
    olası sıfır dolgulu / sıfırsız MAL_KODU varyantlarını üretir (%100 INDEX RANGE SCAN).
    """
    p = str(pcode or "").strip()
    if not p:
        return []
    stripped = p.lstrip("0") or "0"
    cands = [p, stripped]
    if stripped.isdigit():
        for width in (7, 6, 8, 5):
            z = stripped.zfill(width)
            if z not in cands:
                cands.append(z)
    return [c for c in dict.fromkeys(cands) if c]


class _PooledConnWrapper:
    """Oracle bağlantı havuzu oturumunu context-manager çıkışında kapatmak yerine havuza iade eder."""
    __slots__ = ("_conn", "_pool", "_on_broken", "_closed")

    def __init__(self, conn: Any, pool: Any, on_broken: Any = None):
        self._conn = conn
        self._pool = pool
        self._on_broken = on_broken
        self._closed = False

    @property
    def version(self) -> str:
        return getattr(self._conn, "version", "")

    def cursor(self):
        cur = self._conn.cursor()
        try:
            cur.arraysize = 500
        except Exception:
            pass
        return cur

    def commit(self):
        return self._conn.commit()

    def rollback(self):
        return self._conn.rollback()

    def ping(self):
        return self._conn.ping()

    def __getattr__(self, name: str):
        return getattr(self._conn, name)

    def close(self, broken: bool = False):
        if self._closed:
            return
        self._closed = True
        try:
            if self._pool is not None:
                if broken:
                    try:
                        self._pool.drop(self._conn)
                    except Exception:
                        self._pool.release(self._conn)
                else:
                    self._pool.release(self._conn)
            else:
                self._conn.close()
        except Exception:
            try:
                self._conn.close()
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        is_broken = False
        if exc_val is not None:
            es = str(exc_val)
            if any(k in es for k in ("DPY-4011", "DPY-1001", "ORA-00028", "ORA-03113", "ORA-03135", "ORA-01012", "DPI-1080")):
                is_broken = True
                if callable(self._on_broken):
                    try:
                        self._on_broken()
                    except Exception:
                        pass
            else:
                try:
                    self._conn.rollback()
                except Exception:
                    pass
        self.close(broken=is_broken)
        return False

LATIN1_TR_TRANS = str.maketrans({
    '\xdd': 'İ', '\xfd': 'ı', '\xde': 'Ş', '\xfe': 'ş', '\xd0': 'Ğ', '\xf0': 'ğ',
    'Ý': 'İ', 'ý': 'ı', 'Þ': 'Ş', 'þ': 'ş', 'Ð': 'Ğ', 'ð': 'ğ'
})

EXCLUDE_MAL_KODLARI = {
    '0020934', '0026445', '0042923', '0042925', '0042926', '0111629', '0272017', '0272050'
}

def fix_tria_str(val: Any) -> str:
    """TRIA Oracle veritabanından gelen Türkçe karakterleri standartlaştırır."""
    if val is None:
        return ""
    if isinstance(val, (bytes, bytearray)):
        for enc in ('utf-8', 'iso-8859-9', 'windows-1254', 'cp857'):
            try:
                decoded = val.decode(enc)
                if decoded and all(c.isprintable() or c.isspace() for c in decoded):
                    val = decoded
                    break
            except Exception:
                continue
        if isinstance(val, (bytes, bytearray)):
            val = val.decode('iso-8859-9', errors='replace')
    s = str(val).strip()
    return s.translate(LATIN1_TR_TRANS).rstrip('*').strip()


def to_short_path(path: str) -> str:
    """Windows'ta Türkçe/özel karakter içeren yolları 8.3 kısa dosya adına dönüştürür (Oracle ODPI-C UTF-8 fix)."""
    if not path or not os.path.exists(path):
        return path
    if os.name == 'nt':
        try:
            import ctypes
            buf = ctypes.create_unicode_buffer(1024)
            res = ctypes.windll.kernel32.GetShortPathNameW(path, buf, 1024)
            if res > 0 and buf.value:
                return buf.value
        except Exception:
            pass
    return path

class TriaOracleClient:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.oracle_client_initialized = False
        self._bad_auth_cache: Dict[Tuple[str, str, str], float] = {}
        self._takas_schema_cache: Optional[Dict[str, Dict[str, str]]] = None
        self._pool: Any = None
        self._pool_key: Optional[Tuple[str, str, str, str, str]] = None
        self._pool_lock = threading.Lock()
        self._prod_index: Optional[Dict[str, Any]] = None
        self._prod_index_ts: float = 0.0
        self._prod_index_lock = threading.Lock()
        self._mf_hist_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
        self._webliste_drug_barcodes: Optional[set] = None
        self._init_oracle_client()

    def _invalidate_caches(self):
        self._prod_index = None
        self._prod_index_ts = 0.0
        self._takas_schema_cache = None
        self._mf_hist_cache.clear()

    def _drop_pool(self):
        with self._pool_lock:
            old_pool = self._pool
            self._pool = None
            self._pool_key = None
        if old_pool is not None:
            try:
                old_pool.close(force=True)
            except Exception:
                pass

    def _ensure_product_index(self, cur) -> Dict[str, Any]:
        """
        TBL_MAL_TANIM + TBL_MAL_BARKOD_TANIM tablolarını tek seferde belleğe indeksler (10 dk TTL).
        Özellikle TBL_MAL_BARKOD_TANIM(BARKOD / MAL_TANIM_ID) indeksi olmayan uzak TRIA sunucularında
        250x tam tablo taramasını 0.02 ms RAM aramasına indirir (%100 SELECT).
        """
        now = time.time()
        idx_ref = self._prod_index
        if idx_ref is not None and (now - self._prod_index_ts) < 600.0:
            return idx_ref

        with self._prod_index_lock:
            now = time.time()
            if self._prod_index is not None and (now - self._prod_index_ts) < 600.0:
                return self._prod_index

            by_id: Dict[int, Dict[str, Any]] = {}
            by_code: Dict[str, int] = {}
            by_barcode: Dict[str, int] = {}
            by_esdeger: Dict[str, List[int]] = {}

            try:
                prev_arr = getattr(cur, "arraysize", 500)
                try:
                    cur.arraysize = 2500
                except Exception:
                    pass
                cur.execute("""
                    SELECT t.ID,
                           t.MAL_KODU,
                           UTL_RAW.CAST_TO_RAW(t.MAL_ADI),
                           NVL(t.SATIS_FIYATI_1, 0),
                           NVL(t.DEPOCU_SATIS_FIYATI, 0),
                           NVL(t.ALIS_FIYATI_1, 0),
                           NVL(t.KAMU_ISKONTO_ORANI, 0),
                           NVL(t.SATIS_KDV_ID, 5),
                           t.ESDEGER_GRUP_KODU,
                           b.BARKOD
                    FROM TBL_MAL_TANIM t
                    LEFT JOIN TBL_MAL_BARKOD_TANIM b
                           ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                    WHERE (t.PASIF IS NULL OR t.PASIF = 0)
                """)
                for r in cur.fetchall():
                    if r[0] is None:
                        continue
                    mid = int(r[0])
                    mkod = str(r[1] or "").strip()
                    bc = str(r[9] or "").strip()
                    entry = by_id.get(mid)
                    if entry is None:
                        esd = str(r[8] or "").strip()
                        entry = {
                            "id": mid,
                            "mal_kodu": mkod,
                            "raw_name": r[2],
                            "psf": float(r[3] or 0.0),
                            "dsf": float(r[4] or 0.0),
                            "alis1": float(r[5] or 0.0),
                            "kamu_isk": float(r[6] or 0.0),
                            "satis_kdv_id": r[7],
                            "kdv": _kdv_from_satis_kdv_id(r[7]),
                            "esdeger": esd,
                            "barcodes": [],
                            "primary_barcode": "",
                        }
                        by_id[mid] = entry
                        if mkod:
                            by_code[mkod] = mid
                            stripped = mkod.lstrip("0")
                            if stripped and stripped not in by_code:
                                by_code[stripped] = mid
                        if esd:
                            by_esdeger.setdefault(esd, []).append(mid)
                    if bc and bc not in entry["barcodes"]:
                        entry["barcodes"].append(bc)
                        by_barcode[bc] = mid

                for entry in by_id.values():
                    bcs = entry["barcodes"]
                    if bcs:
                        # 13 haneli EAN barkodu önceliklendir
                        ean13 = [x for x in bcs if len(x) == 13 and x.isdigit()]
                        entry["primary_barcode"] = max(ean13) if ean13 else max(bcs)
                    else:
                        entry["primary_barcode"] = entry["mal_kodu"]

                try:
                    cur.arraysize = prev_arr
                except Exception:
                    pass

                built = {
                    "by_id": by_id,
                    "by_code": by_code,
                    "by_barcode": by_barcode,
                    "by_esdeger": by_esdeger,
                }
                self._prod_index = built
                self._prod_index_ts = time.time()
                return built
            except Exception as e_idx:
                print(f"[TriaClient] Ürün RAM indeksi uyarı: {e_idx}")
                return {
                    "by_id": by_id,
                    "by_code": by_code,
                    "by_barcode": by_barcode,
                    "by_esdeger": by_esdeger,
                }

    def _get_takas_schema(self, cur) -> Dict[str, Dict[str, str]]:
        """TRIA Oracle takas ve belge tablolarının sütun tiplerini bir kez okuyup önbelleğe alır (100% SELECT)."""
        if self._takas_schema_cache is not None:
            return self._takas_schema_cache
        schema: Dict[str, Dict[str, str]] = {}
        try:
            cur.execute("""
                SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
                FROM USER_TAB_COLS
                WHERE TABLE_NAME IN (
                    'TBL_TAKAS', 'TBL_TAKAS_DETAY',
                    'TBL_BELGE', 'TBL_BELGE_DETAY',
                    'TBL_CARI_TANIM', 'TBL_ECZANE_TANIM', 'TBL_TAKAS_ECZANE',
                    'TBL_MAL_HAREKET'
                )
            """)
            for tbl, col, dtype in cur.fetchall():
                t_key = str(tbl or "").strip().upper()
                c_key = str(col or "").strip().upper()
                d_val = str(dtype or "").strip().upper()
                if t_key and c_key:
                    schema.setdefault(t_key, {})[c_key] = d_val
            if schema:
                self._takas_schema_cache = schema
        except Exception as e:
            print(f"[TriaClient] Takas şema keşfi uyarısı: {e}")
        return schema

    def _fetch_tria_takas_movements(self, cur, mal_kodu: str, mal_id: Any) -> Tuple[List[Dict[str, Any]], int, int]:
        """
        TRIA'daki hem özel Takas Modülü (TBL_TAKAS + TBL_TAKAS_DETAY) hem de
        Faturalı Eczane Takaslarını (TBL_BELGE TIP_NO: TGF / TÇF / TCF) eksiksiz birleştirir.
        """
        schema = self._get_takas_schema(cur)
        collected: List[Dict[str, Any]] = []
        pcode_str = str(mal_kodu or "").strip()

        def _is_str_col(cols_map: Dict[str, str], cname: str) -> bool:
            dt = cols_map.get(cname, "")
            return dt in ("VARCHAR2", "CHAR", "NVARCHAR2", "NCHAR")

        def _is_num_col(cols_map: Dict[str, str], cname: str) -> bool:
            dt = cols_map.get(cname, "")
            return dt in ("NUMBER", "FLOAT", "BINARY_DOUBLE", "BINARY_FLOAT", "INTEGER")

        def _is_date_col(cols_map: Dict[str, str], cname: str) -> bool:
            dt = cols_map.get(cname, "")
            return dt == "DATE" or dt.startswith("TIMESTAMP")

        # ------------------------------------------------------------------
        # KAYNAK 1: TBL_TAKAS + TBL_TAKAS_DETAY (TRIA Özel Takas Modülü)
        # T.TAKAS_DURUM = 1 -> GİDEN (-TD.MIKTAR), T.TAKAS_DURUM = 0 -> GELEN (+TD.MIKTAR)
        # ------------------------------------------------------------------
        takas_mod_found = False
        t_cols = schema.get("TBL_TAKAS", {})
        td_cols = schema.get("TBL_TAKAS_DETAY", {})
        if t_cols and td_cols and "ID" in t_cols and "MIKTAR" in td_cols:
            try:
                fk_belge = "BELGE_ID" if "BELGE_ID" in td_cols else ("TAKAS_ID" if "TAKAS_ID" in td_cols else None)
                if fk_belge:
                    date_candidates = [
                        c for c in ("BELGE_TARIHI", "TAKAS_TARIHI", "ISLEM_TARIHI", "TARIH", "INSERT_DATE")
                        if _is_date_col(t_cols, c)
                    ]
                    if len(date_candidates) > 1:
                        date_raw_expr = f"COALESCE({', '.join('T.' + c for c in date_candidates)})"
                    elif len(date_candidates) == 1:
                        date_raw_expr = f"T.{date_candidates[0]}"
                    else:
                        date_raw_expr = "SYSDATE"

                    joins_sql = []
                    name_exprs = []
                    for sc in ("KARSI_ECZANE_ADI", "ECZANE_ADI", "CARI_ADI", "KARSI_CARI_ADI", "FIRMA_ADI", "UNVAN", "ACIKLAMA"):
                        if _is_str_col(t_cols, sc):
                            name_exprs.append(f"SUBSTR(NULLIF(TRIM(T.{sc}), ''), 1, 200)")

                    c_cols = schema.get("TBL_CARI_TANIM", {})
                    if c_cols and "ID" in c_cols:
                        cari_fk = next((c for c in ("CARI_TANIM_ID", "CARI_ID", "KARSI_CARI_ID", "KARSI_ECZANE_ID") if c in t_cols), None)
                        if cari_fk:
                            joins_sql.append(f"LEFT JOIN TBL_CARI_TANIM C ON C.ID = T.{cari_fk}")
                            for cc in ("CARI_ADI", "UNVAN", "ADI"):
                                if _is_str_col(c_cols, cc):
                                    name_exprs.append(f"SUBSTR(NULLIF(TRIM(C.{cc}), ''), 1, 200)")

                    for e_tbl in ("TBL_TAKAS_ECZANE", "TBL_ECZANE_TANIM"):
                        e_cols = schema.get(e_tbl, {})
                        if e_cols and "ID" in e_cols:
                            e_fk = next((c for c in ("TAKAS_ECZANE_ID", "ECZANE_TANIM_ID", "ECZANE_ID") if c in t_cols), None)
                            if e_fk:
                                joins_sql.append(f"LEFT JOIN {e_tbl} E ON E.ID = T.{e_fk}")
                                for ec in ("ECZANE_ADI", "CARI_ADI", "ADI", "UNVAN"):
                                    if _is_str_col(e_cols, ec):
                                        name_exprs.append(f"SUBSTR(NULLIF(TRIM(E.{ec}), ''), 1, 200)")
                                break

                    if name_exprs:
                        ecz_raw_expr = f"UTL_RAW.CAST_TO_RAW(COALESCE({', '.join(name_exprs)}, 'TAKAS ECZANESI'))"
                    else:
                        ecz_raw_expr = "UTL_RAW.CAST_TO_RAW('TAKAS ECZANESI')"

                    if "TAKAS_DURUM" in t_cols:
                        durum_expr = "NVL(T.TAKAS_DURUM, 0)"
                    elif "GIRIS_CIKIS_DURUMU" in t_cols:
                        durum_expr = "CASE WHEN NVL(T.GIRIS_CIKIS_DURUMU, 1) = 1 THEN 0 ELSE 1 END"
                    else:
                        durum_expr = "0"

                    uprice_cols = [
                        f"NULLIF(TD.{c}, 0)" for c in (
                            "NET_FIYAT", "BIRIM_FIYAT", "TAKAS_FIYATI", "FIYAT",
                            "MALIYET", "ALIS_FIYATI", "DEPOCU_FIYATI", "ECZACI_FIYATI", "PSF", "ETIKET_FIYATI"
                        ) if _is_num_col(td_cols, c)
                    ]
                    uprice_expr = f"COALESCE({', '.join(uprice_cols)}, 0)" if uprice_cols else "0"

                    tot_cols = [
                        f"NULLIF(TD.{c}, 0)" for c in ("NET_TUTAR", "TUTAR", "TOPLAM_TUTAR", "GENEL_TOPLAM")
                        if _is_num_col(td_cols, c)
                    ]
                    tot_expr = f"COALESCE({', '.join(tot_cols)}, 0)" if tot_cols else "0"

                    pcode_cands = _mal_kodu_variants(pcode_str)
                    where_parts = []
                    bind_params: Dict[str, Any] = {}
                    if "MAL_KODU" in td_cols and pcode_cands and "MAL_ID" in td_cols and mal_id is not None:
                        pk_binds = []
                        for idx_c, cv in enumerate(pcode_cands):
                            bk = f"pk{idx_c}"
                            bind_params[bk] = cv
                            pk_binds.append(f":{bk}")
                        bind_params["mid"] = mal_id
                        where_parts.append(f"(TD.MAL_KODU IN ({','.join(pk_binds)}) OR TD.MAL_ID = :mid)")
                    elif "MAL_KODU" in td_cols and pcode_cands:
                        pk_binds = []
                        for idx_c, cv in enumerate(pcode_cands):
                            bk = f"pk{idx_c}"
                            bind_params[bk] = cv
                            pk_binds.append(f":{bk}")
                        where_parts.append(f"TD.MAL_KODU IN ({','.join(pk_binds)})")
                    elif "MAL_ID" in td_cols and mal_id is not None:
                        where_parts.append("TD.MAL_ID = :mid")
                        bind_params = {"mid": mal_id}

                    for cancel_col in ("IPTAL", "IPTAL_DURUMU", "SILINDI"):
                        if _is_num_col(t_cols, cancel_col):
                            where_parts.append(f"NVL(T.{cancel_col}, 0) = 0")

                    if where_parts:
                        sql_takas_mod = f"""
                            SELECT * FROM (
                                SELECT
                                    TO_CHAR({date_raw_expr}, 'YYYY-MM-DD') AS TARIH,
                                    {ecz_raw_expr} AS ECZANE_RAW,
                                    {durum_expr} AS TAKAS_DURUM,
                                    NVL(TD.MIKTAR, 0) AS MIKTAR,
                                    {uprice_expr} AS BIRIM_FIYAT,
                                    {tot_expr} AS SATIR_TUTAR,
                                    NVL(T.ID, 0) AS SORT_ID
                                FROM TBL_TAKAS_DETAY TD
                                JOIN TBL_TAKAS T ON T.ID = TD.{fk_belge}
                                {' '.join(joins_sql)}
                                WHERE {' AND '.join(where_parts)}
                                ORDER BY {date_raw_expr} DESC NULLS LAST, T.ID DESC
                            ) WHERE ROWNUM <= 20
                        """
                        cur.execute(sql_takas_mod, bind_params)
                        for tr in cur.fetchall():
                            raw_qty = float(tr[3] or 0)
                            t_adet = int(round(abs(raw_qty)))
                            if t_adet <= 0:
                                continue
                            takas_mod_found = True
                            t_durum = int(tr[2] or 0)
                            yon = "GIDEN" if (t_durum == 1 or raw_qty < 0) else "GELEN"
                            u_val = float(tr[4] or 0.0)
                            s_val = float(tr[5] or 0.0)
                            if u_val > 0:
                                b_tutar = round(u_val, 2)
                                top_tutar = round(s_val if s_val > 0 else (b_tutar * t_adet), 2)
                            elif s_val > 0:
                                b_tutar = round(s_val / max(1, t_adet), 2)
                                top_tutar = round(s_val, 2)
                            else:
                                b_tutar = 0.0
                                top_tutar = 0.0
                            ecz_str = fix_tria_str(tr[1]) or "TAKAS ECZANESİ"
                            if ecz_str.upper() == "TAKAS ECZANESI":
                                ecz_str = "TAKAS ECZANESİ"
                            collected.append({
                                "tarih": str(tr[0] or ""),
                                "eczane": ecz_str,
                                "yon": yon,
                                "adet": t_adet,
                                "birim_tutar": b_tutar,
                                "maliyet": b_tutar,
                                "toplam_tutar": top_tutar,
                                "hesap_tipi": "Takas",
                                "_sort_id": int(tr[6] or 0),
                            })
            except Exception as e_tk:
                print(f"[TriaClient] TBL_TAKAS sorgu uyarısı: {e_tk}")

        # ------------------------------------------------------------------
        # KAYNAK 2: TBL_BELGE + TBL_BELGE_DETAY (Faturalı Takas: TGF / TÇF / TCF / TF)
        # WE8ISO8859P9 'Ç' karakter kodlamasından etkilenmemek için SUBSTR T_F kontrolü kullanılır.
        # ------------------------------------------------------------------
        b_cols = schema.get("TBL_BELGE", {})
        bd_cols = schema.get("TBL_BELGE_DETAY", {})
        if not b_cols or ("TIP_NO" in b_cols and "BELGE_TARIHI" in b_cols):
            try:
                c_cols = schema.get("TBL_CARI_TANIM", {})
                has_cari_join = bool(c_cols and "ID" in c_cols and (not b_cols or "CARI_TANIM_ID" in b_cols) and _is_str_col(c_cols, "CARI_ADI"))
                cari_join_sql = "LEFT JOIN TBL_CARI_TANIM c ON c.ID = b.CARI_TANIM_ID" if has_cari_join else ""
                cari_raw_sql = (
                    "UTL_RAW.CAST_TO_RAW(SUBSTR(COALESCE(NULLIF(TRIM(b.CARI_ADI), ''), NULLIF(TRIM(c.CARI_ADI), ''), 'DIGER ECZANE'), 1, 200))"
                    if has_cari_join else
                    "NVL(UTL_RAW.CAST_TO_RAW(SUBSTR(b.CARI_ADI, 1, 200)), UTL_RAW.CAST_TO_RAW('DIGER ECZANE'))"
                )
                alis_satis_sql = "NVL(b.ALIS_SATIS_DURUMU, -1)" if (not b_cols or "ALIS_SATIS_DURUMU" in b_cols) else "-1"

                bd_uprice_parts = []
                for col_nm in ("NET_FIYAT", "BIRIM_FIYAT"):
                    if not bd_cols or _is_num_col(bd_cols, col_nm):
                        bd_uprice_parts.append(f"NULLIF(d.{col_nm}, 0)")
                bd_uprice_sql = f"COALESCE({', '.join(bd_uprice_parts)}, 0)" if bd_uprice_parts else "0"
                bd_tutar_sql = "NVL(d.TUTAR, 0)" if (not bd_cols or _is_num_col(bd_cols, "TUTAR")) else "0"

                pcode_cands = _mal_kodu_variants(pcode_str)
                if pcode_cands:
                    bd_binds = {f"pk{i}": v for i, v in enumerate(pcode_cands)}
                    bd_in = ",".join(f":pk{i}" for i in range(len(pcode_cands)))
                    cur.execute(f"""
                        SELECT * FROM (
                            SELECT
                                TO_CHAR(b.BELGE_TARIHI, 'YYYY-MM-DD') AS TARIH,
                                {cari_raw_sql} AS ECZANE_RAW,
                                UTL_RAW.CAST_TO_RAW(NVL(b.TIP_NO, '')) AS TIP_RAW,
                                {alis_satis_sql} AS ALIS_SATIS,
                                NVL(d.MIKTAR, 0) AS ADET,
                                {bd_uprice_sql} AS BIRIM_FIYAT,
                                {bd_tutar_sql} AS SATIR_TUTAR,
                                NVL(b.ID, 0) AS SORT_ID
                            FROM TBL_BELGE_DETAY d
                            JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                            {cari_join_sql}
                            WHERE d.MAL_KODU IN ({bd_in})
                              AND (
                                  b.TIP_NO IN ('TGF', 'TCF', 'TÇF', 'TF', 'TAK')
                                  OR (
                                      LENGTH(TRIM(NVL(b.TIP_NO, ''))) = 3
                                      AND SUBSTR(UPPER(TRIM(b.TIP_NO)), 1, 1) = 'T'
                                      AND SUBSTR(UPPER(TRIM(b.TIP_NO)), 3, 1) = 'F'
                                  )
                              )
                            ORDER BY b.BELGE_TARIHI DESC NULLS LAST, b.ID DESC
                        ) WHERE ROWNUM <= 20
                    """, bd_binds)
                    bd_takas_rows = cur.fetchall()
                else:
                    bd_takas_rows = []
                for br in bd_takas_rows:
                    raw_qty = float(br[4] or 0)
                    t_adet = int(round(abs(raw_qty)))
                    if t_adet <= 0:
                        continue
                    tip_dec = (fix_tria_str(br[2]) or "").strip().upper()
                    alis_satis = int(br[3] if br[3] is not None else -1)
                    if tip_dec == "TGF" or ("G" in tip_dec and alis_satis != 1):
                        yon = "GELEN"
                        htip_lbl = "Takas Faturası"
                    else:
                        yon = "GIDEN"
                        htip_lbl = "Takas Faturası"
                    u_val = float(br[5] or 0.0)
                    s_val = float(br[6] or 0.0)
                    if u_val > 0:
                        b_tutar = round(u_val, 2)
                        top_tutar = round(s_val if s_val > 0 else (b_tutar * t_adet), 2)
                    elif s_val > 0:
                        b_tutar = round(s_val / max(1, t_adet), 2)
                        top_tutar = round(s_val, 2)
                    else:
                        b_tutar = 0.0
                        top_tutar = 0.0
                    ecz_str = fix_tria_str(br[1]) or "DİĞER ECZANE"
                    if ecz_str.upper() == "DIGER ECZANE":
                        ecz_str = "DİĞER ECZANE"
                    collected.append({
                        "tarih": str(br[0] or ""),
                        "eczane": ecz_str,
                        "yon": yon,
                        "adet": t_adet,
                        "birim_tutar": b_tutar,
                        "maliyet": b_tutar,
                        "toplam_tutar": top_tutar,
                        "hesap_tipi": htip_lbl,
                        "_sort_id": int(br[7] or 0),
                    })
            except Exception as e_bf:
                print(f"[TriaClient] TBL_BELGE takas sorgu uyarısı: {e_bf}")

        # ------------------------------------------------------------------
        # KAYNAK 3: TBL_MAL_HAREKET (Fişli Eczane Takas Hareketleri: BELGE_TURU = 'TAKAS')
        # Not: TRIA'da GIRIS_CIKIS_DURUMU = 0 (veya URUN_BELGE_TIPI = 17) GELEN Takas,
        #      GIRIS_CIKIS_DURUMU = 1 (veya URUN_BELGE_TIPI = 18) GİDEN Takas demektir.
        #      Karşı eczane adı ACIKLAMA sütununda ('... NL TAKAS-LİVA ECZANESİ:888...') yer alır.
        # ------------------------------------------------------------------
        mh_cols = schema.get("TBL_MAL_HAREKET", {})
        if not takas_mod_found and (not mh_cols or ("BELGE_TURU" in mh_cols and "MIKTAR" in mh_cols)):
            try:
                c_cols = schema.get("TBL_CARI_TANIM", {})
                has_mh_cari = bool(
                    c_cols and "ID" in c_cols
                    and (not mh_cols or "CARI_TANIM_ID" in mh_cols)
                    and _is_str_col(c_cols, "CARI_ADI")
                )
                mh_cari_join = "LEFT JOIN TBL_CARI_TANIM c ON c.ID = mh.CARI_TANIM_ID" if has_mh_cari else ""
                mh_cari_expr = (
                    "UTL_RAW.CAST_TO_RAW(SUBSTR(NVL(c.CARI_ADI, ''), 1, 200))"
                    if has_mh_cari else
                    "UTL_RAW.CAST_TO_RAW('')"
                )
                gc_sql = "NVL(mh.GIRIS_CIKIS_DURUMU, -1)" if (not mh_cols or "GIRIS_CIKIS_DURUMU" in mh_cols) else "-1"
                iade_sql = "NVL(mh.NORMAL_IADE_DURUMU, 0)" if (not mh_cols or "NORMAL_IADE_DURUMU" in mh_cols) else "0"
                ubt_sql = "NVL(mh.URUN_BELGE_TIPI, 0)" if (not mh_cols or "URUN_BELGE_TIPI" in mh_cols) else "0"
                mh_price_sql = "NVL(mh.BIRIM_FIYAT, 0)" if (not mh_cols or _is_num_col(mh_cols, "BIRIM_FIYAT")) else "0"
                mh_tot_sql = "NVL(mh.TUTAR, 0)" if (not mh_cols or _is_num_col(mh_cols, "TUTAR")) else "0"
                mh_acik_sql = (
                    "UTL_RAW.CAST_TO_RAW(SUBSTR(NVL(mh.ACIKLAMA, ''), 1, 220))"
                    if (not mh_cols or _is_str_col(mh_cols, "ACIKLAMA")) else
                    "UTL_RAW.CAST_TO_RAW('')"
                )
                mh_id_sql = "NVL(mh.ID, 0)" if (not mh_cols or _is_num_col(mh_cols, "ID")) else "0"

                pcode_cands = _mal_kodu_variants(pcode_str)
                if pcode_cands:
                    mh_binds = {f"pk{i}": v for i, v in enumerate(pcode_cands)}
                    mh_in = ",".join(f":pk{i}" for i in range(len(pcode_cands)))
                    cur.execute(f"""
                        SELECT * FROM (
                            SELECT
                                TO_CHAR(mh.BELGE_TARIHI, 'YYYY-MM-DD') AS TARIH,
                                {gc_sql} AS GC_DURUM,
                                NVL(mh.MIKTAR, 0) AS MIKTAR,
                                {mh_price_sql} AS BIRIM_FIYAT,
                                {mh_tot_sql} AS SATIR_TUTAR,
                                {iade_sql} AS IADE_DURUM,
                                {ubt_sql} AS UBT,
                                {mh_acik_sql} AS ACIK_RAW,
                                {mh_cari_expr} AS CARI_RAW,
                                {mh_id_sql} AS SORT_ID
                            FROM TBL_MAL_HAREKET mh
                            {mh_cari_join}
                            WHERE mh.MAL_KODU IN ({mh_in})
                              AND (mh.BELGE_TURU = 'TAKAS' OR UPPER(TRIM(NVL(mh.BELGE_TURU, ''))) = 'TAKAS')
                            ORDER BY mh.BELGE_TARIHI DESC NULLS LAST, {mh_id_sql} DESC
                        ) WHERE ROWNUM <= 20
                    """, mh_binds)
                    mh_takas_rows = cur.fetchall()
                else:
                    mh_takas_rows = []
                for mr in mh_takas_rows:
                    raw_qty = float(mr[2] or 0)
                    t_adet = int(round(abs(raw_qty)))
                    if t_adet <= 0:
                        continue
                    gc_val = int(mr[1] if mr[1] is not None else -1)
                    iade_val = int(mr[5] or 0)
                    ubt_val = int(mr[6] or 0)

                    if raw_qty < 0:
                        yon = "GIDEN"
                    elif gc_val == 1 or ubt_val == 18:
                        yon = "GELEN" if iade_val == 1 else "GIDEN"
                    elif gc_val == 0 or ubt_val == 17:
                        yon = "GIDEN" if iade_val == 1 else "GELEN"
                    else:
                        yon = "GIDEN" if gc_val == 2 else "GELEN"

                    acik_txt = fix_tria_str(mr[7]).strip()
                    cari_txt = fix_tria_str(mr[8]).strip()
                    ecz_name = cari_txt
                    if not ecz_name and acik_txt:
                        m_ecz = re.search(r"TAKAS\s*[-:]\s*([^:]+)", acik_txt, flags=re.IGNORECASE)
                        if m_ecz:
                            ecz_name = m_ecz.group(1).strip(" -:")
                        elif "-" in acik_txt:
                            tail = acik_txt.split("-", 1)[1].split(":", 1)[0].strip()
                            if len(tail) >= 3:
                                ecz_name = tail
                    if not ecz_name:
                        ecz_name = "TAKAS ECZANESİ"

                    u_val = float(mr[3] or 0.0)
                    s_val = float(mr[4] or 0.0)
                    b_tutar = round(u_val if u_val > 0 else (s_val / max(1, t_adet) if s_val > 0 else 0.0), 2)
                    collected.append({
                        "tarih": str(mr[0] or ""),
                        "eczane": ecz_name,
                        "yon": yon,
                        "adet": t_adet,
                        "birim_tutar": b_tutar,
                        "maliyet": b_tutar,
                        "toplam_tutar": round(s_val if s_val > 0 else (b_tutar * t_adet), 2),
                        "hesap_tipi": "Takas",
                        "_sort_id": int(mr[9] or 0),
                    })
            except Exception as e_mh_tk:
                print(f"[TriaClient] TBL_MAL_HAREKET takas sorgu uyarısı: {e_mh_tk}")

        collected.sort(key=lambda x: (x.get("tarih") or "", int(x.get("_sort_id") or 0)), reverse=True)
        son_takaslar = []
        takas_gelen_kutu = 0
        takas_giden_kutu = 0
        for item in collected[:15]:
            item.pop("_sort_id", None)
            if item["yon"] == "GELEN":
                takas_gelen_kutu += int(item["adet"])
            else:
                takas_giden_kutu += int(item["adet"])
            son_takaslar.append(item)

        return son_takaslar, takas_gelen_kutu, takas_giden_kutu

    def _init_oracle_client(self):
        """Oracle Client (Thick Mode) ve network_admin ayarlarını hazırlar."""
        global _ORACLE_CLIENT_INITIALIZED
        if oracledb is None:
            return
        if self.oracle_client_initialized or _ORACLE_CLIENT_INITIALIZED:
            self.oracle_client_initialized = True
            return

        with _ORACLE_INIT_LOCK:
            if _ORACLE_CLIENT_INITIALIZED:
                self.oracle_client_initialized = True
                return

            client_dir = os.path.join(self.base_dir, "oracle_client", "instantclient_19_23")
            net_admin = os.path.join(self.base_dir, "oracle_client", "network_admin")

            # Eğer paket içindeki oracle_client bulunamazsa tipik konumlardan dene
            if not os.path.exists(client_dir):
                user_profile = os.environ.get("USERPROFILE", "")
                candidate_dirs = [
                    os.path.join(user_profile, "OneDrive", "Masaüstü", "betaprim", "EdaPrim", "instantclient_19_23"),
                    os.path.join(user_profile, "Desktop", "betaprim", "EdaPrim", "instantclient_19_23"),
                    r"C:\instantclient_19_23",
                    r"C:\oracle\instantclient_19_23"
                ]
                for c_dir in candidate_dirs:
                    if os.path.exists(c_dir):
                        client_dir = c_dir
                        break

            try:
                os.makedirs(net_admin, exist_ok=True)
                sqlnet_path = os.path.join(net_admin, "sqlnet.ora")
                if not os.path.exists(sqlnet_path):
                    with open(sqlnet_path, "w", encoding="utf-8") as f:
                        f.write("SQLNET.AUTHENTICATION_SERVICES = (NONE)\n")
            except Exception as e:
                print(f"[TriaClient] sqlnet.ora oluşturma uyarısı: {e}")

            try:
                if os.path.exists(client_dir):
                    os.environ["PATH"] = client_dir + os.pathsep + os.environ.get("PATH", "")
                    if hasattr(os, "add_dll_directory"):
                        try:
                            os.add_dll_directory(client_dir)
                        except Exception:
                            pass
                short_lib = to_short_path(client_dir) if os.path.exists(client_dir) else None
                short_cfg = to_short_path(net_admin) if os.path.exists(net_admin) else None

                # Eğer Windows 10/11'de 8.3 kısa yol kapalıysa ve yolda Türkçe karakter (Masaüstü vb.) varsa
                # geçici olarak client_dir dizinine geçip '.' ile başlatarak DPI-1047 hatasını tamamen önle:
                orig_cwd = os.getcwd()
                try:
                    if short_lib and any(ord(c) > 127 for c in short_lib):
                        os.chdir(client_dir)
                        oracledb.init_oracle_client(lib_dir=".")
                    else:
                        kwargs = {}
                        if short_lib:
                            kwargs["lib_dir"] = short_lib
                        if short_cfg and not any(ord(c) > 127 for c in short_cfg):
                            kwargs["config_dir"] = short_cfg
                        oracledb.init_oracle_client(**kwargs)
                finally:
                    try:
                        os.chdir(orig_cwd)
                    except Exception:
                        pass

                _ORACLE_CLIENT_INITIALIZED = True
                self.oracle_client_initialized = True
                print(f"[TriaClient] Oracle Instant Client Thick Mode aktif: {client_dir}")
            except Exception as e:
                es = str(e)
                if "already been initialized" in es or "DPY-2017" in es:
                    _ORACLE_CLIENT_INITIALIZED = True
                    self.oracle_client_initialized = True
                else:
                    print(f"[TriaClient] Oracle Client başlatma hatası: {e}")

    def _persist_env_settings(self, host: str, port: str, sid: str, user: str, password: str):
        """Başarılı Tria bağlantı bilgilerini .env dosyasına ve ortam değişkenlerine kalıcı olarak yazar."""
        clean_host = (host or "").strip()
        new_tuple = (
            clean_host,
            str(port).strip(),
            (sid or "ORCL").strip(),
            (user or os.environ.get("TRIA_DB_USER", "")).strip(),
            (password or os.environ.get("TRIA_DB_PASSWORD", "")).strip(),
        )
        if self._pool_key is not None and self._pool_key != new_tuple:
            self._drop_pool()
            self._invalidate_caches()
        os.environ["TRIA_DB_HOST"] = clean_host
        os.environ["TRIA_DB_PORT"] = str(port).strip()
        os.environ["TRIA_DB_SID"] = (sid or "ORCL").strip()
        if user:
            os.environ["TRIA_DB_USER"] = user.strip()
        if password:
            os.environ["TRIA_DB_PASSWORD"] = password.strip()
        if clean_host.lower() in ("127.0.0.1", "localhost", "::1") or str(port).strip() == "1522" or (sid or "").strip().upper() == "XEPDB1":
            return
        try:
            env_path = os.path.join(self.base_dir, ".env")
            if os.path.exists(env_path):
                with open(env_path, "r", encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()
                updates = {
                    "TRIA_DB_HOST": clean_host,
                    "TRIA_DB_PORT": str(port).strip(),
                    "TRIA_DB_SID": (sid or "ORCL").strip(),
                }
                if user:
                    updates["TRIA_DB_USER"] = user.strip()
                if password:
                    updates["TRIA_DB_PASSWORD"] = password.strip()
                seen = set()
                new_lines = []
                for line in lines:
                    s = line.strip()
                    if s and not s.startswith("#") and "=" in s:
                        k = s.split("=", 1)[0].strip()
                        if k in updates:
                            new_lines.append(f"{k}={updates[k]}\n")
                            seen.add(k)
                            continue
                    new_lines.append(line)
                for k, v in updates.items():
                    if k not in seen:
                        new_lines.append(f"{k}={v}\n")
                with open(env_path, "w", encoding="utf-8") as f:
                    f.writelines(new_lines)
        except Exception:
            pass

    def get_config(self) -> Dict[str, str]:
        """Güncel bağlantı ayarlarını döndürür."""
        return {
            "user": os.environ.get("TRIA_DB_USER", "").strip(),
            "password": os.environ.get("TRIA_DB_PASSWORD", "").strip(),
            "host": os.environ.get("TRIA_DB_HOST", "").strip() or "127.0.0.1",
            "port": os.environ.get("TRIA_DB_PORT", "1521").strip() or "1521",
            "sid": os.environ.get("TRIA_DB_SID", "ORCL").strip() or "ORCL",
        }

    def _try_auto_unlock_account(self, host: str, port: str, sid: str, target_user: str) -> bool:
        """ORA-28000 (hesap kilitli) durumunda SYSDBA üzerinden hesabı otomatik açar ve şifre kilidi limitini UNLIMITED yapar."""
        if oracledb is None or not target_user:
            return False
        safe_user = "".join(c for c in target_user.strip().upper() if c.isalnum() or c == "_")
        if not safe_user:
            return False
        try:
            dsn = oracledb.makedsn(host, int(port), sid=sid)
        except Exception:
            dsn = f"{host}:{port}/{sid}"

        sys_pwds = ["tria", "TRIA", "manager", "MANAGER", "oracle", "ORACLE", "orcl", "ORCL"]
        for sys_pwd in sys_pwds:
            wrong_sys_pwd = False
            for _ in range(8):
                conn = None
                try:
                    conn = oracledb.connect(
                        user="SYS",
                        password=sys_pwd,
                        dsn=dsn,
                        mode=oracledb.AUTH_MODE_SYSDBA,
                        tcp_connect_timeout=2.0,
                    )
                    cur = conn.cursor()
                    cur.execute(f"ALTER USER {safe_user} ACCOUNT UNLOCK")
                    try:
                        cur.execute("ALTER PROFILE DEFAULT LIMIT FAILED_LOGIN_ATTEMPTS UNLIMITED PASSWORD_LIFE_TIME UNLIMITED")
                    except Exception:
                        pass
                    cur.close()
                    conn.close()
                    print(f"[TriaClient] '{safe_user}' Oracle hesabı (ORA-28000) otomatik olarak açıldı ve UNLIMITED yapıldı.")
                    return True
                except Exception as e:
                    if conn is not None:
                        try:
                            conn.close()
                        except Exception:
                            pass
                    es = str(e)
                    if "ORA-01017" in es or "ORA-01031" in es:
                        wrong_sys_pwd = True
                        break
                    if any(k in es for k in ("DPY-4011", "ORA-00028", "ORA-03113", "ORA-01012", "DPI-1080")):
                        time.sleep(0.08)
                        continue
                    break
            if wrong_sys_pwd:
                continue
        return False

    def _open_and_verify_conn(self, host: str, port: str, sid: str, user: str, password: str, timeout: float = 3.0):
        """Oracle bağlantısını açar, Tria servisi uyumluluk bilgilerini ayarlar ve canlı sorgu ile doğrular."""
        dsn = f"{host}:{port}/{sid}"
        auth_key = (host.strip(), user.strip().upper(), password.strip())
        bad_ts = self._bad_auth_cache.get(auth_key)
        if bad_ts and (time.time() - bad_ts) < 60.0:
            raise RuntimeError(f"ORA-01017: '{user}' şeması için girilen şifre hatalı (hesap kilitlenmesini önlemek için deneme durduruldu).")

        last_err = None
        unlocked_once = False
        for attempt in range(6):
            conn = None
            try:
                conn = oracledb.connect(user=user, password=password, dsn=dsn, tcp_connect_timeout=timeout)
                try:
                    conn.module = "Tria.exe"
                    conn.action = "Tria"
                except Exception:
                    pass
                cur = conn.cursor()
                cur.execute("SELECT 1 FROM TBL_MAL_TANIM WHERE ROWNUM = 1")
                cur.fetchone()
                cur.close()
                self._bad_auth_cache.pop(auth_key, None)
                return conn
            except Exception as err:
                last_err = err
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass
                err_str = str(err)
                # ORA-28000 (the account is locked) -> Otomatik SYSDBA kilit açıcıyı çalıştır ve tekrar dene
                if "ORA-28000" in err_str and not unlocked_once:
                    unlocked_once = True
                    if self._try_auto_unlock_account(host, port, sid, user):
                        time.sleep(0.1)
                        continue
                    break
                # ORA-01017 (hatalı şifre) -> Hesabı kilitlememek için ASLA tekrar deneme!
                if "ORA-01017" in err_str:
                    self._bad_auth_cache[auth_key] = time.time()
                    break
                # DPY-4011 / ORA-00028 / ORA-03113 / ORA-01012 (ProcessDB anlık oturum kesmesi) -> hızlı tekrar dene
                if attempt < 5 and any(k in err_str for k in ("DPY-4011", "ORA-00028", "ORA-03113", "ORA-03135", "ORA-01012", "DPI-1080")):
                    time.sleep(0.08)
                    continue
                break
        raise last_err

    def _acquire_or_init_pool(self, vh: str, vp: str, vs: str, vu: str, vpw: str, fallback_conn: Any = None):
        """Doğrulanmış TRIA Oracle hedefi için kalıcı bağlantı havuzu (ConnectionPool) kurar veya mevcut havuzdan <0.2ms'de oturum alır."""
        target_key = (vh, vp, vs, vu, vpw)
        with self._pool_lock:
            if self._pool is not None and self._pool_key == target_key:
                try:
                    raw_c = self._pool.acquire()
                    if fallback_conn is not None:
                        try:
                            fallback_conn.close()
                        except Exception:
                            pass
                    return _PooledConnWrapper(raw_c, self._pool, self._drop_pool)
                except Exception:
                    try:
                        self._pool.close(force=True)
                    except Exception:
                        pass
                    self._pool = None
                    self._pool_key = None

            if self._pool is not None:
                try:
                    self._pool.close(force=True)
                except Exception:
                    pass
                self._pool = None
                self._pool_key = None

            def _session_cb(connection, requested_tag):
                try:
                    connection.module = "Tria.exe"
                    connection.action = "Tria"
                except Exception:
                    pass

            try:
                new_pool = oracledb.create_pool(
                    user=vu,
                    password=vpw,
                    dsn=f"{vh}:{vp}/{vs}",
                    min=1,
                    max=4,
                    increment=1,
                    ping_interval=45,
                    timeout=120,
                    wait_timeout=4000,
                    getmode=oracledb.POOL_GETMODE_WAIT,
                    session_callback=_session_cb,
                )
                raw_c = new_pool.acquire()
                self._pool = new_pool
                self._pool_key = target_key
                if fallback_conn is not None:
                    try:
                        fallback_conn.close()
                    except Exception:
                        pass
                return _PooledConnWrapper(raw_c, new_pool, self._drop_pool)
            except Exception:
                if fallback_conn is not None:
                    return _PooledConnWrapper(fallback_conn, None, None)
                raise

    def get_connection(self, host: Optional[str] = None, port: Optional[str] = None,
                       sid: Optional[str] = None, user: Optional[str] = None,
                       password: Optional[str] = None):
        """Oracle bağlantısını açar (kalıcı LAN bağlantı havuzu + otomatik port, SID, şema ve ağ sunucusu düzeltme destekli)."""
        if oracledb is None:
            raise RuntimeError("oracledb kütüphanesi yüklü değil. 'pip install oracledb' gereklidir.")

        import socket
        self._init_oracle_client()
        cfg = self.get_config()
        active_host = (host or cfg.get("host") or "127.0.0.1").strip()
        active_port = str(port or cfg.get("port") or "1521").strip()
        active_sid = (sid or cfg.get("sid") or "ORCL").strip()
        active_user = (user or cfg.get("user") or "").strip()
        active_pwd = (password or cfg.get("password") or active_user).strip()

        req_key = (active_host, active_port, active_sid, active_user, active_pwd)
        cfg_default_key = (
            (cfg.get("host") or "127.0.0.1").strip(),
            str(cfg.get("port") or "1521").strip(),
            (cfg.get("sid") or "ORCL").strip(),
            (cfg.get("user") or "").strip(),
            (cfg.get("password") or (cfg.get("user") or "")).strip(),
        )
        can_use_pool = (req_key == cfg_default_key) or (self._pool_key == req_key)

        # HIZLI YOL: Havuz hazırsa LAN üzerinde yeni TCP + TNS el sıkışması yapmadan ~0.1 ms'de oturum al!
        if can_use_pool and self._pool is not None and self._pool_key == req_key:
            try:
                raw_conn = self._pool.acquire()
                return _PooledConnWrapper(raw_conn, self._pool, self._drop_pool)
            except Exception:
                self._drop_pool()

        def _is_tcp_open(h: str, p: str, t: float = 0.45) -> bool:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(t)
                    return s.connect_ex((h, int(p))) == 0
            except Exception:
                return False

        last_error = None
        auth_error_stopped = False
        if active_host and active_user and _is_tcp_open(active_host, active_port, 0.45):
            for s_try in list(dict.fromkeys([active_sid, "ORCL", "XEPDB1", "XE"])):
                try:
                    conn = self._open_and_verify_conn(active_host, active_port, s_try, active_user, active_pwd, timeout=3.0)
                    if s_try != active_sid:
                        self._persist_env_settings(active_host, active_port, s_try, active_user, active_pwd)
                    if can_use_pool or s_try != active_sid:
                        return self._acquire_or_init_pool(active_host, active_port, s_try, active_user, active_pwd, fallback_conn=conn)
                    return _PooledConnWrapper(conn, None, None)
                except Exception as e:
                    last_error = e
                    es = str(e)
                    # Şifre hatalıysa (ORA-01017) veya hesap kilitliyse (ORA-28000) diğer SID'leri deneyip hesabı kilitleme!
                    if "ORA-01017" in es or "ORA-28000" in es:
                        auth_error_stopped = True
                        break

        # Sadece ağ/sunucu erişim hatası varsa yerel ağda keşif yap; şifre/kilit hatasında keşif yapıp hesabı kilitleme
        if not auth_error_stopped:
            disc = self.discover_tria_host()
            if disc.get("found") and disc.get("host"):
                dh = disc["host"]
                dp = str(disc.get("port", "1521"))
                ds = disc.get("sid", "ORCL")
                du = disc.get("user") or active_user
                dpw = disc.get("password") or active_pwd or du
                if du:
                    try:
                        conn = self._open_and_verify_conn(dh, dp, ds, du, dpw, timeout=3.0)
                        self._persist_env_settings(dh, dp, ds, du, dpw)
                        return self._acquire_or_init_pool(dh, dp, ds, du, dpw, fallback_conn=conn)
                    except Exception as e:
                        last_error = e

        if last_error:
            raise last_error
        raise RuntimeError(f"Tria Oracle sunucusuna ({active_host}:{active_port}/{active_sid}) bağlanılamadı. Lütfen Ayarlar > TRIA sekmesinden sunucu IP ve şema adını kontrol edin.")

    def ping(self, host: Optional[str] = None, port: Optional[str] = None,
             sid: Optional[str] = None, user: Optional[str] = None,
             password: Optional[str] = None) -> Dict[str, Any]:
        """Tria Oracle veritabanına ping atar ve bağlantı durumunu test eder (<10ms katalog istatistikli)."""
        cfg = self.get_config()
        active_host = (host or cfg.get("host") or "127.0.0.1").strip()
        active_port = str(port or cfg.get("port") or "1521").strip()
        active_sid = (sid or cfg.get("sid") or "ORCL").strip()
        active_user = (user or cfg.get("user") or "").strip()
        active_pwd = (password or cfg.get("password") or active_user).strip()
        t0 = time.time()
        try:
            with self.get_connection(host=active_host, port=active_port, sid=active_sid, user=active_user, password=active_pwd) as conn:
                cfg_now = self.get_config()
                active_host = cfg_now.get("host", active_host)
                active_port = cfg_now.get("port", active_port)
                active_sid = cfg_now.get("sid", active_sid)
                active_user = cfg_now.get("user", active_user)
                latency_ms = round((time.time() - t0) * 1000, 2)
                cur = conn.cursor()

                # 138k+ satırlık tam tablo COUNT(*) yerine USER_TABLES istatistikleri (<2ms)
                cur.execute("""
                    SELECT TABLE_NAME, NVL(NUM_ROWS, 0)
                    FROM USER_TABLES
                    WHERE TABLE_NAME IN ('TBL_RECETE', 'TBL_MAL_TANIM', 'TBL_BELGE')
                """)
                num_rows_map = {str(r[0]): int(r[1] or 0) for r in cur.fetchall()}
                recete_count = num_rows_map.get("TBL_RECETE", 0)
                mal_count = num_rows_map.get("TBL_MAL_TANIM", 0)
                fatura_count = num_rows_map.get("TBL_BELGE", 0)

                if mal_count <= 0 and self._prod_index is not None:
                    mal_count = len(self._prod_index.get("by_id", {}))
                if mal_count <= 0:
                    cur.execute("SELECT COUNT(*) FROM TBL_MAL_TANIM")
                    mal_count = int(cur.fetchone()[0] or 0)

                # Bugün kesilen reçete sayısı (RECETE_TARIHI indeksli -> <2ms)
                cur.execute("SELECT COUNT(*) FROM TBL_RECETE WHERE RECETE_TARIHI >= TRUNC(SYSDATE)")
                today_recete = int(cur.fetchone()[0] or 0)

                return {
                    "success": True,
                    "connected": True,
                    "message": f"Tria Oracle bağlantısı başarılı ({latency_ms} ms)",
                    "latency_ms": latency_ms,
                    "version": conn.version,
                    "host": active_host,
                    "port": active_port,
                    "sid": active_sid,
                    "user": active_user,
                    "stats": {
                        "recete_sayisi": recete_count,
                        "kayitli_urun_sayisi": mal_count,
                        "bugun_recete_sayisi": today_recete,
                        "fatura_sayisi": fatura_count
                    }
                }
        except Exception as e:
            latency_ms = round((time.time() - t0) * 1000, 2)
            err_msg = str(e)
            user_friendly = err_msg
            if "12541" in err_msg:
                user_friendly = f"Oracle Dinleyici Bulunamadı (ORA-12541). '{active_host}' makinesinde {active_port} portunda Oracle listener çalışmıyor veya farklı bir ağdasınız."
            elif "12514" in err_msg:
                user_friendly = f"Veritabanı Servisi Bulunamadı (ORA-12514). '{active_sid}' SID/Servis adı geçersiz."
            elif "01017" in err_msg:
                user_friendly = f"Kullanıcı adı veya şifre hatalı (ORA-01017). '{active_user}' şeması için şifreyi kontrol ediniz."
            return {
                "success": False,
                "connected": False,
                "message": user_friendly,
                "latency_ms": latency_ms,
                "host": active_host,
                "port": active_port,
                "sid": active_sid,
                "user": active_user,
                "error": err_msg
            }

    def get_product_analysis(self, query: str, barcode: str = "") -> Dict[str, Any]:
        """
        Belirtilen barkod veya ilaç adı için Tria veritabanından:
        1. Anlık raf/mevcut stok (Golden Formula: İade/Emanet düzeltmeli)
        2. Son 6 takvim ayı Nakit ve Reçeteli çıkış adetleri (ÇIKIŞ)
        3. Son depolardan gelen alış faturaları (GİRİŞ)
        4. Aylık ortalama çıkış hızı ve kalan gün tahmini
        5. Akıllı sipariş önerisi
        döndürür.
        """
        clean_q = (barcode or query or "").strip()
        if not clean_q:
            return {"found": False, "message": "Barkod veya ürün belirtilmedi."}

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                # 1. Ürünü bul (Önce 0.02ms RAM indeksi, bulunamazsa canlı SQL geri dönüşü)
                pidx = self._ensure_product_index(cur)
                by_id = pidx["by_id"]
                by_bc = pidx["by_barcode"]
                by_code = pidx["by_code"]
                product_row = None

                # A) Eğer doğrudan barkod verilmişse veya clean_q barkod ise
                target_barcodes = []
                for cand_raw in (barcode, clean_q):
                    cr = str(cand_raw or "").strip()
                    if cr and cr.isdigit() and len(cr) >= 8 and cr not in target_barcodes:
                        target_barcodes.append(cr)

                if target_barcodes:
                    try:
                        from backend.catalog import catalog
                        for b in list(target_barcodes):
                            can = catalog.resolve_canonical_barcode(b)
                            if can and can not in target_barcodes:
                                target_barcodes.append(can)
                            for ab in catalog.get_all_related_barcodes(b):
                                ab_s = str(ab or "").strip()
                                if ab_s and ab_s not in target_barcodes:
                                    target_barcodes.append(ab_s)
                    except Exception:
                        pass

                    for bc in target_barcodes:
                        mid_hit = by_bc.get(bc) or by_code.get(bc)
                        if mid_hit and mid_hit in by_id:
                            ent = by_id[mid_hit]
                            product_row = (ent["id"], ent["mal_kodu"], ent["raw_name"], ent["primary_barcode"] or bc)
                            break

                    if not product_row and target_barcodes and (time.time() - self._prod_index_ts) > 30.0:
                        b_params = {f"b{i}": v for i, v in enumerate(target_barcodes[:25])}
                        b_in = ",".join(f":b{i}" for i in range(len(b_params)))
                        cur.execute(f"""
                            SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(b.BARKOD, '') as BARKOD
                            FROM TBL_MAL_TANIM t
                            LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                            WHERE (b.BARKOD IN ({b_in}) OR t.MAL_KODU IN ({b_in}))
                              AND (t.PASIF IS NULL OR t.PASIF = 0)
                              AND ROWNUM <= 1
                        """, b_params)
                        product_row = cur.fetchone()

                # B) Kısa Sayısal Kod araması (8+ haneli barkod değilse)
                if not product_row and clean_q.isdigit() and len(clean_q) < 8:
                    mid_hit = by_code.get(clean_q) or by_code.get(clean_q.lstrip("0")) or (int(clean_q) if int(clean_q) in by_id else None)
                    if mid_hit and mid_hit in by_id:
                        ent = by_id[mid_hit]
                        product_row = (ent["id"], ent["mal_kodu"], ent["raw_name"], ent["primary_barcode"])
                    else:
                        cur.execute("""
                            SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(b.BARKOD, '') as BARKOD
                            FROM TBL_MAL_TANIM t
                            LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                            WHERE (t.MAL_KODU = :raw_q OR t.ID = TO_NUMBER(:raw_q))
                              AND (t.PASIF IS NULL OR t.PASIF = 0)
                              AND ROWNUM <= 1
                        """, {"raw_q": clean_q})
                        product_row = cur.fetchone()

                # C) İsim araması (Yalnızca metin sorgularında; 8+ haneli barkodda gereksiz LIKE taraması yapma!)
                if not product_row and not (clean_q.isdigit() and len(clean_q) >= 8):
                    tr_query = clean_q.upper().replace("I", "İ").replace("ı", "I")
                    cur.execute("""
                        SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(b.BARKOD, '') as BARKOD
                        FROM TBL_MAL_TANIM t
                        LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                        WHERE (UPPER(t.MAL_ADI) LIKE :q OR UPPER(t.MAL_ADI) LIKE :raw_q)
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                          AND ROWNUM <= 1
                    """, {"q": f"%{tr_query}%", "raw_q": f"%{clean_q.upper()}%"})
                    product_row = cur.fetchone()

                if not product_row:
                    return {
                        "found": False,
                        "connected": True,
                        "kaynak": "TRIA",
                        "message": f"'{clean_q}' Tria kayıtlarında bulunamadı."
                    }

                mal_id, mal_kodu, mal_adi, found_barkod = product_row
                final_barcode = barcode or found_barkod or clean_q
                try:
                    from backend.catalog import catalog
                    can_final = catalog.resolve_canonical_barcode(final_barcode)
                    if can_final:
                        final_barcode = can_final
                except Exception:
                    pass

                # 2. Anlık Altın Stok (Golden Formula - MAL_ID indeksli <2ms)
                cur.execute("""
                    SELECT NVL(
                        SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) - 
                        SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END), 
                        0
                    ) 
                    FROM TBL_MAL_MIKTARLAR m 
                    WHERE m.MAL_ID = :mid
                """, {"mid": mal_id})
                stok_val = cur.fetchone()[0] or 0.0
                stok = int(round(stok_val)) if stok_val == int(stok_val) else round(stok_val, 1)

                # 3. Son 6 Aylık Satış / Çıkış Trendi (MAL_HAREKET_MAL_KODU indeksli <3ms)
                pcode_cands = _mal_kodu_variants(str(mal_kodu))
                p_binds = {f"pk{i}": v for i, v in enumerate(pcode_cands)}
                p_in = ",".join(f":pk{i}" for i in range(len(pcode_cands)))
                cur.execute(f"""
                    SELECT 
                        TO_CHAR(BELGE_TARIHI, 'YYYY-MM') as AY,
                        SUM(CASE WHEN (BELGE_TURU = 'FIS' OR UPPER(TRIM(BELGE_TURU)) = 'FIS') AND BELGE_TIP_NO IN ('01', '06') THEN MIKTAR ELSE 0 END) as NAKIT,
                        SUM(CASE WHEN (BELGE_TURU = 'RECETE' OR UPPER(TRIM(BELGE_TURU)) = 'RECETE') THEN MIKTAR ELSE 0 END) as RECETELI,
                        SUM(CASE 
                            WHEN (BELGE_TURU = 'FIS' OR UPPER(TRIM(BELGE_TURU)) = 'FIS') AND BELGE_TIP_NO IN ('01', '06') THEN MIKTAR 
                            WHEN (BELGE_TURU = 'RECETE' OR UPPER(TRIM(BELGE_TURU)) = 'RECETE') THEN MIKTAR 
                            ELSE 0 
                        END) as TOPLAM
                    FROM TBL_MAL_HAREKET
                    WHERE MAL_KODU IN ({p_in})
                      AND BELGE_TARIHI >= ADD_MONTHS(TRUNC(SYSDATE, 'MM'), -6)
                      AND BELGE_TARIHI <= SYSDATE + 1
                    GROUP BY TO_CHAR(BELGE_TARIHI, 'YYYY-MM')
                    ORDER BY AY ASC
                """, p_binds)
                
                rows = cur.fetchall()

                ay_isimleri = {
                    "01": "Ocak", "02": "Şubat", "03": "Mart", "04": "Nisan",
                    "05": "Mayıs", "06": "Haziran", "07": "Temmuz", "08": "Ağustos",
                    "09": "Eylül", "10": "Ekim", "11": "Kasım", "12": "Aralık"
                }

                activity_by_month = {}
                for r in rows:
                    ay_str = str(r[0])
                    activity_by_month[ay_str] = {
                        "nakit": int(r[1] or 0),
                        "receteli": int(r[2] or 0),
                        "toplam": int(r[3] or 0)
                    }

                # Kesintisiz son 6 takvim ayını oluştur
                today = datetime.date.today()
                aylik_cikislar = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    m_str = f"{m_calc:02d}"
                    ym_key = f"{y_calc}-{m_str}"
                    is_current_month = (i == 0)
                    suffix = " (Bu Ay)" if is_current_month else ""
                    ay_label = f"{ay_isimleri.get(m_str, m_str)} '{str(y_calc)[-2:]}{suffix}"
                    
                    act = activity_by_month.get(ym_key, {"nakit": 0, "receteli": 0, "toplam": 0})
                    aylik_cikislar.append({
                        "ay": ym_key,
                        "label": ay_label,
                        "is_current": is_current_month,
                        "nakit": act["nakit"],
                        "receteli": act["receteli"],
                        "toplam": act["toplam"]
                    })

                # Ortalama aylık ve günlük çıkış hesabı
                gecmis_aylar = aylik_cikislar[:-1] if len(aylik_cikislar) > 1 else aylik_cikislar
                gecmis_sum = sum(x["toplam"] for x in gecmis_aylar)
                if gecmis_sum > 0:
                    ort_aylik = round(gecmis_sum / max(1, len(gecmis_aylar)), 1)
                else:
                    ort_aylik = round(sum(x["toplam"] for x in aylik_cikislar) / max(1, len(aylik_cikislar)), 1)
                
                ort_gunluk = round(ort_aylik / 30.0, 2)

                # Kalan gün ve stok durumu
                if ort_gunluk > 0:
                    kalan_gun = int(round(stok / ort_gunluk))
                else:
                    kalan_gun = 999 if stok > 0 else 0

                toplam_6_aylik_cikis = sum(x["toplam"] for x in aylik_cikislar)
                is_hareketsiz = (stok <= 0 and toplam_6_aylik_cikis == 0)

                if is_hareketsiz:
                    stok_status = "HAREKET YOK"
                    stok_status_color = "slate"
                    onerilen_siparis = 1
                elif stok <= 0:
                    stok_status = "TÜKENDİ"
                    stok_status_color = "red"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(1, hedef_stok - stok)
                elif kalan_gun < 10:
                    stok_status = "KRİTİK AZ"
                    stok_status_color = "amber"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                elif kalan_gun <= 30:
                    stok_status = "YETERLİ"
                    stok_status_color = "emerald"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                else:
                    stok_status = "YÜKSEK STOK"
                    stok_status_color = "sky"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)

                # 4. Son Alış Faturaları / Depo Girişleri (Gerçek KDV Dahil & MF/İskonto Düşülmüş Birim Maliyet — BELGEDETAY_MKODU_NDX <3ms)
                cur.execute(f"""
                    SELECT * FROM (
                        SELECT 
                            TO_CHAR(b.BELGE_TARIHI, 'YYYY-MM-DD') as TARIH,
                            NVL(UTL_RAW.CAST_TO_RAW(b.CARI_ADI), UTL_RAW.CAST_TO_RAW('DIGER DEPO')) as DEPO,
                            NVL(d.MIKTAR, 0) as ADET,
                            NVL(d.MF_MIKTAR, 0) as MF,
                            ROUND(NVL(d.BIRIM_FIYAT, 0), 2) as BIRIM_FIYAT,
                            ROUND(NVL(d.NET_FIYAT, 0), 2) as NET_FIYAT,
                            NVL(b.BELGE_NO, NVL(b.D_FATURA_NO, '')) as FATURA_NO,
                            b.TIP_NO,
                            NVL(b.KDV_DURUMU, 0) as KDV_DURUMU,
                            NVL(d.TUTAR, 0) as TUTAR,
                            NVL(d.KDV, 0) as KDV,
                            NVL(d.KDV_TUTAR, 0) as KDV_TUTAR,
                            (
                                NVL(d.ISKONTO_TUTAR1, 0) + NVL(d.ISKONTO_TUTAR2, 0) +
                                NVL(d.ISKONTO_TUTAR3, 0) + NVL(d.ISKONTO_TUTAR4, 0) +
                                NVL(d.ISKONTO_TUTAR5, 0) + NVL(d.DIP_ISKONTO, 0)
                            ) as TOT_ISK
                        FROM TBL_BELGE_DETAY d
                        JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                        WHERE d.MAL_KODU IN ({p_in})
                          AND (b.TIP_NO IN ('AAF', 'KAF', 'ASIF', 'TGF') OR UPPER(TRIM(NVL(b.TIP_NO, ''))) IN ('AAF', 'KAF', 'ASIF', 'TGF'))
                          AND NVL(d.MIKTAR, 0) > 0
                        ORDER BY b.BELGE_TARIHI DESC, b.ID DESC, d.ID DESC
                    ) WHERE ROWNUM <= 6
                """, p_binds)
                giris_rows = cur.fetchall()

                son_girisler = []
                toplam_giren_kutu = 0
                son_alis_ozet = None
                for gr in giris_rows:
                    g_adet = int(round(float(gr[2] or 0)))
                    g_mf = int(round(max(0.0, float(gr[3] or 0))))
                    g_birim = round(float(gr[4] or 0.0), 2)
                    g_net_raw = round(float(gr[5] or 0.0), 2)
                    g_tip = str(gr[7] or "").strip().upper()
                    g_kdvd = int(gr[8] or 0)
                    g_tut = float(gr[9] or 0.0)
                    g_kdv = float(gr[10] or 0.0)
                    g_kdvt = max(0.0, float(gr[11] or 0.0))
                    g_isk = max(0.0, float(gr[12] or 0.0))
                    top_satir = max(1, g_adet + g_mf)
                    kdv_mult_g = 1.0 + (max(0.0, g_kdv) / 100.0)
                    if g_tut > 0 and top_satir > 0:
                        if g_kdvd == 1:
                            net_kdvli_tot = max(0.0, g_tut - g_isk)
                            g_maliyet_kdvli = round(net_kdvli_tot / top_satir, 2)
                            if 0.0 < g_kdvt < net_kdvli_tot:
                                g_maliyet_kdvsiz = round((net_kdvli_tot - g_kdvt) / top_satir, 2)
                            else:
                                g_maliyet_kdvsiz = round(g_maliyet_kdvli / kdv_mult_g, 2) if kdv_mult_g > 0 else g_maliyet_kdvli
                        else:
                            net_kdvsiz_tot = max(0.0, g_tut - g_isk)
                            g_maliyet_kdvsiz = round(net_kdvsiz_tot / top_satir, 2)
                            if g_kdvt > 0:
                                g_maliyet_kdvli = round((net_kdvsiz_tot + g_kdvt) / top_satir, 2)
                            else:
                                g_maliyet_kdvli = round(g_maliyet_kdvsiz * kdv_mult_g, 2)
                    else:
                        g_maliyet_kdvsiz = g_net_raw
                        g_maliyet_kdvli = round(g_net_raw * kdv_mult_g, 2) if g_net_raw > 0 else 0.0

                    g_depo_str = re.sub(r"\s+", " ", fix_tria_str(gr[1])).strip() or "DİĞER DEPO"
                    if g_tip == "TGF" and not g_depo_str.upper().startswith("TAKAS"):
                        g_depo_str = f"Takas: {g_depo_str}"
                    t_iso = str(gr[0] or "")
                    t_pts = t_iso.split("-") if "-" in t_iso else []
                    t_tr = f"{t_pts[2]}.{t_pts[1]}.{t_pts[0]}" if len(t_pts) == 3 else t_iso

                    toplam_giren_kutu += (g_adet + g_mf)
                    son_girisler.append({
                        "tarih": t_iso,
                        "tarih_tr": t_tr,
                        "depo": g_depo_str,
                        "adet": g_adet,
                        "mf": g_mf,
                        "toplam_adet": g_adet + g_mf,
                        "birim_fiyat": g_birim,
                        "maliyet": g_maliyet_kdvli,
                        "maliyet_kdvli": g_maliyet_kdvli,
                        "maliyet_kdvsiz": g_maliyet_kdvsiz,
                        "fatura_no": str(gr[6] or "")
                    })
                    if son_alis_ozet is None and g_maliyet_kdvli > 0:
                        son_alis_ozet = {
                            "birim_maliyet_kdvli": g_maliyet_kdvli,
                            "birim_maliyet_kdvsiz": g_maliyet_kdvsiz,
                            "tarih": t_tr,
                            "tarih_iso": t_iso,
                            "depo": g_depo_str,
                            "adet": g_adet,
                            "mf": g_mf,
                            "mf_etiket": f"{g_adet}+{g_mf} MF" if g_mf > 0 else (f"{g_adet} Adet" if g_adet > 0 else "MF Yok"),
                            "kdv_dahil": True,
                        }

                # 5. Takas Hareketleri (TBL_TAKAS + TBL_TAKAS_DETAY ve TBL_BELGE TGF/TÇF/TCF Birleşik)
                son_takaslar, takas_gelen_kutu, takas_giden_kutu = self._fetch_tria_takas_movements(cur, str(mal_kodu), mal_id)

                return {
                    "found": True,
                    "connected": True,
                    "kaynak": "TRIA",
                    "otomasyon_adi": "Tria Eczane",
                    "urun_id": mal_id,
                    "mal_id": mal_id,
                    "mal_kodu": str(mal_kodu),
                    "mal_adi": fix_tria_str(mal_adi),
                    "barkod": final_barcode,
                    "stok": stok,
                    "stok_depo": 0,
                    "stok_raf": stok,
                    "stok_acik": 0,
                    "kalan_gun": kalan_gun,
                    "stok_status": stok_status,
                    "stok_status_color": stok_status_color,
                    "ort_aylik_cikis": ort_aylik,
                    "ort_gunluk_cikis": ort_gunluk,
                    "onerilen_siparis": onerilen_siparis,
                    "aylik_cikislar": aylik_cikislar,
                    "son_girisler": son_girisler,
                    "son_alis_ozet": son_alis_ozet,
                    "toplam_giren_kutu": toplam_giren_kutu,
                    "son_takaslar": son_takaslar,
                    "takas_gelen_kutu": takas_gelen_kutu,
                    "takas_giden_kutu": takas_giden_kutu,
                    "hareketsiz_kart": is_hareketsiz,
                    "hareketsiz_aciklama": "Eczanenizde bu ürün için son 6 aydır çıkış hareketi bulunmuyor. Depo ve piyasa koşulları doğrudan üretici EAN barkodu üzerinden sunulmaktadır."
                }

        except Exception as e:
            return {
                "found": False,
                "connected": False,
                "kaynak": "TRIA",
                "error": str(e),
                "message": f"Tria stok ve hareket sorgusu hatası: {str(e)}"
            }

    def _fetch_today_open_emanet_map(self, cur) -> Dict[str, int]:
        """
        Bugün TRIA üzerinde hastaya verilmiş ve henüz reçeteye/nakit fişe kapatılmamış
        (iade de alınmamış) AÇIK EMANET çıkışlarını MAL_KODU bazında döndürür (%100 SELECT).
        NOT: TBL_MAL_HAREKET(HAREKET_ID) üzerinde indeks olmadığından ilişkili alt sorgu yerine
        MAL_HAREKET_TARIH_NX indeksini kullanan tek geçişli LEFT JOIN kullanılır (<3 ms).
        """
        out: Dict[str, int] = {}
        try:
            cur.execute("""
                SELECT e.MAL_KODU,
                       SUM(GREATEST(0, ABS(NVL(e.MIKTAR, 0)) - NVL(k.KAPATILAN, 0))) AS EMANET_ADET
                FROM TBL_MAL_HAREKET e
                LEFT JOIN (
                    SELECT kh.HAREKET_ID, SUM(ABS(NVL(kh.MIKTAR, 0))) AS KAPATILAN
                    FROM TBL_MAL_HAREKET kh
                    WHERE kh.BELGE_TARIHI >= TRUNC(SYSDATE)
                      AND kh.HAREKET_ID IS NOT NULL
                      AND (
                          kh.BELGE_TURU = 'EMANET_KAPATMA'
                          OR UPPER(TRIM(kh.BELGE_TURU)) = 'EMANET_KAPATMA'
                          OR NVL(kh.NORMAL_IADE_DURUMU, 0) = 1
                      )
                    GROUP BY kh.HAREKET_ID
                ) k ON k.HAREKET_ID = e.ID
                WHERE e.BELGE_TARIHI >= TRUNC(SYSDATE)
                  AND (e.BELGE_TURU = 'EMANET' OR UPPER(TRIM(e.BELGE_TURU)) = 'EMANET')
                  AND NVL(e.GIRIS_CIKIS_DURUMU, 1) = 1
                  AND NVL(e.NORMAL_IADE_DURUMU, 0) = 0
                GROUP BY e.MAL_KODU
                HAVING SUM(GREATEST(0, ABS(NVL(e.MIKTAR, 0)) - NVL(k.KAPATILAN, 0))) > 0
            """)
            for r_code, r_qty in cur.fetchall():
                if r_code:
                    c_clean = str(r_code).strip()
                    q_int = int(round(float(r_qty or 0)))
                    if c_clean and c_clean not in EXCLUDE_MAL_KODLARI and q_int > 0:
                        out[c_clean] = q_int
        except Exception as e_em:
            print(f"[Tria] Bugün açık emanet sorgu uyarısı: {e_em}")
        return out

    def _fetch_mf_history_cached(self, cur, prod_codes: List[str], short_prefix: bool = False) -> Dict[str, Dict[str, Any]]:
        """
        Verilen MAL_KODU listesi için son 36 aydaki MF'li fatura geçmişini BELGEDETAY_MKODU_NDX
        indeksi üzerinden toplu çeker ve 15 dk bellekte tutar (%100 SELECT).
        """
        now = time.time()
        ttl = 900.0
        result: Dict[str, Dict[str, Any]] = {}
        missing: List[str] = []

        for mk in prod_codes:
            c_hit = self._mf_hist_cache.get(mk)
            if c_hit is not None and (now - c_hit[0]) < ttl:
                data = c_hit[1]
                if data.get("var"):
                    entry = dict(data)
                    if short_prefix:
                        entry["kisa"] = f"Son: {entry['kisa_raw']} MF"
                    result[mk] = entry
            else:
                missing.append(mk)

        if missing:
            fetched_map: Dict[str, Dict[str, Any]] = {}
            try:
                for i in range(0, len(missing), 900):
                    chunk = missing[i:i + 900]
                    params = {f"k{idx}": c for idx, c in enumerate(chunk)}
                    binds = ",".join(f":{k}" for k in params.keys())
                    cur.execute(f"""
                        SELECT MAL_KODU, MIKTAR, MF_MIKTAR, TO_CHAR(BELGE_TARIHI, 'YYYY-MM-DD'), ALIM_COUNT, DEPO_RAW
                        FROM (
                            SELECT
                                d.MAL_KODU,
                                d.MIKTAR,
                                d.MF_MIKTAR,
                                b.BELGE_TARIHI,
                                COUNT(*) OVER (PARTITION BY d.MAL_KODU) as ALIM_COUNT,
                                NVL(UTL_RAW.CAST_TO_RAW(b.CARI_ADI), UTL_RAW.CAST_TO_RAW('')) as DEPO_RAW,
                                ROW_NUMBER() OVER (PARTITION BY d.MAL_KODU ORDER BY b.BELGE_TARIHI DESC, b.ID DESC) as RN
                            FROM TBL_BELGE_DETAY d
                            JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                            WHERE d.MAL_KODU IN ({binds})
                              AND b.BELGE_TARIHI >= ADD_MONTHS(TRUNC(SYSDATE), -36)
                              AND b.TIP_NO IN ('AAF', 'KAF', 'TGF')
                              AND NVL(d.MF_MIKTAR, 0) > 0
                        ) WHERE RN = 1
                    """, params)
                    for r in cur.fetchall():
                        m_k = str(r[0] or "").strip()
                        m_adet = int(r[1] or 0)
                        m_mf = int(r[2] or 0)
                        raw_dt = str(r[3] or "")
                        if raw_dt and "-" in raw_dt:
                            pts = raw_dt.split("-")
                            fmt_dt = f"{pts[2]}.{pts[1]}.{pts[0]}" if len(pts) == 3 else raw_dt
                        else:
                            fmt_dt = raw_dt
                        cnt = int(r[4] or 1)
                        depo_adi = fix_tria_str(r[5]).strip() if r[5] else ""
                        kisa_raw = f"{m_adet}+{m_mf}" if m_adet > 0 else f"+{m_mf}"
                        fetched_map[m_k] = {
                            "var": True,
                            "sayisi": cnt,
                            "son_adet": m_adet,
                            "son_mf": m_mf,
                            "son_tarih": fmt_dt,
                            "son_depo": depo_adi,
                            "kisa_raw": kisa_raw,
                            "kisa": kisa_raw,
                            "bilgi": f"Geçmişte {cnt} kez MF'li alındı (Son: {kisa_raw} MF, {fmt_dt})",
                        }
            except Exception as e_mf:
                print(f"[Tria] Geçmiş MF sorgu uyarısı: {e_mf}")

            now_done = time.time()
            for mk in missing:
                val = fetched_map.get(mk)
                if val:
                    self._mf_hist_cache[mk] = (now_done, val)
                    entry = dict(val)
                    if short_prefix:
                        entry["kisa"] = f"Son: {entry['kisa_raw']} MF"
                    result[mk] = entry
                else:
                    self._mf_hist_cache[mk] = (now_done, {"var": False})

        return result

    def _fetch_bulk_products_with_stock(self, cur, prod_codes: List[str]) -> List[Tuple[int, str, Any, float, int, str]]:
        """
        Verilen MAL_KODU listesi için TBL_MAL_BARKOD_TANIM üzerinde 250x korele tam tablo taraması yapmadan
        RAM ürün indeksi + tek bir toplu TBL_MAL_MIKTARLAR GROUP BY sorgusu ile ürün ve altın stok bilgisini döner.
        """
        if not prod_codes:
            return []
        pidx = self._ensure_product_index(cur)
        by_id = pidx["by_id"]
        by_code = pidx["by_code"]

        matched_entries: List[Dict[str, Any]] = []
        missing_codes: List[str] = []
        for mk in prod_codes:
            mid = by_code.get(mk) or by_code.get(mk.lstrip("0"))
            if mid and mid in by_id:
                matched_entries.append(by_id[mid])
            else:
                missing_codes.append(mk)

        # RAM indeksinde henüz bulunmayan (son birkaç dakikada açılmış) kartlar varsa canlı çek
        if missing_codes:
            for i in range(0, len(missing_codes), 900):
                chunk = missing_codes[i:i + 900]
                params = {f"k{idx}": c for idx, c in enumerate(chunk)}
                binds = ",".join(f":{k}" for k in params.keys())
                cur.execute(f"""
                    SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(t.SATIS_FIYATI_1, 0), MAX(b.BARKOD)
                    FROM TBL_MAL_TANIM t
                    LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                    WHERE t.MAL_KODU IN ({binds})
                      AND (t.PASIF IS NULL OR t.PASIF = 0)
                    GROUP BY t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(t.SATIS_FIYATI_1, 0)
                """, params)
                for r in cur.fetchall():
                    if r[0] is not None:
                        matched_entries.append({
                            "id": int(r[0]),
                            "mal_kodu": str(r[1] or "").strip(),
                            "raw_name": r[2],
                            "psf": float(r[3] or 0.0),
                            "primary_barcode": str(r[4] or r[1] or "").strip(),
                        })

        if not matched_entries:
            return []

        mal_ids = list({int(e["id"]) for e in matched_entries})
        stock_by_mid: Dict[int, float] = {}
        for i in range(0, len(mal_ids), 900):
            m_chunk = mal_ids[i:i + 900]
            m_params = {f"m{idx}": mid for idx, mid in enumerate(m_chunk)}
            m_binds = ",".join(f":{k}" for k in m_params.keys())
            cur.execute(f"""
                SELECT m.MAL_ID,
                       NVL(
                           SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                           SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END),
                           0
                       ) AS STOK
                FROM TBL_MAL_MIKTARLAR m
                WHERE m.MAL_ID IN ({m_binds})
                GROUP BY m.MAL_ID
            """, m_params)
            for r_mid, r_st in cur.fetchall():
                if r_mid is not None:
                    stock_by_mid[int(r_mid)] = float(r_st or 0.0)

        # Kanonik EAN barkodlarını 250 ayrı SQLite bağlantısı yerine tek toplu çağrıyla çöz (<2ms)
        raw_bcs = [str(e.get("primary_barcode") or e.get("mal_kodu") or "").strip() for e in matched_entries]
        canon_map: Dict[str, str] = {}
        try:
            from backend.catalog import catalog
            canon_map = catalog.resolve_canonical_barcodes_bulk(raw_bcs)
        except Exception:
            pass

        out_rows: List[Tuple[int, str, Any, float, int, str]] = []
        seen_codes = set()
        for e in matched_entries:
            mk = str(e["mal_kodu"]).strip()
            if mk in seen_codes:
                continue
            seen_codes.add(mk)
            mid = int(e["id"])
            raw_bc = str(e.get("primary_barcode") or mk).strip()
            final_bc = canon_map.get(raw_bc, raw_bc) or raw_bc
            stok_int = int(round(stock_by_mid.get(mid, 0.0)))
            out_rows.append((mid, mk, e["raw_name"], float(e.get("psf") or 0.0), stok_int, final_bc))
        return out_rows

    def get_critical_stock_sales(self, limit: int = 0, max_stock_threshold: int = 5, max_stock_days: int = 21) -> List[Dict[str, Any]]:
        """
        Bugün eczaneden çıkışı olan (reçeteli veya nakit) veya bugün hastaya açık emanet verildiği için
        stoğu ≤ 21 gün altına düşen ürünleri listeler.
        """
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                # 1. Adım: Bugün çıkışı olan ürünleri (Reçete + Nakit Fiş) ve bugün verilen Açık Emanetleri çek (<10 ms)
                cur.execute("""
                    SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as BUGUN_ADET
                    FROM TBL_MAL_HAREKET mh
                    WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE)
                      AND (
                          mh.BELGE_TURU = 'RECETE'
                          OR (mh.BELGE_TURU = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                          OR UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                          OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                      )
                    GROUP BY mh.MAL_KODU
                    HAVING SUM(ABS(mh.MIKTAR)) > 0
                """)
                today_rows = cur.fetchall()
                today_map = {
                    str(r[0]).strip(): int(r[1] or 0) for r in today_rows
                    if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI
                }
                today_emanet_map = self._fetch_today_open_emanet_map(cur)
                prod_codes = list(dict.fromkeys(list(today_map.keys()) + list(today_emanet_map.keys())))
                if not prod_codes:
                    return []

                # 2. Adım: Sadece bugün satılan ürünler için son 30 günün çıkışlarını çek (indeksli IN)
                month_map = {}
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i + 900]
                    params = {f"k{idx}": c for idx, c in enumerate(chunk)}
                    binds = ",".join(f":{k}" for k in params.keys())
                    cur.execute(f"""
                        SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as AY_ADET
                        FROM TBL_MAL_HAREKET mh
                        WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 30
                          AND mh.MAL_KODU IN ({binds})
                          AND (
                              mh.BELGE_TURU = 'RECETE'
                              OR (mh.BELGE_TURU = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                              OR UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                          )
                        GROUP BY mh.MAL_KODU
                    """, params)
                    for r in cur.fetchall():
                        if r[0]:
                            month_map[str(r[0]).strip()] = int(r[1] or 0)

                # 3. Adım: Geçmişte MF'li Alım Kontrolü & Son Alış Birim Maliyeti (15 dk önbellekli + indeksli)
                mf_history_map = self._fetch_mf_history_cached(cur, prod_codes, short_prefix=True)
                last_buy_map = self._fetch_last_purchase_map_cached(cur, prod_codes)

                # 4. Adım: İlgili ürünlerin tanım, fiyat, gerçek altın stok ve barkodlarını tek seferde çek
                candidate_items = []
                for m_id, m_kodu, m_adi, psf, stok, barkod_val in self._fetch_bulk_products_with_stock(cur, prod_codes):
                    bugun = int(today_map.get(m_kodu, 0))
                    emanet_val = int(today_emanet_map.get(m_kodu, 0))
                    aylik = int(month_map.get(m_kodu, 0))
                    psf_val = round(float(psf or 0.0), 2)

                    # Kalan stok gün hesabı ve 21 gün kuralı
                    effective_aylik = max(int(aylik or 0), int(bugun + emanet_val or 1))
                    gunluk_ort = max(0.1, round(effective_aylik / 30.0, 2))
                    stok_gun = round((stok * 30.0) / effective_aylik, 1) if stok > 0 else 0.0

                    if emanet_val > 0 and bugun == 0 and stok > 0 and stok_gun > 21:
                        continue
                    if max_stock_days > 0 and stok > 0 and stok_gun > max_stock_days:
                        continue

                    toplam_bugun_hareket = bugun + emanet_val
                    onerilen = max(toplam_bugun_hareket, int(gunluk_ort * 7) - max(0, stok))
                    if onerilen <= 0:
                        onerilen = max(1, toplam_bugun_hareket)

                    mf_hist = mf_history_map.get(m_kodu, {})
                    has_past_mf = bool(mf_hist.get("var", False))
                    lb = last_buy_map.get(m_kodu) or {}

                    item_payload = {
                        "urun_id": m_id,
                        "mal_kodu": m_kodu,
                        "urun_adi": fix_tria_str(m_adi),
                        "barkod": barkod_val,
                        "stok": stok,
                        "stok_gun": stok_gun,
                        "bugun_cikis": bugun,
                        "aylik_cikis": aylik,
                        "psf": psf_val,
                        "onerilen_siparis": max(1, onerilen),
                        "son_alis_maliyet": float(lb.get("maliyet_kdvli") or 0.0),
                        "son_alis_tarih": lb.get("tarih_tr") or "",
                        "son_alis_depo": lb.get("depo") or "",
                        "son_alis_mf": lb.get("mf_etiket") or "",
                        "gecmis_mf_var": has_past_mf,
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", ""),
                    }
                    if emanet_val > 0:
                        item_payload["bugun_emanet"] = emanet_val
                        item_payload["emanet_cikis_var"] = True
                        item_payload["sadece_emanet"] = bool(bugun == 0)

                    candidate_items.append(item_payload)

                # Akıllı Sıralama: Önce normal satışlar (eksi -> tükenen -> kalan gün), ardından sadece emanetle düşenler kendi bloğunda
                candidate_items.sort(key=lambda x: (
                    1 if x.get("sadece_emanet") else 0,
                    0 if x["stok"] < 0 else (1 if x["stok"] == 0 else 2),
                    x["stok"] if x["stok"] < 0 else x["stok_gun"],
                    -(x["bugun_cikis"] + int(x.get("bugun_emanet") or 0))
                ))

                if limit and limit > 0:
                    return candidate_items[:limit]
                return candidate_items
        except Exception as e:
            print(f"[Tria] get_critical_stock_sales hatası: {e}")
            return []

    def get_six_month_smart_order_list(
        self,
        scope: str = "today",
        search_query: str = "",
        target_days: int = 15,
        limit: int = 250
    ) -> Dict[str, Any]:
        """
        TRIA Oracle veritabanından toplu sipariş ve 6 aylık çıkış analizi için:
        - Son 6 takvim ayının ay-ay çıkış sayılarını (Reçeteli + Elden),
        - Günlük ve aylık ortalama çıkış hızını,
        - Trend ve istikrar analizini (STABİL ÇIKAN, ÇIKIŞI AZALAN, ÇIKIŞI ARTAN, ARALIKLI),
        - Hedef gün sayısına göre (örn. 7, 15, 30 gün) akıllı sipariş miktarı önerisini,
        - Geçmiş fatura MF bilgilerini ve anlık raf stoğunu (Golden Formula)
        tek seferde yüksek hızla döndürür.
        """
        import math
        t0 = time.time()
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                ay_kisa = {
                    1: "Oca", 2: "Şub", 3: "Mar", 4: "Nis",
                    5: "May", 6: "Haz", 7: "Tem", 8: "Ağu",
                    9: "Eyl", 10: "Eki", 11: "Kas", 12: "Ara"
                }
                today = datetime.date.today()
                months_meta = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    ym_int = y_calc * 100 + m_calc
                    ym_str = f"{y_calc}-{m_calc:02d}"
                    short_lbl = ay_kisa.get(m_calc, str(m_calc))
                    lbl = f"{short_lbl} '{str(y_calc)[-2:]}"
                    months_meta.append({
                        "ym_int": ym_int,
                        "ym": ym_str,
                        "short": short_lbl,
                        "label": lbl,
                        "is_current": (i == 0)
                    })

                start_ym = months_meta[0]["ym_int"]
                start_date_str = f"{start_ym // 100}-{start_ym % 100:02d}-01"
                lim = max(10, int(limit or 250))

                # 1. Bugünkü Çıkışları Belirle
                cur.execute("""
                    SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as BUGUN_ADET
                    FROM TBL_MAL_HAREKET mh
                    WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE)
                      AND (
                          UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                          OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                      )
                    GROUP BY mh.MAL_KODU
                    HAVING SUM(ABS(mh.MIKTAR)) > 0
                """)
                today_map = {
                    str(r[0]).strip(): int(r[1] or 0)
                    for r in cur.fetchall()
                    if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI
                }
                today_emanet_map = self._fetch_today_open_emanet_map(cur)

                clean_q = (search_query or "").strip()
                scope_norm = (scope or "today").strip().lower()
                prod_codes: List[str] = []

                if clean_q:
                    tr_q = clean_q.replace("i", "İ").replace("ı", "I").upper()
                    raw_u = clean_q.upper()
                    cur.execute(f"""
                        SELECT MAL_KODU FROM (
                            SELECT DISTINCT t.MAL_KODU, t.ID
                            FROM TBL_MAL_TANIM t
                            LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                            WHERE (t.PASIF IS NULL OR t.PASIF = 0)
                              AND (
                                  UPPER(t.MAL_ADI) LIKE :q1
                                  OR UPPER(t.MAL_ADI) LIKE :q2
                                  OR b.BARKOD LIKE :q3
                                  OR t.MAL_KODU LIKE :q3
                              )
                            ORDER BY t.ID DESC
                        ) WHERE ROWNUM <= {lim}
                    """, {"q1": f"%{tr_q}%", "q2": f"%{raw_u}%", "q3": f"%{clean_q}%"})
                    prod_codes = [str(r[0]).strip() for r in cur.fetchall() if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI]
                elif scope_norm in ("week", "days_7"):
                    cur.execute(f"""
                        SELECT MAL_KODU FROM (
                            SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as TOP_ADET
                            FROM TBL_MAL_HAREKET mh
                            WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 7
                              AND (
                                  UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                                  OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                              )
                            GROUP BY mh.MAL_KODU
                            HAVING SUM(ABS(mh.MIKTAR)) > 0
                            ORDER BY SUM(ABS(mh.MIKTAR)) DESC
                        ) WHERE ROWNUM <= {lim}
                    """)
                    prod_codes = [str(r[0]).strip() for r in cur.fetchall() if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI]
                elif scope_norm in ("top6m", "top_6m"):
                    cur.execute(f"""
                        SELECT MAL_KODU FROM (
                            SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as TOP_ADET
                            FROM TBL_MAL_HAREKET mh
                            WHERE mh.BELGE_TARIHI >= TO_DATE(:sdate, 'YYYY-MM-DD')
                              AND (
                                  UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                                  OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                              )
                            GROUP BY mh.MAL_KODU
                            HAVING SUM(ABS(mh.MIKTAR)) > 0
                            ORDER BY SUM(ABS(mh.MIKTAR)) DESC
                        ) WHERE ROWNUM <= {lim}
                    """, {"sdate": start_date_str})
                    prod_codes = [str(r[0]).strip() for r in cur.fetchall() if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI]
                else:
                    prod_codes = list(dict.fromkeys(list(today_map.keys()) + list(today_emanet_map.keys())))
                    if not prod_codes:
                        cur.execute(f"""
                            SELECT MAL_KODU FROM (
                                SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as TOP_ADET
                                FROM TBL_MAL_HAREKET mh
                                WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 3
                                  AND (
                                      UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                                      OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                                  )
                                GROUP BY mh.MAL_KODU
                                HAVING SUM(ABS(mh.MIKTAR)) > 0
                                ORDER BY SUM(ABS(mh.MIKTAR)) DESC
                            ) WHERE ROWNUM <= {lim}
                        """)
                        prod_codes = [str(r[0]).strip() for r in cur.fetchall() if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI]

                if not prod_codes:
                    return {
                        "success": True,
                        "source": "TRIA",
                        "scope": scope,
                        "months": months_meta,
                        "items": [],
                        "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
                    }

                if len(prod_codes) > lim:
                    prod_codes = prod_codes[:lim]

                # 2. Son 6 Ayın Ay-Ay Reçeteli/Nakit Dağılımı VE Son 30 Günün Çıkışlarını TEK SORGUDA Çek
                per_item_months: Dict[str, Dict[int, Dict[str, int]]] = {}
                last30_map: Dict[str, int] = {}
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i + 900]
                    params = {f"k{idx}": c for idx, c in enumerate(chunk)}
                    binds = ",".join(f":{k}" for k in params.keys())
                    params["sdate"] = start_date_str
                    cur.execute(f"""
                        SELECT
                            mh.MAL_KODU,
                            TO_NUMBER(TO_CHAR(mh.BELGE_TARIHI, 'YYYYMM')) as YM,
                            SUM(CASE
                                WHEN mh.BELGE_TURU = 'RECETE' OR UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE' THEN ABS(mh.MIKTAR)
                                WHEN (mh.BELGE_TURU = 'FIS' OR UPPER(TRIM(mh.BELGE_TURU)) = 'FIS') AND mh.BELGE_TIP_NO IN ('01', '06') THEN ABS(mh.MIKTAR)
                                ELSE 0
                            END) as TOP_ADET,
                            SUM(CASE WHEN mh.BELGE_TURU = 'RECETE' OR UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE' THEN ABS(mh.MIKTAR) ELSE 0 END) as REC_ADET,
                            SUM(CASE WHEN (mh.BELGE_TURU = 'FIS' OR UPPER(TRIM(mh.BELGE_TURU)) = 'FIS') AND mh.BELGE_TIP_NO IN ('01', '06') THEN ABS(mh.MIKTAR) ELSE 0 END) as NAK_ADET,
                            SUM(CASE WHEN mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 30 THEN ABS(mh.MIKTAR) ELSE 0 END) as SON30_ADET
                        FROM TBL_MAL_HAREKET mh
                        WHERE mh.BELGE_TARIHI >= TO_DATE(:sdate, 'YYYY-MM-DD')
                          AND mh.MAL_KODU IN ({binds})
                          AND (
                              mh.BELGE_TURU = 'RECETE'
                              OR (mh.BELGE_TURU = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                              OR UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                          )
                        GROUP BY mh.MAL_KODU, TO_NUMBER(TO_CHAR(mh.BELGE_TARIHI, 'YYYYMM'))
                    """, params)
                    for r_code, r_ym, r_top, r_rec, r_nak, r_s30 in cur.fetchall():
                        if not r_code or not r_ym:
                            continue
                        c_str = str(r_code).strip()
                        per_item_months.setdefault(c_str, {})[int(r_ym)] = {
                            "toplam": int(r_top or 0),
                            "receteli": int(r_rec or 0),
                            "nakit": int(r_nak or 0),
                        }
                        if r_s30:
                            last30_map[c_str] = last30_map.get(c_str, 0) + int(r_s30 or 0)

                # 3. Geçmiş Fatura MF Bilgisi & Son Alış Birim Maliyeti (15 dk RAM önbellekli + indeksli)
                mf_history_map = self._fetch_mf_history_cached(cur, prod_codes, short_prefix=False)
                last_buy_map = self._fetch_last_purchase_map_cached(cur, prod_codes)

                # 4. Ürün Tanım, PSF, Altın Stok ve Kanonik Barkodları Tek Seferde Çek
                urun_rows = self._fetch_bulk_products_with_stock(cur, prod_codes)

                items = []
                stabil_count = 0
                azalan_count = 0
                artan_count = 0
                tukenen_count = 0
                target_days_clean = max(1, int(target_days or 15))

                for m_id, m_kodu, m_adi_raw, psf_raw, stok_val, bc_val in urun_rows:
                    u_id = int(m_id or 0)
                    u_adi = fix_tria_str(m_adi_raw)
                    psf_val = round(float(psf_raw or 0.0), 2)
                    bugun_val = int(today_map.get(m_kodu, 0))
                    emanet_val = int(today_emanet_map.get(m_kodu, 0))
                    son30_val = int(last30_map.get(m_kodu, 0))

                    m_dict = per_item_months.get(m_kodu, {})
                    aylik_detay = []
                    toplam_6ay = 0
                    toplam_6ay_recete = 0
                    toplam_6ay_nakit = 0
                    aktif_ay_sayisi = 0

                    for m_meta in months_meta:
                        ym_i = m_meta["ym_int"]
                        cell = m_dict.get(ym_i, {"toplam": 0, "receteli": 0, "nakit": 0})
                        c_top = cell["toplam"]
                        c_rec = cell["receteli"]
                        c_nak = cell["nakit"]
                        toplam_6ay += c_top
                        toplam_6ay_recete += c_rec
                        toplam_6ay_nakit += c_nak
                        if c_top > 0:
                            aktif_ay_sayisi += 1
                        aylik_detay.append({
                            "ym": m_meta["ym"],
                            "short": m_meta["short"],
                            "label": m_meta["label"],
                            "is_current": m_meta["is_current"],
                            "toplam": c_top,
                            "receteli": c_rec,
                            "recete": c_rec,
                            "nakit": c_nak
                        })

                    m_vals = [x["toplam"] for x in aylik_detay]
                    gecmis_5_toplam = sum(m_vals[:5])
                    ort_aylik_6m = round(gecmis_5_toplam / 5.0, 1) if gecmis_5_toplam > 0 else round(toplam_6ay / 6.0, 1)

                    onceki_4_ort = sum(m_vals[:4]) / 4.0
                    gecen_ay_val = m_vals[4] if len(m_vals) >= 5 else 0
                    son_donem_hiz = round((gecen_ay_val + son30_val) / 2.0, 1) if gecen_ay_val > 0 else float(son30_val)

                    degisim_yuzde = 0
                    if onceki_4_ort >= 1.5:
                        degisim_yuzde = int(round(((son_donem_hiz - onceki_4_ort) / onceki_4_ort) * 100))

                    if onceki_4_ort >= 2.0 and son_donem_hiz < onceki_4_ort * 0.65:
                        trend_kodu = "AZALAN"
                        trend_etiket = f"📉 Çıkışı Azalan (%{abs(degisim_yuzde)}↓)"
                        trend_renk = "amber"
                        trend_uyari = f"Son dönemde çıkış hızı {onceki_4_ort:.1f}/ay'dan {son_donem_hiz:.1f}/ay'a geriledi. Yüksek stok bağlamayın."
                        azalan_count += 1
                    elif onceki_4_ort >= 1.5 and son_donem_hiz > onceki_4_ort * 1.35 and son_donem_hiz >= 3.0:
                        trend_kodu = "ARTAN"
                        trend_etiket = f"📈 Çıkışı Artan (+%{abs(degisim_yuzde)}↑)"
                        trend_renk = "sky"
                        trend_uyari = f"Son dönemde talep hızlandı ({onceki_4_ort:.1f} → {son_donem_hiz:.1f}/ay). Güvenli stok tutun."
                        artan_count += 1
                    elif aktif_ay_sayisi >= 4 and toplam_6ay >= 5:
                        trend_kodu = "STABIL"
                        trend_etiket = f"🟢 Stabil Çıkan ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "emerald"
                        trend_uyari = f"Her ay düzenli satıyor (Ort. {ort_aylik_6m:.1f} kt/ay). MF baremli alıma uygun."
                        stabil_count += 1
                    else:
                        trend_kodu = "DUZENSIZ"
                        trend_etiket = f"⚡ Aralıklı ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "slate"
                        trend_uyari = f"Son 6 ayın {aktif_ay_sayisi} ayında çıkış yaptı (Toplam {toplam_6ay} kt). İhtiyaç kadar alın."

                    if stok_val <= 0:
                        tukenen_count += 1

                    if trend_kodu == "AZALAN":
                        etkin_aylik_hiz = max(0.5, min(ort_aylik_6m, max(1.0, son_donem_hiz)))
                    elif trend_kodu == "ARTAN":
                        etkin_aylik_hiz = max(ort_aylik_6m, son_donem_hiz, float(bugun_val))
                    else:
                        etkin_aylik_hiz = max(ort_aylik_6m, float(son30_val), float(bugun_val))

                    gunluk_hiz = round(max(0.05, etkin_aylik_hiz / 30.0), 2)
                    stok_gun = round(stok_val / gunluk_hiz, 1) if stok_val > 0 else 0.0

                    # Sadece emanet çıkışı olan ürünlerde stok 21 günün üzerindeyse Toplu Sipariş (Bugün) listesini de meşgul etmesin
                    if scope_norm == "today" and not clean_q and emanet_val > 0 and bugun_val == 0 and stok_val > 0 and stok_gun > 21:
                        continue

                    hedef_kutu = math.ceil(gunluk_hiz * target_days_clean)
                    if trend_kodu == "AZALAN":
                        kisitli_hedef = math.ceil(gunluk_hiz * min(target_days_clean, 10))
                        onerilen = max(0, kisitli_hedef - max(0, stok_val))
                        if stok_val <= 0:
                            onerilen = max(1, min(bugun_val or 1, 2))
                    else:
                        onerilen = max(0, hedef_kutu - max(0, stok_val))
                        if stok_val <= 0 and onerilen <= 0:
                            onerilen = max(1, bugun_val or 1)

                    mf_hist = mf_history_map.get(m_kodu, {})
                    lb = last_buy_map.get(m_kodu) or {}

                    if trend_kodu == "AZALAN":
                        oneri_metni = f"⚠️ Çıkışı azaldığı için {target_days_clean} gün yerine kısa vadeli ({max(1, onerilen)} kt) önerildi."
                    elif trend_kodu == "STABIL" and mf_hist.get("var"):
                        oneri_metni = f"💡 Düzenli çıkıyor ({ort_aylik_6m:.1f}/ay). Geçmişte {mf_hist.get('kisa')} MF ile alındı; MF baremi avantajlı!"
                    elif trend_kodu == "STABIL":
                        oneri_metni = f"✅ Stabil ürün ({ort_aylik_6m:.1f}/ay). {target_days_clean} günlük stok hedefi için {max(1, onerilen)} kt uygun."
                    elif trend_kodu == "ARTAN":
                        oneri_metni = f"🚀 Çıkış hızı artıyor ({son_donem_hiz:.1f}/ay). Stoksuz kalmamak için {max(1, onerilen)} kt önerilir."
                    else:
                        oneri_metni = f"📦 Aralıklı çıkış ({toplam_6ay} kt / 6 ay). Minimum stok ({max(1, onerilen)} kt) tutun."

                    items.append({
                        "urun_id": u_id,
                        "mal_kodu": m_kodu,
                        "urun_kodu": m_kodu,
                        "urun_adi": u_adi,
                        "barkod": bc_val,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "psf": psf_val,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": son30_val,
                        "toplam_6ay": toplam_6ay,
                        "toplam_6ay_recete": toplam_6ay_recete,
                        "toplam_6ay_nakit": toplam_6ay_nakit,
                        "ort_aylik_6m": ort_aylik_6m,
                        "onceki_4_ort": round(onceki_4_ort, 1),
                        "ilk4_ort": round(onceki_4_ort, 1),
                        "son_donem_hiz": round(son_donem_hiz, 1),
                        "son2_ort": round(son_donem_hiz, 1),
                        "gunluk_hiz": gunluk_hiz,
                        "aktif_ay_sayisi": aktif_ay_sayisi,
                        "aylik_detay": aylik_detay,
                        "trend_kodu": trend_kodu,
                        "trend_etiket": trend_etiket,
                        "trend_renk": trend_renk,
                        "trend_uyari": trend_uyari,
                        "degisim_yuzde": degisim_yuzde,
                        "onerilen_siparis": max(1, onerilen) if (stok_val <= 0 or bugun_val > 0 or emanet_val > 0 or onerilen > 0) else 0,
                        "ham_ihtiyac": max(0, hedef_kutu - max(0, stok_val)),
                        "oneri_metni": oneri_metni,
                        **({
                            "bugun_emanet": emanet_val,
                            "emanet_cikis_var": True,
                            "sadece_emanet": bool(bugun_val == 0)
                        } if emanet_val > 0 else {}),
                        "gecmis_mf_var": bool(mf_hist.get("var", False)),
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_min_alim": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_bedelsiz": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_son_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", ""),
                        "son_alis_maliyet": float(lb.get("maliyet_kdvli") or 0.0),
                        "son_alis_tarih": lb.get("tarih_tr") or "",
                        "son_alis_depo": lb.get("depo") or "",
                        "son_alis_mf": lb.get("mf_etiket") or "",
                    })

                items.sort(key=lambda x: (
                    0 if (x["stok"] <= 0 and x["bugun_cikis"] > 0) else (1 if x["bugun_cikis"] > 0 else 2),
                    x["stok_gun"],
                    -x["toplam_6ay"]
                ))

                return {
                    "success": True,
                    "source": "TRIA",
                    "scope": scope,
                    "target_days": target_days_clean,
                    "elapsed_ms": round((time.time() - t0) * 1000, 1),
                    "months": months_meta,
                    "items": items,
                    "stats": {
                        "total_items": len(items),
                        "stabil_count": stabil_count,
                        "azalan_count": azalan_count,
                        "artan_count": artan_count,
                        "tukenen_count": tukenen_count
                    }
                }
        except Exception as e:
            print(f"[Tria] get_six_month_smart_order_list hatası: {e}")
            return {
                "success": False,
                "source": "TRIA",
                "scope": scope,
                "error": str(e),
                "months": [],
                "items": [],
                "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
            }

    def get_product_vat(self, barcode_or_code: str) -> Optional[float]:
        """Ürünün Tria veritabanındaki resmi KDV oranını döner (örn: 1.0, 10.0, 20.0 - TBL_KDV_TANIM bağımsız)."""
        q = str(barcode_or_code or "").strip()
        if not q:
            return None
        try:
            idx_ref = self._prod_index
            if idx_ref is not None and (time.time() - self._prod_index_ts) < 600.0:
                mid = idx_ref["by_barcode"].get(q) or idx_ref["by_code"].get(q) or idx_ref["by_code"].get(q.lstrip("0"))
                if mid and mid in idx_ref["by_id"]:
                    return float(idx_ref["by_id"][mid]["kdv"])

            with self.get_connection() as conn:
                cur = conn.cursor()
                pidx = self._ensure_product_index(cur)
                mid = pidx["by_barcode"].get(q) or pidx["by_code"].get(q) or pidx["by_code"].get(q.lstrip("0"))
                if mid and mid in pidx["by_id"]:
                    return float(pidx["by_id"][mid]["kdv"])

                cur.execute("""
                    SELECT t.SATIS_KDV_ID
                    FROM TBL_MAL_TANIM t
                    LEFT JOIN TBL_MAL_BARKOD_TANIM b ON t.ID = b.MAL_TANIM_ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                    WHERE (b.BARKOD = :q OR t.MAL_KODU = :q) AND (t.PASIF IS NULL OR t.PASIF = 0)
                      AND ROWNUM = 1
                """, {"q": q})
                row = cur.fetchone()
                if row and row[0] is not None:
                    return _kdv_from_satis_kdv_id(row[0])
        except Exception as e:
            print(f"[Tria] get_product_vat hatası: {e}")
        return None

    def get_product_equivalents(self, barcode_or_code: str) -> Dict[str, Any]:
        """
        Belirtilen barkod veya mal koduna ait SGK Eşdeğer Grubunu (ESDEGER_GRUP_KODU) tespit eder.
        Gruptaki tüm muadilleri LTRIM tam tablo taraması yapmadan indeksli toplu sorgularla (<20ms) döndürür.
        """
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                q = str(barcode_or_code or "").strip()
                if not q:
                    return {"found": False, "esdeger_kodu": None, "muadiller": []}

                pidx = self._ensure_product_index(cur)
                by_id = pidx["by_id"]
                by_bc = pidx["by_barcode"]
                by_code = pidx["by_code"]
                by_esdeger = pidx["by_esdeger"]

                hit_mid = by_bc.get(q) or by_code.get(q) or by_code.get(q.lstrip("0"))

                if (not hit_mid or not by_id.get(hit_mid, {}).get("esdeger")):
                    try:
                        from backend.catalog import catalog
                        cand_bcs = []
                        if not (q.isdigit() and len(q) >= 8):
                            suggs = catalog.search_suggestions(q, limit=2)
                            for s in suggs:
                                if s.get("barcode"):
                                    cand_bcs.append(str(s["barcode"]).strip())
                        else:
                            can_bc = catalog.resolve_canonical_barcode(q)
                            if can_bc:
                                cand_bcs.append(can_bc)
                            cand_bcs.extend(catalog.get_all_related_barcodes(q))
                        for cb in cand_bcs:
                            m_try = by_bc.get(cb) or by_code.get(cb)
                            if m_try and by_id.get(m_try, {}).get("esdeger"):
                                hit_mid = m_try
                                break
                    except Exception:
                        pass

                m_kodu = ""
                grup_str = ""
                if hit_mid and hit_mid in by_id and by_id[hit_mid].get("esdeger"):
                    m_kodu = str(by_id[hit_mid]["mal_kodu"] or "").strip()
                    grup_str = str(by_id[hit_mid]["esdeger"] or "").strip()
                else:
                    clean_w = [w for w in re.findall(r"[a-zA-Z0-9]+", q) if len(w) >= 3]
                    if clean_w:
                        kw = clean_w[0].upper()
                        cur.execute("""
                            SELECT t.ID, t.MAL_KODU, t.ESDEGER_GRUP_KODU
                            FROM TBL_MAL_TANIM t
                            WHERE UPPER(t.MAL_ADI) LIKE :kw || '%'
                              AND (t.PASIF IS NULL OR t.PASIF = 0)
                              AND t.ESDEGER_GRUP_KODU IS NOT NULL
                              AND ROWNUM = 1
                        """, {"kw": kw})
                        r_fb = cur.fetchone()
                        if r_fb and r_fb[2]:
                            m_kodu = str(r_fb[1] or "").strip()
                            grup_str = str(r_fb[2] or "").strip()

                if not grup_str:
                    return {"found": False, "esdeger_kodu": None, "muadiller": [], "message": "SGK eşdeğer grubu bulunamadı."}

                group_mids = list(by_esdeger.get(grup_str, []))
                group_entries: List[Dict[str, Any]] = [by_id[mid] for mid in group_mids if mid in by_id]

                if not group_entries:
                    cur.execute("""
                        SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI),
                               NVL(t.SATIS_FIYATI_1, 0), NVL(t.DEPOCU_SATIS_FIYATI, 0),
                               NVL(t.ALIS_FIYATI_1, 0), NVL(t.KAMU_ISKONTO_ORANI, 0),
                               NVL(t.SATIS_KDV_ID, 5)
                        FROM TBL_MAL_TANIM t
                        WHERE t.ESDEGER_GRUP_KODU = :grp AND (t.PASIF IS NULL OR t.PASIF = 0)
                    """, {"grp": grup_str})
                    for gr in cur.fetchall():
                        group_entries.append({
                            "id": int(gr[0]),
                            "mal_kodu": str(gr[1] or "").strip(),
                            "raw_name": gr[2],
                            "psf": float(gr[3] or 0.0),
                            "dsf": float(gr[4] or 0.0),
                            "alis1": float(gr[5] or 0.0),
                            "kamu_isk": float(gr[6] or 0.0),
                            "kdv": _kdv_from_satis_kdv_id(gr[7]),
                            "primary_barcode": str(gr[1] or "").strip(),
                        })

                if not group_entries:
                    return {"found": False, "esdeger_kodu": grup_str, "muadiller": []}

                all_mids = [int(e["id"]) for e in group_entries]
                stock_map: Dict[int, int] = {}
                for i in range(0, len(all_mids), 500):
                    ch = all_mids[i:i + 500]
                    mp = {f"m{j}": v for j, v in enumerate(ch)}
                    cur.execute(f"""
                        SELECT m.MAL_ID,
                               NVL(
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END),
                                   0
                               )
                        FROM TBL_MAL_MIKTARLAR m
                        WHERE m.MAL_ID IN ({','.join(':' + k for k in mp)})
                        GROUP BY m.MAL_ID
                    """, mp)
                    for r_m, r_s in cur.fetchall():
                        if r_m is not None:
                            stock_map[int(r_m)] = int(round(float(r_s or 0.0)))

                variant_to_canon_code: Dict[str, str] = {}
                for e in group_entries:
                    ck = str(e["mal_kodu"]).strip()
                    for v in _mal_kodu_variants(ck):
                        variant_to_canon_code[v] = ck
                all_code_variants = list(variant_to_canon_code.keys())

                cikis30_map: Dict[str, int] = {}
                for i in range(0, len(all_code_variants), 800):
                    ch = all_code_variants[i:i + 800]
                    kp = {f"k{j}": v for j, v in enumerate(ch)}
                    cur.execute(f"""
                        SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR))
                        FROM TBL_MAL_HAREKET mh
                        WHERE mh.MAL_KODU IN ({','.join(':' + k for k in kp)})
                          AND mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 30
                          AND (
                              mh.BELGE_TURU IN ('RECETE', 'FIS', 'FATURA', 'PS', 'SF')
                              OR mh.BELGE_TIP_NO IN ('01', '06', '02', '03')
                              OR UPPER(TRIM(mh.BELGE_TURU)) LIKE 'RECET%'
                              OR UPPER(TRIM(mh.BELGE_TURU)) LIKE 'REÇET%'
                              OR UPPER(TRIM(mh.BELGE_TURU)) IN ('FIS', 'FİŞ', 'FATURA', 'PS', 'SF')
                          )
                        GROUP BY mh.MAL_KODU
                    """, kp)
                    for r_k, r_q in cur.fetchall():
                        ck = variant_to_canon_code.get(str(r_k or "").strip())
                        if ck:
                            cikis30_map[ck] = cikis30_map.get(ck, 0) + int(round(float(r_q or 0.0)))

                canon_codes = [str(e["mal_kodu"]).strip() for e in group_entries]
                mf_hist_map = self._fetch_mf_history_cached(cur, canon_codes, short_prefix=False)

                eq_rows = []
                for e in group_entries:
                    ck = str(e["mal_kodu"]).strip()
                    mf_h = mf_hist_map.get(ck, {})
                    mf_txt = f"{mf_h.get('kisa_raw', '')} MF ({mf_h.get('son_tarih', '')})" if mf_h.get("var") else ""
                    eq_rows.append((
                        ck,
                        e["raw_name"],
                        str(e.get("primary_barcode") or ck).strip(),
                        e.get("psf", 0.0),
                        stock_map.get(int(e["id"]), 0),
                        cikis30_map.get(ck, 0),
                        mf_txt,
                        e.get("kamu_isk", 0.0),
                        e.get("dsf", 0.0),
                        e.get("alis1", 0.0),
                        e.get("kdv", 10.0),
                    ))

                items = []
                current_kamu_kari = 0.0
                for row in eq_rows:
                    kodu = str(row[0])
                    adi = fix_tria_str(row[1])
                    barkod = str(row[2])
                    psf = round(float(row[3] or 0), 2)
                    stok = int(round(float(row[4] or 0)))
                    cikis30 = int(round(float(row[5] or 0)))
                    mf_bilgi = str(row[6] or "").strip() if row[6] else ""
                    kamu_isk = round(float(row[7] or 0.0), 2)
                    dsf_val = round(float(row[8] or 0.0), 2)
                    alis1_val = round(float(row[9] or 0.0), 2)
                    kdv_oran = float(row[10] or 10.0)
                    kdv_div = 1.0 + (kdv_oran / 100.0) if kdv_oran > 0 else 1.10

                    # Eğer Tria'da kamu iskontosu 0 görünüyorsa ancak DSF veya Alış fiyatından kamu iskontosu anlaşılıyorsa çıkar
                    dsf_brut = (psf / kdv_div) * 0.78125 if psf > 0 else 0.0
                    if kamu_isk <= 0.0 and dsf_brut > 0 and alis1_val > 0 and alis1_val < (dsf_brut * 0.985):
                        derived_isk = round((1.0 - (alis1_val / dsf_brut)) * 100.0, 1)
                        if 1.5 <= derived_isk <= 75.0:
                            kamu_isk = derived_isk

                    ksf = round(psf * (1.0 - (kamu_isk / 100.0)), 2) if (psf > 0 and kamu_isk > 0) else round(psf, 2)

                    if alis1_val > 0:
                        net_kdvsiz = alis1_val
                    elif dsf_val > 0:
                        net_kdvsiz = round(dsf_val * (1.0 - (kamu_isk / 100.0)), 2) if dsf_val >= (dsf_brut * 0.95) else dsf_val
                    elif dsf_brut > 0:
                        net_kdvsiz = round(dsf_brut * (1.0 - (kamu_isk / 100.0)), 2)
                    else:
                        net_kdvsiz = 0.0

                    net_kdvli = round(net_kdvsiz * kdv_div, 2)
                    kamu_kari = round(ksf - net_kdvli, 2) if (ksf > 0 and net_kdvli > 0) else 0.0
                    perakende_kari = round(psf - net_kdvli, 2) if (psf > 0 and net_kdvli > 0) else 0.0
                    is_curr = (kodu == str(m_kodu))
                    if is_curr:
                        current_kamu_kari = kamu_kari

                    items.append({
                        "kod": kodu,
                        "mal_kodu": kodu,
                        "ad": adi,
                        "urun_adi": adi,
                        "barkod": barkod,
                        "etiket_fiyati": psf,
                        "psf": psf,
                        "kamu_fiyati": ksf,
                        "ksf": ksf,
                        "kamu_iskontosu": kamu_isk,
                        "birim_maliyet": net_kdvsiz,
                        "net_birim_maliyet": net_kdvsiz,
                        "birim_maliyet_kdvli": net_kdvli,
                        "net_birim_maliyet_kdvli": net_kdvli,
                        "kamu_kari": kamu_kari,
                        "perakende_kari": perakende_kari,
                        "stok": stok,
                        "cikis_30gun": cikis30,
                        "gecmis_mf_var": bool(mf_bilgi),
                        "gecmis_mf_bilgi": mf_bilgi,
                        "is_current": is_curr
                    })

                for it in items:
                    kf = round(it["kamu_kari"] - current_kamu_kari, 2)
                    it["kar_farki"] = kf
                    it["is_more_profitable"] = (kf > 0)
                    it["kar_artis_yuzdesi"] = round((kf / current_kamu_kari * 100.0), 1) if (current_kamu_kari > 0 and kf > 0) else 0.0

                items.sort(key=lambda x: (x.get("kamu_kari") or 0.0, x.get("stok") or 0), reverse=True)

                en_karli = None
                muadil_kar_avantaji = 0.0
                for it in items:
                    if it.get("kar_farki", 0.0) > 0 and not it.get("is_current"):
                        it["is_best_deal"] = True
                        en_karli = it
                        muadil_kar_avantaji = it["kar_farki"]
                        break

                return {
                    "found": True,
                    "esdeger_kodu": grup_str,
                    "count": len(items),
                    "en_karli_muadil": en_karli,
                    "muadil_kar_avantaji": muadil_kar_avantaji,
                    "current_kamu_kari": current_kamu_kari,
                    "muadiller": items
                }
        except Exception as e:
            print(f"[Tria] get_product_equivalents hatası: {e}")
            return {"found": False, "error": str(e), "esdeger_kodu": None, "muadiller": []}

    def list_available_schemas(self) -> Dict[str, Any]:
        """Oracle veritabanındaki kayıtlı eczane şemalarını listeler (EdaPrim list_available_schemas)."""
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                cur.execute("""
                    SELECT USERNAME FROM ALL_USERS 
                    WHERE USERNAME NOT IN (
                        'SYS', 'SYSTEM', 'ANONYMOUS', 'APEX_PUBLIC_USER', 'APPQOSSYS',
                        'CTXSYS', 'DBSNMP', 'DIP', 'EXFSYS', 'FLOWS_FILES', 'MDDATA',
                        'MDSYS', 'MGMT_VIEW', 'OLAPSYS', 'ORACLE_OCM', 'ORDDATA',
                        'ORDPLUGINS', 'ORDSYS', 'OUTLN', 'OWBSYS', 'OWBSYS_AUDIT',
                        'SCOTT', 'SI_INFORMTN_SCHEMA', 'SPATIAL_CSW_ADMIN_USR',
                        'SPATIAL_WFS_ADMIN_USR', 'SYSMAN', 'WMSYS', 'XDB', 'XS$NULL'
                    )
                    AND USERNAME NOT LIKE 'APEX_%'
                    ORDER BY USERNAME
                """)
                schemas = [r[0] for r in cur.fetchall() if r and r[0] != 'XS$NULL']
                return {"success": True, "schemas": schemas}
        except Exception as e:
            return {"success": False, "error": str(e), "schemas": []}

    def discover_oracle_host(self) -> Dict[str, Any]:
        return self.discover_tria_host()

    def discover_tria_host(self) -> Dict[str, Any]:
        """Ağda veya yerel makinede TRIA Oracle sunucusunu tüm alt ağda paralel tarayarak otomatik keşfeder."""
        import socket
        import concurrent.futures
        import re

        local_ip = "127.0.0.1"
        prefix = "192.168.1"
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            prefix = ".".join(local_ip.split(".")[:3])
        except Exception:
            pass

        cfg_user = os.environ.get("TRIA_DB_USER", "").strip()
        cfg_pwd = os.environ.get("TRIA_DB_PASSWORD", "").strip() or cfg_user
        cfg_host = os.environ.get("TRIA_DB_HOST", "").strip()

        # Varsa yerel Tria / Oracle tnsnames.ora veya ini dosyalarından IP/SID ipucu oku
        hint_ips = []
        if cfg_host and cfg_host not in ("127.0.0.1", "localhost"):
            hint_ips.append(cfg_host)
        for tns_cand in [
            r"C:\Tria\tnsnames.ora",
            r"D:\Tria\tnsnames.ora",
            os.path.join(self.base_dir, "oracle_client", "network_admin", "tnsnames.ora"),
        ]:
            if os.path.exists(tns_cand):
                try:
                    with open(tns_cand, "r", encoding="utf-8", errors="ignore") as f:
                        txt = f.read()
                    for m in re.findall(r"HOST\s*=\s*([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)", txt, re.I):
                        if m not in hint_ips:
                            hint_ips.append(m)
                except Exception:
                    pass

        all_ips = list(dict.fromkeys(
            hint_ips + [f"{prefix}.{i}" for i in range(1, 255) if f"{prefix}.{i}" != local_ip]
        ))

        def _probe_port(ip_port):
            ip, p = ip_port
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.25)
            try:
                if sock.connect_ex((ip, p)) == 0:
                    return (ip, str(p))
            except Exception:
                pass
            finally:
                sock.close()
            return None

        targets = [(ip, p) for p in (1521, 1522) for ip in all_ips]
        open_endpoints = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=96) as ex:
            for res in ex.map(_probe_port, targets):
                if res:
                    open_endpoints.append(res)

        for p in (1521, 1522):
            res = _probe_port(("127.0.0.1", p))
            if res:
                open_endpoints.append(res)

        candidates_found = []
        if oracledb is not None and cfg_user:
            self._init_oracle_client()
            for cand_ip, cand_port in open_endpoints:
                for cand_sid in ("ORCL", "XEPDB1", "XE"):
                    try:
                        conn = self._open_and_verify_conn(
                            cand_ip, cand_port, cand_sid, cfg_user, cfg_pwd, timeout=1.5
                        )
                        cur = conn.cursor()
                        cur.execute("SELECT MAX(RECETE_TARIHI) FROM TBL_RECETE")
                        max_dt = cur.fetchone()[0]
                        conn.close()
                        max_dt_str = str(max_dt or "")
                        match_info = {
                            "success": True,
                            "found": True,
                            "host": cand_ip,
                            "port": cand_port,
                            "sid": cand_sid,
                            "user": cfg_user,
                            "password": cfg_pwd,
                            "max_date": max_dt_str,
                            "_score": (
                                1 if cand_ip != "127.0.0.1" else 0,
                                1 if str(cand_port) == "1521" else 0,
                                max_dt_str,
                            ),
                            "message": f"Ağda canlı TRIA Oracle sunucusu bulundu: {cand_ip}:{cand_port}/{cand_sid} ({cfg_user})"
                        }
                        candidates_found.append(match_info)
                        break
                    except Exception as e:
                        es = str(e)
                        if "ORA-01017" in es or "ORA-28000" in es:
                            break
                        continue

        if candidates_found:
            candidates_found.sort(key=lambda x: x["_score"], reverse=True)
            best_match = dict(candidates_found[0])
            best_match.pop("_score", None)
            if best_match["host"] != "127.0.0.1":
                self._persist_env_settings(
                    best_match["host"],
                    best_match["port"],
                    best_match["sid"],
                    best_match["user"],
                    best_match["password"],
                )
            return best_match

        if open_endpoints:
            found_ip, found_port = open_endpoints[0]
            return {
                "success": True,
                "found": True,
                "host": found_ip,
                "port": found_port,
                "sid": "ORCL",
                "user": cfg_user,
                "message": f"Ağda TRIA Oracle sunucusu bulundu: {found_ip}:{found_port} (Lütfen TRIA şema/kullanıcı adınızı giriniz)"
            }
        return {
            "success": False,
            "found": False,
            "host": "",
            "port": "1521",
            "sid": "ORCL",
            "user": cfg_user,
            "message": "Ağda açık Oracle (1521) sunucusu tespit edilemedi. Lütfen sunucu IP adresini elle giriniz."
        }

    def get_bulk_stock_and_sales_map(self, barcodes: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Verilen barkod listesi için TRIA Oracle veritabanından tek seferde (toplu/bulk)
        anlık altın stok (Golden Formula), son 1 aylık (30 gün) çıkış ve son 3 aylık (90 gün) çıkış
        sayılarını döndürür.
        """
        result: Dict[str, Dict[str, Any]] = {}
        clean_inputs = [str(b or "").strip() for b in (barcodes or []) if str(b or "").strip()]
        if not clean_inputs:
            return result

        variant_to_originals: Dict[str, set] = {}
        for orig_bc in clean_inputs:
            result[orig_bc] = {"stok": 0, "cikis_1ay": 0, "cikis_3ay": 0, "found": False}
            variants = {orig_bc}
            if orig_bc.isdigit():
                if len(orig_bc) == 13:
                    variants.add("0" + orig_bc)
                elif len(orig_bc) == 14 and orig_bc.startswith("0"):
                    variants.add(orig_bc[1:])
            try:
                from backend.catalog import catalog
                c_item = catalog.get_by_barcode(orig_bc)
                if c_item:
                    if c_item.get("barcode"):
                        variants.add(str(c_item["barcode"]).strip())
                    for ab in (c_item.get("all_barcodes") or []):
                        if str(ab).strip():
                            variants.add(str(ab).strip())
            except Exception:
                pass
            for v in variants:
                if v:
                    variant_to_originals.setdefault(v, set()).add(orig_bc)

        all_variants = list(variant_to_originals.keys())
        if not all_variants:
            return result

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                pidx = self._ensure_product_index(cur)
                by_id = pidx["by_id"]
                by_bc = pidx["by_barcode"]
                by_code = pidx["by_code"]

                mal_id_to_originals: Dict[int, set] = {}
                mal_kodu_to_originals: Dict[str, set] = {}
                unmatched_variants: List[str] = []

                for v, origs in variant_to_originals.items():
                    mid = by_bc.get(v) or by_code.get(v)
                    if mid and mid in by_id:
                        mal_id_to_originals.setdefault(mid, set()).update(origs)
                        mk = by_id[mid]["mal_kodu"]
                        if mk:
                            mal_kodu_to_originals.setdefault(mk, set()).update(origs)
                    else:
                        unmatched_variants.append(v)

                chunk_size = 400
                for i in range(0, len(unmatched_variants), chunk_size):
                    chunk = unmatched_variants[i:i + chunk_size]
                    bind_names = [f":b{ idx }" for idx in range(len(chunk))]
                    bind_map = {f"b{ idx }": val for idx, val in enumerate(chunk)}
                    in_clause = ",".join(bind_names)

                    cur.execute(f"""
                        SELECT t.ID, t.MAL_KODU, b.BARKOD
                        FROM TBL_MAL_TANIM t
                        LEFT JOIN TBL_MAL_BARKOD_TANIM b
                               ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                        WHERE (b.BARKOD IN ({in_clause}) OR t.MAL_KODU IN ({in_clause}))
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                    """, bind_map)
                    for row in cur.fetchall():
                        m_id = int(row[0] or 0)
                        m_kodu = str(row[1] or "").strip()
                        b_str = str(row[2] or "").strip()
                        matched_origs = set()
                        if b_str in variant_to_originals:
                            matched_origs.update(variant_to_originals[b_str])
                        if m_kodu in variant_to_originals:
                            matched_origs.update(variant_to_originals[m_kodu])
                        if matched_origs:
                            if m_id > 0:
                                mal_id_to_originals.setdefault(m_id, set()).update(matched_origs)
                            if m_kodu:
                                mal_kodu_to_originals.setdefault(m_kodu, set()).update(matched_origs)

                all_mal_ids = list(mal_id_to_originals.keys())
                all_mal_kodlari = list(mal_kodu_to_originals.keys())
                if not all_mal_ids and not all_mal_kodlari:
                    return result

                mid_stock: Dict[int, int] = {}
                for i in range(0, len(all_mal_ids), chunk_size):
                    m_chunk = all_mal_ids[i:i + chunk_size]
                    bind_names = [f":m{ idx }" for idx in range(len(m_chunk))]
                    bind_map = {f"m{ idx }": val for idx, val in enumerate(m_chunk)}
                    in_clause = ",".join(bind_names)

                    cur.execute(f"""
                        SELECT m.MAL_ID,
                               NVL(
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END),
                                   0
                               ) AS STOK
                        FROM TBL_MAL_MIKTARLAR m
                        WHERE m.MAL_ID IN ({in_clause})
                        GROUP BY m.MAL_ID
                    """, bind_map)
                    for row in cur.fetchall():
                        m_id = int(row[0] or 0)
                        mid_stock[m_id] = int(round(float(row[1] or 0.0)))

                mkod_c30: Dict[str, int] = {}
                mkod_c90: Dict[str, int] = {}
                for i in range(0, len(all_mal_kodlari), chunk_size):
                    k_chunk = all_mal_kodlari[i:i + chunk_size]
                    bind_names = [f":k{ idx }" for idx in range(len(k_chunk))]
                    bind_map = {f"k{ idx }": val for idx, val in enumerate(k_chunk)}
                    in_clause = ",".join(bind_names)

                    cur.execute(f"""
                        SELECT h.MAL_KODU,
                               NVL(SUM(CASE WHEN h.BELGE_TARIHI >= SYSDATE - 30 AND (
                                   (UPPER(TRIM(h.BELGE_TURU)) = 'FIS' AND h.BELGE_TIP_NO IN ('01', '06')) OR
                                   UPPER(TRIM(h.BELGE_TURU)) = 'RECETE'
                               ) THEN h.MIKTAR ELSE 0 END), 0) AS C30,
                               NVL(SUM(CASE WHEN h.BELGE_TARIHI >= SYSDATE - 90 AND (
                                   (UPPER(TRIM(h.BELGE_TURU)) = 'FIS' AND h.BELGE_TIP_NO IN ('01', '06')) OR
                                   UPPER(TRIM(h.BELGE_TURU)) = 'RECETE'
                               ) THEN h.MIKTAR ELSE 0 END), 0) AS C90
                        FROM TBL_MAL_HAREKET h
                        WHERE h.MAL_KODU IN ({in_clause})
                          AND h.BELGE_TARIHI >= SYSDATE - 90
                          AND h.BELGE_TARIHI <= SYSDATE + 1
                        GROUP BY h.MAL_KODU
                    """, bind_map)
                    for row in cur.fetchall():
                        mk = str(row[0] or "").strip()
                        mkod_c30[mk] = int(round(float(row[1] or 0.0)))
                        mkod_c90[mk] = int(round(float(row[2] or 0.0)))

                orig_mids: Dict[str, set] = {}
                for m_id, origs in mal_id_to_originals.items():
                    for obc in origs:
                        orig_mids.setdefault(obc, set()).add(m_id)

                orig_mkods: Dict[str, set] = {}
                for mk, origs in mal_kodu_to_originals.items():
                    for obc in origs:
                        orig_mkods.setdefault(obc, set()).add(mk)

                all_matched_origs = set(orig_mids.keys()) | set(orig_mkods.keys())
                for obc in all_matched_origs:
                    tot_stok = sum(mid_stock.get(m, 0) for m in orig_mids.get(obc, set()))
                    tot_c30 = sum(mkod_c30.get(k, 0) for k in orig_mkods.get(obc, set()))
                    tot_c90 = sum(mkod_c90.get(k, 0) for k in orig_mkods.get(obc, set()))
                    result[obc] = {
                        "stok": int(tot_stok),
                        "cikis_1ay": int(tot_c30),
                        "cikis_3ay": int(tot_c90),
                        "found": True,
                    }

        except Exception as e:
            print(f"[TRIA] get_bulk_stock_and_sales_map hatası: {e}")

        return result

    def _get_webliste_drug_barcodes(self) -> set:
        """TİTCK SKRS resmi ilaç listesi (products.db -> WEBLISTE) barkodlarını bellekte önbellekler."""
        if self._webliste_drug_barcodes is not None:
            return self._webliste_drug_barcodes
        out = set()
        try:
            import sqlite3
            db_path = os.path.join(self.base_dir, "backend", "data", "products.db")
            if os.path.isfile(db_path):
                scon = sqlite3.connect(db_path, timeout=2.0)
                try:
                    for (bc,) in scon.execute(
                        "SELECT primary_barcode FROM products WHERE source = 'WEBLISTE' AND primary_barcode IS NOT NULL"
                    ):
                        b_clean = str(bc or "").strip()
                        if len(b_clean) >= 8:
                            out.add(b_clean)
                finally:
                    scon.close()
        except Exception:
            pass
        self._webliste_drug_barcodes = out
        return out

    def get_dead_stock_list(
        self,
        inactive_days: int = 90,
        exclude_recent_buy_days: int = 30,
        mode: str = "all",
        category: str = "all",
        min_unit_price: float = 0.0,
        search_query: str = "",
        limit: int = 300,
    ) -> Dict[str, Any]:
        """
        TRIA Oracle veritabanından (%100 Salt-Okunur SELECT + ConnectionPool + RAM _prod_index):
        - Gerçek TRIA kategori ayrımı (TBL_MAL_GRUP + ATC/DSF/Kamu/Eşdeğer/TİTCK/KDV/ÜTS):
          İlaç (ILAC), Dermo/Besin Takviyesi/OTC (OTC), Medikal/Diagnostik/İtriyat (MEDIKAL), Pasif (PASIF_ILAC);
          Bioderma, Roll Medikal vb. 8699... barkodlu ürünlerin yanlışlıkla İlaç grubuna karışmasını engeller.
        - Son alış faturasındaki (AAF/KAF/TGF) gerçek KDV dahil & iskonto/MF düşülmüş birim maliyet,
          son depo adı, son alım adedi+MF ve tarih bilgilerini hesaplar.
        """
        import math
        t0 = time.time()
        inact_days = max(15, int(inactive_days or 90))
        recent_buy_days = max(0, int(exclude_recent_buy_days if exclude_recent_buy_days is not None else 30))
        mode_norm = str(mode or "all").strip().lower()
        cat_norm = str(category or "all").strip().lower()
        min_price = max(0.0, float(min_unit_price or 0.0))
        clean_q = str(search_query or "").strip()
        lim = max(20, min(1000, int(limit or 300)))

        consumable_tokens = (
            "BIO TORBA", "ECZANE TORBA", "ECZANE POŞET", "ECZANE POSET", "PLASTİK TORBA", "PLASTIK TORBA",
            "KAĞIT TORBA", "KAGIT TORBA", "KARTON ÇANTA", "KARTON CANTA", "TERMAL RULO", "YAZARKASA RULO",
            "POS RULO", "ETİKET RULO", "ETIKET RULO", "MUAYENE ÜCRET", "MUAYENE UCRET", "KATILIM PAYI",
            "FARK ÜCRET", "MAJİSTRAL", "MAJISTRAL", "KARGO BEDEL"
        )
        excluded_group_tokens = (
            "STOK HARİCİ", "STOK HARICI", "POŞET", "POSET", "SARF MALZEME", "MAJİSTRAL", "MAJISTRAL", "FMK"
        )
        medikal_group_tokens = (
            "MEDİKAL", "MEDIKAL", "DİAGNOSTİK", "DIAGNOSTIK", "İTRİYAT", "ITRIYAT",
            "TANSİYON", "ENJEKTÖR", "ENJEKTOR", "ORTOPED", "SARF"
        )
        otc_group_tokens = (
            "DERMOKOZMETİK", "DERMOKOZMETIK", "BESİN DESTEK", "BESIN DESTEK", "BESİN TAKVİYE", "BESIN TAKVIYE",
            "VİTAMİN", "VITAMIN", "BEBEK", "HAMİLE", "HAMILE", "ANNE", "SAÇ BAKIM", "SAC BAKIM",
            "KİŞİSEL BAKIM", "KISISEL BAKIM", "KİŞİSEL SAĞLIK", "KISISEL SAGLIK", "AĞIZ VE DİŞ", "AGIZ VE DIS",
            "CİNSEL SAĞLIK", "CINSEL SAGLIK", "AROMATERAP", "ORGANİK", "ORGANIK", "GRİP SOĞUK", "GRIP SOGUK",
            "KOZMETİK", "KOZMETIK", "GÜNEŞ", "GUNES", "CİLT BAKIM", "CILT BAKIM", "PARFÜM", "PARFUM", "OTC"
        )
        # "ROLL ON" (deodorant) gibi ürünleri yakalamamak için yalnızca medikal Roll / sarf kalıpları kullanılır
        medikal_name_tokens = (
            "ROLLBANT", "ROLL BANT", "ROLL TERMOJEL", "ROLLFILM", "ROLL FİLM", "ROLLPORE", "ROLL PORE",
            "ROLLFIX", "ROLL FİX", "ROLLPLAST", "ROLL PLAST", "ROLLFLEX", "ROLL FLEX", "ROLLPED", "ROLL PED",
            "ROLLGAZ", "ROLL GAZ", "YARABAND", "YARA BAND", "YARA ÖRTÜ", "YARA ORTU", "FLASTER",
            "GAZLI BEZ", "GAZ KOM", "SARGI BEZ", "BANDAJ", "PAMUK", "ENJEKTÖR", "ENJEKTOR", "ŞIRINGA", "SIRINGA",
            "İĞNE UCU", "IGNE UCU", "ANJIOKAT", "ANJİYOKAT", "BRANÜL", "BRANUL", "KATETER", "SONDA",
            "İDRAR TORBA", "IDRAR TORBA", "KANÜL", "KANUL", "LANCET", "LANSET", "STRIP", "STRİP",
            "ŞEKER ÖLÇÜM", "SEKER OLCUM", "TANSİYON ALET", "TANSIYON ALET", "ATEŞ ÖLÇER", "ATES OLCER",
            "TERMOMETRE", "NEBÜLİZATÖR", "NEBULIZATOR", "CHAMBER", "KORSE", "DİZLİK", "DIZLIK",
            "BİLEKLİK", "BILEKLIK", "BOYUNLUK", "VARİS ÇORAB", "VARIS CORAB", "EMBOLİZM", "ENBOLIZM",
            "HASTA BEZ", "EMİCİ KÜLOT", "EMICI KULOT", "CANPED", "TENA ", "DEPEND ", "MESANE PED",
            "ELDİVEN", "ELDIVEN", "ABESLANG", "BISTÜRİ", "BISTURI", "OKSİJEN MASK", "OKSIJEN MASK",
            "NAZAL OKSİ", "NAZAL OKSI", "TERMOFOR", "BUZ TORBA", "SİNEK KAPAN", "FARE YAPIŞ", "FARE YAPIS",
            "BÖCEK", "BOCEK", "BİT TOKAS", "BIT TOKAS", "TABLET EZİCİ", "TABLET EZICI", "İLAÇ KUTU", "ILAC KUTU",
            "B-GOOD "
        )

        def _pretty_sub_label(raw_g1: str, raw_g: str, fallback: str) -> str:
            up1 = raw_g1.replace("i", "İ").upper()
            upg = raw_g.replace("i", "İ").upper()
            if "DERMOKOZMET" in up1 or "DERMOKOZMET" in upg:
                return "DERMOKOZMETİK"
            if "BESİN" in up1 or "BESIN" in up1 or "VİTAMİN" in upg or "GIDA TAKVİYE" in upg:
                return "BESİN TAKVİYESİ"
            if "AROMATERAP" in up1 or "AROMATERAP" in upg:
                return "AROMATERAPİ"
            if "BEBEK" in up1 or "HAMİLE" in up1 or "ANNE" in up1:
                return "ANNE & BEBEK"
            if "SAÇ BAKIM" in up1 or "SAC BAKIM" in up1:
                return "SAÇ BAKIM"
            if "AĞIZ" in up1 or "AGIZ" in up1:
                return "AĞIZ & DİŞ"
            if "KİŞİSEL BAKIM" in up1 or "KISISEL BAKIM" in up1:
                return "KİŞİSEL BAKIM"
            if "KİŞİSEL SAĞLIK" in up1 or "KISISEL SAGLIK" in up1:
                return "KİŞİSEL SAĞLIK"
            if "CİNSEL" in up1 or "CINSEL" in up1:
                return "CİNSEL SAĞLIK"
            if "ORGANİK" in up1 or "ORGANIK" in up1:
                return "ORGANİK / DOĞAL"
            if "DİAGNOSTİK" in up1 or "DIAGNOSTIK" in up1:
                return "DİAGNOSTİK"
            if "MEDİKAL" in up1 or "MEDIKAL" in up1:
                return "MEDİKAL"
            if "İTRİYAT" in up1 or "ITRIYAT" in up1:
                return "İTRİYAT"
            return (raw_g1 or raw_g or fallback)[:22]

        try:
            web_drugs = self._get_webliste_drug_barcodes()
            with self.get_connection() as conn:
                cur = conn.cursor()
                pidx = self._ensure_product_index(cur)
                by_id = pidx["by_id"]

                # 1. Pozitif stoğu olan tüm ürünleri gerçek TRIA kategori/meta sütunlarıyla tek sorguda çek
                cur.execute("""
                    WITH S AS (
                        SELECT m.MAL_ID,
                               NVL(
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END),
                                   0
                               ) AS STOK
                        FROM TBL_MAL_MIKTARLAR m
                        GROUP BY m.MAL_ID
                        HAVING (
                            SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                            SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END)
                        ) > 0
                    )
                    SELECT t.ID,
                           t.MAL_KODU,
                           UTL_RAW.CAST_TO_RAW(t.MAL_ADI),
                           S.STOK,
                           NVL(t.SATIS_FIYATI_1, 0),
                           NVL(t.DEPOCU_SATIS_FIYATI, 0),
                           NVL(t.SON_ALIS_FIYATI, 0),
                           NVL(t.SATIS_KDV_ID, 5),
                           t.MAL_GRUP_KODU,
                           UTL_RAW.CAST_TO_RAW(g1.MAL_GRUP_ADI),
                           UTL_RAW.CAST_TO_RAW(g.MAL_GRUP_ADI),
                           t.ATC_KODU,
                           t.KAMU_NO,
                           t.ESDEGER_GRUP_KODU,
                           NVL(t.UTS_STATUS, 0),
                           NVL(t.RECETE_TIPI, -1),
                           UTL_RAW.CAST_TO_RAW(t.ILAC_TIPI),
                           NVL(t.PASIF, 0)
                    FROM S
                    JOIN TBL_MAL_TANIM t ON t.ID = S.MAL_ID
                    LEFT JOIN TBL_MAL_GRUP g ON g.MAL_GRUP_KODU = t.MAL_GRUP_KODU
                    LEFT JOIN TBL_MAL_GRUP g1 ON g1.MAL_GRUP_KODU = SUBSTR(t.MAL_GRUP_KODU, 1, 3)
                    WHERE NVL(t.SATIS_FIYATI_1, 0) > 0
                """)
                pos_entries = []
                for row in cur.fetchall():
                    if row[0] is None:
                        continue
                    mid = int(row[0])
                    mk = str(row[1] or "").strip()
                    if not mk or mk in EXCLUDE_MAL_KODLARI:
                        continue
                    stok_i = int(round(float(row[3] or 0.0)))
                    psf_v = round(float(row[4] or 0.0), 2)
                    if stok_i <= 0 or psf_v <= 0:
                        continue
                    idx_e = by_id.get(mid) or {}
                    raw_bc = str(idx_e.get("primary_barcode") or mk).strip()
                    pos_entries.append({
                        "id": mid,
                        "mal_kodu": mk,
                        "raw_name": row[2],
                        "stok": stok_i,
                        "psf": psf_v,
                        "dsf": round(float(row[5] or 0.0), 2),
                        "son_alis_kart": round(float(row[6] or 0.0), 4),
                        "satis_kdv_id": row[7],
                        "kdv": _kdv_from_satis_kdv_id(row[7]),
                        "mal_grup_kodu": str(row[8] or "").strip(),
                        "top_grup_raw": row[9],
                        "sub_grup_raw": row[10],
                        "atc_kodu": str(row[11] or "").strip(),
                        "kamu_no": str(row[12] or "").strip(),
                        "esdeger": str(row[13] or "").strip(),
                        "uts_status": int(row[14] or 0),
                        "recete_tipi": int(row[15] if row[15] is not None else -1),
                        "ilac_tipi_raw": row[16],
                        "pasif": int(row[17] or 0),
                        "primary_barcode": raw_bc,
                    })

                prod_codes = [x["mal_kodu"] for x in pos_entries]
                sales_map: Dict[str, Tuple[str, int, int, int]] = {}
                buy_map: Dict[int, Dict[str, Any]] = {}

                # 2. Son satış tarihi, dönem çıkışı ve son 180 gün çıkışını çek (Reçete + Nakit Fiş + Satış Faturası)
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i + 900]
                    params = {f"k{idx}": c for idx, c in enumerate(chunk)}
                    binds = ",".join(f":{k}" for k in params.keys())
                    cur.execute(f"""
                        SELECT mh.MAL_KODU,
                               TO_CHAR(MAX(mh.BELGE_TARIHI), 'YYYY-MM-DD') as SON_CIKIS,
                               TRUNC(SYSDATE) - TRUNC(MAX(mh.BELGE_TARIHI)) as GECEN_GUN,
                               NVL(SUM(CASE WHEN mh.BELGE_TARIHI >= TRUNC(SYSDATE) - {inact_days} THEN ABS(mh.MIKTAR) ELSE 0 END), 0) as DONEM_ADET,
                               NVL(SUM(CASE WHEN mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 180 THEN ABS(mh.MIKTAR) ELSE 0 END), 0) as ALTAY_ADET
                        FROM TBL_MAL_HAREKET mh
                        WHERE mh.MAL_KODU IN ({binds})
                          AND (
                              UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FATURA' AND mh.BELGE_TIP_NO IN ('KSF', 'ASF'))
                          )
                        GROUP BY mh.MAL_KODU
                    """, params)
                    for r_mk, r_dt, r_gg, r_dn, r_6m in cur.fetchall():
                        if r_mk:
                            sales_map[str(r_mk).strip()] = (
                                str(r_dt or "").strip(),
                                int(r_gg) if r_gg is not None else 9999,
                                int(round(float(r_dn or 0))),
                                int(round(float(r_6m or 0))),
                            )

                # 3. Son alış faturasındaki gerçek KDV dahil & MF/iskonto düşülmüş birim maliyet, depo ve MF bilgisini çek (~135ms)
                try:
                    cur.execute("""
                        WITH S AS (
                            SELECT m.MAL_ID
                            FROM TBL_MAL_MIKTARLAR m
                            GROUP BY m.MAL_ID
                            HAVING (
                                SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                                SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END)
                            ) > 0
                        ),
                        LastBuy AS (
                            SELECT d.MAL_ID,
                                   TO_CHAR(b.BELGE_TARIHI, 'YYYY-MM-DD') AS SON_ALIS,
                                   TRUNC(SYSDATE) - TRUNC(b.BELGE_TARIHI) AS ALIS_GUN,
                                   b.TIP_NO,
                                   NVL(b.KDV_DURUMU, 0) AS KDV_DURUMU,
                                   UTL_RAW.CAST_TO_RAW(b.CARI_ADI) AS DEPO_RAW,
                                   NVL(d.MIKTAR, 0) AS MIKTAR,
                                   NVL(d.MF_MIKTAR, 0) AS MF_MIKTAR,
                                   NVL(d.TUTAR, 0) AS TUTAR,
                                   NVL(d.KDV, 0) AS KDV,
                                   NVL(d.KDV_TUTAR, 0) AS KDV_TUTAR,
                                   (
                                       NVL(d.ISKONTO_TUTAR1, 0) + NVL(d.ISKONTO_TUTAR2, 0) +
                                       NVL(d.ISKONTO_TUTAR3, 0) + NVL(d.ISKONTO_TUTAR4, 0) +
                                       NVL(d.ISKONTO_TUTAR5, 0) + NVL(d.DIP_ISKONTO, 0)
                                   ) AS TOT_ISK,
                                   ROW_NUMBER() OVER (
                                       PARTITION BY d.MAL_ID
                                       ORDER BY b.BELGE_TARIHI DESC, b.ID DESC, d.ID DESC
                                   ) AS RN
                            FROM TBL_BELGE_DETAY d
                            JOIN TBL_BELGE b ON b.ID = d.BELGE_ID
                            WHERE b.TIP_NO IN ('AAF', 'KAF', 'TGF')
                              AND NVL(d.MIKTAR, 0) > 0
                              AND NVL(d.TUTAR, 0) > 0
                              AND d.MAL_ID IN (SELECT MAL_ID FROM S)
                        )
                        SELECT MAL_ID, SON_ALIS, ALIS_GUN, TIP_NO, KDV_DURUMU, DEPO_RAW,
                               MIKTAR, MF_MIKTAR, TUTAR, KDV, KDV_TUTAR, TOT_ISK
                        FROM LastBuy
                        WHERE RN = 1
                    """)
                    for r in cur.fetchall():
                        b_mid = int(r[0])
                        b_dt = str(r[1] or "").strip()
                        b_ag = int(r[2]) if r[2] is not None else 9999
                        b_tip = str(r[3] or "").strip().upper()
                        b_kdvd = int(r[4] or 0)
                        b_depo = re.sub(r"\s+", " ", fix_tria_str(r[5])).strip()
                        if b_tip == "TGF" and b_depo and not b_depo.upper().startswith("TAKAS"):
                            b_depo = f"Takas: {b_depo}"
                        b_mik = float(r[6] or 0.0)
                        b_mf = max(0.0, float(r[7] or 0.0))
                        b_tut = float(r[8] or 0.0)
                        b_kdv = float(r[9] or 0.0)
                        b_kdvt = max(0.0, float(r[10] or 0.0))
                        b_isk = max(0.0, float(r[11] or 0.0))
                        tot_q = b_mik + b_mf
                        if tot_q <= 0 or b_tut <= 0:
                            continue
                        kdv_mult = 1.0 + (max(0.0, b_kdv) / 100.0)
                        if b_kdvd == 1:
                            # KDV dahil belge (örn. TGF Takas Giriş veya KDV dahil KAF)
                            net_kdvli = max(0.0, b_tut - b_isk)
                            unit_kdvli = round(net_kdvli / tot_q, 2)
                            if 0.0 < b_kdvt < net_kdvli:
                                unit_kdvsiz = round((net_kdvli - b_kdvt) / tot_q, 2)
                            else:
                                unit_kdvsiz = round(unit_kdvli / kdv_mult, 2) if kdv_mult > 0 else unit_kdvli
                        else:
                            # Standart depo alış faturası (KDV hariç satır tutarı - tüm iskontolar + KDV) / (Adet + MF)
                            net_kdvsiz = max(0.0, b_tut - b_isk)
                            unit_kdvsiz = round(net_kdvsiz / tot_q, 2)
                            if b_kdvt > 0:
                                unit_kdvli = round((net_kdvsiz + b_kdvt) / tot_q, 2)
                            else:
                                unit_kdvli = round(unit_kdvsiz * kdv_mult, 2)
                        if unit_kdvli > 0:
                            buy_map[b_mid] = {
                                "son_alis_iso": b_dt,
                                "son_alis_gun": b_ag,
                                "unit_kdvli": unit_kdvli,
                                "unit_kdvsiz": unit_kdvsiz,
                                "alis_adet": int(round(b_mik)),
                                "alis_mf": int(round(b_mf)),
                                "alis_depo": b_depo,
                                "kdv_oran": int(round(b_kdv)) if b_kdv > 0 else None,
                            }
                except Exception as e_buy:
                    print(f"[TRIA] get_dead_stock_list son alım fatura sorgusu uyarısı: {e_buy}")

                raw_bcs = [x["primary_barcode"] for x in pos_entries]
                canon_map: Dict[str, str] = {}
                try:
                    from backend.catalog import catalog
                    if raw_bcs:
                        canon_map = catalog.resolve_canonical_barcodes_bulk(raw_bcs)
                except Exception:
                    pass

                def _fmt_iso(dt_s: str, empty_lbl: str = "-") -> str:
                    if not dt_s or "-" not in dt_s:
                        return empty_lbl
                    pts = dt_s.split("-")
                    return f"{pts[2]}.{pts[1]}.{pts[0]}" if len(pts) == 3 else dt_s

                q_norm = clean_q.replace("i", "İ").upper() if clean_q else ""
                filtered_all = []
                for e in pos_entries:
                    mid = e["id"]
                    mk = e["mal_kodu"]
                    stok = e["stok"]
                    psf = e["psf"]
                    u_adi = re.sub(r"\s+", " ", fix_tria_str(e["raw_name"])).strip()
                    if not u_adi:
                        continue
                    up_nm = u_adi.replace("i", "İ").upper()
                    if any(tok in up_nm for tok in consumable_tokens):
                        continue
                    if psf < 25.0 and any(k in up_nm for k in ("ENJEKTÖR", "ENJEKTOR", "ŞIRINGA", "SIRINGA", "İĞNE UCU", "IGNE UCU")):
                        continue

                    g1_nm = re.sub(r"\s+", " ", fix_tria_str(e["top_grup_raw"])).strip()
                    g_nm = re.sub(r"\s+", " ", fix_tria_str(e["sub_grup_raw"])).strip()
                    g1_up = g1_nm.replace("i", "İ").upper()
                    g_up = g_nm.replace("i", "İ").upper()
                    itip_up = re.sub(r"\s+", " ", fix_tria_str(e["ilac_tipi_raw"])).strip().replace("i", "İ").upper()

                    if any(tok in g1_up or tok in g_up for tok in excluded_group_tokens):
                        continue

                    raw_bc = e["primary_barcode"]
                    bc_final = canon_map.get(raw_bc, raw_bc) or raw_bc

                    atc_s = e["atc_kodu"]
                    kamu_s = e["kamu_no"]
                    esd_s = e["esdeger"]
                    dsf_v = e["dsf"]
                    kdv_oran = int(round(e["kdv"]))
                    uts_i = e["uts_status"]
                    rec_i = e["recete_tipi"]

                    has_real_esd = bool(esd_s and not esd_s.upper().startswith("E999"))
                    has_real_atc = bool(
                        len(atc_s) >= 3
                        and atc_s[0].isalpha()
                        and not atc_s.upper().startswith(("V07", "R01AX10"))
                    )
                    is_kdv_drug = (kdv_oran == 10)
                    is_in_webliste = (bc_final in web_drugs) or (raw_bc in web_drugs)
                    has_strong_drug_sig = (
                        (dsf_v > 0 and is_kdv_drug)
                        or bool(kamu_s)
                        or has_real_esd
                        or is_in_webliste
                        or ("BEŞERİ İLAÇ" in itip_up or "BESERI ILAC" in itip_up)
                    )
                    is_otc_group = any(tok in g1_up or tok in g_up for tok in otc_group_tokens)

                    if e["pasif"] == 1:
                        kat = "PASIF_ILAC"
                        alt_kat = "PASİF İLAÇ"
                    elif not has_strong_drug_sig and (
                        any(tok in g1_up or tok in g_up for tok in medikal_group_tokens)
                        or any(tok in up_nm for tok in medikal_name_tokens)
                        or (uts_i == 1 and not is_otc_group)
                    ):
                        kat = "MEDIKAL"
                        alt_kat = _pretty_sub_label(g1_nm, g_nm, "MEDİKAL")
                        if alt_kat not in ("MEDİKAL", "DİAGNOSTİK", "İTRİYAT"):
                            alt_kat = "MEDİKAL"
                    elif has_strong_drug_sig:
                        if kdv_oran in (1, 20) and not is_in_webliste and not kamu_s:
                            kat = "OTC"
                            alt_kat = _pretty_sub_label(g1_nm, g_nm, "DERMO / OTC")
                        else:
                            kat = "ILAC"
                            alt_kat = "TIBBİ MAMA" if atc_s.upper().startswith("V06D") else "İLAÇ"
                    elif is_otc_group or any(k in itip_up for k in ("DERMO", "KOZMET", "OTC", "TAKVİYE", "TAKVIYE")):
                        kat = "OTC"
                        alt_kat = _pretty_sub_label(g1_nm, g_nm, "DERMO / OTC")
                    elif kdv_oran in (1, 20):
                        kat = "OTC"
                        alt_kat = "BESİN TAKVİYESİ" if kdv_oran == 1 else "DERMO / OTC"
                    elif has_real_atc or rec_i >= 0 or (g1_up in ("İLAÇ", "ILAC") and g_up not in ("DİĞER", "DIGER")):
                        kat = "ILAC"
                        alt_kat = "İLAÇ"
                    else:
                        kat = "OTC"
                        alt_kat = _pretty_sub_label(g1_nm, g_nm, "OTC")

                    # Kategori filtrelemesi (Botanik ile %100 aynı kontrat)
                    if cat_norm in ("takas", "drug_otc"):
                        if kat not in ("ILAC", "OTC"):
                            continue
                    elif cat_norm == "drug" and kat != "ILAC":
                        continue
                    elif cat_norm == "otc" and kat != "OTC":
                        continue
                    elif cat_norm == "medikal" and kat != "MEDIKAL":
                        continue
                    elif cat_norm == "pasif" and kat != "PASIF_ILAC":
                        continue

                    if q_norm and q_norm not in up_nm and clean_q not in bc_final and clean_q not in raw_bc and q_norm not in alt_kat.replace("i", "İ").upper():
                        continue

                    s_dt, gecen_gun, donem_cikis, alt_ay_cikis = sales_map.get(mk, ("", 9999, 0, 0))
                    inv = buy_map.get(mid)
                    if inv:
                        a_dt = inv["son_alis_iso"]
                        son_alis_gun = inv["son_alis_gun"]
                        birim_maliyet_kdvli = inv["unit_kdvli"]
                        birim_maliyet_kdvsiz = inv["unit_kdvsiz"]
                        alis_adet = inv["alis_adet"]
                        alis_mf = inv["alis_mf"]
                        alis_depo = inv["alis_depo"]
                        fatura_maliyeti_var = True
                        if inv.get("kdv_oran") is not None:
                            kdv_oran = int(inv["kdv_oran"])
                    else:
                        a_dt = ""
                        son_alis_gun = 9999
                        alis_adet = 0
                        alis_mf = 0
                        kdv_mult = 1.0 + (max(0, kdv_oran) / 100.0)
                        son_kart = e["son_alis_kart"]
                        if 0.0 < son_kart <= psf * 1.15:
                            birim_maliyet_kdvsiz = round(son_kart, 2)
                            birim_maliyet_kdvli = round(son_kart * kdv_mult, 2)
                            alis_depo = "TRIA Kart Kaydı"
                            fatura_maliyeti_var = True
                        else:
                            birim_maliyet_kdvli = round(psf * 0.71, 2)
                            birim_maliyet_kdvsiz = round(birim_maliyet_kdvli / kdv_mult, 2)
                            alis_depo = ""
                            fatura_maliyeti_var = False

                    if min_price > 0 and psf < min_price and birim_maliyet_kdvli < min_price:
                        continue

                    if recent_buy_days > 0 and son_alis_gun < recent_buy_days and donem_cikis == 0:
                        continue

                    durum_tipi = ""
                    satilabilir = 0
                    aylik_hiz = round(alt_ay_cikis / 6.0, 2)
                    if donem_cikis <= 0:
                        durum_tipi = "HAREKETSIZ"
                        satilabilir = stok
                    elif stok >= 4 and aylik_hiz <= 4.0 and gecen_gun >= 10 and (aylik_hiz <= 0 or (stok / max(0.25, aylik_hiz)) >= 8.0) and son_alis_gun >= max(14, recent_buy_days):
                        keep_qty = max(2, math.ceil(aylik_hiz * 2.0))
                        if stok - keep_qty >= 2:
                            durum_tipi = "FAZLA_STOK"
                            satilabilir = stok - keep_qty

                    if not durum_tipi or satilabilir <= 0:
                        continue
                    if mode_norm == "dead" and durum_tipi != "HAREKETSIZ":
                        continue
                    if mode_norm == "overstock" and durum_tipi != "FAZLA_STOK":
                        continue

                    alis_mf_etiket = ""
                    if fatura_maliyeti_var and alis_adet > 0:
                        alis_mf_etiket = f"{alis_adet}+{alis_mf} MF" if alis_mf > 0 else f"{alis_adet} Adet"

                    sat_psf = round(satilabilir * psf, 2)
                    gercek_bagli = round(satilabilir * birim_maliyet_kdvli, 2)
                    raf_toplam = round(stok * birim_maliyet_kdvli, 2)
                    filtered_all.append({
                        "urun_id": mid,
                        "barkod": bc_final,
                        "urun_adi": u_adi,
                        "kategori": kat,
                        "alt_kategori": alt_kat,
                        "kdv_oran": kdv_oran,
                        "stok": stok,
                        "satilabilir_adet": satilabilir,
                        "psf": psf,
                        "bagli_tutar_psf": round(stok * psf, 2),
                        "satilabilir_tutar_psf": sat_psf,
                        "son_birim_maliyet_kdvli": birim_maliyet_kdvli,
                        "son_birim_maliyet_kdvsiz": birim_maliyet_kdvsiz,
                        "fatura_maliyeti_var": fatura_maliyeti_var,
                        "gercek_bagli_maliyet": gercek_bagli,
                        "raf_toplam_maliyet": raf_toplam,
                        "tahmini_maliyet_tutar": gercek_bagli,
                        "son_alis_adet": alis_adet,
                        "son_alis_mf": alis_mf,
                        "son_alis_mf_etiket": alis_mf_etiket,
                        "son_alis_depo": alis_depo,
                        "son_cikis_tarihi": _fmt_iso(s_dt, "Hiç Çıkmadı"),
                        "gecen_gun": gecen_gun,
                        "donem_cikis": donem_cikis,
                        "son_6ay_cikis": alt_ay_cikis,
                        "aylik_hiz": aylik_hiz,
                        "son_alis_tarihi": _fmt_iso(a_dt, "-"),
                        "durum_tipi": durum_tipi,
                    })

                filtered_all.sort(key=lambda x: (x["gercek_bagli_maliyet"], x["satilabilir_tutar_psf"]), reverse=True)
                total_dead_cnt = sum(1 for x in filtered_all if x["durum_tipi"] == "HAREKETSIZ")
                total_over_cnt = sum(1 for x in filtered_all if x["durum_tipi"] == "FAZLA_STOK")
                invoiced_cnt = sum(1 for x in filtered_all if x.get("fatura_maliyeti_var"))
                total_boxes = sum(x["satilabilir_adet"] for x in filtered_all)
                total_psf_val = round(sum(x["satilabilir_tutar_psf"] for x in filtered_all), 2)
                total_shelf_val = round(sum(x["bagli_tutar_psf"] for x in filtered_all), 2)
                total_real_cost = round(sum(x["gercek_bagli_maliyet"] for x in filtered_all), 2)

                return {
                    "success": True,
                    "source": "TRIA",
                    "has_real_invoice_cost": True,
                    "elapsed_ms": round((time.time() - t0) * 1000, 1),
                    "stats": {
                        "total_items": len(filtered_all),
                        "shown_items": min(len(filtered_all), lim),
                        "invoiced_items": invoiced_cnt,
                        "dead_count": total_dead_cnt,
                        "overstock_count": total_over_cnt,
                        "sellable_boxes": total_boxes,
                        "real_cost_total": total_real_cost,
                        "sellable_psf_total": total_psf_val,
                        "shelf_psf_total": total_shelf_val,
                        "estimated_cash_potential": round(total_psf_val * 0.68, 2),
                    },
                    "items": filtered_all[:lim],
                }
        except Exception as e:
            print(f"[TRIA] get_dead_stock_list hatası: {e}")
            return {"success": False, "source": "TRIA", "error": str(e), "stats": {}, "items": []}

    def _fetch_last_purchase_map_cached(self, cur, prod_codes: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Verilen MAL_KODU listesi için son alış faturasındaki gerçek KDV dahil & MF/iskonto düşülmüş
        birim maliyeti, depo ve tarihi 15 dk RAM önbelleği ile çeker (%100 SELECT, BELGEDETAY_MKODU_NDX).
        """
        if not hasattr(self, "_last_buy_cache"):
            self._last_buy_cache: Dict[str, Any] = {}
        now = time.time()
        ttl = 900.0
        result: Dict[str, Dict[str, Any]] = {}
        missing: List[str] = []

        for mk in (prod_codes or []):
            mk_s = str(mk or "").strip()
            if not mk_s:
                continue
            hit = self._last_buy_cache.get(mk_s)
            if hit is not None and (now - hit[0]) < ttl:
                if hit[1]:
                    result[mk_s] = hit[1]
            else:
                missing.append(mk_s)

        if not missing:
            return result

        try:
            fetched_map: Dict[str, Dict[str, Any]] = {}
            for i in range(0, len(missing), 400):
                chunk = missing[i:i + 400]
                params = {f"k{j}": c for j, c in enumerate(chunk)}
                binds = ",".join(f":{k}" for k in params.keys())
                cur.execute(f"""
                    SELECT MAL_KODU, SON_ALIS, TIP_NO, KDV_DURUMU, DEPO_RAW,
                           MIKTAR, MF_MIKTAR, TUTAR, KDV, KDV_TUTAR, TOT_ISK
                    FROM (
                        SELECT d.MAL_KODU,
                               TO_CHAR(b.BELGE_TARIHI, 'YYYY-MM-DD') AS SON_ALIS,
                               b.TIP_NO,
                               NVL(b.KDV_DURUMU, 0) AS KDV_DURUMU,
                               UTL_RAW.CAST_TO_RAW(b.CARI_ADI) AS DEPO_RAW,
                               NVL(d.MIKTAR, 0) AS MIKTAR,
                               NVL(d.MF_MIKTAR, 0) AS MF_MIKTAR,
                               NVL(d.TUTAR, 0) AS TUTAR,
                               NVL(d.KDV, 0) AS KDV,
                               NVL(d.KDV_TUTAR, 0) AS KDV_TUTAR,
                               (
                                   NVL(d.ISKONTO_TUTAR1, 0) + NVL(d.ISKONTO_TUTAR2, 0) +
                                   NVL(d.ISKONTO_TUTAR3, 0) + NVL(d.ISKONTO_TUTAR4, 0) +
                                   NVL(d.ISKONTO_TUTAR5, 0) + NVL(d.DIP_ISKONTO, 0)
                               ) AS TOT_ISK,
                               ROW_NUMBER() OVER (PARTITION BY d.MAL_KODU ORDER BY b.BELGE_TARIHI DESC, b.ID DESC, d.ID DESC) AS RN
                        FROM TBL_BELGE_DETAY d
                        JOIN TBL_BELGE b ON b.ID = d.BELGE_ID
                        WHERE d.MAL_KODU IN ({binds})
                          AND b.TIP_NO IN ('AAF', 'KAF', 'TGF')
                          AND NVL(d.MIKTAR, 0) > 0
                          AND NVL(d.TUTAR, 0) > 0
                    ) WHERE RN = 1
                """, params)
                for r in cur.fetchall():
                    mk_r = str(r[0] or "").strip()
                    if not mk_r:
                        continue
                    b_dt = str(r[1] or "").strip()
                    pts = b_dt.split("-") if "-" in b_dt else []
                    t_tr = f"{pts[2]}.{pts[1]}.{pts[0]}" if len(pts) == 3 else b_dt
                    b_tip = str(r[2] or "").strip().upper()
                    b_kdvd = int(r[3] or 0)
                    b_depo = re.sub(r"\s+", " ", fix_tria_str(r[4])).strip()
                    if b_tip == "TGF" and b_depo and not b_depo.upper().startswith("TAKAS"):
                        b_depo = f"Takas: {b_depo}"
                    b_mik = float(r[5] or 0.0)
                    b_mf = max(0.0, float(r[6] or 0.0))
                    b_tut = float(r[7] or 0.0)
                    b_kdv = float(r[8] or 0.0)
                    b_kdvt = max(0.0, float(r[9] or 0.0))
                    b_isk = max(0.0, float(r[10] or 0.0))
                    tot_q = b_mik + b_mf
                    if tot_q <= 0 or b_tut <= 0:
                        continue
                    kdv_mult = 1.0 + (max(0.0, b_kdv) / 100.0)
                    if b_kdvd == 1:
                        net_kdvli = max(0.0, b_tut - b_isk)
                        unit_kdvli = round(net_kdvli / tot_q, 2)
                    else:
                        net_kdvsiz = max(0.0, b_tut - b_isk)
                        unit_kdvsiz = round(net_kdvsiz / tot_q, 2)
                        unit_kdvli = round((net_kdvsiz + b_kdvt) / tot_q, 2) if b_kdvt > 0 else round(unit_kdvsiz * kdv_mult, 2)
                    if unit_kdvli > 0:
                        adet_i = int(round(b_mik))
                        mf_i = int(round(b_mf))
                        fetched_map[mk_r] = {
                            "maliyet_kdvli": unit_kdvli,
                            "tarih_iso": b_dt,
                            "tarih_tr": t_tr,
                            "depo": b_depo,
                            "adet": adet_i,
                            "mf": mf_i,
                            "mf_etiket": f"{adet_i}+{mf_i} MF" if mf_i > 0 else "",
                        }
            for mk_m in missing:
                val = fetched_map.get(mk_m)
                self._last_buy_cache[mk_m] = (now, val)
                if val:
                    result[mk_m] = val
        except Exception as e_lb:
            print(f"[TRIA] _fetch_last_purchase_map_cached uyarısı: {e_lb}")
        return result

    def get_near_expiry_list(
        self,
        months: int = 6,
        include_expired: bool = False,
        category: str = "takas",
        min_unit_price: float = 0.0,
        search_query: str = "",
        limit: int = 300,
    ) -> Dict[str, Any]:
        """
        TRIA Oracle veritabanından (%100 Salt-Okunur SELECT):
        - TBL_MIAD_MIKTARLAR üzerinden miadı yaklaşan pozitif lotları çeker.
        - FEFO mantığıyla her ürünün miadı yaklaşan lotlarını gerçek Altın Stok (TBL_MAL_MIKTARLAR) ile sınırlar.
        - Gerçek TRIA kategori ayrımı + son 6 aylık çıkış hızı + TBL_BELGE_DETAY gerçek KDV dahil fatura birim maliyeti hesaplar.
        """
        import calendar
        t0 = time.time()
        horizon_months = max(1, min(24, int(months or 6)))
        cat_norm = (category or "takas").strip().lower()
        min_price = max(0.0, float(min_unit_price or 0.0))
        clean_q = (search_query or "").strip()
        lim = max(20, min(1000, int(limit or 300)))

        today = datetime.date.today()
        target_m = today.month + horizon_months
        target_y = today.year + (target_m - 1) // 12
        target_m = ((target_m - 1) % 12) + 1
        target_d = min(today.day, calendar.monthrange(target_y, target_m)[1])
        cutoff_date = datetime.date(target_y, target_m, target_d)
        min_date = (today - datetime.timedelta(days=180)) if include_expired else today

        consumable_tokens = (
            "POŞET", "POSET", "TORBA", "AMBALAJ", "BARKOD ETİKET", "BARKOD ETIKET",
            "TERMAL RULO", "YAZARKASA", "POS RULO", "KARGO", "MAJİSTRAL", "MAJISTRAL",
            "ŞİŞE BOŞ", "SISE BOS", "KAPAK ", "ETİKET ", "ETIKET "
        )
        excluded_group_tokens = ("MAJISTRAL", "MAJİSTRAL", "AMBALAJ", "POSET", "POŞET", "DEMIRBAS", "DEMİRBAŞ")
        medikal_group_tokens = (
            "MEDIKAL", "MEDİKAL", "ITRIYAT", "İTRİYAT", "TIBBI SARF", "TIBBİ SARF",
            "SARF", "ORTOPED", "OPTIK", "OPTİK", "CIHAZ", "CİHAZ", "ENJEKTOR", "ENJEKTÖR",
            "PANSUMAN", "YARA BAND", "FLASTER", "GAZLI", "PAMUK", "ELDIVEN", "ELDİVEN",
            "MASKE", "DIAGNOSTIK", "DİAGNOSTİK", "TEST", "STRİP", "STRIP", "LANS",
            "SONDA", "KATETER", "BANT", "TERMOMETRE", "TANSIYON", "TANSİYON", "NEBUL",
            "BEZ", "PREZERVAT", "KONDOM", "PED ", "PEDİ", "TAMPON", "GÖZLÜK", "GOZLUK"
        )
        medikal_name_tokens = (
            "YARA BAND", "FLASTER", "GAZLI BEZ", "STERIL GAZ", "STERİL GAZ", "BANDAJ",
            "SARG", "ELASTIK BAND", "ELASTİK BAND", "PAMUK", "ELDIVEN", "ELDİVEN",
            "MASKE", "ENJEKTÖR", "ENJEKTOR", "ŞIRINGA", "SIRINGA", "İĞNE UCU", "IGNE UCU",
            "İNSEKTİSİT", "ATEL ", "DİZLİK", "DIZLIK", "BİLEKLİK", "BILEKLIK", "KORSE",
            "BOYUNLUK", "VARİS ÇORAB", "VARIS CORAB", "TANSİYON ALET", "TANSIYON ALET",
            "ATEŞ ÖLÇER", "ATES OLCER", "TERMOMETRE", "NEBULİZATÖR", "NEBULIZATOR",
            "GLUKOMETRE", "ŞEKER ÖLÇÜM", "SEKER OLCUM", "STRIP", "STRİP", "LANSET",
            "GEBELİK TEST", "GEBELIK TEST", "OVULASYON TEST", "İDRAR KABI", "IDRAR KABI",
            "SONDA", "KATETER", "KANÜL", "KANUL", "BRAUNUL", "SERUM SET", "KULAK TIKAC",
            "HİJYENİK PED", "GUNLUK PED", "HASTA BEZ", "EMZİK", "EMZIK", "BİBERON", "BIBERON",
            "DİŞ FIRÇAS", "DIS FIRCAS", "DİŞ İPİ", "DIS IPI", "ARAYÜZ FIRÇ", "ROLL MED",
            "ROLL ", "OKSİJEN MASKE", "OKSIJEN MASKE", "SPACER", "AEROCHAMBER"
        )
        otc_group_tokens = (
            "DERMO", "KOZMET", "GIDA TAKV", "BESIN", "BESİN", "VITAMIN", "VİTAMİN",
            "TAKVİYE", "TAKVIYE", "OTC", "FİTOTERAP", "FITOTERAP", "AROMATERAP",
            "BEBEK", "ANNE", "MAMA", "GÜNEŞ", "GUNES", "SAÇ", "SAC", "CİLT", "CILT",
            "AĞIZ", "AGIZ", "DİŞ", "DIS", "ŞAMPUAN", "SAMPUAN", "KREM", "LOSYON",
            "SERUM KOZ", "GÜZELLİK", "GUZELLIK", "KİŞİSEL BAKIM", "KISISEL BAKIM", "PARFUM", "PARFÜM"
        )

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                idx = self._ensure_product_index(cur)
                by_id = idx["by_id"]

                # 1. TBL_MIAD_MIKTARLAR üzerinden miadı yaklaşan pozitif lotları çek
                cur.execute("""
                    SELECT mm.MAL_ID,
                           TO_CHAR(mm.MIAD, 'YYYY-MM-DD') AS MIAD_ISO,
                           SUM(NVL(mm.GIREN_MIKTAR, 0) - NVL(mm.CIKAN_MIKTAR, 0)) AS KALAN
                    FROM TBL_MIAD_MIKTARLAR mm
                    WHERE mm.MIAD IS NOT NULL
                      AND mm.MIAD >= TO_DATE(:d_min, 'YYYY-MM-DD')
                      AND mm.MIAD <= TO_DATE(:d_max, 'YYYY-MM-DD')
                    GROUP BY mm.MAL_ID, TO_CHAR(mm.MIAD, 'YYYY-MM-DD')
                    HAVING SUM(NVL(mm.GIREN_MIKTAR, 0) - NVL(mm.CIKAN_MIKTAR, 0)) > 0
                """, {"d_min": min_date.isoformat(), "d_max": cutoff_date.isoformat()})

                lots_by_mid: Dict[int, Dict[str, int]] = {}
                for r_mid, r_iso, r_qty in cur.fetchall():
                    if not r_mid or not r_iso:
                        continue
                    qty_i = int(round(float(r_qty or 0)))
                    if qty_i <= 0:
                        continue
                    mid_i = int(r_mid)
                    lots_by_mid.setdefault(mid_i, {})[str(r_iso).strip()[:10]] = qty_i

                target_mids = list(lots_by_mid.keys())
                if not target_mids:
                    return {
                        "success": True,
                        "source": "TRIA",
                        "has_real_invoice_cost": True,
                        "elapsed_ms": round((time.time() - t0) * 1000, 1),
                        "stats": {"total_items": 0, "shown_items": 0, "expired_count": 0, "critical_3m_count": 0, "near_6m_count": 0, "expiring_boxes": 0, "real_cost_total": 0.0, "psf_total": 0.0},
                        "items": [],
                    }

                # 2. Gerçek Altın Stok + Mal Tanım + Grup Meta bilgilerini çek
                pos_entries: List[Dict[str, Any]] = []
                for i in range(0, len(target_mids), 500):
                    chunk = target_mids[i:i + 500]
                    params = {f"m{j}": mid_v for j, mid_v in enumerate(chunk)}
                    binds = ",".join(f":{k}" for k in params.keys())
                    cur.execute(f"""
                        WITH S AS (
                            SELECT m.MAL_ID,
                                   (
                                       SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                                       SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END)
                                   ) AS STOK
                            FROM TBL_MAL_MIKTARLAR m
                            WHERE m.MAL_ID IN ({binds})
                            GROUP BY m.MAL_ID
                            HAVING (
                                SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                                SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END)
                            ) > 0
                        )
                        SELECT s.MAL_ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), s.STOK,
                               NVL(t.SATIS_FIYATI_1, 0), NVL(t.DEPOCU_SATIS_FIYATI, 0),
                               NVL(t.SATIS_KDV_ID, 5), NVL(t.MAL_GRUP_KODU, ''),
                               UTL_RAW.CAST_TO_RAW(NVL(g1.MAL_GRUP_ADI, '')),
                               UTL_RAW.CAST_TO_RAW(NVL(g.MAL_GRUP_ADI, '')),
                               NVL(t.ATC_KODU, ''), NVL(t.KAMU_NO, ''), NVL(t.ESDEGER_GRUP_KODU, ''),
                               NVL(t.UTS_STATUS, 0), NVL(t.RECETE_TIPI, -1),
                               UTL_RAW.CAST_TO_RAW(NVL(t.ILAC_TIPI, '')), NVL(t.PASIF, 0)
                        FROM S s
                        JOIN TBL_MAL_TANIM t ON t.ID = s.MAL_ID
                        LEFT JOIN TBL_MAL_GRUP g ON g.MAL_GRUP_KODU = t.MAL_GRUP_KODU
                        LEFT JOIN TBL_MAL_GRUP g1 ON g1.MAL_GRUP_KODU = SUBSTR(t.MAL_GRUP_KODU, 1, 3)
                    """, params)
                    for row in cur.fetchall():
                        mid = int(row[0])
                        mk = str(row[1] or "").strip()
                        if not mk or mk in EXCLUDE_MAL_KODLARI:
                            continue
                        stok_i = int(round(float(row[3] or 0)))
                        if stok_i <= 0:
                            continue
                        idx_e = by_id.get(mid) or {}
                        raw_bc = str(idx_e.get("primary_barcode") or mk).strip()
                        pos_entries.append({
                            "id": mid,
                            "mal_kodu": mk,
                            "raw_name": row[2],
                            "stok": stok_i,
                            "psf": round(float(row[4] or 0.0), 2),
                            "dsf": round(float(row[5] or 0.0), 2),
                            "kdv": _kdv_from_satis_kdv_id(row[6]),
                            "mal_grup_kodu": str(row[7] or "").strip(),
                            "top_grup_raw": row[8],
                            "sub_grup_raw": row[9],
                            "atc_kodu": str(row[10] or "").strip(),
                            "kamu_no": str(row[11] or "").strip(),
                            "esdeger": str(row[12] or "").strip(),
                            "uts_status": int(row[13] or 0),
                            "recete_tipi": int(row[14] if row[14] is not None else -1),
                            "ilac_tipi_raw": row[15],
                            "pasif": int(row[16] or 0),
                            "primary_barcode": raw_bc,
                        })

                if not pos_entries:
                    return {
                        "success": True,
                        "source": "TRIA",
                        "has_real_invoice_cost": True,
                        "elapsed_ms": round((time.time() - t0) * 1000, 1),
                        "stats": {"total_items": 0, "shown_items": 0, "expired_count": 0, "critical_3m_count": 0, "near_6m_count": 0, "expiring_boxes": 0, "real_cost_total": 0.0, "psf_total": 0.0},
                        "items": [],
                    }

                prod_codes = [x["mal_kodu"] for x in pos_entries]
                sales_6m_map: Dict[str, int] = {}
                for i in range(0, len(prod_codes), 800):
                    chunk = prod_codes[i:i + 800]
                    params = {f"k{j}": c for j, c in enumerate(chunk)}
                    binds = ",".join(f":{k}" for k in params.keys())
                    cur.execute(f"""
                        SELECT mh.MAL_KODU, NVL(SUM(ABS(mh.MIKTAR)), 0)
                        FROM TBL_MAL_HAREKET mh
                        WHERE mh.MAL_KODU IN ({binds})
                          AND mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 180
                          AND (
                              UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FATURA' AND mh.BELGE_TIP_NO IN ('KSF', 'ASF'))
                          )
                        GROUP BY mh.MAL_KODU
                    """, params)
                    for r_mk, r_sum in cur.fetchall():
                        if r_mk:
                            sales_6m_map[str(r_mk).strip()] = int(round(float(r_sum or 0)))

                last_buy_map = self._fetch_last_purchase_map_cached(cur, prod_codes)

                canon_map: Dict[str, str] = {}
                try:
                    from backend.catalog import catalog
                    raw_bcs = [x["primary_barcode"] for x in pos_entries if x["primary_barcode"]]
                    if raw_bcs:
                        canon_map = catalog.resolve_canonical_barcodes_bulk(raw_bcs)
                except Exception:
                    pass

                q_norm = clean_q.replace("i", "İ").upper() if clean_q else ""
                rows_out = []
                for e in pos_entries:
                    mid = e["id"]
                    mk = e["mal_kodu"]
                    stok = e["stok"]
                    psf = e["psf"]
                    u_adi = re.sub(r"\s+", " ", fix_tria_str(e["raw_name"])).strip()
                    if not u_adi:
                        continue
                    up_nm = u_adi.replace("i", "İ").upper()
                    if any(tok in up_nm for tok in consumable_tokens):
                        continue

                    g1_nm = re.sub(r"\s+", " ", fix_tria_str(e["top_grup_raw"])).strip()
                    g_nm = re.sub(r"\s+", " ", fix_tria_str(e["sub_grup_raw"])).strip()
                    g1_up = g1_nm.replace("i", "İ").upper()
                    g_up = g_nm.replace("i", "İ").upper()
                    if any(tok in g1_up or tok in g_up for tok in excluded_group_tokens):
                        continue

                    raw_bc = e["primary_barcode"]
                    bc_final = canon_map.get(raw_bc, raw_bc) or raw_bc
                    if q_norm and q_norm not in up_nm and clean_q not in bc_final and clean_q not in raw_bc and clean_q not in mk:
                        continue

                    atc = e["atc_kodu"]
                    has_real_atc = bool(len(atc) >= 3 and atc[0].isalpha() and any(ch.isdigit() for ch in atc))
                    is_drug_sig = (
                        e["dsf"] > 0
                        or has_real_atc
                        or bool(e["kamu_no"])
                        or bool(e["esdeger"])
                        or (e["recete_tipi"] in (0, 1, 2, 3, 4, 5))
                    )
                    if e["pasif"] == 1:
                        kat = "PASIF_ILAC"
                        alt_kat = "Pasif İlaç"
                    elif is_drug_sig:
                        kat = "ILAC"
                        alt_kat = g_nm or g1_nm or "İlaç"
                    elif e["uts_status"] == 1 or any(tok in g1_up or tok in g_up for tok in medikal_group_tokens) or any(tok in up_nm for tok in medikal_name_tokens):
                        kat = "MEDIKAL"
                        alt_kat = g_nm or g1_nm or "Medikal"
                    elif any(tok in g1_up or tok in g_up for tok in otc_group_tokens) or e["kdv"] in (1.0, 20.0):
                        kat = "OTC"
                        alt_kat = g_nm or g1_nm or "Dermo / OTC"
                    else:
                        kat = "OTC"
                        alt_kat = g_nm or g1_nm or "OTC"

                    if cat_norm in ("takas", "drug_otc") and kat not in ("ILAC", "OTC"):
                        continue
                    elif cat_norm == "drug" and kat != "ILAC":
                        continue
                    elif cat_norm == "otc" and kat != "OTC":
                        continue
                    elif cat_norm == "medikal" and kat != "MEDIKAL":
                        continue
                    elif cat_norm == "pasif" and kat != "PASIF_ILAC":
                        continue

                    lb = last_buy_map.get(mk) or {}
                    unit_cost = float(lb.get("maliyet_kdvli") or 0.0)
                    has_inv = unit_cost > 0
                    if not has_inv:
                        unit_cost = round(psf * 0.71, 2) if psf > 0 else 0.0
                    if min_price > 0 and psf < min_price and unit_cost < min_price:
                        continue

                    rem_stock = stok
                    sorted_lots = sorted((lots_by_mid.get(mid) or {}).items(), key=lambda x: x[0])
                    if not sorted_lots:
                        continue
                    earliest_iso = ""
                    total_exp_qty = 0
                    lot_details = []
                    for m_iso, m_qty in sorted_lots:
                        if rem_stock <= 0:
                            break
                        eff_qty = min(int(m_qty or 0), rem_stock)
                        if eff_qty <= 0:
                            continue
                        rem_stock -= eff_qty
                        total_exp_qty += eff_qty
                        if not earliest_iso:
                            earliest_iso = m_iso
                        pts = m_iso.split("-")
                        m_tr = f"{pts[2]}.{pts[1]}.{pts[0]}" if len(pts) == 3 else m_iso
                        lot_details.append({"miad_iso": m_iso, "miad_tr": m_tr, "adet": eff_qty})

                    if total_exp_qty <= 0 or not earliest_iso:
                        continue

                    try:
                        exp_dt = datetime.date.fromisoformat(earliest_iso)
                        kalan_gun = (exp_dt - today).days
                    except Exception:
                        kalan_gun = 999

                    pts0 = earliest_iso.split("-")
                    earliest_tr = f"{pts0[2]}.{pts0[1]}.{pts0[0]}" if len(pts0) == 3 else earliest_iso
                    alt_ay = int(sales_6m_map.get(mk, 0))
                    aylik_hiz = round(alt_ay / 6.0, 2)
                    tahmini_satis = round((max(0, kalan_gun) / 30.0) * aylik_hiz, 1) if kalan_gun > 0 else 0.0
                    satilamayacak_risk = max(0, int(round(total_exp_qty - tahmini_satis)))

                    if kalan_gun < 0:
                        risk = "GECMIS"
                    elif kalan_gun <= 90:
                        risk = "KRITIK_3AY"
                    elif kalan_gun <= 180:
                        risk = "YAKIN_6AY"
                    else:
                        risk = "IZLE_9AY"

                    rows_out.append({
                        "urun_id": mid,
                        "barkod": bc_final,
                        "urun_adi": u_adi,
                        "kategori": kat,
                        "alt_kategori": alt_kat,
                        "kdv_oran": int(round(e["kdv"])),
                        "stok": stok,
                        "miad_adet": total_exp_qty,
                        "satilabilir_adet": total_exp_qty,
                        "miad_iso": earliest_iso,
                        "miad_tr": earliest_tr,
                        "kalan_gun": kalan_gun,
                        "risk_seviyesi": risk,
                        "lot_sayisi": len(lot_details),
                        "lotlar": lot_details[:5],
                        "miad_kaynak": "TRIA_MIAD",
                        "psf": psf,
                        "son_birim_maliyet_kdvli": unit_cost,
                        "fatura_maliyeti_var": has_inv,
                        "gercek_bagli_maliyet": round(total_exp_qty * unit_cost, 2),
                        "satilabilir_tutar_psf": round(total_exp_qty * psf, 2),
                        "son_alis_tarihi": lb.get("tarih_tr") or "-",
                        "son_alis_depo": lb.get("depo") or "",
                        "son_alis_mf_etiket": lb.get("mf_etiket") or "",
                        "son_6ay_cikis": alt_ay,
                        "aylik_hiz": aylik_hiz,
                        "miada_kadar_tahmini_satis": tahmini_satis,
                        "satilamayacak_risk_adet": satilamayacak_risk,
                    })

                rows_out.sort(key=lambda x: (x["kalan_gun"], -x["gercek_bagli_maliyet"]))

                expired_cnt = sum(1 for x in rows_out if x["kalan_gun"] < 0)
                crit_3m_cnt = sum(1 for x in rows_out if 0 <= x["kalan_gun"] <= 90)
                near_6m_cnt = sum(1 for x in rows_out if 90 < x["kalan_gun"] <= 180)
                exp_boxes = sum(x["miad_adet"] for x in rows_out)
                real_cost_tot = round(sum(x["gercek_bagli_maliyet"] for x in rows_out), 2)
                psf_tot = round(sum(x["satilabilir_tutar_psf"] for x in rows_out), 2)

                return {
                    "success": True,
                    "source": "TRIA",
                    "has_real_invoice_cost": True,
                    "elapsed_ms": round((time.time() - t0) * 1000, 1),
                    "stats": {
                        "total_items": len(rows_out),
                        "shown_items": min(len(rows_out), lim),
                        "expired_count": expired_cnt,
                        "critical_3m_count": crit_3m_cnt,
                        "near_6m_count": near_6m_cnt,
                        "expiring_boxes": exp_boxes,
                        "real_cost_total": real_cost_tot,
                        "psf_total": psf_tot,
                    },
                    "items": rows_out[:lim],
                }
        except Exception as e:
            print(f"[TRIA] get_near_expiry_list hatası: {e}")
            return {"success": False, "source": "TRIA", "error": str(e), "stats": {}, "items": []}


# Singleton instance
tria_client = TriaOracleClient()
