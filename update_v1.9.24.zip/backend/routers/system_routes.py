# -*- coding: utf-8 -*-
"""
backend/routers/system_routes.py
--------------------------------
Sistem durumu, depo/otomasyon şifre ayarları, lisans doğrulama,
canlı güncelleme (LAN + GitHub Portal) ve sunucu yeniden başlatma uç noktaları.
"""

import os
import sys
import time
import json
import asyncio
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response

import backend.app_state as app_state
from backend.config_manager import get_current_credentials, save_credentials_to_env
from backend.core.session_store import SessionStore
from backend.query_engine import DepoSorguMotoru
from backend.updater import updater
from backend.license_manager import license_manager

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parent.parent.parent


@router.get("/api/status")
async def get_status():
    active = [k.value for k in app_state.motor.adapters.keys()] if app_state.motor else []
    return {
        "status": "ready",
        "active_wholesalers": active,
        "count": len(active)
    }


@router.get("/api/settings/credentials")
async def get_credentials_endpoint():
    return get_current_credentials()


@router.post("/api/settings/credentials")
async def save_credentials_endpoint(request: Request):
    data = await request.json()
    old_creds = get_current_credentials()

    for depo in ["alliance", "selcuk", "nevzat", "iskoop", "bek", "ecza1", "farmazon", "dna", "eczatrend", "eczanetakas"]:
        if depo in data:
            old_d = old_creds.get(depo, {})
            new_d = data[depo]
            has_changed = any(str(new_d.get(k, "")).strip() != str(old_d.get(k, "")).strip() for k in new_d)
            if has_changed:
                print(f">> [{depo}] Bilgileri güncellendi, eski oturum temizleniyor...")
                SessionStore.clear(depo)

    save_credentials_to_env(data)
    app_state.critical_stock_cache = {"time": 0.0, "data": []}
    app_state.smart_order_list_cache.clear()

    if app_state.motor:
        await app_state.motor.reload_adapters()
    else:
        app_state.motor = DepoSorguMotoru(headless=True)

    async def _bg_prewarm_after_save():
        try:
            for dk, adp in list(app_state.motor.adapters.items()):
                try:
                    await adp.login()
                    if hasattr(adp, "_ensure_ready_page"):
                        await adp._ensure_ready_page()
                    if hasattr(adp, "get_active_offers"):
                        await adp.get_active_offers(force_refresh=True)
                except Exception:
                    pass
        except Exception:
            pass

    asyncio.create_task(_bg_prewarm_after_save())

    active = [k.value for k in app_state.motor.adapters.keys()]
    return {
        "success": True,
        "message": f"Depo giriş bilgileri başarıyla kaydedildi. {len(active)} platform hazır.",
        "active_wholesalers": active
    }


SERVER_RUNTIME_VERSION = updater.get_local_version_info().get("version", "1.4.0")
SERVER_BOOT_ID = f"{os.getpid()}-{int(time.time() * 1000)}"


@router.get("/api/version")
async def get_version_endpoint():
    """Mevcut yerel sürüm bilgilerini, benzersiz sunucu açılış kimliğini (boot_id) ve RAM'deki aktif çalışma sürümünü döndürür."""
    info = updater.get_local_version_info()
    disk_ver = info.get("version", SERVER_RUNTIME_VERSION)
    info["runtime_version"] = SERVER_RUNTIME_VERSION
    info["boot_id"] = SERVER_BOOT_ID
    info["restart_required"] = (disk_ver != SERVER_RUNTIME_VERSION)
    return info



@router.get("/api/license/status")
async def get_license_status_endpoint(force: bool = Query(False)):
    """Mevcut eczane lisans durumunu (bulut doğrulaması dahil) ve donanım kimliğini (HWID) döndürür."""
    return await asyncio.to_thread(license_manager.get_status, force)


@router.post("/api/license/sync")
async def sync_license_cloud_endpoint():
    """Merkezi bulut lisans sunucusundan (GitHub / CRM) anlık lisans durumunu ve süre uzatımlarını çeker."""
    sync_res = await asyncio.to_thread(license_manager.sync_with_cloud, True)
    status_res = await asyncio.to_thread(license_manager.get_status, False)
    status_res["cloud_sync"] = sync_res
    return status_res


@router.post("/api/license/activate")
async def activate_license_endpoint(request: Request):
    """Yeni bir lisans anahtarını doğrular ve aktive eder."""
    try:
        body = await request.json()
        key_str = str(body.get("license_key") or "").strip()
        res = await asyncio.to_thread(license_manager.activate_license, key_str)
        return res
    except Exception as e:
        return JSONResponse(status_code=400, content={"valid": False, "message": str(e)})


@router.post("/api/license/register-trial")
async def register_trial_license_endpoint(request: Request):
    """
    Eczanenin GLN, Eczane Adı ve Telefon numarası ile otomatik 30 günlük lisans tanımlamasını
    ve GitHub + Yönetici CRM sistemine otomatik kaydedilmesini sağlar.
    """
    try:
        body = await request.json()
        res = await asyncio.to_thread(
            license_manager.register_pharmacy_trial,
            pharmacy_name=str(body.get("pharmacy_name") or ""),
            gln_no=str(body.get("gln_no") or ""),
            phone=str(body.get("phone") or ""),
            pharmacist_name=str(body.get("pharmacist_name") or ""),
            city=str(body.get("city") or ""),
            otomasyon=str(body.get("otomasyon") or os.getenv("ACTIVE_OTOMASYON", "BOTANIK")),
        )
        return res
    except Exception as e:
        return JSONResponse(status_code=400, content={"valid": False, "message": str(e)})


@router.get("/api/license/lookup-gln")
async def lookup_license_by_gln_get_endpoint(
    gln: str = Query(""),
    gln_no: str = Query(""),
    auto_activate: bool = Query(True)
):
    """13 haneli GLN numarası ile buluttan, yerel ağdan veya bağlı otomasyondan lisans anahtarını otomatik bulur."""
    res = await asyncio.to_thread(license_manager.lookup_license_by_gln, gln or gln_no, auto_activate)
    return res


@router.post("/api/license/lookup-gln")
async def lookup_license_by_gln_post_endpoint(request: Request):
    """13 haneli GLN numarası ile buluttan, yerel ağdan veya bağlı otomasyondan lisans anahtarını otomatik bulur."""
    try:
        body = await request.json()
        gln = str(body.get("gln_no") or body.get("gln") or "").strip()
        auto_activate = bool(body.get("auto_activate", True))
        res = await asyncio.to_thread(license_manager.lookup_license_by_gln, gln, auto_activate)
        return res
    except Exception as e:
        return JSONResponse(status_code=400, content={"found": False, "valid": False, "message": str(e)})


@router.get("/api/license/local-telemetry")
async def get_local_device_telemetry_endpoint():
    """Bu bilgisayarın yerel kullanım telemetri özetini döndürür (aynı eczane LAN eşleştirmesi için)."""
    return await asyncio.to_thread(license_manager.get_local_device_telemetry)


def _find_release_dir() -> Optional[Path]:
    candidates = [
        BASE_DIR / "releases",
        BASE_DIR / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "releases",
        BASE_DIR.parent / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "releases",
        Path(r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases"),
    ]
    for c in candidates:
        if (c / "version.json").exists():
            return c
    return None


def _load_release_publisher_module():
    candidates = [
        BASE_DIR / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI",
        BASE_DIR.parent / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI",
        Path(r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI"),
        Path(r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI"),
    ]
    for c in candidates:
        if (c / "release_publisher.py").exists():
            if str(c) not in sys.path:
                sys.path.insert(0, str(c))
            import release_publisher
            return release_publisher
    return None


@router.get("/portal", response_class=HTMLResponse)
@router.get("/releases", response_class=HTMLResponse)
@router.get("/releases/index.html", response_class=HTMLResponse)
async def serve_release_portal_html():
    """Canlı Güncelleme Portalı web sayfasını sunar."""
    rel_dir = _find_release_dir()
    if rel_dir and (rel_dir / "index.html").exists():
        return HTMLResponse(content=(rel_dir / "index.html").read_text(encoding="utf-8"))
    return HTMLResponse(content="<h3>Canlı Güncelleme Portalı hazırlanıyor...</h3>")


@router.get("/releases/version.json")
@router.get("/api/releases/version.json")
async def serve_release_manifest_endpoint(request: Request):
    """Merkezi/Admin bilgisayarda yayınlanan güncel version.json manifestosunu ağa ve istemcilere sunar."""
    rel_dir = _find_release_dir()
    if not rel_dir or not (rel_dir / "version.json").exists():
        return JSONResponse(status_code=404, content={"error": "Yayınlanmış güncelleme manifestosu bulunamadı."})
    try:
        data = json.loads((rel_dir / "version.json").read_text(encoding="utf-8"))
        ver = data.get("version", "1.0.0")
        host_hdr = request.headers.get("host") or "127.0.0.1:8080"
        zip_name = f"update_v{ver}.zip"
        if (rel_dir / zip_name).exists():
            data["download_url"] = f"http://{host_hdr}/releases/{zip_name}"
        return data
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/releases/{filename}")
@router.get("/api/releases/{filename}")
async def serve_release_package_endpoint(filename: str):
    """Merkezi/Admin bilgisayarda yayınlanan update_vX.Y.Z.zip veya licenses_cloud.json paketini sunar."""
    safe_name = os.path.basename(filename)
    rel_dir = _find_release_dir()
    if not rel_dir or not (rel_dir / safe_name).exists():
        return JSONResponse(status_code=404, content={"error": "Güncelleme paketi bulunamadı."})
    if safe_name.endswith(".html"):
        return HTMLResponse(content=(rel_dir / safe_name).read_text(encoding="utf-8"))
    if safe_name.endswith(".json"):
        return Response(
            content=(rel_dir / safe_name).read_bytes(),
            media_type="application/json; charset=utf-8",
            headers={"Cache-Control": "no-cache, no-store, must-revalidate"}
        )
    content_bytes = (rel_dir / safe_name).read_bytes()
    return Response(
        content=content_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{safe_name}"'}
    )


@router.get("/api/admin/launch-crm")
async def launch_crm_admin_endpoint():
    """Yönetici Lisans CRM Paneli (Port 8095) kapalıysa arka planda başlatır ve yönlendirir."""
    from fastapi.responses import RedirectResponse
    import socket, subprocess
    is_open = False
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.3)
            is_open = (s.connect_ex(("127.0.0.1", 8095)) == 0)
    except Exception:
        pass

    if not is_open:
        candidates = [
            BASE_DIR / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "license_admin_tool.py",
            BASE_DIR.parent / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "license_admin_tool.py",
            Path(r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\license_admin_tool.py"),
            Path(r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\license_admin_tool.py"),
        ]
        for cand in candidates:
            if cand.is_file():
                try:
                    cflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
                    env_copy = os.environ.copy()
                    env_copy["CRM_NO_BROWSER"] = "1"
                    subprocess.Popen(
                        [sys.executable, str(cand), "--no-browser"],
                        cwd=str(cand.parent),
                        env=env_copy,
                        creationflags=cflags,
                        close_fds=True
                    )
                    await asyncio.sleep(0.8)
                except Exception:
                    pass
                break

    return RedirectResponse(url="http://127.0.0.1:8095")


@router.post("/api/update/config")
async def update_config_endpoint(request: Request):
    """Manifest URL ve otomatik canlı güncelleme ayarlarını kaydeder."""
    try:
        body = await request.json()
        manifest_url = str(body.get("manifest_url") or "").strip()
        auto_update = body.get("auto_update")
        res = await asyncio.to_thread(updater.set_manifest_url, manifest_url, auto_update)
        return res
    except Exception as e:
        return JSONResponse(status_code=400, content={"success": False, "message": str(e)})


@router.get("/api/github-portal/config")
async def get_github_portal_config_endpoint():
    """GitHub Canlı Güncelleme Portalı ayarlarını döndürür."""
    pub = _load_release_publisher_module()
    local_v = updater.get_local_version_info()
    cur_ver = local_v.get("version", "1.0.7")
    if not pub:
        return {
            "available": False,
            "current_version": cur_ver,
            "next_version": "1.0.8",
            "manifest_url": local_v.get("manifest_url", ""),
            "auto_update": local_v.get("auto_update", True)
        }
    cfg = pub.load_github_config()
    owner = cfg.get("owner", "depomxxx")
    repo = cfg.get("repo", "depo-updates")
    branch = cfg.get("branch", "main")
    return {
        "available": True,
        "owner": owner,
        "repo": repo,
        "branch": branch,
        "has_token": bool(cfg.get("token")),
        "token_preview": (cfg["token"][:7] + "..." + cfg["token"][-4:]) if len(cfg.get("token", "")) > 12 else "",
        "current_version": cur_ver,
        "next_version": pub.bump_patch_version(cur_ver),
        "manifest_url": f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/version.json",
        "pages_url": f"https://{owner}.github.io/{repo}/",
        "auto_update": local_v.get("auto_update", True)
    }


@router.post("/api/github-portal/verify")
async def verify_github_portal_endpoint(request: Request):
    """GitHub Token ile repo oluşturur/doğrular ve Manifest URL'yi kaydeder."""
    pub = _load_release_publisher_module()
    if not pub:
        return JSONResponse(status_code=400, content={"success": False, "message": "Yayınlayıcı modülü (release_publisher.py) bu bilgisayarda bulunamadı."})
    body = await request.json()
    cfg = pub.load_github_config()
    token = str(body.get("token") or cfg.get("token") or "").strip()
    owner = str(body.get("owner") or cfg.get("owner") or "depomxxx").strip()
    repo = str(body.get("repo") or cfg.get("repo") or "depo-updates").strip()
    branch = str(body.get("branch") or cfg.get("branch") or "main").strip()
    res = await asyncio.to_thread(pub.setup_and_verify_github_portal, token, owner, repo, branch)
    if res.get("success") and res.get("manifest_url"):
        await asyncio.to_thread(updater.set_manifest_url, res["manifest_url"], True)
    return res


@router.post("/api/github-portal/publish")
async def publish_github_portal_endpoint(request: Request):
    """Yeni sürümü paketler, GitHub Canlı Portalına yükler ve ağdaki tüm bilgisayarları günceller."""
    pub = _load_release_publisher_module()
    if not pub:
        return JSONResponse(status_code=400, content={"success": False, "message": "Yayınlayıcı modülü (release_publisher.py) bu bilgisayarda bulunamadı."})
    body = await request.json()
    cfg = pub.load_github_config()
    token = str(body.get("token") or cfg.get("token") or "").strip()
    owner = str(body.get("owner") or cfg.get("owner") or "depomxxx").strip()
    repo = str(body.get("repo") or cfg.get("repo") or "depo-updates").strip()
    new_ver = str(body.get("version") or pub.bump_patch_version(updater.get_local_version_info().get("version", "1.0.7"))).strip()
    changelog = str(body.get("changelog") or "Canlı güncelleme ve performans iyileştirmeleri.").strip()

    res = await asyncio.to_thread(
        pub.build_and_publish_release,
        new_ver,
        changelog,
        "",
        True,
        token,
        owner,
        repo
    )
    return res


@router.get("/api/update/check")
async def check_update_endpoint(timeout: float = Query(6.0, ge=0.5, le=15.0)):
    """Merkezi sunucudan (GitHub ve Yerel Ağ LAN) yeni güncelleme olup olmadığını denetler."""
    res = await asyncio.to_thread(updater.check_for_updates, timeout)
    return res


_RESTART_LOCK = False


def trigger_delayed_server_restart(delay_sec: float = 0.4):
    """
    Sıfır kesintiye yakın sıcak devir (Hot-Handover):
    1. Mevcut sunucu port 8080'i açık tutmaya devam ederken arka planda yeni server.py sürecini başlatır.
    2. Yeni süreç tüm ağır kütüphaneleri (FastAPI, Oracle/SQL, adaptörler) yükleyip hazır olduğunda
       (--old-pid parametresiyle) eski süreci sonlandırır ve ~100 ms içinde 8080 portunu devralır.
    """
    global _RESTART_LOCK
    if _RESTART_LOCK:
        return
    _RESTART_LOCK = True

    def _delayed_restart():
        import time, subprocess
        time.sleep(max(0.15, float(delay_sec)))
        base_dir = str(BASE_DIR)
        my_pid = os.getpid()

        pyw_cand = os.path.join(base_dir, "runtime", "pythonw.exe")
        tria_pos_cand = os.path.join(base_dir, "runtime", "TriaPcPOS.exe")
        tria_cand = os.path.join(base_dir, "runtime", "Tria.exe")
        if os.path.isfile(pyw_cand) and not os.path.isfile(tria_pos_cand):
            try:
                import shutil
                shutil.copy2(pyw_cand, tria_pos_cand)
            except Exception:
                pass
        if os.path.isfile(tria_pos_cand):
            py_exe = tria_pos_cand
        elif os.path.isfile(pyw_cand):
            py_exe = pyw_cand
        elif os.path.isfile(tria_cand):
            py_exe = tria_cand
        else:
            py_exe = sys.executable

        script = os.path.join(base_dir, "server.py")
        cflags = 0
        if sys.platform == "win32":
            cflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
        env = os.environ.copy()
        env["SERVER_RESTARTING"] = "1"
        env["NO_AUTO_BROWSER"] = "1"
        env["TRIA_EXE_REEXEC"] = "1"
        subprocess.Popen(
            [py_exe, script, "--restarting", "--no-browser", f"--old-pid={my_pid}"],
            cwd=base_dir,
            env=env,
            creationflags=cflags,
            close_fds=True,
        )
        # Yeni süreç normalde hazır olur olmaz my_pid'yi kapatır; emniyet sübabı olarak en fazla 14 sn sonra çık
        time.sleep(14.0)
        os._exit(0)

    import threading
    threading.Thread(target=_delayed_restart, daemon=True).start()



@router.post("/api/update/apply")
async def apply_update_endpoint(request: Request):
    """Merkezi sunucudan (GitHub veya LAN) güncellemeyi indirip kurar ve sunucuyu yeniden başlatır."""
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass

    custom_manifest = str(body.get("manifest_url") or body.get("update_url") or "").strip()
    if custom_manifest.startswith("http"):
        try:
            updater.set_manifest_url(custom_manifest, True)
        except Exception:
            pass

    download_url = body.get("download_url")
    expected_sha256 = body.get("sha256", "")
    new_version = str(body.get("latest_version") or body.get("target_version") or body.get("version") or "").strip()

    if not download_url:
        chk = await asyncio.to_thread(updater.check_for_updates, 6.0)
        if chk.get("download_url") and (chk.get("update_available") or body.get("force")):
            download_url = chk["download_url"]
            expected_sha256 = chk.get("sha256", "")
            new_version = chk.get("latest_version", "") or new_version
        else:
            return JSONResponse(status_code=400, content={"success": False, "message": "İndirilecek yeni bir sürüm bulunamadı veya sisteminiz zaten güncel."})

    res = await asyncio.to_thread(updater.apply_update, download_url, expected_sha256, new_version)
    if res.get("success"):
        trigger_delayed_server_restart(0.45)
        res["restart"] = True
        res["boot_id"] = SERVER_BOOT_ID
    return res


@router.post("/api/server/restart")
@router.post("/api/system/restart")
async def restart_server_endpoint():
    """Sunucuyu sıcak devir (Hot-Handover) ile yeniden başlatır."""
    trigger_delayed_server_restart(0.35)
    return {
        "success": True,
        "boot_id": SERVER_BOOT_ID,
        "message": "Sunucu yeniden başlatılıyor, hazır olur olmaz ekran otomatik yenilenecek."
    }


@router.get("/apk")
@router.get("/FarmaRadar.apk")
@router.get("/FarmaRadar_Eczane.apk")
async def download_mobile_apk_endpoint():
    """Bu eczane için hazırlanan Android APK paketini doğrudan cep telefonuna indirir."""
    candidates = [
        BASE_DIR / "FarmaRadar_Eczane.apk",
        Path(r"C:\EczaneDepoPro\FarmaRadar_Eczane.apk"),
        Path(r"c:\Users\eczac\OneDrive\Masaüstü\FarmaRadar_Eczane.apk"),
        Path(r"c:\Users\eczac\OneDrive\Masaüstü\depoprogrami\FarmaRadar_Eczane.apk"),
    ]
    for cand in candidates:
        if cand.is_file():
            return FileResponse(
                path=str(cand),
                filename="FarmaRadar_Eczane.apk",
                media_type="application/vnd.android.package-archive",
                headers={"Content-Disposition": 'attachment; filename="FarmaRadar_Eczane.apk"'}
            )
    return JSONResponse(status_code=404, content={"success": False, "message": "APK dosyası henüz oluşturulmadı."})


@router.get("/mobil")
async def mobile_apk_install_page(request: Request):
    """Android cep telefonuna APK indirmek için QR kodlu ve tek tıkla kurulum ekranı."""
    from fastapi.responses import HTMLResponse
    import socket
    lan_ip = "192.168.1.43"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        lan_ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass
    apk_url = f"http://{lan_ip}:8080/apk"
    html = f"""<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Farma Radar Mobil APK Kurulumu</title>
<style>
  body {{ background:#0f172a; color:#f8fafc; font-family:system-ui,-apple-system,sans-serif; margin:0; display:flex; align-items:center; justify-content:center; min-height:100vh; padding:20px; box-sizing:border-box; }}
  .card {{ background:#1e293b; border:1px solid #334155; border-radius:20px; max-width:440px; width:100%; padding:28px; text-align:center; box-shadow:0 20px 50px rgba(0,0,0,0.5); }}
  .badge {{ display:inline-block; background:rgba(16,185,129,0.18); color:#10b981; font-weight:800; font-size:12px; padding:6px 14px; border-radius:99px; margin-bottom:12px; }}
  h1 {{ margin:0 0 8px; font-size:22px; }}
  p {{ color:#94a3b8; font-size:14px; line-height:1.5; margin:0 0 20px; }}
  .qr-box {{ background:#fff; padding:16px; border-radius:16px; display:inline-block; margin-bottom:20px; }}
  .btn {{ display:block; background:#10b981; color:#fff; text-decoration:none; font-weight:800; font-size:16px; padding:15px 20px; border-radius:14px; margin-bottom:12px; box-shadow:0 8px 20px rgba(16,185,129,0.35); }}
  .url {{ font-family:monospace; color:#38bdf8; font-size:13px; background:#0f172a; padding:10px; border-radius:10px; word-break:break-all; }}
</style>
</head>
<body>
  <div class="card">
    <div class="badge">📱 ANDROID MOBİL UYGULAMA</div>
    <h1>Farma Radar Mobil APK</h1>
    <p>Telefonunuz eczane Wi-Fi ağına bağlıyken aşağıdaki <b>QR Kodu</b> telefon kameranızla okutun veya doğrudan <b>APK İndir</b> butonuna dokunun.</p>
    <div class="qr-box">
      <img src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data={apk_url}" width="220" height="220" alt="APK QR" />
    </div>
    <a class="btn" href="/apk">⬇️ FarmaRadar_Eczane.apk İndir</a>
    <div class="url">{apk_url}</div>
  </div>
</body>
</html>"""
    return HTMLResponse(html)


@router.get("/onar", response_class=HTMLResponse)
async def lan_quick_repair_page(request: Request):
    """Ağdaki diğer bilgisayarların tek tıkla en güncel sürümü çekip yerel sunucusunu onarması için hızlı araç sayfası."""
    host_hdr = request.headers.get("host") or "127.0.0.1:8080"
    ver = updater.get_local_version_info().get("version", SERVER_RUNTIME_VERSION)
    html = f"""<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<title>Farma Radar Hızlı Onarım (v{ver})</title>
<style>
  body {{ background:#0f172a; color:#f8fafc; font-family:'Segoe UI',system-ui,sans-serif; margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center; padding:20px; }}
  .card {{ background:#1e293b; border:1px solid #334155; border-radius:24px; max-width:460px; width:100%; padding:32px; text-align:center; box-shadow:0 25px 50px rgba(0,0,0,0.5); }}
  .badge {{ display:inline-block; background:rgba(16,185,129,0.18); color:#34d399; font-weight:800; font-size:11px; padding:5px 12px; border-radius:99px; margin-bottom:12px; }}
  h1 {{ margin:0 0 10px; font-size:22px; }}
  p {{ color:#94a3b8; font-size:13.5px; line-height:1.55; margin:0 0 22px; }}
  .btn {{ display:block; background:linear-gradient(135deg,#10b981,#0284c7); color:#fff; text-decoration:none; font-weight:800; font-size:15px; padding:15px 20px; border-radius:14px; margin-bottom:12px; box-shadow:0 10px 25px rgba(16,185,129,0.3); }}
  .btn2 {{ display:block; background:#334155; color:#e2e8f0; text-decoration:none; font-weight:700; font-size:13px; padding:11px 16px; border-radius:12px; }}
</style>
</head>
<body>
  <div class="card">
    <div class="badge">⚡ YEREL AĞ HIZLI GÜNCELLEME &amp; ONARIM (v{ver})</div>
    <h1>Bu Bilgisayarı Anında Onar</h1>
    <p>Aşağıdaki butona tıklayıp inen <b>FarmaRadar_Onar.bat</b> dosyasını çalıştırın. Şifre ve ayarlarınıza dokunmadan 2 saniyede <b>v{ver}</b> sürümünü kurup programı açar.</p>
    <a class="btn" href="http://{host_hdr}/FarmaRadar_Onar.bat">⬇️ FarmaRadar_Onar.bat İndir ve Çalıştır</a>
    <a class="btn2" href="http://{host_hdr}/">🌐 Veya Doğrudan Ana Bilgisayar Üzerinden Kullan</a>
  </div>
</body>
</html>"""
    return HTMLResponse(html)


@router.get("/FarmaRadar_Onar.bat")
async def download_lan_quick_repair_bat(request: Request):
    """Ağdaki istemci bilgisayarı yerel ağ üzerinden 2 saniyede en son sürüme güncelleyip başlatan .bat betiği."""
    host_hdr = request.headers.get("host") or "127.0.0.1:8080"
    ver = updater.get_local_version_info().get("version", SERVER_RUNTIME_VERSION)
    lan_zip = f"http://{host_hdr}/releases/update_v{ver}.zip"
    gh_zip = f"https://raw.githubusercontent.com/depomxxx/depo-updates/main/update_v{ver}.zip"
    bat_lines = [
        "@echo off",
        "title Farma Radar Hizli Onarim Araci",
        'set "TARGET_DIR="',
        'if exist "C:\\EczaneDepoPro\\server.py" set "TARGET_DIR=C:\\EczaneDepoPro"',
        'if not defined TARGET_DIR if exist "D:\\EczaneDepoPro\\server.py" set "TARGET_DIR=D:\\EczaneDepoPro"',
        'if not defined TARGET_DIR if exist "C:\\FarmaRadar\\server.py" set "TARGET_DIR=C:\\FarmaRadar"',
        'if not defined TARGET_DIR if exist "%LOCALAPPDATA%\\FarmaRadar\\server.py" set "TARGET_DIR=%LOCALAPPDATA%\\FarmaRadar"',
        "if not defined TARGET_DIR exit /b 1",
        'echo Farma Radar guncelleniyor: %TARGET_DIR%',
        'set "PY_EXE=%TARGET_DIR%\\runtime\\python.exe"',
        'if not exist "%PY_EXE%" set "PY_EXE=%TARGET_DIR%\\runtime\\Tria.exe"',
        'if not exist "%PY_EXE%" set "PY_EXE=python"',
        'set "HEAL_PY=%TEMP%\\_fr_quick_heal.py"',
        'echo import os, io, ssl, zipfile, urllib.request> "%HEAL_PY%"',
        'echo t = os.environ.get("TARGET_DIR", r"C:\\EczaneDepoPro")>> "%HEAL_PY%"',
        f'echo urls = ["{lan_zip}", "{gh_zip}"]>> "%HEAL_PY%"',
        'echo ctx = ssl._create_unverified_context()>> "%HEAL_PY%"',
        'echo data = None>> "%HEAL_PY%"',
        'echo for u in urls:>> "%HEAL_PY%"',
        'echo     try:>> "%HEAL_PY%"',
        'echo         data = urllib.request.urlopen(u, timeout=15, context=ctx).read()>> "%HEAL_PY%"',
        'echo         if data: break>> "%HEAL_PY%"',
        'echo     except Exception: pass>> "%HEAL_PY%"',
        'echo if data: zipfile.ZipFile(io.BytesIO(data)).extractall(t)>> "%HEAL_PY%"',
        f'echo print("Basariyla guncellendi: v{ver}")>> "%HEAL_PY%"',
        '"%PY_EXE%" "%HEAL_PY%"',
        'if exist "%TARGET_DIR%\\runtime\\pythonw.exe" start "" "%TARGET_DIR%\\runtime\\pythonw.exe" "%TARGET_DIR%\\launcher.py"',
        'if not exist "%TARGET_DIR%\\runtime\\pythonw.exe" start "" "%PY_EXE%" "%TARGET_DIR%\\launcher.py"',
        "exit /b 0",
    ]
    bat_bytes = ("\r\n".join(bat_lines) + "\r\n").encode("ascii", errors="ignore")
    return Response(
        content=bat_bytes,
        media_type="application/octet-stream",
        headers={"Content-Disposition": 'attachment; filename="FarmaRadar_Onar.bat"'},
    )


@router.get("/api/system/desktop-icons")
async def refresh_and_list_desktop_icons():
    """Masaüstü kısayol ikonlarını anında yeniler ve masaüstündeki kısayolların raporunu döner."""
    import server
    return await asyncio.to_thread(server._refresh_desktop_shortcut_icons)


def _humanize_diagnostic_error(raw_err: str, platform_label: str) -> str:
    s = str(raw_err or "").strip()
    low = s.lower()
    if not s:
        return f"{platform_label} bağlantısı doğrulanamadı."
    if any(k in low for k in ("şifre", "sifre", "password", "parola", "hatalı", "hatali", "invalid", "401", "403", "unauthorized", "yetkisiz", "login failed", "giriş başarısız")):
        return f"{platform_label} kullanıcı adı veya şifre geçersiz. Ayarlar > Ecza Depoları bölümünden kontrol edin."
    if any(k in low for k in ("timed out", "timeout", "zaman aşımı", "zaman asimi")):
        return f"{platform_label} sunucusu yanıt vermedi (zaman aşımı). İnternet veya yerel ağ bağlantısını kontrol edin."
    if any(k in low for k in ("connect", "refused", "unreachable", "ora-12", "sql server", "pyodbc", "socket", "name or service")):
        return f"{platform_label} sunucusuna erişilemiyor ({s[:120]})."
    return s[:180]


@router.get("/api/system/diagnostics")
async def run_system_diagnostics_endpoint(live_check: bool = Query(True)):
    """
    Tek Tıkla Sistem Teşhis & Sağlık Kontrolü:
    - Aktif Eczane Otomasyonu (Botanik / TRIA / TEBEOS / Eczanem) canlı ping ve gecikme
    - Tüm yapılandırılmış Ecza Depoları ve Pazaryeri/Takas platformlarının oturum & şifre durumu
    - Lisans, sürüm, yerel ağ (LAN IP) ve yerel SQLite veritabanı sağlığı
    - Sonucu aynı zamanda Merkezi Lisans/CRM Sağlık Telemetrisine kaydeder.
    """
    import socket
    import datetime as _dt
    from backend.config_manager import get_active_otomasyon
    from backend.models import DepoKodu

    t_start = time.time()
    creds = get_current_credentials()
    active_oto = get_active_otomasyon()
    motor = app_state.get_motor()

    # 1. Otomasyon Ping
    async def _check_otomasyon():
        t0 = time.time()
        try:
            if active_oto == "BOTANIK":
                from backend.botanik_client import botanik_client
                res = await asyncio.to_thread(botanik_client.ping)
            elif active_oto == "TRIA":
                from backend.tria_client import tria_client
                res = await asyncio.to_thread(tria_client.ping)
            elif active_oto == "TEBEOS":
                from backend.tebeos_client import tebeos_client
                res = await asyncio.to_thread(tebeos_client.ping)
            elif active_oto == "ECZANEM":
                from backend.eczanem_client import eczanem_client
                res = await asyncio.to_thread(eczanem_client.ping)
            else:
                res = {"connected": False, "message": f"Bilinmeyen otomasyon: {active_oto}"}
            ok = bool(res.get("connected") or res.get("success"))
            lat = round(float(res.get("latency_ms") or ((time.time() - t0) * 1000.0)), 1)
            msg = str(res.get("message") or ("Bağlantı aktif" if ok else "Bağlanılamadı"))
            return {
                "code": active_oto,
                "name": active_oto,
                "ok": ok,
                "status": "OK" if ok else "ERROR",
                "latency_ms": lat,
                "server": str(res.get("server") or res.get("host") or ""),
                "database": str(res.get("database") or res.get("sid") or ""),
                "stats": res.get("stats") or {},
                "message": msg if ok else _humanize_diagnostic_error(msg, active_oto),
            }
        except Exception as e:
            return {
                "code": active_oto,
                "name": active_oto,
                "ok": False,
                "status": "ERROR",
                "latency_ms": round((time.time() - t0) * 1000.0, 1),
                "message": _humanize_diagnostic_error(str(e), active_oto),
            }

    # 2. Depo & Pazaryeri Oturum Sağlığı
    depo_defs = [
        ("ISKOOP", "İSKOOP", DepoKodu.ISKOOP, "iskoop", "depo"),
        ("SELCUK", "Selçuk Ecza", DepoKodu.SELCUK, "selcuk", "depo"),
        ("ALLIANCE", "Alliance / Hedef", DepoKodu.ALLIANCE, "alliance", "depo"),
        ("NEVZAT", "Nevzat Ecza", DepoKodu.NEVZAT, "nevzat", "depo"),
        ("BEK", "BEK (Bursa Ecza)", DepoKodu.BEK, "bek", "depo"),
        ("DNA", "DNA Ecza", DepoKodu.DNA, "dna", "depo"),
        ("ECZATREND", "Eczatrend Ortak Alım", DepoKodu.ECZATREND, "eczatrend", "takas"),
        ("ECZANETAKAS", "EczaneTakas", DepoKodu.ECZANETAKAS, "eczanetakas", "takas"),
        ("FARMAZON", "Farmazon", DepoKodu.FARMAZON, "farmazon", "pazaryeri"),
        ("ECZA1", "Ecza1", DepoKodu.ECZA1, "ecza1", "pazaryeri"),
    ]

    async def _check_one_depo(code: str, label: str, dk: DepoKodu, cfg_key: str, kind: str):
        t0 = time.time()
        c = creds.get(cfg_key) or {}
        u = str(c.get("username") or "").strip()
        p = str(c.get("password") or "").strip()
        is_act = str(c.get("active", "0")).strip().lower() in ("1", "true", "yes")
        if not u or not p:
            return {
                "code": code,
                "name": label,
                "kind": kind,
                "configured": False,
                "active": False,
                "ok": None,
                "status": "UNCONFIGURED",
                "latency_ms": 0.0,
                "message": "Tanımlı değil (kullanıcı adı / şifre girilmemiş).",
            }
        if not is_act:
            return {
                "code": code,
                "name": label,
                "kind": kind,
                "configured": True,
                "active": False,
                "ok": None,
                "status": "PASSIVE",
                "latency_ms": 0.0,
                "message": "Ayarlardan pasife alınmış.",
            }
        adp = motor.adapters.get(dk) if motor else None
        if not adp:
            return {
                "code": code,
                "name": label,
                "kind": kind,
                "configured": True,
                "active": True,
                "ok": False,
                "status": "ERROR",
                "latency_ms": 0.0,
                "message": f"{label} adaptörü yüklü değil. Yeniden Bağlan veya sunucuyu yeniden başlatmayı deneyin.",
            }

        session_ok = bool(getattr(adp, "is_logged_in", False))
        detail_msg = "Oturum açık ve sorguya hazır." if session_ok else "Oturum henüz doğrulanmadı."
        if live_check:
            try:
                if hasattr(adp, "is_session_valid") and callable(adp.is_session_valid):
                    valid_now = await asyncio.wait_for(adp.is_session_valid(), timeout=8.0)
                    session_ok = bool(valid_now)
                    if session_ok:
                        detail_msg = "Canlı oturum doğrulandı — sorguya hazır."
                    else:
                        detail_msg = f"{label} oturumu düşmüş veya henüz giriş yapılmamış. 'Yeniden Bağlan' butonuna basın."
                elif not session_ok:
                    # Çerez / storage_state dosyası var mı bak
                    s_file = SessionStore.get_session_file(cfg_key)
                    if s_file.exists() and s_file.stat().st_size > 20:
                        session_ok = True
                        detail_msg = "Kayıtlı oturum çerezi mevcut (ilk sorguda otomatik bağlanır)."
                    else:
                        detail_msg = f"{label} oturumu açık değil — 'Yeniden Bağlan' ile test edin."
            except asyncio.TimeoutError:
                session_ok = False
                detail_msg = f"{label} oturum doğrulaması zaman aşımına uğradı."
            except Exception as e:
                session_ok = False
                detail_msg = _humanize_diagnostic_error(str(e), label)

        return {
            "code": code,
            "name": label,
            "kind": kind,
            "configured": True,
            "active": True,
            "ok": session_ok,
            "status": "OK" if session_ok else "WARN",
            "latency_ms": round((time.time() - t0) * 1000.0, 1),
            "message": detail_msg,
        }

    oto_task = _check_otomasyon()
    depo_tasks = [_check_one_depo(c, l, dk, ck, k) for c, l, dk, ck, k in depo_defs]
    lic_task = asyncio.to_thread(license_manager.get_status, False)

    all_res = await asyncio.gather(oto_task, lic_task, *depo_tasks, return_exceptions=True)
    oto_res = all_res[0] if isinstance(all_res[0], dict) else {"code": active_oto, "ok": False, "status": "ERROR", "message": str(all_res[0])}
    lic_res = all_res[1] if isinstance(all_res[1], dict) else {"valid": False, "message": "Lisans okunamadı"}
    depots_res = [r for r in all_res[2:] if isinstance(r, dict)]

    # LAN IP & Yerel Veritabanı / Sürüm
    lan_ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        lan_ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass

    ver_info = updater.get_local_version_info()
    disk_ver = str(ver_info.get("version") or SERVER_RUNTIME_VERSION)
    active_depots = [d for d in depots_res if d.get("active")]
    ok_depots = [d for d in active_depots if d.get("ok") is True]
    failed_depots = [d for d in active_depots if d.get("ok") is not True]

    issues = []
    if not oto_res.get("ok"):
        issues.append(f"Otomasyon ({active_oto}): {oto_res.get('message')}")
    for fd in failed_depots:
        issues.append(f"{fd['name']}: {fd.get('message')}")
    if not lic_res.get("valid"):
        issues.append(f"Lisans: {lic_res.get('message') or 'Geçersiz / süresi dolmuş'}")

    overall_status = "OK" if not issues else ("ERROR" if (not oto_res.get("ok") or not lic_res.get("valid")) else "WARN")
    checked_at = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Merkezi CRM telemetrisine kompakt sağlık özetini yaz
    health_snapshot = {
        "overall": overall_status,
        "otomasyon": active_oto,
        "otomasyon_ok": bool(oto_res.get("ok")),
        "otomasyon_ms": float(oto_res.get("latency_ms") or 0.0),
        "depots_ok": len(ok_depots),
        "depots_total": len(active_depots),
        "depots_failed": [d["code"] for d in failed_depots],
        "last_error": issues[0][:180] if issues else "",
        "checked_at": checked_at,
    }
    try:
        license_manager.set_health_snapshot(health_snapshot, push_cloud=False)
    except Exception:
        pass

    return {
        "success": True,
        "checked_at": checked_at,
        "elapsed_ms": round((time.time() - t_start) * 1000.0, 1),
        "overall_status": overall_status,
        "issues_count": len(issues),
        "issues": issues,
        "system": {
            "pc_name": socket.gethostname(),
            "lan_ip": lan_ip,
            "port": int(os.environ.get("SERVER_PORT", "8080") or 8080),
            "app_version": disk_ver,
            "runtime_version": SERVER_RUNTIME_VERSION,
            "restart_required": disk_ver != SERVER_RUNTIME_VERSION,
        },
        "license": {
            "valid": bool(lic_res.get("valid")),
            "pharmacy_name": lic_res.get("pharmacy_name") or "",
            "gln_no": lic_res.get("gln_no") or "",
            "plan": lic_res.get("plan") or "",
            "expires_at": lic_res.get("expires_at") or "",
            "days_left": int(lic_res.get("days_left") or 0),
            "message": lic_res.get("message") or "",
        },
        "otomasyon": oto_res,
        "depots": depots_res,
        "summary": {
            "depots_ok": len(ok_depots),
            "depots_total": len(active_depots),
            "depots_failed": len(failed_depots),
        },
    }


@router.post("/api/system/reconnect-depo")
async def reconnect_single_depo_endpoint(request: Request):
    """Belirtilen depo veya pazaryeri adaptörünün eski oturumunu temizleyip canlı yeniden giriş (login) testi yapar."""
    from backend.models import DepoKodu
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={"success": False, "message": "Geçersiz istek."})

    code = str(body.get("depo") or body.get("code") or "").strip().upper()
    if code == "HEDEF":
        code = "ALLIANCE"
    code_map = {
        "ISKOOP": (DepoKodu.ISKOOP, "iskoop", "İSKOOP"),
        "SELCUK": (DepoKodu.SELCUK, "selcuk", "Selçuk Ecza"),
        "ALLIANCE": (DepoKodu.ALLIANCE, "alliance", "Alliance / Hedef"),
        "NEVZAT": (DepoKodu.NEVZAT, "nevzat", "Nevzat Ecza"),
        "BEK": (DepoKodu.BEK, "bek", "BEK"),
        "DNA": (DepoKodu.DNA, "dna", "DNA Ecza"),
        "ECZATREND": (DepoKodu.ECZATREND, "eczatrend", "Eczatrend"),
        "ECZANETAKAS": (DepoKodu.ECZANETAKAS, "eczanetakas", "EczaneTakas"),
        "FARMAZON": (DepoKodu.FARMAZON, "farmazon", "Farmazon"),
        "ECZA1": (DepoKodu.ECZA1, "ecza1", "Ecza1"),
    }
    if code not in code_map:
        return JSONResponse(status_code=400, content={"success": False, "message": f"Bilinmeyen platform: {code}"})

    dk, skey, lbl = code_map[code]
    motor = app_state.get_motor()
    adp = motor.adapters.get(dk) if motor else None
    if not adp:
        return JSONResponse(status_code=400, content={"success": False, "message": f"{lbl} aktif değil veya şifre tanımlı değil."})

    t0 = time.time()
    try:
        SessionStore.clear(skey)
        try:
            ok = await asyncio.wait_for(adp.login(force_fresh=True), timeout=25.0)
        except TypeError:
            ok = await asyncio.wait_for(adp.login(), timeout=25.0)
        lat = round((time.time() - t0) * 1000.0, 1)
        if ok:
            return {"success": True, "code": code, "latency_ms": lat, "message": f"✅ {lbl} bağlantısı başarıyla yenilendi ({lat} ms)."}
        return {"success": False, "code": code, "latency_ms": lat, "message": f"{lbl} girişi başarısız oldu. Kullanıcı adı / şifreyi kontrol edin."}
    except Exception as e:
        lat = round((time.time() - t0) * 1000.0, 1)
        return {"success": False, "code": code, "latency_ms": lat, "message": _humanize_diagnostic_error(str(e), lbl)}


