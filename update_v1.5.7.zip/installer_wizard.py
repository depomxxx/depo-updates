# -*- coding: utf-8 -*-
"""
installer_wizard.py
-------------------
Farma Radar - Profesyonel Kurulum Sihirbazı (4 Adımlı Kurumsal Web/App GUI + Canlı Güncelleme + Uninstall).
Gömülü Python (runtime/python.exe veya runtime/Tria.exe) üzerinde tkinter gerektirmeden %100 bağımsız çalışır:
1. Üye Eczane & Eczacı Bilgileri (Ad Soyad, Telefon, Eczane Adı, GLN) ve Lisans Doğrulama
2. Eczane Otomasyonu (Botanik EOS / TRIA Oracle / TEBEOS PostgreSQL) Seçimi, Otomatik Bulma & Canlı Bağlantı Testi
3. Ecza Depoları & Pazaryerleri (Alliance, Selçuk, Nevzat, İSKOOP, BEK, Farmazon, Ecza1, DNA, Eczatrend, EczaneTakas) Şifre Girişi
4. C:\\EczaneDepoPro Kurulumu, depomxxx Canlı Güncelleme Bağlantısı, Masaüstü Kısayolu ve Kaldırıcı (Uninstall)
"""

import os
import sys
import json
import time
import shutil
import socket
import datetime
import subprocess
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parent
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

try:
    from backend.license_manager import LicenseManager
except Exception:
    LicenseManager = None

_INSTALL_STATE = {
    "running": False,
    "pct": 0,
    "message": "Kuruluma hazır.",
    "done": False,
    "success": False,
    "target_dir": r"C:\EczaneDepoPro",
}


def create_uninstaller(target_dir: Path):
    """Hedef klasörde tek tıkla programı ve kısayolları kaldıran Uninstall_FarmaRadar.bat oluşturur."""
    for bat_name in ("Uninstall_FarmaRadar.bat", "Uninstall_EczaneDepoPro.bat"):
        uninstall_bat = target_dir / bat_name
        content = f"""@echo off
title FARMA RADAR - PROGRAM KALDIRMA (UNINSTALL)
color 0C
echo ===============================================================================
echo        FARMA RADAR - KALDIRMA SIHIRBAZI (UNINSTALL)
echo ===============================================================================
echo.
set /p ONAY="Farma Radar programini bilgisayardan kaldirmak istiyor musunuz? (E/H): "
if /i not "%ONAY%"=="E" exit /b 0

echo.
echo [1/3] Arka plan sunucu islemleri durduruluyor...
taskkill /F /IM Tria.exe >nul 2>&1
taskkill /F /IM TriaPcPOS.exe >nul 2>&1
taskkill /F /IM Eda_Depo.exe >nul 2>&1

echo [2/3] Masaustu kisayollari temizleniyor...
del /f /q "%USERPROFILE%\\Desktop\\Farma Radar.lnk" >nul 2>&1
del /f /q "%USERPROFILE%\\OneDrive\\Masaüstü\\Farma Radar.lnk" >nul 2>&1
del /f /q "%USERPROFILE%\\OneDrive\\Desktop\\Farma Radar.lnk" >nul 2>&1
del /f /q "%USERPROFILE%\\Desktop\\Eczane Depo Pro.lnk" >nul 2>&1
del /f /q "%USERPROFILE%\\OneDrive\\Masaüstü\\Eczane Depo Pro.lnk" >nul 2>&1

echo [3/3] Kurulum dosyalari kaldiriliyor: {target_dir}
cd /d "C:\\"
start "" /b cmd /c "ping 127.0.0.1 -n 3 >nul && rmdir /s /q \"{target_dir}\""
echo.
echo Farma Radar basariyla kaldirildi.
pause
exit
"""
        try:
            uninstall_bat.write_text(content, encoding="utf-8")
        except Exception:
            pass


def create_shortcuts(target_dir: Path):
    """Masaüstüne 'Farma Radar' kısayolunu oluşturur."""
    ps_script = f"""
$WshShell = New-Object -ComObject WScript.Shell
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $DesktopPath "Farma Radar.lnk"
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$ExePath = "{target_dir}\\Eda_Depo.exe"
if (-not (Test-Path $ExePath)) {{
    $ExePath = "{target_dir}\\2_EDA_DEPO_BASLAT.bat"
}}
$Shortcut.TargetPath = $ExePath
$Shortcut.WorkingDirectory = "{target_dir}"
$Shortcut.Description = "Farma Radar - Akıllı Depo & MF Karşılaştırma Sistemi"
$IconCandidate = "{target_dir}\\Eda_Depo.exe"
if (Test-Path $IconCandidate) {{
    $Shortcut.IconLocation = "$IconCandidate,0"
}} else {{
    $Shortcut.IconLocation = "shell32.dll,21"
}}
$Shortcut.Save()
"""
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10
        )
    except Exception:
        pass


def record_member_pharmacy(member_info: dict):
    """Kurulum yapılan üye eczanenin bilgilerini yönetici defterine kaydeder."""
    ledger_paths = [
        SRC_DIR / "uye_eczaneler_kayit_defteri.json",
        SRC_DIR.parent / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "musteri_lisans_kayitlari.json"
    ]
    for lp in ledger_paths:
        try:
            if not lp.parent.exists():
                continue
            records = []
            if lp.exists():
                try:
                    records = json.loads(lp.read_text(encoding="utf-8"))
                except Exception:
                    records = []
            records.insert(0, member_info)
            lp.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass


def perform_installation(cfg: dict, progress_cb=None) -> dict:
    """Tüm kurulum, .env depo/otomasyon şifre kaydı, lisans aktivasyonu ve kısayol işlemlerini yürütür."""
    target_dir = Path((cfg.get("install_dir") or r"C:\EczaneDepoPro").strip())
    try:
        if progress_cb:
            progress_cb(10, f"Hedef klasör hazırlanıyor: {target_dir}")
        target_dir.mkdir(parents=True, exist_ok=True)

        # Mevcut hedef klasördeki (.env) depo ve otomasyon şifrelerini önce oku (kurulum sırasında şifreler asla silinmesin!)
        existing_env = {}
        for env_cand in (SRC_DIR / ".env", target_dir / ".env"):
            if env_cand.exists():
                try:
                    for ln in env_cand.read_text(encoding="utf-8", errors="ignore").splitlines():
                        s = ln.strip()
                        if s and not s.startswith("#") and "=" in s:
                            ek, ev = s.split("=", 1)
                            if ev.strip():
                                existing_env[ek.strip()] = ev.strip()
                except Exception:
                    pass

        if target_dir.resolve() != SRC_DIR.resolve():
            items_to_copy = [
                "backend",
                "data",
                "oracle_client",
                "runtime",
                "server.py",
                "launcher.py",
                "installer_wizard.py",
                "1_PROFESYONEL_KURULUM_SIHIRBAZI.bat",
                "1_OTOMATIK_KURULUM_EDA.bat",
                "Eda_Depo.exe",
                "Depo.exe",
                "2_EDA_DEPO_BASLAT.bat",
                "3_EDA_DEPO_SESSIZ_BASLAT.vbs",
                "4_EDA_DEPO_HATA_AYIKLAMA.bat",
                "Depo_Baslat.bat",
                "version.json",
            ]
            if not (target_dir / ".env").exists():
                items_to_copy.append(".env")
            total_items = len(items_to_copy)
            for idx, item_name in enumerate(items_to_copy):
                src_item = SRC_DIR / item_name
                dst_item = target_dir / item_name
                if not src_item.exists():
                    continue
                pct = 12 + int((idx / total_items) * 58)
                if progress_cb:
                    progress_cb(pct, f"Kuruluyor: {item_name} ...")
                if src_item.is_dir():
                    shutil.copytree(
                        src_item,
                        dst_item,
                        dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "sessions", "*.cookie")
                    )
                else:
                    shutil.copy2(src_item, dst_item)

        if progress_cb:
            progress_cb(75, "Farma Radar arka plan motoru hazırlanıyor...")
        rt_dir = target_dir / "runtime"
        if (rt_dir / "python.exe").exists() and not (rt_dir / "Tria.exe").exists():
            shutil.copy2(rt_dir / "python.exe", rt_dir / "Tria.exe")
        if (rt_dir / "pythonw.exe").exists() and not (rt_dir / "TriaPcPOS.exe").exists():
            shutil.copy2(rt_dir / "pythonw.exe", rt_dir / "TriaPcPOS.exe")

        # python313._pth içindeki sabit C:\EczaneDepoPro yolunu bağıl (..) olarak koru ki her klasörde çalışsın
        pth_file = rt_dir / "python313._pth"
        if pth_file.exists():
            try:
                pth_file.write_text("python313.zip\n.\n..\nLib\nLib\\site-packages\nimport site\n", encoding="utf-8")
            except Exception:
                pass

        if progress_cb:
            progress_cb(82, "Otomasyon ve Ecza Deposu şifreleri (.env) kaydediliyor...")
        env_path = target_dir / ".env"

        def _val(cfg_key, env_key, default=""):
            v = str(cfg.get(cfg_key) or "").strip()
            if v:
                return v
            return existing_env.get(env_key, default)

        def _active_flag(u, p, extra=None):
            if extra is not None and not str(extra).strip():
                return "0"
            return "1" if (str(u or "").strip() and str(p or "").strip()) else "0"

        all_code = _val("alliance_code", "ALLIANCE_PHARMACY_CODE")
        all_user = _val("alliance_user", "ALLIANCE_USERNAME")
        all_pwd = _val("alliance_pwd", "ALLIANCE_PASSWORD")
        sel_user = _val("selcuk_user", "SELCUK_USERNAME")
        sel_pwd = _val("selcuk_pwd", "SELCUK_PASSWORD")
        nev_code = _val("nevzat_code", "NEVZAT_ACCOUNT_CODE")
        nev_user = _val("nevzat_user", "NEVZAT_USERNAME")
        nev_pwd = _val("nevzat_pwd", "NEVZAT_PASSWORD")
        isk_user = _val("iskoop_user", "ISKOOP_USERNAME")
        isk_pwd = _val("iskoop_pwd", "ISKOOP_PASSWORD")
        bek_user = _val("bek_user", "BEK_USERNAME")
        bek_pwd = _val("bek_pwd", "BEK_PASSWORD")
        fz_user = _val("farmazon_user", "FARMAZON_USERNAME")
        fz_pwd = _val("farmazon_pwd", "FARMAZON_PASSWORD")
        e1_user = _val("ecza1_user", "ECZA1_USERNAME")
        e1_pwd = _val("ecza1_pwd", "ECZA1_PASSWORD")
        dna_user = _val("dna_user", "DNA_USERNAME")
        dna_pwd = _val("dna_pwd", "DNA_PASSWORD")
        etr_user = _val("eczatrend_user", "ECZATREND_USERNAME")
        etr_pwd = _val("eczatrend_pwd", "ECZATREND_PASSWORD")
        etk_user = _val("eczanetakas_user", "ECZANETAKAS_USERNAME")
        etk_pwd = _val("eczanetakas_pwd", "ECZANETAKAS_PASSWORD")

        updates = {
            "ACTIVE_OTOMASYON": _val("active_otomasyon", "ACTIVE_OTOMASYON", "BOTANIK"),
            "BOTANIK_SQL_SERVER": _val("botanik_server", "BOTANIK_SQL_SERVER", r".\BOTANIKSQL"),
            "BOTANIK_SQL_DB": _val("botanik_db", "BOTANIK_SQL_DB", "eczane"),
            "BOTANIK_SQL_USER": _val("botanik_user", "BOTANIK_SQL_USER", "sa"),
            "BOTANIK_SQL_PASSWORD": _val("botanik_pwd", "BOTANIK_SQL_PASSWORD", "123"),
            "BOTANIK_SQL_TRUSTED": existing_env.get("BOTANIK_SQL_TRUSTED", "false"),
            "TRIA_ORACLE_HOST": _val("tria_host", "TRIA_ORACLE_HOST"),
            "TRIA_ORACLE_PORT": _val("tria_port", "TRIA_ORACLE_PORT", "1521"),
            "TRIA_ORACLE_SID": _val("tria_sid", "TRIA_ORACLE_SID", "ORCL"),
            "TRIA_ORACLE_USER": _val("tria_user", "TRIA_ORACLE_USER"),
            "TRIA_ORACLE_PASSWORD": _val("tria_pwd", "TRIA_ORACLE_PASSWORD"),
            "TEBEOS_PG_HOST": _val("tebeos_host", "TEBEOS_PG_HOST"),
            "TEBEOS_PG_PORT": _val("tebeos_port", "TEBEOS_PG_PORT", "5454"),
            "TEBEOS_PG_DB": _val("tebeos_db", "TEBEOS_PG_DB", "tebeos_db"),
            "TEBEOS_PG_USER": _val("tebeos_user", "TEBEOS_PG_USER", "tebeos"),
            "TEBEOS_PG_PASSWORD": _val("tebeos_pwd", "TEBEOS_PG_PASSWORD", "123"),
            "ALLIANCE_PHARMACY_CODE": all_code,
            "ALLIANCE_USERNAME": all_user,
            "ALLIANCE_PASSWORD": all_pwd,
            "ALLIANCE_ACTIVE": _active_flag(all_user, all_pwd, all_code),
            "SELCUK_USERNAME": sel_user,
            "SELCUK_PASSWORD": sel_pwd,
            "SELCUK_ACTIVE": _active_flag(sel_user, sel_pwd),
            "NEVZAT_ACCOUNT_CODE": nev_code,
            "NEVZAT_USERNAME": nev_user,
            "NEVZAT_PASSWORD": nev_pwd,
            "NEVZAT_ACTIVE": _active_flag(nev_user, nev_pwd, nev_code),
            "ISKOOP_USERNAME": isk_user,
            "ISKOOP_PASSWORD": isk_pwd,
            "ISKOOP_ACTIVE": _active_flag(isk_user, isk_pwd),
            "BEK_USERNAME": bek_user,
            "BEK_PASSWORD": bek_pwd,
            "BEK_ACTIVE": _active_flag(bek_user, bek_pwd),
            "FARMAZON_USERNAME": fz_user,
            "FARMAZON_PASSWORD": fz_pwd,
            "FARMAZON_ACTIVE": _active_flag(fz_user, fz_pwd),
            "ECZA1_USERNAME": e1_user,
            "ECZA1_PASSWORD": e1_pwd,
            "ECZA1_ACTIVE": _active_flag(e1_user, e1_pwd),
            "DNA_USERNAME": dna_user,
            "DNA_PASSWORD": dna_pwd,
            "DNA_ACTIVE": _active_flag(dna_user, dna_pwd),
            "ECZATREND_USERNAME": etr_user,
            "ECZATREND_PASSWORD": etr_pwd,
            "ECZATREND_ACTIVE": _active_flag(etr_user, etr_pwd),
            "ECZANETAKAS_USERNAME": etk_user,
            "ECZANETAKAS_PASSWORD": etk_pwd,
            "ECZANETAKAS_ACTIVE": _active_flag(etk_user, etk_pwd),
            "UPDATE_MANIFEST_URL": "https://raw.githubusercontent.com/depomxxx/depo-updates/main/version.json"
        }

        new_lines = [
            "# ==========================================================",
            "# FARMA RADAR - ECZANE DEPO & OTOMASYON AYARLARI",
            "# =========================================================="
        ]
        for k, v in updates.items():
            new_lines.append(f"{k}={v}")
        env_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

        if progress_cb:
            progress_cb(88, "Eczane kaydı ve 30 Günlük Otomatik Lisans tanımlanıyor (GitHub Bulut)...")
        my_hwid = "----"
        lic_exp = ""
        lic_key_final = (cfg.get("license_key") or "").strip()
        if LicenseManager is not None:
            lm = LicenseManager(base_dir=str(target_dir))
            my_hwid = lm.get_hardware_id()
            if lic_key_final:
                lic_res = lm.activate_license(
                    lic_key_final,
                    pharmacist_name=cfg.get("pharmacist_name", ""),
                    phone=cfg.get("phone", ""),
                    city=cfg.get("city", "")
                )
            else:
                lic_res = lm.register_pharmacy_trial(
                    pharmacy_name=cfg.get("pharmacy_name", ""),
                    gln_no=cfg.get("gln_no", ""),
                    phone=cfg.get("phone", ""),
                    pharmacist_name=cfg.get("pharmacist_name", ""),
                    city=cfg.get("city", ""),
                    otomasyon=cfg.get("active_otomasyon", "BOTANIK")
                )
            if not lic_res.get("valid"):
                return {"success": False, "message": lic_res.get("message", "Lisans doğrulanamadı! Lütfen Eczane Adı, GLN ve Telefon bilgilerinizi kontrol edin.")}
            lic_exp = lic_res.get("expires_at", "")
            lic_key_final = lic_res.get("license_key", lic_key_final)

        record_member_pharmacy({
            "installed_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "pharmacy_name": cfg.get("pharmacy_name", ""),
            "pharmacist_name": cfg.get("pharmacist_name", ""),
            "phone": cfg.get("phone", ""),
            "city": cfg.get("city", ""),
            "gln_no": cfg.get("gln_no", ""),
            "otomasyon": cfg.get("active_otomasyon", "BOTANIK"),
            "db_host": cfg.get("tria_host") or cfg.get("tebeos_host") or cfg.get("botanik_server", ""),
            "hwid": my_hwid,
            "pc_name": socket.gethostname(),
            "expires_at": lic_exp,
            "license_key": lic_key_final
        })

        if progress_cb:
            progress_cb(94, "Masaüstü kısayolu ve Kaldırma (Uninstall) aracı oluşturuluyor...")
        create_uninstaller(target_dir)
        create_shortcuts(target_dir)

        # Farma Radar sunucusunu başlat
        if progress_cb:
            progress_cb(98, "Farma Radar arka plan sunucusu başlatılıyor...")
        tria_exe = target_dir / "runtime" / "Tria.exe"
        py_exe = target_dir / "runtime" / "python.exe"
        exe_to_use = tria_exe if tria_exe.exists() else (py_exe if py_exe.exists() else Path(sys.executable))
        srv_py = target_dir / "server.py"
        if exe_to_use.exists() and srv_py.exists():
            cflags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000) | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
            env = os.environ.copy()
            env["TRIA_EXE_REEXEC"] = "1"
            subprocess.Popen([str(exe_to_use), str(srv_py)], cwd=str(target_dir), env=env, creationflags=cflags, close_fds=True)

        if progress_cb:
            progress_cb(100, "Kurulum tamamlandı! Farma Radar açılıyor...")
        return {"success": True, "target_dir": str(target_dir)}
    except Exception as e:
        return {"success": False, "message": f"Kurulum hatası: {str(e)}"}


def _load_initial_defaults() -> dict:
    env_defaults = {}
    for env_f in (SRC_DIR / ".env", Path(r"C:\EczaneDepoPro\.env")):
        if env_f.exists():
            for ln in env_f.read_text(encoding="utf-8", errors="ignore").splitlines():
                s = ln.strip()
                if s and not s.startswith("#") and "=" in s:
                    k, v = s.split("=", 1)
                    if v.strip():
                        env_defaults[k.strip()] = v.strip()

    my_hwid = "----"
    default_lic = ""
    if LicenseManager is not None:
        try:
            my_hwid = LicenseManager().get_hardware_id()
        except Exception:
            pass

    return {
        "hwid": my_hwid,
        "default_license": default_lic,
        "env": env_defaults,
        "src_dir": str(SRC_DIR),
        "default_install_dir": r"C:\EczaneDepoPro",
    }


WIZARD_HTML = """<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farma Radar — Profesyonel Kurulum Sihirbazı</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        body { font-family: 'Inter', sans-serif; background: #0f172a; color: #1e293b; }
    </style>
</head>
<body class="min-h-screen flex flex-col justify-between p-3 sm:p-5">
    <div class="max-w-4xl w-full mx-auto bg-white rounded-2xl shadow-2xl border border-slate-700 overflow-hidden my-auto">
        <!-- Üst Başlık -->
        <div class="px-5 py-3.5 bg-gradient-to-r from-slate-900 via-indigo-950 to-emerald-950 text-white flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 text-lg">
                    <i class="fa-solid fa-satellite-dish"></i>
                </div>
                <div>
                    <h1 class="text-base font-black tracking-tight text-white">FARMA RADAR — PROFESYONEL KURULUM SİHİRBAZI</h1>
                    <p class="text-[11px] text-slate-300">Adım Adım Eczane Otomasyonu, Depo Şifreleri ve Masaüstü Kurulum Yapılandırması</p>
                </div>
            </div>
            <span class="px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-extrabold">v1.4.2 Kurumsal</span>
        </div>

        <!-- Adım Sekmeleri -->
        <div class="grid grid-cols-4 bg-slate-100 border-b border-slate-200 text-xs font-extrabold">
            <button type="button" id="stepBtn1" onclick="goStep(1)" class="py-2.5 px-3 border-b-2 border-emerald-600 bg-white text-emerald-800 flex items-center justify-center gap-1.5 cursor-pointer">
                <span>1. 🏥 Eczane & Lisans</span>
            </button>
            <button type="button" id="stepBtn2" onclick="goStep(2)" class="py-2.5 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 flex items-center justify-center gap-1.5 cursor-pointer">
                <span>2. 🗄️ Eczane Otomasyonu</span>
            </button>
            <button type="button" id="stepBtn3" onclick="goStep(3)" class="py-2.5 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 flex items-center justify-center gap-1.5 cursor-pointer">
                <span>3. 🚚 Depo Şifreleri</span>
            </button>
            <button type="button" id="stepBtn4" onclick="goStep(4)" class="py-2.5 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 flex items-center justify-center gap-1.5 cursor-pointer">
                <span>4. 🚀 Kurulum & Başlat</span>
            </button>
        </div>

        <!-- İçerik Alanı -->
        <div class="p-5">
            <!-- ADIM 1 -->
            <div id="stepPanel1" class="space-y-4">
                <div class="text-xs font-extrabold text-slate-800 uppercase tracking-wider">Üye Eczane & Eczacı İletişim Bilgileri</div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Eczane Adı (*)</label>
                        <input id="pharmacy_name" type="text" placeholder="Örn: Eda Eczanesi" class="w-full p-2 rounded-lg border border-slate-300 font-bold">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Eczacı Adı Soyadı (*)</label>
                        <input id="pharmacist_name" type="text" placeholder="Örn: Ecz. Ad Soyad" class="w-full p-2 rounded-lg border border-slate-300">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Cep Telefonu (*)</label>
                        <input id="phone" type="text" placeholder="05XX XXX XX XX" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-2 gap-2">
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Şehir / İlçe</label>
                            <input id="city" type="text" placeholder="İstanbul" class="w-full p-2 rounded-lg border border-slate-300">
                        </div>
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Eczane GLN No (13 Hane) (*)</label>
                            <input id="gln_no" type="text" placeholder="8680001..." class="w-full p-2 rounded-lg border border-slate-300 font-mono font-bold">
                        </div>
                    </div>
                </div>

                <div class="bg-emerald-50/80 p-4 rounded-xl border border-emerald-300 space-y-2.5 text-xs">
                    <div class="flex flex-wrap items-center justify-between gap-2">
                        <span class="font-extrabold text-emerald-950">🎁 Otomatik 30 Günlük Lisans & GitHub Bulut Kaydı (HWID: <code id="hwidBadge" class="font-mono bg-white px-2 py-0.5 rounded border">----</code>)</span>
                        <div class="flex items-center gap-1.5">
                            <button type="button" id="btnClaimTrialWiz" onclick="claimAutoTrialLicense()" class="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black cursor-pointer shadow-xs">
                                🎁 30 Günlük Otomatik Lisans Tanımla
                            </button>
                            <button type="button" onclick="verifyLicense()" class="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold cursor-pointer">Anahtarı Doğrula</button>
                        </div>
                    </div>
                    <input id="license_key" type="text" placeholder="Yukarıdaki bilgileri doldurup '30 Günlük Otomatik Lisans Tanımla' butonuna tıklayın (veya mevcut FR-... anahtarınızı yapıştırın)" class="w-full p-2 rounded-lg border border-emerald-300 bg-white font-mono text-[11px] text-emerald-900">
                    <div id="licVerifyMsg" class="text-[11px] font-bold text-emerald-800">💡 Eczane Adı, GLN No ve Telefon numaranızı yazıp <b>"30 Günlük Otomatik Lisans Tanımla"</b> butonuna bastığınızda lisansınız otomatik oluşturulur ve merkezi sisteme kaydedilir.</div>
                </div>

                <div class="flex justify-end pt-2">
                    <button type="button" onclick="goStep(2)" class="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xs cursor-pointer">
                        Sonraki Adım: Eczane Otomasyonu ➔
                    </button>
                </div>
            </div>

            <!-- ADIM 2 -->
            <div id="stepPanel2" class="hidden space-y-4">
                <div>
                    <div class="text-xs font-extrabold text-slate-800 uppercase">Eczanenizde Kullandığınız Otomasyon Programını Seçin</div>
                    <p class="text-[11px] text-slate-500">Sadece seçtiğiniz otomasyon aktif edilir ve diğer otomasyon bağlantıları gizlenir.</p>
                </div>

                <div class="grid grid-cols-3 gap-2.5 text-xs">
                    <label onclick="selectOto('BOTANIK')" id="otoCard_BOTANIK" class="p-3 rounded-xl border-2 border-emerald-600 bg-emerald-50/60 cursor-pointer flex items-center gap-2 font-extrabold text-emerald-950">
                        <input type="radio" name="active_otomasyon" value="BOTANIK" checked class="accent-emerald-600">
                        <span>🌿 Botanik EOS (MS SQL)</span>
                    </label>
                    <label onclick="selectOto('TRIA')" id="otoCard_TRIA" class="p-3 rounded-xl border-2 border-slate-200 bg-slate-50 cursor-pointer flex items-center gap-2 font-extrabold text-slate-700">
                        <input type="radio" name="active_otomasyon" value="TRIA" class="accent-amber-600">
                        <span>🗄️ TRIA Eczane (Oracle)</span>
                    </label>
                    <label onclick="selectOto('TEBEOS')" id="otoCard_TEBEOS" class="p-3 rounded-xl border-2 border-slate-200 bg-slate-50 cursor-pointer flex items-center gap-2 font-extrabold text-slate-700">
                        <input type="radio" name="active_otomasyon" value="TEBEOS" class="accent-sky-600">
                        <span>🏥 TEBEOS (PostgreSQL)</span>
                    </label>
                </div>

                <!-- Botanik Kutusu -->
                <div id="otoBox_BOTANIK" class="p-4 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div class="sm:col-span-2">
                        <label class="block font-bold text-slate-700 mb-1">SQL Sunucu Adresi</label>
                        <input id="botanik_server" type="text" value=".\\BOTANIKSQL" class="w-full p-2 rounded-lg border border-slate-300 font-mono font-bold">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Veritabanı</label>
                        <input id="botanik_db" type="text" value="eczane" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-2 gap-1.5">
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Kullanıcı</label>
                            <input id="botanik_user" type="text" value="sa" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                        </div>
                        <div>
                            <label class="block font-bold text-slate-700 mb-1">Şifre</label>
                            <input id="botanik_pwd" type="text" value="123" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                        </div>
                    </div>
                </div>

                <!-- Tria Kutusu -->
                <div id="otoBox_TRIA" class="hidden p-4 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Ana Bilgisayar IP</label>
                        <input id="tria_host" type="text" placeholder="192.168.1.X" class="w-full p-2 rounded-lg border border-slate-300 font-mono font-bold">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Port</label>
                        <input id="tria_port" type="text" value="1521" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">SID</label>
                        <input id="tria_sid" type="text" value="ORCL" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Şema (Kullanıcı)</label>
                        <input id="tria_user" type="text" placeholder="TRIA_..." class="w-full p-2 rounded-lg border border-slate-300 font-mono font-bold">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Şifre</label>
                        <input id="tria_pwd" type="text" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                </div>

                <!-- Tebeos Kutusu -->
                <div id="otoBox_TEBEOS" class="hidden p-4 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Sunucu IP</label>
                        <input id="tebeos_host" type="text" placeholder="127.0.0.1" class="w-full p-2 rounded-lg border border-slate-300 font-mono font-bold">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Port</label>
                        <input id="tebeos_port" type="text" value="5454" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Veritabanı</label>
                        <input id="tebeos_db" type="text" value="tebeos_db" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Kullanıcı</label>
                        <input id="tebeos_user" type="text" value="tebeos" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">Şifre</label>
                        <input id="tebeos_pwd" type="text" value="123" class="w-full p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                </div>

                <div id="dbStatusBox" class="p-3 rounded-xl bg-slate-100 border border-slate-200 text-xs font-bold text-slate-700">
                    💡 "Ağda / Bilgisayarda Otomatik Bul" butonuyla sunucu bilgilerini otomatik doldurabilir veya elle girebilirsiniz.
                </div>

                <div class="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div class="flex items-center gap-2">
                        <button type="button" onclick="discoverDb()" class="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs cursor-pointer">
                            🔍 Ağda / Bilgisayarda Otomatik Bul
                        </button>
                        <button type="button" onclick="testDb()" class="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs cursor-pointer">
                            ⚡ Canlı Bağlantıyı Test Et
                        </button>
                    </div>
                    <button type="button" onclick="goStep(3)" class="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xs cursor-pointer">
                        Sonraki Adım: Depo Şifreleri ➔
                    </button>
                </div>
            </div>

            <!-- ADIM 3 -->
            <div id="stepPanel3" class="hidden space-y-3">
                <div class="text-xs font-extrabold text-slate-800 uppercase">Ecza Depoları & Pazaryeri Giriş Bilgileri (Kullandığınız Depoları Doldurun)</div>
                <div class="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2 text-xs max-h-[340px] overflow-y-auto">
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">Alliance Healthcare</span>
                        <input id="alliance_code" placeholder="Eczane Kodu" class="col-span-3 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="alliance_user" placeholder="Kullanıcı Adı" class="col-span-3 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="alliance_pwd" type="password" placeholder="Şifre" class="col-span-3 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">Selçuk Ecza (WebDepo)</span>
                        <input id="selcuk_user" placeholder="Kullanıcı Kodu" class="col-span-4 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="selcuk_pwd" type="password" placeholder="Şifre" class="col-span-5 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">Nevzat Ecza Deposu</span>
                        <input id="nevzat_code" placeholder="Hesap Kodu" class="col-span-3 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="nevzat_user" placeholder="Kullanıcı Adı" class="col-span-3 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="nevzat_pwd" type="password" placeholder="Şifre" class="col-span-3 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">İSKOOP (İstanbul Koop)</span>
                        <input id="iskoop_user" placeholder="Kullanıcı Kodu" class="col-span-4 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="iskoop_pwd" type="password" placeholder="Şifre" class="col-span-5 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">BEK (Bursa Ecz. Koop)</span>
                        <input id="bek_user" placeholder="Kullanıcı Kodu" class="col-span-4 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="bek_pwd" type="password" placeholder="Şifre" class="col-span-5 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">DNA Ecza Deposu</span>
                        <input id="dna_user" placeholder="Kullanıcı Kodu" class="col-span-4 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="dna_pwd" type="password" placeholder="Şifre" class="col-span-5 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">Farmazon Pazaryeri</span>
                        <input id="farmazon_user" placeholder="Kullanıcı / E-posta" class="col-span-4 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="farmazon_pwd" type="password" placeholder="Şifre" class="col-span-5 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">Ecza1 Pazaryeri</span>
                        <input id="ecza1_user" placeholder="Kullanıcı / GLN" class="col-span-4 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="ecza1_pwd" type="password" placeholder="Şifre" class="col-span-5 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">Eczatrend Ortak Alım</span>
                        <input id="eczatrend_user" placeholder="E-posta / Kullanıcı" class="col-span-4 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="eczatrend_pwd" type="password" placeholder="Şifre" class="col-span-5 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                    <div class="grid grid-cols-12 gap-2 items-center">
                        <span class="col-span-3 font-extrabold text-slate-800">EczaneTakas</span>
                        <input id="eczanetakas_user" placeholder="E-posta / Kullanıcı" class="col-span-4 p-1.5 rounded border border-slate-300 font-mono">
                        <input id="eczanetakas_pwd" type="password" placeholder="Şifre" class="col-span-5 p-1.5 rounded border border-slate-300 font-mono">
                    </div>
                </div>
                <div class="flex justify-end pt-1">
                    <button type="button" onclick="goStep(4)" class="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xs cursor-pointer">
                        Sonraki Adım: Kurulumu Tamamla ➔
                    </button>
                </div>
            </div>

            <!-- ADIM 4 -->
            <div id="stepPanel4" class="hidden space-y-4">
                <div>
                    <label class="block text-xs font-extrabold text-slate-800 uppercase mb-1">Hedef Kurulum Klasörü</label>
                    <input id="install_dir" type="text" value="C:\\EczaneDepoPro" class="w-full p-2.5 rounded-xl border border-slate-300 bg-slate-50 font-mono font-bold text-sm">
                </div>

                <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 space-y-1.5 font-semibold">
                    <div>✓ Masaüstüne <b>"Farma Radar"</b> başlatma kısayolu oluşturulacak</div>
                    <div>✓ Canlı Güncelleme Merkezi (<b>depomxxx/depo-updates</b>) otomatik aktif edilecek</div>
                    <div>✓ Sadece seçtiğiniz eczane otomasyonu aktif edilecek</div>
                    <div>✓ Kurulum klasörüne tek tıkla kaldırma aracı (<b>Uninstall_FarmaRadar.bat</b>) eklenecek</div>
                </div>

                <div class="space-y-1.5">
                    <div id="installStatusText" class="text-xs font-extrabold text-emerald-700">Kuruluma hazır. Aşağıdaki butona tıklayarak kurulumu başlatın.</div>
                    <div class="w-full h-3 bg-slate-200 rounded-full overflow-hidden">
                        <div id="installProgressBar" class="h-full bg-emerald-600 transition-all duration-300" style="width: 0%;"></div>
                    </div>
                </div>

                <button type="button" id="btnStartInstall" onclick="startInstall()" class="w-full py-3.5 px-5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-sm shadow-lg transition cursor-pointer">
                    🚀 KURULUMU BAŞLAT, AYARLARI KAYDET VE FARMA RADAR'I AÇ
                </button>
            </div>
        </div>
    </div>

    <script>
        let currentOto = 'BOTANIK';

        function goStep(n) {
            for (let i = 1; i <= 4; i++) {
                document.getElementById('stepPanel' + i).classList.toggle('hidden', i !== n);
                const btn = document.getElementById('stepBtn' + i);
                if (i === n) {
                    btn.className = 'py-2.5 px-3 border-b-2 border-emerald-600 bg-white text-emerald-800 flex items-center justify-center gap-1.5 cursor-pointer';
                } else {
                    btn.className = 'py-2.5 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 flex items-center justify-center gap-1.5 cursor-pointer';
                }
            }
        }

        function selectOto(oto) {
            currentOto = oto;
            ['BOTANIK', 'TRIA', 'TEBEOS'].forEach(k => {
                document.getElementById('otoBox_' + k).classList.toggle('hidden', k !== oto);
                const card = document.getElementById('otoCard_' + k);
                const radio = card.querySelector('input[type="radio"]');
                if (radio) radio.checked = (k === oto);
                card.className = (k === oto)
                    ? 'p-3 rounded-xl border-2 border-emerald-600 bg-emerald-50/60 cursor-pointer flex items-center gap-2 font-extrabold text-emerald-950'
                    : 'p-3 rounded-xl border-2 border-slate-200 bg-slate-50 cursor-pointer flex items-center gap-2 font-extrabold text-slate-700';
            });
        }

        async function loadDefaults() {
            try {
                const res = await fetch('/api/defaults');
                const d = await res.json();
                if (d.hwid) document.getElementById('hwidBadge').innerText = d.hwid;
                if (d.default_license) document.getElementById('license_key').value = d.default_license;
                const env = d.env || {};
                const map = {
                    'BOTANIK_SQL_SERVER': 'botanik_server',
                    'BOTANIK_SQL_DB': 'botanik_db',
                    'BOTANIK_SQL_USER': 'botanik_user',
                    'BOTANIK_SQL_PASSWORD': 'botanik_pwd',
                    'TRIA_ORACLE_HOST': 'tria_host',
                    'TRIA_ORACLE_PORT': 'tria_port',
                    'TRIA_ORACLE_SID': 'tria_sid',
                    'TRIA_ORACLE_USER': 'tria_user',
                    'TRIA_ORACLE_PASSWORD': 'tria_pwd',
                    'TEBEOS_PG_HOST': 'tebeos_host',
                    'TEBEOS_PG_PORT': 'tebeos_port',
                    'TEBEOS_PG_DB': 'tebeos_db',
                    'TEBEOS_PG_USER': 'tebeos_user',
                    'TEBEOS_PG_PASSWORD': 'tebeos_pwd',
                    'ALLIANCE_PHARMACY_CODE': 'alliance_code',
                    'ALLIANCE_USERNAME': 'alliance_user',
                    'ALLIANCE_PASSWORD': 'alliance_pwd',
                    'SELCUK_USERNAME': 'selcuk_user',
                    'SELCUK_PASSWORD': 'selcuk_pwd',
                    'NEVZAT_ACCOUNT_CODE': 'nevzat_code',
                    'NEVZAT_USERNAME': 'nevzat_user',
                    'NEVZAT_PASSWORD': 'nevzat_pwd',
                    'ISKOOP_USERNAME': 'iskoop_user',
                    'ISKOOP_PASSWORD': 'iskoop_pwd',
                    'BEK_USERNAME': 'bek_user',
                    'BEK_PASSWORD': 'bek_pwd',
                    'DNA_USERNAME': 'dna_user',
                    'DNA_PASSWORD': 'dna_pwd',
                    'FARMAZON_USERNAME': 'farmazon_user',
                    'FARMAZON_PASSWORD': 'farmazon_pwd',
                    'ECZA1_USERNAME': 'ecza1_user',
                    'ECZA1_PASSWORD': 'ecza1_pwd',
                    'ECZATREND_USERNAME': 'eczatrend_user',
                    'ECZATREND_PASSWORD': 'eczatrend_pwd',
                    'ECZANETAKAS_USERNAME': 'eczanetakas_user',
                    'ECZANETAKAS_PASSWORD': 'eczanetakas_pwd'
                };
                Object.keys(map).forEach(k => {
                    if (env[k] !== undefined && document.getElementById(map[k])) {
                        document.getElementById(map[k]).value = env[k];
                    }
                });
                if (env.ACTIVE_OTOMASYON) selectOto(env.ACTIVE_OTOMASYON.toUpperCase());
            } catch (e) {}
        }

        async function claimAutoTrialLicense() {
            const pname = document.getElementById('pharmacy_name').value.trim();
            const gln = document.getElementById('gln_no').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const pharmacist = document.getElementById('pharmacist_name').value.trim();
            const city = document.getElementById('city').value.trim();
            const el = document.getElementById('licVerifyMsg');
            const btn = document.getElementById('btnClaimTrialWiz');

            if (!pname || !gln || !phone) {
                el.innerText = '✗ Lütfen önce Eczane Adı, 13 Haneli GLN Numarası ve Cep Telefonu alanlarını doldurunuz!';
                el.className = 'text-[11px] font-bold text-rose-600';
                return;
            }
            if (btn) {
                btn.disabled = true;
                btn.innerText = '⏳ Tanımlanıyor...';
            }
            try {
                const res = await fetch('/api/register-trial', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        pharmacy_name: pname,
                        gln_no: gln,
                        phone: phone,
                        pharmacist_name: pharmacist,
                        city: city,
                        otomasyon: currentOto
                    })
                });
                const d = await res.json();
                if (d.license_key) {
                    document.getElementById('license_key').value = d.license_key;
                }
                el.innerText = (d.valid ? '✓ ' : '✗ ') + (d.message || '');
                el.className = d.valid ? 'text-[11px] font-bold text-emerald-700' : 'text-[11px] font-bold text-rose-600';
            } catch (e) {
                el.innerText = '✗ Bağlantı hatası: ' + e.message;
                el.className = 'text-[11px] font-bold text-rose-600';
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerText = '🎁 30 Günlük Otomatik Lisans Tanımla';
                }
            }
        }

        async function verifyLicense() {
            const key = document.getElementById('license_key').value;
            const res = await fetch('/api/verify-license', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({license_key: key})
            });
            const d = await res.json();
            const el = document.getElementById('licVerifyMsg');
            el.innerText = (d.valid ? '✓ ' : '✗ ') + (d.message || '');
            el.className = d.valid ? 'text-[11px] font-bold text-emerald-700' : 'text-[11px] font-bold text-rose-600';
        }

        async function discoverDb() {
            const box = document.getElementById('dbStatusBox');
            box.innerText = '🔍 ' + currentOto + ' sunucusu bilgisayarda ve yerel ağda otomatik aranıyor...';
            box.className = 'p-3 rounded-xl bg-sky-50 border border-sky-200 text-xs font-bold text-sky-800';
            const res = await fetch('/api/discover-db', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({otomasyon: currentOto})
            });
            const d = await res.json();
            if (d.found || d.success) {
                if (currentOto === 'BOTANIK') {
                    if (d.server) document.getElementById('botanik_server').value = d.server;
                    if (d.database) document.getElementById('botanik_db').value = d.database;
                    if (d.user) document.getElementById('botanik_user').value = d.user;
                    if (d.password) document.getElementById('botanik_pwd').value = d.password;
                } else if (currentOto === 'TRIA') {
                    if (d.host) document.getElementById('tria_host').value = d.host;
                    if (d.port) document.getElementById('tria_port').value = d.port;
                    if (d.sid) document.getElementById('tria_sid').value = d.sid;
                    if (d.user) document.getElementById('tria_user').value = d.user;
                    if (d.password) document.getElementById('tria_pwd').value = d.password;
                } else if (currentOto === 'TEBEOS') {
                    if (d.host) document.getElementById('tebeos_host').value = d.host;
                    if (d.port) document.getElementById('tebeos_port').value = d.port;
                    if (d.database) document.getElementById('tebeos_db').value = d.database;
                    if (d.user) document.getElementById('tebeos_user').value = d.user;
                    if (d.password) document.getElementById('tebeos_pwd').value = d.password;
                }
                box.innerText = '✅ ' + (d.message || 'Sunucu bilgileri otomatik bulundu!');
                box.className = 'p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800';
            } else {
                box.innerText = '⚠️ ' + (d.message || 'Otomatik bulunamadı, lütfen bilgileri elle girin.');
                box.className = 'p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs font-bold text-amber-800';
            }
        }

        async function testDb() {
            const box = document.getElementById('dbStatusBox');
            box.innerText = '⏳ ' + currentOto + ' veritabanına bağlanılıyor, lütfen bekleyin...';
            box.className = 'p-3 rounded-xl bg-sky-50 border border-sky-200 text-xs font-bold text-sky-800';
            const payload = collectPayload();
            const res = await fetch('/api/test-db', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            });
            const d = await res.json();
            if (d.connected) {
                box.innerText = '✅ BAĞLANTI BAŞARILI (' + (d.latency_ms || 0) + ' ms) — ' + (d.message || '');
                box.className = 'p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800';
            } else {
                box.innerText = '❌ Bağlantı Hatası: ' + (d.message || 'Sunucuya ulaşılamadı');
                box.className = 'p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs font-bold text-rose-700';
            }
        }

        function collectPayload() {
            const ids = [
                'install_dir', 'pharmacy_name', 'pharmacist_name', 'phone', 'city', 'gln_no', 'license_key',
                'botanik_server', 'botanik_db', 'botanik_user', 'botanik_pwd',
                'tria_host', 'tria_port', 'tria_sid', 'tria_user', 'tria_pwd',
                'tebeos_host', 'tebeos_port', 'tebeos_db', 'tebeos_user', 'tebeos_pwd',
                'alliance_code', 'alliance_user', 'alliance_pwd',
                'selcuk_user', 'selcuk_pwd',
                'nevzat_code', 'nevzat_user', 'nevzat_pwd',
                'iskoop_user', 'iskoop_pwd',
                'bek_user', 'bek_pwd',
                'dna_user', 'dna_pwd',
                'farmazon_user', 'farmazon_pwd',
                'ecza1_user', 'ecza1_pwd',
                'eczatrend_user', 'eczatrend_pwd',
                'eczanetakas_user', 'eczanetakas_pwd'
            ];
            const out = { active_otomasyon: currentOto };
            ids.forEach(id => {
                const el = document.getElementById(id);
                out[id] = el ? el.value : '';
            });
            return out;
        }

        async function startInstall() {
            const btn = document.getElementById('btnStartInstall');
            btn.disabled = true;
            btn.innerText = '⏳ Kuruluyor, lütfen bekleyin...';
            const payload = collectPayload();
            await fetch('/api/install', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            });
            const timer = setInterval(async () => {
                try {
                    const r = await fetch('/api/install-status');
                    const st = await r.json();
                    document.getElementById('installProgressBar').style.width = (st.pct || 0) + '%';
                    document.getElementById('installStatusText').innerText = st.message || '';
                    if (st.done) {
                        clearInterval(timer);
                        if (st.success) {
                            btn.innerText = '✅ KURULUM TAMAMLANDI! FARMA RADAR AÇILIYOR...';
                            setTimeout(() => {
                                window.location.href = 'http://127.0.0.1:8080';
                            }, 2200);
                        } else {
                            btn.disabled = false;
                            btn.innerText = '🚀 KURULUMU BAŞLAT, AYARLARI KAYDET VE FARMA RADAR\\'I AÇ';
                            alert(st.message || 'Kurulum hatası');
                        }
                    }
                } catch (e) {}
            }, 400);
        }

        loadDefaults();
    </script>
</body>
</html>
"""


class _WizardHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def _send_json(self, data: dict, status: int = 200):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path.startswith("/api/defaults"):
            self._send_json(_load_initial_defaults())
            return
        if self.path.startswith("/api/install-status"):
            self._send_json(_INSTALL_STATE)
            return
        raw = WIZARD_HTML.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}

        if self.path.startswith("/api/register-trial"):
            if not LicenseManager:
                self._send_json({"valid": False, "message": "Lisans motoru yüklenemedi."})
                return
            res = LicenseManager().register_pharmacy_trial(
                pharmacy_name=body.get("pharmacy_name", ""),
                gln_no=body.get("gln_no", ""),
                phone=body.get("phone", ""),
                pharmacist_name=body.get("pharmacist_name", ""),
                city=body.get("city", ""),
                otomasyon=body.get("otomasyon", "BOTANIK"),
            )
            self._send_json(res)
            return

        if self.path.startswith("/api/verify-license"):
            if not LicenseManager:
                self._send_json({"valid": True, "message": "Lisans anahtarı hazır."})
                return
            res = LicenseManager().verify_license_key(body.get("license_key", ""))
            self._send_json(res)
            return

        if self.path.startswith("/api/discover-db"):
            chosen = (body.get("otomasyon") or "BOTANIK").upper()
            try:
                if chosen == "BOTANIK":
                    from backend.botanik_client import botanik_client
                    res = botanik_client.read_botanik_config_file()
                    self._send_json(res)
                elif chosen == "TRIA":
                    from backend.tria_client import tria_client
                    res = tria_client.discover_tria_host()
                    self._send_json(res)
                else:
                    from backend.tebeos_client import tebeos_client
                    res = tebeos_client.discover_tebeos_host()
                    self._send_json(res)
            except Exception as e:
                self._send_json({"found": False, "success": False, "message": str(e)})
            return

        if self.path.startswith("/api/test-db"):
            chosen = (body.get("active_otomasyon") or "BOTANIK").upper()
            try:
                if chosen == "TRIA":
                    from backend.tria_client import tria_client
                    res = tria_client.ping(
                        host=body.get("tria_host", ""),
                        port=body.get("tria_port", "1521"),
                        sid=body.get("tria_sid", "ORCL"),
                        user=body.get("tria_user", ""),
                        password=body.get("tria_pwd", "")
                    )
                elif chosen == "TEBEOS":
                    from backend.tebeos_client import tebeos_client
                    res = tebeos_client.ping(
                        host=body.get("tebeos_host", ""),
                        port=body.get("tebeos_port", "5454"),
                        database=body.get("tebeos_db", "tebeos_db"),
                        user=body.get("tebeos_user", "tebeos"),
                        password=body.get("tebeos_pwd", "123")
                    )
                else:
                    from backend.botanik_client import botanik_client
                    res = botanik_client.ping(
                        server=body.get("botanik_server", r".\BOTANIKSQL"),
                        database=body.get("botanik_db", "eczane"),
                        user=body.get("botanik_user", "sa"),
                        password=body.get("botanik_pwd", "123")
                    )
                self._send_json(res)
            except Exception as e:
                self._send_json({"connected": False, "message": str(e)})
            return

        if self.path.startswith("/api/install"):
            if _INSTALL_STATE["running"]:
                self._send_json({"started": True})
                return
            _INSTALL_STATE.update({"running": True, "pct": 5, "message": "Kurulum başlatılıyor...", "done": False, "success": False})

            def _cb(pct, msg):
                _INSTALL_STATE["pct"] = pct
                _INSTALL_STATE["message"] = msg

            def _worker():
                res = perform_installation(body, progress_cb=_cb)
                _INSTALL_STATE["running"] = False
                _INSTALL_STATE["done"] = True
                _INSTALL_STATE["success"] = bool(res.get("success"))
                _INSTALL_STATE["message"] = res.get("message") or ("Kurulum tamamlandı!" if res.get("success") else "Hata oluştu")
                if res.get("success"):
                    time.sleep(5.0)
                    os._exit(0)

            threading.Thread(target=_worker, daemon=True).start()
            self._send_json({"started": True})
            return


def _open_app_window(url: str):
    """Varsa Edge/Chrome --app modunda masaüstü penceresi olarak açar, yoksa varsayılan tarayıcıda açar."""
    candidates = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    ]
    for exe in candidates:
        if os.path.isfile(exe):
            try:
                subprocess.Popen([exe, f"--app={url}", "--window-size=940,740"])
                return
            except Exception:
                pass
    try:
        os.startfile(url)
    except Exception:
        webbrowser.open(url)


def run_gui():
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), _WizardHandler)
    port = httpd.server_address[1]
    url = f"http://127.0.0.1:{port}"
    print("===============================================================================")
    print("   FARMA RADAR - PROFESYONEL KURULUM SIHIRBAZI CALISIYOR")
    print(f"   Kurulum ekrani acildi: {url}")
    print("   (Bu pencere kurulum tamamlandiginda otomatik kapanacaktir)")
    print("===============================================================================")
    threading.Timer(0.4, lambda: _open_app_window(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    run_gui()
