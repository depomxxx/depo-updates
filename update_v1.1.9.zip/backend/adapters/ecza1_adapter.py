import asyncio
import json
from typing import List, Optional, Dict, Any
from pathlib import Path
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.core.session_store import SessionStore
from backend.catalog import catalog

class Ecza1Adapter(BaseDepoAdapter):
    LOGIN_URL = "https://www.ecza1.com/Home/Login"
    MAIN_URL = "https://www.ecza1.com/Product/CategoryProductList"

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ECZA1, "Ecza1 Pazaryeri")
        self.username = username
        self.password = password
        self.headless = headless
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
        self._last_login_fail_ts: float = 0.0
        self._lock = asyncio.Lock()

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-setuid-sandbox"]
            )
            
            session_file = SessionStore.get_session_file("ecza1")
            if session_file.exists():
                try:
                    self._context = await self._browser.new_context(storage_state=str(session_file))
                except Exception:
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()
                
            self._page = await self._context.new_page()

    async def is_session_valid(self) -> bool:
        session_file = SessionStore.get_session_file("ecza1")
        if not self._page and not session_file.exists():
            return False
        if not self._page:
            await self._init_browser()
            
        try:
            cur_url = (self._page.url or "").lower()
            if "ecza1.com" in cur_url and "login" not in cur_url:
                has_header = await self._page.evaluate("() => !!document.querySelector('#siteWideSearch, .site-header')")
                if has_header:
                    return True
            if not session_file.exists():
                return False
            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=6000)
            if "login" in (self._page.url or "").lower():
                return False
            has_header = await self._page.evaluate("() => !!document.querySelector('#siteWideSearch, .site-header')")
            return bool(has_header)
        except Exception:
            return False

    async def login(self) -> bool:
        """Ecza1'e giriş yapar."""
        import time
        if not self.username or not self.password:
            raise ValueError("Ecza1 için Kullanıcı Adı ve Şifre zorunludur.")

        await self._init_browser()
        
        if await self.is_session_valid():
            print("[Ecza1] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            self._last_login_fail_ts = 0.0
            return True

        print("[Ecza1] Giriş yapılıyor...")
        try:
            await self._page.goto(self.LOGIN_URL, wait_until="domcontentloaded", timeout=10000)

            await self._page.fill('input[name="UserName"]', str(self.username))
            await self._page.fill('input[name="Password"]', str(self.password))
            await self._page.click('button[type="submit"]')
            
            try:
                await self._page.wait_for_url(lambda url: "login" not in url.lower(), timeout=6000)
            except Exception:
                await self._page.wait_for_load_state("domcontentloaded")

            if "login" in (self._page.url or "").lower():
                self._last_login_fail_ts = time.time()
                raise RuntimeError("Ecza1 Giriş Başarısız! Kullanıcı adı veya şifre hatalı.")

            session_file = SessionStore.get_session_file("ecza1")
            await self._context.storage_state(path=str(session_file))
            print("[Ecza1] Başarıyla giriş yapıldı ve oturum kaydedildi.")
            self.is_logged_in = True
            self._last_login_fail_ts = 0.0
            return True
        except Exception:
            self._last_login_fail_ts = time.time()
            raise

    async def _ensure_ready_page(self):
        if not self._page:
            await self._init_browser()
        cur_url = (self._page.url or "").lower()
        if "ecza1.com" not in cur_url or "login" in cur_url:
            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=8000)

    async def search_product(self, query: str) -> List[DepoUrunSarti]:
        """Ecza1'de ürün ara."""
        import time
        async with self._lock:
            if not self.is_logged_in:
                if self._last_login_fail_ts and (time.time() - self._last_login_fail_ts) < 120.0:
                    return []
                await self.login()

            await self._ensure_ready_page()
            print(f"[Ecza1] '{query}' sorgulanıyor...")

            res = await self._page.evaluate("""async (q) => {
            const formData = new URLSearchParams();
            formData.append("PageSize", "10");
            formData.append("PageNumber", "1");
            formData.append("KategoriStr", "0");
            formData.append("SearchText", "");
            formData.append("SearchKey", q);
            formData.append("SiteIdList", "");
            formData.append("Menu", "");
            formData.append("IsEqualUserId", "false");
            formData.append("Sira", "0");
            formData.append("ListName", "productgridlistTemp");
            formData.append("MarkaStr", "");
            formData.append("EczaciStr", "");
            formData.append("AltKategoriStr", "");

            try {
                const r = await fetch("/Product/GetProductList", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                    },
                    body: formData.toString()
                });
                const data = await r.json();
                if (!data || !data.Data) return [];

                const products = data.Data.slice(0, 5);
                const enriched = await Promise.all(products.map(async (p) => {
                    let miad = null;
                    let offers = [];
                    if (p.UserProductCount > 0 && p.LowestPrice > 0) {
                        try {
                            const fd = new URLSearchParams();
                            fd.append("id", p.Id);
                            fd.append("IsMiadFilter", "false");
                            fd.append("IsCargo", "false");
                            fd.append("IsGreaterThan", "false");
                            fd.append("IsNotMinPrice", "false");
                            const mResp = await fetch("/Shop/SearchSiteProductListUserProducts", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                                },
                                body: fd.toString()
                            });
                            const mJson = await mResp.json();
                            if (mJson && mJson.Data) {
                                const rawListings = typeof mJson.Data === 'string' ? JSON.parse(mJson.Data) : mJson.Data;
                                if (rawListings && rawListings.length > 0) {
                                    miad = rawListings[0].PostMatureDate || null;
                                    offers = rawListings.map(l => {
                                        const cleanNote = (l.WebNote && l.WebNote.trim() !== "-") ? l.WebNote.trim() : "";
                                        return {
                                            ilan_id: String(l.UserProductId || l.SiteProductId || ""),
                                            satici: l.Username || "Ecza1 Eczanesi",
                                            fiyat_kdvli: parseFloat(l.UnitPrice) || 0.0,
                                            fiyat_kdvsiz: parseFloat(l.UnitPrice) || 0.0,
                                            stok: parseInt(l.Stock) || 0,
                                            miad: l.PostMatureDate || "-",
                                            puan: parseFloat(l.AvgRating) || null,
                                            min_tutar: parseFloat(l.MinimumSaleAmount) || null,
                                            ucretsiz_kargo: (parseFloat(l.CargoCampaignAmount) > 0) ? parseFloat(l.CargoCampaignAmount) : null,
                                            kargo: l.UserShippingFirms || "",
                                            aciklama: cleanNote,
                                            e_fatura: !!l.IsEInvoice
                                        };
                                    });
                                }
                            }
                        } catch(e) {}
                    }
                    return {
                        ...p,
                        extractedMiad: miad,
                        extractedOffers: offers
                    };
                }));
                return enriched;
            } catch(e) {
                return [];
            }
        }""", query)

        if not res:
            return []

        clean_q = query.strip()
        # Barkod Filtreleme: Aranan ürünle eşleşmeyen yabancı ürün tekliflerini filtrele
        if clean_q.isdigit() and len(clean_q) >= 8:
            matched_items = [it for it in res if str(it.get("Barcode") or "").strip() == clean_q]
            if not matched_items:
                cat_item = catalog.get_by_barcode(clean_q)
                target_name_lower = (cat_item.get("name") if cat_item else "").lower()
                if target_name_lower and res:
                    first_title = str(res[0].get("Title") or "").lower()
                    main_words = [w for w in target_name_lower.split() if len(w) > 3 and not w.isdigit()]
                    if any(w in first_title for w in main_words):
                        matched_items = [res[0]]
            if matched_items:
                res = matched_items
            else:
                return []

        # Ön KDV tespiti (Katalogdan veya genel)
        cat_info = catalog.get_by_barcode(clean_q)
        initial_vat = float(cat_info["vat"]) if (cat_info and cat_info.get("vat") and float(cat_info["vat"]) > 0) else None

        supplement_keywords = [
            "takviye edici", "gida takviyesi", "gıda takviyesi", "omega", "balık yağı", "balik yagi",
            "vitamin", "mineral", "multivitamin", "kolajen", "kollajen", "collagen",
            "magnezyum", "magnesium", "çinko", "zinc", "probiyotik", "probiotik",
            "d3", "b12", "c vitamini", "ester-c", "sambucol", "solgar", "ocean",
            "venatura", "zade vital", "supradyn", "pharmaton", "vefail", "coenzyme", "koenzim",
            "krill", "propolis", "kara mürver", "melatonin", "glukozamin", "glucosamine"
        ]

        # Tüm varyasyon ve ürünlerden gelen satıcı tekliflerini tek bir havuzda birleştir
        all_offers = []
        seen_ilan_ids = set()
        best_min_price = 999999.0
        total_user_count = 0
        canonical_title = str(res[0].get("Title") or "")

        # KDV Tespiti: Katalog -> İsim analizi -> %10
        kdv_orani = 10.0
        if initial_vat:
            kdv_orani = initial_vat
        else:
            title_lower = canonical_title.lower()
            if any(kw in title_lower for kw in supplement_keywords):
                kdv_orani = 1.0

        for it in res:
            lowest_price = float(it.get("LowestPrice") or 0.0)
            if lowest_price > 0 and lowest_price < best_min_price:
                best_min_price = lowest_price
            total_user_count += int(it.get("UserProductCount") or 0)
            raw_offers = it.get("extractedOffers") or []
            it_title = str(it.get("Title") or "")

            for off in raw_offers:
                ilan_id = off.get("ilan_id")
                if ilan_id and ilan_id in seen_ilan_ids:
                    continue
                if ilan_id:
                    seen_ilan_ids.add(ilan_id)

                # Ecza1'de çekilen UnitPrice KDV DAHİL fiyattır.
                raw_val = float(off.get("fiyat_kdvli") or off.get("fiyat_kdvsiz") or off.get("fiyat") or 0.0)
                if raw_val <= 0:
                    continue
                f_kdvli = round(raw_val, 2)
                f_kdvsiz = round(f_kdvli / (1.0 + (kdv_orani / 100.0)), 2)

                all_offers.append({
                    **off,
                    "fiyat": f_kdvli,
                    "fiyat_kdvli": f_kdvli,
                    "fiyat_kdvsiz": f_kdvsiz
                })

        all_offers.sort(key=lambda x: x["fiyat_kdvsiz"])

        has_stock = len(all_offers) > 0 or (total_user_count > 0 and best_min_price < 999999.0)
        stok_durumu = StokDurumu.VAR if has_stock else StokDurumu.YOK

        if all_offers:
            net_birim = all_offers[0]["fiyat_kdvsiz"]
            net_kdvli = all_offers[0]["fiyat_kdvli"]
            extracted_miad = all_offers[0]["miad"] if all_offers[0]["miad"] != "-" else None
        elif best_min_price < 999999.0:
            net_kdvli = round(best_min_price, 2)
            net_birim = round(net_kdvli / (1.0 + (kdv_orani / 100.0)), 2)
            extracted_miad = None
        else:
            net_birim = 0.0
            net_kdvli = 0.0
            extracted_miad = None

        teklif_sayisi = len(all_offers) if all_offers else total_user_count
        notu = f"{teklif_sayisi} Eczane Satışta (Farklı Fiyatlar)"
        if extracted_miad:
            notu += f" • Miad: {extracted_miad}"

        sarti = DepoUrunSarti(
            depo=DepoKodu.ECZA1,
            depo_adi=self.depo_adi,
            barkod=str(res[0].get("Barcode") or query),
            urun_id=str(res[0].get("Id", "")),
            urun_adi=canonical_title,
            stok_durumu=stok_durumu,
            stok_adedi=teklif_sayisi,
            depocu_satis_fiyati=net_birim,
            perakende_satis_fiyati=round(net_birim * 1.35, 2),
            kdv_orani=kdv_orani,
            mf_metni="PAZARYERİ",
            ticari_iskonto=0.0,
            vade_gun=0,
            net_birim_maliyet=net_birim,
            net_birim_maliyet_kdvli=net_kdvli,
            toplam_indirim_yuzdesi=0.0,
            miad=extracted_miad,
            ozel_kampanya_notu=notu,
            pazaryeri_teklifleri=all_offers
        )
        return [sarti]

    async def close(self):
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
