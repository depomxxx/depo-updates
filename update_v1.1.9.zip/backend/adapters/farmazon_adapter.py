import asyncio
import json
import os
from pathlib import Path
from typing import List, Optional, Dict, Any
from playwright.async_api import async_playwright, Browser, BrowserContext, Page, Playwright

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.catalog import catalog

SESSIONS_DIR = Path(__file__).resolve().parent.parent / "sessions"
SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
FARMAZON_STATE_FILE = SESSIONS_DIR / "farmazon_state.json"

class FarmazonAdapter(BaseDepoAdapter):
    """
    Farmazon B2B Eczane Pazaryeri Adaptörü
    URL: https://www.farmazon.com.tr
    """
    LOGIN_URL = "https://www.farmazon.com.tr/account/login"
    HOMEPAGE_URL = "https://www.farmazon.com.tr/homepage"
    SEARCH_URL = "https://www.farmazon.com.tr/categories/?q="

    def __init__(self, username: str, password: str, headless: bool = True):
        super().__init__(
            depo_kodu=DepoKodu.FARMAZON,
            depo_adi="Farmazon Pazaryeri"
        )
        self.username = username
        self.password = password
        self.headless = headless
        self._playwright: Optional[Playwright] = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
        self._last_login_fail_ts: float = 0.0
        self._lock = asyncio.Lock()

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
        if not self._browser:
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-dev-shm-usage"]
            )
        if not self._context:
            if FARMAZON_STATE_FILE.exists():
                try:
                    self._context = await self._browser.new_context(
                        storage_state=str(FARMAZON_STATE_FILE),
                        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                    )
                except Exception as e:
                    print(f"[Farmazon] State yükleme hatası: {e}")
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()

        if not self._page:
            self._page = await self._context.new_page()

    async def login(self) -> bool:
        """Farmazon'a giriş yapar veya kayıtlı oturumu doğrular."""
        await self._init_browser()

        # Kayıtlı oturumu kontrol et
        if FARMAZON_STATE_FILE.exists():
            try:
                cur_url = (self._page.url or "").lower()
                if "farmazon.com.tr" not in cur_url:
                    await self._page.goto("https://www.farmazon.com.tr/categories/", wait_until="commit", timeout=8000)
                has_auth = await self._page.evaluate("""() => {
                    try {
                        const a = localStorage.getItem("AuthData_1");
                        if (a && JSON.parse(a).token) return true;
                    } catch(e) {}
                    return false;
                }""")
                if has_auth and "login" not in (self._page.url or "").lower():
                    self.is_logged_in = True
                    self._is_logged_in = True
                    self._last_login_fail_ts = 0.0
                    print("[Farmazon] Mevcut oturum aktif, doğrudan bağlanıldı.")
                    return True
                else:
                    print("[Farmazon] Oturum süresi dolmuş veya token yok, yeniden giriş yapılıyor...")
            except Exception as e:
                print(f"[Farmazon] Mevcut oturum kontrolü hatası: {e}")

        print("[Farmazon] Giriş yapılıyor...")
        try:
            await self._page.goto(self.LOGIN_URL, wait_until="domcontentloaded", timeout=12000)

            # Çerez onayını geç
            try:
                cookie_btn = await self._page.query_selector('button:has-text("Hepsini Kabul Et")')
                if cookie_btn:
                    await cookie_btn.click()
                    await self._page.wait_for_timeout(300)
            except Exception:
                pass

            # Kullanıcı adı ve şifre doldur
            await self._page.fill('input[name="loginUsername"]', self.username)
            await self._page.fill('input[name="loginPassword"]', self.password)
            await self._page.click('button[type="submit"]')

            for _ in range(15):
                await asyncio.sleep(0.25)
                if "login" not in (self._page.url or "").lower():
                    break

            if "login" not in (self._page.url or "").lower():
                await self._context.storage_state(path=str(FARMAZON_STATE_FILE))
                self.is_logged_in = True
                self._is_logged_in = True
                self._last_login_fail_ts = 0.0
                print("[Farmazon] Giriş başarılı, oturum kaydedildi.")
                return True
            else:
                import time
                self._last_login_fail_ts = time.time()
                print(f"[Farmazon] Giriş başarısız, URL: {self._page.url}")
                return False

        except Exception as e:
            import time
            self._last_login_fail_ts = time.time()
            print(f"[Farmazon] Giriş sırasında hata oluştu: {e}")
            return False

    async def search_product(self, query: str) -> List[DepoUrunSarti]:
        """Farmazon'da barkod veya kelime ile ürün ara."""
        import time
        clean_q = query.strip()
        try:
            async with self._lock:
                if not self.is_logged_in:
                    if self._last_login_fail_ts and (time.time() - self._last_login_fail_ts) < 120.0:
                        return []
                    ok = await self.login()
                    if not ok:
                        return []

                print(f"[Farmazon] '{clean_q}' sorgulanıyor...")
                data = None
                cur_url = (self._page.url or "").lower()
                if "farmazon.com.tr" not in cur_url or "login" in cur_url:
                    await self._page.goto("https://www.farmazon.com.tr/categories/", wait_until="commit", timeout=6000)

                try:
                    data = await self._page.evaluate("""async (term) => {
                        let token = "";
                        try {
                            const a = localStorage.getItem("AuthData_1");
                            if (a) token = JSON.parse(a).token;
                        } catch(e) {}
                        if (!token) return { _no_token: true };
                        try {
                            const resp = await fetch("https://lab.farmazon.com.tr/api/v1/Products/GetCategoryProductsByFilters", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json",
                                    "Accept": "application/json",
                                    "Authorization": "Bearer " + token
                                },
                                body: JSON.stringify({ categoryIds: null, page: 1, keyword: term })
                            });
                            if (resp.status === 401 || resp.status === 403) return { _unauthorized: true };
                            if (!resp.ok) return null;
                            const j = await resp.json();
                            return { _ok: true, ...(j || {}) };
                        } catch(err) {
                            return null;
                        }
                    }""", clean_q)
                except Exception:
                    data = None

                if isinstance(data, dict) and (data.get("_no_token") or data.get("_unauthorized")):
                    self.is_logged_in = False
                    self._is_logged_in = False
                    if FARMAZON_STATE_FILE.exists():
                        try:
                            FARMAZON_STATE_FILE.unlink()
                        except Exception:
                            pass
                    if await self.login():
                        data = await self._page.evaluate("""async (term) => {
                            let token = "";
                            try {
                                const a = localStorage.getItem("AuthData_1");
                                if (a) token = JSON.parse(a).token;
                            } catch(e) {}
                            if (!token) return null;
                            const resp = await fetch("https://lab.farmazon.com.tr/api/v1/Products/GetCategoryProductsByFilters", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json",
                                    "Accept": "application/json",
                                    "Authorization": "Bearer " + token
                                },
                                body: JSON.stringify({ categoryIds: null, page: 1, keyword: term })
                            });
                            if (!resp.ok) return null;
                            const j = await resp.json();
                            return { _ok: true, ...(j || {}) };
                        }""", clean_q)

                if not data or not data.get("_ok"):
                    return []

            result = data.get("result") or {}
            products = result.get("products") or []
            if not products:
                return []

            # Barkod Filtreleme: Aranan ürünle eşleşmeyen yabancı ürün tekliflerini kesinlikle filtrele
            matched_products = []
            if clean_q.isdigit() and len(clean_q) >= 8:
                for p in products:
                    p_bc = str(p.get("barcode") or "").strip()
                    if p_bc == clean_q:
                        matched_products.append(p)
                if not matched_products and products:
                    # Farmazon product objesinde barkodu boş döner; keyword=barkod aramasında doğrudan eşleşen ürünü döner
                    cat_item = catalog.get_by_barcode(clean_q)
                    target_name_lower = (cat_item.get("name") if cat_item else "").replace("İ", "i").replace("I", "i").lower()
                    if target_name_lower:
                        first_p_name = str(products[0].get("name") or "").replace("İ", "i").replace("I", "i").lower()
                        main_words = [w for w in target_name_lower.split() if len(w) > 3 and not w.isdigit()]
                        if any(w in first_p_name for w in main_words) or len(products) <= 3:
                            matched_products = products[:2]
                    elif len(products) <= 5:
                        matched_products = products[:2]
            else:
                matched_products = products[:3]

            if not matched_products:
                return []

            products = matched_products

            # Ürünlerin tüm satıcı tekliflerini ve MİAD bilgilerini çek
            pids = [str(p.get("id")) for p in products[:5] if p.get("id")]
            listing_data = {}
            if pids:
                try:
                    listing_data = await self._page.evaluate("""async (productIds) => {
                        let token = "";
                        try {
                            const authRaw = localStorage.getItem("AuthData_1");
                            if (authRaw) {
                                const authObj = JSON.parse(authRaw);
                                token = authObj.token || "";
                            }
                        } catch(e) {}

                        const res = {};
                        await Promise.all(productIds.map(async (pid) => {
                            try {
                                const headers = { 'Accept': 'application/json' };
                                if (token) headers['Authorization'] = 'Bearer ' + token;
                                const resp = await fetch('https://lab.farmazon.com.tr/api/v1/Products/GetProductListings?productID=' + pid, {
                                    headers: headers
                                });
                                const data = await resp.json();
                                const rawListings = (data && data.result && data.result.listings) ? data.result.listings : [];
                                
                                let bestMiad = null;
                                const offers = [];

                                for (const l of rawListings) {
                                    let expStr = "";
                                    if (l.expiration) {
                                        const d = new Date(l.expiration);
                                        const month = String(d.getMonth() + 1).padStart(2, '0');
                                        const year = d.getFullYear();
                                        expStr = `${month}/${year}`;
                                    }
                                    if (!bestMiad && expStr) {
                                        bestMiad = expStr;
                                    }
                                    const seller = l.seller || {};
                                    const ratings = seller.ratings || {};
                                    const freeLimit = parseFloat(seller.freeCargoLimit);

                                    offers.push({
                                        ilan_id: String(l.id || ""),
                                        satici: seller.username || "Farmazon Eczanesi",
                                        fiyat_kdvli: parseFloat(l.price) || 0.0,
                                        fiyat_kdvsiz: parseFloat(l.price) || 0.0,
                                        stok: parseInt(l.stock) || 0,
                                        miad: expStr || "-",
                                        puan: (ratings && ratings.rate !== undefined) ? parseFloat(ratings.rate) : null,
                                        min_tutar: (seller && seller.minOrderAmount) ? parseFloat(seller.minOrderAmount) : null,
                                        ucretsiz_kargo: (!isNaN(freeLimit) && freeLimit > 0 && freeLimit < 50000) ? freeLimit : null,
                                        kargo: seller.selectedShipper || "",
                                        aciklama: l.description || l.mf || ""
                                    });
                                }

                                res[pid] = {
                                    miad: bestMiad,
                                    offers: offers
                                };
                            } catch(e) {
                                res[pid] = { miad: null, offers: [] };
                            }
                        }));
                        return res;
                    }""", pids)
                except Exception as e:
                    print(f"[Farmazon] Teklif çekme hatası: {e}")

            # Ön KDV tespiti (Katalogdan veya genel)
            cat_info = catalog.get_by_barcode(query)
            initial_vat = float(cat_info["vat"]) if (cat_info and cat_info.get("vat") and float(cat_info["vat"]) > 0) else None

            supplement_keywords = [
                "takviye edici", "gida takviyesi", "gıda takviyesi", "omega", "balık yağı", "balik yagi",
                "vitamin", "mineral", "multivitamin", "kolajen", "kollajen", "collagen",
                "magnezyum", "magnesium", "çinko", "zinc", "probiyotik", "probiotik",
                "d3", "b12", "c vitamini", "ester-c", "sambucol", "solgar", "ocean",
                "venatura", "zade vital", "supradyn", "pharmaton", "vefail", "coenzyme", "koenzim",
                "krill", "propolis", "kara mürver", "melatonin", "glukozamin", "glucosamine"
            ]

            # Tüm ürünlerden gelen satıcı tekliflerini tek bir havuzda birleştir
            all_offers = []
            seen_ilan_ids = set()
            best_min_price = 999999.0
            total_listing_count = 0

            # İsim tespiti: "Eski Ambalaj" veya "Puansız" içermeyen orijinal adı tercih et
            clean_names = [str(p.get("name") or "") for p in products if not any(w in str(p.get("name") or "").lower() for w in ["eski ambalaj", "puansız", "puansiz"])]
            canonical_name = clean_names[0] if clean_names else str(products[0].get("name") or "")

            # KDV Tespiti: Katalog -> İsim analizi -> %10
            kdv_orani = 10.0
            if initial_vat:
                kdv_orani = initial_vat
            else:
                name_brand = f"{canonical_name}".lower()
                if any(kw in name_brand for kw in supplement_keywords):
                    kdv_orani = 1.0

            for p in products[:6]:
                p_name = str(p.get("name") or "")
                min_p = float(p.get("listingMinPrice") or 0.0)
                if min_p > 0 and min_p < best_min_price:
                    best_min_price = min_p
                total_listing_count += int(p.get("listingCount") or 0)
                prod_id = str(p.get("id") or "")
                
                pid_info = listing_data.get(prod_id) or {}
                raw_offers = pid_info.get("offers") or []

                variant_tag = ""
                if "eski ambalaj" in p_name.lower():
                    variant_tag = "[Eski Ambalaj]"
                elif "puansız" in p_name.lower() or "puansiz" in p_name.lower():
                    variant_tag = "[Puansız]"

                for off in raw_offers:
                    ilan_id = off.get("ilan_id")
                    if ilan_id and ilan_id in seen_ilan_ids:
                        continue
                    if ilan_id:
                        seen_ilan_ids.add(ilan_id)

                    # Farmazon'da listelenen fiyat KDV DAHİL fiyattır.
                    raw_val = float(off.get("fiyat_kdvli") or off.get("fiyat_kdvsiz") or off.get("fiyat") or 0.0)
                    if raw_val <= 0:
                        continue
                    f_kdvli = round(raw_val, 2)
                    f_kdvsiz = round(f_kdvli / (1.0 + (kdv_orani / 100.0)), 2)
                    
                    full_desc = f"{variant_tag} {off.get('aciklama', '')}".strip()
                    all_offers.append({
                        **off,
                        "fiyat": f_kdvli,
                        "fiyat_kdvli": f_kdvli,
                        "fiyat_kdvsiz": f_kdvsiz,
                        "aciklama": full_desc
                    })

            all_offers.sort(key=lambda x: x["fiyat_kdvsiz"])

            has_stock = len(all_offers) > 0 or (total_listing_count > 0 and best_min_price < 999999.0)
            stok_durumu = StokDurumu.VAR if has_stock else StokDurumu.YOK

            if all_offers:
                net_birim = all_offers[0]["fiyat_kdvsiz"]
                net_kdvli = all_offers[0]["fiyat_kdvli"]
                extracted_miad = all_offers[0]["miad"] if all_offers[0]["miad"] != "-" else None
            elif best_min_price < 999999.0:
                net_kdvli = round(best_min_price, 2)
                net_birim = round(net_kdvli / (1.0 + (kdv_orani / 100.0)), 2)
                extracted_miad = None
            else:
                net_birim = 0.0
                net_kdvli = 0.0
                extracted_miad = None

            teklif_sayisi = len(all_offers) if all_offers else total_listing_count
            notu = f"{teklif_sayisi} Eczane Satışta (Farklı Fiyatlar)"
            if extracted_miad:
                notu += f" • Miad: {extracted_miad}"

            found_barcode = str(products[0].get("barcode") or products[0].get("gtin") or products[0].get("ean") or query).strip()

            sarti = DepoUrunSarti(
                depo=DepoKodu.FARMAZON,
                depo_adi=self.depo_adi,
                barkod=found_barcode,
                urun_id=str(products[0].get("id") or ""),
                urun_adi=canonical_name,
                stok_durumu=stok_durumu,
                stok_adedi=teklif_sayisi,
                depocu_satis_fiyati=net_birim,
                perakende_satis_fiyati=round(net_birim * 1.35, 2),
                kdv_orani=kdv_orani,
                mf_metni="PAZARYERİ",
                kademeler=[],
                ticari_iskonto=0.0,
                vade_gun=0,
                net_birim_maliyet=net_birim,
                net_birim_maliyet_kdvli=net_kdvli,
                toplam_indirim_yuzdesi=0.0,
                miad=extracted_miad,
                ozel_kampanya_notu=notu,
                pazaryeri_teklifleri=all_offers
            )
            return [sarti]

        except Exception as e:
            print(f"[Farmazon] Arama hatası ({query}): {e}")
            return []

    async def close(self):
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
