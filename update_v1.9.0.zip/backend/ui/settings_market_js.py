# -*- coding: utf-8 -*-
SETTINGS_MARKET_JS = """        // ================= Ayarlar & Şifre Yönetimi =================
        function togglePasswordVisibility(inputId, btn) {
            const input = document.getElementById(inputId);
            if (!input) return;
            const icon = btn ? btn.querySelector('i') : null;
            if (input.classList.contains('masked-pwd')) {
                const isUnmasked = input.classList.toggle('unmasked');
                if (icon) {
                    icon.className = isUnmasked
                        ? 'fa-solid fa-eye-slash text-slate-700'
                        : 'fa-solid fa-eye text-slate-400';
                }
            } else if (input.type === 'password') {
                input.type = 'text';
                if (icon) icon.className = 'fa-solid fa-eye-slash text-slate-700';
            } else {
                input.type = 'password';
                if (icon) icon.className = 'fa-solid fa-eye text-slate-400';
            }
        }

        // Google Chrome Şifre Yöneticisinin arama çubuklarında şifre/kullanıcı adı önermesini %100 engelleyen koruma
        (function enforceAntiPasswordAutofill() {
            function sanitizeInputs() {
                document.querySelectorAll('input[type="password"]').forEach(el => {
                    el.setAttribute('type', 'text');
                    el.classList.add('masked-pwd');
                    el.setAttribute('autocomplete', 'off');
                    el.setAttribute('data-lpignore', 'true');
                    el.setAttribute('data-1p-ignore', 'true');
                    el.setAttribute('data-bwignore', 'true');
                    el.setAttribute('data-form-type', 'other');
                    el.setAttribute('spellcheck', 'false');
                });
                const searchIds = ['searchInput', 'smartOrderSearchInput', 'marketSearchInput', 'criticalFilterInput', 'quickPinYokInput', 'etModalSearchInput', 'etrModalSearchInput', 'etrCampUrunSearchInput', 'etrMdlProdSearch', 'etrMyQueryInput'];
                searchIds.forEach(id => {
                    const el = document.getElementById(id);
                    if (el) {
                        if (el.getAttribute('type') !== 'search') el.setAttribute('type', 'search');
                        el.setAttribute('role', 'searchbox');
                        el.setAttribute('autocomplete', 'off');
                        el.setAttribute('autocorrect', 'off');
                        el.setAttribute('autocapitalize', 'off');
                        el.setAttribute('spellcheck', 'false');
                        el.setAttribute('data-lpignore', 'true');
                        el.setAttribute('data-1p-ignore', 'true');
                        el.setAttribute('data-bwignore', 'true');
                        el.setAttribute('data-form-type', 'other');
                    }
                });
            }
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', sanitizeInputs);
            } else {
                sanitizeInputs();
            }
            setTimeout(sanitizeInputs, 400);
        })();

        // ================= Ayarlar Tab & TRIA Oracle Entegrasyonu (EdaPrim Stili) =================
        // ================= Ayarlar Tab & TRIA Oracle Entegrasyonu (EdaPrim Stili) =================
        window.isAdminSettingsUnlocked = false;
        window.pendingAdminSubTab = 'dermo';

        function unlockAdminSettingsPanel() {
            const pwdInput = document.getElementById('adminSettingsPwdInput');
            const errEl = document.getElementById('adminSettingsLockError');
            const lockBox = document.getElementById('adminSettingsLockBox');
            const unlockedArea = document.getElementById('adminSettingsUnlockedArea');
            const val = (pwdInput?.value || '').trim();

            if (val !== '1986cagri1986') {
                if (errEl) {
                    errEl.innerHTML = '<i class="fa-solid fa-circle-exclamation mr-1"></i>Hatalı yönetici şifresi! Lütfen tekrar deneyin.';
                    errEl.classList.remove('hidden');
                }
                if (pwdInput) {
                    pwdInput.value = '';
                    pwdInput.focus();
                }
                return;
            }

            window.isAdminSettingsUnlocked = true;
            if (errEl) errEl.classList.add('hidden');
            if (pwdInput) pwdInput.value = '';
            if (lockBox) lockBox.classList.add('hidden');
            if (unlockedArea) unlockedArea.classList.remove('hidden');

            fetchCatalogStats();
            loadGithubPortalConfig();
            switchAdminSubTab(window.pendingAdminSubTab || 'dermo');
            showToast('Yönetici Paneli Açıldı', 'Gelişmiş sistem ve katalog araçlarına erişim sağlandı.', 'success');
        }

        function lockAdminSettingsPanel() {
            window.isAdminSettingsUnlocked = false;
            const pwdInput = document.getElementById('adminSettingsPwdInput');
            const errEl = document.getElementById('adminSettingsLockError');
            const lockBox = document.getElementById('adminSettingsLockBox');
            const unlockedArea = document.getElementById('adminSettingsUnlockedArea');
            if (pwdInput) pwdInput.value = '';
            if (errEl) errEl.classList.add('hidden');
            if (lockBox) lockBox.classList.remove('hidden');
            if (unlockedArea) unlockedArea.classList.add('hidden');
        }

        function switchAdminSubTab(subTab) {
            window.pendingAdminSubTab = subTab || 'dermo';
            const btnDermo = document.getElementById('adminSubBtnDermo');
            const btnKatalog = document.getElementById('adminSubBtnKatalog');
            const btnGithub = document.getElementById('adminSubBtnGithub');
            const contentDermo = document.getElementById('tabContentDermo');
            const contentKatalog = document.getElementById('tabContentKatalog');
            const contentGithub = document.getElementById('adminSubContentGithub');

            const inactiveCls = 'px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 transition flex items-center gap-1.5 cursor-pointer';
            if (btnDermo) btnDermo.className = inactiveCls;
            if (btnKatalog) btnKatalog.className = inactiveCls;
            if (btnGithub) btnGithub.className = inactiveCls;

            if (contentDermo) contentDermo.classList.add('hidden');
            if (contentKatalog) contentKatalog.classList.add('hidden');
            if (contentGithub) contentGithub.classList.add('hidden');

            if (subTab === 'katalog') {
                if (btnKatalog) btnKatalog.className = 'px-3.5 py-2 rounded-xl text-xs font-bold bg-indigo-600 text-white shadow-sm transition flex items-center gap-1.5 cursor-pointer';
                if (contentKatalog) contentKatalog.classList.remove('hidden');
                fetchCatalogStats();
            } else if (subTab === 'github') {
                if (btnGithub) btnGithub.className = 'px-3.5 py-2 rounded-xl text-xs font-bold bg-cyan-600 text-white shadow-sm transition flex items-center gap-1.5 cursor-pointer';
                if (contentGithub) contentGithub.classList.remove('hidden');
                loadGithubPortalConfig();
            } else {
                if (btnDermo) btnDermo.className = 'px-3.5 py-2 rounded-xl text-xs font-bold bg-pink-600 text-white shadow-sm transition flex items-center gap-1.5 cursor-pointer';
                if (contentDermo) contentDermo.classList.remove('hidden');
            }
        }

        function switchSettingsTab(tabName) {
            if (tabName === 'dermo' || tabName === 'katalog') {
                window.pendingAdminSubTab = tabName;
                tabName = 'yonetici';
            }

            const btnBotanik = document.getElementById('tabBtnBotanik');
            const btnTria = document.getElementById('tabBtnTria');
            const btnTebeos = document.getElementById('tabBtnTebeos');
            const btnDepolar = document.getElementById('tabBtnDepolar');
            const btnGuncelleme = document.getElementById('tabBtnGuncelleme');
            const btnYonetici = document.getElementById('tabBtnYonetici');
            const contentBotanik = document.getElementById('tabContentBotanik');
            const contentTria = document.getElementById('tabContentTria');
            const contentTebeos = document.getElementById('tabContentTebeos');
            const contentDepolar = document.getElementById('tabContentDepolar');
            const contentGuncelleme = document.getElementById('tabContentGuncelleme');
            const contentYonetici = document.getElementById('tabContentYonetici');
            const modalTitle = document.getElementById('settingsModalTitle');
            const modalDesc = document.getElementById('settingsModalDesc');
            const modalIcon = document.getElementById('settingsModalIcon');

            const activeOto = (window.activeOtomasyon || 'BOTANIK').toUpperCase();

            // Hepsini pasife çek (aktif olmayan otomasyon sekmelerini gizli tut)
            [
                { el: btnBotanik, hide: activeOto !== 'BOTANIK' },
                { el: btnTria, hide: activeOto !== 'TRIA' },
                { el: btnTebeos, hide: activeOto !== 'TEBEOS' },
                { el: btnDepolar, hide: false },
                { el: btnGuncelleme, hide: false }
            ].forEach(item => {
                if (item.el) {
                    item.el.className = (item.hide ? 'hidden ' : 'flex ') + 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 items-center space-x-2 transition cursor-pointer shrink-0';
                }
            });
            if (btnYonetici) {
                btnYonetici.className = 'ml-auto pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-400 hover:text-slate-800 flex items-center space-x-1.5 transition cursor-pointer shrink-0';
            }

            if (contentBotanik) contentBotanik.classList.add('hidden');
            if (contentTria) contentTria.classList.add('hidden');
            if (contentTebeos) contentTebeos.classList.add('hidden');
            if (contentDepolar) contentDepolar.classList.add('hidden');
            if (contentGuncelleme) contentGuncelleme.classList.add('hidden');
            if (contentYonetici) contentYonetici.classList.add('hidden');

            if (tabName === 'botanik') {
                if (btnBotanik) btnBotanik.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-emerald-600 text-emerald-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentBotanik) contentBotanik.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'Botanik Eczane Otomasyonu (MS SQL) Bağlantı & Şifre Ayarları';
                if (modalDesc) modalDesc.innerText = 'Botanik SQL Server adı, veritabanı adı, kullanıcı ve şifresini buradan yapılandırıp canlı ping testi yapabilirsiniz.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-leaf text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400';
                }
            } else if (tabName === 'tria') {
                if (btnTria) btnTria.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-amber-600 text-amber-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentTria) contentTria.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'TRIA Eczane Veritabanı (Oracle) Bağlantı & Şifre Ayarları';
                if (modalDesc) modalDesc.innerText = 'Oracle sunucu IP, port, şema adı ve şifresini buradan yapılandırıp canlı ping testi yapabilirsiniz.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-database text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400';
                }
            } else if (tabName === 'tebeos') {
                if (btnTebeos) btnTebeos.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-sky-600 text-sky-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentTebeos) contentTebeos.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'TEBEOS Eczane Veritabanı (PostgreSQL) Bağlantı & Şifre Ayarları';
                if (modalDesc) modalDesc.innerText = 'TEBEOS PostgreSQL sunucu IP (Port 5454), veritabanı adı ve şifresini buradan yapılandırıp canlı ping testi yapabilirsiniz.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-mortar-pestle text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-400';
                }
            } else if (tabName === 'yonetici') {
                if (btnYonetici) btnYonetici.className = 'ml-auto pb-2.5 px-3.5 text-xs font-bold border-b-2 border-rose-600 text-rose-900 flex items-center space-x-1.5 transition cursor-pointer shrink-0';
                if (contentYonetici) contentYonetici.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'Sistem Yönetici Paneli (Şifre Korumalı)';
                if (modalDesc) modalDesc.innerText = 'Botanik kart birleştirme, katalog senkronizasyonu ve GitHub canlı dağıtım ayarları.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-user-shield text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-400/30 flex items-center justify-center text-rose-400';
                }
                if (window.isAdminSettingsUnlocked) {
                    switchAdminSubTab(window.pendingAdminSubTab || 'dermo');
                } else {
                    setTimeout(() => {
                        const pwdInput = document.getElementById('adminSettingsPwdInput');
                        if (pwdInput) pwdInput.focus();
                    }, 80);
                }
            } else if (tabName === 'guncelleme') {
                if (btnGuncelleme) btnGuncelleme.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-cyan-600 text-cyan-900 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentGuncelleme) contentGuncelleme.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'Otomatik Güncelleme & Lisans Yönetimi';
                if (modalDesc) modalDesc.innerText = 'Programın sürümünü ve kurumsal lisans durumunu kontrol edebilir, tek tıkla en son güncellemeleri yükleyebilirsiniz.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-cloud-arrow-down text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-400';
                }
                checkAppUpdate(false);
                loadLicenseStatus();
            } else {
                if (btnDepolar) btnDepolar.className = 'pb-2.5 px-3.5 text-xs font-bold border-b-2 border-emerald-600 text-emerald-800 flex items-center space-x-2 transition cursor-pointer shrink-0';
                if (contentDepolar) contentDepolar.classList.remove('hidden');
                if (modalTitle) modalTitle.innerText = 'Ecza Depoları & Pazaryeri Giriş Bilgileri';
                if (modalDesc) modalDesc.innerText = 'Alliance, Selçuk, Nevzat, İSKOOP, Ecza1 ve Farmazon resmi B2B giriş şifrelerinizi yönetin.';
                if (modalIcon) {
                    modalIcon.innerHTML = '<i class="fa-solid fa-truck-ramp-box text-lg"></i>';
                    modalIcon.className = 'w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400';
                }
            }
        }

        // ================= Otomatik Güncelleme & Lisans Yönetimi =================
        let lastCheckedUpdate = null;

        async function loadGithubPortalConfig() {
            try {
                const res = await fetch('/api/github-portal/config');
                const data = await res.json();
                const mInput = document.getElementById('cfg_update_manifest_url');
                if (mInput && data.manifest_url) mInput.value = data.manifest_url;
                const ownerEl = document.getElementById('ghPortalOwner');
                if (ownerEl && data.owner) ownerEl.value = data.owner;
                const repoEl = document.getElementById('ghPortalRepo');
                if (repoEl && data.repo) repoEl.value = data.repo;
                const verEl = document.getElementById('ghPortalNewVersion');
                if (verEl && data.next_version) verEl.value = data.next_version;
                const badgeEl = document.getElementById('ghPortalStatusBadge');
                const tokenEl = document.getElementById('ghPortalToken');
                if (data.has_token) {
                    if (badgeEl) {
                        badgeEl.innerText = 'GITHUB BAĞLI ✓';
                        badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30';
                    }
                    if (tokenEl) tokenEl.placeholder = `Kayıtlı (${data.token_preview})`;
                }
            } catch (e) {}
        }

        async function saveManifestUrlConfig() {
            const mInput = document.getElementById('cfg_update_manifest_url');
            const urlVal = (mInput?.value || '').trim();
            if (!urlVal) {
                showToast('Uyarı', 'Lütfen geçerli bir GitHub Manifest URL girin.', 'error');
                return;
            }
            try {
                const res = await fetch('/api/update/config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ manifest_url: urlVal, auto_update: true })
                });
                const data = await res.json();
                if (data.success) {
                    if (mInput && data.manifest_url) mInput.value = data.manifest_url;
                    showToast('Kaydedildi', 'Canlı güncelleme Manifest URL adresi güncellendi.', 'success');
                    checkAppUpdate(true);
                } else {
                    showToast('Hata', data.message || 'Kaydedilemedi.', 'error');
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function verifyAndSetupGithubPortal() {
            const btn = document.getElementById('btnVerifyGhPortal');
            const resBox = document.getElementById('ghPortalResultText');
            const badgeEl = document.getElementById('ghPortalStatusBadge');
            const token = (document.getElementById('ghPortalToken')?.value || '').trim();
            const owner = (document.getElementById('ghPortalOwner')?.value || '').trim();
            const repo = (document.getElementById('ghPortalRepo')?.value || 'depo-updates').trim();

            if (btn) { btn.disabled = true; btn.innerText = 'Bağlanıyor...'; }
            if (resBox) resBox.innerText = 'GitHub API ile depo kontrol ediliyor / oluşturuluyor...';

            try {
                const res = await fetch('/api/github-portal/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ token, owner, repo })
                });
                const data = await res.json();
                if (data.success) {
                    const ownerEl = document.getElementById('ghPortalOwner');
                    if (ownerEl && data.owner) ownerEl.value = data.owner;
                    const mInput = document.getElementById('cfg_update_manifest_url');
                    if (mInput && data.manifest_url) mInput.value = data.manifest_url;
                    if (badgeEl) {
                        badgeEl.innerText = 'GITHUB BAĞLI ✓';
                        badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30';
                    }
                    if (resBox) resBox.innerText = `✅ ${data.message} (${data.manifest_url})`;
                    showToast('GitHub Portalı Hazır', data.message, 'success');
                } else {
                    if (resBox) resBox.innerText = `❌ ${data.message}`;
                    showToast('GitHub Hatası', data.message || 'Bağlantı kurulamadı.', 'error');
                }
            } catch (e) {
                if (resBox) resBox.innerText = `❌ ${e.message}`;
                showToast('Hata', e.message, 'error');
            } finally {
                if (btn) { btn.disabled = false; btn.innerText = 'Bağla'; }
            }
        }

        async function publishLiveReleaseFromPortal() {
            const btn = document.getElementById('btnPublishGhPortal');
            const resBox = document.getElementById('ghPortalResultText');
            const token = (document.getElementById('ghPortalToken')?.value || '').trim();
            const owner = (document.getElementById('ghPortalOwner')?.value || '').trim();
            const repo = (document.getElementById('ghPortalRepo')?.value || 'depo-updates').trim();
            const version = (document.getElementById('ghPortalNewVersion')?.value || '').trim();
            const changelog = (document.getElementById('ghPortalChangelog')?.value || '').trim();

            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Paketreleniyor & Yayınlanıyor...</span>`;
            }
            if (resBox) resBox.innerText = 'Güncelleme paketi hazırlanıyor, GitHub ve yerel ağa gönderiliyor...';

            try {
                const res = await fetch('/api/github-portal/publish', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ token, owner, repo, version, changelog })
                });
                const data = await res.json();
                if (data.success) {
                    if (resBox) resBox.innerText = `✅ v${data.version} yayınlandı (${data.size_kb} KB) | ${data.git_message}`;
                    showToast(`v${data.version} Canlı Yayınlandı!`, data.git_message, 'success');
                    loadGithubPortalConfig();
                    checkAppUpdate(false);
                } else {
                    if (resBox) resBox.innerText = `❌ ${data.message}`;
                    showToast('Yayınlama Hatası', data.message || 'Paket yayınlanamadı.', 'error');
                }
            } catch (e) {
                if (resBox) resBox.innerText = `❌ ${e.message}`;
                showToast('Hata', e.message, 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = `<i class="fa-solid fa-rocket"></i><span>GitHub + Tüm Bilgisayarlara Canlı Yayınla</span>`;
                }
            }
        }

        window.currentLicenseStatus = null;
        window.userOpenedLicenseModalManually = false;

        window.isLicenseRestricted = function() {
            return !!(window.currentLicenseStatus && window.currentLicenseStatus.valid === false);
        };

        window.checkLicenseBeforeAction = function(featureLabel = 'Bu özellik') {
            if (!window.isLicenseRestricted()) return true;
            const st = window.currentLicenseStatus || {};
            const reason = st.message || 'Lisans süreniz dolmuş veya yönetici tarafından kısıtlanmıştır.';
            showToast(`🔒 ${featureLabel} Kilitli (Lisans Gerekli)`, reason, 'error');
            openLicenseActivationModalFromBanner();
            return false;
        };

        function openLicenseActivationModalFromBanner() {
            window.userOpenedLicenseModalManually = true;
            const lockModal = document.getElementById('licenseLockOverlayModal');
            const closeBtn = document.getElementById('lockModalCloseRestrictedBtn');
            const st = window.currentLicenseStatus || {};
            if (closeBtn) {
                if (st.unactivated) {
                    closeBtn.classList.add('hidden');
                } else {
                    closeBtn.classList.remove('hidden');
                }
            }
            if (lockModal) {
                lockModal.style.display = 'flex';
                lockModal.classList.remove('hidden');
            }
        }

        function closeLicenseModalToRestrictedMode() {
            const st = window.currentLicenseStatus || {};
            if (st.unactivated) {
                showToast('Lisans Anahtarı Gerekli', 'İlk kurulumda programı açabilmek için geçerli bir FR-... veya EDP-... lisans anahtarı girmelisiniz.', 'error');
                return;
            }
            window.userOpenedLicenseModalManually = false;
            const lockModal = document.getElementById('licenseLockOverlayModal');
            if (lockModal) {
                lockModal.style.display = 'none';
                lockModal.classList.add('hidden');
            }
        }

        function applyLicenseStatusToUI(data) {
            if (!data) return;
            const prevValid = window.currentLicenseStatus ? window.currentLicenseStatus.valid : null;
            window.currentLicenseStatus = data;

            const titleEl = document.getElementById('licPharmacyTitle');
            const badgeEl = document.getElementById('licStatusBadge');
            const hwidEl = document.getElementById('licMyHwid');
            const expEl = document.getElementById('licExpiresAt');
            const daysEl = document.getElementById('licDaysLeftText');
            const keyInput = document.getElementById('licKeyInput');
            const lockKeyInput = document.getElementById('lockModalKeyInput');
            const glnSettingsInput = document.getElementById('licGlnLookupInput');
            const chkAtEl = document.getElementById('licRemoteCheckedAt');

            if (hwidEl && data.my_hwid) hwidEl.innerText = data.my_hwid;
            if (keyInput && data.license_key) keyInput.value = data.license_key;
            if (lockKeyInput && data.license_key) lockKeyInput.value = data.license_key;
            if (glnSettingsInput && data.gln_no && document.activeElement !== glnSettingsInput) glnSettingsInput.value = data.gln_no;
            if (titleEl && data.pharmacy_name) titleEl.innerText = `${data.pharmacy_name} (${data.plan || 'KURUMSAL'})`;
            if (expEl) expEl.innerText = data.expires_at || '--';
            if (chkAtEl) {
                chkAtEl.innerText = data.remote_checked_at ? `Son Online Kontrol: ${data.remote_checked_at}` : '';
            }
            if (daysEl && data.days_left !== undefined) {
                if (data.unactivated) {
                    daysEl.innerText = 'Lisans Anahtarı Girilmedi';
                    daysEl.className = 'text-[11px] text-rose-600 font-bold';
                } else if (data.suspended) {
                    daysEl.innerText = 'Yönetici Tarafından Kısıtlandı (Askıda)';
                    daysEl.className = 'text-[11px] text-rose-600 font-bold';
                } else {
                    daysEl.innerText = data.days_left >= 0 ? `${data.days_left} gün kaldı` : `Süresi Doldu (${Math.abs(data.days_left)} gün geçti)`;
                    daysEl.className = data.days_left > 15 ? 'text-[11px] text-emerald-700 font-bold' : 'text-[11px] text-rose-600 font-bold';
                }
            }
            if (badgeEl) {
                if (data.valid) {
                    badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300';
                    badgeEl.innerText = 'LİSANS AKTİF';
                } else if (data.unactivated) {
                    badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300';
                    badgeEl.innerText = 'ANAHTAR BEKLENİYOR';
                } else if (data.suspended) {
                    badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-300';
                    badgeEl.innerText = 'ASKIDA (KISITLI MOD)';
                } else {
                    badgeEl.className = 'text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-300';
                    badgeEl.innerText = 'SÜRESİ DOLDU (KISITLI MOD)';
                }
            }

            // 1. Üstteki Kalıcı Lisans Kısıtlama Bandı (#licenseRestrictedTopBanner) ve Yaklaşan Bitiş Bandı (#licenseExpiringTopBanner)
            const restrictedBanner = document.getElementById('licenseRestrictedTopBanner');
            const expiringBanner = document.getElementById('licenseExpiringTopBanner');
            const bannerStatusPill = document.getElementById('licBannerStatusPill');
            const bannerDesc = document.getElementById('licBannerDesc');
            const expBannerTxt = document.getElementById('licExpiringBannerText');

            if (restrictedBanner) {
                if (data.valid === false && !data.unactivated) {
                    restrictedBanner.classList.remove('hidden');
                    if (bannerStatusPill) {
                        bannerStatusPill.innerText = data.suspended ? 'ASKIDA (KISITLI)' : `SÜRESİ DOLDU (${data.expires_at || ''})`;
                    }
                    if (bannerDesc) {
                        bannerDesc.innerHTML = `${data.message || 'Lisansınız aktif değildir.'} <strong>(Depo Sorgulama, Sepete Ekleme, Toplu Sipariş ve MF Asistanı Kilitli)</strong>`;
                    }
                } else {
                    restrictedBanner.classList.add('hidden');
                }
            }

            if (expiringBanner) {
                if (data.valid === true && data.days_left !== undefined && data.days_left >= 0 && data.days_left <= 15) {
                    expiringBanner.classList.remove('hidden');
                    if (expBannerTxt) {
                        expBannerTxt.innerText = `⚠️ Kurumsal lisansınızın (${data.pharmacy_name || 'Eczane'}) bitmesine ${data.days_left} gün kaldı (Bitiş: ${data.expires_at}). Süre bittiğinde Depo Sorgulama, Sepete Ekleme, Toplu Sipariş ve MF Asistanı özellikleri kısıtlanacaktır.`;
                    }
                } else {
                    expiringBanner.classList.add('hidden');
                }
            }

            // 2. Tam Ekran Kilit Modalı:
            // - İlk kurulumda (unactivated === true) ZORUNLU tam ekran kilit açılır (anahtar girilmeden program hiç açılmaz).
            // - Süre dolumu / ASKIDA durumunda ise program açık kalır (Özellik Kısıtlama Modu); modal sadece kullanıcı butona tıklarsa açılır.
            const lockModal = document.getElementById('licenseLockOverlayModal');
            const closeBtn = document.getElementById('lockModalCloseRestrictedBtn');
            const autoRegSection = document.getElementById('lockModalAutoRegisterSection');
            if (lockModal) {
                const lockBadge = document.getElementById('lockModalStatusBadge');
                const lockPharm = document.getElementById('lockModalPharmacyName');
                const lockReason = document.getElementById('lockModalReasonBox');
                const lockHwid = document.getElementById('lockModalHwid');

                if (lockBadge) {
                    lockBadge.innerText = data.unactivated ? 'YENİ ECZANE KAYDI — 30 GÜN OTOMATİK LİSANS' : (data.suspended ? 'ASKIDA (KISITLI MOD)' : 'SÜRESİ DOLDU (KISITLI MOD)');
                    lockBadge.className = data.unactivated
                        ? 'text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-emerald-400 text-slate-950'
                        : 'text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-rose-500 text-white';
                }
                if (lockPharm) lockPharm.innerText = data.pharmacy_name || 'Farma Radar Eczane Sistemi';
                if (lockReason) {
                    lockReason.innerText = data.unactivated
                        ? 'Hoş geldiniz! Eczane GLN, Eczane Adı ve Cep Telefonu numaranızı girerek 30 Günlük Otomatik Lisansınızı hemen tanımlayabilirsiniz.'
                        : (data.message || 'Lisans süreniz dolmuş veya yönetici tarafından kısıtlanmıştır.');
                    lockReason.className = data.unactivated
                        ? 'p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 text-xs font-bold leading-relaxed'
                        : 'p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-bold leading-relaxed';
                }
                if (lockHwid && data.my_hwid) lockHwid.innerText = data.my_hwid;
                if (autoRegSection) {
                    if (data.unactivated) {
                        autoRegSection.classList.remove('hidden');
                        preloadRegistrationModalCredentials();
                    } else {
                        autoRegSection.classList.add('hidden');
                    }
                }

                if (data.valid === false && data.unactivated) {
                    if (closeBtn) closeBtn.classList.add('hidden');
                    lockModal.style.display = 'flex';
                    lockModal.classList.remove('hidden');
                } else if (data.valid === false && window.userOpenedLicenseModalManually) {
                    if (closeBtn) closeBtn.classList.remove('hidden');
                    lockModal.style.display = 'flex';
                    lockModal.classList.remove('hidden');
                } else {
                    window.userOpenedLicenseModalManually = false;
                    lockModal.style.display = 'none';
                    lockModal.classList.add('hidden');
                }
            }

            // 3. Lisans durumu değiştiyse (Aktif <-> Kısıtlı) açık tabloları anında yeniden çiz
            if (prevValid !== data.valid) {
                if (typeof renderCriticalList === 'function') {
                    try { renderCriticalList(); } catch (e) {}
                }
                if (typeof renderSmartOrderTable === 'function') {
                    try { renderSmartOrderTable(); } catch (e) {}
                }
                if (prevValid === false && data.valid === true) {
                    if (typeof loadCriticalStock === 'function') {
                        try { loadCriticalStock(true); } catch (e) {}
                    }
                    if (window.smartOrderLoadedOnce && typeof loadSmartOrderList === 'function') {
                        try { loadSmartOrderList(true); } catch (e) {}
                    }
                }
            }
        }

        async function loadLicenseStatus(forceCloud = false) {
            try {
                const res = await fetch(`/api/license/status?force=${forceCloud ? 'true' : 'false'}`);
                const data = await res.json();
                applyLicenseStatusToUI(data);
                return data;
            } catch (e) {
                return null;
            }
        }

        async function syncLicenseWithCloud(manualClick = false) {
            const icon = document.getElementById('syncLicCloudIcon');
            if (icon) icon.className = 'fa-solid fa-spinner fa-spin';
            try {
                const res = await fetch('/api/license/sync', { method: 'POST' });
                const data = await res.json();
                applyLicenseStatusToUI(data);
                if (manualClick) {
                    if (data.valid) {
                        showToast('Online Lisans Doğrulandı', `${data.pharmacy_name} — Bitiş: ${data.expires_at} (${data.days_left} gün kaldı)`, 'success');
                    } else {
                        showToast('Lisans Kısıtlaması Aktif', data.message || 'Lisansınız aktif değil.', 'error');
                    }
                }
            } catch (e) {
                if (manualClick) showToast('Bağlantı Hatası', e.message, 'error');
            } finally {
                if (icon) icon.className = 'fa-solid fa-cloud-arrow-down';
            }
        }

        async function activateLicenseFromLockModal() {
            const inp = document.getElementById('lockModalKeyInput');
            const keyVal = (inp?.value || '').trim();
            if (!keyVal) {
                showToast('Uyarı', 'Lütfen FR-... veya EDP-... ile başlayan lisans anahtarınızı girin.', 'error');
                return;
            }
            const mainInp = document.getElementById('licKeyInput');
            if (mainInp) mainInp.value = keyVal;
            await activateNewLicense();
        }

        window._regModalCredsPreloaded = false;
        window._loadedRegModalCredentials = null;

        async function preloadRegistrationModalCredentials() {
            if (window._regModalCredsPreloaded) return;
            try {
                const res = await fetch('/api/settings/credentials');
                if (!res.ok) return;
                const c = await res.json();
                window._loadedRegModalCredentials = c;
                window._regModalCredsPreloaded = true;

                const setIfEmpty = (id, val) => {
                    const el = document.getElementById(id);
                    if (el && !el.value && val) el.value = val;
                };

                const otoSel = document.getElementById('regModalOtomasyon');
                if (otoSel && c.active_otomasyon) {
                    otoSel.value = String(c.active_otomasyon).toUpperCase();
                }

                if (c.selcuk) {
                    setIfEmpty('regDepo_selcuk_user', c.selcuk.username);
                    setIfEmpty('regDepo_selcuk_pwd', c.selcuk.password);
                }
                if (c.alliance) {
                    setIfEmpty('regDepo_alliance_pcode', c.alliance.pharmacy_code);
                    setIfEmpty('regDepo_alliance_user', c.alliance.username);
                    setIfEmpty('regDepo_alliance_pwd', c.alliance.password);
                }
                if (c.nevzat) {
                    setIfEmpty('regDepo_nevzat_account', c.nevzat.account_code);
                    setIfEmpty('regDepo_nevzat_user', c.nevzat.username);
                    setIfEmpty('regDepo_nevzat_pwd', c.nevzat.password);
                }
                if (c.iskoop) {
                    setIfEmpty('regDepo_iskoop_user', c.iskoop.username);
                    setIfEmpty('regDepo_iskoop_pwd', c.iskoop.password);
                }
                if (c.farmazon) {
                    setIfEmpty('regDepo_farmazon_user', c.farmazon.username);
                    setIfEmpty('regDepo_farmazon_pwd', c.farmazon.password);
                }
                if (c.ecza1) {
                    setIfEmpty('regDepo_ecza1_user', c.ecza1.username);
                    setIfEmpty('regDepo_ecza1_pwd', c.ecza1.password);
                }

                let savedCount = 0;
                ['selcuk', 'alliance', 'nevzat', 'iskoop', 'farmazon', 'ecza1', 'eczatrend', 'eczanetakas'].forEach(k => {
                    if (c[k] && (c[k].username || '').trim() && (c[k].password || '').trim()) {
                        savedCount++;
                    }
                });
                const badge = document.getElementById('regModalExistingCredsBadge');
                if (badge) {
                    if (savedCount > 0) {
                        badge.className = 'text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300';
                        badge.innerText = `✅ ${savedCount} Kayıtlı Depo Şifreniz Otomatik Yüklendi & Korunuyor`;
                    } else {
                        badge.innerText = '🚚 Depo Kullanıcı Adı & Şifrelerinizi Girebilirsiniz';
                    }
                }
            } catch (e) {}
        }

        async function saveRegistrationModalCredentialsIfNeeded() {
            try {
                let base = window._loadedRegModalCredentials;
                if (!base) {
                    const r = await fetch('/api/settings/credentials');
                    if (r.ok) base = await r.json();
                }
                if (!base) return;

                const pick = (inputId, existingVal) => {
                    const el = document.getElementById(inputId);
                    const v = (el?.value || '').trim();
                    return v ? v : (existingVal || '');
                };
                const isAct = (u, p, extra = 'OK') => (u && p && extra) ? "1" : "0";

                const selUser = pick('regDepo_selcuk_user', base.selcuk?.username);
                const selPwd = pick('regDepo_selcuk_pwd', base.selcuk?.password);

                const allCode = pick('regDepo_alliance_pcode', base.alliance?.pharmacy_code);
                const allUser = pick('regDepo_alliance_user', base.alliance?.username);
                const allPwd = pick('regDepo_alliance_pwd', base.alliance?.password);

                const nevAcc = pick('regDepo_nevzat_account', base.nevzat?.account_code);
                const nevUser = pick('regDepo_nevzat_user', base.nevzat?.username);
                const nevPwd = pick('regDepo_nevzat_pwd', base.nevzat?.password);

                const iskUser = pick('regDepo_iskoop_user', base.iskoop?.username);
                const iskPwd = pick('regDepo_iskoop_pwd', base.iskoop?.password);

                const fzUser = pick('regDepo_farmazon_user', base.farmazon?.username);
                const fzPwd = pick('regDepo_farmazon_pwd', base.farmazon?.password);

                const e1User = pick('regDepo_ecza1_user', base.ecza1?.username);
                const e1Pwd = pick('regDepo_ecza1_pwd', base.ecza1?.password);

                const chosenOto = (document.getElementById('regModalOtomasyon')?.value || base.active_otomasyon || 'BOTANIK').toUpperCase();

                const payload = {
                    ...base,
                    active_otomasyon: chosenOto,
                    selcuk: { username: selUser, password: selPwd, active: isAct(selUser, selPwd) },
                    alliance: { pharmacy_code: allCode, username: allUser, password: allPwd, active: isAct(allUser, allPwd, allCode) },
                    nevzat: { account_code: nevAcc, username: nevUser, password: nevPwd, active: isAct(nevUser, nevPwd, nevAcc) },
                    iskoop: { username: iskUser, password: iskPwd, active: isAct(iskUser, iskPwd) },
                    farmazon: { username: fzUser, password: fzPwd, active: isAct(fzUser, fzPwd) },
                    ecza1: { username: e1User, password: e1Pwd, active: isAct(e1User, e1Pwd) }
                };

                await fetch('/api/settings/credentials', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                window.activeOtomasyon = chosenOto;
                if (typeof refreshDepoStatusBadge === 'function') {
                    refreshDepoStatusBadge();
                }
            } catch (e) {}
        }

        async function registerTrialLicenseFromModal() {
            const pname = (document.getElementById('regModalPharmacyName')?.value || '').trim();
            const gln = (document.getElementById('regModalGln')?.value || '').trim();
            const phone = (document.getElementById('regModalPhone')?.value || '').trim();
            const pharmacist = (document.getElementById('regModalPharmacist')?.value || '').trim();
            const city = (document.getElementById('regModalCity')?.value || '').trim();
            const chosenOto = (document.getElementById('regModalOtomasyon')?.value || window.activeOtomasyon || 'BOTANIK').toUpperCase();
            const btn = document.getElementById('btnRegisterTrialModal');

            if (!pname || pname.length < 3) {
                showToast('Eksik Bilgi', 'Lütfen Eczane Adınızı giriniz.', 'error');
                return;
            }
            if (!gln || gln.replace(/[^0-9]/g, '').length < 8) {
                showToast('Eksik Bilgi', 'Lütfen 13 haneli Eczane GLN Numaranızı giriniz.', 'error');
                return;
            }
            if (!phone || phone.replace(/[^0-9]/g, '').length < 10) {
                showToast('Eksik Bilgi', 'Lütfen geçerli Cep Telefonu numaranızı giriniz.', 'error');
                return;
            }

            const origHtml = btn ? btn.innerHTML : '';
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Depo Şifreleri Korunuyor & 30 Günlük Lisansınız GitHub'a Kaydediliyor...</span>`;
            }
            try {
                await saveRegistrationModalCredentialsIfNeeded();
                const res = await fetch('/api/license/register-trial', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        pharmacy_name: pname,
                        gln_no: gln,
                        phone: phone,
                        pharmacist_name: pharmacist,
                        city: city,
                        otomasyon: chosenOto
                    })
                });
                const data = await res.json();
                applyLicenseStatusToUI(data);
                if (data.valid) {
                    showToast('🎁 30 Günlük Lisansınız Tanımlandı!', data.message || `${pname} için 30 günlük lisansınız aktif edildi.`, 'success');
                } else {
                    showToast('Lisans Uyarısı', data.message || 'Lisans tanımlanamadı.', 'error');
                }
            } catch (e) {
                showToast('Bağlantı Hatası', e.message || 'Sunucuya ulaşılamadı.', 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = origHtml;
                }
            }
        }
        window.registerTrialLicenseFromModal = registerTrialLicenseFromModal;

        window._glnLookupTimer = null;
        window._lastLookedUpGln = '';

        async function lookupLicenseByGln(rawGln, autoActivate = true, sourceUi = 'modal') {
            const digits = String(rawGln || '').replace(/[^0-9]/g, '');
            const badgeId = sourceUi === 'settings' ? 'licGlnLookupBadge' : 'regModalGlnLookupBadge';
            const badgeEl = document.getElementById(badgeId);
            const btnId = sourceUi === 'settings' ? 'btnLookupGlnSettings' : 'btnLookupGlnModal';
            const btnEl = document.getElementById(btnId);

            if (digits.length < 8) {
                showToast('Eksik GLN', 'Lütfen 13 haneli Eczane GLN numaranızı giriniz (Örn: 8680001...).', 'error');
                return null;
            }

            const origBtnHtml = btnEl ? btnEl.innerHTML : '';
            if (btnEl) {
                btnEl.disabled = true;
                btnEl.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Aranıyor...</span>`;
            }
            if (badgeEl) {
                badgeEl.className = 'text-[10px] font-extrabold text-amber-600';
                badgeEl.innerText = '⏳ Bulut & Ağdan Lisans Anahtarı Aranıyor...';
            }

            try {
                const res = await fetch(`/api/license/lookup-gln?gln=${encodeURIComponent(digits)}&auto_activate=${autoActivate ? 'true' : 'false'}`);
                const data = await res.json();

                if (data && data.found && data.license_key) {
                    window._lastLookedUpGln = digits;

                    const setVal = (id, val) => {
                        const el = document.getElementById(id);
                        if (el && val) el.value = val;
                    };
                    setVal('regModalGln', data.gln_no || digits);
                    setVal('licGlnLookupInput', data.gln_no || digits);
                    setVal('regModalPharmacyName', data.pharmacy_name);
                    setVal('regModalPharmacist', data.pharmacist_name);
                    setVal('regModalPhone', data.phone);
                    setVal('regModalCity', data.city);
                    if (data.otomasyon && document.getElementById('regModalOtomasyon')) {
                        document.getElementById('regModalOtomasyon').value = String(data.otomasyon).toUpperCase();
                    }
                    setVal('lockModalKeyInput', data.license_key);
                    setVal('licKeyInput', data.license_key);

                    if (badgeEl) {
                        badgeEl.className = 'text-[10px] font-extrabold text-emerald-700';
                        badgeEl.innerText = `✅ ${data.pharmacy_name || 'Eczane'} Lisans Anahtarı Otomatik Geldi!`;
                    }
                    const fb = document.getElementById('licFeedbackMsg');
                    if (fb) {
                        fb.classList.remove('hidden');
                        fb.className = 'text-xs font-semibold p-2.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200';
                        fb.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5 text-emerald-600"></i>${data.message || 'Lisans anahtarınız otomatik getirildi ve etkinleştirildi.'}`;
                    }

                    applyLicenseStatusToUI(data);
                    showToast('🎉 Lisans Anahtarı Otomatik Geldi!', data.message || `${data.pharmacy_name} için lisans anahtarınız otomatik yüklendi ve etkinleştirildi.`, 'success');
                    return data;
                } else {
                    if (badgeEl) {
                        badgeEl.className = 'text-[10px] font-extrabold text-slate-500';
                        badgeEl.innerText = 'Yeni GLN — Bilgileri doldurup 30 Günlük Lisansı başlatabilirsiniz';
                    }
                }
                return data;
            } catch (e) {
                if (badgeEl) {
                    badgeEl.className = 'text-[10px] font-extrabold text-rose-600';
                    badgeEl.innerText = 'Sorgulama hatası';
                }
                return null;
            } finally {
                if (btnEl) {
                    btnEl.disabled = false;
                    btnEl.innerHTML = origBtnHtml;
                }
            }
        }
        window.lookupLicenseByGln = lookupLicenseByGln;

        function onRegModalGlnInput(val, sourceUi = 'modal') {
            const digits = String(val || '').replace(/[^0-9]/g, '');
            if (window._glnLookupTimer) clearTimeout(window._glnLookupTimer);
            if (digits.length === 13 && digits !== window._lastLookedUpGln) {
                window._glnLookupTimer = setTimeout(() => {
                    lookupLicenseByGln(digits, true, sourceUi);
                }, 150);
            }
        }
        window.onRegModalGlnInput = onRegModalGlnInput;

        function onLicenseKeyOrGlnInput(inputEl, autoActivate = true) {
            if (!inputEl) return;
            const raw = String(inputEl.value || '').trim();
            if (raw.toUpperCase().startsWith('FR-') || raw.toUpperCase().startsWith('EDP-')) return;
            const digits = raw.replace(/[^0-9]/g, '');
            if (digits.length === 13 && digits !== window._lastLookedUpGln) {
                if (window._glnLookupTimer) clearTimeout(window._glnLookupTimer);
                window._glnLookupTimer = setTimeout(async () => {
                    const d = await lookupLicenseByGln(digits, autoActivate, 'settings');
                    if (d && d.license_key) {
                        inputEl.value = d.license_key;
                    }
                }, 150);
            }
        }
        window.onLicenseKeyOrGlnInput = onLicenseKeyOrGlnInput;

        // Sayfa açılışında, her 25 saniyede bir ve sekme odaklandığında uzaktan online lisans durumunu kontrol et
        setTimeout(() => loadLicenseStatus(true), 400);
        setInterval(() => loadLicenseStatus(true), 25000);
        window.addEventListener('focus', () => loadLicenseStatus(true));

        async function activateNewLicense() {
            const keyInput = document.getElementById('licKeyInput');
            const fb = document.getElementById('licFeedbackMsg');
            const keyVal = (keyInput?.value || '').trim();
            if (!keyVal) {
                showToast('Uyarı', 'Lütfen geçerli bir FR-... veya EDP-... lisans anahtarı girin.', 'error');
                return;
            }
            try {
                const res = await fetch('/api/license/activate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ license_key: keyVal })
                });
                const data = await res.json();
                applyLicenseStatusToUI(data);
                if (fb) {
                    fb.classList.remove('hidden');
                    if (data.valid) {
                        fb.className = 'text-xs font-semibold p-2.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200';
                        fb.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5 text-emerald-600"></i>${data.message}`;
                        showToast('Lisans Aktive Edildi', data.message, 'success');
                    } else {
                        fb.className = 'text-xs font-semibold p-2.5 rounded-xl bg-rose-50 text-rose-800 border border-rose-200';
                        fb.innerHTML = `<i class="fa-solid fa-circle-xmark mr-1.5 text-rose-600"></i>${data.message}`;
                        showToast('Lisans Uyarısı', data.message, 'error');
                    }
                } else {
                    if (data.valid) {
                        showToast('Lisans Aktive Edildi', data.message, 'success');
                    } else {
                        showToast('Lisans Uyarısı', data.message, 'error');
                    }
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        function openUpdateModal() {
            openSettingsModal('guncelleme');
            checkAppUpdate(true);
            loadLicenseStatus();
            loadGithubPortalConfig();
        }

        async function checkAppUpdate(isManual = false, _retryCount = 0) {
            const btnCheck = document.getElementById('btnCheckUpdateNow');
            const checkIcon = document.getElementById('checkUpdateIcon');
            const statusCard = document.getElementById('updateStatusCard');
            const headerVersionBtn = document.getElementById('headerVersionBtn');
            const headerVersionText = document.getElementById('headerVersionText');
            const headerUpdateDot = document.getElementById('headerUpdateDot');
            const tabUpdateBadge = document.getElementById('tabUpdateBadge');

            if (isManual && checkIcon) {
                checkIcon.classList.add('fa-spin');
            }

            try {
                // 1. Önce yerel sürümü al
                let localInfo = { version: '1.3.5', manifest_url: 'https://raw.githubusercontent.com/depomxxx/depo-updates/main/version.json' };
                try {
                    const verRes = await fetch('/api/version');
                    if (verRes.ok) {
                        localInfo = await verRes.json();
                    }
                } catch (ve) {
                    if (_retryCount < 2) {
                        await new Promise(r => setTimeout(r, 1200));
                        return await checkAppUpdate(isManual, _retryCount + 1);
                    }
                    throw ve;
                }

                if (localInfo.version) {
                    if (!window._initialLoadedVersion) {
                        window._initialLoadedVersion = String(localInfo.version);
                    } else if (window._initialLoadedVersion !== String(localInfo.version)) {
                        if (typeof showToast === 'function') {
                            showToast('Yeni Sürüm Aktif (v' + localInfo.version + ')', 'Arayüz yeni sürüm özellikleriyle yenileniyor...', 'success');
                        }
                        setTimeout(() => { window.location.replace(window.location.pathname + '?v=' + encodeURIComponent(localInfo.version) + '&t=' + Date.now()); }, 800);
                        return;
                    }
                    if (localInfo.restart_required && !window._restartReloadScheduled) {
                        window._restartReloadScheduled = true;
                        setTimeout(() => { window.location.replace(window.location.pathname + '?v=' + encodeURIComponent(localInfo.version) + '&t=' + Date.now()); }, 2800);
                    }
                    if (headerVersionText) {
                        headerVersionText.innerText = `v${localInfo.version}`;
                    }
                }
                const titleEl = document.getElementById('updateLocalVersionTitle');
                if (titleEl) titleEl.innerText = `Farma Radar v${localInfo.version || '1.3.5'}`;
                const dateEl = document.getElementById('updateBuildDateText');
                if (dateEl) dateEl.innerText = `Son Güncelleme: ${localInfo.updated_at || localInfo.build_date || '2026-10-24'}`;
                const mInput = document.getElementById('cfg_update_manifest_url');
                if (mInput && localInfo.manifest_url && document.activeElement !== mInput) {
                    mInput.value = localInfo.manifest_url;
                }

                // 2. Güncelleme denetimi yap (Önce yerel sunucu üzerinden, hata olursa doğrudan GitHub bulutundan)
                let chk = null;
                try {
                    const chkRes = await fetch('/api/update/check?timeout=6.0');
                    if (chkRes.ok) {
                        chk = await chkRes.json();
                    }
                } catch (ce) {}

                if (!chk || !chk.success) {
                    try {
                        const mUrl = (localInfo.manifest_url || 'https://raw.githubusercontent.com/depomxxx/depo-updates/main/version.json') + '?t=' + Date.now();
                        const ghRes = await fetch(mUrl, { cache: 'no-store' });
                        if (ghRes.ok) {
                            const ghData = await ghRes.json();
                            const curV = String(localInfo.version || '1.3.5').replace(/^v/i, '');
                            const remV = String(ghData.version || curV).replace(/^v/i, '');
                            const curParts = curV.split('.').map(n => parseInt(n, 10) || 0);
                            const remParts = remV.split('.').map(n => parseInt(n, 10) || 0);
                            let isNewer = false;
                            for (let i = 0; i < Math.max(curParts.length, remParts.length); i++) {
                                const a = remParts[i] || 0, b = curParts[i] || 0;
                                if (a > b) { isNewer = true; break; }
                                if (a < b) { break; }
                            }
                            chk = {
                                success: true,
                                update_available: isNewer,
                                current_version: curV,
                                latest_version: remV,
                                download_url: ghData.download_url || '',
                                sha256: ghData.sha256 || '',
                                changelog: ghData.changelog || '',
                                mandatory: !!ghData.mandatory,
                                auto_update: true
                            };
                        }
                    } catch (ghe) {}
                }

                if (!chk) {
                    chk = {
                        success: true,
                        update_available: false,
                        current_version: localInfo.version || '1.3.5',
                        latest_version: localInfo.version || '1.3.5'
                    };
                }

                lastCheckedUpdate = chk;

                if (chk.update_available) {
                    // Yeni sürüm bulundu!
                    if (headerVersionBtn) {
                        headerVersionBtn.className = 'inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl font-bold bg-amber-500 hover:bg-amber-600 text-white transition shadow-sm cursor-pointer animate-pulse';
                    }
                    if (headerVersionText) {
                        headerVersionText.innerText = `🔔 v${chk.latest_version} Güncelle`;
                    }
                    if (headerUpdateDot) headerUpdateDot.classList.remove('hidden');
                    if (tabUpdateBadge) tabUpdateBadge.classList.remove('hidden');

                    if (statusCard) {
                        statusCard.classList.remove('hidden');
                        statusCard.className = 'p-5 rounded-2xl border border-amber-300 bg-amber-50/90 text-amber-950 space-y-3 shadow-sm';
                        statusCard.innerHTML = `
                            <div class="flex items-start justify-between">
                                <div class="flex items-center space-x-3">
                                    <div class="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center text-lg shadow-sm">
                                        <i class="fa-solid fa-bell"></i>
                                    </div>
                                    <div>
                                        <h5 class="text-sm font-black text-amber-950">Yeni Sürüm Yayında: v${chk.latest_version}</h5>
                                        <p class="text-xs text-amber-800">Mevcut sürümünüz: v${chk.current_version}</p>
                                    </div>
                                </div>
                                <span class="text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-amber-200 text-amber-900">Güncelleme Hazır</span>
                            </div>
                            <div class="bg-white/80 p-3.5 rounded-xl border border-amber-200 text-xs space-y-1">
                                <div class="font-bold text-slate-800">Yenilikler & Düzeltmeler:</div>
                                <p class="text-slate-700 whitespace-pre-line">${escapeHtml(chk.changelog || 'Hata düzeltmeleri ve hızlandırmalar.')}</p>
                            </div>
                            <div class="flex items-center justify-between pt-2">
                                <span class="text-[11px] text-amber-800 font-medium">Paket Boyutu: ~1.5 MB (Şifreleriniz ve ayarlarınız korunur)</span>
                                <button type="button" onclick="applyAppUpdate()" id="btnApplyUpdate" class="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-200 transition flex items-center space-x-2 cursor-pointer">
                                    <i class="fa-solid fa-cloud-arrow-down"></i>
                                    <span>Hemen Güncelle & Yeniden Başlat</span>
                                </button>
                            </div>
                        `;
                    }

                    if (isManual) {
                        showToast('Yeni Güncelleme Mevcut!', `Sürüm v${chk.latest_version} bulundu, otomatik kuruluyor...`, 'info');
                        setTimeout(() => applyAppUpdate(), 800);
                    } else if (chk.auto_update !== false || chk.mandatory) {
                        showToast('Canlı Güncelleme', `Yeni sürüm (v${chk.latest_version}) bulundu, otomatik kuruluyor...`, 'info');
                        setTimeout(() => applyAppUpdate(), 1200);
                    }
                } else {
                    // En güncel sürüm
                    if (headerUpdateDot) headerUpdateDot.classList.add('hidden');
                    if (tabUpdateBadge) tabUpdateBadge.classList.add('hidden');

                    if (statusCard) {
                        statusCard.classList.remove('hidden');
                        statusCard.className = 'p-4 rounded-2xl border border-emerald-200 bg-emerald-50 text-emerald-950 flex items-center space-x-3.5';
                        statusCard.innerHTML = `
                            <div class="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center text-lg shrink-0">
                                <i class="fa-solid fa-check"></i>
                            </div>
                            <div>
                                <h5 class="text-xs font-bold text-emerald-950">Programınız En Güncel Sürümde (v${chk.current_version})</h5>
                                <p class="text-[11px] text-emerald-700">Tüm depo entegrasyonları, 13 haneli barkod motoru ve sepet özellikleri güncel.</p>
                            </div>
                        `;
                    }

                    if (isManual) {
                        showToast('Güncel', `Programınız zaten en güncel sürümde (v${chk.current_version}).`, 'success');
                    }
                }
            } catch (err) {
                if (isManual) {
                    showToast('Kontrol Uyarısı', 'Yerel sunucu yeniden başlatılıyor olabilir, lütfen 2 saniye sonra tekrar deneyin.', 'error');
                }
            } finally {
                if (checkIcon) checkIcon.classList.remove('fa-spin');
            }
        }

        async function applyAppUpdate() {
            const btn = document.getElementById('btnApplyUpdate');
            const statusCard = document.getElementById('updateStatusCard');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1.5"></i>İndiriliyor & Kuruluyor...`;
            }

            try {
                const res = await fetch('/api/update/apply', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(lastCheckedUpdate || {})
                });
                const data = await res.json();

                if (data.success) {
                    if (statusCard) {
                        statusCard.className = 'p-5 rounded-2xl border border-emerald-300 bg-emerald-50 text-emerald-950 text-center space-y-2';
                        statusCard.innerHTML = `
                            <div class="inline-flex w-12 h-12 rounded-xl bg-emerald-600 text-white items-center justify-center text-2xl shadow-md">
                                <i class="fa-solid fa-circle-check"></i>
                            </div>
                            <h4 class="text-sm font-black text-emerald-950">Güncelleme Başarıyla Kuruldu!</h4>
                            <p class="text-xs text-emerald-800">Sunucu yeni kodlarla yeniden başlatılıyor. Sayfa 3 saniye içinde açılacak...</p>
                            <div class="w-full bg-emerald-200 h-1.5 rounded-full overflow-hidden mt-3">
                                <div class="bg-emerald-600 h-full animate-pulse w-full"></div>
                            </div>
                        `;
                    }
                    showToast('Başarılı', 'Güncelleme kuruldu! Sayfa yenileniyor...', 'success');
                    setTimeout(() => {
                        window.location.replace(window.location.pathname + '?v=' + encodeURIComponent(data.new_version || Date.now()) + '&t=' + Date.now());
                    }, 3200);
                } else {
                    showToast('Güncelleme Hatası', data.message || 'Güncelleme uygulanamadı.', 'error');
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = `<i class="fa-solid fa-rotate-right mr-1.5"></i>Tekrar Dene`;
                    }
                }
            } catch (err) {
                showToast('Hata', 'Güncelleme sırasında bağlantı kesildi: ' + err.message, 'error');
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = `<i class="fa-solid fa-rotate-right mr-1.5"></i>Tekrar Dene`;
                }
            }
        }

        async function restartAppServer() {
            if (!confirm('EDA Depo sunucusu yeniden başlatılsın mı? Sayfa 3 saniye içinde otomatik tazelenecektir.')) return;
            try {
                showToast('Yeniden Başlatılıyor', 'Sunucu yeniden başlatılıyor...', 'info');
                await fetch('/api/server/restart', { method: 'POST' });
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            } catch (e) {
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            }
        }

        // Sayfa açılışında ve her 90 saniyede bir otomatik canlı güncelleme kontrolü yap
        setTimeout(() => checkAppUpdate(false), 1500);
        setInterval(() => checkAppUpdate(false), 90000);

        // ================= Dermo & OTC Barkod Onarım Sihirbazı İşlemleri =================
        function escapeHtml(text) {
            if (!text) return '';
            return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }

        let currentDermoMatches = [];

        async function runDermoAudit() {
            const brand = document.getElementById('dermoBrandSelect')?.value || '';
            const limit = document.getElementById('dermoLimitSelect')?.value || 50;
            const btn = document.getElementById('btnRunDermoAudit');
            const loading = document.getElementById('dermoLoading');
            const resultsContainer = document.getElementById('dermoResultsContainer');
            const feedback = document.getElementById('dermoSyncFeedback');

            if (feedback) feedback.classList.add('hidden');
            if (resultsContainer) resultsContainer.classList.add('hidden');
            if (loading) loading.classList.remove('hidden');
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> Taranıyor...'; }

            try {
                const resp = await fetch(`/api/botanik/dermo-audit?brand=${encodeURIComponent(brand)}&limit=${limit}`);
                const data = await resp.json();

                if (loading) loading.classList.add('hidden');
                if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-magnifying-glass-arrow-right"></i> Hatalı Barkodları Tara & Eşleştir'; }

                if (!data.success) {
                    showToast(data.message || 'Tarama sırasında bir hata oluştu.', 'error');
                    return;
                }

                currentDermoMatches = data.matches || [];
                document.getElementById('dermoStatScanned').innerText = data.scanned_count || 0;
                document.getElementById('dermoStatMatched').innerText = currentDermoMatches.length;
                document.getElementById('dermoStatElapsed').innerText = (data.elapsed_sec || 0) + 's';

                const tbody = document.getElementById('dermoAuditTableBody');
                if (!tbody) return;
                tbody.innerHTML = '';

                if (currentDermoMatches.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-slate-400 font-medium">Bu filtreye uygun hatalı veya eksik barkodlu ürün bulunamadı.</td></tr>`;
                } else {
                    currentDermoMatches.forEach((item) => {
                        const tr = document.createElement('tr');
                        tr.id = `dermoRow_${item.urun_id}`;
                        tr.className = 'hover:bg-pink-50/40 transition';
                        tr.innerHTML = `
                            <td class="py-2.5 px-3 text-center">
                                <input type="checkbox" class="dermoItemCheck rounded text-pink-600 focus:ring-0 w-4 h-4 cursor-pointer" data-id="${item.urun_id}" data-bc="${item.oneri_barkod}" checked />
                            </td>
                            <td class="py-2.5 px-3">
                                <div class="font-bold text-slate-800">${escapeHtml(item.urun_adi)}</div>
                                <div class="text-[10px] text-slate-400 font-mono">ID: ${item.urun_id} • Stok: ${item.stok} Kutu</div>
                            </td>
                            <td class="py-2.5 px-3">
                                <span class="inline-flex items-center px-2 py-0.5 rounded font-mono text-[11px] font-bold ${item.mevcut_barkod === 'YOK' ? 'bg-slate-100 text-slate-500' : 'bg-amber-100 text-amber-800'}">
                                    ${item.mevcut_barkod}
                                </span>
                            </td>
                            <td class="py-2.5 px-3">
                                <span class="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-800 font-mono text-xs font-black shadow-2xs">
                                    <i class="fa-solid fa-barcode text-emerald-600"></i>
                                    <span>${item.oneri_barkod}</span>
                                </span>
                            </td>
                            <td class="py-2.5 px-3 text-[11px] text-slate-600 font-medium">
                                ${escapeHtml(item.katalog_urun_adi || '-')}
                            </td>
                            <td class="py-2.5 px-3 text-center" id="dermoStatusCell_${item.urun_id}">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-pink-100 text-pink-700">
                                    ${item.guven || 'Tam Uyum'}
                                </span>
                            </td>
                        `;
                        tbody.appendChild(tr);
                    });
                }

                if (resultsContainer) resultsContainer.classList.remove('hidden');
                showToast(data.message, 'success');

            } catch (err) {
                if (loading) loading.classList.add('hidden');
                if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-magnifying-glass-arrow-right"></i> Hatalı Barkodları Tara & Eşleştir'; }
                showToast('Bağlantı hatası: ' + err.message, 'error');
            }
        }

        function toggleAllDermoCheckboxes(masterCheckbox) {
            const checks = document.querySelectorAll('.dermoItemCheck');
            checks.forEach(c => c.checked = masterCheckbox.checked);
        }

        async function applyDermoSync() {
            const checks = document.querySelectorAll('.dermoItemCheck:checked');
            if (checks.length === 0) {
                showToast('Lütfen Botanik’e eklemek için en az bir ürün seçin.', 'info');
                return;
            }

            const itemsToSync = [];
            checks.forEach(c => {
                itemsToSync.push({
                    urun_id: parseInt(c.dataset.id),
                    oneri_barkod: c.dataset.bc
                });
            });

            const confirmed = confirm(`${itemsToSync.length} adet gerçek üretici barkodu Botanik programınıza ek barkod olarak eklenecektir.\\n\\nMevcut verileriniz silinmez. Devam edilsin mi?`);
            if (!confirmed) return;

            const btn = document.getElementById('btnApplyDermoSync');
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> Ekleniyor...'; }

            try {
                const resp = await fetch('/api/botanik/dermo-sync', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ items: itemsToSync })
                });
                const res = await resp.json();

                if (btn) { btn.disabled = false; btn.innerHTML = `<i class="fa-solid fa-floppy-disk"></i> Seçilenleri Botanik'e Ekle`; }

                if (res.success) {
                    showToast(res.message, 'success');
                    // Başarılı satırları güncelle
                    itemsToSync.forEach(it => {
                        const cell = document.getElementById(`dermoStatusCell_${it.urun_id}`);
                        if (cell) {
                            cell.innerHTML = '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800"><i class="fa-solid fa-check mr-1"></i> Eklendi</span>';
                        }
                    });
                } else {
                    showToast(res.message || 'Eklenirken bir hata oluştu.', 'error');
                }
            } catch (err) {
                if (btn) { btn.disabled = false; btn.innerHTML = `<i class="fa-solid fa-floppy-disk"></i> Seçilenleri Botanik'e Ekle`; }
                showToast('Hata: ' + err.message, 'error');
            }
        }

        async function fetchCatalogStats() {
            try {
                const res = await fetch('/api/catalog/stats');
                if (res.ok) {
                    const data = await res.json();
                    document.getElementById('catStatProducts').innerText = (data.total_products || 0).toLocaleString('tr-TR');
                    document.getElementById('catStatBarcodes').innerText = (data.total_barcodes || 0).toLocaleString('tr-TR');
                    document.getElementById('catStatSecondary').innerText = (data.secondary_barcodes || 0).toLocaleString('tr-TR');
                }
            } catch(e) {
                console.error('Katalog istatistik hatası:', e);
            }
        }

        async function syncBotanikCatalog() {
            const btn = document.getElementById('btnSyncBotanikCat');
            const statusDiv = document.getElementById('botanikSyncStatus');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Botanik taranıyor...`;
            statusDiv.className = 'hidden';

            try {
                const res = await fetch('/api/catalog/sync-botanik', { method: 'POST' });
                const data = await res.json();
                if (data.success) {
                    statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200';
                    statusDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5"></i>${data.message}`;
                    fetchCatalogStats();
                    showToast('Katalog Güncellendi', data.message, 'success');
                } else {
                    throw new Error(data.error || 'Botanik senkronizasyonu başarısız oldu.');
                }
            } catch(e) {
                statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-red-50 text-red-800 border border-red-200';
                statusDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        async function syncTriaCatalog() {
            const btn = document.getElementById('btnSyncTriaCat');
            const statusDiv = document.getElementById('triaSyncStatus');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Senkronize ediliyor...`;
            statusDiv.className = 'hidden';

            try {
                const res = await fetch('/api/catalog/sync-tria', { method: 'POST' });
                const data = await res.json();
                if (data.success) {
                    statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200';
                    statusDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5"></i>${data.message}`;
                    fetchCatalogStats();
                    showToast('Katalog Güncellendi', data.message, 'success');
                } else {
                    throw new Error(data.error || 'Senkronizasyon başarısız oldu.');
                }
            } catch(e) {
                statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-red-50 text-red-800 border border-red-200';
                statusDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        async function uploadCatalogExcel() {
            const fileInput = document.getElementById('excelCatalogFile');
            const btn = document.getElementById('btnUploadCatExcel');
            const statusDiv = document.getElementById('excelUploadStatus');

            if (!fileInput.files || fileInput.files.length === 0) {
                alert('Lütfen yüklenecek bir Excel (.xlsx) dosyası seçin.');
                return;
            }

            const formData = new FormData();
            formData.append('file', fileInput.files[0]);

            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Aktarılıyor...`;
            statusDiv.className = 'hidden';

            try {
                const res = await fetch('/api/catalog/upload-excel', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.success) {
                    statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200';
                    statusDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5"></i>Başarılı: ${data.count} ürün kataloğa aktarıldı.`;
                    fetchCatalogStats();
                    showToast('Excel Aktarıldı', `${data.count} ürün kataloğa eklendi.`, 'success');
                    fileInput.value = '';
                } else {
                    throw new Error(data.error || 'Excel aktarımı başarısız oldu.');
                }
            } catch(e) {
                statusDiv.className = 'text-xs font-semibold p-3 rounded-xl bg-red-50 text-red-800 border border-red-200';
                statusDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        function setBotanikProfile(profile) {
            if (profile === 'yerel') {
                document.getElementById('cfg_botanik_server').value = '.\\\\BOTANIKSQL';
                document.getElementById('cfg_botanik_db').value = 'eczane';
                document.getElementById('cfg_botanik_user').value = 'sa';
                document.getElementById('cfg_botanik_pwd').value = '123';
                document.getElementById('cfg_botanik_trusted').checked = false;
                showToast('Profil Yüklendi', 'Yerel SQL (.\\\\BOTANIKSQL) varsayılan ayarları uygulandı.', 'success');
            }
        }

        async function autoReadBotanikConfigFile() {
            try {
                const res = await fetch('/api/botanik/read-config');
                const data = await res.json();
                if (data.success) {
                    const cfg = data.config || data;
                    const serverVal = cfg.server || data.server;
                    const dbVal = cfg.database || data.database;
                    const userVal = cfg.user || data.user;
                    const pwdVal = cfg.password || data.password;
                    const trustedVal = (cfg.trusted !== undefined) ? cfg.trusted : data.trusted;

                    if (serverVal) document.getElementById('cfg_botanik_server').value = serverVal;
                    if (dbVal) document.getElementById('cfg_botanik_db').value = dbVal;
                    if (userVal) document.getElementById('cfg_botanik_user').value = userVal;
                    if (pwdVal) document.getElementById('cfg_botanik_pwd').value = pwdVal;
                    if (trustedVal !== undefined) {
                        document.getElementById('cfg_botanik_trusted').checked = (trustedVal === true || trustedVal === 'true');
                    }
                    const pathInfo = data.path ? ` (${data.path})` : '';
                    showToast('Config Başarıyla Okundu', data.message || `Botanik config${pathInfo} dosyasından bilgiler otomatik aktarıldı.`, 'success');
                } else {
                    showToast('Config Bulunamadı', data.message || 'Botanik config dosyası okunamadı. Lütfen elle giriniz.', 'error');
                }
            } catch(e) {
                showToast('Hata', `Config okuma hatası: ${e.message}`, 'error');
            }
        }

        async function pingBotanikConnection() {
            const btn = document.getElementById('btnPingBotanik');
            const resBox = document.getElementById('botanikPingResult');
            const origHtml = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i><span>Ping Atılıyor...</span>`;
            resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-slate-100 text-slate-600 border border-slate-200';
            resBox.innerHTML = '<i class="fa-solid fa-spinner animate-spin mr-1.5"></i>Botanik MS SQL veritabanına bağlanılıyor...';
            resBox.classList.remove('hidden');

            try {
                const res = await fetch('/api/botanik/ping');
                const data = await res.json();
                if (data.success && data.connected) {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-emerald-50 text-emerald-900 border border-emerald-300';
                    resBox.innerHTML = `
                        <div class="flex items-center justify-between border-b border-emerald-200/80 pb-1.5 mb-2">
                            <span class="font-bold text-sm text-emerald-800 flex items-center space-x-1.5">
                                <i class="fa-solid fa-circle-check text-emerald-600"></i>
                                <span>Botanik SQL Bağlantısı Başarılı</span>
                            </span>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-200 text-emerald-900 font-mono">${data.latency_ms} ms</span>
                        </div>
                        <div class="text-[11px] text-emerald-800 space-y-1">
                            <div>Sunucu: <strong class="font-mono text-emerald-950">${data.server}</strong> | Veritabanı: <strong class="font-mono text-emerald-950">${data.database}</strong> (Kullanıcı: <strong>${data.user}</strong>)</div>
                            <div>SQL Sürüm: <strong>${data.version || 'MS SQL Server'}</strong></div>
                            <div>Kayıtlı Veri: <strong>${(data.stats && data.stats.kayitli_urun_sayisi) ? data.stats.kayitli_urun_sayisi.toLocaleString() : '-'}</strong> İlaç/Ürün, <strong>${(data.stats && data.stats.toplam_recete_sayisi) ? data.stats.toplam_recete_sayisi.toLocaleString() : '-'}</strong> Reçete, <strong>${(data.stats && data.stats.fatura_sayisi) ? data.stats.fatura_sayisi.toLocaleString() : '-'}</strong> Fatura</div>
                        </div>
                    `;
                    updateHeaderBotanikStatus(true, data);
                    showToast('Botanik Bağlantısı Başarılı', `Botanik veritabanına ${data.latency_ms} ms içinde bağlanıldı.`, 'success');
                } else {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                    resBox.innerHTML = `
                        <div class="font-bold text-sm text-red-800 flex items-center space-x-1.5 mb-1">
                            <i class="fa-solid fa-circle-xmark text-red-600"></i>
                            <span>Bağlantı Başarısız (${data.latency_ms || 0} ms)</span>
                        </div>
                        <div class="text-[11px] text-red-700">
                            <strong>Hata Detayı:</strong> ${data.message || data.error || 'Veritabanı yanıt vermedi.'}
                        </div>
                    `;
                    updateHeaderBotanikStatus(false, data);
                }
            } catch(e) {
                resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                resBox.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5 text-red-600"></i>Bağlantı hatası: ${e.message}`;
                updateHeaderBotanikStatus(false);
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        }

        window.activeOtomasyon = 'BOTANIK';
        window.botanikStatus = { connected: null, latency_ms: null };
        window.triaStatus = { connected: null, latency_ms: null };
        window.tebeosStatus = { connected: null, latency_ms: null };

        function toggleOtomasyonSelector() {
            const grid = document.getElementById('otoSelectorCardsGrid');
            if (!grid) return;
            grid.classList.toggle('hidden');
        }

        function refreshHeaderActiveOtomasyon() {
            const btn = document.getElementById('headerActiveOtomasyonBtn');
            const icon = document.getElementById('headerOtomasyonIcon');
            const text = document.getElementById('headerOtomasyonText');
            const dot = document.getElementById('headerOtomasyonDot');

            if (!btn || !text) return;

            const activeOto = (window.activeOtomasyon || 'BOTANIK').toUpperCase();
            const baseBtnCls = 'inline-flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl font-semibold transition cursor-pointer whitespace-nowrap shrink-0';

            if (activeOto === 'TEBEOS') {
                if (icon) icon.className = 'fa-solid fa-mortar-pestle text-sky-600 text-[11px]';
                if (window.tebeosStatus.connected === true) {
                    btn.className = `${baseBtnCls} bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200`;
                    text.innerText = `TEBEOS`;
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-emerald-500 shrink-0';
                } else if (window.tebeosStatus.connected === false) {
                    btn.className = `${baseBtnCls} bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200`;
                    text.innerText = 'TEBEOS: Yok';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-rose-500 shrink-0';
                } else {
                    btn.className = `${baseBtnCls} bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200`;
                    text.innerText = 'TEBEOS...';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-amber-500 shrink-0';
                }
                btn.title = 'TEBEOS PostgreSQL Veritabanı ve Şifre Ayarlarını Aç';
            } else if (activeOto === 'BOTANIK') {
                if (icon) icon.className = 'fa-solid fa-leaf text-emerald-600 text-[11px]';
                if (window.botanikStatus.connected === true) {
                    btn.className = `${baseBtnCls} bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200`;
                    text.innerText = `Botanik EOS`;
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-emerald-500 shrink-0';
                } else if (window.botanikStatus.connected === false) {
                    btn.className = `${baseBtnCls} bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200`;
                    text.innerText = 'Botanik: Yok';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-rose-500 shrink-0';
                } else {
                    btn.className = `${baseBtnCls} bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200`;
                    text.innerText = 'Botanik...';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-amber-500 shrink-0';
                }
                btn.title = 'Botanik Eczane MS SQL Veritabanı ve Şifre Ayarlarını Aç';
            } else {
                if (icon) icon.className = 'fa-solid fa-database text-amber-600 text-[11px]';
                if (window.triaStatus.connected === true) {
                    btn.className = `${baseBtnCls} bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200`;
                    text.innerText = `TRIA`;
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-emerald-500 shrink-0';
                } else if (window.triaStatus.connected === false) {
                    btn.className = `${baseBtnCls} bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200`;
                    text.innerText = 'TRIA: Yok';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-rose-500 shrink-0';
                } else {
                    btn.className = `${baseBtnCls} bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200`;
                    text.innerText = 'TRIA...';
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-amber-500 shrink-0';
                }
                btn.title = 'TRIA Oracle Veritabanı ve Şifre Ayarlarını Aç';
            }
        }

        function selectActiveOtomasyon(type, switchTab = true) {
            type = (type || 'BOTANIK').toUpperCase();
            if (type === 'ECZANEM') type = 'BOTANIK';
            window.activeOtomasyon = type;
            const sel = document.getElementById('cfg_active_otomasyon');
            if (sel) sel.value = type;

            const cardBotanik = document.getElementById('otoChoiceCardBotanik');
            const cardTria = document.getElementById('otoChoiceCardTria');
            const cardTebeos = document.getElementById('otoChoiceCardTebeos');
            const badgeBotanik = document.getElementById('otoChoiceBadgeBotanik');
            const badgeTria = document.getElementById('otoChoiceBadgeTria');
            const badgeTebeos = document.getElementById('otoChoiceBadgeTebeos');
            const summaryBadge = document.getElementById('activeOtoSummaryBadge');
            const bannerLabel = document.getElementById('activeOtoBannerLabel');

            // Sadece kurulu/aktif olan otomasyonun sekmesini ve senkronizasyon kartını göster, diğerlerini gizle
            const tabBtnBotanik = document.getElementById('tabBtnBotanik');
            const tabBtnTria = document.getElementById('tabBtnTria');
            const tabBtnTebeos = document.getElementById('tabBtnTebeos');
            const syncCardBotanik = document.getElementById('syncCardBotanik');
            const syncCardTria = document.getElementById('syncCardTria');

            if (tabBtnBotanik) tabBtnBotanik.classList.toggle('hidden', type !== 'BOTANIK');
            if (tabBtnTria) tabBtnTria.classList.toggle('hidden', type !== 'TRIA');
            if (tabBtnTebeos) tabBtnTebeos.classList.toggle('hidden', type !== 'TEBEOS');
            if (syncCardBotanik) syncCardBotanik.classList.toggle('hidden', type !== 'BOTANIK');
            if (syncCardTria) syncCardTria.classList.toggle('hidden', type !== 'TRIA');

            const inactiveCardClass = 'p-3.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 cursor-pointer transition flex items-center justify-between group';
            const inactiveBadgeClass = 'text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/10 text-slate-400';

            if (cardBotanik) cardBotanik.className = inactiveCardClass;
            if (cardTria) cardTria.className = inactiveCardClass;
            if (cardTebeos) cardTebeos.className = inactiveCardClass;
            if (badgeBotanik) { badgeBotanik.className = inactiveBadgeClass; badgeBotanik.innerText = 'SEÇ'; }
            if (badgeTria) { badgeTria.className = inactiveBadgeClass; badgeTria.innerText = 'SEÇ'; }
            if (badgeTebeos) { badgeTebeos.className = inactiveBadgeClass; badgeTebeos.innerText = 'SEÇ'; }

            if (type === 'BOTANIK') {
                if (cardBotanik) cardBotanik.className = 'p-3.5 rounded-xl border-2 border-emerald-500 bg-emerald-500/20 cursor-pointer transition flex items-center justify-between group shadow-sm';
                if (badgeBotanik) {
                    badgeBotanik.className = 'text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-400 text-slate-950';
                    badgeBotanik.innerText = '✓ AKTİF SEÇİM';
                }
                if (summaryBadge) {
                    summaryBadge.className = 'px-2.5 py-0.5 rounded-full text-[11px] font-black bg-emerald-400 text-slate-950';
                    summaryBadge.innerText = 'BOTANİK EOS (MS SQL)';
                }
                if (bannerLabel) {
                    bannerLabel.className = 'ml-1.5 text-xs font-black px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30';
                    bannerLabel.innerText = '🌿 Botanik Eczane (MS SQL)';
                }
                if (switchTab) switchSettingsTab('botanik');
            } else if (type === 'TEBEOS') {
                if (cardTebeos) cardTebeos.className = 'p-3.5 rounded-xl border-2 border-sky-500 bg-sky-500/20 cursor-pointer transition flex items-center justify-between group shadow-sm';
                if (badgeTebeos) {
                    badgeTebeos.className = 'text-[10px] font-black px-2 py-0.5 rounded-full bg-sky-400 text-slate-950';
                    badgeTebeos.innerText = '✓ AKTİF SEÇİM';
                }
                if (summaryBadge) {
                    summaryBadge.className = 'px-2.5 py-0.5 rounded-full text-[11px] font-black bg-sky-400 text-slate-950';
                    summaryBadge.innerText = 'TEBEOS (PostgreSQL)';
                }
                if (bannerLabel) {
                    bannerLabel.className = 'ml-1.5 text-xs font-black px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-400/30';
                    bannerLabel.innerText = '🔷 TEBEOS Eczane (PostgreSQL)';
                }
                if (switchTab) switchSettingsTab('tebeos');
            } else {
                if (cardTria) cardTria.className = 'p-3.5 rounded-xl border-2 border-amber-500 bg-amber-500/20 cursor-pointer transition flex items-center justify-between group shadow-sm';
                if (badgeTria) {
                    badgeTria.className = 'text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-400 text-slate-950';
                    badgeTria.innerText = '✓ AKTİF SEÇİM';
                }
                if (summaryBadge) {
                    summaryBadge.className = 'px-2.5 py-0.5 rounded-full text-[11px] font-black bg-amber-400 text-slate-950';
                    summaryBadge.innerText = 'TRIA ECZANE (Oracle)';
                }
                if (bannerLabel) {
                    bannerLabel.className = 'ml-1.5 text-xs font-black px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30';
                    bannerLabel.innerText = '⚡ TRIA Eczane (Oracle)';
                }
                if (switchTab) switchSettingsTab('tria');
            }

            // Seçim yapıldıktan sonra seçim kartlarını daralt
            const grid = document.getElementById('otoSelectorCardsGrid');
            if (grid && switchTab) grid.classList.add('hidden');

            refreshHeaderActiveOtomasyon();
        }

        function setTebeosProfile(profile) {
            if (profile === 'yerel') {
                document.getElementById('cfg_tebeos_host').value = '127.0.0.1';
                document.getElementById('cfg_tebeos_port').value = '5454';
                document.getElementById('cfg_tebeos_db').value = 'tebeos_db';
                document.getElementById('cfg_tebeos_user').value = 'tebeos';
                document.getElementById('cfg_tebeos_pwd').value = '123';
                showToast('Profil Yüklendi', 'TEBEOS Bu Bilgisayar (127.0.0.1:5454) varsayılan ayarları uygulandı.', 'success');
            }
        }

        async function unlockTebeosLocalTrust() {
            const btn = document.getElementById('btnUnlockTebeosTrust');
            const resDiv = document.getElementById('tebeosDiscoverResult');
            const orig = btn ? btn.innerHTML : '';
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>pg_hba.conf Açılıyor...`;
            }
            if (resDiv) {
                resDiv.className = 'text-[11px] mt-1 text-amber-700 font-medium';
                resDiv.innerText = 'TEBEOS PostgreSQL pg_hba.conf dosyası taranıyor ve trust (şifresiz ağ erişimi) ayarlanıyor...';
                resDiv.classList.remove('hidden');
            }
            try {
                const res = await fetch('/api/tebeos/unlock-trust', { method: 'POST' });
                const data = await res.json();
                if (data.success) {
                    if (resDiv) {
                        resDiv.className = 'text-[11px] mt-1 text-emerald-700 font-bold';
                        resDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>${data.message}`;
                    }
                    showToast('Şifresiz Ağ Erişimi Açıldı', data.message, 'success');
                    setTimeout(() => pingTebeosConnection(), 500);
                } else {
                    if (resDiv) {
                        resDiv.className = 'text-[11px] mt-1 text-rose-600 font-medium';
                        resDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1"></i>${data.message}`;
                    }
                    showToast('Uyarı', data.message || 'Yerel TEBEOS kurulumu bulunamadı.', 'warning');
                }
            } catch (e) {
                if (resDiv) {
                    resDiv.className = 'text-[11px] mt-1 text-rose-600 font-medium';
                    resDiv.innerText = `İşlem hatası: ${e.message}`;
                }
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = orig;
                }
            }
        }

        async function discoverTebeosHost() {
            const btn = document.getElementById('btnDiscoverTebeos');
            const resDiv = document.getElementById('tebeosDiscoverResult');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Taranıyor...`;
            resDiv.className = 'text-[11px] mt-1 text-slate-500 font-medium';
            resDiv.innerText = 'Yerel ağdaki TEBEOS PostgreSQL sunucusu taranıyor (Port 5454)...';
            resDiv.classList.remove('hidden');

            try {
                const res = await fetch('/api/tebeos/discover');
                const data = await res.json();
                if (data.success && data.found) {
                    if (data.host) document.getElementById('cfg_tebeos_host').value = data.host;
                    if (data.port) document.getElementById('cfg_tebeos_port').value = data.port;
                    if (data.database) document.getElementById('cfg_tebeos_db').value = data.database;
                    if (data.user) document.getElementById('cfg_tebeos_user').value = data.user;
                    if (data.password) document.getElementById('cfg_tebeos_pwd').value = data.password;
                    resDiv.className = 'text-[11px] mt-1 text-emerald-700 font-bold';
                    resDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>Bulundu: <strong>${data.host}:${data.port || '5454'}/${data.database || 'tebeos_db'}</strong> (${data.message})`;
                    showToast('TEBEOS Sunucusu Bulundu', `Ağda çalışan TEBEOS PostgreSQL sunucusu (${data.host}) tespit edildi ve tüm alanlar dolduruldu.`, 'success');
                } else {
                    resDiv.className = 'text-[11px] mt-1 text-amber-700 font-medium';
                    resDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1 text-amber-500"></i>${data.message || 'Otomatik tespit edilemedi, lütfen IP adresini elle giriniz.'}`;
                }
            } catch(e) {
                resDiv.className = 'text-[11px] mt-1 text-rose-600 font-medium';
                resDiv.innerText = `Arama hatası: ${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        async function pingTebeosConnection() {
            const btn = document.getElementById('btnPingTebeos');
            const resBox = document.getElementById('tebeosPingResult');
            const origHtml = btn.innerHTML;

            const host = (document.getElementById('cfg_tebeos_host')?.value || '').trim();
            const port = (document.getElementById('cfg_tebeos_port')?.value || '').trim();
            const db = (document.getElementById('cfg_tebeos_db')?.value || '').trim();
            const user = (document.getElementById('cfg_tebeos_user')?.value || '').trim();
            const pwd = (document.getElementById('cfg_tebeos_pwd')?.value || '').trim();

            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i><span>Bağlanıyor...</span>`;
            resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-slate-100 text-slate-600 border border-slate-200';
            resBox.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1.5"></i><strong>${host || '127.0.0.1'}:${port || '5454'}/${db || 'tebeos_db'}</strong> (${user || 'tebeos'}) adresine bağlanılıyor...`;
            resBox.classList.remove('hidden');

            try {
                const params = new URLSearchParams();
                if (host) params.append('host', host);
                if (port) params.append('port', port);
                if (db) params.append('database', db);
                if (user) params.append('user', user);
                if (pwd) params.append('password', pwd);

                const res = await fetch(`/api/tebeos/ping?${params.toString()}`);
                const data = await res.json();
                if (data.success && data.connected) {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-emerald-50 text-emerald-900 border border-emerald-300';
                    resBox.innerHTML = `
                        <div class="flex items-center justify-between border-b border-emerald-200/80 pb-1.5 mb-2">
                            <span class="font-bold text-sm text-emerald-800 flex items-center space-x-1.5">
                                <i class="fa-solid fa-circle-check text-emerald-600"></i>
                                <span>TEBEOS PostgreSQL Bağlantısı Başarılı</span>
                            </span>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-200 text-emerald-900 font-mono">${data.latency_ms} ms</span>
                        </div>
                        <div class="text-[11px] text-emerald-800 space-y-1">
                            <div>Host: <strong class="font-mono text-emerald-950">${data.host}:${data.port}/${data.database}</strong> (Kullanıcı: <strong>${data.user}</strong>)</div>
                            <div>PostgreSQL Sürüm: <strong>${data.version || 'PostgreSQL 12'}</strong></div>
                            <div>Kayıtlı Veri: <strong>${(data.stats && data.stats.kayitli_urun_sayisi) ? data.stats.kayitli_urun_sayisi.toLocaleString() : '-'}</strong> İlaç/Ürün, <strong>${(data.stats && data.stats.toplam_satis_hareketi) ? data.stats.toplam_satis_hareketi.toLocaleString() : '-'}</strong> Satış Hareketi, <strong>${(data.stats && data.stats.fatura_sayisi) ? data.stats.fatura_sayisi.toLocaleString() : '-'}</strong> Fatura</div>
                        </div>
                    `;
                    updateHeaderTebeosStatus(true, data);
                    showToast('TEBEOS Bağlantısı Başarılı', `TEBEOS PostgreSQL veritabanına ${data.latency_ms} ms içinde bağlanıldı.`, 'success');
                } else {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                    resBox.innerHTML = `
                        <div class="font-bold text-sm text-red-800 flex items-center space-x-1.5 mb-1">
                            <i class="fa-solid fa-circle-xmark text-red-600"></i>
                            <span>Bağlantı Başarısız (${data.latency_ms || 0} ms)</span>
                        </div>
                        <div class="text-[11px] text-red-700">
                            <strong>Hata Detayı:</strong> ${data.message || data.error || 'Veritabanı yanıt vermedi.'}
                        </div>
                    `;
                    updateHeaderTebeosStatus(false, data);
                }
            } catch(e) {
                resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                resBox.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5 text-red-600"></i>Bağlantı hatası: ${e.message}`;
                updateHeaderTebeosStatus(false);
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        }

        function updateHeaderTebeosStatus(connected, data) {
            window.tebeosStatus = {
                connected: !!connected,
                latency_ms: (data && data.latency_ms) ? data.latency_ms : null
            };
            const tabBadge = document.getElementById('tabTebeosBadge');
            if (tabBadge) {
                tabBadge.className = connected 
                    ? 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold'
                    : 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold';
                tabBadge.innerText = connected ? 'Bağlı' : 'Kesildi';
            }
            refreshHeaderActiveOtomasyon();
        }

        async function checkTebeosStatusOnLoad() {
            try {
                const res = await fetch('/api/tebeos/ping');
                const data = await res.json();
                updateHeaderTebeosStatus(data.success && data.connected, data);
            } catch(e) {
                updateHeaderTebeosStatus(false);
            }
        }

        function updateHeaderBotanikStatus(connected, data) {
            window.botanikStatus = {
                connected: !!connected,
                latency_ms: (data && data.latency_ms) ? data.latency_ms : null
            };
            const tabBadge = document.getElementById('tabBotanikBadge');
            if (tabBadge) {
                tabBadge.className = connected 
                    ? 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold'
                    : 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold';
                tabBadge.innerText = connected ? 'Bağlı' : 'Kesildi';
            }
            refreshHeaderActiveOtomasyon();
        }

        async function checkBotanikStatusOnLoad() {
            try {
                const res = await fetch('/api/botanik/ping');
                const data = await res.json();
                updateHeaderBotanikStatus(data.success && data.connected, data);
            } catch(e) {
                updateHeaderBotanikStatus(false);
            }
        }

        function setTriaProfile(profile) {
            if (profile === 'yerel') {
                document.getElementById('cfg_tria_host').value = '127.0.0.1';
                document.getElementById('cfg_tria_port').value = '1521';
                document.getElementById('cfg_tria_sid').value = 'ORCL';
                showToast('Profil Yüklendi', 'Bu Bilgisayar (127.0.0.1:1521/ORCL) ayarları uygulandı.', 'success');
            }
        }

        async function discoverTriaHost() {
            const btn = document.getElementById('btnDiscoverHost');
            const resDiv = document.getElementById('discoverResult');
            const hostInput = document.getElementById('cfg_tria_host');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Taranıyor...`;
            resDiv.className = 'text-[11px] mt-1 text-slate-500 font-medium';
            resDiv.innerText = 'Ağdaki TRIA Oracle sunucusu taranıyor (Port 1521/1522)...';
            resDiv.classList.remove('hidden');

            try {
                const res = await fetch('/api/tria/discover');
                const data = await res.json();
                if (data.success && data.found) {
                    hostInput.value = data.host;
                    if (data.port) document.getElementById('cfg_tria_port').value = data.port;
                    if (data.sid) document.getElementById('cfg_tria_sid').value = data.sid;
                    if (data.user) document.getElementById('cfg_tria_user').value = data.user;
                    if (data.password) document.getElementById('cfg_tria_pwd').value = data.password;
                    resDiv.className = 'text-[11px] mt-1 text-emerald-700 font-bold';
                    resDiv.innerHTML = `<i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>Bulundu: <strong>${data.host}:${data.port || '1521'}/${data.sid || 'ORCL'}</strong> (${data.message})`;
                    showToast('TRIA Sunucusu Bulundu', `Ağda çalışan canlı Oracle sunucusu (${data.host}) tespit edildi ve tüm alanlar dolduruldu.`, 'success');
                } else {
                    resDiv.className = 'text-[11px] mt-1 text-amber-700 font-medium';
                    resDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1 text-amber-500"></i>${data.message || 'Otomatik tespit edilemedi, lütfen IP adresini elle giriniz.'}`;
                }
            } catch(e) {
                resDiv.className = 'text-[11px] mt-1 text-rose-600 font-medium';
                resDiv.innerText = `Arama hatası: ${e.message}`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        async function loadAvailableSchemas() {
            const btn = document.getElementById('btnListSchemas');
            const container = document.getElementById('schemaListContainer');
            const pills = document.getElementById('schemaPills');
            const orig = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i>Listeleniyor...`;

            try {
                const res = await fetch('/api/tria/schemas');
                const data = await res.json();
                if (data.success && data.schemas && data.schemas.length > 0) {
                    container.classList.remove('hidden');
                    pills.innerHTML = data.schemas.map(s => `
                        <button type="button" onclick="selectTriaSchema('${s}')" class="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-lg text-xs font-mono font-bold transition flex items-center space-x-1 cursor-pointer">
                            <i class="fa-solid fa-circle-arrow-right text-[10px] text-amber-700"></i>
                            <span>${s}</span>
                        </button>
                    `).join('');
                    showToast('Şemalar Listelendi', `${data.count} eczane şeması bulundu.`, 'success');
                } else {
                    showToast('Bilgi', data.message || 'Eczane şeması bulunamadı.', 'error');
                }
            } catch(e) {
                showToast('Hata', `Şemalar çekilemedi: ${e.message}`, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }

        function selectTriaSchema(schemaName) {
            document.getElementById('cfg_tria_user').value = schemaName;
            const pwdInput = document.getElementById('cfg_tria_pwd');
            if (!pwdInput.value) {
                pwdInput.value = schemaName;
            }
            showToast('Şema Seçildi', `${schemaName} şeması seçildi. Şifre alanı otomatik dolduruldu.`, 'success');
        }

        async function pingTriaConnection() {
            const btn = document.getElementById('btnPingTria');
            const resBox = document.getElementById('triaPingResult');
            const origHtml = btn.innerHTML;

            const host = (document.getElementById('cfg_tria_host')?.value || '').trim();
            const port = (document.getElementById('cfg_tria_port')?.value || '').trim();
            const sid = (document.getElementById('cfg_tria_sid')?.value || '').trim();
            const user = (document.getElementById('cfg_tria_user')?.value || '').trim();
            const pwd = (document.getElementById('cfg_tria_pwd')?.value || '').trim();

            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i><span>Bağlanıyor...</span>`;
            resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-slate-100 text-slate-600 border border-slate-200';
            resBox.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1.5"></i><strong>${host || '127.0.0.1'}:${port || '1521'}/${sid || 'ORCL'}</strong> (${user || 'TRIA'}) adresine bağlanılıyor...`;
            resBox.classList.remove('hidden');

            try {
                const params = new URLSearchParams();
                if (host) params.append('host', host);
                if (port) params.append('port', port);
                if (sid) params.append('sid', sid);
                if (user) params.append('user', user);
                if (pwd) params.append('password', pwd);

                const res = await fetch(`/api/tria/ping?${params.toString()}`);
                const data = await res.json();
                if (data.success && data.connected) {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-emerald-50 text-emerald-900 border border-emerald-300';
                    resBox.innerHTML = `
                        <div class="flex items-center justify-between border-b border-emerald-200/80 pb-1.5 mb-2">
                            <span class="font-bold text-sm text-emerald-800 flex items-center space-x-1.5">
                                <i class="fa-solid fa-circle-check text-emerald-600"></i>
                                <span>Oracle Bağlantısı Başarılı</span>
                            </span>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-200 text-emerald-900 font-mono">${data.latency_ms} ms</span>
                        </div>
                        <div class="text-[11px] text-emerald-800 space-y-1">
                            <div>Host: <strong class="font-mono text-emerald-950">${data.host}:${data.port}/${data.sid}</strong> (Kullanıcı: <strong>${data.user}</strong>)</div>
                            <div>Oracle Sürüm: <strong>${data.version || '11.2'}</strong></div>
                            <div>Kayıtlı Veri: <strong>${(data.stats && data.stats.recete_sayisi) ? data.stats.recete_sayisi.toLocaleString() : '-'}</strong> Reçete, <strong>${(data.stats && data.stats.kayitli_urun_sayisi) ? data.stats.kayitli_urun_sayisi.toLocaleString() : '-'}</strong> Kayıtlı Ürün</div>
                        </div>
                    `;
                    updateHeaderTriaStatus(true, data);
                    showToast('Oracle Bağlantısı Başarılı', `Tria veritabanına ${data.latency_ms} ms içinde bağlanıldı.`, 'success');
                } else {
                    resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                    resBox.innerHTML = `
                        <div class="font-bold text-sm text-red-800 flex items-center space-x-1.5 mb-1">
                            <i class="fa-solid fa-circle-xmark text-red-600"></i>
                            <span>Bağlantı Başarısız (${data.latency_ms || 0} ms)</span>
                        </div>
                        <div class="text-[11px] text-red-700">
                            <strong>Hata Detayı:</strong> ${data.message || data.error || 'Veritabanı yanıt vermedi.'}
                        </div>
                    `;
                    updateHeaderTriaStatus(false, data);
                }
            } catch(e) {
                resBox.className = 'mt-3 p-3.5 rounded-2xl text-xs bg-red-50 text-red-900 border border-red-300';
                resBox.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5 text-red-600"></i>Bağlantı hatası: ${e.message}`;
                updateHeaderTriaStatus(false);
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        }

        function updateHeaderTriaStatus(connected, data) {
            window.triaStatus = {
                connected: !!connected,
                latency_ms: (data && data.latency_ms) ? data.latency_ms : null
            };
            const hostBadge = document.getElementById('triaHostSubBadge');
            const tabTriaBadge = document.getElementById('tabTriaBadge');

            if (hostBadge && data && data.host) {
                hostBadge.innerText = `${data.host} (${data.user || 'TRIA'})`;
            }
            if (tabTriaBadge) {
                tabTriaBadge.className = connected
                    ? 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold'
                    : 'ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold';
                tabTriaBadge.innerText = connected ? 'Bağlı' : 'Kesildi';
            }
            refreshHeaderActiveOtomasyon();
        }

        async function checkTriaStatusOnLoad() {
            try {
                const res = await fetch('/api/tria/ping');
                const data = await res.json();
                updateHeaderTriaStatus(data.success && data.connected, data);
            } catch(e) {
                updateHeaderTriaStatus(false);
            }
        }

        // ==========================================
        // DEPO AKTİF / PASİF YÖNETİMİ & VALIDASYONU
        // ==========================================
        const DEPO_LIST = ['alliance', 'selcuk', 'nevzat', 'iskoop', 'bek', 'ecza1', 'farmazon', 'dna', 'eczatrend', 'eczanetakas'];

        function hasDepoCredentials(depo) {
            if (depo === 'alliance') {
                const p = (document.getElementById('cfg_alliance_pcode')?.value || '').trim();
                const u = (document.getElementById('cfg_alliance_user')?.value || '').trim();
                const pwd = (document.getElementById('cfg_alliance_pwd')?.value || '').trim();
                return !!(p && u && pwd);
            }
            if (depo === 'nevzat') {
                const a = (document.getElementById('cfg_nevzat_account')?.value || '').trim();
                const u = (document.getElementById('cfg_nevzat_user')?.value || '').trim();
                const pwd = (document.getElementById('cfg_nevzat_pwd')?.value || '').trim();
                return !!(a && u && pwd);
            }
            const u = (document.getElementById(`cfg_${depo}_user`)?.value || '').trim();
            const pwd = (document.getElementById(`cfg_${depo}_pwd`)?.value || '').trim();
            return !!(u && pwd);
        }

        function updateDepoCardUI(depo) {
            const chk = document.getElementById(`cfg_${depo}_active`);
            const badge = document.getElementById(`badge_${depo}_status`);
            const card = document.getElementById(`card_${depo}`);
            if (!chk || !badge) return;

            const hasCreds = hasDepoCredentials(depo);

            if (!hasCreds) {
                chk.checked = false;
                badge.className = 'hidden';
                badge.innerHTML = '';
                if (card) {
                    card.classList.add('opacity-70');
                    card.classList.remove('ring-2', 'ring-emerald-400');
                }
            } else if (chk.checked) {
                badge.className = 'text-[11px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-200 inline-block cursor-pointer select-none';
                badge.innerHTML = '● Aktif';
                badge.title = 'Pasif yapmak için tıklayın';
                if (card) {
                    card.classList.remove('opacity-70');
                }
            } else {
                badge.className = 'text-[11px] font-bold text-slate-500 bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded-full border border-slate-200 inline-block cursor-pointer select-none';
                badge.innerHTML = '○ Pasif';
                badge.title = 'Aktif yapmak için tıklayın';
                if (card) {
                    card.classList.add('opacity-70');
                    card.classList.remove('ring-2', 'ring-emerald-400');
                }
            }
        }

        function toggleDepoActiveFromBadge(depo) {
            const chk = document.getElementById(`cfg_${depo}_active`);
            if (!chk) return;
            chk.checked = !chk.checked;
            onDepoActiveToggle(depo);
        }

        function updateDepoTabSummary() {
            const summaryBadge = document.getElementById('depoTabSummaryBadge');
            let activeCount = 0;
            DEPO_LIST.forEach(d => {
                const chk = document.getElementById(`cfg_${d}_active`);
                const hasCreds = hasDepoCredentials(d);
                if (chk && chk.checked && hasCreds) {
                    activeCount++;
                }
            });
            if (summaryBadge) {
                summaryBadge.innerHTML = `<span class="inline-flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span> <strong class="text-emerald-800">${activeCount} Depo Aktif</strong></span>`;
            }
        }

        function onDepoActiveToggle(depo) {
            const chk = document.getElementById(`cfg_${depo}_active`);
            if (!chk) return;
            const hasCreds = hasDepoCredentials(depo);
            if (chk.checked && !hasCreds) {
                chk.checked = false;
                const feedback = document.getElementById('settingsFeedback');
                if (feedback) {
                    feedback.className = 'p-3 rounded-xl text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200 mb-3 block';
                    feedback.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5 text-amber-600"></i><strong>${depo.toUpperCase()}</strong> için kullanıcı adı ve şifre girilmediğinden aktif edilemez.`;
                    feedback.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }
            } else {
                if (!chk.checked) {
                    chk.dataset.manuallyDeactivated = "true";
                } else {
                    delete chk.dataset.manuallyDeactivated;
                }
            }
            updateDepoCardUI(depo);
            updateDepoTabSummary();
        }

        function onDepoCredInput(depo) {
            const chk = document.getElementById(`cfg_${depo}_active`);
            if (!chk) return;
            const hasCreds = hasDepoCredentials(depo);
            if (!hasCreds) {
                chk.checked = false;
            } else {
                chk.checked = true;
                delete chk.dataset.manuallyDeactivated;
            }
            updateDepoCardUI(depo);
            updateDepoTabSummary();
        }

        function updateHeaderDepoBadge(activeCount, totalCount = 7) {
            const text = document.getElementById('headerDepoText');
            const dot = document.getElementById('headerDepoDot');
            const btn = document.getElementById('headerDepoBadgeBtn');
            if (!text || !dot) return;

            if (activeCount > 0) {
                text.innerText = `${activeCount} Depo Aktif`;
                dot.className = "w-2 h-2 rounded-full bg-emerald-500 mr-0.5";
                if (btn) btn.className = "inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border border-emerald-200 bg-emerald-50/90 text-emerald-800 text-xs font-semibold hover:bg-emerald-100 transition shadow-sm cursor-pointer";
            } else {
                text.innerText = "0 Depo Aktif";
                dot.className = "w-2 h-2 rounded-full bg-slate-400 mr-0.5";
                if (btn) btn.className = "inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 text-xs font-semibold hover:bg-slate-100 transition shadow-sm cursor-pointer";
            }
        }

        window.activeBulkDepos = ['ALLIANCE', 'SELCUK', 'ISKOOP', 'NEVZAT'];

        function getActiveBulkDepos() {
            if (Array.isArray(window.activeBulkDepos) && window.activeBulkDepos.length > 0) {
                return window.activeBulkDepos;
            }
            return ['ALLIANCE', 'SELCUK', 'ISKOOP', 'NEVZAT'];
        }

        function isBulkDepoActive(depoKey) {
            const k = String(depoKey || '').toUpperCase();
            return getActiveBulkDepos().includes(k);
        }

        function applyActiveDeposToUI() {
            const activeList = getActiveBulkDepos();
            window.defaultQuickDepo = activeList[0] || 'ALLIANCE';

            // 1. Günün Çıkışları ve 6 Aylık Sipariş ekranlarındaki tüm depo butonlarını aktif depolara göre göster/gizle
            document.querySelectorAll('[data-depo-btn]').forEach(btn => {
                const depo = String(btn.getAttribute('data-depo-btn') || '').toUpperCase();
                if (activeList.includes(depo)) {
                    btn.classList.remove('hidden');
                } else {
                    btn.classList.add('hidden');
                }
            });

            // 2. Günün Çıkışları kartlarında aktif olmayan bir depo seçiliyse ilk aktif depoya çevir ve listeyi yenile
            if (window.cardSelectedDepos) {
                Object.keys(window.cardSelectedDepos).forEach(idx => {
                    if (!activeList.includes(window.cardSelectedDepos[idx])) {
                        window.cardSelectedDepos[idx] = window.defaultQuickDepo;
                    }
                });
            }
            if (typeof renderCriticalList === 'function' && Array.isArray(window.criticalStockItems) && window.criticalStockItems.length > 0) {
                renderCriticalList();
            }

            // 3. 6 Aylık Sipariş satırlarında aktif olmayan bir depo seçiliyse ilk aktif depoya çevir ve tabloyu yenile
            if (window.smartRowDepos) {
                Object.keys(window.smartRowDepos).forEach(key => {
                    if (!activeList.includes(window.smartRowDepos[key])) {
                        window.smartRowDepos[key] = window.defaultQuickDepo;
                    }
                });
            }
            if (typeof renderSmartOrderTable === 'function' && window.smartOrderLoadedOnce) {
                renderSmartOrderTable();
            }
        }

        async function refreshDepoStatusBadge() {
            try {
                const res = await fetch('/api/settings/credentials');
                if (res.ok) {
                    const c = await res.json();
                    let activeCount = 0;
                    DEPO_LIST.forEach(d => {
                        if (c[d] && (c[d].active === "1" || c[d].active === true || c[d].active === 1)) {
                            activeCount++;
                        }
                    });
                    updateHeaderDepoBadge(activeCount, DEPO_LIST.length);

                    // Toplu sipariş destekleyen 4 ana deponun (ALLIANCE, SELCUK, ISKOOP, NEVZAT) aktiflik durumunu tespit et
                    const bulkCandidates = [
                        { key: 'ALLIANCE', cfg: c.alliance || {}, req: ['pharmacy_code', 'username', 'password'] },
                        { key: 'SELCUK', cfg: c.selcuk || {}, req: ['username', 'password'] },
                        { key: 'ISKOOP', cfg: c.iskoop || {}, req: ['username', 'password'] },
                        { key: 'NEVZAT', cfg: c.nevzat || {}, req: ['account_code', 'username', 'password'] }
                    ];
                    const detectedBulkDepos = [];
                    bulkCandidates.forEach(item => {
                        const isAct = (item.cfg.active === "1" || item.cfg.active === true || item.cfg.active === 1);
                        const hasCreds = item.req.every(field => Boolean((item.cfg[field] || '').trim()));
                        if (isAct && hasCreds) {
                            detectedBulkDepos.push(item.key);
                        }
                    });
                    window.activeBulkDepos = detectedBulkDepos.length > 0
                        ? detectedBulkDepos
                        : ['ALLIANCE', 'SELCUK', 'ISKOOP', 'NEVZAT'];
                    applyActiveDeposToUI();

                    const etCfg = c.eczanetakas || {};
                    const isEtEnabled = Boolean(
                        (etCfg.username || '').trim() &&
                        (etCfg.password || '').trim() &&
                        (etCfg.active === "1" || etCfg.active === true || etCfg.active === 1)
                    );
                    window.isEczaneTakasActive = isEtEnabled;
                    const etChip = document.getElementById('etQuickOffersChipBtn');
                    if (etChip) {
                        if (isEtEnabled) {
                            etChip.classList.remove('hidden');
                            etChip.classList.add('flex');
                        } else {
                            etChip.classList.add('hidden');
                            etChip.classList.remove('flex');
                        }
                    }
                    if (typeof window.syncEtCampaignBarVisibility === 'function') {
                        window.syncEtCampaignBarVisibility();
                    }
                    const etrCfg = c.eczatrend || {};
                    const isEtrEnabled = Boolean(
                        (etrCfg.username || '').trim() &&
                        (etrCfg.password || '').trim() &&
                        (etrCfg.active === "1" || etrCfg.active === true || etrCfg.active === 1)
                    );
                    window.isEczatrendActive = isEtrEnabled;
                    const etrChip = document.getElementById('eczatrendQuickOffersChipBtn');
                    if (etrChip) {
                        if (isEtrEnabled) {
                            etrChip.classList.remove('hidden');
                            etrChip.classList.add('flex');
                        } else {
                            etrChip.classList.add('hidden');
                            etrChip.classList.remove('flex');
                        }
                    }
                    if (typeof window.syncEtCampaignBarVisibility === 'function') {
                        window.syncEtCampaignBarVisibility();
                    }
                }
            } catch(e) {
                console.error("Depo durum bilgisi alınamadı:", e);
            }
        }

        async function openSettingsModal(defaultTab = null) {
            const modal = document.getElementById('settingsModal');
            const feedback = document.getElementById('settingsFeedback');
            if (feedback) feedback.className = 'hidden';
            lockAdminSettingsPanel();

            let activeOtoUpper = (window.activeOtomasyon || 'BOTANIK').toUpperCase();
            if (activeOtoUpper === 'ECZANEM') activeOtoUpper = 'BOTANIK';
            selectActiveOtomasyon(activeOtoUpper, false);
            const activeTab = defaultTab || (activeOtoUpper === 'TEBEOS' ? 'tebeos' : (activeOtoUpper === 'TRIA' ? 'tria' : 'botanik'));
            switchSettingsTab(activeTab);
            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
            }

            try {
                const res = await fetch('/api/settings/credentials');
                if (res.ok) {
                    const c = await res.json();
                    if (c.active_otomasyon) {
                        selectActiveOtomasyon(c.active_otomasyon, defaultTab !== null ? false : true);
                    }
                    if (c.alliance) {
                        document.getElementById('cfg_alliance_pcode').value = c.alliance.pharmacy_code || '';
                        document.getElementById('cfg_alliance_user').value = c.alliance.username || '';
                        document.getElementById('cfg_alliance_pwd').value = c.alliance.password || '';
                    }
                    if (c.selcuk) {
                        document.getElementById('cfg_selcuk_user').value = c.selcuk.username || '';
                        document.getElementById('cfg_selcuk_pwd').value = c.selcuk.password || '';
                    }
                    if (c.nevzat) {
                        document.getElementById('cfg_nevzat_account').value = c.nevzat.account_code || '';
                        document.getElementById('cfg_nevzat_user').value = c.nevzat.username || '';
                        document.getElementById('cfg_nevzat_pwd').value = c.nevzat.password || '';
                    }
                    if (c.iskoop) {
                        document.getElementById('cfg_iskoop_user').value = c.iskoop.username || '';
                        document.getElementById('cfg_iskoop_pwd').value = c.iskoop.password || '';
                    }
                    if (c.bek) {
                        document.getElementById('cfg_bek_user').value = c.bek.username || '';
                        document.getElementById('cfg_bek_pwd').value = c.bek.password || '';
                    }
                    if (c.ecza1) {
                        document.getElementById('cfg_ecza1_user').value = c.ecza1.username || '';
                        document.getElementById('cfg_ecza1_pwd').value = c.ecza1.password || '';
                    }
                    if (c.farmazon) {
                        document.getElementById('cfg_farmazon_user').value = c.farmazon.username || '';
                        document.getElementById('cfg_farmazon_pwd').value = c.farmazon.password || '';
                    }
                    if (c.dna) {
                        document.getElementById('cfg_dna_user').value = c.dna.username || '';
                        document.getElementById('cfg_dna_pwd').value = c.dna.password || '';
                    }
                    if (c.eczatrend) {
                        document.getElementById('cfg_eczatrend_user').value = c.eczatrend.username || '';
                        document.getElementById('cfg_eczatrend_pwd').value = c.eczatrend.password || '';
                    }
                    if (c.eczanetakas) {
                        document.getElementById('cfg_eczanetakas_user').value = c.eczanetakas.username || '';
                        document.getElementById('cfg_eczanetakas_pwd').value = c.eczanetakas.password || '';
                    }
                    if (c.tria) {
                        document.getElementById('cfg_tria_host').value = c.tria.host || '';
                        document.getElementById('cfg_tria_port').value = c.tria.port || '1521';
                        document.getElementById('cfg_tria_sid').value = c.tria.sid || 'ORCL';
                        document.getElementById('cfg_tria_user').value = c.tria.user || '';
                        document.getElementById('cfg_tria_pwd').value = c.tria.password || '';
                    }
                    if (c.botanik) {
                        document.getElementById('cfg_botanik_server').value = c.botanik.server || '.\\\\BOTANIKSQL';
                        document.getElementById('cfg_botanik_db').value = c.botanik.database || 'eczane';
                        document.getElementById('cfg_botanik_user').value = c.botanik.user || 'sa';
                        document.getElementById('cfg_botanik_pwd').value = c.botanik.password || '123';
                        document.getElementById('cfg_botanik_trusted').checked = (c.botanik.trusted === 'true' || c.botanik.trusted === true);
                    }
                    if (c.tebeos) {
                        document.getElementById('cfg_tebeos_host').value = c.tebeos.host || '';
                        document.getElementById('cfg_tebeos_port').value = c.tebeos.port || '5454';
                        document.getElementById('cfg_tebeos_db').value = c.tebeos.database || 'tebeos_db';
                        document.getElementById('cfg_tebeos_user').value = c.tebeos.user || 'tebeos';
                        document.getElementById('cfg_tebeos_pwd').value = c.tebeos.password || '123';
                    }
                    if (c.active_otomasyon) {
                        const sel = document.getElementById('cfg_active_otomasyon');
                        if (sel) sel.value = c.active_otomasyon;
                    }

                    // Depo Kartlarının Aktif/Pasif durumlarını ve rozetlerini ayarla
                    DEPO_LIST.forEach(d => {
                        const chk = document.getElementById(`cfg_${d}_active`);
                        if (!chk) return;
                        const dData = c[d] || {};
                        const hasCreds = hasDepoCredentials(d);
                        const isUserPasif = dData.user_pasif === "1" || dData.user_pasif === true;
                        const isActive = hasCreds && !isUserPasif && (dData.active === "1" || dData.active === true || dData.active === 1 || dData.active === undefined);
                        chk.checked = isActive;
                        if (!isActive && hasCreds && isUserPasif) {
                            chk.dataset.manuallyDeactivated = "true";
                        } else {
                            delete chk.dataset.manuallyDeactivated;
                        }
                        updateDepoCardUI(d);
                    });
                    updateDepoTabSummary();
                }
            } catch(e) {
                console.error("Ayarlar yüklenemedi:", e);
            }
        }

        function closeSettingsModal() {
            lockAdminSettingsPanel();
            const modal = document.getElementById('settingsModal');
            if (modal) {
                modal.style.display = 'none';
                modal.classList.add('hidden');
            }
        }

        // Modal dışına tıklandığında kazara kapanmayı engelle (kullanıcı sadece X veya Vazgeç butonuyla kapatabilir)
        // window.addEventListener('click', function(e) { if (e.target === modal) closeSettingsModal(); });

        async function saveSettings() {
            const btn = document.getElementById('saveSettingsBtn');
            const feedback = document.getElementById('settingsFeedback');
            const origHtml = btn.innerHTML;

            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner animate-spin mr-1"></i><span>Kaydediliyor...</span>`;
            feedback.className = 'hidden';

            const payload = {
                alliance: {
                    pharmacy_code: document.getElementById('cfg_alliance_pcode').value.trim(),
                    username: document.getElementById('cfg_alliance_user').value.trim(),
                    password: document.getElementById('cfg_alliance_pwd').value.trim(),
                    active: document.getElementById('cfg_alliance_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_alliance_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                selcuk: {
                    username: document.getElementById('cfg_selcuk_user').value.trim(),
                    password: document.getElementById('cfg_selcuk_pwd').value.trim(),
                    active: document.getElementById('cfg_selcuk_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_selcuk_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                nevzat: {
                    account_code: document.getElementById('cfg_nevzat_account').value.trim(),
                    username: document.getElementById('cfg_nevzat_user').value.trim(),
                    password: document.getElementById('cfg_nevzat_pwd').value.trim(),
                    active: document.getElementById('cfg_nevzat_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_nevzat_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                iskoop: {
                    username: document.getElementById('cfg_iskoop_user').value.trim(),
                    password: document.getElementById('cfg_iskoop_pwd').value.trim(),
                    active: document.getElementById('cfg_iskoop_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_iskoop_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                bek: {
                    username: document.getElementById('cfg_bek_user').value.trim(),
                    password: document.getElementById('cfg_bek_pwd').value.trim(),
                    active: document.getElementById('cfg_bek_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_bek_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                ecza1: {
                    username: document.getElementById('cfg_ecza1_user').value.trim(),
                    password: document.getElementById('cfg_ecza1_pwd').value.trim(),
                    active: document.getElementById('cfg_ecza1_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_ecza1_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                farmazon: {
                    username: document.getElementById('cfg_farmazon_user').value.trim(),
                    password: document.getElementById('cfg_farmazon_pwd').value.trim(),
                    active: document.getElementById('cfg_farmazon_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_farmazon_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                dna: {
                    username: document.getElementById('cfg_dna_user').value.trim(),
                    password: document.getElementById('cfg_dna_pwd').value.trim(),
                    active: document.getElementById('cfg_dna_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_dna_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                eczatrend: {
                    username: document.getElementById('cfg_eczatrend_user').value.trim(),
                    password: document.getElementById('cfg_eczatrend_pwd').value.trim(),
                    active: document.getElementById('cfg_eczatrend_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_eczatrend_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                eczanetakas: {
                    username: document.getElementById('cfg_eczanetakas_user').value.trim(),
                    password: document.getElementById('cfg_eczanetakas_pwd').value.trim(),
                    active: document.getElementById('cfg_eczanetakas_active').checked ? "1" : "0",
                    user_pasif: document.getElementById('cfg_eczanetakas_active').dataset.manuallyDeactivated === "true" ? "1" : "0"
                },
                tria: {
                    host: document.getElementById('cfg_tria_host').value.trim(),
                    port: document.getElementById('cfg_tria_port').value.trim(),
                    sid: document.getElementById('cfg_tria_sid').value.trim(),
                    user: document.getElementById('cfg_tria_user').value.trim(),
                    password: document.getElementById('cfg_tria_pwd').value.trim()
                },
                botanik: {
                    server: document.getElementById('cfg_botanik_server').value.trim(),
                    database: document.getElementById('cfg_botanik_db').value.trim(),
                    user: document.getElementById('cfg_botanik_user').value.trim(),
                    password: document.getElementById('cfg_botanik_pwd').value.trim(),
                    trusted: document.getElementById('cfg_botanik_trusted').checked ? 'true' : 'false'
                },
                tebeos: {
                    host: document.getElementById('cfg_tebeos_host').value.trim(),
                    port: document.getElementById('cfg_tebeos_port').value.trim(),
                    database: document.getElementById('cfg_tebeos_db').value.trim(),
                    user: document.getElementById('cfg_tebeos_user').value.trim(),
                    password: document.getElementById('cfg_tebeos_pwd').value.trim()
                },
                active_otomasyon: document.getElementById('cfg_active_otomasyon') ? document.getElementById('cfg_active_otomasyon').value : 'TRIA'
            };

            try {
                const res = await fetch('/api/settings/credentials', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const data = await res.json();
                if (res.ok && data.success) {
                    feedback.className = 'p-3 rounded-xl text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 block';
                    feedback.innerHTML = `
                        <div class="flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-circle-check text-emerald-600 text-sm"></i><span>${data.message || 'Ayarlar ve tercihler başarıyla kaydedildi!'}</span></span>
                            <button type="button" onclick="closeSettingsModal()" class="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition shadow-xs cursor-pointer">Kapat</button>
                        </div>
                    `;
                    feedback.classList.remove('hidden');
                    refreshDepoStatusBadge();
                    checkBotanikStatusOnLoad();
                    checkTriaStatusOnLoad();
                    checkTebeosStatusOnLoad();
                    if (typeof loadCriticalStockList === 'function') loadCriticalStockList(true);
                    showToast('Ayarlar Kaydedildi', 'Tüm tercihler ve bağlantı bilgileri kaydedildi.', 'success');
                } else {
                    throw new Error(data.error || 'Kaydetme sırasında bir hata oluştu');
                }
            } catch(e) {
                feedback.className = 'p-3 rounded-xl text-xs font-semibold bg-red-50 text-red-800 border border-red-200 block';
                feedback.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${e.message}`;
                feedback.classList.remove('hidden');
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        }

        // ==========================================
        // E-TİCARET & PİYASA FİYAT KIYASLAMA MODÜLÜ JS
        // ==========================================
        window.currentMarketReport = null;
        window.currentSelectedMarketPlatform = 'ALL';

        function switchMainView(tab) {
            const btnDepo = document.getElementById('mainTabDepo');
            const btnSmart = document.getElementById('mainTabSmartOrder');
            const btnMarket = document.getElementById('mainTabMarket');
            const viewDepo = document.getElementById('viewDepo');
            const viewSmart = document.getElementById('viewSmartOrder');
            const viewMarket = document.getElementById('viewMarket');

            const activeBtnCls = 'py-1.5 px-3 rounded-lg bg-white text-indigo-700 shadow-2xs font-bold text-xs flex items-center space-x-1.5 transition cursor-pointer shrink-0 whitespace-nowrap';
            const inactiveBtnCls = 'py-1.5 px-3 rounded-lg text-slate-600 hover:text-slate-900 font-semibold text-xs flex items-center space-x-1.5 transition cursor-pointer shrink-0 whitespace-nowrap';

            if (viewDepo) viewDepo.classList.add('hidden');
            if (viewSmart) viewSmart.classList.add('hidden');
            if (viewMarket) viewMarket.classList.add('hidden');

            if (btnDepo) btnDepo.className = inactiveBtnCls;
            if (btnSmart) btnSmart.className = inactiveBtnCls;
            if (btnMarket) btnMarket.className = inactiveBtnCls;

            if (tab === 'depo') {
                if (viewDepo) viewDepo.classList.remove('hidden');
                if (btnDepo) btnDepo.className = activeBtnCls;
            } else if (tab === 'smart_order') {
                if (viewSmart) viewSmart.classList.remove('hidden');
                if (btnSmart) btnSmart.className = activeBtnCls;
                if (!window.smartOrderLoadedOnce) {
                    loadSmartOrderList(false);
                }
            } else if (tab === 'market') {
                if (viewMarket) viewMarket.classList.remove('hidden');
                if (btnMarket) btnMarket.className = activeBtnCls;

                const marketInput = document.getElementById('marketSearchInput');
                const depoInput = document.getElementById('searchInput');
                const latestDepoQuery = (
                    (typeof currentReport !== 'undefined' && currentReport && (currentReport.urun_adi || currentReport.barkod))
                        ? (currentReport.urun_adi || currentReport.barkod)
                        : ((depoInput && depoInput.value.trim()) ? depoInput.value.trim() : (window.lastDepoSearchQuery || ''))
                ).trim();

                if (marketInput && latestDepoQuery) {
                    marketInput.value = latestDepoQuery;
                    const rep = window.currentMarketReport;
                    if (rep) {
                        const repName = String(rep.urun_adi || rep.aranan_kelime || '').trim().toLowerCase();
                        const repBc = String(rep.barkod || '').trim();
                        const depoBc = String((typeof currentReport !== 'undefined' && currentReport && currentReport.barkod) || window.lastDepoSearchBarcode || '').trim();
                        const qLower = latestDepoQuery.toLowerCase();
                        const isSameProduct = (depoBc && repBc && depoBc === repBc) || (repName && (repName === qLower || repName.includes(qLower) || qLower.includes(repName)));
                        if (!isSameProduct) {
                            const resultsEl = document.getElementById('marketResults');
                            const emptyEl = document.getElementById('marketEmptyState');
                            if (resultsEl) resultsEl.classList.add('hidden');
                            if (emptyEl) emptyEl.classList.remove('hidden');
                        }
                    }
                }
                const marketSuggestBox = document.getElementById('marketSuggestBox');
                if (marketSuggestBox) marketSuggestBox.classList.add('hidden');
                if (marketInput) marketInput.focus();
            }
        }

        // =========================================================================
        // TOPLU SİPARİŞ PLANLAMA MODÜLÜ JS
        // =========================================================================
        window.smartOrderItems = [];
        window.smartOrderFiltered = [];
        window.smartOrderMonths = [];
        window.smartOrderScope = 'today';
        window.smartTargetDays = 15;
        window.smartTrendFilter = 'ALL';
        window.smartStockMaxDays = 21;
        window.smartOrderQtyMode = 'auto'; // 'manual' veya 'auto'
        window.smartRowDepos = {};
        window.smartRowCustomQty = {};
        window.smartRowManualLocked = {};
        window.smartRowCheckedMap = {};
        window.smartOrderLoadedOnce = false;
        window.isSmartMfScanning = false;

        function parseAllMfTiers(mfStr) {
            if (!mfStr || mfStr === 'YOK' || mfStr === '-') return [];
            const s = String(mfStr);
            const regex = /([0-9]+)\\s*\\+\\s*([0-9]+)/g;
            const tiers = [];
            const seen = new Set();
            let m;
            while ((m = regex.exec(s)) !== null) {
                const alinan = parseInt(m[1], 10) || 0;
                const hediye = parseInt(m[2], 10) || 0;
                if (alinan > 0 && hediye > 0) {
                    const text = `${alinan}+${hediye}`;
                    if (!seen.has(text)) {
                        seen.add(text);
                        tiers.push({ alinan, hediye, text });
                    }
                }
            }
            tiers.sort((a, b) => a.alinan - b.alinan);
            return tiers;
        }
        window.parseAllMfTiers = parseAllMfTiers;

        function parseMfPair(mfStr) {
            const tiers = parseAllMfTiers(mfStr);
            return tiers.length > 0 ? tiers[0] : null;
        }
        window.parseMfPair = parseMfPair;

        function normalizeDepoCode(rawDepo) {
            const fallback = (typeof getActiveBulkDepos === 'function' && getActiveBulkDepos().length > 0)
                ? getActiveBulkDepos()[0]
                : 'ALLIANCE';
            if (!rawDepo) return fallback;
            const u = String(rawDepo).toUpperCase();
            let candidate = fallback;
            if (u.includes('SELCUK') || u.includes('SELÇUK')) candidate = 'SELCUK';
            else if (u.includes('ISKOOP') || u.includes('İSKOOP')) candidate = 'ISKOOP';
            else if (u.includes('NEVZAT')) candidate = 'NEVZAT';
            else if (u.includes('ALLIANCE') || u.includes('HEDEF')) candidate = 'ALLIANCE';
            if (typeof isBulkDepoActive === 'function' && !isBulkDepoActive(candidate)) {
                return fallback;
            }
            return candidate;
        }

        function renderSmartOrderRestrictedLockHtml() {
            const st = window.currentLicenseStatus || {};
            const reason = st.message || 'Lisans süreniz dolmuş veya yönetici tarafından kısıtlanmıştır.';
            return `
                <tr>
                    <td colspan="7" class="py-12 px-6">
                        <div class="max-w-xl mx-auto rounded-2xl border-2 border-rose-300 bg-gradient-to-br from-rose-50 via-white to-amber-50 p-6 text-center shadow-md space-y-3">
                            <div class="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center text-xl mx-auto shadow-sm">
                                <i class="fa-solid fa-lock"></i>
                            </div>
                            <h4 class="text-sm font-black text-rose-950 uppercase tracking-wide">🔒 Toplu Sipariş & Akıllı Dağıtım Özelliği Kısıtlanmıştır</h4>
                            <p class="text-xs text-rose-800 font-semibold leading-relaxed">${reason}</p>
                            <div class="pt-2 flex flex-wrap items-center justify-center gap-2">
                                <button type="button" onclick="openLicenseActivationModalFromBanner()" class="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black transition cursor-pointer flex items-center gap-1.5 shadow-sm">
                                    <i class="fa-solid fa-key"></i>
                                    <span>Yeni Lisans Anahtarı Gir</span>
                                </button>
                                <button type="button" onclick="syncLicenseWithCloud(true)" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black transition cursor-pointer flex items-center gap-1.5 shadow-sm">
                                    <i class="fa-solid fa-cloud-arrow-down"></i>
                                    <span>Online Lisans Kontrolü Yap</span>
                                </button>
                            </div>
                        </div>
                    </td>
                </tr>
            `;
        }

        async function loadSmartOrderList(force = false, customSearch = null) {
            const tbody = document.getElementById('smartOrderTableBody');
            if (window.isLicenseRestricted && window.isLicenseRestricted()) {
                if (tbody) tbody.innerHTML = renderSmartOrderRestrictedLockHtml();
                return;
            }
            const refreshIcon = document.getElementById('smartOrderRefreshIcon');
            if (refreshIcon) refreshIcon.classList.add('fa-spin');

            if (tbody && (force || !window.smartOrderLoadedOnce)) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="7" class="py-12 text-center text-slate-500 text-sm">
                            <i class="fa-solid fa-spinner fa-spin text-indigo-500 mr-2 text-lg"></i>Eczane otomasyonu veritabanından stok yeterliliği, çıkış hızları ve geçmiş MF'ler hesaplanıyor...
                        </td>
                    </tr>
                `;
            }

            try {
                const qParam = customSearch !== null ? customSearch : '';
                const url = `/api/otomasyon/smart-order-list?scope=${encodeURIComponent(window.smartOrderScope)}&q=${encodeURIComponent(qParam)}&target_days=${window.smartTargetDays}&limit=250&force=${force}`;
                const res = await fetch(url);
                const data = await res.json();
                if (res.status === 403 || data.license_restricted) {
                    await loadLicenseStatus(false);
                    if (tbody) tbody.innerHTML = renderSmartOrderRestrictedLockHtml();
                    return;
                }
                if (!res.ok) throw new Error(data.error || 'Toplu sipariş servisi yanıt vermedi');

                window.smartOrderLoadedOnce = true;
                window.smartOrderItems = data.items || [];
                window.smartOrderMonths = data.months || [];

                const srcRaw = String(data.source || data.active_otomasyon || 'TRIA').toUpperCase();
                const srcPretty = srcRaw === 'BOTANIK' ? 'Botanik' : (srcRaw === 'TEBEOS' ? 'Tebeos' : 'Tria');
                const srcBadgeEl = document.getElementById('smartOrderSourceBadge');
                if (srcBadgeEl) {
                    srcBadgeEl.innerText = srcPretty;
                }
                const tabLblEl = document.getElementById('mainTabSmartOrderLabel');
                if (tabLblEl) {
                    tabLblEl.innerText = `Toplu Sipariş`;
                }

                // Sekme rozetini güncelle
                const tabBadge = document.getElementById('smartOrderTabBadge');
                if (tabBadge) {
                    tabBadge.classList.remove('hidden');
                    tabBadge.innerText = `${window.smartOrderItems.length}`;
                }

                recalculateSmartOrderClientSide(false);
                renderSmartOrderTable();

                // Arka planda canlı MF taramasını başlat
                setTimeout(() => resolveAllSmartOrderMfs(false), 250);
            } catch (e) {
                console.error('Smart order list error:', e);
                if (tbody) {
                    tbody.innerHTML = `
                        <tr>
                            <td colspan="7" class="py-8 text-center text-rose-600 text-xs bg-rose-50">
                                <i class="fa-solid fa-circle-exclamation mr-1.5 text-base"></i>Toplu sipariş listesi alınamadı: ${e.message}
                            </td>
                        </tr>
                    `;
                }
            } finally {
                if (refreshIcon) refreshIcon.classList.remove('fa-spin');
            }
        }

        function changeSmartOrderScope(newScope) {
            window.smartOrderScope = newScope;
            const scopes = ['today', 'week', 'top6m'];
            const ids = { 'today': 'btnSmartScopeToday', 'week': 'btnSmartScopeWeek', 'top6m': 'btnSmartScopeTop6m' };
            scopes.forEach(s => {
                const el = document.getElementById(ids[s]);
                if (!el) return;
                if (s === newScope) {
                    el.className = 'px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-indigo-600 text-white transition cursor-pointer';
                } else {
                    el.className = 'px-2 py-0.5 rounded-md text-[10.5px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer';
                }
            });
            if (newScope === 'top6m') {
                setSmartStockMaxDays(999, false);
            }
            loadSmartOrderList(false);
        }

        function searchBotanikInSmartOrder() {
            const inp = document.getElementById('smartOrderSearchInput');
            const val = inp ? inp.value.trim() : '';
            if (!val) {
                loadSmartOrderList(false);
                return;
            }
            window.smartOrderScope = 'search';
            setSmartStockMaxDays(999, false);
            loadSmartOrderList(true, val);
        }

        function setSmartOrderQtyMode(mode) {
            window.smartOrderQtyMode = mode === 'manual' ? 'manual' : 'auto';
            const cardManual = document.getElementById('smartModeCardManual');
            const cardAuto = document.getElementById('smartModeCardAuto');
            const btnManual = document.getElementById('btnSmartModeManual');
            const btnAuto = document.getElementById('btnSmartModeAuto');

            if (window.smartOrderQtyMode === 'manual') {
                if (cardManual) cardManual.className = 'flex flex-wrap items-center gap-1';
                if (cardAuto) cardAuto.className = 'hidden';
                if (btnManual) btnManual.className = 'px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-indigo-600 text-white shadow-2xs transition cursor-pointer';
                if (btnAuto) btnAuto.className = 'px-2 py-0.5 rounded-md text-[10.5px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer';
            } else {
                if (cardManual) cardManual.className = 'hidden';
                if (cardAuto) cardAuto.className = 'flex flex-wrap items-center gap-1';
                if (btnManual) btnManual.className = 'px-2 py-0.5 rounded-md text-[10.5px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer';
                if (btnAuto) btnAuto.className = 'px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-indigo-600 text-white shadow-2xs transition cursor-pointer';
            }
        }

        function startCleanManualSmartOrder() {
            setSmartOrderQtyMode('manual');
            window.smartRowCheckedMap = {};
            (window.smartOrderItems || []).forEach(it => {
                const key = it.barkod || it.urun_kodu || it.urun_adi;
                window.smartRowCheckedMap[key] = !!window.smartRowManualLocked[key];
                if (!window.smartRowManualLocked[key]) {
                    window.smartRowCustomQty[key] = 1;
                }
            });
            renderSmartOrderTable();
            showToast('✍️ Sabit Adet Modu', 'İstediğiniz ilacın kutusuna rakam yazın veya hızlı adet butonlarına (1, 2, 3, 5, 10) tıklayın.', 'info');
        }

        function applyBulkCustomQtyToSmartOrder(rawQty) {
            const qty = Math.max(1, Math.min(999, parseInt(rawQty) || 1));
            setSmartOrderQtyMode('manual');
            const fixedInp = document.getElementById('smartBulkFixedQtyInput');
            if (fixedInp) fixedInp.value = qty;

            const checkedBoxes = document.querySelectorAll('.smartRowCheck:checked');
            let targetIndices = [];
            if (checkedBoxes.length > 0) {
                checkedBoxes.forEach(c => targetIndices.push(parseInt(c.dataset.idx)));
            } else {
                (window.smartOrderFiltered || []).forEach((it, idx) => {
                    if (it.siparis_durumu !== 'SIPARIS_VERILDI') targetIndices.push(idx);
                });
            }

            targetIndices.forEach(idx => {
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (!it) return;
                const key = it.barkod || it.urun_kodu || it.urun_adi;
                window.smartRowCustomQty[key] = qty;
                window.smartRowManualLocked[key] = true;
                window.smartRowCheckedMap[key] = true;
            });

            renderSmartOrderTable();
            showToast('Sabit Sipariş Rakamı Uygulandı', `${targetIndices.length} kalem ilacın sipariş adedi ${qty} kutu olarak sabitlendi.`, 'success');
        }

        function setSmartTargetDays(daysVal) {
            const d = Math.max(1, Math.min(365, parseInt(daysVal) || 15));
            window.smartTargetDays = d;
            setSmartOrderQtyMode('auto');

            const customInp = document.getElementById('smartCustomDaysInput');
            if (customInp) customInp.value = d;

            const lbl = document.getElementById('smartTargetDaysLabel');
            if (lbl) lbl.innerText = `${d}G`;

            [1, 7, 10, 15, 21, 30, 45, 60].forEach(preset => {
                const btn = document.getElementById(`btnSmartDays_${preset}`);
                if (!btn) return;
                if (preset === d) {
                    btn.className = `px-2 py-0.5 rounded-md text-[11px] font-bold bg-indigo-600 text-white cursor-pointer`;
                } else {
                    btn.className = `px-2 py-0.5 rounded-md text-[11px] font-bold bg-white hover:bg-indigo-50 text-slate-700 border border-slate-200 cursor-pointer`;
                }
            });

            recalculateSmartOrderClientSide(true);
            renderSmartOrderTable();
            showToast('Hedef Gün Güncellendi', `Sipariş önerileri ${d} günlük hedef stoğa göre yeniden hesaplandı.`, 'success');
        }

        function applyRecommendedToAllInputs() {
            setSmartOrderQtyMode('auto');
            window.smartRowCustomQty = {};
            window.smartRowManualLocked = {};
            window.smartRowCheckedMap = {};
            recalculateSmartOrderClientSide(true);
            renderSmartOrderTable();
            showToast('Önerilen Rakamlar Uygulandı', `Tüm satırlardaki sipariş kutuları ${window.smartTargetDays} günlük akıllı öneriye eşitlendi.`, 'success');
        }

        function setSmartTrendFilter(filterMode) {
            window.smartTrendFilter = filterMode;
            const kpis = {
                'ALL': { id: 'smartKpiAll', active: 'px-2 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-bold cursor-pointer transition flex items-center gap-1', passive: 'px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1' },
                'STABIL': { id: 'smartKpiStabil', active: 'px-2 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-bold cursor-pointer transition flex items-center gap-1', passive: 'px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1' },
                'AZALAN': { id: 'smartKpiAzalan', active: 'px-2 py-1 rounded-lg bg-rose-600 text-white text-[11px] font-bold cursor-pointer transition flex items-center gap-1', passive: 'px-2 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1' },
                'ARTAN': { id: 'smartKpiArtan', active: 'px-2 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-bold cursor-pointer transition flex items-center gap-1', passive: 'px-2 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1' },
                'MF_ONLY': { id: 'smartKpiMf', active: 'px-2 py-1 rounded-lg bg-amber-500 text-white text-[11px] font-bold cursor-pointer transition flex items-center gap-1', passive: 'px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1' },
                'ORDERED': { id: 'smartKpiOrdered', active: 'px-2 py-1 rounded-lg bg-slate-800 text-white text-[11px] font-bold cursor-pointer transition flex items-center gap-1', passive: 'px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1' }
            };
            Object.keys(kpis).forEach(k => {
                const el = document.getElementById(kpis[k].id);
                if (el) el.className = (k === filterMode) ? kpis[k].active : kpis[k].passive;
            });
            renderSmartOrderTable();
        }

        function setSmartStockMaxDays(maxDays, shouldRender = true) {
            window.smartStockMaxDays = maxDays;
            [21, 14, 0, 999].forEach(val => {
                const btn = document.getElementById(`btnSmartStock_${val}`);
                if (!btn) return;
                if (val === maxDays) {
                    btn.className = 'px-2 py-1 rounded-md text-[11px] font-bold bg-indigo-600 text-white transition cursor-pointer';
                } else {
                    btn.className = 'px-2 py-1 rounded-md text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer';
                }
            });
            if (shouldRender) renderSmartOrderTable();
        }

        function recalculateSmartOrderClientSide(resetCustomQty = false) {
            const autoRoundMfEl = document.getElementById('smartAutoRoundMfCheck');
            const autoRoundMf = autoRoundMfEl ? autoRoundMfEl.checked : true;
            const tDays = window.smartTargetDays || 15;

            (window.smartOrderItems || []).forEach(it => {
                const stok = it.stok || 0;
                const bugun = it.bugun_cikis || 0;
                const gunlukHiz = it.gunluk_hiz || 0;
                const son2Ort = it.son2_ort || 0;
                const ilk4Ort = it.ilk4_ort || 0;
                const ort6m = it.ort_aylik_6m || 0;
                const stokGun = it.stok_gun !== undefined ? it.stok_gun : 999;
                const trend = it.trend_kodu || 'STABIL';

                let effHiz = gunlukHiz;
                if (trend === 'AZALAN') {
                    effHiz = Math.min(gunlukHiz, son2Ort / 30.0);
                } else if (trend === 'ARTAN') {
                    effHiz = Math.max(gunlukHiz, son2Ort / 30.0);
                }

                let hamIhtiyac = 0;
                if (tDays <= 1) {
                    if (stok <= 0) {
                        hamIhtiyac = Math.max(1, bugun || 1);
                    } else if (stok < bugun) {
                        hamIhtiyac = Math.max(1, bugun - stok);
                    } else if (stokGun <= 3) {
                        hamIhtiyac = Math.max(1, Math.ceil(effHiz * 2));
                    } else {
                        hamIhtiyac = 0;
                    }
                } else {
                    const hedefToplam = Math.ceil(effHiz * tDays);
                    hamIhtiyac = Math.max(0, hedefToplam - Math.max(0, stok));
                    if (stok <= 0 && (bugun > 0 || it.toplam_6ay > 0) && hamIhtiyac <= 0) {
                        hamIhtiyac = Math.max(1, bugun || 1);
                    }
                    if (trend === 'AZALAN' && stok > 0 && stokGun >= 10) {
                        hamIhtiyac = 0;
                    } else if (trend === 'AZALAN' && hamIhtiyac > 0) {
                        const maxSafe = Math.max(1, Math.ceil((son2Ort / 30.0) * Math.min(tDays, 10)));
                        hamIhtiyac = Math.min(hamIhtiyac, maxSafe);
                    }
                }

                let onerilen = hamIhtiyac;
                let oneriMetni = '';

                const liveTiers = parseAllMfTiers(it.mf_metni);
                // SADECE güncel (anlık) depo MF'si varsa otomatik MF tamamlama yap; eski G.MF'ye göre asla tamamlama yapma!
                const candidateTiers = liveTiers.length > 0 ? liveTiers : [];

                if (trend === 'AZALAN') {
                    oneriMetni = `${ilk4Ort}→${son2Ort}/ay (Düştü)`;
                } else if (trend === 'STABIL' || trend === 'ARTAN') {
                    if (autoRoundMf && candidateTiers.length > 0) {
                        for (let tIdx = 0; tIdx < candidateTiers.length; tIdx++) {
                            const tObj = candidateTiers[tIdx];
                            const minA = tObj.alinan;
                            if (minA <= 1) continue;
                            const mfCoverDays = minA / Math.max(0.15, effHiz);
                            if (hamIhtiyac >= Math.ceil(minA * 0.6) && hamIhtiyac <= minA && mfCoverDays <= Math.max(60, tDays * 2.2)) {
                                onerilen = minA;
                                oneriMetni = `🎁 MF (${tObj.text}) tamamlama`;
                                break;
                            }
                        }
                    }
                    if (!oneriMetni) {
                        oneriMetni = `Aylık ~${ort6m} kt (${tDays}G hedef)`;
                    }
                } else {
                    oneriMetni = `Aralıklı (~${ort6m}/ay)`;
                }

                it.onerilen_siparis = onerilen;
                it.oneri_metni = oneriMetni;

                const key = it.barkod || it.urun_kodu || it.urun_adi;
                if (!window.smartRowManualLocked[key]) {
                    if (resetCustomQty || window.smartRowCustomQty[key] === undefined) {
                        window.smartRowCustomQty[key] = Math.max(1, onerilen > 0 ? onerilen : (bugun > 0 ? bugun : 1));
                    }
                }
                if (it.mf_depo && (!window.smartRowDepos[key])) {
                    window.smartRowDepos[key] = normalizeDepoCode(it.mf_depo);
                }
            });

            updateSmartKpiCounters();
        }

        function updateSmartKpiCounters() {
            const all = window.smartOrderItems || [];
            const setTxt = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = val; };
            setTxt('smartStatTotal', all.length);
            setTxt('smartStatStabil', all.filter(x => x.trend_kodu === 'STABIL').length);
            setTxt('smartStatAzalan', all.filter(x => x.trend_kodu === 'AZALAN').length);
            setTxt('smartStatArtan', all.filter(x => x.trend_kodu === 'ARTAN').length);
            setTxt('smartStatMf', all.filter(x => (x.mf_metni && x.mf_metni !== 'YOK') || x.gecmis_mf_var).length);
            setTxt('smartStatOrdered', all.filter(x => !!x.siparis_durumu).length);
        }

        function renderSmartOrderTable() {
            const tbody = document.getElementById('smartOrderTableBody');
            if (!tbody) return;
            if (window.isLicenseRestricted && window.isLicenseRestricted()) {
                tbody.innerHTML = renderSmartOrderRestrictedLockHtml();
                return;
            }

            const searchInp = document.getElementById('smartOrderSearchInput');
            const q = searchInp ? searchInp.value.trim().toLowerCase() : '';
            const hideOrdEl = document.getElementById('smartHideOrderedCheck');
            const hideOrdered = hideOrdEl ? hideOrdEl.checked : false;
            const maxDays = window.smartStockMaxDays !== undefined ? window.smartStockMaxDays : 21;
            const tFilter = window.smartTrendFilter || 'ALL';

            const filtered = (window.smartOrderItems || []).filter(it => {
                if (hideOrdered && (it.siparis_durumu === 'SIPARIS_VERILDI' || it.siparis_durumu === 'SIPARIS_VERILMEYECEK')) return false;

                if (maxDays === 0) {
                    if ((it.stok || 0) > 0) return false;
                } else if (maxDays < 900) {
                    if ((it.stok || 0) > 0 && (it.stok_gun || 0) > maxDays) return false;
                }

                if (tFilter === 'STABIL' && it.trend_kodu !== 'STABIL') return false;
                if (tFilter === 'AZALAN' && it.trend_kodu !== 'AZALAN') return false;
                if (tFilter === 'ARTAN' && it.trend_kodu !== 'ARTAN') return false;
                if (tFilter === 'MF_ONLY') {
                    const hasMf = (it.mf_metni && it.mf_metni !== 'YOK') || !!it.gecmis_mf_var;
                    if (!hasMf) return false;
                }
                if (tFilter === 'ORDERED' && !it.siparis_durumu) return false;

                if (q && window.smartOrderScope !== 'search') {
                    const nm = (it.urun_adi || '').toLowerCase();
                    const bc = (it.barkod || '').toLowerCase();
                    if (!nm.includes(q) && !bc.includes(q)) return false;
                }
                return true;
            });

            window.smartOrderFiltered = filtered;

            if (filtered.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="7" class="py-10 text-center text-slate-400 text-xs">
                            <i class="fa-solid fa-filter-circle-xmark text-2xl text-slate-300 mb-2 block"></i>
                            Seçili filtre kriterlerine uyan ilaç bulunamadı. Üstteki "Tümü" butonuna tıklayarak filtreyi genişletebilirsiniz.
                        </td>
                    </tr>
                `;
                updateSmartSelectionSummary();
                return;
            }

            const monthDefs = window.smartOrderMonths || [];

            tbody.innerHTML = filtered.map((it, idx) => {
                const key = it.barkod || it.urun_kodu || it.urun_adi;
                const safeBc = (it.barkod || '').replace(/'/g, "\\\\'");
                const safeName = (it.urun_adi || '').replace(/'/g, "\\\\'");
                const stok = it.stok || 0;
                const stokGun = it.stok_gun !== undefined ? it.stok_gun : 999;

                // Kompakt & Net Stok Rozeti
                let stockBadge = '';
                if (stok < 0) {
                    stockBadge = `<span class="px-1.5 py-0.5 rounded-md text-[11px] font-black font-mono bg-rose-600 text-white shadow-2xs inline-block">STOK: ${stok}</span>`;
                } else if (stok === 0) {
                    stockBadge = `<span class="px-1.5 py-0.5 rounded-md text-[11px] font-black font-mono bg-rose-100 text-rose-800 border border-rose-300 inline-block">0 Kt <span class="text-[9px] font-sans">(YOK)</span></span>`;
                } else if (stokGun <= 7) {
                    stockBadge = `<span class="px-1.5 py-0.5 rounded-md text-[11px] font-black font-mono bg-rose-50 text-rose-800 border border-rose-300 inline-block">${stok} Kt <span class="text-[9px] font-sans font-bold">(${stokGun}G)</span></span>`;
                } else if (stokGun <= 14) {
                    stockBadge = `<span class="px-1.5 py-0.5 rounded-md text-[11px] font-black font-mono bg-amber-50 text-amber-900 border border-amber-300 inline-block">${stok} Kt <span class="text-[9px] font-sans font-bold">(${stokGun}G)</span></span>`;
                } else if (stokGun <= 21) {
                    stockBadge = `<span class="px-1.5 py-0.5 rounded-md text-[11px] font-black font-mono bg-sky-50 text-sky-900 border border-sky-300 inline-block">${stok} Kt <span class="text-[9px] font-sans font-bold">(${stokGun}G)</span></span>`;
                } else {
                    stockBadge = `<span class="px-1.5 py-0.5 rounded-md text-[11px] font-black font-mono bg-slate-100 text-slate-800 border border-slate-300 inline-block">${stok} Kt <span class="text-[9px] font-sans font-semibold">(${stokGun > 180 ? '180+' : stokGun}G)</span></span>`;
                }

                // 6 Aylık Çıkış Mini Izgara (Tek hücrede 6 ay yan yana, kompakt)
                const aylikDetay = it.aylik_detay || [];
                let sixMonthStripHtml = '<div class="grid grid-cols-6 gap-0.5 text-center">';
                for (let mIdx = 0; mIdx < 6; mIdx++) {
                    const mObj = aylikDetay[mIdx] || { toplam: 0, nakit: 0, recete: 0 };
                    const mDef = monthDefs[mIdx] || {};
                    const shortLbl = mIdx === 5 ? 'Bu Ay' : (mDef.short || mObj.short || `A${mIdx + 1}`).slice(0, 3);
                    const val = mObj.toplam || 0;
                    const isCur = mIdx === 5;
                    const boxCls = isCur
                        ? 'bg-emerald-50 border border-emerald-300 text-emerald-950 font-black'
                        : (val > 0 ? 'bg-slate-50 border border-slate-200 text-slate-800 font-bold' : 'bg-slate-50/40 border border-slate-100 text-slate-300');
                    sixMonthStripHtml += `
                        <div class="rounded py-0.5 px-0.5 ${boxCls}" title="${mObj.label || shortLbl}: ${val} Kutu (${mObj.recete || 0} Reçete + ${mObj.nakit || 0} Elden)">
                            <div class="text-[7.5px] uppercase text-slate-400 font-bold leading-none">${shortLbl}</div>
                            <div class="font-mono text-[10.5px] leading-tight">${val}</div>
                        </div>
                    `;
                }
                sixMonthStripHtml += '</div>';

                // Trend Rozeti
                const recVal = it.onerilen_siparis || 0;
                let trendBadge = '';
                if (it.trend_kodu === 'STABIL') {
                    trendBadge = `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[9.5px] font-black bg-emerald-100 text-emerald-900 border border-emerald-300">🟢 Stabil</span>`;
                } else if (it.trend_kodu === 'AZALAN') {
                    trendBadge = `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[9.5px] font-black bg-rose-100 text-rose-900 border border-rose-300">📉 Azalan</span>`;
                } else if (it.trend_kodu === 'ARTAN') {
                    trendBadge = `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[9.5px] font-black bg-sky-100 text-sky-900 border border-sky-300">📈 Artan</span>`;
                } else {
                    trendBadge = `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-amber-50 text-amber-900 border border-amber-200">${it.trend_etiket || '⚡ Aralıklı'}</span>`;
                }

                const curQty = window.smartRowCustomQty[key] !== undefined ? window.smartRowCustomQty[key] : Math.max(1, it.onerilen_siparis || 1);
                const isManualLocked = !!window.smartRowManualLocked[key];
                let curDepo = window.smartRowDepos[key] || normalizeDepoCode(it.mf_depo) || (getActiveBulkDepos()[0] || 'ALLIANCE');
                if (!isBulkDepoActive(curDepo)) {
                    curDepo = getActiveBulkDepos()[0] || 'ALLIANCE';
                }
                window.smartRowDepos[key] = curDepo;

                // MF Rozeti (Canlı / Geçmiş — Her MF Kademesi Ayrı Tıklanabilir Kutu)
                const hasLiveMf = it.mf_metni && it.mf_metni !== 'YOK';
                const liveTiers = parseAllMfTiers(it.mf_metni);
                const pastTiers = it.gecmis_mf_var
                    ? parseAllMfTiers(it.gecmis_mf_kisa || `${it.gecmis_mf_min_alim || 10}+${it.gecmis_mf_bedelsiz || 1}`)
                    : [];

                let mfColHtml = '';
                if (hasLiveMf && liveTiers.length > 0) {
                    const clickDepo = normalizeDepoCode(it.mf_depo);
                    const depoShort = (it.mf_depo || 'Depo').slice(0, 8);
                    const tierBtns = liveTiers.map(t => {
                        const isSelTier = (curQty === t.alinan);
                        const btnStyle = isSelTier
                            ? 'bg-emerald-600 text-white ring-1 ring-emerald-300 shadow-2xs'
                            : 'bg-amber-500 hover:bg-amber-600 text-slate-950';
                        return `
                            <button type="button" onclick="applySmartMfToRow(${idx}, ${t.alinan}, '${clickDepo}', '${t.text}')" class="inline-flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9.5px] font-black ${btnStyle} transition cursor-pointer" title="Tıklayın: Sipariş adedini ${t.alinan} kutu yap (${t.text} MF • ${it.mf_depo || 'Depo'})">
                                <i class="fa-solid ${isSelTier ? 'fa-check' : 'fa-gift'} text-[8px]"></i>
                                <span>${t.text}</span>
                            </button>
                        `;
                    }).join('');
                    mfColHtml += `${tierBtns}<span class="px-1 py-0.2 rounded bg-slate-200/80 text-slate-700 text-[8.5px] font-extrabold">${depoShort}</span>`;
                } else if (hasLiveMf) {
                    const clickDepo = normalizeDepoCode(it.mf_depo);
                    const safeMfText = String(it.mf_metni || '').replace(/'/g, "\\\\'");
                    mfColHtml += `
                        <button type="button" onclick="applySmartMfToRow(${idx}, 10, '${clickDepo}', '${safeMfText}')" class="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[9.5px] font-black bg-amber-500 hover:bg-amber-600 text-slate-950 transition cursor-pointer" title="Tıklayın (${it.mf_depo || 'Depo'})">
                            <i class="fa-solid fa-gift text-[8px]"></i>
                            <span>${it.mf_metni}</span>
                        </button>
                    `;
                } else if (it.gecmis_mf_var && pastTiers.length > 0) {
                    const pastDepo = normalizeDepoCode(it.gecmis_mf_depo);
                    const pastBtns = pastTiers.map(t => {
                        const isSelTier = (curQty === t.alinan);
                        const btnStyle = isSelTier
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300';
                        return `
                            <button type="button" onclick="applySmartMfToRow(${idx}, ${t.alinan}, '${pastDepo}', '${t.text}')" class="inline-flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold border ${btnStyle} transition cursor-pointer" title="${it.gecmis_mf_bilgi || 'Geçmiş MF'} — Tıklayınca adedi ${t.alinan} kutu yapar">
                                <span>G.MF: ${t.text}</span>
                            </button>
                        `;
                    }).join('');
                    mfColHtml += pastBtns;
                } else {
                    mfColHtml += `
                        <button type="button" onclick="resolveSingleSmartRowMf(${idx})" class="text-[9.5px] text-indigo-600 hover:underline font-bold cursor-pointer" title="Bu ilaç için depolarda canlı MF sorgula">MF Sorgula</button>
                    `;
                }

                // Sipariş Durumu Rozeti (Sayfa yenilemeden anında güncellenir)
                let orderStatusBadge = '';
                let rowBgClass = 'hover:bg-slate-50/90';
                if (it.siparis_durumu === 'SIPARIS_VERILDI') {
                    rowBgClass = 'bg-emerald-50/50 opacity-85';
                    orderStatusBadge = `
                        <span class="inline-flex items-center space-x-1 px-1.5 py-0 rounded bg-emerald-600 text-white text-[9px] font-black shadow-2xs">
                            <span>✓ ${it.siparis_depo || 'DEPO'} (${it.siparis_miktar || 1})</span>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event);" class="ml-0.5 underline hover:text-rose-200 cursor-pointer" title="Sipariş verildi işaretini kaldır">×</button>
                        </span>
                    `;
                } else if (it.siparis_durumu === 'SIPARIS_VERILMEYECEK') {
                    const isYokRow = String(it.siparis_depo || '').toUpperCase() === 'YOK_LISTESI';
                    rowBgClass = isYokRow ? 'bg-rose-50/40 opacity-85' : 'bg-slate-100/70 opacity-80';
                    orderStatusBadge = `
                        <span class="inline-flex items-center space-x-1 px-1.5 py-0 rounded ${isYokRow ? 'bg-rose-600' : 'bg-slate-700'} text-white text-[9px] font-black shadow-2xs">
                            <span>${isYokRow ? '🚨 YOK' : '🚫 YOKSAY'}</span>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event);" class="ml-0.5 underline hover:text-rose-200 cursor-pointer" title="İşareti kaldır">×</button>
                        </span>
                    `;
                } else if (it.siparis_durumu === 'SEPETTE') {
                    rowBgClass = 'bg-amber-50/30';
                    orderStatusBadge = `
                        <span class="inline-flex items-center space-x-1 px-1.5 py-0 rounded bg-amber-100 text-amber-950 border border-amber-300 text-[9px] font-extrabold">
                            <span>🛒 ${it.siparis_depo || 'DEPO'} (${it.siparis_miktar || 1})</span>
                            <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeName}', '${it.siparis_depo || 'ALLIANCE'}', ${it.siparis_miktar || 1});" class="px-1 rounded bg-emerald-600 text-white cursor-pointer" title="Sipariş verildi olarak onayla">✓</button>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event);" class="px-1 rounded bg-white text-slate-600 hover:text-rose-600 border border-amber-300 cursor-pointer" title="Sepet işaretini kaldır">×</button>
                        </span>
                    `;
                }

                let isChecked = false;
                if (it.siparis_durumu === 'SIPARIS_VERILDI' || it.siparis_durumu === 'SIPARIS_VERILMEYECEK') {
                    isChecked = false;
                    window.smartRowCheckedMap[key] = false;
                } else if (window.smartRowCheckedMap[key] !== undefined) {
                    isChecked = !!window.smartRowCheckedMap[key];
                } else {
                    isChecked = false;
                    window.smartRowCheckedMap[key] = false;
                }

                const qtyBoxBorderClass = isManualLocked
                    ? 'bg-indigo-50 border border-indigo-500 ring-2 ring-indigo-400/50'
                    : 'bg-slate-100 border border-slate-300';

                return `
                    <tr class="${rowBgClass} transition">
                        <td class="py-1.5 px-1.5 text-center align-middle">
                            <input 
                                type="checkbox" 
                                class="smartRowCheck rounded text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5 cursor-pointer" 
                                data-idx="${idx}"
                                onchange="onSmartRowCheckChange(${idx}, this.checked)"
                                ${isChecked ? 'checked' : ''}
                            />
                        </td>
                        <td class="py-1.5 px-2 align-middle overflow-hidden">
                            <div class="font-extrabold text-[11.5px] leading-tight ${it.siparis_durumu === 'SIPARIS_VERILDI' || it.siparis_durumu === 'SIPARIS_VERILMEYECEK' || it.siparis_durumu === 'SEPETTE' ? 'line-through text-slate-500' : 'text-slate-900 hover:text-indigo-700'} cursor-pointer truncate" onclick="searchFromCritical('${safeBc}', '${safeName}')" title="${it.urun_adi} — Tüm depolarda karşılaştırmak için tıklayın">
                                ${it.urun_adi}
                            </div>
                            <div class="flex flex-wrap items-center gap-1.5 mt-0.5 text-[9.5px] text-slate-400 font-mono leading-none">
                                <span>${it.barkod || '-'}</span>
                                ${it.psf > 0 ? `<span class="text-slate-600 font-bold">• ${it.psf.toFixed(0)}₺</span>` : ''}
                                ${!it.siparis_durumu ? `
                                    <button type="button" onclick="markItemSkippedDirect('${safeBc}', '${safeName}');" class="text-slate-400 hover:text-slate-700 font-sans font-semibold cursor-pointer" title="Bugün sipariş verilmeyecek olarak işaretle">Yoksay</button>
                                    <button type="button" onclick="markItemYokDirect('${safeBc}', '${safeName}');" class="text-rose-600 hover:text-rose-800 font-sans font-bold cursor-pointer" title="Doğrudan Yok Listesine ekle">Yok'a At</button>
                                ` : ''}
                                ${orderStatusBadge}
                            </div>
                            ${it.takas_7gun_uyari ? (() => {
                                const tw = it.takas_7gun_uyari;
                                const twDepo = tw.depo_etiket || tw.depo || 'Takas/Ortak Alım';
                                const twQty = tw.miktar || 1;
                                const twKalan = tw.kalan_gun || 7;
                                return `
                                    <div class="mt-0.5 inline-flex items-center gap-1 px-1.5 py-0 rounded bg-violet-100 border border-violet-300 text-violet-950 text-[9px] font-extrabold">
                                        <span>⏳ ${twDepo}: ${twQty}Kt (${twKalan}G)</span>
                                        <button type="button" onclick="if(window.dismissTakas7DayWarning) window.dismissTakas7DayWarning('${safeBc}', '${safeName}', event);" class="ml-0.5 px-1 rounded bg-violet-200 hover:bg-rose-500 hover:text-white text-violet-900 text-[8px] font-black cursor-pointer">×</button>
                                    </div>
                                `;
                            })() : ''}
                            <div id="smartMfAssistant_${idx}" class="hidden"></div>
                        </td>
                        <td class="py-1.5 px-1.5 text-center align-middle">
                            <div class="flex flex-col items-center leading-tight">
                                ${stockBadge}
                                <span class="mt-0.5 text-[9.5px] font-mono ${it.bugun_cikis > 0 ? 'font-extrabold text-amber-800' : 'text-slate-400'}">Bugün: ${it.bugun_cikis || 0}</span>
                            </div>
                        </td>
                        <td class="py-1.5 px-1.5 align-middle">
                            ${sixMonthStripHtml}
                        </td>
                        <td class="py-1.5 px-1.5 text-center align-middle bg-slate-50/80 leading-tight">
                            <div class="font-black text-slate-900 font-mono text-[11px]">${it.toplam_6ay || 0} Kt</div>
                            <div class="text-[9px] text-slate-500 font-semibold">Ort: ${it.ort_aylik_6m || 0}/Ay</div>
                        </td>
                        <td class="py-1.5 px-2 align-middle" id="smartMfCell_${idx}">
                            <div class="flex flex-wrap items-center gap-1">
                                ${trendBadge}
                                ${mfColHtml}
                            </div>
                        </td>
                        <td class="py-1.5 pl-2 pr-3 align-middle text-right bg-indigo-50/20">
                            <div class="flex items-center justify-end gap-1.5 flex-nowrap w-full">
                                <button type="button" onclick="setSmartRowQty(${idx}, ${Math.max(1, recVal)}, false)" class="h-7 px-2 inline-flex items-center justify-center rounded-lg text-[9.5px] font-extrabold ${!isManualLocked ? 'bg-indigo-100 text-indigo-800 border border-indigo-200' : 'bg-slate-100 hover:bg-indigo-50 text-slate-600 border border-slate-200/80'} transition cursor-pointer shrink-0 leading-none" title="${it.oneri_metni || 'Akıllı öneriyi uygula'}">Öneri: ${recVal}</button>
                                <div id="smartQtyWrapper_${idx}" class="h-7 inline-flex items-center rounded-lg px-0.5 shrink-0 ${qtyBoxBorderClass}">
                                    <button type="button" onclick="changeSmartRowQty(${idx}, -1)" class="w-5 h-5 inline-flex items-center justify-center rounded-md bg-white hover:bg-slate-200 text-slate-800 font-black text-[11px] leading-none transition cursor-pointer shrink-0">-</button>
                                    <input 
                                        type="number" 
                                        id="smartQtyInput_${idx}" 
                                        value="${curQty}" 
                                        min="0" 
                                        max="999"
                                        onfocus="this.select()"
                                        oninput="onSmartRowQtyInput(${idx}, this.value)"
                                        class="no-spinners w-7 text-center font-black font-mono text-[11px] text-slate-900 bg-transparent focus:outline-none leading-none"
                                    />
                                    <button type="button" onclick="changeSmartRowQty(${idx}, 1)" class="w-5 h-5 inline-flex items-center justify-center rounded-md bg-white hover:bg-slate-200 text-slate-800 font-black text-[11px] leading-none transition cursor-pointer shrink-0">+</button>
                                </div>

                                <select 
                                    id="smartDepoSelect_${idx}" 
                                    onchange="onSmartRowDepoChange(${idx}, this.value)"
                                    class="h-7 pl-1.5 pr-1 rounded-lg text-[10.5px] font-extrabold border border-slate-300 bg-white hover:border-indigo-400 text-slate-800 focus:outline-none focus:border-indigo-500 transition cursor-pointer shrink-0"
                                >
                                    ${isBulkDepoActive('ALLIANCE') ? `<option value="ALLIANCE" ${curDepo === 'ALLIANCE' ? 'selected' : ''}>Alliance</option>` : ''}
                                    ${isBulkDepoActive('SELCUK') ? `<option value="SELCUK" ${curDepo === 'SELCUK' ? 'selected' : ''}>Selçuk</option>` : ''}
                                    ${isBulkDepoActive('ISKOOP') ? `<option value="ISKOOP" ${curDepo === 'ISKOOP' ? 'selected' : ''}>İSKOOP</option>` : ''}
                                    ${isBulkDepoActive('NEVZAT') ? `<option value="NEVZAT" ${curDepo === 'NEVZAT' ? 'selected' : ''}>Nevzat</option>` : ''}
                                </select>

                                <button 
                                    type="button" 
                                    id="btnSmartSingleAdd_${idx}"
                                    onclick="sendSingleSmartRowToDepo(${idx})" 
                                    class="w-7 h-7 inline-flex items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 active:scale-95 text-white border border-emerald-600/80 shadow-xs hover:shadow transition-all cursor-pointer shrink-0"
                                    title="Bu ilacı seçili adetle doğrudan sepete ekle"
                                >
                                    <i class="fa-solid fa-cart-plus text-[11.5px] leading-none"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');

            updateSmartSelectionSummary();
        }

        function onSmartRowCheckChange(idx, isChecked) {
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (it) {
                const key = it.barkod || it.urun_kodu || it.urun_adi;
                window.smartRowCheckedMap[key] = !!isChecked;
            }
            updateSmartSelectionSummary();
        }

        function setSmartRowQty(idx, val, markManual = true) {
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it) return;
            const key = it.barkod || it.urun_kodu || it.urun_adi;
            const parsed = parseInt(val);
            const clean = isNaN(parsed) ? 1 : Math.max(0, parsed);
            window.smartRowCustomQty[key] = clean > 0 ? clean : 1;
            window.smartRowManualLocked[key] = !!markManual;

            const inp = document.getElementById(`smartQtyInput_${idx}`);
            if (inp) inp.value = clean;

            const chk = document.querySelector(`.smartRowCheck[data-idx="${idx}"]`);
            if (clean > 0) {
                window.smartRowCheckedMap[key] = true;
                if (chk) chk.checked = true;
            } else {
                window.smartRowCheckedMap[key] = false;
                if (chk) chk.checked = false;
            }

            renderSmartOrderTable();
        }

        function changeSmartRowQty(idx, delta) {
            const inp = document.getElementById(`smartQtyInput_${idx}`);
            if (!inp) return;
            const cur = parseInt(inp.value) || 0;
            setSmartRowQty(idx, Math.max(0, cur + delta), true);
        }

        function onSmartRowQtyInput(idx, val) {
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it) return;
            const key = it.barkod || it.urun_kodu || it.urun_adi;
            const parsed = parseInt(val);
            const clean = isNaN(parsed) ? 0 : Math.max(0, parsed);
            window.smartRowManualLocked[key] = true;

            const chk = document.querySelector(`.smartRowCheck[data-idx="${idx}"]`);
            const wrap = document.getElementById(`smartQtyWrapper_${idx}`);
            if (wrap) {
                wrap.className = 'h-7 inline-flex items-center rounded-lg px-0.5 shrink-0 bg-indigo-50 border border-indigo-500 ring-2 ring-indigo-400/50';
            }

            if (clean > 0) {
                window.smartRowCustomQty[key] = clean;
                window.smartRowCheckedMap[key] = true;
                if (chk) chk.checked = true;
            } else {
                window.smartRowCustomQty[key] = 1;
                window.smartRowCheckedMap[key] = false;
                if (chk) chk.checked = false;
            }
            const mfAssEl = document.getElementById(`smartMfAssistant_${idx}`);
            if (mfAssEl && typeof buildSmartMfBaremAssistantHtml === 'function') {
                mfAssEl.innerHTML = buildSmartMfBaremAssistantHtml(it, clean > 0 ? clean : 1, 'smart', idx);
            }
            updateSmartSelectionSummary();
        }

        function onSmartRowDepoChange(idx, depoCode) {
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it) return;
            const key = it.barkod || it.urun_kodu || it.urun_adi;
            window.smartRowDepos[key] = depoCode;
            const chk = document.querySelector(`.smartRowCheck[data-idx="${idx}"]`);
            if (chk) {
                chk.checked = true;
            }
            window.smartRowCheckedMap = window.smartRowCheckedMap || {};
            if (key) window.smartRowCheckedMap[key] = true;
            updateSmartSelectionSummary();
        }

        function applySmartMfToRow(idx, minAlimQty, depoCode, mfText) {
            onSmartRowDepoChange(idx, depoCode);
            setSmartRowQty(idx, minAlimQty, true);
            showToast('MF Kademesi Uygulandı', `Sipariş rakamı ${mfText || minAlimQty} MF şartı için ${minAlimQty} kutu (${depoCode}) olarak ayarlandı.`, 'success');
        }

        function handleSmartMasterCheckClick(event) {
            if (event) event.preventDefault();
            const allChecks = Array.from(document.querySelectorAll('.smartRowCheck'));
            const checkedCount = allChecks.filter(c => c.checked).length;
            const shouldCheckAll = !(allChecks.length > 0 && checkedCount === allChecks.length);

            allChecks.forEach(c => {
                c.checked = shouldCheckAll;
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (it) {
                    const key = it.barkod || it.urun_kodu || it.urun_adi;
                    window.smartRowCheckedMap[key] = shouldCheckAll;
                }
            });
            updateSmartSelectionSummary();
        }

        function toggleSmartSelectAll(master) {
            const allChecks = Array.from(document.querySelectorAll('.smartRowCheck'));
            const targetState = master ? !!master.checked : true;
            allChecks.forEach(c => {
                c.checked = targetState;
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (it) {
                    const key = it.barkod || it.urun_kodu || it.urun_adi;
                    window.smartRowCheckedMap[key] = targetState;
                }
            });
            updateSmartSelectionSummary();
        }

        function syncSmartMasterCheckboxState() {
            const master = document.getElementById('smartMasterCheck');
            const vbox = document.getElementById('smartMasterVisualBox');
            const vicon = document.getElementById('smartMasterVisualIcon');
            const vtext = document.getElementById('smartMasterText');
            const allChecks = Array.from(document.querySelectorAll('.smartRowCheck'));
            const checkedCount = allChecks.filter(c => c.checked).length;

            const isAllSelected = allChecks.length > 0 && checkedCount === allChecks.length;
            const isPartial = checkedCount > 0 && checkedCount < allChecks.length;

            if (master) master.checked = isAllSelected;

            if (vbox && vicon) {
                if (isAllSelected) {
                    vbox.className = 'w-4 h-4 rounded-md flex items-center justify-center border-2 border-sky-600 bg-sky-600 text-white shadow-2xs transition-all';
                    vicon.className = 'fa-solid fa-check text-[10px] font-black';
                    if (vtext) vtext.innerText = 'Tümünü Bırak';
                } else if (isPartial) {
                    vbox.className = 'w-4 h-4 rounded-md flex items-center justify-center border-2 border-sky-500 bg-sky-100 text-sky-700 transition-all';
                    vicon.className = 'fa-solid fa-minus text-[10px] font-black';
                    if (vtext) vtext.innerText = 'Tümünü Seç';
                } else {
                    vbox.className = 'w-4 h-4 rounded-md flex items-center justify-center border-2 border-slate-300 bg-white text-transparent transition-all';
                    vicon.className = 'fa-solid fa-check text-[10px] opacity-0';
                    if (vtext) vtext.innerText = 'Tümünü Seç';
                }
            }
        }

        function selectSmartByTrend(mode) {
            const checks = document.querySelectorAll('.smartRowCheck');
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (!it || it.siparis_durumu === 'SIPARIS_VERILDI') {
                    c.checked = false;
                    return;
                }
                const key = it.barkod || it.urun_kodu || it.urun_adi;
                if (mode === 'STABIL') {
                    c.checked = (it.trend_kodu === 'STABIL' && (it.onerilen_siparis || 0) > 0);
                } else if (mode === 'MF') {
                    c.checked = !!((it.mf_metni && it.mf_metni !== 'YOK') || it.gecmis_mf_var);
                } else if (mode === 'MANUAL') {
                    c.checked = !!window.smartRowManualLocked[key];
                }
                window.smartRowCheckedMap[key] = c.checked;
            });
            updateSmartSelectionSummary();
        }

        function updateSmartSelectionSummary() {
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            let totalBoxes = 0;
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const inp = document.getElementById(`smartQtyInput_${idx}`);
                totalBoxes += inp ? (parseInt(inp.value) || 1) : 1;
            });
            const cntBadge = document.getElementById('smartSelectedCountBadge');
            const boxBadge = document.getElementById('smartSelectedBoxesBadge');
            if (cntBadge) cntBadge.innerText = `${checks.length} Kalem Seçili`;
            if (boxBadge) boxBadge.innerText = `Toplam ${totalBoxes} Kutu`;
            syncSmartMasterCheckboxState();
        }

        async function resolveSingleSmartRowMf(idx) {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('MF Asistanı')) return;
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it || !it.barkod) return;
            const cell = document.getElementById(`smartMfCell_${idx}`);
            if (cell) cell.innerHTML = `<span class="text-[10px] text-amber-600 font-bold"><i class="fa-solid fa-spinner fa-spin mr-1"></i>Sorgulanıyor...</span>`;
            try {
                const res = await fetch('/api/otomasyon/resolve-mf', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barcodes: [it.barkod] })
                });
                const data = await res.json();
                const mfInfo = data.results ? data.results[it.barkod] : null;
                if (mfInfo && mfInfo.mf) {
                    it.mf_metni = mfInfo.mf;
                    it.mf_depo = mfInfo.depo || 'Depo';
                    recalculateSmartOrderClientSide(false);
                    renderSmartOrderTable();
                    showToast('Canlı MF Bulundu', `${it.urun_adi}: ${mfInfo.mf} MF (${mfInfo.depo})`, 'success');
                } else {
                    renderSmartOrderTable();
                    showToast('MF Bulunamadı', `${it.urun_adi} için şu an aktif depo MF'si görünmüyor.`, 'info');
                }
            } catch (e) {
                renderSmartOrderTable();
            }
        }

        async function resolveAllSmartOrderMfs(manualClick = false) {
            if (window.isLicenseRestricted && window.isLicenseRestricted()) {
                if (manualClick && window.checkLicenseBeforeAction) window.checkLicenseBeforeAction('MF Asistanı');
                return;
            }
            if (window.isSmartMfScanning) return;
            const list = window.smartOrderFiltered && window.smartOrderFiltered.length > 0 ? window.smartOrderFiltered : (window.smartOrderItems || []);
            const targets = list.filter(it => it.barkod && ((!it.mf_checked && !it.mf_metni) || manualClick)).slice(0, 35).map(it => it.barkod);
            if (targets.length === 0) {
                if (manualClick) showToast('MF Taraması Tamam', 'Listedeki ürünlerin güncel MF bilgileri zaten yüklü.', 'info');
                return;
            }

            window.isSmartMfScanning = true;
            const progBadge = document.getElementById('smartMfScanProgressBadge');
            const btnIcon = document.getElementById('smartResolveMfIcon');
            if (progBadge) progBadge.classList.remove('hidden');
            if (btnIcon) btnIcon.className = 'fa-solid fa-spinner fa-spin text-sm';

            let hasMoreToScan = false;
            try {
                const res = await fetch('/api/otomasyon/resolve-mf', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barcodes: targets })
                });
                if (res.ok) {
                    const data = await res.json();
                    const results = data.results || {};
                    let foundCount = 0;
                    (window.smartOrderItems || []).forEach(it => {
                        if (it.barkod && (it.barkod in results)) {
                            it.mf_checked = true;
                            const mfObj = results[it.barkod];
                            if (mfObj && mfObj.mf) {
                                it.mf_metni = mfObj.mf;
                                it.mf_depo = mfObj.depo || 'Depo';
                                if (mfObj.fiyat && !it.psf) it.psf = Number(mfObj.fiyat);
                                foundCount++;
                            } else {
                                it.mf_metni = null;
                                it.mf_depo = null;
                            }
                        }
                    });
                    const remaining = list.filter(it => it.barkod && !it.mf_checked && !it.mf_metni).length;
                    if (!manualClick && remaining > 0) {
                        hasMoreToScan = true;
                    }
                    recalculateSmartOrderClientSide(false);
                    renderSmartOrderTable();
                    if (manualClick) {
                        showToast('Canlı MF Taraması Tamamlandı', `${targets.length} ürün tarandı, ${foundCount} üründe aktif depo MF şartı bulundu.`, 'success');
                    }
                }
            } catch (e) {
                console.error('Smart MF batch error:', e);
            } finally {
                window.isSmartMfScanning = false;
                if (progBadge) progBadge.classList.add('hidden');
                if (btnIcon) btnIcon.className = 'fa-solid fa-gift text-sm';
                if (hasMoreToScan) {
                    setTimeout(() => resolveAllSmartOrderMfs(false), 350);
                }
            }
        }

        async function sendSingleSmartRowToDepo(idx) {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Sepete Ekleme')) return;
            const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
            if (!it) return;
            const inp = document.getElementById(`smartQtyInput_${idx}`);
            const sel = document.getElementById(`smartDepoSelect_${idx}`);
            const btn = document.getElementById(`btnSmartSingleAdd_${idx}`);
            const qty = inp ? (parseInt(inp.value) || 1) : 1;
            const depo = sel ? sel.value : 'ALLIANCE';

            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin text-[11.5px] leading-none"></i>`;
            }
            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        barkod: it.barkod,
                        urun_id: it.barkod,
                        miktar: qty,
                        name: it.urun_adi || ''
                    })
                });
                const data = await res.json();
                if (data.success) {
                    if (typeof recordDepotSessionFromSingleAdd === 'function') {
                        recordDepotSessionFromSingleAdd(depo, data.sepet_tutari, data.sepet_no, data.portal_url);
                    }
                    const dUp = String(depo || 'ALLIANCE').toUpperCase();
                    if (typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus([{ barkod: it.barkod || '', urun_adi: it.urun_adi || '', miktar: qty, depo: dUp }], 'SEPETTE', dUp);
                    }
                    if (typeof updateMultiDepotCartUI === 'function') updateMultiDepotCartUI();
                    showToast(`${depo} Sepetine Eklendi`, `${it.urun_adi} x${qty} kutu sepete aktarıldı.`, 'success');
                    renderSmartOrderTable();
                    if (typeof syncTodayOrdersAcrossPCs === 'function') await syncTodayOrdersAcrossPCs();
                } else {
                    showToast('Sepet Hatası', data.message || 'Ürün eklenemedi.', 'error');
                }
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = `<i class="fa-solid fa-cart-plus text-[11.5px] leading-none"></i>`;
                }
            }
        }

        async function markSelectedSmartItemsOrdered() {
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yok', 'Lütfen işaretlemek için en az bir ilaç seçin.', 'info');
                return;
            }
            const itemsPayload = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (!it) return;
                const inp = document.getElementById(`smartQtyInput_${idx}`);
                const sel = document.getElementById(`smartDepoSelect_${idx}`);
                itemsPayload.push({
                    barkod: it.barkod || '',
                    urun_adi: it.urun_adi || '',
                    depo: sel ? sel.value : 'MANUEL',
                    miktar: inp ? (parseInt(inp.value) || 1) : 1
                });
            });
            try {
                if (typeof applyOptimisticOrderStatus === 'function') {
                    applyOptimisticOrderStatus(itemsPayload, 'SIPARIS_VERILDI', 'TOPLU');
                }
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ durum: 'SIPARIS_VERILDI', depo: 'TOPLU', items: itemsPayload })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Ortak Sipariş Takibine İşlendi', `${itemsPayload.length} kalem ilaç tüm bilgisayarlarda 'Sipariş Verildi' olarak işaretlendi.`, 'success');
                    updateSmartKpiCounters();
                    renderSmartOrderTable();
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markSelectedSmartItemsSkipped() {
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yok', 'Lütfen bugün sipariş verilmeyecek olarak işaretlemek istediğiniz ilaçları seçin.', 'info');
                return;
            }
            const itemsPayload = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (!it) return;
                itemsPayload.push({
                    barkod: it.barkod || '',
                    urun_adi: it.urun_adi || '',
                    depo: 'VERILMEYECEK',
                    miktar: 1
                });
            });
            try {
                if (typeof applyOptimisticOrderStatus === 'function') {
                    applyOptimisticOrderStatus(itemsPayload, 'SIPARIS_VERILMEYECEK', 'VERILMEYECEK');
                }
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ durum: 'SIPARIS_VERILMEYECEK', depo: 'VERILMEYECEK', items: itemsPayload })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Toplu Verilmeyecek İşaretlendi', `${itemsPayload.length} kalem ilaç tüm bilgisayarlarda 'Sipariş Verilmeyecek' olarak işaretlendi.`, 'info');
                    updateSmartKpiCounters();
                    renderSmartOrderTable();
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markSelectedSmartItemsYok() {
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yok', 'Lütfen Yok Listesine eklemek istediğiniz ilaçları seçin.', 'info');
                return;
            }
            const itemsPayload = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (!it) return;
                itemsPayload.push({
                    barkod: it.barkod || '',
                    urun_adi: it.urun_adi || '',
                    depo: 'YOK_LISTESI',
                    miktar: 1,
                    kaynak: 'Toplu Sipariş'
                });
            });
            if (itemsPayload.length === 0) return;
            try {
                window.persistentYokUserClosed = false;
                if (typeof applyOptimisticOrderStatus === 'function') {
                    applyOptimisticOrderStatus(itemsPayload, 'SIPARIS_VERILMEYECEK', 'YOK_LISTESI');
                }
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ items: itemsPayload })
                });
                const data = await res.json();
                if (data.success) {
                    if (Array.isArray(data.yok_items) && typeof renderPersistentYokWidgets === 'function') {
                        renderPersistentYokWidgets(data.yok_items, Array.isArray(data.var_items) ? data.var_items : [], null);
                    }
                    showToast('🚨 Toplu Yok Listesine Eklendi', `${itemsPayload.length} kalem ilaç doğrudan Yok Listesine eklendi.`, 'info');
                    updateSmartKpiCounters();
                    renderSmartOrderTable();
                    if (typeof loadEndOfDaySummary === 'function') await loadEndOfDaySummary();
                    if (typeof syncTodayOrdersAcrossPCs === 'function') await syncTodayOrdersAcrossPCs();
                } else {
                    showToast('Uyarı', data.error || 'Yok listesine eklenemedi.', 'error');
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function triggerSmartBulkOrder(depoKodu = 'ALLIANCE') {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Toplu Sipariş')) return;
            const depo = (depoKodu || 'ALLIANCE').toUpperCase();
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', 'Lütfen sepete aktarmak istediğiniz ilaçları tablodan seçiniz.', 'info');
                return;
            }

            const itemsToOrder = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (it && it.barkod) {
                    const inp = document.getElementById(`smartQtyInput_${idx}`);
                    const qty = inp ? (parseInt(inp.value) || 1) : 1;
                    itemsToOrder.push({
                        barcode: it.barkod,
                        name: it.urun_adi,
                        miktar: qty
                    });
                }
            });

            await executeBulkOrderWithItems(depo, itemsToOrder);
        }

        async function triggerSmartBulkOrderByRowDepo() {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Toplu Sipariş')) return;
            const checks = document.querySelectorAll('.smartRowCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', 'Lütfen dağıtılacak ilaçları tablodan seçiniz.', 'info');
                return;
            }
            const groups = {};
            const allOrderedItems = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.smartOrderFiltered ? window.smartOrderFiltered[idx] : null;
                if (it && it.barkod) {
                    const inp = document.getElementById(`smartQtyInput_${idx}`);
                    const sel = document.getElementById(`smartDepoSelect_${idx}`);
                    const qty = inp ? (parseInt(inp.value) || 1) : 1;
                    const d = (sel ? sel.value : 'ALLIANCE').toUpperCase();
                    if (!groups[d]) groups[d] = [];
                    const itemObj = { barcode: it.barkod, name: it.urun_adi, miktar: qty, target_depo: d };
                    groups[d].push(itemObj);
                    allOrderedItems.push(itemObj);
                }
            });

            const depoKeys = Object.keys(groups);
            if (depoKeys.length === 0) return;

            if (typeof executeMultiDepotBulkDistribution === 'function') {
                await executeMultiDepotBulkDistribution(groups, allOrderedItems);
                await loadSmartOrderList(true);
                return;
            }

            if (depoKeys.length === 1) {
                await executeBulkOrderWithItems(depoKeys[0], groups[depoKeys[0]]);
                return;
            }

            // Birden fazla depoya dağıtım
            const firstDepo = depoKeys[0];
            await executeBulkOrderWithItems(firstDepo, groups[firstDepo]);
            for (let i = 1; i < depoKeys.length; i++) {
                const dKey = depoKeys[i];
                window.currentBulkState.missingItems = groups[dKey];
                await transferMissingItemsTo(dKey);
            }
            await loadSmartOrderList(true);
        }

        async function executeBulkOrderWithItems(depo, itemsToOrder) {
            const cfg = DEPO_BULK_CONFIGS[depo] || DEPO_BULK_CONFIGS['ALLIANCE'];
            const preserved = (typeof getPreservedBulkCartState === 'function')
                ? getPreservedBulkCartState()
                : { depoSessions: {}, allResults: [], triedDepos: [] };
            const newPendingResults = itemsToOrder.map(it => ({
                barcode: it.barcode,
                name: it.name,
                miktar: it.miktar,
                target_depo: depo,
                status: 'PENDING',
                assigned_depo: null,
                net_fiyat: 0,
                vade: 30,
                message: 'İşleniyor...'
            }));
            const filteredPreservedResults = preserved.allResults.filter(pr => {
                if (String(pr.assigned_depo || '').toUpperCase() !== depo) return true;
                return !itemsToOrder.some(nt => nt.barcode && pr.barcode && nt.barcode === pr.barcode);
            });
            window.currentBulkState = {
                depo: depo,
                initialDepo: depo,
                triedDepos: Array.from(new Set([...preserved.triedDepos, depo])),
                requestedItems: itemsToOrder,
                depoSessions: { ...preserved.depoSessions },
                missingItems: [],
                preservedResults: filteredPreservedResults,
                allResults: [...newPendingResults]
            };

            const modal = document.getElementById('bulkOrderModal');
            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
            }
            if (typeof resetBulkOrderModalUIForNewRun === 'function') {
                resetBulkOrderModalUIForNewRun(itemsToOrder.length);
            } else {
                window.activeBulkResultTab = 'ALL';
            }

            const modalTitle = document.getElementById('bulkModalTitle');
            const modalDesc = document.getElementById('bulkModalDesc');
            const modalIcon = document.getElementById('bulkModalIcon');
            const modalTargetDepo = document.getElementById('bulkModalTargetDepo');
            const modalCartLink = document.getElementById('bulkModalCartLink');
            const modalCartText = document.getElementById('bulkModalCartBtnText');

            if (modalTitle) modalTitle.innerText = cfg.title;
            if (modalDesc) modalDesc.innerText = cfg.desc;
            if (modalTargetDepo) modalTargetDepo.innerText = `${cfg.name} B2B`;
            if (modalIcon) modalIcon.className = cfg.icon;
            if (modalCartLink) modalCartLink.href = cfg.cartUrl;
            if (modalCartText) modalCartText.innerText = cfg.cartBtnText;

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');
            const statTotal = document.getElementById('bulkStatTotal');
            const statSuccess = document.getElementById('bulkStatSuccess');
            const statFailed = document.getElementById('bulkStatFailed');
            const statAmount = document.getElementById('bulkStatAmount');

            if (statTotal) statTotal.innerText = itemsToOrder.length;
            if (statSuccess) statSuccess.innerText = '0';
            if (statFailed) statFailed.innerText = '0';
            if (statAmount) statAmount.innerText = '0.00 ₺';
            if (pBar) pBar.style.width = '25%';
            if (pPercent) pPercent.innerText = '%25';
            if (pText) pText.innerText = `${cfg.name} sepetine ${itemsToOrder.length} kalem aktarılıyor...`;
            if (pSpinner) pSpinner.className = 'fa-solid fa-spinner fa-spin text-sky-600';

            renderBulkItemsTable();

            try {
                const res = await fetch('/api/cart/bulk-add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo, items: itemsToOrder, cascade: false })
                });
                const data = await res.json();
                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '%100';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-check text-emerald-600';

                if (data.success || data.success_count > 0 || data.items) {
                    const successCount = data.success_count || 0;
                    const totalAmount = data.total_amount || 0;
                    const missing = [];
                    const addedOptimistic = [];
                    (data.items || []).forEach(r => {
                        const target = window.currentBulkState.allResults.find(it => it.barcode === r.barcode && it.status === 'PENDING' && (!it.target_depo || it.target_depo === depo))
                                    || window.currentBulkState.allResults.find(it => it.barcode === r.barcode && (!it.assigned_depo || it.assigned_depo === depo));
                        if (r.success) {
                            addedOptimistic.push({
                                barkod: r.barcode || (target && target.barcode) || '',
                                urun_adi: r.name || (target && target.name) || '',
                                miktar: r.miktar || (target && target.miktar) || 1,
                                depo: depo
                            });
                            if (target) {
                                target.status = 'ADDED';
                                target.assigned_depo = depo;
                                target.urun_id = r.urun_id || r.matnr || r.urun_kodu || target.urun_id || '';
                                target.net_fiyat = r.net_fiyat || 0;
                                target.vade = r.vade || 30;
                                target.message = r.message || 'Eklendi';
                            }
                        } else {
                            if (target) {
                                target.status = 'YOK';
                                target.message = r.message || 'Stok Yok';
                            }
                            missing.push({
                                barcode: r.barcode,
                                name: r.name || (target ? target.name : r.barcode),
                                miktar: r.miktar || (target ? target.miktar : 1),
                                message: r.message || 'Stok Yok'
                            });
                        }
                    });
                    if (addedOptimistic.length > 0 && typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus(addedOptimistic, 'SEPETTE', depo);
                    }
                    const prevPreservedForDepo = (window.currentBulkState.preservedResults || []).filter(it => it.status === 'ADDED' && it.assigned_depo === depo).length;
                    const curForThisDepo = window.currentBulkState.allResults.filter(it => it.status === 'ADDED' && it.assigned_depo === depo).length;
                    const totalForThisDepo = prevPreservedForDepo + curForThisDepo;
                    const prevSessAmt = (window.currentBulkState.depoSessions[depo] && window.currentBulkState.depoSessions[depo].amount) || 0;
                    window.currentBulkState.depoSessions[depo] = {
                        count: Math.max(successCount, totalForThisDepo),
                        amount: totalAmount > 0 ? totalAmount : prevSessAmt,
                        name: cfg.name,
                        cartUrl: cfg.cartUrl,
                        finalized: false,
                        cleared: false
                    };
                    window.currentBulkState.missingItems = missing;
                    if (statSuccess) statSuccess.innerText = `${successCount} Kalem`;
                    if (statFailed) statFailed.innerText = `${missing.length} Kalem`;
                    if (statAmount) statAmount.innerText = `${totalAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;
                    const tabAllCount = document.getElementById('bulkTabCountAll');
                    const tabYokCount = document.getElementById('bulkTabCountYok');
                    if (tabAllCount) tabAllCount.innerText = itemsToOrder.length;
                    if (tabYokCount) tabYokCount.innerText = missing.length;
                    if (pText) pText.innerHTML = `<strong>Tamamlandı:</strong> ${successCount} Kalem ${cfg.name} sepetine eklendi! ${missing.length > 0 ? `<span class="text-rose-600 font-bold ml-1">(${missing.length} kalem bu depoda bulunamadı)</span>` : ''}`;
                    renderDepoBreakdownPills();
                    updateBulkMainFinalizeButtonUI();
                    renderTransferMissingBar(depo);
                    renderBulkItemsTable();
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                    loadSmartOrderList(true);
                } else {
                    if (pText) pText.innerText = `Aktarım uyarısı: ${data.message || 'Ürünler sepete eklenemedi'}`;
                    if (pSpinner) pSpinner.className = 'fa-solid fa-triangle-exclamation text-rose-600';
                    updateBulkMainFinalizeButtonUI();
                    showToast('Aktarım Uyarısı', data.message || 'İşlem tamamlanamadı.', 'error');
                }
            } catch (e) {
                if (pText) pText.innerText = `Hata: ${e.message}`;
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-xmark text-rose-600';
                updateBulkMainFinalizeButtonUI();
                showToast('Bağlantı Hatası', e.message, 'error');
            }
        }

        function quickMarketSearch(query, label) {
            const input = document.getElementById('marketSearchInput');
            if (input) input.value = query;
            handleMarketSearchSubmit(query);
        }

        async function handleMarketSearchSubmit(overrideQuery = null) {
            const input = document.getElementById('marketSearchInput');
            const query = (overrideQuery || (input ? input.value : '')).trim();
            if (!query) {
                showToast('Eksik Bilgi', 'Lütfen aramak için bir ilaç/ürün adı veya barkod giriniz', 'error');
                return;
            }

            const loadingEl = document.getElementById('marketLoading');
            const emptyEl = document.getElementById('marketEmptyState');
            const resultsEl = document.getElementById('marketResults');
            const btn = document.getElementById('marketSearchBtn');

            if (loadingEl) loadingEl.classList.remove('hidden');
            if (emptyEl) emptyEl.classList.add('hidden');
            if (resultsEl) resultsEl.classList.add('hidden');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1.5"></i><span>Taranıyor...</span>`;
            }

            try {
                const res = await fetch(`/api/market/search?q=${encodeURIComponent(query)}`);
                if (!res.ok) {
                    const err = await res.json().catch(() => ({}));
                    throw new Error(err.error || `Arama hatası: HTTP ${res.status}`);
                }
                const data = await res.json();
                window.currentMarketReport = data;
                window.currentSelectedMarketPlatform = 'ALL';

                renderMarketReport(data);

                if (loadingEl) loadingEl.classList.add('hidden');
                if (resultsEl) resultsEl.classList.remove('hidden');
                showToast('Piyasa Taraması', `${data.toplam_teklif_sayisi} teklif bulundu`, 'success');
            } catch (err) {
                console.error("Market search error:", err);
                if (loadingEl) loadingEl.classList.add('hidden');
                if (emptyEl) emptyEl.classList.remove('hidden');
                showToast('Tarama Hatası', err.message || 'Piyasa fiyatları alınamadı', 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = `<i class="fa-solid fa-bolt mr-1.5"></i><span>Piyasayı Tara</span>`;
                }
            }
        }

        function renderMarketReport(report) {
            // Header Info
            const titleEl = document.getElementById('marketResTitle');
            const barcodeEl = document.getElementById('marketResBarcode');
            if (titleEl) titleEl.textContent = report.urun_adi || report.aranan_kelime;
            if (barcodeEl) barcodeEl.textContent = report.barkod ? `Barkod: ${report.barkod}` : `Arama: ${report.aranan_kelime}`;

            // KPIs
            const kpiDepoFiyat = document.getElementById('kpiDepoFiyat');
            const kpiDepoAdi = document.getElementById('kpiDepoAdi');
            if (kpiDepoFiyat) {
                kpiDepoFiyat.textContent = report.depo_en_dusuk_fiyat ? `${report.depo_en_dusuk_fiyat.toFixed(2)} ₺` : 'Kayıt Yok';
                kpiDepoFiyat.className = report.depo_en_dusuk_fiyat ? "text-2xl font-black text-emerald-600" : "text-2xl font-black text-slate-400";
            }
            if (kpiDepoAdi) kpiDepoAdi.textContent = report.depo_en_dusuk_adi ? `En Uygun: ${report.depo_en_dusuk_adi}` : 'Depo alış fiyatı bulunamadı';

            const kpiIntFiyat = document.getElementById('kpiInternetFiyat');
            const kpiIntPlat = document.getElementById('kpiInternetPlatform');
            if (kpiIntFiyat) {
                kpiIntFiyat.textContent = report.internet_en_dusuk_fiyat ? `${report.internet_en_dusuk_fiyat.toFixed(2)} ₺` : 'Teklif Yok';
            }
            if (kpiIntPlat) kpiIntPlat.textContent = report.internet_en_dusuk_platform ? `Platform: ${report.internet_en_dusuk_platform}` : 'Piyasada teklif yok';

            const kpiKarFark = document.getElementById('kpiKarFark');
            const kpiKarYuzde = document.getElementById('kpiKarYuzde');
            const kpiKarCard = document.getElementById('kpiKarCard');
            if (kpiKarFark && kpiKarYuzde) {
                if (report.kar_farki_tl !== null) {
                    const isPositive = report.kar_farki_tl >= 0;
                    kpiKarFark.textContent = `${isPositive ? '+' : ''}${report.kar_farki_tl.toFixed(2)} ₺`;
                    kpiKarFark.className = isPositive ? "text-2xl font-black text-emerald-600" : "text-2xl font-black text-red-600";
                    kpiKarYuzde.textContent = `Brüt Kâr: %${report.kar_yuzdesi}`;
                    if (!isPositive && kpiKarCard) {
                        kpiKarCard.classList.add('border-red-300', 'bg-red-50/20');
                    } else if (kpiKarCard) {
                        kpiKarCard.classList.remove('border-red-300', 'bg-red-50/20');
                    }
                } else {
                    kpiKarFark.textContent = '-';
                    kpiKarYuzde.textContent = 'Maliyet veya satış eksik';
                }
            }

            const kpiOrt = document.getElementById('kpiOrtalamaFiyat');
            const kpiYuk = document.getElementById('kpiYuksekFiyat');
            const kpiTop = document.getElementById('kpiToplamTeklif');
            if (kpiOrt) kpiOrt.textContent = report.internet_ortalama_fiyat ? `${report.internet_ortalama_fiyat.toFixed(2)} ₺` : '- ₺';
            if (kpiYuk) kpiYuk.textContent = report.internet_en_yuksek_fiyat ? `${report.internet_en_yuksek_fiyat.toFixed(2)} ₺` : '- ₺';
            if (kpiTop) kpiTop.textContent = `${report.platform_sayisi} Farklı Platformda ${report.toplam_teklif_sayisi} Teklif`;

            // Cheaper Warning
            const warningEl = document.getElementById('marketCheaperWarning');
            const warningText = document.getElementById('marketCheaperText');
            if (warningEl && warningText) {
                if (report.internet_depodan_ucuz && report.internet_en_dusuk_fiyat && report.depo_en_dusuk_fiyat) {
                    warningEl.classList.remove('hidden');
                    const diff = Math.abs(report.kar_farki_tl).toFixed(2);
                    warningText.innerHTML = `İnternet en ucuz perakende satış fiyatı (<b>${report.internet_en_dusuk_fiyat.toFixed(2)} ₺</b> - ${report.internet_en_dusuk_platform}), en ucuz ecza deposu alış maliyetinden (<b>${report.depo_en_dusuk_fiyat.toFixed(2)} ₺</b> - ${report.depo_en_dusuk_adi}) <b>${diff} ₺ daha ucuzdur!</b> Piyasada damping veya serbest fiyat rekabeti bulunmaktadır. Bu üründe stok yaparken dikkatli olunuz.`;
                } else {
                    warningEl.classList.add('hidden');
                }
            }

            // Render Wholesale Depo List (Left Column)
            renderDepoOzetList(report.depo_fiyatlari, report.depo_en_dusuk_fiyat);

            // Render Platform Filter Bar (Right Column)
            renderPlatformFilterChips(report.teklifler);

            // Render Retail Offers (Right Column)
            renderRetailOffersList(report.teklifler, report.depo_en_dusuk_fiyat);
        }

        function renderDepoOzetList(depoList, lowestCost) {
            const listEl = document.getElementById('depoFiyatlariList');
            const countEl = document.getElementById('depoOzetCount');
            if (!listEl) return;
            if (countEl) countEl.textContent = `${depoList.length} Depo Kaydı`;

            if (!depoList || depoList.length === 0) {
                listEl.innerHTML = `
                    <div class="py-6 text-center text-xs text-slate-400">
                        <i class="fa-solid fa-boxes-packing text-2xl mb-2 text-slate-300"></i>
                        <p>Bu ürün için ecza depolarında kayıtlı alış şartı bulunamadı veya ürün doğrudan üretici/ithalatçı kanallı OTC ürünü.</p>
                    </div>
                `;
                return;
            }

            const depoColors = {
                'ALLIANCE': 'border-l-sky-500 bg-sky-50/30 text-sky-800',
                'SELCUK': 'border-l-emerald-500 bg-emerald-50/30 text-emerald-800',
                'NEVZAT': 'border-l-orange-500 bg-orange-50/30 text-orange-800',
                'ISKOOP': 'border-l-red-500 bg-red-50/30 text-red-800',
                'BEK': 'border-l-teal-500 bg-teal-50/30 text-teal-800',
                'FARMAZON': 'border-l-amber-500 bg-amber-50/30 text-amber-800',
                'ECZA1': 'border-l-purple-500 bg-purple-50/30 text-purple-800',
                'DNA': 'border-l-cyan-500 bg-cyan-50/30 text-cyan-800',
                'ECZATREND': 'border-l-orange-500 bg-orange-50/30 text-orange-800',
                'ECZANETAKAS': 'border-l-sky-500 bg-sky-50/30 text-sky-800',
            };

            let html = '';
            depoList.forEach(df => {
                const isBest = lowestCost && Math.abs(df.net_birim_maliyet_kdvli - lowestCost) < 0.05;
                const colorCls = depoColors[df.depo] || 'border-l-slate-400 bg-slate-50 text-slate-800';

                html += `
                    <div class="py-3 px-3 rounded-xl border-l-4 ${colorCls} my-1.5 transition hover:bg-slate-50">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-1.5">
                                <span class="font-bold text-xs text-slate-900">${df.depo_adi}</span>
                                ${isBest ? '<span class="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-emerald-600 text-white">EN İYİ</span>' : ''}
                            </div>
                            <span class="text-sm font-black text-slate-900">${df.net_birim_maliyet_kdvli.toFixed(2)} ₺</span>
                        </div>
                        <div class="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                            <span>MF: <b class="text-slate-700 font-semibold">${df.mf_metni}</b></span>
                            <span>KDV Hariç: <b>${df.net_birim_maliyet.toFixed(2)} ₺</b></span>
                        </div>
                        <div class="mt-1 flex items-center justify-between text-[10px] text-slate-400">
                            <span>Stok: <b class="${df.stok_durumu === 'VAR' ? 'text-emerald-600' : 'text-slate-500'}">${df.stok_durumu}${df.stok_adedi ? ` (${df.stok_adedi} adet)` : ''}</b></span>
                            ${df.miad ? `<span>Miad: ${df.miad}</span>` : ''}
                        </div>
                    </div>
                `;
            });
            listEl.innerHTML = html;
        }

        function renderPlatformFilterChips(offers) {
            const barEl = document.getElementById('platformFilterBar');
            if (!barEl) return;

            // Count per platform
            const counts = {};
            offers.forEach(o => {
                counts[o.platform] = (counts[o.platform] || 0) + 1;
            });

            const platformNames = {
                'TRENDYOL': 'Trendyol',
                'HEPSIBURADA': 'Hepsiburada',
                'DERMOECZANEM': 'Dermoeczanem',
                'SACHANE': 'Sachane',
                'DERMOKOZMETIKA': 'Dermokozmetika',
                'KIRMIZIBEYAZ': 'Kırmızıbeyaz',
                'DERMOJET': 'Dermojet',
                'KOZVIT': 'Kozvit',
                'DAFFNE': 'Daffne',
            };

            let html = `
                <button onclick="filterMarketPlatform('ALL')" class="px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${window.currentSelectedMarketPlatform === 'ALL' ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'}">
                    Tüm Platformlar (${offers.length})
                </button>
            `;

            Object.keys(counts).forEach(pKey => {
                const isSelected = window.currentSelectedMarketPlatform === pKey;
                const pName = platformNames[pKey] || pKey;
                html += `
                    <button onclick="filterMarketPlatform('${pKey}')" class="px-3 py-1.5 rounded-xl text-xs font-semibold transition shrink-0 cursor-pointer ${isSelected ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'}">
                        ${pName} (${counts[pKey]})
                    </button>
                `;
            });

            barEl.innerHTML = html;
        }

        function filterMarketPlatform(platformKey) {
            window.currentSelectedMarketPlatform = platformKey;
            if (!window.currentMarketReport) return;

            renderPlatformFilterChips(window.currentMarketReport.teklifler);

            let filtered = window.currentMarketReport.teklifler;
            if (platformKey !== 'ALL') {
                filtered = filtered.filter(o => o.platform === platformKey);
            }
            renderRetailOffersList(filtered, window.currentMarketReport.depo_en_dusuk_fiyat);
        }

        function togglePlatformOffers(platKey) {
            const drawer = document.getElementById(`platDrawer_${platKey}`);
            const chevron = document.getElementById(`platChevron_${platKey}`);
            if (!drawer) return;
            if (drawer.classList.contains('hidden')) {
                drawer.classList.remove('hidden');
                if (chevron) chevron.style.transform = 'rotate(180deg)';
            } else {
                drawer.classList.add('hidden');
                if (chevron) chevron.style.transform = 'rotate(0deg)';
            }
        }

        function renderRetailOffersList(offers, depoCost) {
            const listEl = document.getElementById('retailOffersList');
            if (!listEl) return;

            if (!offers || offers.length === 0) {
                listEl.innerHTML = `
                    <div class="bg-white p-8 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
                        Bu platformda veya kriterde teklif bulunamadı.
                    </div>
                `;
                return;
            }

            const platformBadges = {
                'TRENDYOL': { bg: 'bg-orange-500', text: 'Trendyol', icon: 'fa-tag', border: 'border-orange-200' },
                'HEPSIBURADA': { bg: 'bg-amber-600', text: 'Hepsiburada', icon: 'fa-tag', border: 'border-amber-200' },
                'SACHANE': { bg: 'bg-pink-600', text: 'Sachane', icon: 'fa-scissors', border: 'border-pink-200' },
                'DERMOECZANEM': { bg: 'bg-emerald-600', text: 'Dermoeczanem', icon: 'fa-shield-heart', border: 'border-emerald-200' },
                'DERMOKOZMETIKA': { bg: 'bg-indigo-600', text: 'Dermokozmetika', icon: 'fa-sparkles', border: 'border-indigo-200' },
                'KIRMIZIBEYAZ': { bg: 'bg-rose-600', text: 'Kırmızıbeyaz', icon: 'fa-plus', border: 'border-rose-200' },
                'DERMOJET': { bg: 'bg-cyan-600', text: 'Dermojet', icon: 'fa-plane', border: 'border-cyan-200' },
                'KOZVIT': { bg: 'bg-purple-600', text: 'Kozvit', icon: 'fa-star', border: 'border-purple-200' },
                'DAFFNE': { bg: 'bg-teal-600', text: 'Daffne', icon: 'fa-leaf', border: 'border-teal-200' },
            };

            // 1. Platform bazında teklifleri grupla
            const groups = {};
            offers.forEach(o => {
                if (!groups[o.platform]) groups[o.platform] = [];
                groups[o.platform].push(o);
            });

            // 2. Her gruptaki teklifleri fiyata göre sırala
            Object.keys(groups).forEach(pKey => {
                groups[pKey].sort((a, b) => a.fiyat - b.fiyat);
            });

            // 3. Platformları en ucuz tekliflerine göre sırala
            const sortedPlatforms = Object.keys(groups).sort((a, b) => {
                return groups[a][0].fiyat - groups[b][0].fiyat;
            });

            let html = '';
            sortedPlatforms.forEach((pKey, pIdx) => {
                const pOffers = groups[pKey];
                const bestOffer = pOffers[0];
                const plat = platformBadges[pKey] || { bg: 'bg-slate-700', text: bestOffer.platform_adi, icon: 'fa-bag-shopping', border: 'border-slate-200' };

                // Kâr marjı (en ucuz teklife göre)
                let marginHtml = '';
                if (depoCost && depoCost > 0) {
                    const diff = bestOffer.fiyat - depoCost;
                    const pct = ((diff / depoCost) * 100).toFixed(1);
                    if (diff >= 0) {
                        marginHtml = `<span class="px-2 py-0.5 rounded-md text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">+${diff.toFixed(2)} ₺ (%${pct} Kâr)</span>`;
                    } else {
                        marginHtml = `<span class="px-2 py-0.5 rounded-md text-[11px] font-bold bg-red-50 text-red-700 border border-red-200">${diff.toFixed(2)} ₺ Depodan Ucuz!</span>`;
                    }
                }

                const imgHtml = bestOffer.gorsel_url 
                    ? `<img src="${bestOffer.gorsel_url}" alt="${bestOffer.urun_adi}" class="w-14 h-14 object-contain rounded-xl bg-slate-50 border border-slate-100 p-1 shrink-0" onerror="this.src='https://via.placeholder.com/56?text=Foto'"/>`
                    : `<div class="w-14 h-14 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400 text-base shrink-0"><i class="fa-solid fa-box"></i></div>`;

                const hasMultiple = pOffers.length > 1;

                // Alt Kıvrım (Accordion Sub-Panel) HTML
                let drawerHtml = '';
                if (hasMultiple) {
                    let subItemsHtml = pOffers.map((sub, sIdx) => {
                        let subMarginHtml = '';
                        if (depoCost && depoCost > 0) {
                            const diff = sub.fiyat - depoCost;
                            const pct = ((diff / depoCost) * 100).toFixed(1);
                            subMarginHtml = diff >= 0 
                                ? `<span class="text-[10px] font-semibold text-emerald-600">+${diff.toFixed(2)} ₺ (%${pct})</span>`
                                : `<span class="text-[10px] font-semibold text-red-600">${diff.toFixed(2)} ₺</span>`;
                        }

                        return `
                            <div class="p-2.5 rounded-xl bg-slate-50/90 border border-slate-200/80 hover:bg-slate-100/80 transition flex items-center justify-between gap-3 text-xs">
                                <div class="flex items-center gap-2.5 min-w-0 flex-1">
                                    <span class="w-5 h-5 rounded-full ${sIdx === 0 ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'} flex items-center justify-center text-[10px] font-bold shrink-0">
                                        ${sIdx + 1}
                                    </span>
                                    <div class="min-w-0 flex-1">
                                        <div class="flex items-center gap-2">
                                            <span class="font-bold text-slate-800 truncate">${sub.satici || 'Pazaryeri Satıcısı'}</span>
                                            ${sub.puan ? `<span class="text-[10px] text-amber-600 font-bold flex items-center gap-0.5"><i class="fa-solid fa-star text-[8px]"></i>${sub.puan}</span>` : ''}
                                            ${sIdx === 0 ? '<span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800">En Düşük Fiyat</span>' : ''}
                                        </div>
                                        <div class="text-[11px] text-slate-500 truncate" title="${sub.urun_adi}">${sub.urun_adi}</div>
                                    </div>
                                </div>
                                <div class="flex items-center gap-3 shrink-0">
                                    <div class="text-right">
                                        <div class="text-sm font-black text-slate-900">${sub.fiyat.toFixed(2)} ₺</div>
                                        ${subMarginHtml}
                                    </div>
                                    <a href="${sub.url}" target="_blank" rel="noopener noreferrer" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-800 hover:bg-indigo-600 text-white transition flex items-center gap-1 shadow-2xs cursor-pointer">
                                        <span>Git</span>
                                        <i class="fa-solid fa-arrow-up-right-from-square text-[9px]"></i>
                                    </a>
                                </div>
                            </div>
                        `;
                    }).join('');

                    drawerHtml = `
                        <div id="platDrawer_${pKey}" class="hidden mt-3 pt-3 border-t border-dashed border-slate-200">
                            <div class="mb-2 flex items-center justify-between text-[11px] font-bold text-slate-500 px-1">
                                <span><i class="fa-solid fa-store mr-1 text-slate-400"></i>${plat.text} Üzerindeki Tüm Satıcılar (${pOffers.length} Teklif)</span>
                                <span>Ucuzdan Pahalıya</span>
                            </div>
                            <div class="space-y-1.5">
                                ${subItemsHtml}
                            </div>
                        </div>
                    `;
                }

                html += `
                    <div class="bg-white p-4 rounded-2xl border ${plat.border} shadow-xs hover:shadow-md transition">
                        <!-- PLATFORM ANA SATIRI -->
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div class="flex items-center gap-3 min-w-0 flex-1">
                                ${imgHtml}
                                <div class="min-w-0 flex-1">
                                    <div class="flex flex-wrap items-center gap-1.5 mb-1">
                                        <span class="px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase text-white ${plat.bg} flex items-center gap-1">
                                            <i class="fa-solid ${plat.icon} text-[9px]"></i>
                                            <span>${plat.text}</span>
                                        </span>
                                        ${pIdx === 0 ? '<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-600 text-white">EN UCUZ PLATFORM</span>' : ''}
                                        
                                        <!-- ALT KIVRIM BUTONU -->
                                        ${hasMultiple ? `
                                            <button type="button" onclick="togglePlatformOffers('${pKey}')" class="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition flex items-center gap-1 cursor-pointer" title="Diğer satıcı fiyatlarını gör">
                                                <i class="fa-solid fa-layer-group text-[9px]"></i>
                                                <span>${pOffers.length} Farklı Satıcı Fiyatı</span>
                                                <i id="platChevron_${pKey}" class="fa-solid fa-chevron-down text-[8px] transition-transform duration-200"></i>
                                            </button>
                                        ` : `
                                            <span class="text-[10px] text-slate-400 font-semibold">(Tek Satıcı)</span>
                                        `}
                                    </div>
                                    <h4 class="text-xs font-bold text-slate-900 leading-snug line-clamp-1" title="${bestOffer.urun_adi}">
                                        ${bestOffer.urun_adi}
                                    </h4>
                                    <div class="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                                        ${bestOffer.satici ? `<span>En Uygun Satıcı: <b class="text-slate-700">${bestOffer.satici}</b></span>` : ''}
                                        ${marginHtml}
                                    </div>
                                </div>
                            </div>

                            <div class="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100">
                                <div class="text-right">
                                    <div class="text-lg font-black text-slate-900">${bestOffer.fiyat.toFixed(2)} ₺</div>
                                    ${bestOffer.eski_fiyat && bestOffer.eski_fiyat > bestOffer.fiyat ? `<div class="text-[11px] text-slate-400 line-through font-medium">${bestOffer.eski_fiyat.toFixed(2)} ₺</div>` : ''}
                                </div>
                                <div class="flex items-center gap-1.5 mt-1">
                                    ${hasMultiple ? `
                                        <button type="button" onclick="togglePlatformOffers('${pKey}')" class="px-2.5 py-1 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1 cursor-pointer">
                                            <span>Detay</span>
                                            <i class="fa-solid fa-chevron-down text-[9px]"></i>
                                        </button>
                                    ` : ''}
                                    <a href="${bestOffer.url}" target="_blank" rel="noopener noreferrer" class="px-3 py-1 rounded-xl text-xs font-bold bg-slate-900 hover:bg-indigo-600 text-white transition flex items-center gap-1 shadow-xs cursor-pointer">
                                        <span>Ürüne Git</span>
                                        <i class="fa-solid fa-arrow-up-right-from-square text-[9px]"></i>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- ALT KIVRIM (DRAWER) -->
                        ${drawerHtml}
                    </div>
                `;
            });

            listEl.innerHTML = html;
        }

        // ==========================================
        // Market Arama İçin Canlı Akıllı Öneri (Suggest)
        // ==========================================
        function initMarketSuggest() {
            const marketInput = document.getElementById('marketSearchInput');
            const marketSuggestBox = document.getElementById('marketSuggestBox');
            if (!marketInput || !marketSuggestBox) return;

            let mDebounce;
            marketInput.addEventListener('input', function() {
                clearTimeout(mDebounce);
                const val = this.value.trim();
                if (val.length < 2) {
                    marketSuggestBox.classList.add('hidden');
                    return;
                }
                mDebounce = setTimeout(async () => {
                    try {
                        const res = await fetch(`/api/catalog/suggest?q=${encodeURIComponent(val)}`);
                        if (res.ok) {
                            const items = await res.json();
                            renderMarketSuggestions(items);
                        }
                    } catch(e) {
                        console.error("Market suggest error:", e);
                    }
                }, 80);
            });

            document.addEventListener('click', (e) => {
                if (!marketInput.contains(e.target) && !marketSuggestBox.contains(e.target)) {
                    marketSuggestBox.classList.add('hidden');
                }
            });
        }

        function renderMarketSuggestions(items) {
            const marketInput = document.getElementById('marketSearchInput');
            const marketSuggestBox = document.getElementById('marketSuggestBox');
            if (!marketSuggestBox) return;
            if (!items || items.length === 0) {
                marketSuggestBox.classList.add('hidden');
                return;
            }
            marketSuggestBox.innerHTML = '';
            items.forEach(item => {
                const multiBadge = (item.barcode_count && item.barcode_count > 1)
                    ? `<span class="ml-1.5 px-1.5 py-0.5 text-[10px] font-semibold bg-indigo-100 text-indigo-800 rounded border border-indigo-200" title="Kayıtlı Tüm Barkodlar: ${(item.all_barcodes || []).join(', ')}">+${item.barcode_count - 1} Barkod</span>`
                    : '';
                const div = document.createElement('div');
                div.className = 'px-4 py-3 hover:bg-indigo-50/70 cursor-pointer flex items-center justify-between transition';
                div.innerHTML = `
                    <div class="flex items-center space-x-3">
                        <div class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center text-xs font-bold shrink-0">
                            <i class="fa-solid fa-sparkles"></i>
                        </div>
                        <div>
                            <div class="text-sm font-semibold text-slate-800">${item.name}</div>
                            <div class="text-xs text-slate-400 font-mono">${item.barcode}${multiBadge} • <span class="text-indigo-600 font-medium">${item.manufacturer || 'Genel'}</span></div>
                        </div>
                    </div>
                    <div class="text-right">
                        ${item.price ? `<div class="text-xs font-bold text-slate-700">${item.price.toFixed(2)} ₺</div>` : ''}
                        <span class="text-[10px] text-indigo-600 font-semibold">Seç & Tara ↗</span>
                    </div>
                `;
                div.addEventListener('click', () => {
                    marketInput.value = item.name;
                    marketSuggestBox.classList.add('hidden');
                    handleMarketSearchSubmit(item.barcode);
                });
                marketSuggestBox.appendChild(div);
            });
            marketSuggestBox.classList.remove('hidden');
        }

"""
