import asyncio
import datetime
import html as html_lib
import json
import logging
import os
import re
import time
from typing import List, Optional, Dict, Any
import httpx

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.core.session_store import SessionStore
from backend.catalog import catalog

logger = logging.getLogger("eczatrend_adapter")


def _norm_tr_name(s: str) -> str:
    if not s:
        return ""
    s = s.upper().translate(str.maketrans("ÇĞİÖŞÜIîÂÊÛ", "CGIOSUIIAEO"))
    return re.sub(r"[^A-Z0-9]", "", s)


class EczatrendAdapter(BaseDepoAdapter):
    """
    Eczatrend (eczatrend.com) Eczaneler Arası Ortak Alım Grubu & Barem Takas Adaptörü.
    'Grubumun Teklifleri' (menualloffer) sayfasındaki kampanyaları, baremleri,
    hedeflenen adetleri, kalan adetleri ve KDV'li/KDV'siz net birim fiyatları çeker.
    """
    LOGIN_URL = "https://eczatrend.com/gtsp/ajax/login"
    MAIN_URL = "https://eczatrend.com/eczanet/panelNew/main"
    PANEL_URL = "https://eczatrend.com/eczanet/panelNew/main.html"
    ONSALE_URL = "https://eczatrend.com/eczanet/panel/onSale"
    PREREQUEST_URL = "https://eczatrend.com/eczanet/panel/prerequest"
    PURCHASE_URL = "https://eczatrend.com/eczanet/panel/purchase"
    SELECTED_GROUP_URL = "https://eczatrend.com/gtsp/ajax/selectedGroup"

    _OFFERS_CACHE: List[Dict[str, Any]] = []
    _RAW_OFFERS_CACHE: List[Dict[str, Any]] = []
    _OFFERS_CACHE_TIME: float = 0.0
    _OFFERS_CACHE_TTL: float = 90.0
    _BOOTSTRAP_CACHE: Optional[Dict[str, Any]] = None
    _BOOTSTRAP_CACHE_TIME: float = 0.0
    _BOOTSTRAP_CACHE_TTL: float = 180.0
    _FETCH_LOCK: Optional[asyncio.Lock] = None

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ECZATREND, "Eczatrend Alım Grubu")
        self.username = (username or os.environ.get("ECZATREND_USERNAME", "")).strip()
        self.password = (password or os.environ.get("ECZATREND_PASSWORD", "")).strip()
        self.headless = headless
        self.session_data: Optional[Dict[str, Any]] = None
        self._client: Optional[httpx.AsyncClient] = None

    def _get_headers(self) -> Dict[str, str]:
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Origin": "https://eczatrend.com",
            "Referer": "https://eczatrend.com/eczanet/panelNew/main",
            "Content-Type": "application/x-www-form-urlencoded",
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "application/json, text/javascript, */*; q=0.01"
        }

    async def _get_client(self, reset: bool = False) -> httpx.AsyncClient:
        if reset and self._client is not None:
            try:
                await self._client.aclose()
            except Exception:
                pass
            self._client = None
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers=self._get_headers(),
                follow_redirects=True,
                timeout=25.0,
                verify=False
            )
            # Kayıtlı oturumu yükle
            cached = SessionStore.load_state("eczatrend")
            if cached and isinstance(cached, dict) and "cookies" in cached:
                for k, v in cached["cookies"].items():
                    self._client.cookies.set(k, v, domain="eczatrend.com")
                self.session_data = cached
        return self._client

    async def is_session_valid(self) -> bool:
        """Kayıtlı oturum çerezinin geçerli olup olmadığını kontrol eder."""
        client = await self._get_client()
        if "eria_session" not in client.cookies:
            return False

        try:
            payload = {
                "action": "purchaseGrid",
                "searchMiadSwitch": "true",
                "searchTargetSwitch": "false",
                "searchPharmacyOfferSwitch": "true",
                "page": "0",
                "priority": "2",
                "productName": "",
                "pharmacy": "",
                "selectedMenu": "menualloffer",
                "directSalesCategory": "",
                "taxFilter": "0"
            }
            resp = await client.post(self.MAIN_URL, data=payload)
            if resp.status_code == 200 and resp.text and resp.text.strip() and not resp.text.startswith("<"):
                data = resp.json()
                if "data" in data or "firstmes" in data:
                    self.is_logged_in = True
                    return True
        except Exception:
            pass
        return False

    async def login(self, force_fresh: bool = False) -> bool:
        """Eczatrend B2B ortak alım portalına giriş yapar."""
        if not self.username or not self.password:
            raise ValueError("Eczatrend için Kullanıcı Adı ve Şifre zorunludur.")

        client = await self._get_client()

        # 1. Mevcut çerez hala geçerli mi?
        if not force_fresh and await self.is_session_valid():
            logger.info("[Eczatrend] Mevcut oturum aktif, doğrudan devam ediliyor.")
            return True

        # Eski/bozuk çerezleri temizle
        client.cookies.clear()
        SessionStore.clear("eczatrend")
        self.is_logged_in = False

        logger.info("[Eczatrend] Oturum açılıyor (%s)...", self.username)
        login_payload = {
            "username": self.username,
            "password": self.password,
            "remember": "true"
        }

        try:
            login_headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Origin": "https://eczatrend.com",
                "Referer": "https://eczatrend.com/eczanet/site/sitelogin",
                "X-Requested-With": "XMLHttpRequest"
            }
            resp = await client.post(self.LOGIN_URL, data=login_payload, headers=login_headers)
            if resp.status_code != 200:
                raise RuntimeError(f"Giriş isteği başarısız: HTTP {resp.status_code}")

            res_json = resp.json()
            if not res_json.get("success"):
                err_msg = res_json.get("message") or "Kullanıcı adı veya şifre hatalı."
                raise RuntimeError(f"Eczatrend Giriş Başarısız: {err_msg}")

            # Oturumu kaydet
            cookie_dict = dict(client.cookies)
            state_data = {
                "cookies": cookie_dict,
                "pharmacyName": res_json.get("pharmacyName", ""),
                "userName": res_json.get("userName", ""),
                "userRealName": res_json.get("userRealName", "")
            }
            SessionStore.save_state("eczatrend", state_data)
            self.session_data = state_data
            self.is_logged_in = True
            logger.info("[Eczatrend] Giriş başarılı! Eczane: %s", res_json.get("pharmacyName"))
            return True

        except Exception as e:
            logger.error("[Eczatrend] Giriş hatası: %s", e)
            self.is_logged_in = False
            raise

    async def _query_purchase_grid_json(self, product_name: str = "", offset: int = 0) -> Dict[str, Any]:
        """Eczatrend purchaseGrid uç noktasından ham JSON yanıtını (data + secondmes toplam sayı) döndürür.
        Not: Eczatrend'de 'page' parametresi sayfa numarası değil SQL OFFSET değeridir (0, 24, 48, 72...).
        searchTargetSwitch='false' gönderildiğinde hedefi dolmuş (kapalı) teklifler elenir, yalnızca açık teklifler gelir.
        """
        client = await self._get_client()
        if not self.is_logged_in:
            await self.login()

        payload = {
            "action": "purchaseGrid",
            "searchMiadSwitch": "true",
            "searchTargetSwitch": "false",
            "searchPharmacyOfferSwitch": "true",
            "page": str(offset),
            "priority": "2",
            "productName": product_name,
            "pharmacy": "",
            "selectedMenu": "menualloffer",
            "directSalesCategory": "",
            "taxFilter": "0"
        }

        for attempt in range(2):
            try:
                resp = await client.post(self.MAIN_URL, data=payload)
            except RuntimeError:
                client = await self._get_client(reset=True)
                resp = await client.post(self.MAIN_URL, data=payload)

            if resp.status_code != 200 or resp.text.startswith("<") or "sitelogin" in resp.text:
                logger.warning("[Eczatrend] Oturum süresi dolmuş, yeniden giriş yapılıyor...")
                await self.login(force_fresh=True)
                resp = await client.post(self.MAIN_URL, data=payload)

            if resp.status_code == 200 and resp.text and resp.text.strip() and not resp.text.startswith("<"):
                try:
                    return resp.json()
                except Exception:
                    pass
            await asyncio.sleep(0.12)

        return {}

    async def _query_purchase_grid(self, product_name: str = "", page: int = 0) -> List[Dict[str, Any]]:
        """Eczatrend purchaseGrid uç noktasından ham teklif listesini döndürür."""
        j = await self._query_purchase_grid_json(product_name=product_name, offset=page)
        return j.get("data") or []

    async def get_active_offers(self, force_refresh: bool = False, search_query: str = "") -> List[Dict[str, Any]]:
        """
        Eczatrend 'Grubumun Teklifleri' sayfasındaki TÜM aktif ortak alım tekliflerini
        (SQL offset: 0, 24, 48, ... üzerinden paralel çekerek) normalize edilmiş sözlük listesi olarak döndürür.
        """
        now = time.time()
        clean_sq = (search_query or "").strip()

        if not clean_sq and not force_refresh and EczatrendAdapter._OFFERS_CACHE and (now - EczatrendAdapter._OFFERS_CACHE_TIME < EczatrendAdapter._OFFERS_CACHE_TTL):
            return EczatrendAdapter._OFFERS_CACHE

        if EczatrendAdapter._FETCH_LOCK is None:
            EczatrendAdapter._FETCH_LOCK = asyncio.Lock()

        async with EczatrendAdapter._FETCH_LOCK:
            now = time.time()
            if not clean_sq and not force_refresh and EczatrendAdapter._OFFERS_CACHE and (now - EczatrendAdapter._OFFERS_CACHE_TIME < EczatrendAdapter._OFFERS_CACHE_TTL):
                return EczatrendAdapter._OFFERS_CACHE

            j0 = await self._query_purchase_grid_json(product_name=clean_sq, offset=0)
            raw_all: List[Dict[str, Any]] = list(j0.get("data") or [])
            try:
                total_reported = int(str(j0.get("secondmes") or "0").strip())
            except Exception:
                total_reported = len(raw_all)

            max_offset = min(total_reported, 240 if clean_sq else 1500)
            if len(raw_all) >= 24 and max_offset > 24:
                offsets = list(range(24, max_offset, 24))
                sem = asyncio.Semaphore(6)

                async def _fetch_offset(off: int) -> List[Dict[str, Any]]:
                    async with sem:
                        try:
                            j_page = await self._query_purchase_grid_json(product_name=clean_sq, offset=off)
                            return j_page.get("data") or []
                        except Exception as e:
                            logger.warning("[Eczatrend] Offset %d çekilirken hata: %s", off, e)
                            return []

                pages = await asyncio.gather(*(_fetch_offset(o) for o in offsets))
                for p_items in pages:
                    if p_items:
                        raw_all.extend(p_items)

            seen_pks = set()
            normalized_offers: List[Dict[str, Any]] = []
            for it in raw_all:
                offer_pk = str(it.get("offerPK") or "").strip()
                if offer_pk and offer_pk in seen_pks:
                    continue
                if offer_pk:
                    seen_pks.add(offer_pk)

                try:
                    left_target = int(float(str(it.get("leftTarget") or "0").strip()))
                except Exception:
                    left_target = 0
                if left_target <= 0:
                    continue

                try:
                    target_amount = int(float(str(it.get("offertarget") or "0").strip()))
                except Exception:
                    target_amount = 0

                try:
                    total_purchase = int(float(str(it.get("totalPurchase") or "0").strip()))
                except Exception:
                    total_purchase = 0

                try:
                    net_price_kdvli = float(str(it.get("netprice") or "0").replace(",", ".").strip())
                except Exception:
                    net_price_kdvli = 0.0

                try:
                    net_price_kdvsiz = float(str(it.get("vatExcludedNetPrice") or "0").replace(",", ".").strip())
                except Exception:
                    net_price_kdvsiz = 0.0

                try:
                    market_price = float(str(it.get("marketPrice") or "0").replace(",", ".").strip())
                except Exception:
                    market_price = 0.0

                try:
                    product_price = float(str(it.get("productPrice") or "0").replace(",", ".").strip())
                except Exception:
                    product_price = 0.0

                try:
                    product_vat = float(str(it.get("productVat") or "10").replace(",", ".").strip())
                except Exception:
                    product_vat = 10.0

                p_bc = str(it.get("productBarcode") or "").strip()
                p_name = str(it.get("productName") or "").strip()
                offer_mf = str(it.get("offerMF") or "").strip()
                pharmacy_name = str(it.get("pharmacy") or "Grup Eczanesi").strip()
                group_name = str(it.get("groupName") or "Ortak Alım").strip()
                expire_dt = str(it.get("expireDT") or "").strip()
                offer_load = str(it.get("offerload") or "0").strip()

                normalized_offers.append({
                    "offer_id": offer_pk,
                    "urun_adi": p_name,
                    "barcode": p_bc,
                    "satici": pharmacy_name,
                    "groupName": group_name,
                    "mf": offer_mf,
                    "hedef": target_amount,
                    "alinan": total_purchase,
                    "kalan": left_target,
                    "doluluk": f"%{offer_load}",
                    "depo_fiyati": market_price,
                    "psf": product_price,
                    "kdv": product_vat,
                    "fiyat_kdvsiz": net_price_kdvsiz,
                    "fiyat_kdvli": net_price_kdvli,
                    "kalan_sure": expire_dt,
                    "katil_url": "https://eczatrend.com/eczanet/panelNew/main.html"
                })

            if not clean_sq:
                EczatrendAdapter._OFFERS_CACHE = normalized_offers
                EczatrendAdapter._RAW_OFFERS_CACHE = raw_all
                EczatrendAdapter._OFFERS_CACHE_TIME = time.time()

            return normalized_offers

    async def search_product(self, query: str, include_equivalents: bool = False, is_background: bool = False) -> List[DepoUrunSarti]:
        """
        'Grubumun Teklifleri' (menualloffer) listesinde ürün veya barkod sorgular.
        Teklifin baremini, hedefini, kalan miktarını ve birim fiyatını çeker.
        """
        clean_q = query.strip()
        if not clean_q:
            return []

        try:
            is_barcode_query = clean_q.isdigit() and len(clean_q) >= 8
            catalog_name = None
            if is_barcode_query:
                try:
                    prod = catalog.get_by_barcode(clean_q)
                    if prod and prod.get("name"):
                        catalog_name = prod["name"]
                except Exception:
                    pass

            # Önce önbellekteki (675+ aktif grup teklifi) tam listeden eşleşme kontrolü yap
            if EczatrendAdapter._RAW_OFFERS_CACHE and (time.time() - EczatrendAdapter._OFFERS_CACHE_TIME < EczatrendAdapter._OFFERS_CACHE_TTL):
                cached_res = self._parse_offer_items(EczatrendAdapter._RAW_OFFERS_CACHE, clean_q, catalog_name=catalog_name)
                if cached_res:
                    return cached_res

            raw_items = await self._query_purchase_grid(product_name=clean_q, page=0)

            if not raw_items and is_barcode_query and catalog_name and not is_background:
                first_word = catalog_name.split()[0] if catalog_name.split() else ""
                if len(first_word) >= 3:
                    raw_items = await self._query_purchase_grid(product_name=first_word, page=0)

            if not raw_items:
                return []

            return self._parse_offer_items(raw_items, clean_q, catalog_name=catalog_name)

        except Exception as e:
            logger.error("[Eczatrend] Arama sırasında hata: %s", e)
            return []

    def _parse_offer_items(self, items: List[Dict[str, Any]], query: str, catalog_name: Optional[str] = None) -> List[DepoUrunSarti]:
        """Eczatrend API'sinden gelen teklif listesini DepoUrunSarti formatına dönüştürür."""
        is_barcode_query = query.isdigit() and len(query) >= 8
        query_lower = query.lower()
        norm_cat = _norm_tr_name(catalog_name) if catalog_name else ""
        norm_q = _norm_tr_name(query) if not is_barcode_query else ""

        matched_offers = []
        for it in items:
            p_bc = str(it.get("productBarcode") or "").strip()
            p_name = str(it.get("productName") or "").strip()
            norm_p = _norm_tr_name(p_name)

            # Barkod veya isim eşleşmesi
            if is_barcode_query:
                bc_ok = (p_bc == query or query in p_bc)
                name_ok = bool(norm_cat and norm_p and (norm_cat in norm_p or norm_p in norm_cat))
                if not (bc_ok or name_ok):
                    continue
            else:
                if query_lower not in p_name.lower() and query_lower not in p_bc and (not norm_q or norm_q not in norm_p):
                    continue

            matched_offers.append(it)

        if not matched_offers:
            return []

        # Her teklif detayını hazırla
        pazaryeri_teklifleri = []
        for it in matched_offers:
            try:
                left_target = int(float(str(it.get("leftTarget") or "0").strip()))
            except Exception:
                left_target = 0

            try:
                target_amount = int(float(str(it.get("offertarget") or "0").strip()))
            except Exception:
                target_amount = 0

            try:
                total_purchase = int(float(str(it.get("totalPurchase") or "0").strip()))
            except Exception:
                total_purchase = 0

            try:
                net_price_kdvli = float(str(it.get("netprice") or "0").replace(",", ".").strip())
            except Exception:
                net_price_kdvli = 0.0

            try:
                net_price_kdvsiz = float(str(it.get("vatExcludedNetPrice") or "0").replace(",", ".").strip())
            except Exception:
                net_price_kdvsiz = 0.0

            try:
                market_price = float(str(it.get("marketPrice") or "0").replace(",", ".").strip())
            except Exception:
                market_price = 0.0

            try:
                product_price = float(str(it.get("productPrice") or "0").replace(",", ".").strip())
            except Exception:
                product_price = 0.0

            try:
                product_vat = float(str(it.get("productVat") or "10").replace(",", ".").strip())
            except Exception:
                product_vat = 10.0

            offer_mf = str(it.get("offerMF") or "").strip()
            pharmacy_name = str(it.get("pharmacy") or "Grup Eczanesi").strip()
            group_name = str(it.get("groupName") or "Ortak Alım").strip()
            expire_dt = str(it.get("expireDT") or "").strip()
            offer_pk = str(it.get("offerPK") or "").strip()
            offer_load = str(it.get("offerload") or "0").strip()

            pazaryeri_teklifleri.append({
                "offer_id": offer_pk,
                "satici": pharmacy_name,
                "pharmacy": pharmacy_name,
                "groupName": group_name,
                "fiyat": net_price_kdvli,
                "fiyat_kdvsiz": net_price_kdvsiz,
                "depocu_fiyat": market_price,
                "psf": product_price,
                "kdv": product_vat,
                "mf": offer_mf,
                "hedef": target_amount,
                "kalan": left_target,
                "alinan": total_purchase,
                "doluluk": f"%{offer_load}",
                "kalan_sure": expire_dt,
                "tur": str(it.get("offerSpecialTypeFK") or "Grup Teklifi"),
                "durum": "Alıma Açık" if left_target > 0 else "Hedefe Ulaştı (Kapalı)"
            })

        # Sadece açık teklifleri (kalan > 0) öne al; hiç açık teklif yoksa karşılaştırma tablosunu kalabalıklaştırma
        open_offers = [x for x in pazaryeri_teklifleri if x["kalan"] > 0]
        if not open_offers:
            return []

        open_offers.sort(key=lambda x: (x["fiyat"] if x["fiyat"] > 0 else 999999))

        best = open_offers[0]
        first_raw = matched_offers[0]

        primary_barcode = str(first_raw.get("productBarcode") or (query if is_barcode_query else "")).strip()
        primary_name = str(first_raw.get("productName") or f"Ürün ({primary_barcode})").strip()

        stok_durumu = StokDurumu.VAR
        kalan_adet = best["kalan"]
        hedef_adet = best["hedef"]
        mf_text = best["mf"] or "BAREM"

        kampanya_notu = (
            f"🎯 Barem: {mf_text} | Kalan: {kalan_adet} Adet (Hedef: {hedef_adet}, Doluluk: {best['doluluk']}) | "
            f"Eczane: {best['satici']} ({best['groupName']})"
        )

        depocu_fiyat = best["depocu_fiyat"]
        net_maliyet = best["fiyat_kdvsiz"]
        net_kdvli = best["fiyat"]

        # İndirim yüzdesi
        indirim = 0.0
        if depocu_fiyat > 0 and net_maliyet > 0:
            indirim = round((1 - (net_maliyet / depocu_fiyat)) * 100, 2)

        sart = DepoUrunSarti(
            depo=DepoKodu.ECZATREND,
            depo_adi="Eczatrend (Alım Grubu)",
            barkod=primary_barcode,
            urun_id=best["offer_id"],
            urun_adi=primary_name,
            stok_durumu=stok_durumu,
            stok_adedi=kalan_adet,
            depocu_satis_fiyati=depocu_fiyat,
            perakende_satis_fiyati=best["psf"],
            kdv_orani=best["kdv"],
            mf_metni=mf_text,
            ticari_iskonto=0.0,
            vade_gun=30,
            net_birim_maliyet=net_maliyet,
            net_birim_maliyet_kdvli=net_kdvli,
            toplam_indirim_yuzdesi=indirim,
            miad=best["kalan_sure"],
            ozel_kampanya_notu=kampanya_notu,
            pazaryeri_teklifleri=open_offers
        )

        return [sart]

    async def add_to_cart(self, urun_id: str, barcode: str = "", miktar: int = 1, name: str = "") -> Dict[str, Any]:
        """
        Eczatrend ortak alım grup teklifine (offerPK) doğrudan katılma işlemi.
        """
        offer_pk = str(urun_id or "").strip()
        if not offer_pk:
            return {"success": False, "message": "Geçerli bir Eczatrend teklif kodu (offerPK) belirtilmedi."}

        if not self.is_logged_in:
            await self.login()

        client = await self._get_client()
        qty = max(1, int(miktar or 1))
        try:
            # 1. Geçerli barem koşulunu (conditionPK) kontrol et
            selected_mf = ""
            try:
                cond_resp = await client.get(
                    "https://eczatrend.com/eczanet/panel/purchase",
                    params={"action": "listOtherCondition", "offerPK": offer_pk, "amount": str(qty)},
                    timeout=10.0
                )
                if "sitelogin" in cond_resp.text:
                    await self.login(force_fresh=True)
                    cond_resp = await client.get(
                        "https://eczatrend.com/eczanet/panel/purchase",
                        params={"action": "listOtherCondition", "offerPK": offer_pk, "amount": str(qty)},
                        timeout=10.0
                    )
                if cond_resp.status_code == 200 and cond_resp.text.strip().startswith("{"):
                    cond_json = cond_resp.json()
                    rows = cond_json.get("rows") or []
                    for r in rows:
                        if "Geçerli" in str(r.get("acceptCondition") or "") and r.get("conditionPK"):
                            selected_mf = str(r["conditionPK"]).strip()
                            break
                    if not selected_mf and rows and rows[0].get("conditionPK"):
                        selected_mf = str(rows[0]["conditionPK"]).strip()
            except Exception:
                pass

            params = {
                "action": "purchase",
                "offerPK": offer_pk,
                "amount": str(qty),
                "showName": "true",
                "typePay": "0",
                "selectedMF": selected_mf or "null",
                "courier": "null"
            }
            resp = await client.get(
                "https://eczatrend.com/eczanet/panel/purchase",
                params=params,
                timeout=12.0
            )
            if "sitelogin" in resp.text:
                await self.login(force_fresh=True)
                resp = await client.get(
                    "https://eczatrend.com/eczanet/panel/purchase",
                    params=params,
                    timeout=12.0
                )

            res_json = resp.json() if (resp.text and resp.text.strip().startswith("{")) else {}
            ok = bool(res_json.get("success") in (True, 1, "1", "true"))
            msg_raw = str(res_json.get("message") or res_json.get("firstmes") or "").strip()
            if ok:
                # Önbellekteki kalan miktarı güncelle
                try:
                    for off in EczatrendAdapter._OFFERS_CACHE:
                        if str(off.get("offer_id")) == offer_pk:
                            off["kalan"] = max(0, int(off.get("kalan") or 0) - qty)
                            off["alinan"] = int(off.get("alinan") or 0) + qty
                    for raw_it in EczatrendAdapter._RAW_OFFERS_CACHE:
                        if str(raw_it.get("offerPK") or "").strip() == offer_pk:
                            cur_left = int(float(str(raw_it.get("leftTarget") or "0").strip()))
                            cur_purch = int(float(str(raw_it.get("totalPurchase") or "0").strip()))
                            raw_it["leftTarget"] = max(0, cur_left - qty)
                            raw_it["totalPurchase"] = cur_purch + qty
                except Exception:
                    pass
                return {
                    "success": True,
                    "message": f"Eczatrend ortak alım teklifine {qty} adet ile başarıyla katıldınız!",
                    "offer_id": offer_pk
                }
            else:
                return {
                    "success": False,
                    "message": msg_raw or "Eczatrend teklifine katılınamadı.",
                    "offer_id": offer_pk,
                    "katil_url": self.PANEL_URL
                }
        except Exception as e:
            logger.error("[Eczatrend] add_to_cart hatası: %s", e)
            return {
                "success": False,
                "message": f"Eczatrend teklifine katılma hatası: {e}",
                "offer_id": offer_pk,
                "katil_url": self.PANEL_URL
            }

    # =========================================================================
    # ECZATREND TAKAS (STOĞUMDAKİ ÜRÜN) & KAMPANYA AÇMA / YÖNETME MODÜLÜ
    # =========================================================================

    @staticmethod
    def _parse_json_field(val: Any, default: Any = None) -> Any:
        if val is None:
            return default
        if isinstance(val, (dict, list)):
            return val
        if isinstance(val, str):
            s = val.strip()
            if not s:
                return default
            if s.startswith(("{", "[")):
                try:
                    return json.loads(s)
                except Exception:
                    return default
        return default

    @staticmethod
    def _strip_html(text: str) -> str:
        if not text:
            return ""
        cleaned = re.sub(r"<br\s*/?>", " • ", str(text), flags=re.IGNORECASE)
        cleaned = re.sub(r"<[^>]+>", " ", cleaned)
        cleaned = html_lib.unescape(cleaned)
        return re.sub(r"\s+", " ", cleaned).strip()

    @staticmethod
    def _to_float(val: Any, default: float = 0.0) -> float:
        if val is None or val == "":
            return default
        try:
            s = str(val).strip().replace(",", ".")
            m = re.search(r"-?\d+(?:\.\d+)?", s)
            return float(m.group(0)) if m else default
        except Exception:
            return default

    @staticmethod
    def _to_etr_date(date_str: str, fallback_days: Optional[int] = None) -> str:
        """YYYY-MM-DD / DD.MM.YYYY / DD-MM-YYYY tarihini Eczatrend'in beklediği DD-MM-YYYY formatına çevirir."""
        s = str(date_str or "").strip()
        if s:
            s_norm = s.replace(".", "-").replace("/", "-")
            parts = [p.strip() for p in s_norm.split("-") if p.strip()]
            if len(parts) == 3:
                if len(parts[0]) == 4:
                    # YYYY-MM-DD -> DD-MM-YYYY
                    yyyy, mm, dd = parts[0], parts[1].zfill(2), parts[2].zfill(2)
                    return f"{dd}-{mm}-{yyyy}"
                elif len(parts[2]) == 4:
                    dd, mm, yyyy = parts[0].zfill(2), parts[1].zfill(2), parts[2]
                    return f"{dd}-{mm}-{yyyy}"
        if fallback_days is not None:
            dt = datetime.date.today() + datetime.timedelta(days=int(fallback_days))
            return dt.strftime("%d-%m-%Y")
        return ""

    @staticmethod
    def _etr_date_to_iso(date_str: str) -> str:
        """DD-MM-YYYY / DD.MM.YYYY tarihini HTML date input için YYYY-MM-DD formatına çevirir."""
        s = str(date_str or "").strip()
        if not s:
            return ""
        s_norm = s.split(" ")[0].replace(".", "-").replace("/", "-")
        parts = [p.strip() for p in s_norm.split("-") if p.strip()]
        if len(parts) == 3:
            if len(parts[0]) == 4:
                return f"{parts[0]}-{parts[1].zfill(2)}-{parts[2].zfill(2)}"
            if len(parts[2]) == 4 and int(parts[2]) >= 2000:
                return f"{parts[2]}-{parts[1].zfill(2)}-{parts[0].zfill(2)}"
        return ""

    async def _panel_request(
        self,
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: float = 15.0,
    ) -> Dict[str, Any]:
        """Oturum düşmesine ('sitelogin') karşı otomatik yeniden giriş destekli ortak JSON istek yardımcısı."""
        if not self.is_logged_in:
            await self.login()
        client = await self._get_client()

        async def _do_once() -> httpx.Response:
            if method.upper() == "GET":
                return await client.get(url, params=params, timeout=timeout)
            return await client.post(url, params=params, data=data, timeout=timeout)

        resp = await _do_once()
        body_txt = (resp.text or "").strip()
        if "sitelogin" in body_txt.lower() or "sitelogin" in str(resp.url).lower():
            await self.login(force_fresh=True)
            client = await self._get_client()
            resp = await _do_once()
            body_txt = (resp.text or "").strip()

        if body_txt.startswith(("{", "[")):
            try:
                parsed = resp.json()
                if isinstance(parsed, dict):
                    return parsed
                return {"success": True, "rows": parsed}
            except Exception as e:
                logger.warning("[Eczatrend] JSON ayrıştırma hatası (%s): %s", url, e)
        return {
            "success": False,
            "status_code": resp.status_code,
            "message": self._strip_html(body_txt)[:240] or f"Eczatrend yanıtı okunamadı (HTTP {resp.status_code}).",
        }

    async def get_campaign_bootstrap(self, force_refresh: bool = False) -> Dict[str, Any]:
        """
        Aktif eczane bilgilerini, üye olunan Eczatrend gruplarını, gruptaki eczane listesini,
        komisyon oranını ve yeni teklif açma ön-kontrol (controlBeforeNewOffer) durumunu getirir.
        """
        now = time.time()
        if (
            not force_refresh
            and EczatrendAdapter._BOOTSTRAP_CACHE
            and (now - EczatrendAdapter._BOOTSTRAP_CACHE_TIME) < self._BOOTSTRAP_CACHE_TTL
        ):
            return dict(EczatrendAdapter._BOOTSTRAP_CACHE)

        start_res, onsale_cfg, all_groups_res, spec_pharm_res = await asyncio.gather(
            self._panel_request("POST", self.MAIN_URL, data={"action": "startpage"}),
            self._panel_request("POST", self.MAIN_URL, data={"action": "onsalepage"}),
            self._panel_request("GET", self.ONSALE_URL, params={"action": "allOfferGroupListCombo"}),
            self._panel_request("GET", self.ONSALE_URL, params={"action": "specificPharmacyList"}),
            return_exceptions=True,
        )

        start_dict = start_res if isinstance(start_res, dict) else {}
        cfg_dict = onsale_cfg if isinstance(onsale_cfg, dict) else {}
        groups_combo_dict = all_groups_res if isinstance(all_groups_res, dict) else {}
        pharm_dict = spec_pharm_res if isinstance(spec_pharm_res, dict) else {}

        raw_groups = self._parse_json_field(start_dict.get("pharmacyGroups"), [])
        if not isinstance(raw_groups, list) or not raw_groups:
            raw_groups = self._parse_json_field(groups_combo_dict.get("message"), [])
        if not isinstance(raw_groups, list):
            raw_groups = []

        selected_group_key = str(start_dict.get("selectedGroupKey") or "").strip()
        groups: List[Dict[str, Any]] = []
        for g in raw_groups:
            if not isinstance(g, dict):
                continue
            gid = str(g.get("id") or g.get("value") or "").strip()
            gname = str(g.get("name") or g.get("text") or g.get("label") or "").strip()
            if not gid:
                continue
            is_sel = bool(g.get("selected") in (True, "true", "1", 1)) or (gid == selected_group_key)
            groups.append({"id": gid, "name": gname or "Eczatrend Grubu", "selected": is_sel})

        if not selected_group_key and groups:
            sel_item = next((x for x in groups if x.get("selected")), groups[0])
            selected_group_key = sel_item["id"]
            sel_item["selected"] = True

        # Yeni teklif açma yetki / aidat / grup kontrolü (controlBeforeNewOffer)
        can_create_offer = True
        preflight_warning = ""
        try:
            ctrl_res = await self._panel_request(
                "POST",
                self.ONSALE_URL,
                data={"action": "controlBeforeNewOffer", "groupFK": selected_group_key},
            )
            if isinstance(ctrl_res, dict):
                ctrl_ok = bool(ctrl_res.get("success") in (True, 1, "1", "true"))
                if ctrl_ok:
                    ctrl_groups = self._parse_json_field(ctrl_res.get("message"), [])
                    if isinstance(ctrl_groups, list) and ctrl_groups:
                        merged = []
                        for cg in ctrl_groups:
                            if not isinstance(cg, dict):
                                continue
                            gid = str(cg.get("id") or cg.get("value") or "").strip()
                            gname = str(cg.get("name") or cg.get("text") or "").strip()
                            if gid:
                                merged.append({
                                    "id": gid,
                                    "name": gname or "Eczatrend Grubu",
                                    "selected": bool(cg.get("selected") in (True, "true", "1", 1)) or (gid == selected_group_key),
                                })
                        if merged:
                            groups = merged
                else:
                    can_create_offer = False
                    preflight_warning = self._strip_html(str(ctrl_res.get("message") or ""))
        except Exception as e:
            logger.warning("[Eczatrend] controlBeforeNewOffer uyarısı: %s", e)

        raw_pharms = self._parse_json_field(pharm_dict.get("message"), [])
        pharmacies: List[Dict[str, str]] = []
        if isinstance(raw_pharms, list):
            for ph in raw_pharms:
                if not isinstance(ph, dict):
                    continue
                pid = str(ph.get("id") or ph.get("value") or "").strip()
                pname = str(ph.get("text") or ph.get("name") or ph.get("pharmacyName") or "").strip()
                if pid and pname:
                    pharmacies.append({"id": pid, "name": pname})

        selected_group_name = next(
            (g["name"] for g in groups if g["id"] == selected_group_key),
            (groups[0]["name"] if groups else "Eczatrend Grubu"),
        )

        result = {
            "success": True,
            "pharmacy_name": str(start_dict.get("USERNAME") or start_dict.get("pharmacyName") or "").strip(),
            "pharmacy_city": str(start_dict.get("pharmacyCity") or "").strip(),
            "pharmacy_gln": str(start_dict.get("pharmacyGln") or "").strip(),
            "groups": groups,
            "selected_group_key": selected_group_key,
            "selected_group_name": selected_group_name,
            "can_create_offer": can_create_offer,
            "preflight_warning": preflight_warning,
            "retransfer_ratio": self._to_float(cfg_dict.get("RETRANSFERRATIO"), 4.5),
            "offer_dealer_enabled": str(cfg_dict.get("OFFERDEALER") or "").lower() == "true",
            "pharmacies": pharmacies,
        }
        EczatrendAdapter._BOOTSTRAP_CACHE = result
        EczatrendAdapter._BOOTSTRAP_CACHE_TIME = now
        return dict(result)

    async def switch_active_group(self, group_id: str) -> Dict[str, Any]:
        """Aktif Eczatrend grubunu değiştirir ve güncel grup bilgilerini döner."""
        gid = str(group_id or "").strip()
        if not gid:
            return {"success": False, "message": "Geçerli bir grup ID belirtilmedi."}
        await self._panel_request(
            "POST",
            self.SELECTED_GROUP_URL,
            data={"action": "changeCombo", "valueCombo": gid},
        )
        EczatrendAdapter._BOOTSTRAP_CACHE = None
        EczatrendAdapter._BOOTSTRAP_CACHE_TIME = 0.0
        EczatrendAdapter._OFFERS_CACHE = []
        EczatrendAdapter._OFFERS_CACHE_TIME = 0.0
        boot = await self.get_campaign_bootstrap(force_refresh=True)
        boot["switched_group_id"] = gid
        return boot

    async def search_catalog_products(self, query: str) -> List[Dict[str, Any]]:
        """Eczatrend ürün kataloğunda (prerequest?action=listProduct) barkod veya isimle arama yapar."""
        clean_q = str(query or "").strip()
        if len(clean_q) < 3:
            return []
        res = await self._panel_request(
            "POST",
            self.PREREQUEST_URL,
            data={"action": "listProduct", "tet": clean_q},
        )
        raw_items = self._parse_json_field(res.get("message"), [])
        if not isinstance(raw_items, list):
            return []

        results: List[Dict[str, Any]] = []
        for it in raw_items:
            if not isinstance(it, dict):
                continue
            pk = str(it.get("productPK") or it.get("id") or it.get("value") or "").strip()
            raw_text = str(it.get("productName") or it.get("text") or it.get("label") or "").strip()
            if not pk or len(pk) != 32:
                continue

            bc = str(it.get("barCode") or it.get("barcode") or it.get("barkod") or "").strip()
            disp_name = raw_text
            if "Barkod:" in raw_text:
                parts = raw_text.split("Barkod:", 1)
                disp_name = parts[0].strip().rstrip(".- ")
                if not bc:
                    bc = re.sub(r"\D", "", parts[1])

            vat_str = str(it.get("productVat") or "10").strip()
            vat_int = int(self._to_float(vat_str, 10.0))
            if vat_int not in (1, 10, 20):
                vat_int = 10

            grp_list = self._parse_json_field(it.get("group"), [])
            grp_info = grp_list[0] if (isinstance(grp_list, list) and grp_list and isinstance(grp_list[0], dict)) else {}

            market_price = round(self._to_float(grp_info.get("productMarketPrice"), 0.0), 2)
            retail_price = round(self._to_float(grp_info.get("retailPrice"), 0.0), 2)
            updated_at = str(grp_info.get("productUpdatedAtByStore") or "").strip()
            is_updated_today = str(grp_info.get("isUpdatedToday") or "0").strip() == "1"
            purchase_type = str(grp_info.get("purchaseType") or "").strip()
            img_path = str(it.get("imagePath") or "").strip()
            if img_path and img_path.startswith("/"):
                img_path = f"https://eczatrend.com{img_path}"

            results.append({
                "id": pk,
                "product_pk": pk,
                "name": disp_name or raw_text,
                "full_label": f"{disp_name} ({bc})" if bc else disp_name,
                "barcode": bc,
                "vat": vat_int,
                "market_price": market_price,
                "retail_price": retail_price,
                "purchase_type": purchase_type,
                "updated_at": updated_at,
                "is_updated_today": is_updated_today,
                "image_url": img_path,
            })
        return results

    async def get_product_offer_insights(self, product_pk: str, group_key: str = "") -> Dict[str, Any]:
        """Seçili ürün için Eczatrend geçmiş tekliflerini (getBeforeList) ve aktif grup teklif uyarısını (checkOtherOffers) getirir."""
        pk = str(product_pk or "").strip()
        if len(pk) != 32:
            return {"success": False, "history": [], "has_active_group_offer": False, "active_offer_warning": ""}

        before_task = self._panel_request("GET", self.ONSALE_URL, params={"action": "getBeforeList", "productPK": pk})
        dup_task = self._panel_request(
            "GET",
            self.ONSALE_URL,
            params={"action": "checkOtherOffers", "productFK": pk, "groups": str(group_key or "")},
        )
        before_res, dup_res = await asyncio.gather(before_task, dup_task, return_exceptions=True)

        history: List[Dict[str, Any]] = []
        if isinstance(before_res, dict):
            rows = before_res.get("rows") if isinstance(before_res.get("rows"), list) else []
            for r in rows[:12]:
                if not isinstance(r, dict):
                    continue
                history.append({
                    "created_at": str(r.get("createdAt") or r.get("startDT") or "").strip(),
                    "pharmacy": str(r.get("pharmacy") or "").strip(),
                    "mf": str(r.get("offerMF") or "1+0").strip(),
                    "market_price": round(self._to_float(r.get("marketPrice"), 0.0), 2),
                    "net_price": round(self._to_float(r.get("netprice"), 0.0), 2),
                    "publish_type": str(r.get("offerPublishStatusDisplay") or "").strip(),
                    "status": str(r.get("status") or "").strip(),
                    "purchased": int(self._to_float(r.get("totalPurchase"), 0.0)),
                    "target": str(r.get("offertargetNumber") or r.get("offertarget") or "").strip(),
                })

        has_dup = False
        dup_msg = ""
        if isinstance(dup_res, dict) and dup_res.get("success") in (True, 1, "1", "true"):
            has_dup = True
            dup_msg = self._strip_html(str(dup_res.get("message") or "Bu ürüne ait grubunuzda açık teklif bulunmaktadır."))

        return {
            "success": True,
            "product_pk": pk,
            "history": history,
            "has_active_group_offer": has_dup,
            "active_offer_warning": dup_msg,
        }

    async def prepare_offer_product(
        self,
        barcode: str = "",
        name: str = "",
        search_term: str = "",
    ) -> Dict[str, Any]:
        """
        Aranan ürün için Eczatrend Takas / Kampanya açma formunu hazırlar:
        - Grup & eczane listesi (bootstrap)
        - Ürün eşleşmesi (productPK, KDV, portal DSF & PSF)
        - Eczatrend geçmiş grup teklifleri (getBeforeList) & açık teklif kontrolü (checkOtherOffers)
        """
        boot = await self.get_campaign_bootstrap(force_refresh=False)
        candidates: List[Dict[str, Any]] = []

        clean_manual = str(search_term or "").strip()
        clean_bc = re.sub(r"\D", "", str(barcode or ""))
        clean_name = str(name or "").strip()

        if clean_manual:
            candidates = await self.search_catalog_products(clean_manual)
        else:
            if len(clean_bc) >= 8:
                candidates = await self.search_catalog_products(clean_bc)
            if not candidates and len(clean_name) >= 3:
                # İlk 2 anlamlı kelime ile ara
                tokens = [t for t in re.split(r"\s+", clean_name) if len(t) >= 2]
                q_try = " ".join(tokens[:2]) if tokens else clean_name[:15]
                if len(q_try) >= 3:
                    candidates = await self.search_catalog_products(q_try)
                if not candidates and tokens and len(tokens[0]) >= 3:
                    candidates = await self.search_catalog_products(tokens[0])

        matched_item: Optional[Dict[str, Any]] = None
        if candidates:
            if clean_bc:
                matched_item = next((c for c in candidates if c.get("barcode") == clean_bc), None)
            if not matched_item and clean_name:
                target_norm = _norm_tr_name(clean_name)
                matched_item = next(
                    (c for c in candidates if _norm_tr_name(c.get("name", "")) == target_norm),
                    None,
                )
            if not matched_item and (clean_manual or clean_bc or len(candidates) == 1):
                matched_item = candidates[0]

        insights = {"history": [], "has_active_group_offer": False, "active_offer_warning": ""}
        if matched_item and matched_item.get("product_pk"):
            insights = await self.get_product_offer_insights(
                matched_item["product_pk"],
                boot.get("selected_group_key", ""),
            )

        return {
            **boot,
            "matched": bool(matched_item),
            "matched_product": matched_item,
            "product_pk": matched_item["product_pk"] if matched_item else "",
            "urun_adi": matched_item["name"] if matched_item else clean_name,
            "barcode": matched_item["barcode"] if matched_item else clean_bc,
            "portal_market_price": matched_item["market_price"] if matched_item else 0.0,
            "portal_retail_price": matched_item["retail_price"] if matched_item else 0.0,
            "portal_vat": matched_item["vat"] if matched_item else 10,
            "candidates": candidates[:30],
            "history": insights.get("history", []),
            "has_active_group_offer": insights.get("has_active_group_offer", False),
            "active_offer_warning": insights.get("active_offer_warning", ""),
        }

    @classmethod
    def _calc_condition_net(
        cls,
        market_price: float,
        target_qty: int,
        amount: int,
        extra: int,
        depo_iskonto: float,
        depo_iskonto_tl: float,
        retransfer_ratio: float = 0.0,
    ) -> Dict[str, Any]:
        """Eczatrend OfferEditForm (w5_mod_7827.js satır 487-495) ile birebir aynı net fiyat formülü."""
        amt = max(1, int(amount or 1))
        ext = max(0, int(extra or 0))
        isk_pct = max(0.0, min(99.9, float(depo_iskonto or 0.0)))
        isk_tl = max(0.0, float(depo_iskonto_tl or 0.0))
        tgt = max(1, int(target_qty or 1))

        if market_price <= 0:
            return {"netPriceCondi": 0, "netPriceCondiEczatrend": "", "net_float": 0.0}

        base_unit = (market_price * amt) / float(amt + ext)
        disc = 0.0
        if isk_pct > 0:
            disc += (base_unit * isk_pct) / 100.0
        if isk_tl > 0 and tgt > 0:
            disc += isk_tl / float(tgt)
        net_val = max(0.0, base_unit - disc)
        net_str = f"{net_val:.6g}"

        etr_comm_str = ""
        if 0 < retransfer_ratio < 100:
            with_comm = (net_val / (100.0 - retransfer_ratio)) * 100.0
            etr_comm_str = f"{with_comm:.6g}"

        return {
            "netPriceCondi": net_str,
            "netPriceCondiEczatrend": etr_comm_str,
            "net_float": round(net_val, 4),
        }

    async def create_or_update_offer(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Eczatrend üzerinde Raf Stoğundan Takas ('2') veya Depo Kampanyası ('0' Genel / '1' Özel)
        oluşturur, taslak kaydeder veya mevcut bir teklifi günceller (action=saveAllForm).
        """
        boot = await self.get_campaign_bootstrap(force_refresh=False)
        retransfer_ratio = float(boot.get("retransfer_ratio") or 4.5)

        offer_pk = str(payload.get("offer_pk") or payload.get("offerPK") or "").strip()
        is_edit = len(offer_pk) == 32

        product_pk = str(payload.get("product_pk") or payload.get("productPK") or "").strip()
        if len(product_pk) != 32:
            return {"success": False, "message": "Lütfen Eczatrend kataloğundan geçerli bir ürün seçin (productPK eksik)."}

        urun_adi = str(payload.get("urun_adi") or payload.get("productName") or "Ürün").strip()

        # Teklif Türü: "2" = Stoğumdaki Ürün (Takas), "0" = Depodan Genel, "1" = Deponun Bana Özel Teklifi
        publish_status = str(payload.get("offer_publish_status") if payload.get("offer_publish_status") is not None else payload.get("offerPublishStatusFK", "2")).strip()
        if publish_status not in ("0", "1", "2"):
            publish_status = "2"

        special_type = str(payload.get("offer_special_type") or payload.get("offerSpecialTypeFK") or "0").strip()
        if special_type not in ("0", "1", "2", "4"):
            special_type = "0"
        if special_type == "4":
            publish_status = "2"

        base_market_price = self._to_float(payload.get("market_price") or payload.get("marketPrice"), 0.0)
        ciro_primi = str(payload.get("ciro_primi") or payload.get("offerCiroPrimArtisOran") or "").strip()
        if ciro_primi not in ("1", "2", "3", "4"):
            ciro_primi = ""

        # Eğer kullanıcı ham depo fiyatı gönderdiyse ve ciro_primi seçiliyse (ve apply_ciro_to_base True ise) uygula
        eff_market_price = base_market_price
        if ciro_primi and payload.get("ciro_already_applied") is not True and eff_market_price > 0:
            eff_market_price = round(eff_market_price * (1.0 + float(ciro_primi) / 100.0), 2)

        product_price = self._to_float(payload.get("product_price") or payload.get("productPrice"), 0.0)
        if product_price <= 0 and eff_market_price > 0:
            # Etiket fiyatı girilmemişse güvenli varsayılan olarak depo fiyatının ~%25 üstünü ata (Eczatrend >0 zorunlu tutar)
            product_price = round(eff_market_price * 1.25, 2)

        if eff_market_price <= 0:
            return {"success": False, "message": "Geçerli bir Depo Fiyatı (KDV Dahil) girilmelidir."}
        if product_price <= 0:
            return {"success": False, "message": "Geçerli bir Etiket Fiyatı (PSF) girilmelidir."}

        vat_val = str(int(self._to_float(payload.get("vat") or payload.get("offerTaxPercent"), 10.0)))
        if vat_val not in ("1", "10", "20"):
            vat_val = "10"

        target_qty = int(self._to_float(payload.get("offertarget") or payload.get("adet"), 0))
        min_qty = int(self._to_float(payload.get("min") or payload.get("min_alim"), 1))
        max_qty = int(self._to_float(payload.get("max") or payload.get("max_alim"), target_qty))
        if target_qty < 1:
            return {"success": False, "message": "Hedeflenen (satılacak) kutu adedi en az 1 olmalıdır."}
        if max_qty < 1:
            max_qty = target_qty
        if min_qty < 1 or min_qty > max_qty or max_qty > target_qty:
            return {
                "success": False,
                "message": f"Adet sınırları hatalı: Min ({min_qty}) ≤ Maks ({max_qty}) ≤ Hedef ({target_qty}) olmalıdır.",
            }

        purchase_mult_raw = str(payload.get("purchase_multiplier") or payload.get("purchaseMultiplier") or "").strip()
        purchase_mult = ""
        if purchase_mult_raw:
            pm_int = int(self._to_float(purchase_mult_raw, 0))
            if pm_int > 0:
                if pm_int > max_qty or pm_int > target_qty:
                    return {"success": False, "message": f"Alım katı ({pm_int}), maksimum ({max_qty}) ve hedef ({target_qty}) adetten büyük olamaz."}
                purchase_mult = str(pm_int)

        start_dt = self._to_etr_date(payload.get("start_dt") or payload.get("startDT") or "", fallback_days=0)
        end_dt = self._to_etr_date(payload.get("end_dt") or payload.get("endDT") or "", fallback_days=30)
        expire_dt = self._to_etr_date(payload.get("expire_dt") or payload.get("expireDT") or payload.get("miad") or "", fallback_days=None)

        if publish_status == "2" or special_type == "4":
            if not expire_dt:
                return {"success": False, "message": "Raf Stoğumdan Takas (Stoğumdaki Ürün) tekliflerinde Miad / Son Kullanım Tarihi zorunludur!"}

        # Stoğumdaki Ürün ("2") tekliflerinde Eczatrend kuralı gereği hedef geçilemez ("1") ve kendi alımım olmaz
        accept_record = str(payload.get("accept_record") or payload.get("acceptRecord") or ("1" if publish_status == "2" else "2")).strip()
        if publish_status == "2" or accept_record not in ("1", "2"):
            accept_record = "1" if publish_status == "2" else "2"

        self_purchase = 0
        if publish_status != "2" and not is_edit:
            self_purchase = max(0, int(self._to_float(payload.get("self_purchase") or payload.get("selfPurchase"), 0)))
            if self_purchase > 0:
                if self_purchase < min_qty or self_purchase > max_qty or self_purchase > target_qty:
                    return {
                        "success": False,
                        "message": f"Kendi alımınız ({self_purchase}), minimum ({min_qty}) ile maksimum ({max_qty}) arasında olmalıdır.",
                    }
                if purchase_mult and (self_purchase % int(purchase_mult) != 0):
                    return {
                        "success": False,
                        "message": f"Kendi alımınız ({self_purchase}), alım katının ({purchase_mult}) tam katı olmalıdır.",
                    }

        # Yayınlama Tipi: "0" = Grubuma Özel, "1" = Eczaneye Özel (Birebir Takas), "2" = Tüm Gruplarımda
        spec_type = str(payload.get("specific_pharmacy_type") or payload.get("specificPharmacyTypeFK") or "0").strip()
        if spec_type not in ("0", "1", "2"):
            spec_type = "0"
        spec_pharm_fk = str(payload.get("specific_pharmacy_fk") or payload.get("specificPharmacyFK") or "").strip()
        if spec_type == "1" and len(spec_pharm_fk) != 32:
            return {"success": False, "message": "Eczaneye Özel Takas seçildiğinde listeden hedef eczaneyi seçmelisiniz."}
        if spec_type != "1":
            spec_pharm_fk = ""

        boot_groups = boot.get("groups") or []
        all_group_ids = [g["id"] for g in boot_groups if g.get("id")]
        req_group = str(payload.get("group_id") or payload.get("allGroupOffer") or boot.get("selected_group_key") or "").strip()
        if spec_type == "2":
            all_group_offer_val = "0"
        elif spec_type == "1":
            all_group_offer_val = ""
        else:
            all_group_offer_val = req_group or (all_group_ids[0] if all_group_ids else "0")

        # Barem / Şart Tablosunu (offerConditionEdit) oluştur (1..8 satır, 0. satır her zaman 1+0 zorunludur!)
        raw_conditions = payload.get("conditions")
        normalized_conds: List[Dict[str, Any]] = []
        if isinstance(raw_conditions, list) and raw_conditions:
            for rc in raw_conditions:
                if not isinstance(rc, dict):
                    continue
                c_amt = max(1, int(self._to_float(rc.get("amount"), 1)))
                c_ext = max(0, int(self._to_float(rc.get("extra"), 0)))
                c_isk = max(0.0, min(99.9, self._to_float(rc.get("depoiskonto"), 0.0)))
                c_tl = max(0.0, self._to_float(rc.get("depoiskontoTL"), 0.0))
                c_pk = str(rc.get("conditionPK") or "").strip()
                normalized_conds.append({
                    "amount": c_amt,
                    "extra": c_ext,
                    "depoiskonto": round(c_isk, 4),
                    "depoiskontoTL": round(c_tl, 2),
                    "conditionPK": c_pk,
                })
        else:
            # Basit moddan (sart1, sart2, iskonto) şart üretimi
            s1 = max(1, int(self._to_float(payload.get("alimsarti1") or payload.get("amount"), 1)))
            s2 = max(0, int(self._to_float(payload.get("alimsarti2") or payload.get("extra"), 0)))
            isk = max(0.0, min(99.9, self._to_float(payload.get("iskonto") or payload.get("depoiskonto"), 0.0)))
            isk_tl = max(0.0, self._to_float(payload.get("iskonto_tl") or payload.get("depoiskontoTL"), 0.0))
            if s1 == 1 and s2 == 0:
                normalized_conds.append({
                    "amount": 1,
                    "extra": 0,
                    "depoiskonto": round(isk, 4),
                    "depoiskontoTL": round(isk_tl, 2),
                    "conditionPK": "",
                })
            else:
                # Eczatrend kuralı: 0. satırda 1+0 bulunmak zorundadır!
                row0_isk = max(0.0, min(99.9, self._to_float(payload.get("base_row_iskonto"), 0.0)))
                normalized_conds.append({
                    "amount": 1,
                    "extra": 0,
                    "depoiskonto": round(row0_isk, 4),
                    "depoiskontoTL": 0.0,
                    "conditionPK": "",
                })
                normalized_conds.append({
                    "amount": s1,
                    "extra": s2,
                    "depoiskonto": round(isk, 4),
                    "depoiskontoTL": round(isk_tl, 2),
                    "conditionPK": "",
                })

        # 1+0 satırının varlığını ve ilk sırada olmasını garanti altına al + mükerrer A+B kontrolü yap
        has_base_1_0 = any(c["amount"] == 1 and c["extra"] == 0 for c in normalized_conds)
        if not has_base_1_0:
            normalized_conds.insert(0, {
                "amount": 1,
                "extra": 0,
                "depoiskonto": 0.0,
                "depoiskontoTL": 0.0,
                "conditionPK": "",
            })

        normalized_conds.sort(key=lambda c: (0 if (c["amount"] == 1 and c["extra"] == 0) else 1, c["amount"], c["extra"]))
        dedup_conds: List[Dict[str, Any]] = []
        seen_pairs = set()
        max_cond_total = 1
        for c in normalized_conds:
            pair_key = f"{c['amount']}+{c['extra']}"
            if pair_key in seen_pairs:
                continue
            seen_pairs.add(pair_key)
            max_cond_total = max(max_cond_total, c["amount"] + c["extra"])
            calc = self._calc_condition_net(
                market_price=eff_market_price,
                target_qty=target_qty,
                amount=c["amount"],
                extra=c["extra"],
                depo_iskonto=c["depoiskonto"],
                depo_iskonto_tl=c["depoiskontoTL"],
                retransfer_ratio=retransfer_ratio,
            )
            dedup_conds.append({
                "amount": c["amount"],
                "extra": c["extra"],
                "depoiskonto": c["depoiskonto"],
                "depoiskontoTL": c["depoiskontoTL"],
                "netPriceCondi": calc["netPriceCondi"],
                "kdvPriceCondi": None,
                "netPriceCondiEczatrend": calc["netPriceCondiEczatrend"],
                "conditionPK": c.get("conditionPK", ""),
            })
            if len(dedup_conds) >= 8:
                break

        # Eczatrend kuralı (w5_mod_7827.js satır 723): Depo kampanyasında (0 veya 1) toplam barem (A+B) > hedef olamaz (ancak stoktan '2' olabilir)
        if publish_status in ("0", "1") and max_cond_total > target_qty:
            return {
                "success": False,
                "message": f"Depo kampanyasında en yüksek barem toplamı ({max_cond_total} kutu), hedeflenen alım adedinden ({target_qty} kutu) büyük olamaz. Hedef adedi artırın veya 'Raf Stoğumdan Takas' modunu seçin.",
            }

        info_note = str(payload.get("information") or payload.get("aciklama") or "").strip()[:100]
        auto_reopen = "1" if (
            bool(payload.get("auto_reopen"))
            and accept_record == "1"
            and spec_type != "1"
            and special_type != "4"
        ) else "0"

        is_draft = bool(payload.get("as_draft") is True or str(payload.get("save_mode") or "").lower() == "draft")
        if is_edit:
            # Mevcut teklif güncellenirken: eğer Taslak yayına alınıyorsa "true", aksi halde ""
            save_type_val = "true" if bool(payload.get("publish_draft")) else ""
        else:
            save_type_val = "false" if is_draft else "true"

        form_data: Dict[str, str] = {
            "action": "saveAllForm",
            "productPK": product_pk,
            "marketPrice": f"{eff_market_price:.2f}".rstrip("0").rstrip(".") if "." in f"{eff_market_price:.2f}" else str(eff_market_price),
            "productPrice": f"{product_price:.2f}".rstrip("0").rstrip(".") if "." in f"{product_price:.2f}" else str(product_price),
            "offerTaxPercent": vat_val,
            "offerCiroPrimArtisOran": ciro_primi if ciro_primi else ("0" if is_edit else ""),
            "startDT": start_dt,
            "endDT": end_dt,
            "offertarget": str(target_qty),
            "min": str(min_qty),
            "max": str(max_qty),
            "information": info_note,
            "offerSecretDetails": "",
            "offerPublishStatusFK": publish_status,
            "acceptRecord": accept_record,
            "specificPharmacyTypeFK": spec_type,
            "specificPharmacyFK": spec_pharm_fk,
            "offerSpecialTypeFK": special_type,
            "allGroupOffer": all_group_offer_val,
            "storeFK": str(payload.get("store_fk") or "").strip(),
            "isColdTransportationRequired": "",
            "prerequestPK": "",
            "offerStoreFK": "",
            "autoOfferCreationFK": auto_reopen,
            "offerConditionEdit": json.dumps(dedup_conds, ensure_ascii=False),
            "saveType": save_type_val,
        }
        if not ciro_primi and not is_edit:
            form_data.pop("offerCiroPrimArtisOran", None)
        if expire_dt:
            form_data["expireDT"] = expire_dt
        if purchase_mult:
            form_data["purchaseMultiplier"] = purchase_mult
        if self_purchase > 0:
            form_data["selfPurchase"] = str(self_purchase)
        if publish_status == "2" and bool(payload.get("add_near_expiry_list")):
            # Eczatrend ters alan ismi: Rt=true olduğunda notNearTermOffer="false" gönderilir
            form_data["notNearTermOffer"] = "false"
        if is_edit:
            form_data["offerPK"] = offer_pk
        if all_group_ids:
            form_data["multiOfferGroup"] = ",".join(all_group_ids)

        res = await self._panel_request("POST", self.ONSALE_URL, data=form_data, timeout=20.0)
        ok = bool(res.get("success") in (True, 1, "1", "true"))
        msg_clean = self._strip_html(str(res.get("message") or ""))

        if not ok:
            return {
                "success": False,
                "message": msg_clean or "Eczatrend teklifi kaydedilemedi. Grup yetkinizi veya alanları kontrol edin.",
                "raw": res,
            }

        saved_offer_pk = str(res.get("message4") or res.get("offerPK") or offer_pk or "").strip()
        self_purchase_msg = ""
        if self_purchase > 0 and saved_offer_pk and not is_edit and not is_draft:
            try:
                sp_res = await self._panel_request(
                    "GET",
                    self.PURCHASE_URL,
                    params={
                        "action": "purchase",
                        "offerPK": saved_offer_pk,
                        "amount": str(self_purchase),
                        "showName": " ",
                        "courier": " ",
                    },
                )
                if sp_res.get("success") in (True, 1, "1", "true"):
                    self_purchase_msg = f" Kendi alımınız ({self_purchase} kutu) otomatik işlendi."
                else:
                    sp_err = self._strip_html(str(sp_res.get("message") or ""))
                    self_purchase_msg = f" (Uyarı: Kendi alımınız işlenemedi: {sp_err})"
            except Exception as e:
                logger.warning("[Eczatrend] Kendi alımı işlenemedi: %s", e)

        # Önbelleği sıfırla ki yeni teklif hemen görünsün
        EczatrendAdapter._OFFERS_CACHE = []
        EczatrendAdapter._OFFERS_CACHE_TIME = 0.0

        best_net = min(float(c["netPriceCondi"]) for c in dedup_conds) if dedup_conds else eff_market_price
        mf_summary = " / ".join(
            f"{c['amount']}+{c['extra']}" + (f" (-%{c['depoiskonto']:g})" if c["depoiskonto"] > 0 else "")
            for c in dedup_conds
            if not (len(dedup_conds) > 1 and c["amount"] == 1 and c["extra"] == 0 and c["depoiskonto"] == 0)
        ) or "1+0"

        action_word = "güncellendi" if is_edit else ("taslak olarak kaydedildi" if is_draft else "yayına alındı")
        return {
            "success": True,
            "offer_pk": saved_offer_pk,
            "is_draft": is_draft,
            "is_edit": is_edit,
            "mf": mf_summary,
            "net_price": round(best_net, 2),
            "message": f"{urun_adi} teklifiniz Eczatrend'de başarıyla {action_word}!{self_purchase_msg}",
        }

    async def list_my_offers(
        self,
        status: str = "0",
        publish_type: str = "9",
        page: int = 1,
        rows: int = 40,
        query: str = "",
    ) -> Dict[str, Any]:
        """Eczanenin kendi açtığı Eczatrend Takas & Kampanya tekliflerini (Tekliflerim) listeler."""
        params = {
            "action": "listOffer",
            "offerPublishTypeSelect": str(publish_type or "9"),
            "form_control_offerStatus": str(status or "0"),
            "form_control_offerType": "1",
            "page": str(max(1, int(page or 1))),
            "rows": str(max(5, min(100, int(rows or 40)))),
            "totalGridRow": "0",
            "productName": str(query or "").strip(),
            "pharmacy": "",
            "allOfStartDT": "",
            "allOfEndDT": "",
            "barcode": "",
            "productFK": "",
            "allOfTimeList": "false",
            "isExcelExport": "false",
            "onlyReTransfer": "",
        }
        res = await self._panel_request("GET", self.ONSALE_URL, params=params, timeout=18.0)
        raw_rows = res.get("rows") if isinstance(res.get("rows"), list) else []
        total = int(self._to_float(res.get("total"), len(raw_rows)))

        items: List[Dict[str, Any]] = []
        for r in raw_rows:
            if not isinstance(r, dict):
                continue
            offer_pk = str(r.get("offerPK") or "").strip()
            if not offer_pk:
                continue
            target_str = str(r.get("offertargetNumber") or r.get("offertarget") or "0").strip()
            target_num = int(self._to_float(target_str.split("/")[0] if "/" in target_str else target_str, 0))
            purchased_num = int(self._to_float(r.get("totalPurchase"), 0))
            left_num = max(0, target_num - purchased_num)
            pub_fk = str(r.get("offerPublishStatusFK") if r.get("offerPublishStatusFK") is not None else "").strip()
            pub_disp = str(r.get("offerPublishStatusDisplay") or "").strip()
            if not pub_disp:
                pub_disp = {
                    "2": "Stoğumdaki Ürün (Takas)",
                    "0": "Depodan Genel",
                    "1": "Deponun Bana Özel",
                }.get(pub_fk, "Teklif")

            items.append({
                "offer_pk": offer_pk,
                "product_pk": str(r.get("productPK") or "").strip(),
                "product_name": str(r.get("productName") or "").strip(),
                "barcode": str(r.get("barCode") or r.get("productBarcode") or "").strip(),
                "mf": str(r.get("offerMF") or "1+0").strip(),
                "market_price": round(self._to_float(r.get("marketPrice"), 0.0), 2),
                "product_price": round(self._to_float(r.get("productPrice"), 0.0), 2),
                "net_price": round(self._to_float(r.get("netprice"), 0.0), 2),
                "vat_excluded_net": round(self._to_float(r.get("vatExcludedNetPrice"), 0.0), 2),
                "vat": int(self._to_float(r.get("productVat") or r.get("offerTaxPercent"), 10.0)),
                "target": target_num,
                "purchased": purchased_num,
                "left": left_num,
                "min_max": str(r.get("minmaks") or f"{r.get('min', 1)}/{r.get('max', target_num)}").strip(),
                "status": str(r.get("status") or "").strip(),
                "publish_status_fk": pub_fk,
                "publish_status_label": pub_disp,
                "group_name": str(r.get("groupName") or r.get("allGroupOfferDisplay") or "").strip(),
                "start_dt": str(r.get("startDT") or "").strip(),
                "end_dt": str(r.get("endDT") or "").strip(),
                "expire_dt": str(r.get("expireDT") or "").strip(),
                "information": str(r.get("information") or "").strip(),
                "accept_record": str(r.get("acceptRecord") or "1").strip(),
                "ciro_primi": str(r.get("offerCiroPrimArtisOran") or "").strip(),
            })

        return {
            "success": True,
            "total": total,
            "count": len(items),
            "offers": items,
        }

    async def get_offer_detail(self, offer_pk: str) -> Dict[str, Any]:
        """Teklifin barem detaylarını (editOffer) ve alım yapan eczaneler listesini (pharmacyList) döner."""
        pk = str(offer_pk or "").strip()
        if len(pk) != 32:
            return {"success": False, "message": "Geçersiz teklif kodu (offerPK)."}

        edit_task = self._panel_request(
            "POST",
            self.ONSALE_URL,
            data={"action": "editOffer", "offerPK": pk, "createNewOrEdit": "true"},
        )
        buyers_task = self._panel_request(
            "GET",
            self.ONSALE_URL,
            params={"action": "pharmacyList", "offerPK": pk},
        )
        edit_res, buyers_res = await asyncio.gather(edit_task, buyers_task, return_exceptions=True)

        conditions: List[Dict[str, Any]] = []
        groups_info: List[Dict[str, Any]] = []
        if isinstance(edit_res, dict) and edit_res.get("success") in (True, 1, "1", "true"):
            raw_conds = self._parse_json_field(edit_res.get("message"), [])
            if isinstance(raw_conds, dict):
                raw_conds = raw_conds.get("rows") or []
            if isinstance(raw_conds, list):
                for c in raw_conds:
                    if not isinstance(c, dict):
                        continue
                    conditions.append({
                        "amount": max(1, int(self._to_float(c.get("amount"), 1))),
                        "extra": max(0, int(self._to_float(c.get("extra"), 0))),
                        "depoiskonto": round(self._to_float(c.get("depoiskonto"), 0.0), 4),
                        "depoiskontoTL": round(self._to_float(c.get("depoiskontoTL"), 0.0), 2),
                        "conditionPK": str(c.get("conditionPK") or "").strip(),
                    })
            conditions.sort(key=lambda x: (0 if (x["amount"] == 1 and x["extra"] == 0) else 1, x["amount"], x["extra"]))
            raw_grps = self._parse_json_field(edit_res.get("message4"), [])
            if isinstance(raw_grps, list):
                groups_info = [g for g in raw_grps if isinstance(g, dict)]

        buyers: List[Dict[str, Any]] = []
        if isinstance(buyers_res, dict):
            b_rows = buyers_res.get("rows") if isinstance(buyers_res.get("rows"), list) else []
            for b in b_rows:
                if not isinstance(b, dict):
                    continue
                buyers.append({
                    "purchase_pk": str(b.get("purchasePK") or b.get("id") or "").strip(),
                    "pharmacy": str(b.get("pharmacy") or b.get("pharmacyName") or "").strip(),
                    "city": str(b.get("city") or b.get("pharmacyCity") or "").strip(),
                    "amount": int(self._to_float(b.get("amount") or b.get("purchaseAmount"), 0)),
                    "mf": str(b.get("offerMF") or b.get("conditionDisplay") or "").strip(),
                    "net_price": round(self._to_float(b.get("netprice") or b.get("netPrice"), 0.0), 2),
                    "total_price": round(self._to_float(b.get("totalPrice") or b.get("totalAmount"), 0.0), 2),
                    "status": str(b.get("status") or b.get("purchaseStatus") or "").strip(),
                    "created_at": str(b.get("createdAt") or b.get("purchaseDT") or "").strip(),
                })

        return {
            "success": True,
            "offer_pk": pk,
            "conditions": conditions,
            "groups": groups_info,
            "buyers": buyers,
            "buyers_count": len(buyers),
        }

    async def change_offer_status(
        self,
        offer_pk: str,
        operation: str,
        approve_and_send: bool = False,
    ) -> Dict[str, Any]:
        """
        Açılmış Eczatrend teklifinin durumunu yönetir:
        - 'passive' : Pasife Çek (action=passive)
        - 'active'  : Taslak/Pasif Teklifi Yayınla (action=btnactive)
        - 'close'   : Teklifi Kapat / Onayla ve Dağıt (checkBeforeApproveAndClose + approveAndClose)
        """
        pk = str(offer_pk or "").strip()
        op = str(operation or "").strip().lower()
        if len(pk) != 32:
            return {"success": False, "message": "Geçersiz teklif kodu (offerPK)."}

        if op == "passive":
            res = await self._panel_request("POST", self.ONSALE_URL, data={"action": "passive", "offerFK": pk})
            ok = bool(res.get("success") in (True, 1, "1", "true"))
            EczatrendAdapter._OFFERS_CACHE = []
            EczatrendAdapter._OFFERS_CACHE_TIME = 0.0
            return {
                "success": ok,
                "message": self._strip_html(str(res.get("message") or ("Teklif pasife çekildi." if ok else "Teklif pasife çekilemedi."))),
            }

        if op == "active":
            res = await self._panel_request(
                "POST",
                self.ONSALE_URL,
                data={"action": "btnactive", "refresh": "false", "offerFK": pk},
            )
            ok = bool(res.get("success") in (True, 1, "1", "true"))
            EczatrendAdapter._OFFERS_CACHE = []
            EczatrendAdapter._OFFERS_CACHE_TIME = 0.0
            return {
                "success": ok,
                "message": self._strip_html(str(res.get("message") or ("Teklif yayına alındı." if ok else "Teklif yayına alınamadı."))),
            }

        if op in ("close", "approve"):
            pre1, pre2 = await asyncio.gather(
                self._panel_request("GET", self.ONSALE_URL, params={"action": "checkBeforeApproveAndClose", "offerFK": pk}),
                self._panel_request("GET", self.MAIN_URL, params={"action": "findSizePendingBuyRequestByOfferPK", "offerFK": pk}),
                return_exceptions=True,
            )
            if isinstance(pre2, dict):
                pending_cnt = int(self._to_float(pre2.get("message"), 0))
                if pending_cnt > 0:
                    return {
                        "success": False,
                        "message": f"Bu teklifte bekleyen {pending_cnt} adet alım talebi var. Önce Eczatrend üzerinden bekleyen talebi yanıtlayın.",
                    }
            if isinstance(pre1, dict) and pre1.get("success") in (False, 0, "0", "false"):
                warn = self._strip_html(str(pre1.get("message") or ""))
                if warn:
                    return {"success": False, "message": warn}

            res = await self._panel_request(
                "POST",
                self.ONSALE_URL,
                data={
                    "action": "approveAndClose",
                    "offerFK": pk,
                    "approveAndSend": "true" if approve_and_send else "false",
                },
            )
            ok = bool(res.get("success") in (True, 1, "1", "true"))
            EczatrendAdapter._OFFERS_CACHE = []
            EczatrendAdapter._OFFERS_CACHE_TIME = 0.0
            return {
                "success": ok,
                "message": self._strip_html(str(res.get("message") or ("Teklif onaylandı / kapatıldı." if ok else "Teklif kapatılamadı."))),
            }

        return {"success": False, "message": f"Bilinmeyen işlem türü: {op}"}

    async def close(self):
        """HTTP bağlantısını kapatır."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
