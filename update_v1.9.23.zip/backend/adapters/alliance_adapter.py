import asyncio
import base64
import json
import re
import time
from typing import List, Optional, Dict, Any
from pathlib import Path
import httpx
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu, MFKademeDetay
from backend.core.cost_calculator import CostCalculator
from backend.core.session_store import SessionStore, SESSIONS_DIR

class AllianceAdapter(BaseDepoAdapter):
    BASE_URL = "https://esiparisv2.alliance-healthcare.com.tr/"
    MAIN_URL = "https://esiparisv2.alliance-healthcare.com.tr/Home/MainPage"

    def __init__(self, pharmacy_code: str = "", username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ALLIANCE, "Alliance Healthcare")
        self.pharmacy_code = pharmacy_code
        self.username = username
        self.password = password
        self.headless = headless
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
        self._lock = asyncio.Lock()
        self._cart_busy: int = 0
        self._search_busy: int = 0
        self._fast_cart_cache: Dict[str, Dict[str, Any]] = {}
        self._hot_search_cache: Dict[str, Any] = {}
        self._item_cache_file: Path = SESSIONS_DIR / "alliance_item_cache.json"
        self._item_cache: Dict[str, Dict[str, Any]] = {}
        self._http_client: Optional[httpx.AsyncClient] = None
        self._http_has_cookies: bool = False
        self._last_relogin_ts: float = 0.0
        self._last_added_items: List[Dict[str, Any]] = []
        self._last_added_time: float = 0.0
        self._load_item_cache()
        self._load_http_cookies_from_disk()

    def _load_item_cache(self) -> None:
        try:
            if self._item_cache_file.exists():
                raw = json.loads(self._item_cache_file.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    self._item_cache = raw
        except Exception:
            self._item_cache = {}

    def _save_item_cache(self) -> None:
        try:
            if len(self._item_cache) > 8000:
                sorted_keys = sorted(
                    self._item_cache.keys(),
                    key=lambda k: float((self._item_cache.get(k) or {}).get("ts") or 0.0),
                    reverse=True,
                )[:6000]
                self._item_cache = {k: self._item_cache[k] for k in sorted_keys}
            self._item_cache_file.write_text(json.dumps(self._item_cache, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _record_item_meta(self, item_id: str, item_string: str, barcode: str, name: str, tag_price: str = "") -> bool:
        iid = str(item_id or "").strip()
        if not iid:
            return False
        now = time.time()
        prev = self._item_cache.get(f"ID:{iid}") or {}
        eff_str = str(item_string or prev.get("itemString") or "").strip()
        eff_bc = str(barcode or prev.get("barcode") or "").strip()
        eff_nm = str(name or prev.get("name") or "").strip()
        eff_tp = str(tag_price or prev.get("tagPrice") or "").strip()
        entry = {
            "id": iid,
            "itemString": eff_str if item_string else prev.get("itemString", ""),
            "itemStringTs": now if item_string else float(prev.get("itemStringTs") or 0.0),
            "barcode": eff_bc,
            "name": eff_nm,
            "tagPrice": eff_tp,
            "ts": now,
        }
        changed = (prev.get("id") != iid) or (bool(item_string) and prev.get("itemString") != item_string) or (eff_bc and f"BC:{eff_bc}" not in self._item_cache)
        self._item_cache[f"ID:{iid}"] = entry
        if eff_bc:
            self._item_cache[f"BC:{eff_bc}"] = entry
            stripped = eff_bc.lstrip("0")
            if stripped:
                self._item_cache[f"BC:{stripped}"] = entry
        return changed

    def _get_cached_row_meta(self, query_or_bc: str, urun_id: str = "") -> Optional[Dict[str, Any]]:
        q = str(query_or_bc or "").strip()
        uid = str(urun_id or "").strip()
        cand = None
        if uid:
            cand = self._item_cache.get(f"ID:{uid}")
        if not cand and q:
            cand = self._item_cache.get(f"BC:{q}") or self._item_cache.get(f"BC:{q.lstrip('0')}")
        return dict(cand) if isinstance(cand, dict) and cand.get("id") else None

    def _ensure_http_client(self) -> httpx.AsyncClient:
        if self._http_client is None or self._http_client.is_closed:
            self._http_client = httpx.AsyncClient(
                base_url="https://esiparisv2.alliance-healthcare.com.tr",
                http2=False,
                follow_redirects=False,
                limits=httpx.Limits(max_keepalive_connections=12, max_connections=24, keepalive_expiry=60.0),
                timeout=httpx.Timeout(9.0, connect=4.5),
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                    "X-Requested-With": "XMLHttpRequest",
                    "Origin": "https://esiparisv2.alliance-healthcare.com.tr",
                    "Referer": "https://esiparisv2.alliance-healthcare.com.tr/Home/MainPage",
                    "Accept": "*/*",
                },
            )
        return self._http_client

    def _load_http_cookies_from_disk(self) -> bool:
        try:
            state = SessionStore.load_state("alliance")
            cookies = (state or {}).get("cookies") or []
            if not cookies:
                return False
            client = self._ensure_http_client()
            client.cookies.clear()
            count = 0
            for c in cookies:
                nm = c.get("name")
                val = c.get("value")
                dom = str(c.get("domain") or "esiparisv2.alliance-healthcare.com.tr").lstrip(".")
                if nm and val is not None and "alliance-healthcare" in dom:
                    client.cookies.set(nm, val, domain=dom, path=c.get("path") or "/")
                    count += 1
            self._http_has_cookies = count > 0
            return self._http_has_cookies
        except Exception:
            self._http_has_cookies = False
            return False

    async def _sync_http_cookies_from_context(self) -> None:
        if not self._context:
            return
        try:
            cookies = await self._context.cookies()
            client = self._ensure_http_client()
            client.cookies.clear()
            count = 0
            for c in cookies:
                nm = c.get("name")
                val = c.get("value")
                dom = str(c.get("domain") or "esiparisv2.alliance-healthcare.com.tr").lstrip(".")
                if nm and val is not None and "alliance-healthcare" in dom:
                    client.cookies.set(nm, val, domain=dom, path=c.get("path") or "/")
                    count += 1
            self._http_has_cookies = count > 0
        except Exception:
            pass

    def _merge_last_added_items(self, new_items: List[Dict[str, Any]]) -> None:
        if not new_items:
            return
        now = time.time()
        existing = list(self._last_added_items or []) if (now - float(self._last_added_time or 0.0)) < 21600 else []
        merged: List[Dict[str, Any]] = []
        index_by_key: Dict[str, int] = {}

        def _keys_for(entry: Dict[str, Any]) -> List[str]:
            ks = []
            for field in ("urun_id", "kod", "barcode", "barkod", "id"):
                val = str(entry.get(field) or "").strip()
                if val:
                    ks.append(f"ID:{val.lstrip('0') or val}")
            nm = str(entry.get("ad") or entry.get("name") or entry.get("urun_adi") or "").strip().upper()
            if nm:
                ks.append(f"NM:{nm}")
            return ks

        for item in existing + list(new_items):
            if not isinstance(item, dict):
                continue
            keys = _keys_for(item)
            hit_idx = next((index_by_key[k] for k in keys if k in index_by_key), None)
            if hit_idx is not None:
                prev = merged[hit_idx]
                updated = dict(prev)
                for k, v in item.items():
                    if v not in (None, ""):
                        updated[k] = v
                merged[hit_idx] = updated
                for k in _keys_for(updated):
                    index_by_key[k] = hit_idx
            else:
                new_idx = len(merged)
                merged.append(dict(item))
                for k in keys:
                    index_by_key[k] = new_idx

        self._last_added_items = merged
        self._last_added_time = now

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-setuid-sandbox"]
            )
            
            session_file = SessionStore.get_session_file("alliance")
            if session_file.exists():
                try:
                    self._context = await self._browser.new_context(storage_state=str(session_file))
                except Exception:
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()
                
            self._page = await self._context.new_page()

    async def is_session_valid(self) -> bool:
        if not self._page:
            await self._init_browser()
            
        try:
            cur_url = (self._page.url or "").lower()
            if "alliance-healthcare.com.tr" in cur_url and "login" not in cur_url and "sales/cart" not in cur_url:
                is_ready = await self._page.evaluate("() => typeof AjaxPostWithoutOverlay === 'function' && !document.querySelector('#pharmacyCode')")
                if is_ready:
                    return True

            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            await self._page.wait_for_selector("#searchArea, #searchedItems", timeout=4000)
            return True
        except Exception:
            return False

    async def _login_unlocked(self) -> bool:
        """Alliance eSiparis v2'ye giriş yapar ve oturum kaydeder."""
        if not self.pharmacy_code or not self.username or not self.password:
            raise ValueError("Alliance için Eczane Kodu, Kullanıcı Adı ve Şifre zorunludur.")

        await self._init_browser()
        
        if await self.is_session_valid():
            print("[Alliance] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            await self._sync_http_cookies_from_context()
            self._last_relogin_ts = time.time()
            return True

        print("[Alliance] Giriş sayfası açılıyor...")
        await self._page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=15000)

        await self._page.wait_for_selector("#pharmacyCode", timeout=8000)
        await self._page.fill("#pharmacyCode", str(self.pharmacy_code))
        await self._page.click("#Customer_username")
        await self._page.fill("#Customer_username", str(self.username))
        await self._page.fill("#Customer_password", str(self.password))
        
        login_result = {}

        async def handle_response(response):
            if "/Home/Login" in response.url and response.request.method == "POST":
                try:
                    data = await response.json()
                    login_result.update(data)
                except Exception:
                    pass

        self._page.on("response", handle_response)
        try:
            print("[Alliance] Giriş yapılıyor...")
            await self._page.click(".Customer_login__button")
            
            for _ in range(30):
                await asyncio.sleep(0.15)
                if login_result:
                    break

            if login_result.get("Result") is False:
                error_msg = login_result.get("Message", "Giriş başarısız oldu!")
                raise RuntimeError(f"Alliance Giriş Hatası: {error_msg}")

            await self._page.wait_for_url("**/Home/MainPage**", timeout=12000)
            await self._page.wait_for_function("() => typeof AjaxPostWithoutOverlay === 'function'", timeout=10000)
            
            session_file = SessionStore.get_session_file("alliance")
            await self._context.storage_state(path=str(session_file))
            await self._sync_http_cookies_from_context()
            self._last_relogin_ts = time.time()
            print("[Alliance] Oturum başarıyla açıldı ve kaydedildi.")
            self.is_logged_in = True
            return True
        finally:
            try:
                self._page.remove_listener("response", handle_response)
            except Exception:
                pass

    async def login(self) -> bool:
        async with self._lock:
            return await self._login_unlocked()

    async def _ensure_ready_page(self):
        """Arama fonksiyonunun hazır olduğundan emin olur."""
        if not self._page:
            await self._init_browser()
            
        is_ready = False
        try:
            cur_u = (self._page.url or "").lower()
            if "sales/cart" not in cur_u and "order" not in cur_u:
                is_ready = await self._page.evaluate("() => typeof AjaxPostWithoutOverlay === 'function' && !document.querySelector('#pharmacyCode')")
        except Exception:
            is_ready = False

        if not is_ready:
            print("[Alliance] Sayfa hazırlanıyor...")
            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            cur_url = (self._page.url or "").lower()
            if "login" in cur_url or await self._page.evaluate("() => !!document.querySelector('#pharmacyCode')"):
                self.is_logged_in = False
                await self._login_unlocked()
            else:
                await self._page.wait_for_function("() => typeof AjaxPostWithoutOverlay === 'function'", timeout=10000)
                await self._sync_http_cookies_from_context()

    @staticmethod
    def _extract_search_rows_py(html_str: str) -> List[Dict[str, Any]]:
        if not html_str or not isinstance(html_str, str):
            return []
        soup = BeautifulSoup(html_str, "html.parser")
        rows = []
        for tr in soup.select('tr[id^="branchdetailstring_"]')[:10]:
            rid = str(tr.get("data-itemid") or str(tr.get("id") or "").replace("branchdetailstring_", "")).strip()
            if not rid:
                continue
            item_string = str(tr.get("data-itemstring") or "").strip()
            span_el = tr.select_one("td.text_column span[title], span[title]")
            barcode = str(span_el.get("title") or "").strip() if span_el else ""
            if span_el:
                name = span_el.get_text(" ", strip=True)
            else:
                td_txt = tr.select_one("td.text_column")
                name = td_txt.get_text(" ", strip=True) if td_txt else ""
            price_el = tr.select_one('[id^="price_"], td.numeric_column')
            tag_price = ""
            if price_el:
                tag_price = str(price_el.get("data-tagprice") or price_el.get_text(" ", strip=True) or "").strip()
            rows.append({
                "id": rid,
                "itemString": item_string,
                "barcode": barcode,
                "name": name,
                "tagPrice": tag_price,
            })
        return rows

    @staticmethod
    def _is_alliance_resp_expired(resp: httpx.Response) -> bool:
        if resp.status_code in (301, 302, 303, 307, 308, 401, 403):
            return True
        loc = str(resp.headers.get("location") or "").lower()
        if "login" in loc:
            return True
        txt = resp.text or ""
        if "pharmacyCode" in txt or "Customer_username" in txt or "/Home/Login" in txt:
            return True
        return False

    async def _search_via_httpx(self, clean_q: str) -> Any:
        """
        Tarayıcı kilidini (self._lock) ve Chrome başlatma gecikmesini tamamen atlayan,
        keep-alive HTTP havuzu ve disk ItemID/ItemString önbellekli ultra hızlı sorgu motoru.
        """
        if not self._http_has_cookies and not self._load_http_cookies_from_disk():
            return {"_need_login": True}

        client = self._ensure_http_client()
        now = time.time()
        is_bc = clean_q.isdigit() and len(clean_q) >= 8

        rows: List[Dict[str, Any]] = []
        used_cached_row = False

        # 1. Barkod daha önce sorgulanmışsa /Sales/SearchItems adımını TAMAMEN ATLA!
        if is_bc:
            c_row = self._get_cached_row_meta(clean_q)
            if c_row and c_row.get("id") and c_row.get("itemString") and (now - float(c_row.get("itemStringTs") or 0.0)) < 28800:
                rows = [c_row]
                used_cached_row = True

        async def _fetch_search_rows(q_val: str) -> Any:
            r_s = await client.post("/Sales/SearchItems", data={
                "SearchText": q_val,
                "OnlyStock": "false",
                "SearchContains": "false",
                "SelectedClass": "3",
                "Sorter": "0",
                "ManufacturerID": "0",
                "WithEQ": "false",
                "RequestedPage": "1",
                "BeforeSearchRequest": "",
            })
            if self._is_alliance_resp_expired(r_s):
                return {"_session_expired": True}
            parsed_r = self._extract_search_rows_py(r_s.text)
            if not parsed_r and len(q_val) == 13 and q_val.isdigit():
                r_s2 = await client.post("/Sales/SearchItems", data={
                    "SearchText": "0" + q_val,
                    "OnlyStock": "false",
                    "SearchContains": "false",
                    "SelectedClass": "3",
                    "Sorter": "0",
                    "ManufacturerID": "0",
                    "WithEQ": "false",
                    "RequestedPage": "1",
                    "BeforeSearchRequest": "",
                })
                if self._is_alliance_resp_expired(r_s2):
                    return {"_session_expired": True}
                parsed_r = self._extract_search_rows_py(r_s2.text)
            return parsed_r

        if not rows:
            sr_res = await _fetch_search_rows(clean_q)
            if isinstance(sr_res, dict) and sr_res.get("_session_expired"):
                return {"_session_expired": True}
            rows = sr_res or []

        if not rows:
            return []

        async def _fetch_branch_and_v3(active_rows: List[Dict[str, Any]]) -> Any:
            row_map = {str(r["id"]): r for r in active_rows}
            r_b = await client.post("/Sales/ItemsBranchDetail", data={
                "ItemIDs": ",".join(str(r["id"]) for r in active_rows),
                "NonDrugInventoryItems": "",
            })
            if self._is_alliance_resp_expired(r_b):
                return {"_session_expired": True}
            try:
                b_data = r_b.json()
            except Exception:
                return {"_session_expired": True}
            if not isinstance(b_data, list) or not b_data:
                return []

            sem = asyncio.Semaphore(6)
            async def _one_v3(b_obj: Dict[str, Any]) -> Dict[str, Any]:
                sid = str(b_obj.get("ItemID") or "")
                r_meta = row_map.get(sid) or {"id": sid, "itemString": "", "barcode": "", "name": "", "tagPrice": ""}
                b_str = str(b_obj.get("BranchItemDetailString") or "")
                detail_html = ""
                if b_str and not b_str.startswith("eyJ"):
                    async with sem:
                        r_v3 = await client.post("/Sales/ItemDetailv3", data={
                            "ItemString": r_meta.get("itemString") or "",
                            "ItemDetailString": b_str,
                            "ViewType": "ItemDetail",
                            "ItemID": sid,
                            "LoadSimple": "false",
                        })
                    if self._is_alliance_resp_expired(r_v3):
                        return {"_session_expired": True}
                    detail_html = r_v3.text or ""
                return {"branch": b_obj, "rowMeta": r_meta, "detailHtml": detail_html}

            parts = await asyncio.gather(*[_one_v3(b) for b in b_data])
            if any(isinstance(p, dict) and p.get("_session_expired") for p in parts):
                return {"_session_expired": True}
            return list(parts)

        enriched = await _fetch_branch_and_v3(rows)
        if isinstance(enriched, dict) and enriched.get("_session_expired"):
            return {"_session_expired": True}

        # Önbellekteki ItemString süresi dolmuş veya kampanya HTML'i boş dönmüşse otomatik SearchItems ile tazele
        if used_cached_row and (
            not enriched
            or any(
                not str((e.get("branch") or {}).get("BranchItemDetailString") or "").startswith("eyJ")
                and "accordion" not in str(e.get("detailHtml") or "")
                for e in enriched
            )
        ):
            sr_fresh = await _fetch_search_rows(clean_q)
            if isinstance(sr_fresh, dict) and sr_fresh.get("_session_expired"):
                return {"_session_expired": True}
            if sr_fresh:
                enriched = await _fetch_branch_and_v3(sr_fresh)
                if isinstance(enriched, dict) and enriched.get("_session_expired"):
                    return {"_session_expired": True}

        return enriched

    def _build_results_from_branch_entries(self, branch_data: List[Dict[str, Any]], clean_q: str) -> List[DepoUrunSarti]:
        sonuclar: List[DepoUrunSarti] = []
        cache_dirty = False
        for entry in branch_data:
            if not isinstance(entry, dict):
                continue
            b_item = entry.get("branch") if "branch" in entry else entry
            row_meta = entry.get("rowMeta") or {}
            detail_html = entry.get("detailHtml") or ""
            if not isinstance(b_item, dict):
                continue
            item_id = str(b_item.get("ItemID", "") or row_meta.get("id", "")).strip()
            b64_detail = str(b_item.get("BranchItemDetailString", "") or "").strip()
            if not b64_detail and not detail_html:
                continue
            try:
                extracted = self._extract_detail_bundle(b_item, row_meta, detail_html, clean_q)
                detail = extracted.get("detail")
                if not detail:
                    continue
                eq_string = str(b_item.get("EQString", "") or "").strip()
                sarti = self._parse_branch_item(detail, eq_string, clean_q)
                sonuclar.append(sarti)

                bc_val = str(detail.get("Barcode") or row_meta.get("barcode") or sarti.barkod or "").strip()
                if self._record_item_meta(
                    item_id=item_id,
                    item_string=str(row_meta.get("itemString") or ""),
                    barcode=bc_val or (clean_q if clean_q.isdigit() else ""),
                    name=str(detail.get("Name") or sarti.urun_adi or ""),
                    tag_price=str(row_meta.get("tagPrice") or ""),
                ):
                    cache_dirty = True

                basket_item_str = str(extracted.get("basket_item_str") or "").strip()
                offer_rows = extracted.get("offer_rows") or []
                if basket_item_str and offer_rows:
                    default_off = next((r for r in offer_rows if r.get("checked")), offer_rows[0])
                    cache_entry = {
                        "from_v3": True,
                        "item_id": item_id,
                        "b64_detail": basket_item_str,
                        "offer_b64": default_off["offer_b64"],
                        "offer_rows": offer_rows,
                        "name": detail.get("Name") or sarti.urun_adi,
                        "vade": int(default_off.get("vade") or sarti.vade_gun or 30),
                        "net_fiyat": float(default_off.get("net_fiyat") or sarti.net_birim_maliyet or 0.0),
                        "has_stock": bool(detail.get("HasStock", True)),
                    }
                    if item_id:
                        self._fast_cart_cache[item_id] = cache_entry
                    if bc_val:
                        self._fast_cart_cache[bc_val] = cache_entry
                        self._fast_cart_cache[bc_val.lstrip("0")] = cache_entry
                    if clean_q.isdigit():
                        self._fast_cart_cache[clean_q] = cache_entry
            except Exception as e:
                print(f"[Alliance] Ürün ayrıştırma hatası ({item_id}): {e}")

        if cache_dirty:
            self._save_item_cache()
        return sonuclar

    async def search_product(self, query: str, include_equivalents: bool = True, is_background: bool = False) -> List[DepoUrunSarti]:
        """
        Barkod veya ürün adına göre depoda arama yapar.
        1. Öncelik: Kilitsiz (lock-free) keep-alive HTTPX + kalıcı ItemID/ItemString önbelleği (Paralel sorgu ve 0ms tarayıcı bekleme!).
        2. Yedek: Oturum yenileme veya ağ istisnalarında otomatik Playwright yedek hattı.
        """
        if is_background and getattr(self, "_cart_busy", 0) > 0:
            return []

        clean_q = str(query or "").strip()
        if not clean_q:
            return []

        # 20 saniyelik sıcak sonuç önbelleği (Arka arkaya aynı barkod sorgularında 0ms yanıt!)
        now_ts = time.time()
        hot = self._hot_search_cache.get(clean_q)
        if hot and (now_ts - hot[0]) < 20.0:
            return [r.model_copy(deep=True) for r in hot[1]]

        if not is_background:
            self._search_busy += 1
        try:
            if not is_background:
                print(f"[Alliance] '{clean_q}' sorgulanıyor...")

            # A) HIZLI KİLİTSİZ HTTPX YOLU (Playwright kilidine girmeden paralel çalışır!)
            try:
                fast_data = await self._search_via_httpx(clean_q)
                if isinstance(fast_data, dict) and (fast_data.get("_need_login") or fast_data.get("_session_expired")):
                    req_ts = time.time()
                    async with self._lock:
                        if self._last_relogin_ts < (req_ts - 3.0) or not self._http_has_cookies:
                            if fast_data.get("_session_expired"):
                                print("[Alliance] HTTP oturumu yenileniyor...")
                                self.is_logged_in = False
                                SessionStore.clear("alliance")
                                if self._page:
                                    try:
                                        await self._page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=12000)
                                    except Exception:
                                        pass
                            await self._login_unlocked()
                    fast_data = await self._search_via_httpx(clean_q)

                if isinstance(fast_data, list):
                    sonuclar_fast = self._build_results_from_branch_entries(fast_data, clean_q)
                    if sonuclar_fast:
                        self._hot_search_cache[clean_q] = (time.time(), sonuclar_fast)
                    return sonuclar_fast
            except Exception as http_err:
                if not is_background:
                    print(f"[Alliance] Hızlı HTTP sorgu uyarısı ({clean_q}), tarayıcı yedeğine geçiliyor: {http_err}")

            # B) YEDEK PLAYWRIGHT TARAYICI YOLU
            async with self._lock:
                if is_background and getattr(self, "_cart_busy", 0) > 0:
                    return []
                if not self.is_logged_in:
                    await self._login_unlocked()

                await self._ensure_ready_page()

                js_alliance_search = """async (q) => {
                    function postNoOverlay(url, data, timeoutMs = 6500) {
                        return new Promise((resolve) => {
                            let done = false;
                            const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, timeoutMs);
                            try {
                                if (typeof $ !== 'undefined' && $.ajax) {
                                    $.ajax({
                                        url: url,
                                        type: 'POST',
                                        data: data,
                                        timeout: timeoutMs,
                                        success: function(res) {
                                            if (!done) {
                                                done = true;
                                                clearTimeout(timer);
                                                if (typeof res === 'string' && (res.includes('pharmacyCode') || res.includes('Customer_username') || res.includes('/Home/Login'))) {
                                                    resolve({ _session_expired: true });
                                                    return;
                                                }
                                                resolve(res);
                                            }
                                        },
                                        error: function(xhr) {
                                            if (!done) {
                                                done = true;
                                                clearTimeout(timer);
                                                if (xhr && (xhr.status === 401 || xhr.status === 403 || xhr.status === 302)) {
                                                    resolve({ _session_expired: true });
                                                    return;
                                                }
                                                resolve(null);
                                            }
                                        }
                                    });
                                    return;
                                }
                                AjaxPostWithoutOverlay(url, data, function(res) {
                                    if (!done) { done = true; clearTimeout(timer); resolve(res); }
                                });
                            } catch (e) {
                                if (!done) { done = true; clearTimeout(timer); resolve(null); }
                            }
                        });
                    }

                    let searchHtml = await postNoOverlay('/Sales/SearchItems', {
                        SearchText: q,
                        OnlyStock: false,
                        SearchContains: false,
                        SelectedClass: '3',
                        Sorter: 0,
                        ManufacturerID: '0',
                        WithEQ: false,
                        RequestedPage: 1,
                        BeforeSearchRequest: ''
                    });
                    if (searchHtml && typeof searchHtml === 'object' && searchHtml._session_expired) {
                        return { _session_expired: true };
                    }

                    function extractRows(html) {
                        if (!html || typeof html !== 'string') return [];
                        const temp = document.createElement('div');
                        temp.innerHTML = html;
                        const trs = Array.from(temp.querySelectorAll('tr[id^="branchdetailstring_"]')).slice(0, 10);
                        return trs.map(tr => {
                            const id = (tr.getAttribute('data-itemid') || (tr.id || '').replace('branchdetailstring_', '')).trim();
                            const itemString = tr.getAttribute('data-itemstring') || '';
                            const spanEl = tr.querySelector('td.text_column span[title], span[title]');
                            const barcode = spanEl ? (spanEl.getAttribute('title') || '').trim() : '';
                            const name = spanEl ? (spanEl.textContent || '').trim() : ((tr.querySelector('td.text_column')?.textContent || '').trim());
                            const priceEl = tr.querySelector('[id^="price_"], td.numeric_column');
                            const tagPrice = priceEl ? (priceEl.getAttribute('data-tagprice') || priceEl.textContent || '').trim() : '';
                            return { id, itemString, barcode, name, tagPrice };
                        }).filter(r => !!r.id);
                    }

                    let rows = extractRows(searchHtml);

                    if (rows.length === 0 && /^\\d{13}$/.test(q)) {
                        searchHtml = await postNoOverlay('/Sales/SearchItems', {
                            SearchText: '0' + q,
                            OnlyStock: false,
                            SearchContains: false,
                            SelectedClass: '3',
                            Sorter: 0,
                            ManufacturerID: '0',
                            WithEQ: false,
                            RequestedPage: 1,
                            BeforeSearchRequest: ''
                        });
                        if (searchHtml && typeof searchHtml === 'object' && searchHtml._session_expired) {
                            return { _session_expired: true };
                        }
                        rows = extractRows(searchHtml);
                    }

                    if (rows.length === 0) return [];

                    const rowMap = {};
                    rows.forEach(r => { rowMap[String(r.id)] = r; });

                    const bData = await postNoOverlay('/Sales/ItemsBranchDetail', {
                        ItemIDs: rows.map(r => r.id).join(','),
                        NonDrugInventoryItems: ''
                    });
                    if (bData && typeof bData === 'object' && bData._session_expired) {
                        return { _session_expired: true };
                    }
                    if (!Array.isArray(bData) || bData.length === 0) return [];

                    const enriched = [];
                    const chunkSize = 5;
                    for (let i = 0; i < bData.length; i += chunkSize) {
                        const chunk = bData.slice(i, i + chunkSize);
                        const part = await Promise.all(chunk.map(async (b) => {
                            const sid = String(b.ItemID || '');
                            const rMeta = rowMap[sid] || { id: sid, itemString: '', barcode: '', name: '', tagPrice: '' };
                            let detailHtml = '';
                            const bStr = b.BranchItemDetailString || '';
                            if (bStr && !bStr.startsWith('eyJ')) {
                                const v3 = await postNoOverlay('/Sales/ItemDetailv3', {
                                    ItemString: rMeta.itemString || '',
                                    ItemDetailString: bStr,
                                    ViewType: 'ItemDetail',
                                    ItemID: sid,
                                    LoadSimple: false
                                }, 6500);
                                if (v3 && typeof v3 === 'object' && v3._session_expired) {
                                    return { _session_expired: true };
                                }
                                if (typeof v3 === 'string') {
                                    detailHtml = v3;
                                }
                            }
                            return { branch: b, rowMeta: rMeta, detailHtml: detailHtml };
                        }));
                        if (part.some(x => x && x._session_expired)) {
                            return { _session_expired: true };
                        }
                        enriched.push(...part);
                    }
                    return enriched;
                }"""

                branch_data = await self._page.evaluate(js_alliance_search, clean_q)
                if isinstance(branch_data, dict) and branch_data.get("_session_expired"):
                    print("[Alliance] Oturum düşmüş (başka tarayıcıdan giriş veya süre sonu), otomatik yenileniyor...")
                    self.is_logged_in = False
                    SessionStore.clear("alliance")
                    await self._page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=12000)
                    await self._login_unlocked()
                    await self._ensure_ready_page()
                    branch_data = await self._page.evaluate(js_alliance_search, clean_q)

                sonuclar = self._build_results_from_branch_entries(branch_data if isinstance(branch_data, list) else [], clean_q)
                if sonuclar:
                    self._hot_search_cache[clean_q] = (time.time(), sonuclar)
                return sonuclar
        finally:
            if not is_background:
                self._search_busy = max(0, self._search_busy - 1)

    @staticmethod
    def _parse_tr_float(val: Any) -> float:
        if val is None:
            return 0.0
        if isinstance(val, (int, float)):
            return float(val)
        s = re.sub(r"[^0-9.,-]", "", str(val or "")).strip()
        if not s or s in ("-", ".", ","):
            return 0.0
        if "," in s and "." in s:
            if s.rfind(",") > s.rfind("."):
                s = s.replace(".", "").replace(",", ".")
            else:
                s = s.replace(",", "")
        elif "," in s:
            s = s.replace(",", ".")
        try:
            return float(s)
        except Exception:
            return 0.0

    @staticmethod
    def _try_decode_b64_json(raw_b64: str) -> Optional[Dict[str, Any]]:
        s = str(raw_b64 or "").strip()
        if not s:
            return None
        try:
            pad = s + ("=" * ((4 - len(s) % 4) % 4))
            raw_bytes = base64.b64decode(pad)
            for enc in ("utf-8", "latin-1"):
                try:
                    txt = raw_bytes.decode(enc).strip()
                    if txt.startswith("{") and txt.endswith("}"):
                        obj = json.loads(txt)
                        if isinstance(obj, dict):
                            return obj
                except Exception:
                    continue
        except Exception:
            return None
        return None

    def _extract_detail_bundle(
        self,
        b_item: Dict[str, Any],
        row_meta: Dict[str, Any],
        detail_html: str,
        fallback_query: str,
    ) -> Dict[str, Any]:
        item_id = str(b_item.get("ItemID") or row_meta.get("id") or "").strip()
        b64_detail = str(b_item.get("BranchItemDetailString") or "").strip()

        # 1. Eski düz Base64 JSON formatı ise doğrudan çöz
        legacy_detail = self._try_decode_b64_json(b64_detail)
        if legacy_detail and not detail_html:
            offer_rows = []
            for idx, off in enumerate(legacy_detail.get("Offers") or []):
                try:
                    off_b64 = base64.b64encode(json.dumps(off, ensure_ascii=False).encode("utf-8")).decode("utf-8")
                    offer_rows.append({
                        "offer_b64": off_b64,
                        "min_qty": int(off.get("MinQuantity") or 1),
                        "eq_rate": float(off.get("EQRate") or 0.0),
                        "vade": int(off.get("DaysDue") or 30),
                        "net_fiyat": float(off.get("NetPrice") or 0.0),
                        "checked": idx == 0,
                    })
                except Exception:
                    pass
            return {
                "detail": legacy_detail,
                "basket_item_str": b64_detail,
                "offer_rows": offer_rows,
            }

        # 2. Yeni Alliance v2.3+ ItemDetailv3 HTML ayrıştırması
        basket_item_str = ""
        offer_rows: List[Dict[str, Any]] = []
        parsed_offers: List[Dict[str, Any]] = []
        html_fields: Dict[str, Any] = {}

        if detail_html:
            soup = BeautifulSoup(detail_html, "html.parser")
            acc = soup.select_one("#accordion") or soup.select_one("#popup_accordion") or soup.select_one("[data-item]")
            if acc:
                basket_item_str = str(acc.get("data-item") or "").strip()
                if acc.get("data-name"):
                    html_fields["name"] = str(acc.get("data-name") or "").strip()

            title_el = soup.select_one("#itemTitle")
            if title_el:
                title_txt = title_el.get_text(" ", strip=True)
                if " - " in title_txt:
                    bc_part, nm_part = title_txt.split(" - ", 1)
                    if bc_part.strip().isdigit():
                        html_fields["barcode"] = bc_part.strip()
                    if nm_part.strip():
                        html_fields["name"] = nm_part.strip()
                elif title_txt:
                    html_fields.setdefault("name", title_txt)

            for row_div in soup.select("#divIlacBilgileri .row"):
                cols = row_div.find_all("div", recursive=False)
                if len(cols) == 1:
                    cols = cols[0].find_all("div", recursive=False)
                if len(cols) >= 2:
                    lbl = cols[0].get_text(" ", strip=True).lower()
                    val = cols[1].get_text(" ", strip=True)
                    if "perakende" in lbl:
                        html_fields["psf"] = self._parse_tr_float(val)
                    elif "vergi dahil depocu" in lbl:
                        html_fields["dsf_taxed"] = self._parse_tr_float(val)
                    elif "vergi hari" in lbl and "depocu" in lbl:
                        html_fields["dsf_notax"] = self._parse_tr_float(val)
                    elif "kdv oran" in lbl:
                        html_fields["kdv"] = self._parse_tr_float(val)
                    elif "eczacı kar" in lbl or "eczaci kar" in lbl:
                        html_fields["profit_rate"] = self._parse_tr_float(val)
                    elif "saklama" in lbl:
                        v_low = val.lower()
                        html_fields["is_cold"] = ("soğuk" in v_low or "soguk" in v_low or "2-8" in v_low or "buzdolab" in v_low)

            for tr in soup.select("#tblKampanyalar tbody tr, #popup_tblKampanyalar tbody tr"):
                radio = tr.select_one("input[type='radio'][data-offer], input[data-offer]")
                if not radio:
                    continue
                off_str = str(radio.get("data-offer") or "").strip()
                if not off_str:
                    continue
                tds = tr.find_all("td")
                min_qty = int(self._parse_tr_float(tr.get("data-minquantity") or radio.get("data-minquantity") or (tds[2].get_text() if len(tds) > 2 else 1)) or 1)
                eq_rate = self._parse_tr_float(tr.get("data-eqrate") or 0.0)
                vade = int(self._parse_tr_float(tds[1].get_text() if len(tds) > 1 else 30) or 30)
                mf_free = self._parse_tr_float(tds[3].get_text() if len(tds) > 3 else 0.0)
                kurum_pct = self._parse_tr_float(tds[4].get_text() if len(tds) > 4 else 0.0)
                ticari_pct = self._parse_tr_float(tds[5].get_text() if len(tds) > 5 else 0.0)
                net_price = self._parse_tr_float(tds[-1].get_text() if tds else 0.0)
                is_checked = radio.has_attr("checked") or ("checked" in str(radio))

                decoded_off = self._try_decode_b64_json(off_str)
                if decoded_off:
                    min_qty = int(decoded_off.get("MinQuantity") or min_qty or 1)
                    eq_rate = float(decoded_off.get("EQRate") if decoded_off.get("EQRate") is not None else eq_rate)
                    vade = int(decoded_off.get("DaysDue") or vade or 30)
                    net_price = float(decoded_off.get("NetPrice") or net_price or 0.0)
                    parsed_offers.append(decoded_off)
                else:
                    reward_nm = f"{min_qty}+{int(mf_free)}" if mf_free > 0 else ""
                    parsed_offers.append({
                        "Name": f"{vade} GÜN",
                        "RewardName": reward_nm,
                        "MinQuantity": min_qty,
                        "ExtraQuantityForMinQuantity": mf_free,
                        "EQRate": eq_rate,
                        "DaysDue": vade,
                        "NetPrice": net_price,
                        "Rate": ticari_pct,
                        "ExtraDiscountRate": 0.0,
                        "CashDiscountRate": 0.0,
                    })

                if kurum_pct > 0 and "kurum_isk" not in html_fields:
                    html_fields["kurum_isk"] = kurum_pct
                if ticari_pct > 0:
                    html_fields["ticari_isk"] = max(float(html_fields.get("ticari_isk") or 0.0), ticari_pct)

                offer_rows.append({
                    "offer_b64": off_str,
                    "min_qty": max(1, min_qty),
                    "eq_rate": eq_rate,
                    "vade": vade,
                    "net_fiyat": net_price,
                    "checked": bool(is_checked),
                })

        # #accordion[data-item] Base64 JSON ise tam modeli al, değilse (gelecekte o da şifrelenirse) HTML'den sentetik model kur
        detail = self._try_decode_b64_json(basket_item_str)
        stock_html = str(b_item.get("StockHtml") or "")
        stock_order = int(b_item.get("StockOrder") or 0)
        has_stock_branch = ("has-stock" in stock_html and "hasnot-stock" not in stock_html) or (stock_order == 1)

        if not detail:
            dsf_notax = float(html_fields.get("dsf_notax") or self._parse_tr_float(b_item.get("PriceHtml") or row_meta.get("tagPrice")) or 0.0)
            dsf_taxed = float(html_fields.get("dsf_taxed") or 0.0)
            detail = {
                "ID": item_id,
                "Name": html_fields.get("name") or row_meta.get("name") or "Ürün",
                "Barcode": html_fields.get("barcode") or row_meta.get("barcode") or (fallback_query if fallback_query.isdigit() else ""),
                "HasStock": has_stock_branch,
                "QA": 1 if has_stock_branch else 0,
                "MustShipCold": bool(html_fields.get("is_cold", False)),
                "PriceTag": {
                    "ListPrice": float(html_fields.get("psf") or 0.0),
                    "SalesPrice": dsf_taxed,
                    "SalesPriceOutOfTaxes": dsf_notax,
                    "TaxRate": float(html_fields.get("kdv") or 10.0),
                    "CustomerProfitRate": float(html_fields.get("profit_rate") or 0.0),
                },
                "KurumOran": float(html_fields.get("kurum_isk") or self._parse_tr_float(b_item.get("KurumOranHtml")) or 0.0),
                "TicariOran": float(html_fields.get("ticari_isk") or self._parse_tr_float(b_item.get("TicariHtml")) or 0.0),
                "Ticari2Oran": 0.0,
                "WebPrimOran": self._parse_tr_float(b_item.get("WebHtml")),
                "DealRate": self._parse_tr_float(b_item.get("DealHtml")),
                "OfferRate": 0.0,
                "Offers": parsed_offers,
            }

        return {
            "detail": detail,
            "basket_item_str": basket_item_str or b64_detail,
            "offer_rows": offer_rows,
        }

    @staticmethod
    def _pick_offer_for_qty(cached: Dict[str, Any], miktar: int) -> Dict[str, Any]:
        rows = cached.get("offer_rows") or []
        if not rows:
            return {
                "offer_b64": cached.get("offer_b64", ""),
                "vade": int(cached.get("vade") or 30),
                "net_fiyat": float(cached.get("net_fiyat") or 0.0),
            }
        qty = max(1, int(miktar or 1))
        default_row = next((r for r in rows if r.get("checked")), rows[0])
        default_vade = int(default_row.get("vade") or 30)
        eligible = [r for r in rows if int(r.get("min_qty") or 1) <= qty]
        if not eligible:
            return default_row
        # Varsayılan vadeyi koruyan (peşin vadeye zorlamayan) ve miktara uygun en yüksek MF / kademeyi seç
        same_vade = [r for r in eligible if int(r.get("vade") or 30) >= default_vade]
        pool = same_vade if same_vade else eligible
        best = max(
            pool,
            key=lambda r: (
                float(r.get("eq_rate") or 0.0),
                int(r.get("min_qty") or 1),
                -float(r.get("net_fiyat") or 999999.0),
            ),
        )
        return best

    def _parse_branch_item(self, detail: Dict[str, Any], eq_string: str, query: str) -> DepoUrunSarti:
        item_id = str(detail.get("ID", ""))
        name = detail.get("Name", "")
        barcode = detail.get("Barcode") or query
        
        has_stock = bool(detail.get("HasStock", False))
        stock_qty = int(detail.get("QA", 0) or 0)
        stok_durumu = StokDurumu.VAR if has_stock else StokDurumu.YOK

        price_tag = detail.get("PriceTag") or {}
        psf = float(price_tag.get("ListPrice") or 0.0)
        dsf_taxed = float(price_tag.get("SalesPrice") or 0.0)
        dsf_notax = float(price_tag.get("SalesPriceOutOfTaxes") or 0.0)
        dsf = dsf_notax if dsf_notax > 0 else dsf_taxed
        kdv_orani = float(price_tag.get("TaxRate") or 10.0)
        eczaci_kari = float(price_tag.get("CustomerProfitRate") or 0.0)
        is_cold = bool(detail.get("MustShipCold", False))

        # İskontolar
        kurum_isk = float(detail.get("KurumOran") or 0.0)
        ticari_isk = float(detail.get("TicariOran") or 0.0)
        ticari2_isk = float(detail.get("Ticari2Oran") or 0.0)
        web_prim = float(detail.get("WebPrimOran") or 0.0)
        deal_rate = float(detail.get("DealRate") or 0.0)
        offer_rate = float(detail.get("OfferRate") or 0.0)

        # Teklifler (Offers)
        offers = detail.get("Offers") or []
        en_iyi_vade = 30
        en_iyi_net_fiyat = 0.0
        kampanya_notu = ""
        secilen_teklif = None

        min_offer_net = 999999.0
        base_offer_net = 0.0

        if offers:
            for off in offers:
                o_net = float(off.get("NetPrice") or 0.0)
                o_min_qty = int(off.get("MinQuantity") or 1)
                o_days = int(off.get("DaysDue") or 30)

                if o_min_qty <= 1 and base_offer_net == 0.0 and o_net > 0:
                    base_offer_net = o_net

                if o_net > 0 and o_net < min_offer_net:
                    min_offer_net = o_net
                    en_iyi_vade = o_days
                    secilen_teklif = off

            if not secilen_teklif:
                secilen_teklif = offers[0]
                en_iyi_vade = int(secilen_teklif.get("DaysDue") or 30)
                min_offer_net = float(secilen_teklif.get("NetPrice") or dsf)

            en_iyi_net_fiyat = min_offer_net
            min_q = secilen_teklif.get("MinQuantity", 1)
            kampanya_notu = f"{secilen_teklif.get('Name')} (Min: {min_q} Adet, {en_iyi_vade} Gün)"

        # Açık ticari iskontoların toplamı
        toplam_ticari = ticari_isk + ticari2_isk + web_prim + deal_rate + offer_rate
        if secilen_teklif:
            off_rate = float(secilen_teklif.get("Rate") or 0.0)
            off_extra = float(secilen_teklif.get("ExtraDiscountRate") or 0.0)
            off_cash = float(secilen_teklif.get("CashDiscountRate") or 0.0)
            toplam_ticari = max(toplam_ticari, off_rate + off_extra + off_cash)

        # Eczane İskonto Çarpanı:
        # Kurum/Kamu İskontosu ve Ticari İskonto birlikte DSF'den düşülür
        # Formül: Net = DSF * (1 - Kurum / 100) * (1 - Ticari / 100)
        birlesik_isk_carpan = (1.0 - (kurum_isk / 100.0)) * (1.0 - (toplam_ticari / 100.0))
        birlesik_iskonto_yuzdesi = round((1.0 - birlesik_isk_carpan) * 100.0, 2)

        # Eğer Alliance'ın doğrudan bildirdiği teklif net fiyatı daha avantajlıysa (örn. özel kampanya)
        if dsf > 0 and en_iyi_net_fiyat > 0 and en_iyi_net_fiyat < (dsf - 0.01):
            derived_disc = round((1.0 - (en_iyi_net_fiyat / dsf)) * 100.0, 2)
            if not eq_string or eq_string.strip().upper() in ["YOK", "-", ""]:
                birlesik_iskonto_yuzdesi = max(birlesik_iskonto_yuzdesi, derived_disc)

        # MF formatlama
        mf_text = eq_string.strip() if eq_string else "YOK"

        # Maliyet motoru (Tüm kademeleri hesaplar)
        maliyet = CostCalculator.calculate(
            dsf=dsf,
            psf=psf,
            kdv_orani=kdv_orani,
            mf_str=mf_text,
            ticari_iskonto=birlesik_iskonto_yuzdesi,
            vade_gun=en_iyi_vade
        )

        final_net = maliyet.net_birim_maliyet
        if en_iyi_net_fiyat > 0 and (final_net == 0 or en_iyi_net_fiyat < final_net):
            final_net = round(en_iyi_net_fiyat, 2)

        final_net_kdvli = round(final_net * (1.0 + (kdv_orani / 100.0)), 2)

        # Eğer MF yok ama tekliflerde farklı ve daha avantajlı alım kademeleri varsa kademelere ekle
        kademeler = list(maliyet.kademeler)
        if not kademeler and len(offers) > 1:
            for off in sorted(offers, key=lambda x: int(x.get("MinQuantity") or 1)):
                q = int(off.get("MinQuantity") or 1)
                np = float(off.get("NetPrice") or 0.0)
                if q > 1 and np > 0 and np < (final_net - 0.01):
                    np_kdvli = round(np * (1.0 + (kdv_orani / 100.0)), 2)
                    off_disc = round((1.0 - (np / dsf)) * 100.0, 2) if dsf > 0 else 0.0
                    kademeler.append(MFKademeDetay(
                        alinan=q,
                        hediye=0,
                        mf_text=f"{q} Kutu",
                        net_birim_maliyet=round(np, 2),
                        net_birim_maliyet_kdvli=np_kdvli,
                        toplam_iskonto_yuzdesi=off_disc
                    ))

        # Kampanya ve vade notunu zenginleştir
        notlar = [f"{en_iyi_vade} Gün Vade"]
        if mf_text != "YOK":
            notlar.append(f"MF: {mf_text}")
        if toplam_ticari > 0:
            notlar.append(f"İsk: %{round(toplam_ticari, 2)}")
        if kurum_isk > 0:
            notlar.append(f"Kamu İsk: %{round(kurum_isk, 2)}")
        if notlar:
            kampanya_notu = " • ".join(notlar)

        return DepoUrunSarti(
            depo=DepoKodu.ALLIANCE,
            depo_adi=self.depo_adi,
            barkod=barcode,
            urun_id=item_id,
            urun_adi=name,
            stok_durumu=stok_durumu,
            stok_adedi=stock_qty if has_stock else 0,
            depocu_satis_fiyati=round(dsf, 2),
            perakende_satis_fiyati=round(psf, 2),
            kdv_orani=kdv_orani,
            mf_metni=mf_text,
            kademeler=kademeler,
            ticari_iskonto=round(toplam_ticari, 2),
            vade_gun=en_iyi_vade,
            net_birim_maliyet=round(final_net, 2),
            net_birim_maliyet_kdvli=final_net_kdvli,
            toplam_indirim_yuzdesi=round((1.0 - (final_net / dsf)) * 100.0, 2) if dsf > 0 else 0.0,
            ozel_kampanya_notu=kampanya_notu,
            soguk_zincir=is_cold,
            kamu_iskontosu=round(kurum_isk, 2),
            eczaci_kari=round(eczaci_kari, 2)
        )

    async def _add_to_cart_unlocked(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        barkod = str(kwargs.get("barkod") or "").strip()
        if len(barkod) == 14 and barkod.startswith("0"):
            barkod = barkod[1:]
        actual_id = str(urun_id or "").strip()
        fallback_name = str(kwargs.get("name") or kwargs.get("urun_adi") or "").strip()

        # 1. HIZLI YOL: Arama sırasında önbelleğe alınmış ürün ise (SearchItems + ItemsBranchDetail atlanır, tek adımda ~80ms!)
        cached = self._fast_cart_cache.get(actual_id) or (self._fast_cart_cache.get(barkod) if barkod else None)
        if cached and cached.get("from_v3") and cached.get("b64_detail") and cached.get("offer_b64"):
            if not cached.get("has_stock", True):
                return {"success": False, "message": "Ürün Alliance deposunda stokta yok."}

            chosen_off = self._pick_offer_for_qty(cached, int(miktar))
            add_resp = await self._page.evaluate("""async (param) => {
                function postBasket(supCtrl) {
                    return new Promise((resolve) => {
                        let done = false;
                        const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, 6500);
                        const finish = (res) => {
                            if (done) return;
                            done = true;
                            clearTimeout(timer);
                            resolve(res);
                        };
                        try {
                            if (typeof $ !== 'undefined' && $.ajax) {
                                $.ajax({
                                    url: "/Sales/AddItemToBasket",
                                    type: "POST",
                                    data: {
                                        ItemString: param.itemString,
                                        OfferString: param.offerString,
                                        Quantity: param.quantity,
                                        SupplierControlParam: supCtrl
                                    },
                                    timeout: 6500,
                                    success: finish,
                                    error: () => finish(null)
                                });
                                return;
                            }
                            const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                            postFn("/Sales/AddItemToBasket", {
                                ItemString: param.itemString,
                                OfferString: param.offerString,
                                Quantity: param.quantity,
                                SupplierControlParam: supCtrl
                            }, finish);
                        } catch (e) {
                            finish(null);
                        }
                    });
                }
                let res = await postBasket(false);
                if (res && !res.Result && res.ResultUrl === "SupplierControlParam") {
                    res = await postBasket(true);
                }
                if (res && res.Result && typeof RebindQuickCart === 'function') {
                    try { RebindQuickCart(); } catch (e) {}
                }
                return res;
            }""", {
                "itemString": cached["b64_detail"],
                "offerString": chosen_off["offer_b64"],
                "quantity": int(miktar)
            })

            if add_resp and isinstance(add_resp, dict) and add_resp.get("Result"):
                prod_name = cached.get("name", "Ürün")
                resolved_cid = str(cached.get("item_id") or actual_id or "").strip()
                unit_p = float(chosen_off.get("net_fiyat") or cached.get("net_fiyat") or 0.0)
                vade_val = int(chosen_off.get("vade") or cached.get("vade") or 30)
                self._merge_last_added_items([{
                    "id": resolved_cid or barkod,
                    "kod": resolved_cid,
                    "urun_id": resolved_cid,
                    "barcode": barkod or "",
                    "ad": prod_name,
                    "name": prod_name,
                    "miktar": int(miktar),
                    "mf": "0",
                    "birim_fiyat": unit_p,
                    "tutar": round(unit_p * int(miktar), 2)
                }])
                return {
                    "success": True,
                    "depo": "ALLIANCE",
                    "message": f"{prod_name} başarıyla Alliance sepetine eklendi.",
                    "urun_adi": prod_name,
                    "urun_id": resolved_cid,
                    "miktar": int(miktar),
                    "vade": vade_val,
                    "net_fiyat": unit_p
                }

        # 2. YEDEK YOL: Önbellekte yoksa (veya hızlı yol başarısız olduysa) TEK JS çağrısında çöz ve ekle
        is_direct_id = actual_id.isdigit() and len(actual_id) <= 8 and not actual_id.startswith("869")
        search_target = barkod or actual_id or fallback_name

        js_single_add = """async (params) => {
            function postAsync(url, data, timeoutMs = 6500) {
                return new Promise((resolve) => {
                    let done = false;
                    const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, timeoutMs);
                    try {
                        if (typeof $ !== 'undefined' && $.ajax) {
                            $.ajax({
                                url: url,
                                type: 'POST',
                                data: data,
                                timeout: timeoutMs,
                                success: function(res) {
                                    if (!done) {
                                        done = true;
                                        clearTimeout(timer);
                                        if (typeof res === 'string' && (res.includes('pharmacyCode') || res.includes('Customer_username') || res.includes('/Home/Login'))) {
                                            resolve({ _session_expired: true });
                                            return;
                                        }
                                        resolve(res);
                                    }
                                },
                                error: function(xhr) {
                                    if (!done) {
                                        done = true;
                                        clearTimeout(timer);
                                        if (xhr && (xhr.status === 401 || xhr.status === 403 || xhr.status === 302)) {
                                            resolve({ _session_expired: true });
                                            return;
                                        }
                                        resolve(null);
                                    }
                                }
                            });
                            return;
                        }
                        const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                        postFn(url, data, function(res) { if (!done) { done = true; clearTimeout(timer); resolve(res); } });
                    } catch (e) {
                        if (!done) { done = true; clearTimeout(timer); resolve(null); }
                    }
                });
            }

            function parseTrFloat(raw) {
                if (raw == null) return 0;
                if (typeof raw === 'number') return raw;
                let s = String(raw).replace(/[^0-9.,-]/g, '').trim();
                if (!s || s === '-' || s === '.' || s === ',') return 0;
                if (s.includes(',') && s.includes('.')) {
                    if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\\./g, '').replace(',', '.');
                    else s = s.replace(/,/g, '');
                } else if (s.includes(',')) {
                    s = s.replace(',', '.');
                }
                return parseFloat(s) || 0;
            }

            function tryDecodeB64Json(b64Str) {
                if (!b64Str || typeof b64Str !== 'string') return null;
                try {
                    const bin = atob(b64Str.trim());
                    const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
                    const utfTxt = new TextDecoder('utf-8').decode(bytes).trim();
                    if (utfTxt.startsWith('{') && utfTxt.endsWith('}')) return JSON.parse(utfTxt);
                } catch (_e1) {}
                try {
                    const latTxt = atob(b64Str.trim()).trim();
                    if (latTxt.startsWith('{') && latTxt.endsWith('}')) return JSON.parse(latTxt);
                } catch (_e2) {}
                return null;
            }

            function encodeJsonUtf8B64(obj) {
                const u8 = new TextEncoder().encode(JSON.stringify(obj || {}));
                let bin = '';
                for (let bi = 0; bi < u8.length; bi++) bin += String.fromCharCode(u8[bi]);
                return btoa(bin);
            }

            function pickOfferForQty(offerRows, qty) {
                if (!offerRows || !offerRows.length) return null;
                const q = Math.max(1, parseInt(qty, 10) || 1);
                const defRow = offerRows.find(r => r.checked) || offerRows[0];
                const defVade = defRow.vade || 30;
                const eligible = offerRows.filter(r => (r.min_qty || 1) <= q);
                if (!eligible.length) return defRow;
                const sameVade = eligible.filter(r => (r.vade || 30) >= defVade);
                const pool = sameVade.length ? sameVade : eligible;
                let best = pool[0];
                for (const r of pool) {
                    if ((r.eq_rate || 0) > (best.eq_rate || 0)) best = r;
                    else if ((r.eq_rate || 0) === (best.eq_rate || 0)) {
                        if ((r.min_qty || 1) > (best.min_qty || 1)) best = r;
                        else if ((r.min_qty || 1) === (best.min_qty || 1) && (r.net_fiyat || 999999) < (best.net_fiyat || 999999)) best = r;
                    }
                }
                return best;
            }

            function extractFirstSearchRow(html) {
                if (!html || typeof html !== 'string') return null;
                const temp = document.createElement('div');
                temp.innerHTML = html;
                const tr = temp.querySelector('tr[id^="branchdetailstring_"]');
                if (!tr) return null;
                const id = (tr.getAttribute('data-itemid') || (tr.id || '').replace('branchdetailstring_', '')).trim();
                if (!id) return null;
                const spanEl = tr.querySelector('td.text_column span[title], span[title]');
                return {
                    id: id,
                    itemString: tr.getAttribute('data-itemstring') || '',
                    name: spanEl ? (spanEl.textContent || '').trim() : ''
                };
            }

            try {
                let targetId = params.isDirectId ? params.actualId : '';
                let rowItemString = '';
                let rowName = params.fallbackName || '';

                if (!targetId && params.searchTarget) {
                    let searchHtml = await postAsync('/Sales/SearchItems', {
                        SearchText: params.searchTarget,
                        OnlyStock: false,
                        SearchContains: false,
                        SelectedClass: '3',
                        Sorter: 0,
                        ManufacturerID: '0',
                        WithEQ: false,
                        RequestedPage: 1,
                        BeforeSearchRequest: ''
                    });
                    if (searchHtml && typeof searchHtml === 'object' && searchHtml._session_expired) {
                        return { _session_expired: true };
                    }
                    let sr = extractFirstSearchRow(searchHtml);
                    if (!sr && /^\\d{13}$/.test(params.searchTarget)) {
                        searchHtml = await postAsync('/Sales/SearchItems', {
                            SearchText: '0' + params.searchTarget,
                            OnlyStock: false,
                            SearchContains: false,
                            SelectedClass: '3',
                            Sorter: 0,
                            ManufacturerID: '0',
                            WithEQ: false,
                            RequestedPage: 1,
                            BeforeSearchRequest: ''
                        });
                        if (searchHtml && typeof searchHtml === 'object' && searchHtml._session_expired) {
                            return { _session_expired: true };
                        }
                        sr = extractFirstSearchRow(searchHtml);
                    }
                    if (!sr && params.fallbackName) {
                        const cleanWords = params.fallbackName.replace(/[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]/g, ' ').trim().split(/\\s+/).slice(0, 3).join(' ');
                        if (cleanWords.length >= 3) {
                            searchHtml = await postAsync('/Sales/SearchItems', {
                                SearchText: cleanWords,
                                OnlyStock: false,
                                SearchContains: false,
                                SelectedClass: '3',
                                Sorter: 0,
                                ManufacturerID: '0',
                                WithEQ: false,
                                RequestedPage: 1,
                                BeforeSearchRequest: ''
                            });
                            if (searchHtml && typeof searchHtml === 'object' && searchHtml._session_expired) {
                                return { _session_expired: true };
                            }
                            sr = extractFirstSearchRow(searchHtml);
                        }
                    }
                    if (sr) {
                        targetId = sr.id;
                        rowItemString = sr.itemString || '';
                        if (sr.name) rowName = sr.name;
                    }
                }

                if (!targetId) {
                    return { success: false, message: 'Alliance deposunda ürün bulunamadı.' };
                }

                const branchData = await postAsync('/Sales/ItemsBranchDetail', {
                    ItemIDs: targetId,
                    NonDrugInventoryItems: ''
                });
                if (branchData && typeof branchData === 'object' && branchData._session_expired) {
                    return { _session_expired: true };
                }
                if (!branchData || !Array.isArray(branchData) || !branchData[0] || !branchData[0].BranchItemDetailString) {
                    return { success: false, message: 'Alliance ürün şube bilgisi alınamadı.' };
                }

                const b0 = branchData[0];
                const b64Detail = b0.BranchItemDetailString;
                const stockHtml = String(b0.StockHtml || '');
                if (stockHtml.includes('hasnot-stock') || (b0.StockOrder !== undefined && Number(b0.StockOrder) !== 1 && !stockHtml.includes('has-stock'))) {
                    return { success: false, message: 'Ürün Alliance deposunda stokta yok.' };
                }

                let basketItemStr = '';
                let offerRows = [];
                let prodName = rowName || 'Ürün';

                const legacyDetail = tryDecodeB64Json(b64Detail);
                if (legacyDetail && Array.isArray(legacyDetail.Offers) && legacyDetail.Offers.length > 0) {
                    if (legacyDetail.HasStock === false) {
                        return { success: false, message: 'Ürün Alliance deposunda stokta yok.' };
                    }
                    basketItemStr = b64Detail;
                    prodName = legacyDetail.Name || prodName;
                    offerRows = legacyDetail.Offers.map((off, idx) => ({
                        offer_b64: encodeJsonUtf8B64(off),
                        min_qty: parseInt(off.MinQuantity, 10) || 1,
                        eq_rate: parseFloat(off.EQRate) || 0,
                        vade: parseInt(off.DaysDue, 10) || 30,
                        net_fiyat: parseFloat(off.NetPrice) || 0,
                        checked: idx === 0
                    }));
                } else {
                    const v3Html = await postAsync('/Sales/ItemDetailv3', {
                        ItemString: rowItemString || '',
                        ItemDetailString: b64Detail,
                        ViewType: 'ItemDetail',
                        ItemID: targetId,
                        LoadSimple: false
                    });
                    if (v3Html && typeof v3Html === 'object' && v3Html._session_expired) {
                        return { _session_expired: true };
                    }
                    if (!v3Html || typeof v3Html !== 'string') {
                        return { success: false, message: 'Alliance ürün kampanya detayı alınamadı.' };
                    }
                    const dDiv = document.createElement('div');
                    dDiv.innerHTML = v3Html;
                    const acc = dDiv.querySelector('#accordion, #popup_accordion, [data-item]');
                    if (acc) {
                        basketItemStr = (acc.getAttribute('data-item') || '').trim();
                        if (acc.getAttribute('data-name')) prodName = acc.getAttribute('data-name').trim();
                    }
                    const decItem = tryDecodeB64Json(basketItemStr);
                    if (decItem) {
                        if (decItem.HasStock === false) {
                            return { success: false, message: 'Ürün Alliance deposunda stokta yok.' };
                        }
                        if (decItem.Name) prodName = decItem.Name;
                    }
                    const trs = Array.from(dDiv.querySelectorAll('#tblKampanyalar tbody tr, #popup_tblKampanyalar tbody tr'));
                    for (const tr of trs) {
                        const rad = tr.querySelector('input[type="radio"][data-offer], input[data-offer]');
                        if (!rad) continue;
                        const offStr = (rad.getAttribute('data-offer') || '').trim();
                        if (!offStr) continue;
                        const tds = tr.querySelectorAll('td');
                        let minQ = parseInt(tr.getAttribute('data-minquantity') || rad.getAttribute('data-minquantity') || (tds[2]?.textContent || '1'), 10) || 1;
                        let eqR = parseTrFloat(tr.getAttribute('data-eqrate') || '0');
                        let vade = parseInt(tds[1]?.textContent || '30', 10) || 30;
                        let netP = parseTrFloat(tds[tds.length - 1]?.textContent || '0');
                        const decOff = tryDecodeB64Json(offStr);
                        if (decOff) {
                            minQ = parseInt(decOff.MinQuantity, 10) || minQ || 1;
                            if (decOff.EQRate != null) eqR = parseFloat(decOff.EQRate) || 0;
                            vade = parseInt(decOff.DaysDue, 10) || vade || 30;
                            netP = parseFloat(decOff.NetPrice) || netP || 0;
                        }
                        offerRows.push({
                            offer_b64: offStr,
                            min_qty: Math.max(1, minQ),
                            eq_rate: eqR,
                            vade: vade,
                            net_fiyat: Math.round(netP * 100) / 100,
                            checked: rad.hasAttribute('checked') || rad.checked
                        });
                    }
                }

                if (!basketItemStr || !offerRows.length) {
                    return { success: false, message: 'Ürün için geçerli kampanya veya satış şartı bulunamadı.' };
                }

                const chosen = pickOfferForQty(offerRows, params.quantity);
                let addResp = await postAsync('/Sales/AddItemToBasket', {
                    ItemString: basketItemStr,
                    OfferString: chosen.offer_b64,
                    Quantity: params.quantity,
                    SupplierControlParam: false
                });
                if (addResp && !addResp.Result && addResp.ResultUrl === 'SupplierControlParam') {
                    addResp = await postAsync('/Sales/AddItemToBasket', {
                        ItemString: basketItemStr,
                        OfferString: chosen.offer_b64,
                        Quantity: params.quantity,
                        SupplierControlParam: true
                    });
                }

                if (addResp && addResp.Result) {
                    if (typeof RebindQuickCart === 'function') {
                        try { RebindQuickCart(); } catch(e) {}
                    }
                    return {
                        success: true,
                        depo: 'ALLIANCE',
                        urun_adi: prodName || 'Ürün',
                        vade: chosen.vade || 30,
                        net_fiyat: chosen.net_fiyat || 0.0,
                        b64_detail: basketItemStr,
                        offer_b64: chosen.offer_b64,
                        offer_rows: offerRows,
                        item_id: String(targetId)
                    };
                }
                return {
                    success: false,
                    message: (addResp && addResp.Message) || 'Alliance sepete ekleme reddedildi.'
                };
            } catch (e) {
                return { success: false, message: 'Alliance işlem hatası: ' + e.toString() };
            }
        }"""

        single_params = {
            "actualId": actual_id,
            "isDirectId": is_direct_id,
            "searchTarget": search_target,
            "fallbackName": fallback_name,
            "quantity": int(miktar)
        }
        single_res = await self._page.evaluate(js_single_add, single_params)
        if isinstance(single_res, dict) and single_res.get("_session_expired"):
            self.is_logged_in = False
            SessionStore.clear("alliance")
            await self._page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=12000)
            await self._login_unlocked()
            await self._ensure_ready_page()
            single_res = await self._page.evaluate(js_single_add, single_params)

        if single_res and single_res.get("success"):
            prod_name = single_res.get("urun_adi", "Ürün")
            resolved_item_id = str(single_res.get("item_id") or actual_id or "").strip()
            if single_res.get("b64_detail") and single_res.get("offer_b64"):
                o_rows = single_res.get("offer_rows") or []
                def_off = next((r for r in o_rows if r.get("checked")), o_rows[0]) if o_rows else None
                ce = {
                    "from_v3": True,
                    "item_id": resolved_item_id,
                    "b64_detail": single_res["b64_detail"],
                    "offer_b64": def_off["offer_b64"] if def_off else single_res["offer_b64"],
                    "offer_rows": o_rows,
                    "name": prod_name,
                    "vade": int((def_off.get("vade") if def_off else None) or single_res.get("vade") or 30),
                    "net_fiyat": float((def_off.get("net_fiyat") if def_off else None) or single_res.get("net_fiyat") or 0.0),
                    "has_stock": True
                }
                if ce["item_id"]:
                    self._fast_cart_cache[ce["item_id"]] = ce
                if barkod:
                    self._fast_cart_cache[barkod] = ce
            self._merge_last_added_items([{
                "id": resolved_item_id or barkod,
                "kod": resolved_item_id,
                "urun_id": resolved_item_id,
                "barcode": barkod or "",
                "ad": prod_name,
                "name": prod_name,
                "miktar": int(miktar),
                "mf": "0",
                "birim_fiyat": float(single_res.get("net_fiyat") or 0.0),
                "tutar": round(float(single_res.get("net_fiyat") or 0.0) * int(miktar), 2)
            }])
            return {
                "success": True,
                "depo": "ALLIANCE",
                "message": f"{prod_name} başarıyla Alliance sepetine eklendi.",
                "urun_adi": prod_name,
                "urun_id": resolved_item_id,
                "miktar": int(miktar),
                "vade": single_res.get("vade", 30),
                "net_fiyat": float(single_res.get("net_fiyat") or 0.0)
            }

        return {
            "success": False,
            "message": (single_res.get("message") if single_res else "") or "Alliance sepete ekleme başarısız."
        }

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """Alliance Healthcare sepetine ürün ekler (ID veya barkod destekli, önbellek hızlandırmalı)."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def _ensure_bulk_bridge(self):
        if not self._context:
            return
        if getattr(self, "_bridged_ctx", None) is self._context:
            return

        def _on_bulk_step(payload):
            cb = getattr(self, "_active_bulk_progress_cb", None)
            if callable(cb) and isinstance(payload, dict):
                try:
                    cb(payload)
                except Exception:
                    pass

        try:
            await self._context.expose_function("_frReportBulkProgress", _on_bulk_step)
        except Exception:
            pass
        self._bridged_ctx = self._context

    async def bulk_add_to_cart(self, items: List[Dict[str, Any]], progress_cb=None) -> Dict[str, Any]:
        """
        Alliance Healthcare sepetine toplu (batch/paralel) ürün ekler.
        items: [{"barcode": "...", "miktar": 1, "name": "...", "urun_id": "..."}]
        """
        if not items:
            return {
                "success": False,
                "message": "Eklenecek ürün listesi boş.",
                "total_items": 0,
                "success_count": 0,
                "failed_count": 0,
                "total_amount": 0.0,
                "items": []
            }

        def _emit(ev: dict):
            if callable(progress_cb):
                try:
                    progress_cb(ev)
                except Exception:
                    pass

        total_items_cnt = max(1, len(items))
        self._cart_busy += 1
        try:
            async with self._lock:
                self._active_bulk_progress_cb = progress_cb
                _emit({
                    "type": "phase",
                    "phase": "login",
                    "percent": 8,
                    "ceiling": 14,
                    "status_text": f"Alliance Healthcare oturumu doğrulanıyor ({total_items_cnt} kalem)...",
                    "current_index": 0,
                    "current_name": str(items[0].get("name") or items[0].get("urun_adi") or ""),
                })
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()
                await self._ensure_ready_page()
                await self._ensure_bulk_bridge()

                now_meta = time.time()
                clean_items = []
                for it in items:
                    bc = str(it.get("barcode") or it.get("barkod") or "").strip()
                    if len(bc) == 14 and bc.startswith("0"):
                        bc = bc[1:]
                    qty = max(1, int(it.get("miktar") or it.get("quantity") or 1))
                    name = str(it.get("name") or it.get("urun_adi") or "").strip()
                    u_id = str(it.get("urun_id") or "").strip()
                    cached = self._fast_cart_cache.get(u_id) or (self._fast_cart_cache.get(bc) if bc else None)
                    if cached and not cached.get("from_v3"):
                        cached = None
                    chosen_cached = self._pick_offer_for_qty(cached, qty) if cached else None
                    row_meta = self._get_cached_row_meta(bc, u_id)
                    fresh_istr = (
                        row_meta.get("itemString")
                        if row_meta and row_meta.get("itemString") and (now_meta - float(row_meta.get("itemStringTs") or 0.0)) < 28800
                        else ""
                    )
                    clean_items.append({
                        "barcode": bc,
                        "miktar": qty,
                        "name": name or (row_meta.get("name") if row_meta else ""),
                        "urun_id": (cached.get("item_id") if cached and cached.get("item_id") else (row_meta.get("id") if row_meta and row_meta.get("id") else u_id)),
                        "cached_item_str": fresh_istr,
                        "cached_b64": cached.get("b64_detail") if cached else None,
                        "cached_offer": chosen_cached.get("offer_b64") if chosen_cached else None,
                        "cached_name": cached.get("name") if cached else None,
                        "cached_vade": chosen_cached.get("vade") if chosen_cached else None,
                        "cached_price": chosen_cached.get("net_fiyat") if cached else None,
                        "cached_stock": cached.get("has_stock", True) if cached else True
                    })

                eval_bundle = await self._page.evaluate("""async (items) => {
                    function postAsync(url, data, timeoutMs = 6500) {
                        return new Promise((resolve) => {
                            let done = false;
                            const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, timeoutMs);
                            try {
                                if (typeof $ !== 'undefined' && $.ajax) {
                                    $.ajax({
                                        url: url,
                                        type: 'POST',
                                        data: data,
                                        timeout: timeoutMs,
                                        success: function(res) { if (!done) { done = true; clearTimeout(timer); resolve(res); } },
                                        error: function() { if (!done) { done = true; clearTimeout(timer); resolve(null); } }
                                    });
                                    return;
                                }
                                const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                                postFn(url, data, function(res) {
                                    if (!done) { done = true; clearTimeout(timer); resolve(res); }
                                });
                            } catch (e) {
                                if (!done) { done = true; clearTimeout(timer); resolve(null); }
                            }
                        });
                    }

                    function parseTrFloat(raw) {
                        if (raw == null) return 0;
                        if (typeof raw === 'number') return raw;
                        let s = String(raw).replace(/[^0-9.,-]/g, '').trim();
                        if (!s || s === '-' || s === '.' || s === ',') return 0;
                        if (s.includes(',') && s.includes('.')) {
                            if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\\./g, '').replace(',', '.');
                            else s = s.replace(/,/g, '');
                        } else if (s.includes(',')) {
                            s = s.replace(',', '.');
                        }
                        return parseFloat(s) || 0;
                    }

                    function tryDecodeB64Json(b64Str) {
                        if (!b64Str || typeof b64Str !== 'string') return null;
                        try {
                            const bin = atob(b64Str.trim());
                            const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
                            const utfTxt = new TextDecoder('utf-8').decode(bytes).trim();
                            if (utfTxt.startsWith('{') && utfTxt.endsWith('}')) return JSON.parse(utfTxt);
                        } catch (_e1) {}
                        try {
                            const latTxt = atob(b64Str.trim()).trim();
                            if (latTxt.startsWith('{') && latTxt.endsWith('}')) return JSON.parse(latTxt);
                        } catch (_e2) {}
                        return null;
                    }

                    function encodeOfferB64Safe(offerObj) {
                        const u8 = new TextEncoder().encode(JSON.stringify(offerObj || {}));
                        let bin = '';
                        for (let bi = 0; bi < u8.length; bi++) bin += String.fromCharCode(u8[bi]);
                        return btoa(bin);
                    }

                    function pickOfferForQty(offerRows, qty) {
                        if (!offerRows || !offerRows.length) return null;
                        const q = Math.max(1, parseInt(qty, 10) || 1);
                        const defRow = offerRows.find(r => r.checked) || offerRows[0];
                        const defVade = defRow.vade || 30;
                        const eligible = offerRows.filter(r => (r.min_qty || 1) <= q);
                        if (!eligible.length) return defRow;
                        const sameVade = eligible.filter(r => (r.vade || 30) >= defVade);
                        const pool = sameVade.length ? sameVade : eligible;
                        let best = pool[0];
                        for (const r of pool) {
                            if ((r.eq_rate || 0) > (best.eq_rate || 0)) best = r;
                            else if ((r.eq_rate || 0) === (best.eq_rate || 0)) {
                                if ((r.min_qty || 1) > (best.min_qty || 1)) best = r;
                                else if ((r.min_qty || 1) === (best.min_qty || 1) && (r.net_fiyat || 999999) < (best.net_fiyat || 999999)) best = r;
                            }
                        }
                        return best;
                    }

                    function extractFirstSearchRow(html) {
                        if (!html || typeof html !== 'string') return null;
                        const temp = document.createElement('div');
                        temp.innerHTML = html;
                        const tr = temp.querySelector('tr[id^="branchdetailstring_"]');
                        if (!tr) return null;
                        const id = (tr.getAttribute('data-itemid') || (tr.id || '').replace('branchdetailstring_', '')).trim();
                        if (!id) return null;
                        const spanEl = tr.querySelector('td.text_column span[title], span[title]');
                        return {
                            id: id,
                            barcode: spanEl ? (spanEl.getAttribute('title') || '').trim() : '',
                            itemString: tr.getAttribute('data-itemstring') || '',
                            name: spanEl ? (spanEl.textContent || '').trim() : ''
                        };
                    }

                    const discoveredRows = [];
                    const totalItems = Math.max(1, items.length);
                    function reportStep(ev) {
                        try {
                            if (typeof window._frReportBulkProgress === 'function') {
                                window._frReportBulkProgress(ev);
                            }
                        } catch (_e) {}
                    }
                    reportStep({
                        type: 'phase',
                        phase: 'prepare_meta',
                        percent: 12,
                        ceiling: 18,
                        status_text: `Alliance ürün kodları sorgulanıyor (0/${totalItems})...`
                    });

                    // ADIM 1A: Önbellekte olmayan ürünlerin ItemID + ItemString bilgisini 6'lı paralel gruplarla çöz
                    async function resolveRowMeta(item) {
                        if (item.cached_b64 && item.cached_offer) {
                            return { item, fromFastCache: true, rowId: item.urun_id || '', rowItemString: item.cached_item_str || '', rowName: item.cached_name || item.name || '' };
                        }
                        if (item.urun_id && item.cached_item_str && !String(item.urun_id).startsWith('869') && String(item.urun_id).length <= 8) {
                            return { item, fromFastCache: false, rowId: String(item.urun_id), rowItemString: item.cached_item_str, rowName: item.name || '' };
                        }
                        const searchTarget = (item.barcode && item.barcode.trim()) ? item.barcode.trim() : (item.name || '').trim();
                        if (searchTarget) {
                            let searchHtml = await postAsync('/Sales/SearchItems', {
                                SearchText: searchTarget, OnlyStock: false, SearchContains: false,
                                SelectedClass: '3', Sorter: 0, ManufacturerID: '0',
                                WithEQ: false, RequestedPage: 1, BeforeSearchRequest: ''
                            });
                            let sr = extractFirstSearchRow(searchHtml);
                            if (!sr && item.barcode && item.barcode.length === 13) {
                                searchHtml = await postAsync('/Sales/SearchItems', {
                                    SearchText: '0' + item.barcode, OnlyStock: false, SearchContains: false,
                                    SelectedClass: '3', Sorter: 0, ManufacturerID: '0',
                                    WithEQ: false, RequestedPage: 1, BeforeSearchRequest: ''
                                });
                                sr = extractFirstSearchRow(searchHtml);
                            }
                            if (!sr && item.name) {
                                const cleanWords = item.name.replace(/[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]/g, ' ').trim().split(/\\s+/).slice(0, 3).join(' ');
                                if (cleanWords.length >= 3) {
                                    searchHtml = await postAsync('/Sales/SearchItems', {
                                        SearchText: cleanWords, OnlyStock: false, SearchContains: false,
                                        SelectedClass: '3', Sorter: 0, ManufacturerID: '0',
                                        WithEQ: false, RequestedPage: 1, BeforeSearchRequest: ''
                                    });
                                    sr = extractFirstSearchRow(searchHtml);
                                }
                            }
                            if (sr && sr.id) {
                                discoveredRows.push({ id: sr.id, itemString: sr.itemString || '', barcode: sr.barcode || item.barcode || '', name: sr.name || item.name || '' });
                                return { item, fromFastCache: false, rowId: sr.id, rowItemString: sr.itemString || '', rowName: sr.name || item.name || '' };
                            }
                            return { item, fromFastCache: false, rowId: '', rowItemString: '', rowName: item.name || '', notFound: true };
                        }
                        if (item.urun_id) {
                            return { item, fromFastCache: false, rowId: String(item.urun_id), rowItemString: item.cached_item_str || '', rowName: item.name || '' };
                        }
                        return { item, fromFastCache: false, rowId: '', rowItemString: '', rowName: item.name || '' };
                    }

                    const resolvedMetas = [];
                    for (let i = 0; i < items.length; i += 6) {
                        const chunk = items.slice(i, i + 6);
                        const mRes = await Promise.all(chunk.map(it => resolveRowMeta(it)));
                        resolvedMetas.push(...mRes);
                        reportStep({
                            type: 'phase',
                            phase: 'prepare_meta',
                            percent: 12 + Math.round((resolvedMetas.length / totalItems) * 6),
                            ceiling: 20,
                            status_text: `Alliance ürün kodları çözümleniyor (${resolvedMetas.length}/${totalItems})...`
                        });
                    }

                    // ADIM 1B: Tüm ürünlerin şube detaylarını (ItemsBranchDetail) N ayrı istek yerine TEK TOPLU İSTEKTE çek!
                    const needBranchIds = Array.from(new Set(
                        resolvedMetas.filter(m => !m.fromFastCache && m.rowId).map(m => String(m.rowId))
                    ));
                    if (needBranchIds.length > 0) {
                        reportStep({
                            type: 'phase',
                            phase: 'prepare_branch',
                            percent: 19,
                            ceiling: 23,
                            status_text: `Alliance şube stok durumu kontrol ediliyor (${needBranchIds.length} kalem)...`
                        });
                    }
                    const branchMap = {};
                    for (let i = 0; i < needBranchIds.length; i += 25) {
                        const idSlice = needBranchIds.slice(i, i + 25);
                        const batchBranch = await postAsync('/Sales/ItemsBranchDetail', {
                            ItemIDs: idSlice.join(','),
                            NonDrugInventoryItems: ''
                        }, 8500);
                        if (Array.isArray(batchBranch)) {
                            for (const b of batchBranch) {
                                if (b && b.ItemID != null) branchMap[String(b.ItemID)] = b;
                            }
                        }
                    }

                    // ADIM 1C: ItemDetailv3 kampanya tokenlarını 6'lı paralel gruplarla çöz (~38ms/kalem!)
                    async function buildPreparedFromMeta(meta, forceFresh = false) {
                        const item = meta.item;
                        const prep = {
                            item: item,
                            ready: false,
                            rowId: meta.rowId || item.urun_id || '',
                            b64Detail: (!forceFresh && item.cached_b64) ? item.cached_b64 : '',
                            offerB64: (!forceFresh && item.cached_offer) ? item.cached_offer : '',
                            offerRows: [],
                            urunAdi: meta.rowName || item.cached_name || item.name || '',
                            vade: item.cached_vade || 30,
                            netFiyat: item.cached_price || 0,
                            noStock: false,
                            failMessage: ''
                        };
                        try {
                            if (!forceFresh && meta.fromFastCache && item.cached_b64 && item.cached_offer) {
                                if (item.cached_stock === false) {
                                    prep.noStock = true;
                                    prep.failMessage = 'Ürün Stokta Yok (Depo mevcudu 0)';
                                    return prep;
                                }
                                if (!prep.rowId) {
                                    const cd = tryDecodeB64Json(item.cached_b64);
                                    if (cd && (cd.ItemID || cd.Id || cd.ID)) prep.rowId = String(cd.ItemID || cd.Id || cd.ID);
                                }
                                prep.ready = true;
                                prep.fromCache = true;
                                return prep;
                            }

                            let rowId = meta.rowId || '';
                            let rowItemString = meta.rowItemString || '';
                            let prodName = meta.rowName || item.name || 'Ürün';

                            if (forceFresh || (!rowId && !meta.notFound)) {
                                const freshMeta = await resolveRowMeta({ ...item, cached_b64: null, cached_offer: null, cached_item_str: '' });
                                rowId = freshMeta.rowId || rowId;
                                rowItemString = freshMeta.rowItemString || rowItemString;
                                if (freshMeta.rowName) prodName = freshMeta.rowName;
                            }

                            if (!rowId) {
                                prep.noStock = true;
                                prep.failMessage = meta.notFound ? 'Alliance deposunda bulunamadı (Stok yok veya kapalı)' : 'Ürün şube ID belirlenemedi';
                                return prep;
                            }

                            let b0 = (!forceFresh) ? branchMap[String(rowId)] : null;
                            if (!b0 || !b0.BranchItemDetailString) {
                                const singleB = await postAsync('/Sales/ItemsBranchDetail', { ItemIDs: rowId, NonDrugInventoryItems: '' });
                                if (Array.isArray(singleB) && singleB[0]) b0 = singleB[0];
                            }
                            if (!b0 || !b0.BranchItemDetailString) {
                                prep.failMessage = 'Şube detayı bulunamadı';
                                return prep;
                            }

                            const b64Detail = b0.BranchItemDetailString;
                            const stockHtml = String(b0.StockHtml || '');
                            if (stockHtml.includes('hasnot-stock') || (b0.StockOrder !== undefined && Number(b0.StockOrder) !== 1 && !stockHtml.includes('has-stock'))) {
                                prep.noStock = true;
                                prep.failMessage = 'Ürün Stokta Yok (Depo mevcudu 0)';
                                return prep;
                            }

                            let basketItemStr = '';
                            let offerRows = [];

                            const legacyDetail = tryDecodeB64Json(b64Detail);
                            if (legacyDetail && Array.isArray(legacyDetail.Offers) && legacyDetail.Offers.length > 0) {
                                if (legacyDetail.HasStock === false) {
                                    prep.noStock = true;
                                    prep.failMessage = 'Ürün Stokta Yok (Depo mevcudu 0)';
                                    return prep;
                                }
                                basketItemStr = b64Detail;
                                prodName = legacyDetail.Name || prodName;
                                offerRows = legacyDetail.Offers.map((off, idx) => ({
                                    offer_b64: encodeOfferB64Safe(off),
                                    min_qty: parseInt(off.MinQuantity, 10) || 1,
                                    eq_rate: parseFloat(off.EQRate) || 0,
                                    vade: parseInt(off.DaysDue, 10) || 30,
                                    net_fiyat: parseFloat(off.NetPrice) || 0,
                                    checked: idx === 0
                                }));
                            } else {
                                let v3Html = await postAsync('/Sales/ItemDetailv3', {
                                    ItemString: rowItemString || '',
                                    ItemDetailString: b64Detail,
                                    ViewType: 'ItemDetail',
                                    ItemID: rowId,
                                    LoadSimple: false
                                });
                                if ((!v3Html || typeof v3Html !== 'string' || !v3Html.includes('accordion')) && rowItemString && item.barcode) {
                                    const sHtml = await postAsync('/Sales/SearchItems', {
                                        SearchText: item.barcode, OnlyStock: false, SearchContains: false,
                                        SelectedClass: '3', Sorter: 0, ManufacturerID: '0',
                                        WithEQ: false, RequestedPage: 1, BeforeSearchRequest: ''
                                    });
                                    const sr2 = extractFirstSearchRow(sHtml);
                                    if (sr2 && sr2.itemString) {
                                        discoveredRows.push({ id: sr2.id || rowId, itemString: sr2.itemString, barcode: sr2.barcode || item.barcode, name: sr2.name || prodName });
                                        v3Html = await postAsync('/Sales/ItemDetailv3', {
                                            ItemString: sr2.itemString,
                                            ItemDetailString: b64Detail,
                                            ViewType: 'ItemDetail',
                                            ItemID: rowId,
                                            LoadSimple: false
                                        });
                                    }
                                }
                                if (!v3Html || typeof v3Html !== 'string') {
                                    prep.failMessage = 'Şube kampanya detayı alınamadı';
                                    return prep;
                                }
                                const dDiv = document.createElement('div');
                                dDiv.innerHTML = v3Html;
                                const acc = dDiv.querySelector('#accordion, #popup_accordion, [data-item]');
                                if (acc) {
                                    basketItemStr = (acc.getAttribute('data-item') || '').trim();
                                    if (acc.getAttribute('data-name')) prodName = acc.getAttribute('data-name').trim();
                                }
                                const decItem = tryDecodeB64Json(basketItemStr);
                                if (decItem) {
                                    if (decItem.HasStock === false) {
                                        prep.noStock = true;
                                        prep.failMessage = 'Ürün Stokta Yok (Depo mevcudu 0)';
                                        return prep;
                                    }
                                    if (decItem.Name) prodName = decItem.Name;
                                }
                                const trs = Array.from(dDiv.querySelectorAll('#tblKampanyalar tbody tr, #popup_tblKampanyalar tbody tr'));
                                for (const tr of trs) {
                                    const rad = tr.querySelector('input[type="radio"][data-offer], input[data-offer]');
                                    if (!rad) continue;
                                    const offStr = (rad.getAttribute('data-offer') || '').trim();
                                    if (!offStr) continue;
                                    const tds = tr.querySelectorAll('td');
                                    let minQ = parseInt(tr.getAttribute('data-minquantity') || rad.getAttribute('data-minquantity') || (tds[2]?.textContent || '1'), 10) || 1;
                                    let eqR = parseTrFloat(tr.getAttribute('data-eqrate') || '0');
                                    let vade = parseInt(tds[1]?.textContent || '30', 10) || 30;
                                    let netP = parseTrFloat(tds[tds.length - 1]?.textContent || '0');
                                    const decOff = tryDecodeB64Json(offStr);
                                    if (decOff) {
                                        minQ = parseInt(decOff.MinQuantity, 10) || minQ || 1;
                                        if (decOff.EQRate != null) eqR = parseFloat(decOff.EQRate) || 0;
                                        vade = parseInt(decOff.DaysDue, 10) || vade || 30;
                                        netP = parseFloat(decOff.NetPrice) || netP || 0;
                                    }
                                    offerRows.push({
                                        offer_b64: offStr,
                                        min_qty: Math.max(1, minQ),
                                        eq_rate: eqR,
                                        vade: vade,
                                        net_fiyat: Math.round(netP * 100) / 100,
                                        checked: rad.hasAttribute('checked') || rad.checked
                                    });
                                }
                            }

                            if (!basketItemStr || offerRows.length === 0) {
                                prep.noStock = true;
                                prep.failMessage = 'Satış şartı / kampanya teklifi bulunamadı';
                                return prep;
                            }

                            const chosen = pickOfferForQty(offerRows, item.miktar);
                            prep.ready = true;
                            prep.rowId = String(rowId || '');
                            prep.b64Detail = basketItemStr;
                            prep.offerB64 = chosen.offer_b64;
                            prep.offerRows = offerRows;
                            prep.urunAdi = prodName;
                            prep.vade = chosen.vade || 30;
                            prep.netFiyat = Math.round((chosen.net_fiyat || 0) * 100) / 100;
                            return prep;
                        } catch (e) {
                            prep.failMessage = 'Hazırlık hatası: ' + e.message;
                            return prep;
                        }
                    }

                    const preparedList = [];
                    for (let i = 0; i < resolvedMetas.length; i += 6) {
                        const chunk = resolvedMetas.slice(i, i + 6);
                        const pRes = await Promise.all(chunk.map(m => buildPreparedFromMeta(m, false)));
                        preparedList.push(...pRes);
                        reportStep({
                            type: 'phase',
                            phase: 'prepare_offers',
                            percent: 21 + Math.round((preparedList.length / totalItems) * 7),
                            ceiling: 30,
                            status_text: `Satış şartları ve kampanyalar hazırlanıyor (${preparedList.length}/${totalItems})...`
                        });
                    }
                    reportStep({
                        type: 'phase',
                        phase: 'adding',
                        percent: 28,
                        ceiling: 33,
                        current_index: 0,
                        current_name: (preparedList[0] && (preparedList[0].urunAdi || preparedList[0].item?.name)) || '',
                        status_text: `[1/${totalItems}] Alliance sepetine aktarılıyor...`
                    });

                    // 2. AŞAMA (Sıralı Sepet Yazma): ASP.NET Session çakışması ve kalem kaybını %100 önlemek için AddItemToBasket tek tek sıralı gönderilir!
                    const results = [];
                    for (let i = 0; i < preparedList.length; i++) {
                        const p = preparedList[i];
                        const item = p.item;
                        const itemRes = {
                            barcode: item.barcode,
                            name: item.name,
                            miktar: item.miktar,
                            urun_id: String(p.rowId || item.urun_id || ''),
                            success: false,
                            no_stock: !!p.noStock,
                            message: p.failMessage || '',
                            urun_adi: p.urunAdi || item.name,
                            net_fiyat: p.netFiyat || 0,
                            vade: p.vade || 30,
                            toplam_tutar: 0,
                            b64_detail: p.b64Detail || '',
                            offer_b64: p.offerB64 || '',
                            offer_rows: p.offerRows || []
                        };

                        if (!p.ready) {
                            results.push(itemRes);
                            reportStep({
                                type: 'item',
                                index: i,
                                percent: 28 + Math.round(((i + 1) / totalItems) * 64),
                                barcode: itemRes.barcode,
                                name: itemRes.name,
                                urun_adi: itemRes.urun_adi,
                                miktar: itemRes.miktar,
                                urun_id: itemRes.urun_id,
                                success: false,
                                net_fiyat: 0,
                                vade: itemRes.vade || 30,
                                toplam_tutar: 0,
                                message: itemRes.message || 'Eklenemedi'
                            });
                            continue;
                        }

                        try {
                            let addResp = await postAsync('/Sales/AddItemToBasket', {
                                ItemString: p.b64Detail,
                                OfferString: p.offerB64,
                                Quantity: item.miktar,
                                SupplierControlParam: false
                            });
                            if (addResp && !addResp.Result && addResp.ResultUrl === 'SupplierControlParam') {
                                addResp = await postAsync('/Sales/AddItemToBasket', {
                                    ItemString: p.b64Detail,
                                    OfferString: p.offerB64,
                                    Quantity: item.miktar,
                                    SupplierControlParam: true
                                });
                            }

                            if ((!addResp || !addResp.Result) && p.fromCache) {
                                const freshPrep = await buildPreparedFromMeta(resolvedMetas[i], true);
                                if (freshPrep.ready) {
                                    itemRes.urun_id = String(freshPrep.rowId || itemRes.urun_id || '');
                                    itemRes.urun_adi = freshPrep.urunAdi || itemRes.urun_adi;
                                    itemRes.vade = freshPrep.vade || 30;
                                    itemRes.net_fiyat = freshPrep.netFiyat || 0;
                                    itemRes.b64_detail = freshPrep.b64Detail || '';
                                    itemRes.offer_b64 = freshPrep.offerB64 || '';
                                    itemRes.offer_rows = freshPrep.offerRows || [];
                                    addResp = await postAsync('/Sales/AddItemToBasket', {
                                        ItemString: freshPrep.b64Detail,
                                        OfferString: freshPrep.offerB64,
                                        Quantity: item.miktar,
                                        SupplierControlParam: false
                                    });
                                    if (addResp && !addResp.Result && addResp.ResultUrl === 'SupplierControlParam') {
                                        addResp = await postAsync('/Sales/AddItemToBasket', {
                                            ItemString: freshPrep.b64Detail,
                                            OfferString: freshPrep.offerB64,
                                            Quantity: item.miktar,
                                            SupplierControlParam: true
                                        });
                                    }
                                } else {
                                    itemRes.no_stock = !!freshPrep.noStock;
                                    itemRes.message = freshPrep.failMessage || 'Şube satış şartı güncellenemedi';
                                }
                            }

                            if (addResp && addResp.Result) {
                                itemRes.success = true;
                                itemRes.message = 'Alliance sepetine eklendi';
                                itemRes.toplam_tutar = Math.round((itemRes.net_fiyat || 0) * item.miktar * 100) / 100;
                            } else if (!itemRes.message) {
                                itemRes.message = (addResp && addResp.Message) ? addResp.Message : 'Sepete ekleme reddedildi';
                            }
                        } catch (e) {
                            itemRes.message = 'İşlem hatası: ' + e.message;
                        }
                        results.push(itemRes);
                        reportStep({
                            type: 'item',
                            index: i,
                            percent: 28 + Math.round(((i + 1) / totalItems) * 64),
                            barcode: itemRes.barcode,
                            name: itemRes.name,
                            urun_adi: itemRes.urun_adi,
                            miktar: itemRes.miktar,
                            urun_id: itemRes.urun_id,
                            success: !!itemRes.success,
                            net_fiyat: itemRes.net_fiyat || 0,
                            vade: itemRes.vade || 30,
                            toplam_tutar: itemRes.toplam_tutar || 0,
                            message: itemRes.message || ''
                        });
                        await new Promise(r => setTimeout(r, 5));
                    }

                    if (typeof RebindQuickCart === 'function') {
                        try { RebindQuickCart(); } catch(e) {}
                    }

                    return { results, discoveredRows };
                }""", clean_items)

                results = eval_bundle.get("results", []) if isinstance(eval_bundle, dict) else (eval_bundle or [])
                disc_rows = eval_bundle.get("discoveredRows", []) if isinstance(eval_bundle, dict) else []
                item_cache_dirty = False
                for dr in disc_rows:
                    if isinstance(dr, dict) and self._record_item_meta(
                        item_id=str(dr.get("id") or ""),
                        item_string=str(dr.get("itemString") or ""),
                        barcode=str(dr.get("barcode") or ""),
                        name=str(dr.get("name") or ""),
                    ):
                        item_cache_dirty = True
                if item_cache_dirty:
                    self._save_item_cache()

                # Önbelleği tazele
                for r in results:
                    if r.get("success") and r.get("b64_detail") and r.get("offer_b64"):
                        r_uid = str(r.get("urun_id") or "").strip()
                        r_bc = str(r.get("barcode") or "").strip()
                        o_rows = r.get("offer_rows") or []
                        def_off = next((x for x in o_rows if x.get("checked")), o_rows[0]) if o_rows else None
                        ce = {
                            "from_v3": True,
                            "item_id": r_uid,
                            "b64_detail": r["b64_detail"],
                            "offer_b64": def_off["offer_b64"] if def_off else r["offer_b64"],
                            "offer_rows": o_rows,
                            "name": r.get("urun_adi") or r.get("name") or "Ürün",
                            "vade": int((def_off.get("vade") if def_off else None) or r.get("vade") or 30),
                            "net_fiyat": float((def_off.get("net_fiyat") if def_off else None) or r.get("net_fiyat") or 0.0),
                            "has_stock": True
                        }
                        if r_uid:
                            self._fast_cart_cache[r_uid] = ce
                        if r_bc:
                            self._fast_cart_cache[r_bc] = ce

                # 3. AŞAMA (Canlı Sepet Doğrulaması + Düşen Kalem İçin 1 Kez Sıralı Otomatik Tekrar):
                # "17 kalem eklendi görünüp sepette 15 kalem çıkması" sorununu kesin olarak engeller!
                def _norm_tr(s: str) -> str:
                    tr_m = str.maketrans("İIıŞşĞğÜüÖöÇç", "iiissgguuoocc")
                    return re.sub(r"[^a-z0-9]+", " ", str(s or "").translate(tr_m).lower()).strip()

                def _match_alliance_row(r_item: Dict[str, Any], c_items: List[Dict[str, Any]], used_idx: set) -> Optional[Dict[str, Any]]:
                    r_uid = str(r_item.get("urun_id") or "").strip().lstrip("0")
                    r_bc = str(r_item.get("barcode") or "").strip().lstrip("0")
                    # 1. Kesin ID eşleşmesi
                    for idx_c, ci in enumerate(c_items):
                        if idx_c in used_idx:
                            continue
                        ci_kod = str(ci.get("kod") or ci.get("id") or "").strip().lstrip("0")
                        if r_uid and ci_kod and r_uid == ci_kod:
                            used_idx.add(idx_c)
                            return ci
                        if r_bc and ci_kod and r_bc == ci_kod:
                            used_idx.add(idx_c)
                            return ci
                    # 2. Tam normalize isim / token eşleşmesi (her sepet satırı yalnızca 1 kez eşleşebilir!)
                    r_nm = _norm_tr(r_item.get("urun_adi") or r_item.get("name") or "")
                    if not r_nm:
                        return None
                    r_tokens = [w for w in r_nm.split() if len(w) >= 2]
                    r_nums = {w for w in r_nm.split() if w.isdigit()}
                    for idx_c, ci in enumerate(c_items):
                        if idx_c in used_idx:
                            continue
                        ci_nm = _norm_tr(ci.get("ad") or "")
                        if not ci_nm:
                            continue
                        if r_nm == ci_nm or (len(r_nm) >= 6 and (r_nm in ci_nm or ci_nm in r_nm)):
                            used_idx.add(idx_c)
                            return ci
                        ci_tokens = [w for w in ci_nm.split() if len(w) >= 2]
                        ci_nums = {w for w in ci_nm.split() if w.isdigit()}
                        if r_tokens and ci_tokens and r_tokens[0] == ci_tokens[0]:
                            if r_nums and ci_nums and not r_nums.intersection(ci_nums):
                                continue
                            common = set(r_tokens).intersection(set(ci_tokens))
                            if len(common) >= min(2, len(r_tokens), len(ci_tokens)):
                                used_idx.add(idx_c)
                                return ci
                    return None

                _emit({
                    "type": "phase",
                    "phase": "verifying",
                    "percent": 95,
                    "ceiling": 99,
                    "status_text": "Alliance sepeti doğrulanıyor ve tutar kontrol ediliyor...",
                })
                live_total = 0.0
                try:
                    live_cart = await self._get_cart_status_unlocked()
                    live_items = live_cart.get("items", []) or []
                    used_indices: set = set()
                    missing_for_retry = []
                    for r in results:
                        m_ci = _match_alliance_row(r, live_items, used_indices)
                        if m_ci:
                            r["_verified_ci"] = m_ci
                        elif r.get("success") or (not r.get("no_stock") and "stokta yok" not in str(r.get("message") or "").lower() and "bulunamadı" not in str(r.get("message") or "").lower()):
                            missing_for_retry.append(r)

                    if missing_for_retry:
                        retried_ok = False
                        for r in missing_for_retry:
                            try:
                                retry_res = await self._add_to_cart_unlocked(
                                    urun_id=str(r.get("urun_id") or r.get("barcode") or r.get("name") or ""),
                                    miktar=int(r.get("miktar") or 1),
                                    barkod=str(r.get("barcode") or ""),
                                    name=str(r.get("name") or "")
                                )
                                if retry_res.get("urun_id"):
                                    r["urun_id"] = str(retry_res.get("urun_id")).strip()
                                if retry_res.get("success"):
                                    r["success"] = True
                                    r["urun_adi"] = retry_res.get("urun_adi") or r.get("urun_adi") or r.get("name")
                                    retried_ok = True
                                else:
                                    r["message"] = retry_res.get("message") or r.get("message") or "Alliance sepete ekleme reddedildi."
                            except Exception:
                                pass
                        if retried_ok or missing_for_retry:
                            live_cart = await self._get_cart_status_unlocked()
                            live_items = live_cart.get("items", []) or []

                    used_final: set = set()
                    for r in results:
                        r.pop("_verified_ci", None)
                        r.pop("b64_detail", None)
                        r.pop("offer_b64", None)
                        r.pop("offer_rows", None)
                        m_ci = _match_alliance_row(r, live_items, used_final)
                        if m_ci:
                            r["success"] = True
                            if m_ci.get("kod"):
                                r["urun_id"] = str(m_ci.get("kod")).strip()
                            if m_ci.get("ad"):
                                r["urun_adi"] = m_ci.get("ad")
                            if m_ci.get("birim_fiyat"):
                                r["net_fiyat"] = float(m_ci.get("birim_fiyat") or r.get("net_fiyat") or 0.0)
                            if m_ci.get("tutar"):
                                r["toplam_tutar"] = float(m_ci.get("tutar") or r.get("toplam_tutar") or 0.0)
                        elif r.get("success") and live_cart.get("success") and not live_cart.get("timeout"):
                            r["success"] = False
                            r["toplam_tutar"] = 0.0
                            r["message"] = "Alliance canlı sepet doğrulamasında ürün sepette görülmedi (Kota/Tevzi/Şube stok kısıtı olabilir)."

                    live_total = float(live_cart.get("total_amount") or 0.0)
                except Exception:
                    for r in results:
                        r.pop("_verified_ci", None)
                        r.pop("b64_detail", None)
                        r.pop("offer_b64", None)
                        r.pop("offer_rows", None)

                success_items = [r for r in results if r.get("success")]
                failed_items = [r for r in results if not r.get("success")]
                calc_total = round(sum(float(r.get("toplam_tutar") or 0.0) for r in success_items), 2)
                total_amount = round(live_total, 2) if live_total > 0 else calc_total
                if success_items:
                    self._merge_last_added_items([
                        {
                            "id": r.get("urun_id") or r.get("barcode") or "",
                            "kod": r.get("urun_id") or "",
                            "urun_id": r.get("urun_id") or "",
                            "barcode": r.get("barcode") or "",
                            "ad": r.get("urun_adi") or r.get("name") or "",
                            "name": r.get("urun_adi") or r.get("name") or "",
                            "miktar": int(r.get("miktar") or 1),
                            "mf": "0",
                            "birim_fiyat": float(r.get("net_fiyat") or 0.0),
                            "tutar": float(r.get("toplam_tutar") or 0.0)
                        }
                        for r in success_items
                    ])

                return {
                    "success": len(success_items) > 0,
                    "depo": "ALLIANCE",
                    "message": f"Alliance sepetine {len(success_items)}/{len(items)} kalem ürün doğrulamalı olarak eklendi (Toplam: {total_amount:,.2f} ₺).",
                    "total_items": len(items),
                    "success_count": len(success_items),
                    "failed_count": len(failed_items),
                    "total_amount": total_amount,
                    "items": results
                }
        finally:
            self._active_bulk_progress_cb = None
            self._cart_busy = max(0, self._cart_busy - 1)

    def get_portal_urls(self) -> dict:
        """Alliance Healthcare sepet ve sipariş web arayüzü linklerini döndürür."""
        return {
            "cart_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart",
            "checkout_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart"
        }

    async def _get_cart_status_unlocked(self) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        parsed = await self._page.evaluate("""async () => {
            function parseTrFloat(raw) {
                if (!raw) return 0.0;
                const cl = String(raw).replace(/[^0-9.,-]/g, '').replace(/\\./g, '').replace(',', '.').trim();
                return parseFloat(cl) || 0.0;
            }

            function parseCartHtml(html) {
                if (!html || typeof html !== 'string') {
                    return { item_count: 0, total_amount: 0.0, declared_count: 0, items: [] };
                }
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = html;
                const rows = tempDiv.querySelectorAll('table.tbl-cart tr, table tr');
                const items = [];
                const seenKeys = new Set();

                rows.forEach(tr => {
                    const chk = tr.querySelector('input[data-basketitem], input[data-itemid], [data-basketitem]');
                    if (!chk) return;
                    const basketId = chk.getAttribute('data-basketitem') || '';
                    const itemId = chk.getAttribute('data-itemid') || '';
                    const dedup = basketId || itemId;
                    if (dedup && seenKeys.has(dedup)) return;
                    const tds = tr.querySelectorAll('td');
                    if (tds.length < 6) return;

                    let name = (tds[1]?.innerText || '').trim();
                    if (!name || /^\\d+$/.test(name)) {
                        const altLink = tr.querySelector('a[onclick*="Item"], td:nth-child(3), .item-name, .product-name');
                        if (altLink && (altLink.innerText || '').trim().length > 2) {
                            name = (altLink.innerText || '').trim();
                        }
                    }

                    let qty = 1;
                    const qtyInp = tr.querySelector('input[type="number"], input.qty, input[name*="Quantity"], input[id*="qty"], input[onchange*="Basket"]');
                    if (qtyInp && qtyInp.value) {
                        qty = parseInt(String(qtyInp.value).trim(), 10) || 1;
                    } else if (tds[5]) {
                        const td5Inp = tds[5].querySelector('input');
                        qty = parseInt((td5Inp ? td5Inp.value : tds[5].innerText || '1').trim(), 10) || 1;
                    }

                    const mf = (tds[6]?.innerText || '0').trim();
                    let unitPrice = 0.0;
                    let total = 0.0;
                    if (tds.length >= 12) {
                        unitPrice = parseTrFloat(tds[10]?.innerText || tds[9]?.innerText || '0');
                        total = parseTrFloat(tds[11]?.innerText || '0') || (qty * unitPrice);
                    } else {
                        unitPrice = parseTrFloat(tds[tds.length - 2]?.innerText || '0');
                        total = parseTrFloat(tds[tds.length - 1]?.innerText || '0') || (qty * unitPrice);
                    }

                    if (dedup) seenKeys.add(dedup);
                    items.push({
                        id: basketId,
                        kod: itemId,
                        ad: name,
                        miktar: qty,
                        mf: mf,
                        birim_fiyat: unitPrice,
                        tutar: total
                    });
                });

                const topText = tempDiv.innerText || '';
                let topTutar = 0.0;
                const match = topText.match(/Toplam[^\\d]{0,15}([\\d.,]+)\\s*TL/i) || topText.match(/Genel\\s*Toplam[^\\d]{0,15}([\\d.,]+)/i);
                if (match) {
                    topTutar = parseTrFloat(match[1]);
                }
                const sumItems = items.reduce((acc, it) => acc + (it.tutar || 0), 0);
                if (!topTutar || (sumItems > topTutar * 1.05)) {
                    topTutar = sumItems;
                }

                let declaredCount = 0;
                const cntMatch = topText.match(/(\\d+)\\s*(?:Kalem|Ürün|Çeşit)/i);
                if (cntMatch) {
                    declaredCount = parseInt(cntMatch[1], 10) || 0;
                }

                return {
                    item_count: items.length,
                    declared_count: declaredCount,
                    sum_items: sumItems,
                    total_amount: topTutar,
                    items: items
                };
            }

            function fetchAjaxHtml(url, method = 'POST', timeoutMs = 6500) {
                return new Promise((resolve) => {
                    let done = false;
                    const timer = setTimeout(() => { if (!done) { done = true; resolve(''); } }, timeoutMs);
                    try {
                        if (typeof $ !== 'undefined' && $.ajax) {
                            $.ajax({
                                url: url,
                                type: method,
                                data: {},
                                timeout: timeoutMs,
                                success: (h) => { if (!done) { done = true; clearTimeout(timer); resolve(typeof h === 'string' ? h : ''); } },
                                error: () => { if (!done) { done = true; clearTimeout(timer); resolve(''); } }
                            });
                            return;
                        }
                        fetch(url, { method: method, credentials: 'same-origin' })
                            .then(r => r.text())
                            .then(h => { if (!done) { done = true; clearTimeout(timer); resolve(h || ''); } })
                            .catch(() => { if (!done) { done = true; clearTimeout(timer); resolve(''); } });
                    } catch (_e) {
                        if (!done) { done = true; clearTimeout(timer); resolve(''); }
                    }
                });
            }

            const quickHtml = await fetchAjaxHtml('/Home/QuickCart', 'POST', 6000);
            const quickParsed = parseCartHtml(quickHtml);

            // ÖNEMLİ: QuickCart mini-dropdown 10-15 kalemde satır sınırına takılabilir veya toplam tutar > satır toplamı kalabilir!
            // Böyle bir durumda tam sepet sayfası (/Sales/Cart) HTML'ini de çekerek 17, 30, 50+ kalemin tamamını eksiksiz oku!
            let domBadgeCount = 0;
            try {
                const badgeEl = document.querySelector('#spanBasketCount, #basketItemCount, .basket-count, .cart-count');
                if (badgeEl) domBadgeCount = parseInt((badgeEl.innerText || '').replace(/\\D/g, ''), 10) || 0;
            } catch (_e) {}

            const sumDiff = Math.abs((quickParsed.total_amount || 0) - (quickParsed.sum_items || 0));
            const mayBeTruncated = (
                quickParsed.items.length >= 10 ||
                (quickParsed.declared_count > quickParsed.items.length) ||
                (domBadgeCount > quickParsed.items.length) ||
                (quickParsed.total_amount > 0 && sumDiff > 2.0)
            );

            if (mayBeTruncated) {
                const fullCartHtml = await fetchAjaxHtml('/Sales/Cart', 'GET', 6500);
                const fullParsed = parseCartHtml(fullCartHtml);
                if (fullParsed.items.length > quickParsed.items.length) {
                    if (!fullParsed.total_amount && quickParsed.total_amount) {
                        fullParsed.total_amount = quickParsed.total_amount;
                    }
                    return fullParsed;
                }
            }

            return quickParsed;
        }""")

        items = parsed.get("items", [])
        total_amount = float(parsed.get("total_amount") or 0.0)

        return {
            "success": True,
            "depo": "ALLIANCE",
            "depo_adi": self.depo_adi,
            "supported": True,
            "item_count": len(items),
            "total_amount": round(total_amount, 2),
            "items": items,
            "cart_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart",
            "checkout_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart"
        }

    async def get_cart_status(self) -> Dict[str, Any]:
        """Alliance Healthcare sepetinin anlık içeriğini ve toplam tutarını sorgular."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._get_cart_status_unlocked()
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def clear_cart(self) -> Dict[str, Any]:
        """Alliance Healthcare sepetindeki tüm ürünleri temizler."""
        self._cart_busy += 1
        try:
            async with self._lock:
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()
                await self._ensure_ready_page()

                res = await self._page.evaluate("""async () => {
                    return new Promise((resolve) => {
                        let done = false;
                        const timer = setTimeout(() => {
                            if (!done) { done = true; resolve({ success: false, message: "Alliance sepet temizleme zaman aşımı." }); }
                        }, 6500);
                        const finish = (resp) => {
                            if (done) return;
                            done = true;
                            clearTimeout(timer);
                            if (resp && resp.Result) {
                                if (typeof RebindQuickCart === 'function') {
                                    try { RebindQuickCart(); } catch(e) {}
                                }
                                resolve({ success: true, message: "Alliance sepeti başarıyla temizlendi." });
                            } else {
                                resolve({ success: false, message: (resp && resp.Message) || "Sepet temizlenemedi." });
                            }
                        };
                        try {
                            if (typeof $ !== 'undefined' && $.ajax) {
                                $.ajax({
                                    url: "/Sales/RemoveBasketItems",
                                    type: "POST",
                                    data: { Clear: true, BasketItemStrings: [] },
                                    timeout: 6500,
                                    success: finish,
                                    error: () => finish(null)
                                });
                                return;
                            }
                            const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                            if (typeof postFn !== 'function') {
                                finish(null);
                                return;
                            }
                            postFn("/Sales/RemoveBasketItems", { Clear: true, BasketItemStrings: [] }, finish);
                        } catch (e) {
                            finish(null);
                        }
                    });
                }""")
                self._last_added_items = []
                self._last_added_time = 0.0
                return res
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def finalize_order(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        """Tekli veya toplu siparişi Alliance sepetine ekler ve depoya iletir."""
        self._cart_busy += 1
        try:
            async with self._lock:
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()
                await self._ensure_ready_page()

                cart_status = await self._get_cart_status_unlocked()
                existing_items = cart_status.get("items", [])

                if urun_id:
                    u_clean = str(urun_id).strip()
                    already_in_cart = any(it.get("kod") == u_clean or it.get("id") == u_clean for it in existing_items)
                    if not already_in_cart:
                        added_res = await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
                        if not added_res.get("success"):
                            return {
                                "success": False,
                                "message": f"Ürün sepete eklenemediği için sipariş sonlandırılamadı: {added_res.get('message')}"
                            }
                        cart_status = await self._get_cart_status_unlocked()
                        existing_items = cart_status.get("items", [])

                pre_count = len(existing_items)
                if not existing_items:
                    return {"success": False, "message": "Alliance sepetinde siparişe dönüştürülecek ürün bulunamadı."}

                if len(existing_items) > 1 and not force:
                    return {
                        "success": False,
                        "need_confirmation": True,
                        "item_count": len(existing_items),
                        "items": existing_items,
                        "total_amount": cart_status.get("total_amount", 0.0),
                        "message": f"Alliance Healthcare sepetinizde önceden eklenmiş {len(existing_items)} farklı ürün bulunmaktadır (Toplam: {cart_status.get('total_amount', 0.0):,.2f} ₺). Tüm sepeti depoya göndermek için onay veriniz."
                    }

                # Alliance sepet sayfasına git (SubmitBasketRequest ve sipariş gönderme bu sayfada tanımlıdır)
                if "sales/cart" not in (self._page.url or "").lower():
                    try:
                        await self._page.goto("https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart", wait_until="domcontentloaded", timeout=10000)
                    except Exception:
                        pass

                # Alliance siparişini onayla (Çift aşamalı BasketToSalesOrder + ErrorAlert/Result ters mantık korumalı)
                res = {"success": False, "message": "Sipariş onaylanamadı."}
                try:
                    res = await self._page.evaluate("""async () => {
                        return new Promise((resolve) => {
                            let done = false;
                            const finish = (val) => {
                                if (done) return;
                                done = true;
                                clearTimeout(timer);
                                resolve(val);
                            };
                            const timer = setTimeout(() => {
                                finish({ success: false, timeout: true, message: "Zaman aşımı" });
                            }, 16000);

                            const extractOrderConfirmation = (htmlStr) => {
                                if (typeof htmlStr !== 'string') return null;
                                const mNo = htmlStr.match(/<b>\\s*(\\d+)\\s*<\\/b>\\s*numaral[ıi]\\s*sipari[şs]/i)
                                         || htmlStr.match(/(\\d{4,})\\s*numaral[ıi]\\s*sipari[şs]/i);
                                const orderNo = (mNo && mNo[1]) ? mNo[1] : '';
                                const lower = htmlStr.toLowerCase();
                                const isConfirmed = Boolean(
                                    orderNo
                                    || lower.includes('sipariş detay')
                                    || lower.includes('siparis detay')
                                    || lower.includes('order-detail')
                                    || lower.includes('/sales/orderdetail')
                                    || /numaral[ıi]\\s*sipari[şs]/i.test(htmlStr)
                                    || /sipari[şs]iniz\\s*(ba[şs]ar[ıi]yla\\s*)?(al[ıi]nm[ıi][şs]t[ıi]r|olu[şs]turulmu[şs]tur|iletilmi[şs]tir)/i.test(htmlStr)
                                );
                                if (!isConfirmed) return null;
                                return {
                                    success: true,
                                    order_confirmed: true,
                                    order_no: orderNo,
                                    message: `Alliance siparişi başarıyla depoya iletildi.${orderNo ? ' (Sipariş No: ' + orderNo + ')' : ''}`
                                };
                            };

                            const extractModalWarningText = (htmlStr) => {
                                try {
                                    const temp = document.createElement('div');
                                    temp.innerHTML = htmlStr || '';
                                    temp.querySelectorAll('script, style, button, a.btn').forEach(el => el.remove());
                                    const sel = temp.querySelector('.alert-danger, .alert-warning, .validation-summary-errors, .error, .modal-body, .modal-v2inner');
                                    const raw = ((sel ? sel.innerText : temp.innerText) || '').replace(/\\s+/g, ' ').trim();
                                    return raw.slice(0, 280);
                                } catch (e) {
                                    return '';
                                }
                            };

                            // Alliance sepet formundaki gerçek parametreleri (ShippingMethods, Note, Clone, IsDuty) topla
                            const collectFormParams = () => {
                                const isCartPage = window.location.href.toLowerCase().includes('/sales/cart');
                                const baseArea = isCartPage ? '.cartpage' : '#right-cart';
                                const noteEl = document.querySelector(`${baseArea} #orderNote`) || document.querySelector('#orderNote');
                                const cloneEl = document.querySelector(`${baseArea} #cloneAfterAfterProcessing`) || document.querySelector('#cloneAfterAfterProcessing');
                                const dutyEl = document.querySelector(`${baseArea} #ImDuty`) || document.querySelector('#ImDuty');
                                const selects = Array.from(document.querySelectorAll(`${baseArea} select[name=OrderPriority], select[name=OrderPriority]`));
                                const seen = new Set();
                                const parts = [];
                                for (const s of selects) {
                                    const val = (s.value || '').trim();
                                    const wh = (s.getAttribute('data-warehouseid') || s.dataset?.warehouseid || '').trim();
                                    const token = (wh && val && !val.includes(':')) ? `${wh}:${val}` : val;
                                    if (token && !seen.has(token)) {
                                        seen.add(token);
                                        parts.push(token);
                                    }
                                }
                                return {
                                    shippingMethods: parts.join(','),
                                    note: noteEl ? (noteEl.value || '') : '',
                                    cloneAfter: Boolean(cloneEl && cloneEl.checked),
                                    isDuty: Boolean(dutyEl && dutyEl.checked)
                                };
                            };

                            let formParams = collectFormParams();

                            const handleStep2Response = (resp2) => {
                                try {
                                    if (typeof resp2 === 'string') {
                                        const conf2 = extractOrderConfirmation(resp2);
                                        if (conf2) {
                                            finish(conf2);
                                            return;
                                        }
                                        const warn2 = extractModalWarningText(resp2);
                                        finish({
                                            success: false,
                                            needs_cart_check: true,
                                            message: warn2 || "Alliance 2. aşama sipariş onayı tamamlanamadı."
                                        });
                                        return;
                                    }
                                    // Alliance BasketToSalesOrder: n.Result === true => ErrorAlert(n.Message)!
                                    if (resp2 && resp2.Result) {
                                        finish({
                                            success: false,
                                            explicit_error: true,
                                            message: resp2.Message || "Alliance siparişi reddetti (Depo kısıtı / minimum tutar uyarısı)."
                                        });
                                        return;
                                    }
                                    if (resp2 && resp2.Result === false) {
                                        finish({
                                            success: true,
                                            needs_cart_check: true,
                                            message: resp2.Message || "Alliance siparişi işleme alındı."
                                        });
                                        return;
                                    }
                                    finish({
                                        success: false,
                                        needs_cart_check: true,
                                        message: (resp2 && resp2.Message) || "Alliance sipariş yanıtı doğrulanamadı."
                                    });
                                } catch (e2) {
                                    finish({ success: false, message: "2. aşama yanıt hatası: " + e2.toString() });
                                }
                            };

                            const handleStep1Response = (resp) => {
                                try {
                                    // DİKKAT: Alliance SubmitBasketRequest içinde `n.Result == undefined` HTML modal demektir;
                                    // `n.Result !== undefined` (özellikle `n.Result === true`) ise DOĞRUDAN ErrorAlert(n.Message) hatasıdır!
                                    if (typeof resp === 'string') {
                                        const conf1 = extractOrderConfirmation(resp);
                                        if (conf1) {
                                            finish(conf1);
                                            return;
                                        }
                                        // Eğer 2. aşama onay modalı (BasketToSalesOrder) geldiyse otomatik olarak 2. adımı çağır
                                        if (resp.includes('BasketToSalesOrder') && typeof AjaxPost === 'function') {
                                            AjaxPost(
                                                '/Sales/BasketToSalesOrder',
                                                {
                                                    Note: formParams.note,
                                                    IsDuty: formParams.isDuty,
                                                    CloneAfterAfterProcessing: formParams.cloneAfter,
                                                    ShippingMethods: formParams.shippingMethods
                                                },
                                                handleStep2Response
                                            );
                                            return;
                                        }
                                        const warnText = extractModalWarningText(resp);
                                        finish({
                                            success: false,
                                            needs_cart_check: true,
                                            message: warnText || "Alliance sepet onayı tamamlanmadı (Minimum tutar veya depo uyarısını kontrol ediniz)."
                                        });
                                        return;
                                    }
                                    if (resp && typeof resp === 'object') {
                                        finish({
                                            success: false,
                                            explicit_error: true,
                                            message: resp.Message || "Alliance siparişi onaylanamadı (Depo uyarısı)."
                                        });
                                        return;
                                    }
                                    finish({ success: false, needs_cart_check: true, message: "Sipariş onaylanamadı." });
                                } catch (e) {
                                    finish({ success: false, message: "Sipariş yanıtı işlenirken hata oluştu: " + e.toString() });
                                }
                            };

                            // Sayfanın kendi SumbitBasket() fonksiyonu varsa ShippingMethods argümanını birebir ondan yakala
                            if (typeof SumbitBasket === 'function' && typeof AjaxPost === 'function') {
                                const origSubmitReq = window.SubmitBasketRequest;
                                const origErrorAlert = window.ErrorAlert;
                                let intercepted = false;
                                try {
                                    window.ErrorAlert = function(msg) {
                                        if (!intercepted) {
                                            intercepted = true;
                                            window.SubmitBasketRequest = origSubmitReq;
                                            window.ErrorAlert = origErrorAlert;
                                            finish({ success: false, explicit_error: true, message: String(msg || 'Alliance sepet uyarısı') });
                                        }
                                    };
                                    window.SubmitBasketRequest = function(shipStr, noteVal, cloneVal, dutyVal) {
                                        intercepted = true;
                                        window.SubmitBasketRequest = origSubmitReq;
                                        window.ErrorAlert = origErrorAlert;
                                        formParams = {
                                            shippingMethods: (shipStr != null ? String(shipStr) : formParams.shippingMethods),
                                            note: (noteVal != null ? String(noteVal) : formParams.note),
                                            cloneAfter: Boolean(cloneVal),
                                            isDuty: Boolean(dutyVal)
                                        };
                                        AjaxPost(
                                            '/Sales/SubmitBasket',
                                            {
                                                Note: formParams.note,
                                                IsDuty: formParams.isDuty,
                                                CloneAfterAfterProcessing: formParams.cloneAfter,
                                                ShippingMethods: formParams.shippingMethods
                                            },
                                            handleStep1Response
                                        );
                                    };
                                    SumbitBasket();
                                    if (!intercepted) {
                                        window.SubmitBasketRequest = origSubmitReq;
                                        window.ErrorAlert = origErrorAlert;
                                        AjaxPost(
                                            '/Sales/SubmitBasket',
                                            {
                                                Note: formParams.note,
                                                IsDuty: formParams.isDuty,
                                                CloneAfterAfterProcessing: formParams.cloneAfter,
                                                ShippingMethods: formParams.shippingMethods
                                            },
                                            handleStep1Response
                                        );
                                    }
                                } catch (e) {
                                    window.SubmitBasketRequest = origSubmitReq;
                                    window.ErrorAlert = origErrorAlert;
                                    finish({ success: false, message: "Sipariş gönderme hatası: " + e.toString() });
                                }
                            } else if (typeof AjaxPost === 'function') {
                                AjaxPost(
                                    '/Sales/SubmitBasket',
                                    {
                                        Note: formParams.note,
                                        IsDuty: formParams.isDuty,
                                        CloneAfterAfterProcessing: formParams.cloneAfter,
                                        ShippingMethods: formParams.shippingMethods
                                    },
                                    handleStep1Response
                                );
                            } else if (typeof SubmitBasketRequest === 'function') {
                                SubmitBasketRequest(
                                    formParams.shippingMethods,
                                    formParams.note,
                                    formParams.cloneAfter,
                                    formParams.isDuty,
                                    handleStep1Response
                                );
                            } else {
                                const btn = document.querySelector('#btnSubmitBasket, .btn-submit-basket, button[onclick*="SubmitBasket"], button[onclick*="SumbitBasket"]');
                                if (btn) {
                                    btn.click();
                                    finish({ success: false, needs_cart_check: true, message: "Alliance sipariş butonu tetiklendi, sepet kontrol ediliyor..." });
                                } else {
                                    finish({ success: false, message: "SubmitBasketRequest fonksiyonu bulunamadı." });
                                }
                            }
                        });
                    }""")
                except Exception as nav_err:
                    print(f"[Alliance] Finalize evaluate/navigation: {nav_err}")

                # Her durumda ana sayfaya dön ve canlı sepetin gerçekten boşaldığını ZORUNLU doğrula!
                # (Ürünler hala sepette duruyorsa ASLA success=True döndürme!)
                try:
                    await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=8000)
                except Exception:
                    pass

                if pre_count > 0:
                    last_post_cart = None
                    for wait_s in (0.5, 0.9, 1.3):
                        try:
                            await asyncio.sleep(wait_s)
                            post_cart = await self._get_cart_status_unlocked()
                            if post_cart.get("success"):
                                last_post_cart = post_cart
                                if post_cart.get("item_count", -1) == 0:
                                    if not res.get("success"):
                                        res = {
                                            "success": True,
                                            "depo": "ALLIANCE",
                                            "message": "Alliance Healthcare siparişiniz başarıyla depoya iletildi ve sepet onaylandı!"
                                        }
                                    break
                                # Eğer açık bir hata (ErrorAlert / Result:true) döndüyse ilk kontrolde hemen çık
                                if res.get("explicit_error"):
                                    break
                        except Exception:
                            pass

                    # KRİTİK GÜVENLİK KİLİDİ: Sepette hala ürün varsa sipariş depoya DÜŞMEMİŞTİR!
                    if last_post_cart and last_post_cart.get("item_count", 0) > 0:
                        rem_cnt = last_post_cart.get("item_count", 0)
                        raw_msg = (res.get("message") or "").strip()
                        if (
                            not raw_msg
                            or "başarıyla" in raw_msg.lower()
                            or "iletildi" in raw_msg.lower()
                            or "işleme" in raw_msg.lower()
                            or "tetiklendi" in raw_msg.lower()
                        ):
                            raw_msg = "Minimum sepet tutarı veya depo onay kısıtı nedeniyle sipariş tamamlanmadı."
                        res = {
                            "success": False,
                            "depo": "ALLIANCE",
                            "remaining_count": rem_cnt,
                            "cart_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart",
                            "message": f"Alliance siparişi depoya DÜŞMEDİ ({raw_msg}) — Ürünler hala Alliance sepetinde bekliyor ({rem_cnt} kalem)!"
                        }

                if res.get("success"):
                    self._last_added_items = []
                    self._last_added_time = 0.0

                return res
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)




    async def close(self):
        if self._http_client and not self._http_client.is_closed:
            try:
                await self._http_client.aclose()
            except Exception:
                pass
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
