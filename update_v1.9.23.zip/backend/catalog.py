import re
import sqlite3
import unicodedata
from pathlib import Path
from typing import List, Dict, Optional, Any, Set
from collections import defaultdict
import openpyxl

DATA_DIR = Path(__file__).resolve().parent / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "products.db"
EXCEL_PATH = DATA_DIR / "WEBLISTE.xlsx"

def normalize_text(text: str) -> str:
    """Türkçe karakterleri normalize eder ve küçük harfe çevirir."""
    if not text:
        return ""
    text = text.strip()
    tr_map = {
        'İ': 'i', 'I': 'i', 'ı': 'i',
        'Ş': 's', 'ş': 's',
        'Ğ': 'g', 'ğ': 'g',
        'Ü': 'u', 'ü': 'u',
        'Ö': 'o', 'ö': 'o',
        'Ç': 'c', 'ç': 'c'
    }
    for k, v in tr_map.items():
        text = text.replace(k, v)
    return re.sub(r'\s+', ' ', text.lower())

KNOWN_BARCODE_NAME_FIXES: Dict[str, str] = {
    "8699956513676": "BIODERMA ATODERM CREAM ULTRA 500 ML KAMPANYALI",
}

def clean_catalog_product_name(name: str, barcode: str = "") -> str:
    """Bilinen katalog yazım hatalarını (örn. ATODERRM -> ATODERM) ve fazla boşlukları temizler."""
    bc = str(barcode or "").strip()
    if bc in KNOWN_BARCODE_NAME_FIXES:
        return KNOWN_BARCODE_NAME_FIXES[bc]
    s = re.sub(r'\s+', ' ', str(name or '').strip())
    if "ATODERRM" in s.upper():
        s = re.sub(r'(?i)ATODERRM', 'ATODERM', s)
    return s

def detect_brand(name: str) -> str:
    """Ürün isminden tanınmış dermokozmetik veya OTC markasını çıkarır."""
    if not name:
        return "Genel"
    n_up = name.upper()
    brand_keywords = [
        ("LA ROCHE", "La Roche Posay"),
        ("LRP ", "La Roche Posay"),
        ("BIODERMA", "Bioderma"),
        ("CERAVE", "CeraVe"),
        ("AVENE", "Avene"),
        ("VICHY", "Vichy"),
        ("BEPANTHOL", "Bepanthol"),
        ("SOLGAR", "Solgar"),
        ("OCEAN", "Orzax Ocean"),
        ("ORZAX", "Orzax Ocean"),
        ("VENATURA", "Venatura"),
        ("DUCRAY", "Ducray"),
        ("SVR", "SVR"),
        ("DARPHIN", "Darphin"),
        ("MUSTELA", "Mustela"),
        ("SEBAMED", "Sebamed"),
        ("NUXE", "Nuxe"),
        ("SKINCEUTICALS", "SkinCeuticals"),
        ("BABE", "Babe"),
        ("URIAGE", "Uriage"),
        ("BIONIKE", "Bionike"),
        ("SUPRADYN", "Supradyn"),
        ("PHARMATON", "Pharmaton"),
        ("NEW LIFE", "New Life"),
        ("NATURES SUPREME", "Nature's Supreme"),
        ("ZADEN", "Zaden"),
        ("LIPOSOMAL", "Liposomal"),
        ("NIVEA", "Nivea"),
        ("DERCOS", "Vichy Dercos"),
        ("MINERAL 89", "Vichy"),
    ]
    for kw, brand in brand_keywords:
        if kw in n_up:
            return brand
    first_token = name.split()[0] if name.split() else "Genel"
    return first_token.capitalize() if len(first_token) > 2 else "Genel"

class ProductCatalog:
    def __init__(self):
        self.db_path = DB_PATH
        self._suggest_cache = {}
        self._ensure_db()

    def _get_connection(self):
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous = NORMAL;")
        conn.execute("PRAGMA cache_size = -64000;")
        conn.execute("PRAGMA temp_store = MEMORY;")
        conn.execute("PRAGMA mmap_size = 268435456;")
        return conn

    def _ensure_db(self):
        with self._get_connection() as conn:
            # 1. Ana Ürünler Tablosu (Tekil Ürünler - WEBLISTE ve TRIA MAL_TANIM gibi)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    code TEXT,
                    name TEXT,
                    name_normalized TEXT,
                    manufacturer TEXT,
                    price REAL,
                    depo_price REAL,
                    vat REAL,
                    primary_barcode TEXT,
                    institution_discount REAL DEFAULT 0.0,
                    profit_rate REAL DEFAULT 0.0,
                    source TEXT DEFAULT 'WEBLISTE',
                    in_pharmacy_db INTEGER DEFAULT 0,
                    pharmacy_stock INTEGER DEFAULT 0,
                    pharmacy_source TEXT DEFAULT ''
                )
            """)

            # Mevcut veritabanları için yeni sütun migrasyonları
            existing_cols = {row[1] for row in conn.execute("PRAGMA table_info(products)").fetchall()}
            if "in_pharmacy_db" not in existing_cols:
                conn.execute("ALTER TABLE products ADD COLUMN in_pharmacy_db INTEGER DEFAULT 0")
            if "pharmacy_stock" not in existing_cols:
                conn.execute("ALTER TABLE products ADD COLUMN pharmacy_stock INTEGER DEFAULT 0")
            if "pharmacy_source" not in existing_cols:
                conn.execute("ALTER TABLE products ADD COLUMN pharmacy_source TEXT DEFAULT ''")

            # Yanlışlıkla tüm 155.000 ham BOTANIK satırına verilen toplu 1 puanını temizle;
            # Sadece gerçekten çoklu barkodu birleştirilmiş (eczanede işlem görmüş) veya stoğu olan geçerli EAN kartlarını önceliklendir
            conn.execute("""
                UPDATE products
                SET in_pharmacy_db = 0
                WHERE in_pharmacy_db = 1 AND pharmacy_stock <= 0
            """)
            conn.execute("""
                UPDATE products
                SET in_pharmacy_db = 2,
                    pharmacy_source = CASE WHEN pharmacy_source = '' AND source IN ('TRIA', 'BOTANIK', 'TEBEOS', 'ECZANEM') THEN source ELSE pharmacy_source END
                WHERE (
                    pharmacy_stock > 0
                    OR id IN (
                        SELECT product_id FROM product_barcodes GROUP BY product_id HAVING COUNT(*) > 1
                    )
                )
                AND primary_barcode GLOB '[0-9]*'
                AND length(primary_barcode) BETWEEN 8 AND 14
                AND primary_barcode NOT GLOB '9999*'
                AND price >= 15.0
            """)

            # 2. Çoklu Barkod Tablosu (1 Ürün -> N Barkod)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS product_barcodes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER,
                    barcode TEXT UNIQUE,
                    is_primary INTEGER DEFAULT 0,
                    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
                )
            """)

            conn.execute("CREATE INDEX IF NOT EXISTS idx_prod_name_norm ON products(name_normalized)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_prod_primary_barcode ON products(primary_barcode)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_prod_own_priority ON products(in_pharmacy_db DESC, pharmacy_stock DESC)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_barcodes_barcode ON product_barcodes(barcode)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_barcodes_pid ON product_barcodes(product_id)")

            # FTS5 Sanal Tablosu (Tam metin arama ve milisaniyelik anlık öneri)
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS products_fts USING fts5(
                    product_id UNINDEXED,
                    name,
                    name_normalized,
                    primary_barcode,
                    tokenize = "unicode61"
                )
            """)

            # Tablo boşsa WEBLISTE.xlsx'ten aktar
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM products")
            count = cursor.fetchone()[0]
            if count == 0 and EXCEL_PATH.exists():
                print(f"[Catalog] İlaç veritabanı ilk kez oluşturuluyor ({EXCEL_PATH.name})...")
                self.import_from_excel(EXCEL_PATH)
                cursor.execute("SELECT COUNT(*) FROM products")
                count = cursor.fetchone()[0]

            # Bilinen katalog ürün ismi yazım hatalarını (örn. 8699956513676 ATODERRM -> ATODERM) hem products hem products_fts içinde otomatik onar
            try:
                fix_rows = cursor.execute("""
                    SELECT id, primary_barcode, name
                    FROM products
                    WHERE primary_barcode = '8699956513676'
                       OR name_normalized LIKE '%atoderrm%'
                """).fetchall()
                fixed_any = False
                for fr in fix_rows:
                    fid = int(fr[0])
                    fbc = str(fr[1] or "")
                    old_nm = str(fr[2] or "")
                    new_nm = clean_catalog_product_name(old_nm, fbc)
                    new_norm = normalize_text(new_nm)
                    if new_nm and new_nm != old_nm:
                        conn.execute(
                            "UPDATE products SET name = ?, name_normalized = ? WHERE id = ?",
                            (new_nm, new_norm, fid),
                        )
                        try:
                            conn.execute("DELETE FROM products_fts WHERE product_id = ?", (fid,))
                            conn.execute(
                                "INSERT INTO products_fts (product_id, name, name_normalized, primary_barcode) VALUES (?, ?, ?, ?)",
                                (fid, new_nm, new_norm, fbc),
                            )
                        except Exception:
                            pass
                        fixed_any = True
                if fixed_any:
                    conn.commit()
            except Exception as e_fix:
                print(f"[Catalog] İsim düzeltme migrasyon uyarısı: {e_fix}")

            # FTS5 indeksi eksik veya güncel değilse oluştur
            try:
                cursor.execute("SELECT COUNT(*) FROM products_fts")
                fts_count = cursor.fetchone()[0]
                if fts_count < count:
                    print(f"[Catalog] FTS5 arama indeksi güncelleniyor ({count} ürün)...")
                    self._rebuild_fts(conn)
            except Exception:
                self._rebuild_fts(conn)

    def _rebuild_fts(self, conn=None):
        """FTS5 sanal tablosunu sıfırdan yeniden oluşturur ve senkronize eder."""
        should_close = False
        if conn is None:
            conn = self._get_connection()
            should_close = True
        try:
            conn.execute("DROP TABLE IF EXISTS products_fts")
            conn.execute("""
                CREATE VIRTUAL TABLE products_fts USING fts5(
                    product_id UNINDEXED,
                    name,
                    name_normalized,
                    primary_barcode,
                    tokenize = "unicode61"
                )
            """)
            conn.execute("""
                INSERT INTO products_fts (product_id, name, name_normalized, primary_barcode)
                SELECT id, name, name_normalized, primary_barcode FROM products
            """)
            conn.commit()
            print("[Catalog] FTS5 tam metin arama indeksi hazırlandı.")
        except Exception as e:
            print(f"[Catalog] FTS5 oluşturma hatası: {e}")
        finally:
            if should_close:
                conn.close()

    def import_from_excel(self, excel_file: Path):
        """Selçuk Ecza WEBLISTE.xlsx dosyasını SQLite veritabanına aktarır."""
        wb = openpyxl.load_workbook(excel_file, read_only=True)
        sheet = wb.active

        with self._get_connection() as conn:
            cur = conn.cursor()
            for row in sheet.iter_rows(min_row=2, values_only=True):
                if not row or not row[0]:
                    continue
                
                raw_barcode = str(row[0]).strip().replace(".0", "")
                if not raw_barcode.isdigit() or len(raw_barcode) < 8:
                    continue

                name = str(row[1] or "").strip()
                price = float(row[2] or 0.0)
                manufacturer = str(row[3] or "").strip()
                vat = float(row[5] or 10.0) if len(row) > 5 and row[5] is not None else 10.0
                inst_disc = float(row[6] or 0.0) if len(row) > 6 and row[6] is not None else 0.0
                profit = float(row[10] or 0.0) if len(row) > 10 and row[10] is not None else 0.0
                name_norm = normalize_text(name)

                # Ürünü ekle
                cur.execute("""
                    INSERT INTO products 
                    (code, name, name_normalized, manufacturer, price, depo_price, vat, primary_barcode, institution_discount, profit_rate, source)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'WEBLISTE')
                """, (raw_barcode, name, name_norm, manufacturer, price, 0.0, vat, raw_barcode, inst_disc, profit))
                prod_id = cur.lastrowid

                # Barkodunu kaydet
                cur.execute("""
                    INSERT OR IGNORE INTO product_barcodes (product_id, barcode, is_primary)
                    VALUES (?, ?, 1)
                """, (prod_id, raw_barcode))

        wb.close()
        print(f"[Catalog] Selçuk WEBLISTE başarıyla aktarıldı.")

    def update_product_live_stock(self, barcode: str, stock: int, source: str = ""):
        """Tekil ürün veya kritik stok sorgularında elde edilen canlı eczane stoğunu yerel katalogda günceller."""
        clean_b = str(barcode or "").strip()
        if not clean_b:
            return
        self.update_products_live_stock_bulk([(clean_b, stock)], source=source)

    def update_products_live_stock_bulk(self, entries: List[Any], source: str = ""):
        """Çoklu ürünün canlı eczane stoğunu tek bir hızlı SQLite işlemiyle günceller (<3ms)."""
        cleaned = []
        for item in (entries or []):
            if not item or len(item) < 2:
                continue
            bc = str(item[0] or "").strip()
            if not bc:
                continue
            try:
                st_val = int(round(float(item[1] or 0)))
            except Exception:
                st_val = 0
            cleaned.append((bc, st_val))
        if not cleaned:
            return
        try:
            prio = 2
            with self._get_connection() as conn:
                cur = conn.cursor()
                bcs = list({bc for bc, _ in cleaned})
                bc_to_pid: Dict[str, int] = {}
                for i in range(0, len(bcs), 400):
                    chunk = bcs[i:i + 400]
                    ph = ",".join("?" for _ in chunk)
                    for r_bc, r_pid in cur.execute(
                        f"SELECT barcode, product_id FROM product_barcodes WHERE barcode IN ({ph})",
                        chunk,
                    ).fetchall():
                        if r_bc and r_pid is not None:
                            bc_to_pid[str(r_bc)] = int(r_pid)
                for clean_b, st_val in cleaned:
                    pid = bc_to_pid.get(clean_b)
                    if pid is not None:
                        cur.execute("""
                            UPDATE products
                            SET in_pharmacy_db = CASE WHEN in_pharmacy_db < ? THEN ? ELSE in_pharmacy_db END,
                                pharmacy_stock = ?,
                                pharmacy_source = CASE WHEN ? <> '' THEN ? ELSE pharmacy_source END
                            WHERE id = ?
                        """, (prio, prio, st_val, source, source, pid))
                    else:
                        cur.execute("""
                            UPDATE products
                            SET in_pharmacy_db = CASE WHEN in_pharmacy_db < ? THEN ? ELSE in_pharmacy_db END,
                                pharmacy_stock = ?,
                                pharmacy_source = CASE WHEN ? <> '' THEN ? ELSE pharmacy_source END
                            WHERE primary_barcode = ?
                        """, (prio, prio, st_val, source, source, clean_b))
                conn.commit()
            self._suggest_cache.clear()
        except Exception:
            pass

    def sync_from_tria(self, force: bool = True):
        """
        TRIA Oracle veritabanından eczanenin tüm aktif ürünlerini, stoklarını, hareket durumunu ve çoklu barkodlarını aktarır.
        Her TBL_MAL_TANIM kaydı TEKİL bir ürün olarak tutulur; tüm alternatif barkodları product_barcodes tablosuna bağlanır.
        """
        import json
        import time as _time
        sync_state_file = DATA_DIR / "erp_sync_state.json"
        if not force and sync_state_file.exists():
            try:
                st_data = json.loads(sync_state_file.read_text(encoding="utf-8"))
                last_ts = float(st_data.get("TRIA", 0) or 0)
                if (_time.time() - last_ts) < 43200:  # 12 saat içinde zaten senkronize edildiyse başlangıçta LAN'ı yorma
                    return
            except Exception:
                pass
        try:
            from .tria_client import tria_client, fix_tria_str
            stock_by_id = {}
            moved_codes = set()
            with tria_client.get_connection() as conn:
                cur = conn.cursor()
                print("[Catalog] TRIA Oracle'dan ürünler, stoklar ve barkodlar çekiliyor...")
                cur.execute("""
                    SELECT m.ID, m.MAL_KODU, UTL_RAW.CAST_TO_RAW(m.MAL_ADI), m.SATIS_FIYATI_1, m.DEPOCU_SATIS_FIYATI, b.BARKOD
                    FROM TBL_MAL_TANIM m
                    JOIN TBL_MAL_BARKOD_TANIM b ON m.ID = b.MAL_TANIM_ID
                    WHERE (m.PASIF IS NULL OR m.PASIF = 0)
                      AND (b.PASIF IS NULL OR b.PASIF = 0)
                      AND b.BARKOD IS NOT NULL
                """)
                rows = cur.fetchall()

                # Toplu stok haritası (TBL_MAL_MIKTARLAR)
                try:
                    cur.execute("""
                        SELECT m.MAL_ID,
                               NVL(
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END),
                                   0
                               )
                        FROM TBL_MAL_MIKTARLAR m
                        GROUP BY m.MAL_ID
                    """)
                    for sr in cur.fetchall():
                        if sr[0] is not None:
                            stock_by_id[int(sr[0])] = int(round(float(sr[1] or 0)))
                except Exception as se:
                    print(f"[Catalog] TRIA toplu stok sorgu uyarısı: {se}")

                # Son 12 ayda hareket gören ürünler
                try:
                    cur.execute("""
                        SELECT DISTINCT MAL_KODU
                        FROM TBL_MAL_HAREKET
                        WHERE BELGE_TARIHI >= ADD_MONTHS(TRUNC(SYSDATE), -12)
                          AND MAL_KODU IS NOT NULL
                    """)
                    for mr in cur.fetchall():
                        if mr[0]:
                            moved_codes.add(str(mr[0]).strip())
                except Exception as me:
                    print(f"[Catalog] TRIA hareket sorgu uyarısı: {me}")

            products_map = {}
            barcodes_by_prod = defaultdict(list)

            for r in rows:
                p_id = int(r[0])
                p_code = str(r[1] or "").strip()
                raw_name = r[2]
                name = fix_tria_str(raw_name)
                psf = float(r[3] or 0.0)
                dsf = float(r[4] or 0.0)
                barcode = str(r[5] or "").strip()

                if not barcode or not name:
                    continue

                if p_id not in products_map:
                    stok_val = stock_by_id.get(p_id, 0)
                    has_mov = (p_code in moved_codes) or (stok_val > 0)
                    products_map[p_id] = {
                        "id": p_id,
                        "code": p_code,
                        "name": name,
                        "psf": psf,
                        "dsf": dsf,
                        "stok": stok_val,
                        "priority": 2 if has_mov else 0
                    }
                if barcode not in barcodes_by_prod[p_id]:
                    barcodes_by_prod[p_id].append(barcode)

            print(f"[Catalog] TRIA'dan {len(products_map)} tekil ürün ve {sum(len(b) for b in barcodes_by_prod.values())} barkod bağlantısı işleniyor...")

            inserted_new = 0
            with self._get_connection() as s_conn:
                s_cur = s_conn.cursor()
                existing_bc_to_pid: Dict[str, int] = {
                    str(r[0]): int(r[1])
                    for r in s_cur.execute("SELECT barcode, product_id FROM product_barcodes").fetchall()
                    if r[0] and r[1] is not None
                }

                for p_id, pdata in products_map.items():
                    barcodes = barcodes_by_prod[p_id]
                    name = clean_catalog_product_name(pdata["name"], barcodes[0] if barcodes else "")
                    name_norm = normalize_text(name)
                    brand = detect_brand(name)
                    stok_val = pdata["stok"]
                    prio_val = 2 if (pdata["priority"] >= 2 or len(barcodes) > 1) else 0
                    # Sadece en az bir geçerli (8-14 hane rakamdan oluşan) barkodu olan ürünleri kataloğa dahil et
                    valid_numeric = [b for b in barcodes if b.isdigit() and 8 <= len(b) <= 14]
                    if not valid_numeric:
                        continue  # Dahili 'VTR...' veya geçersiz sahte barkodlu kayıtları atla

                    # 13 haneli EAN barkodları öncelikli primary olarak seç
                    sorted_valid = sorted(
                        valid_numeric,
                        key=lambda x: (
                            not (len(x) == 13),
                            len(x)
                        )
                    )
                    primary_bc = sorted_valid[0]

                    # Bu barkodlardan herhangi biri mevcut ürünlerde kayıtlı mı? (RAM O(1) arama)
                    existing_prod_id = None
                    for b in barcodes:
                        pid_hit = existing_bc_to_pid.get(b)
                        if pid_hit is not None:
                            existing_prod_id = pid_hit
                            break

                    if existing_prod_id:
                        target_id = existing_prod_id
                        s_cur.execute("""
                            UPDATE products
                            SET in_pharmacy_db = CASE WHEN ? > in_pharmacy_db THEN ? ELSE in_pharmacy_db END,
                                pharmacy_stock = CASE WHEN ? > 0 THEN ? ELSE pharmacy_stock END,
                                pharmacy_source = 'TRIA',
                                price = CASE WHEN ? > 0 THEN ? ELSE price END,
                                depo_price = CASE WHEN ? > 0 THEN ? ELSE depo_price END
                            WHERE id = ?
                        """, (prio_val, prio_val, stok_val, stok_val, pdata["psf"], pdata["psf"], pdata["dsf"], pdata["dsf"], target_id))
                        # Mevcut ürüne diğer barkodları ekle
                        for b in barcodes:
                            if b not in existing_bc_to_pid:
                                is_prim = 1 if b == primary_bc else 0
                                s_cur.execute("""
                                    INSERT OR IGNORE INTO product_barcodes (product_id, barcode, is_primary)
                                    VALUES (?, ?, ?)
                                """, (target_id, b, is_prim))
                                existing_bc_to_pid[b] = target_id
                    else:
                        # Yeni ürün oluştur
                        s_cur.execute("""
                            INSERT INTO products 
                            (code, name, name_normalized, manufacturer, price, depo_price, vat, primary_barcode, source, in_pharmacy_db, pharmacy_stock, pharmacy_source)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'TRIA', ?, ?, 'TRIA')
                        """, (pdata["code"], name, name_norm, brand, pdata["psf"], pdata["dsf"], 20.0, primary_bc, prio_val, stok_val))
                        target_id = s_cur.lastrowid
                        inserted_new += 1

                        for b in barcodes:
                            is_prim = 1 if b == primary_bc else 0
                            s_cur.execute("""
                                INSERT OR IGNORE INTO product_barcodes (product_id, barcode, is_primary)
                                VALUES (?, ?, ?)
                            """, (target_id, b, is_prim))
                            existing_bc_to_pid[b] = target_id

                s_conn.commit()

            self._suggest_cache.clear()
            if inserted_new > 0:
                self._rebuild_fts()
            try:
                st_prev = {}
                if sync_state_file.exists():
                    st_prev = json.loads(sync_state_file.read_text(encoding="utf-8"))
                st_prev["TRIA"] = _time.time()
                sync_state_file.write_text(json.dumps(st_prev), encoding="utf-8")
            except Exception:
                pass
            print(f"[Catalog] TRIA çoklu barkod ve eczane öncelik senkronizasyonu tamamlandı ({inserted_new} yeni ürün).")
        except Exception as e:
            print(f"[Catalog] TRIA senkronizasyon hatası: {e}")

    def sync_from_botanik(self):
        """
        Botanik MS SQL veritabanından eczanenin tüm aktif ürünlerini, stoklarını, hareket durumunu ve barkodlarını aktarır.
        Her Urun kaydı tekil ürün olarak tutulur; tüm alternatif barkodları product_barcodes tablosuna bağlanır.
        """
        try:
            from .botanik_client import botanik_client
            moved_ids = set()
            with botanik_client.get_connection() as conn:
                cur = conn.cursor()
                print("[Catalog] Botanik SQL veritabanından ürünler, stoklar ve barkodlar çekiliyor...")
                cur.execute("""
                    SELECT u.UrunId,
                           u.UrunAdi,
                           ISNULL(u.UrunFiyatEtiket, 0),
                           b.BarkodAdi,
                           (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) AS ToplamStok,
                           ISNULL(u.UrunAktif, 1) AS Aktif
                    FROM Urun u WITH (NOLOCK)
                    JOIN Barkod b WITH (NOLOCK) ON u.UrunId = b.BarkodUrunId
                    WHERE ISNULL(u.UrunSilme, 0) = 0 AND ISNULL(b.BarkodSilme, 0) = 0 
                      AND b.BarkodAdi IS NOT NULL AND b.BarkodAdi <> ''
                """)
                rows = cur.fetchall()

                # Hareket görmüş (satış veya alış faturası olan) ürünleri hızlıca çek
                try:
                    cur.execute("""
                        SELECT DISTINCT RIUrunId FROM EldenIlaclari WITH (NOLOCK) WHERE ISNULL(RISilme, 0) = 0 AND RIUrunId IS NOT NULL
                        UNION
                        SELECT DISTINCT RIUrunId FROM ReceteIlaclari WITH (NOLOCK) WHERE ISNULL(RISilme, 0) = 0 AND RIUrunId IS NOT NULL
                        UNION
                        SELECT DISTINCT FSUrunId FROM FaturaSatir WITH (NOLOCK) WHERE FSUrunId IS NOT NULL
                    """)
                    for mr in cur.fetchall():
                        if mr[0] is not None:
                            moved_ids.add(int(mr[0]))
                except Exception as me:
                    print(f"[Catalog] Botanik hareket sorgu uyarısı: {me}")

            products_map = {}
            barcodes_by_prod = defaultdict(list)

            for r in rows:
                p_id = int(r[0])
                name = str(r[1] or "").strip()
                psf = float(r[2] or 0.0)
                barcode = str(r[3] or "").strip()
                stok_val = int(round(float(r[4] or 0)))

                if not barcode or not name:
                    continue

                if p_id not in products_map:
                    has_mov = (p_id in moved_ids) or (stok_val > 0)
                    products_map[p_id] = {
                        "id": p_id,
                        "code": str(p_id),
                        "name": name,
                        "psf": psf,
                        "dsf": round(psf * 0.75, 2),
                        "stok": stok_val,
                        "priority": 2 if has_mov else 0
                    }
                else:
                    if stok_val > products_map[p_id]["stok"]:
                        products_map[p_id]["stok"] = stok_val
                    if stok_val > 0 or (p_id in moved_ids):
                        products_map[p_id]["priority"] = 2

                if barcode not in barcodes_by_prod[p_id]:
                    barcodes_by_prod[p_id].append(barcode)

            print(f"[Catalog] Botanik'ten {len(products_map)} tekil ürün ve {sum(len(v) for v in barcodes_by_prod.values())} barkod okundu. SQLite'a yazılıyor...")

            with self._get_connection() as s_conn:
                s_cur = s_conn.cursor()

                for p_id, pdata in products_map.items():
                    barcodes = barcodes_by_prod.get(p_id, [])
                    name = clean_catalog_product_name(pdata["name"], barcodes[0] if barcodes else "")
                    name_norm = normalize_text(name)
                    brand = detect_brand(name)
                    stok_val = pdata["stok"]
                    prio_val = 2 if (pdata["priority"] >= 2 or len(barcodes) > 1) else 0

                    if not barcodes:
                        continue

                    # 13 haneli barkodları önceliklendir
                    sorted_valid = sorted(
                        barcodes,
                        key=lambda x: (
                            not (x.isdigit() and len(x) in (13, 8)),
                            not (len(x) == 13),
                            len(x)
                        )
                    )
                    primary_bc = sorted_valid[0]

                    # Bu barkodlardan herhangi biri mevcut ürünlerde kayıtlı mı?
                    existing_prod_id = None
                    for b in barcodes:
                        s_cur.execute("SELECT product_id FROM product_barcodes WHERE barcode = ?", (b,))
                        row = s_cur.fetchone()
                        if row:
                            existing_prod_id = row[0]
                            break

                    if existing_prod_id:
                        target_id = existing_prod_id
                        s_cur.execute("""
                            UPDATE products
                            SET in_pharmacy_db = CASE WHEN ? > in_pharmacy_db THEN ? ELSE in_pharmacy_db END,
                                pharmacy_stock = CASE WHEN ? > 0 THEN ? ELSE pharmacy_stock END,
                                pharmacy_source = 'BOTANIK',
                                price = CASE WHEN ? > 0 THEN ? ELSE price END
                            WHERE id = ?
                        """, (prio_val, prio_val, stok_val, stok_val, pdata["psf"], pdata["psf"], target_id))
                        for b in barcodes:
                            is_prim = 1 if b == primary_bc else 0
                            s_cur.execute("""
                                INSERT OR IGNORE INTO product_barcodes (product_id, barcode, is_primary)
                                VALUES (?, ?, ?)
                            """, (target_id, b, is_prim))
                    else:
                        s_cur.execute("""
                            INSERT INTO products 
                            (code, name, name_normalized, manufacturer, price, depo_price, vat, primary_barcode, source, in_pharmacy_db, pharmacy_stock, pharmacy_source)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'BOTANIK', ?, ?, 'BOTANIK')
                        """, (pdata["code"], name, name_norm, brand, pdata["psf"], pdata["dsf"], 20.0, primary_bc, prio_val, stok_val))
                        target_id = s_cur.lastrowid

                        for b in barcodes:
                            is_prim = 1 if b == primary_bc else 0
                            s_cur.execute("""
                                INSERT OR IGNORE INTO product_barcodes (product_id, barcode, is_primary)
                                VALUES (?, ?, ?)
                            """, (target_id, b, is_prim))

                s_conn.commit()

            self._suggest_cache.clear()
            self._rebuild_fts()
            print("[Catalog] Botanik çoklu barkod ve eczane öncelik senkronizasyonu başarıyla tamamlandı.")
        except Exception as e:
            print(f"[Catalog] Botanik senkronizasyon hatası: {e}")

    def sync_from_tebeos(self):
        """
        TEBEOS PostgreSQL veritabanından eczanenin hem İlaç (ilac.urun_ms) hem de
        OTC / Takviye / Dermo (public.idu_bilgi_ms) kartlarını, çoklu barkodlarını ve
        kart bazlı gerçek TEBEOS stoklarını yerel arama kataloğuna senkronize eder.
        """
        try:
            from .tebeos_client import tebeos_client, _expand_barcode_variants
            with tebeos_client.get_connection() as conn:
                print("[Catalog] TEBEOS PostgreSQL veritabanından kart bazlı stok ve OTC/İlaç kayıtları çekiliyor...")
                # 1. Hareket görmüş veya stoğu olan İlaç kartları
                _, u_rows = conn.query("""
                    SELECT u.urun_id,
                           u.urun_adi,
                           COALESCE(st.stok, 0) AS stok,
                           COALESCE(st.mov_cnt, 0) AS mov_cnt,
                           COALESCE(f.psf, 0) AS psf,
                           COALESCE(f.dsf, 0) AS dsf,
                           COALESCE(f.kdv, 10) AS kdv
                    FROM (
                        SELECT h.urun_id, SUM(h.adet) AS stok, COUNT(*) AS mov_cnt
                        FROM stok.stok_hareket_ms h
                        WHERE h.urun_id > 0
                        GROUP BY h.urun_id
                    ) st
                    JOIN ilac.urun_ms u ON u.urun_id = st.urun_id
                    LEFT JOIN LATERAL (
                        SELECT psf, dsf, kdv FROM ilac.urun_fiyat_ms uf
                        WHERE uf.urun_id = u.urun_id
                        ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                        LIMIT 1
                    ) f ON true
                """)
                u_ids = [int(r[0]) for r in u_rows if r[0]]
                u_bc_map = {}
                for idx in range(0, len(u_ids), 500):
                    chk = u_ids[idx:idx + 500]
                    in_str = "(" + ",".join(str(x) for x in chk) + ")"
                    _, b_rows = conn.query(f"SELECT urun_id, barkod FROM ilac.urun_barkod_ms WHERE urun_id IN {in_str} AND barkod IS NOT NULL AND barkod <> ''")
                    for br in b_rows:
                        u_bc_map.setdefault(int(br[0]), []).append(str(br[1]).strip())

                # 2. Tüm OTC / Takviye / Dermo (public.idu_bilgi_ms) kartları ve kart bazlı net stokları
                i_rows = []
                i_bc_map = {}
                try:
                    _, i_rows = conn.query("""
                        SELECT i.idu_bilgi_id,
                               i.idu_tanim,
                               COALESCE(st.stok, 0) AS stok,
                               COALESCE(st.mov_cnt, 0) AS mov_cnt,
                               COALESCE(f.eczane_satis_fiyat, 0) AS psf,
                               COALESCE(f.depocu_satis_fiyat, 0) AS dsf,
                               COALESCE(f.idu_kdv, 20) AS kdv
                        FROM public.idu_bilgi_ms i
                        LEFT JOIN (
                            SELECT h.idu_bilgi_id, SUM(h.adet) AS stok, COUNT(*) AS mov_cnt
                            FROM stok.stok_hareket_ms h
                            WHERE h.idu_bilgi_id > 0
                            GROUP BY h.idu_bilgi_id
                        ) st ON st.idu_bilgi_id = i.idu_bilgi_id
                        LEFT JOIN LATERAL (
                            SELECT eczane_satis_fiyat, depocu_satis_fiyat, idu_kdv FROM public.idu_fiyat_ms uf
                            WHERE uf.idu_bilgi_id = i.idu_bilgi_id
                            ORDER BY uf.idu_fiyat_id DESC
                            LIMIT 1
                        ) f ON true
                        WHERE i.idu_bilgi_id > 0
                          AND (COALESCE(st.mov_cnt, 0) > 0 OR COALESCE(st.stok, 0) <> 0)
                    """)
                    i_ids = [int(r[0]) for r in i_rows if r[0]]
                    for idx in range(0, len(i_ids), 500):
                        chk = i_ids[idx:idx + 500]
                        in_str = "(" + ",".join(str(x) for x in chk) + ")"
                        _, ib_rows = conn.query(f"SELECT idu_bilgi_id, barkod FROM public.idu_barkod_ms WHERE idu_bilgi_id IN {in_str} AND barkod IS NOT NULL AND barkod <> ''")
                        for br in ib_rows:
                            i_bc_map.setdefault(int(br[0]), []).append(str(br[1]).strip())
                except Exception as ie:
                    print(f"[Catalog] TEBEOS IDU okuma uyarısı: {ie}")

            cards = []
            for r in u_rows:
                uid = int(r[0])
                bcs = u_bc_map.get(uid, [])
                if bcs:
                    cards.append((f"TEB_U_{uid}", str(r[1] or "").strip(), int(round(float(r[2] or 0))), int(r[3] or 0), float(r[4] or 0.0), float(r[5] or 0.0), float(r[6] or 10.0), bcs))
            for r in i_rows:
                iid = int(r[0])
                bcs = i_bc_map.get(iid, [])
                if bcs:
                    cards.append((f"TEB_I_{iid}", str(r[1] or "").strip(), int(round(float(r[2] or 0))), int(r[3] or 0), float(r[4] or 0.0), float(r[5] or 0.0), float(r[6] or 20.0), bcs))

            if not cards:
                return

            inserted_new = 0
            with self._get_connection() as s_conn:
                s_cur = s_conn.cursor()
                for code_key, name, stok_val, mov_cnt, psf_v, dsf_v, kdv_v, raw_bcs in cards:
                    if not name or not raw_bcs:
                        continue
                    name = clean_catalog_product_name(name, raw_bcs[0] if raw_bcs else "")
                    prio_val = 2 if (stok_val > 0 or mov_cnt > 0) else 0
                    var_map = _expand_barcode_variants(raw_bcs)
                    lookup_bcs = []
                    for vlist in var_map.values():
                        for v in vlist:
                            if v not in lookup_bcs:
                                lookup_bcs.append(v)

                    matched_pids = set()
                    for lb in lookup_bcs:
                        s_cur.execute("SELECT product_id FROM product_barcodes WHERE barcode = ? LIMIT 1", (lb,))
                        prow = s_cur.fetchone()
                        if prow and prow[0]:
                            matched_pids.add(int(prow[0]))

                    if matched_pids:
                        for pid in matched_pids:
                            s_cur.execute("""
                                UPDATE products
                                SET in_pharmacy_db = CASE WHEN in_pharmacy_db < ? THEN ? ELSE in_pharmacy_db END,
                                    pharmacy_stock = ?,
                                    pharmacy_source = 'TEBEOS',
                                    price = CASE WHEN price <= 0 AND ? > 0 THEN ? ELSE price END
                                WHERE id = ?
                            """, (prio_val, prio_val, stok_val, psf_v, psf_v, pid))
                        # Yalnızca tek bir ürüne eşleştiyse kartın diğer resmi/format barkodlarını da bağla (farklı kartları asla birleştirme!)
                        if len(matched_pids) == 1:
                            only_pid = next(iter(matched_pids))
                            for rb in raw_bcs:
                                s_cur.execute("INSERT OR IGNORE INTO product_barcodes (product_id, barcode, is_primary) VALUES (?, ?, 0)", (only_pid, rb))
                    else:
                        # Katalogda hiç olmayan eczane OTC/Takviye kartını (örn. özel Velavit, Solgar, Medikal vb.) ekle
                        sorted_bcs = sorted(raw_bcs, key=lambda x: (not (x.isdigit() and len(x) == 13), -len(x)))
                        prim_bc = sorted_bcs[0]
                        name_norm = normalize_text(name)
                        brand = detect_brand(name)
                        s_cur.execute("""
                            INSERT INTO products
                            (code, name, name_normalized, manufacturer, price, depo_price, vat, primary_barcode, source, in_pharmacy_db, pharmacy_stock, pharmacy_source)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'TEBEOS', ?, ?, 'TEBEOS')
                        """, (code_key, name, name_norm, brand, psf_v, dsf_v, kdv_v, prim_bc, prio_val, stok_val))
                        new_pid = s_cur.lastrowid
                        inserted_new += 1
                        for rb in raw_bcs:
                            s_cur.execute(
                                "INSERT OR IGNORE INTO product_barcodes (product_id, barcode, is_primary) VALUES (?, ?, ?)",
                                (new_pid, rb, 1 if rb == prim_bc else 0),
                            )
                s_conn.commit()

            self._suggest_cache.clear()
            if inserted_new > 0:
                self._rebuild_fts()
            print(f"[Catalog] TEBEOS eczane öncelik senkronizasyonu tamamlandı ({len(cards)} kart, {inserted_new} yeni OTC/ürün eklendi).")
        except Exception as e:
            print(f"[Catalog] TEBEOS senkronizasyon hatası: {e}")

    def sync_from_eczanem(self):
        """Pasif: Eczanem entegrasyonu devre dışı bırakılmıştır."""
        return

    def sync_from_active_erp(self, active_oto: str = "", force: bool = False):
        """Aktif eczane otomasyonuna (TRIA / BOTANIK / TEBEOS) göre yerel arama indeksini günceller."""
        import os
        oto = (active_oto or os.environ.get("ACTIVE_OTOMASYON", "TRIA")).strip().upper()
        if oto in ("BOTANIK", "ECZANEM"):
            self.sync_from_botanik()
        elif oto == "TEBEOS":
            self.sync_from_tebeos()
        else:
            self.sync_from_tria(force=force)

    def search_suggestions(self, query: str, limit: int = 15) -> List[Dict[str, Any]]:
        """
        Kullanıcı yazarken anlık hızlı öneri sunar.
        3 Katmanlı Hibrit Öncelik Algoritması (1: Eczanede Aktif/Stoklu/Hareketli, 2: Geçerli EAN İlaç/OTC, 3: Genel Katalog)
        ve FTS5 Full-Text Search ile milisaniyelik (<2ms) hızda sonuç döndürür.
        """
        clean_q = query.strip()
        if not clean_q:
            return []

        cache_key = f"{clean_q.lower()}_{limit}"
        if cache_key in self._suggest_cache:
            return self._suggest_cache[cache_key]

        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Eğer sadece rakamlardan oluşuyorsa barkod üzerinden ara (Önce Eczanenin Kendi Veritabanı!)
            if clean_q.isdigit():
                cursor.execute("""
                    SELECT DISTINCT p.id, p.name, p.manufacturer, p.price, p.primary_barcode,
                                    p.in_pharmacy_db, p.pharmacy_stock, p.pharmacy_source
                    FROM product_barcodes pb
                    JOIN products p ON pb.product_id = p.id
                    WHERE pb.barcode LIKE ?
                    ORDER BY 
                        CASE WHEN pb.barcode = ? THEN 0 WHEN pb.barcode LIKE ? THEN 1 ELSE 2 END,
                        p.in_pharmacy_db DESC,
                        CASE WHEN p.pharmacy_stock > 0 THEN 0 ELSE 1 END,
                        length(pb.barcode) ASC, p.name ASC
                    LIMIT ?
                """, (f"{clean_q}%", clean_q, f"{clean_q}%", limit))
                rows = cursor.fetchall()
                if not rows and len(clean_q) >= 4:
                    cursor.execute("""
                        SELECT DISTINCT p.id, p.name, p.manufacturer, p.price, p.primary_barcode,
                                        p.in_pharmacy_db, p.pharmacy_stock, p.pharmacy_source
                        FROM product_barcodes pb
                        JOIN products p ON pb.product_id = p.id
                        WHERE pb.barcode LIKE ?
                        ORDER BY
                            p.in_pharmacy_db DESC,
                            CASE WHEN p.pharmacy_stock > 0 THEN 0 ELSE 1 END,
                            p.name ASC
                        LIMIT ?
                    """, (f"%{clean_q}%", limit))
                    rows = cursor.fetchall()
            else:
                norm_q = normalize_text(clean_q)
                words = [w for w in re.findall(r"[\w]+", norm_q) if len(w) > 0]
                rows = []

                # 1. Kısa 2-3 harfli kısaltmalarda doğrudan indeksli aralık sorgusu (ultra-hızlı <1ms)
                if len(words) == 1 and len(norm_q) <= 3:
                    prefix = norm_q
                    next_prefix = prefix[:-1] + chr(ord(prefix[-1]) + 1)
                    cursor.execute("""
                        SELECT p.id, p.name, p.manufacturer, p.price, p.primary_barcode,
                               p.in_pharmacy_db, p.pharmacy_stock, p.pharmacy_source
                        FROM products p
                        WHERE p.name_normalized >= ? AND p.name_normalized < ?
                        ORDER BY 
                            p.in_pharmacy_db DESC,
                            CASE WHEN p.pharmacy_stock > 0 THEN 0 ELSE 1 END,
                            CASE WHEN p.primary_barcode GLOB '86[89]*' AND length(p.primary_barcode) = 13 THEN 0 ELSE 1 END,
                            CASE WHEN p.name_normalized GLOB 'parol*' 
                                   OR p.name_normalized GLOB 'arveles*' 
                                   OR p.name_normalized GLOB 'augmentin*' 
                                   OR p.name_normalized GLOB 'apranax*' 
                                   OR p.name_normalized GLOB 'coraspin*' 
                                   OR p.name_normalized GLOB 'pantpas*' 
                                   OR p.name_normalized GLOB 'panto*' 
                                   OR p.name_normalized GLOB 'dolorex*' 
                                   OR p.name_normalized GLOB 'dolven*' 
                                   OR p.name_normalized GLOB 'majezik*' 
                                   OR p.name_normalized GLOB 'klacid*' 
                                   OR p.name_normalized GLOB 'beloc*' 
                                   OR p.name_normalized GLOB 'a-ferin*' 
                                   OR p.name_normalized GLOB 'aferin*' 
                                   OR p.name_normalized GLOB 'nexium*' 
                                   OR p.name_normalized GLOB 'buscopan*' 
                                   OR p.name_normalized GLOB 'dexofen*' 
                                 THEN 0 ELSE 1 END,
                            CASE WHEN p.vat IN (8.0, 10.0) OR p.institution_discount > 0 OR p.source = 'WEBLISTE' THEN 0 ELSE 1 END,
                            length(p.name) ASC
                        LIMIT ?
                    """, (prefix, next_prefix, limit))
                    rows = cursor.fetchall()

                # 2. FTS5 Tam Metin Arama (Kelimelerin başlarını ve tam hallerini tarar)
                if not rows and words:
                    safe_terms = [re.sub(r'[^\w]', '', w) for w in words if len(w) > 0]
                    fts_query = " ".join(f'"{t}"*' for t in safe_terms)
                    try:
                        cursor.execute(f"""
                            SELECT p.id, p.name, p.manufacturer, p.price, p.primary_barcode,
                                   p.in_pharmacy_db, p.pharmacy_stock, p.pharmacy_source
                            FROM products_fts f
                            JOIN products p ON f.product_id = p.id
                            WHERE products_fts MATCH ?
                            ORDER BY 
                                p.in_pharmacy_db DESC,
                                CASE WHEN p.pharmacy_stock > 0 THEN 0 ELSE 1 END,
                                CASE WHEN p.primary_barcode GLOB '86[89]*' AND length(p.primary_barcode) = 13 THEN 0 ELSE 1 END,
                                CASE WHEN p.name_normalized LIKE ? THEN 0 ELSE 1 END,
                                CASE WHEN p.name_normalized GLOB 'parol*' 
                                       OR p.name_normalized GLOB 'arveles*' 
                                       OR p.name_normalized GLOB 'augmentin*' 
                                       OR p.name_normalized GLOB 'apranax*' 
                                       OR p.name_normalized GLOB 'coraspin*' 
                                       OR p.name_normalized GLOB 'pantpas*' 
                                       OR p.name_normalized GLOB 'panto*' 
                                       OR p.name_normalized GLOB 'dolorex*' 
                                       OR p.name_normalized GLOB 'dolven*' 
                                       OR p.name_normalized GLOB 'majezik*' 
                                       OR p.name_normalized GLOB 'klacid*' 
                                       OR p.name_normalized GLOB 'beloc*' 
                                       OR p.name_normalized GLOB 'a-ferin*' 
                                       OR p.name_normalized GLOB 'aferin*' 
                                       OR p.name_normalized GLOB 'nexium*' 
                                       OR p.name_normalized GLOB 'buscopan*' 
                                       OR p.name_normalized GLOB 'dexofen*' 
                                     THEN 0 ELSE 1 END,
                                CASE WHEN p.vat IN (8.0, 10.0) OR p.institution_discount > 0 OR p.source = 'WEBLISTE' THEN 0 ELSE 1 END,
                                rank
                            LIMIT ?
                        """, (fts_query, f"{norm_q}%", limit))
                        rows = cursor.fetchall()
                    except Exception as e:
                        print(f"[Catalog] FTS sorgu hatası: {e}")

                # 3. Fallback standart LIKE
                if not rows and words:
                    conditions = ["p.name_normalized LIKE ?"] * len(words)
                    params = [f"%{w}%" for w in words]
                    sql = f"""
                        SELECT p.id, p.name, p.manufacturer, p.price, p.primary_barcode,
                               p.in_pharmacy_db, p.pharmacy_stock, p.pharmacy_source
                        FROM products p
                        WHERE {" AND ".join(conditions)}
                        ORDER BY 
                            p.in_pharmacy_db DESC,
                            CASE WHEN p.pharmacy_stock > 0 THEN 0 ELSE 1 END,
                            CASE WHEN p.name_normalized LIKE ? THEN 0 ELSE 1 END,
                            CASE WHEN p.vat IN (8.0, 10.0) OR p.institution_discount > 0 OR p.source = 'WEBLISTE' THEN 0 ELSE 1 END,
                            length(p.name) ASC 
                        LIMIT ?
                    """
                    cursor.execute(sql, params + [f"{norm_q}%", limit])
                    rows = cursor.fetchall()

            results = []
            if rows:
                p_ids = [r["id"] for r in rows]
                barcodes_by_pid = defaultdict(list)
                placeholders = ",".join("?" for _ in p_ids)
                cursor.execute(f"SELECT product_id, barcode FROM product_barcodes WHERE product_id IN ({placeholders})", p_ids)
                for pid, bc in cursor.fetchall():
                    barcodes_by_pid[pid].append(bc)

                for r in rows:
                    p_id = r["id"]
                    all_bcs = barcodes_by_pid.get(p_id, [])
                    results.append({
                        "id": p_id,
                        "barcode": r["primary_barcode"] or (all_bcs[0] if all_bcs else ""),
                        "all_barcodes": all_bcs,
                        "barcode_count": len(all_bcs),
                        "name": r["name"],
                        "manufacturer": r["manufacturer"],
                        "price": r["price"],
                        "in_pharmacy_db": int(r["in_pharmacy_db"] or 0),
                        "pharmacy_stock": int(r["pharmacy_stock"] or 0),
                        "pharmacy_source": str(r["pharmacy_source"] or "")
                    })

            # Hafıza önbelleğine al (maksimum 300 anahtar)
            if len(self._suggest_cache) > 300:
                self._suggest_cache.clear()
            self._suggest_cache[cache_key] = results

            return results

    def get_by_barcode(self, barcode: str) -> Optional[Dict[str, Any]]:
        """Barkod üzerinden ürünü ve o ürüne bağlı tüm diğer barkodları getirir."""
        clean_b = barcode.strip()
        if not clean_b:
            return None

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT p.id, p.code, p.name, p.manufacturer, p.price, p.depo_price, p.vat, 
                       p.primary_barcode, p.institution_discount, p.profit_rate,
                       p.in_pharmacy_db, p.pharmacy_stock, p.pharmacy_source
                FROM product_barcodes pb
                JOIN products p ON pb.product_id = p.id
                WHERE pb.barcode = ?
                ORDER BY p.in_pharmacy_db DESC, p.pharmacy_stock DESC
                LIMIT 1
            """, (clean_b,))
            row = cursor.fetchone()
            if row:
                p_id = row["id"]
                cursor.execute("SELECT barcode FROM product_barcodes WHERE product_id = ?", (p_id,))
                all_bcs = [r[0] for r in cursor.fetchall()]
                return {
                    "id": row["id"],
                    "barcode": row["primary_barcode"] or clean_b,
                    "all_barcodes": all_bcs,
                    "barcode_count": len(all_bcs),
                    "code": row["code"],
                    "name": row["name"],
                    "manufacturer": row["manufacturer"],
                    "price": row["price"],
                    "depo_price": row["depo_price"],
                    "vat": row["vat"],
                    "institution_discount": row["institution_discount"],
                    "profit_rate": row["profit_rate"],
                    "in_pharmacy_db": int(row["in_pharmacy_db"] or 0),
                    "pharmacy_stock": int(row["pharmacy_stock"] or 0),
                    "pharmacy_source": str(row["pharmacy_source"] or "")
                }
            
            # Eğer product_barcodes'ta bulunamadıysa doğrudan products.primary_barcode'a bak
            cursor.execute("""
                SELECT id, code, name, manufacturer, price, depo_price, vat, 
                       primary_barcode, institution_discount, profit_rate,
                       in_pharmacy_db, pharmacy_stock, pharmacy_source
                FROM products 
                WHERE primary_barcode = ?
                ORDER BY in_pharmacy_db DESC, pharmacy_stock DESC
                LIMIT 1
            """, (clean_b,))
            row2 = cursor.fetchone()
            if row2:
                return {
                    "id": row2["id"],
                    "barcode": row2["primary_barcode"],
                    "all_barcodes": [row2["primary_barcode"]],
                    "barcode_count": 1,
                    "code": row2["code"],
                    "name": row2["name"],
                    "manufacturer": row2["manufacturer"],
                    "price": row2["price"],
                    "depo_price": row2["depo_price"],
                    "vat": row2["vat"],
                    "institution_discount": row2["institution_discount"],
                    "profit_rate": row2["profit_rate"],
                    "in_pharmacy_db": int(row2["in_pharmacy_db"] or 0),
                    "pharmacy_stock": int(row2["pharmacy_stock"] or 0),
                    "pharmacy_source": str(row2["pharmacy_source"] or "")
                }
        return None

    def upsert_products(self, items: List[Dict[str, Any]]):
        """Yeni bulunan (özellikle OTC/Dermokozmetik) ürünleri ve barkodlarını kataloğa ekler/günceller."""
        if not items:
            return
        with self._get_connection() as conn:
            cur = conn.cursor()
            for it in items:
                barcode = str(it.get("barcode", "")).strip()
                if not barcode or len(barcode) < 6:
                    continue
                name = clean_catalog_product_name(str(it.get("name", "")).strip(), barcode)
                if not name:
                    continue
                name_norm = normalize_text(name)
                manufacturer = str(it.get("manufacturer", "")).strip() or detect_brand(name)
                price = float(it.get("price", 0.0) or 0.0)
                vat = float(it.get("vat", 20.0) or 20.0)

                # Barkod zaten var mı?
                cur.execute("SELECT product_id FROM product_barcodes WHERE barcode = ?", (barcode,))
                row = cur.fetchone()
                if row:
                    p_id = row[0]
                    cur.execute("UPDATE products SET price = ? WHERE id = ? AND price <= 0", (price, p_id))
                else:
                    cur.execute("""
                        INSERT INTO products 
                        (code, name, name_normalized, manufacturer, price, depo_price, vat, primary_barcode, source)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'DISCOVERED')
                    """, (barcode, name, name_norm, manufacturer, price, 0.0, vat, barcode))
                    p_id = cur.lastrowid
                    cur.execute("""
                        INSERT INTO product_barcodes (product_id, barcode, is_primary)
                        VALUES (?, ?, 1)
                    """, (p_id, barcode))

    def import_custom_excel(self, excel_path: Path) -> Dict[str, Any]:
        """
        Kullanıcının yüklediği Dermokozmetik / OTC Excel dosyasını akıllı sütun eşleme ile içeri aktarır.
        Desteklenen sütunlar: Barkod, Ürün Adı / İsim, Satış Fiyatı / Fiyat, KDV, Marka / Firma.
        """
        wb = openpyxl.load_workbook(excel_path, read_only=True)
        sheet = wb.active

        rows = list(sheet.iter_rows(values_only=True))
        if not rows or len(rows) < 2:
            wb.close()
            return {"success": False, "error": "Excel dosyası boş veya başlık satırı yok."}

        header = [str(cell or "").strip().lower() for cell in rows[0]]

        # Sütun indekslerini tespit et
        barcode_idx = None
        name_idx = None
        price_idx = None
        vat_idx = None
        brand_idx = None

        for idx, col in enumerate(header):
            if any(k in col for k in ["barkod", "barcode", "gtin", "ean"]):
                barcode_idx = idx
            elif any(k in col for k in ["ürün adı", "urun adi", "mal adı", "isim", "name", "ürün", "ilaç"]):
                name_idx = idx
            elif any(k in col for k in ["fiyat", "psf", "satış", "tutar", "price"]):
                price_idx = idx
            elif any(k in col for k in ["kdv", "vat"]):
                vat_idx = idx
            elif any(k in col for k in ["marka", "üretici", "firma", "brand", "manufacturer"]):
                brand_idx = idx

        if barcode_idx is None and name_idx is None:
            # Otomatik varsayılan: 0: Barkod, 1: Ürün Adı, 2: Fiyat
            barcode_idx, name_idx = 0, 1
            if len(header) > 2: price_idx = 2

        imported_count = 0
        items_to_upsert = []

        for row in rows[1:]:
            if not row:
                continue
            bc_raw = str(row[barcode_idx] if barcode_idx is not None and barcode_idx < len(row) else "").strip().replace(".0", "")
            name_raw = str(row[name_idx] if name_idx is not None and name_idx < len(row) else "").strip()
            
            if not bc_raw or not name_raw:
                continue

            prc = 0.0
            if price_idx is not None and price_idx < len(row) and row[price_idx]:
                try:
                    prc = float(str(row[price_idx]).replace(".", "").replace(",", "."))
                except:
                    prc = 0.0

            vat = 20.0
            if vat_idx is not None and vat_idx < len(row) and row[vat_idx]:
                try:
                    vat = float(row[vat_idx])
                except:
                    vat = 20.0

            brand = ""
            if brand_idx is not None and brand_idx < len(row) and row[brand_idx]:
                brand = str(row[brand_idx]).strip()

            items_to_upsert.append({
                "barcode": bc_raw,
                "name": name_raw,
                "price": prc,
                "vat": vat,
                "manufacturer": brand or detect_brand(name_raw)
            })
            imported_count += 1

        wb.close()
        if items_to_upsert:
            self.upsert_products(items_to_upsert)

        return {"success": True, "count": imported_count}

    def add_barcode_to_product(self, product_id: int, barcode: str):
        """Ürüne yeni keşfedilen geçerli bir barkodu ikincil barkod olarak bağlar."""
        clean_b = str(barcode).strip()
        if not clean_b or len(clean_b) < 6:
            return
        with self._get_connection() as conn:
            cur = conn.cursor()
            try:
                cur.execute("""
                    INSERT OR IGNORE INTO product_barcodes (product_id, barcode, is_primary)
                    VALUES (?, ?, 0)
                """, (product_id, clean_b))
                conn.commit()
            except Exception:
                pass

    def find_canonical_barcodes_by_name(self, name: str, exclude_barcode: str = "") -> List[str]:
        """
        Ürün adından (özellikle Botanik'te sahte/uydurma barkodla açılmış OTC/dermokozmetik ürünlerde)
        veritabanındaki gerçek uluslararası geçerli barkodları keşfeder.
        """
        if not name:
            return []
        norm = normalize_text(name)
        brand_synonyms = [
            (["laroche posay", "la roche posay", "laroche", "la roche"], "lrp"),
            (["jel"], "gel"),
            (["kapsul", "kapsül", "softgel"], "kap"),
            (["tablet"], "tb")
        ]
        norm_expanded = norm
        for syn_list, target in brand_synonyms:
            for s in syn_list:
                if s in norm_expanded:
                    norm_expanded = norm_expanded.replace(s, target)
                    break

        words = [w for w in norm_expanded.split() if len(w) > 2 and w not in ["ml.", "ml", "mg.", "mg", "adet", "kutu", "icin", "tb", "tb.", "gel", "jel"]]
        found_barcodes = []
        exclude_b = str(exclude_barcode).strip()

        with self._get_connection() as conn:
            cur = conn.cursor()
            
            # 1. Strateji: norm_expanded kelimeleriyle tam eşleştirme
            if words:
                query_parts = " AND ".join(f"p.name_normalized LIKE '%{w}%'" for w in words if len(w) >= 3)
                cur.execute(f"""
                    SELECT pb.barcode, p.source 
                    FROM products p
                    JOIN product_barcodes pb ON p.id = pb.product_id
                    WHERE {query_parts}
                      AND pb.barcode IS NOT NULL 
                      AND LENGTH(pb.barcode) >= 8
                      AND pb.barcode NOT GLOB '*[^0-9]*'
                      AND pb.barcode NOT LIKE '8690000%'
                      AND pb.barcode NOT LIKE '8699999%'
                      AND pb.barcode NOT LIKE '8699222%'
                    ORDER BY 
                      (CASE WHEN p.source='WEBLISTE' THEN 1 WHEN p.source='TRIA' THEN 2 ELSE 3 END) ASC,
                      (CASE WHEN p.name_normalized LIKE '%kampanya%' OR p.name_normalized LIKE '%indirim%' OR p.name_normalized LIKE '%hediye%' OR p.name_normalized LIKE '%set%' OR p.name_normalized LIKE '%promosyon%' THEN 2 ELSE 1 END) ASC,
                      LENGTH(p.name_normalized) ASC
                    LIMIT 5
                """)
                for r in cur.fetchall():
                    bc = str(r[0]).strip()
                    if bc and bc != exclude_b and bc not in found_barcodes:
                        found_barcodes.append(bc)

            # 2. Strateji: Ayırt edici kelimeler + sayılar (örn: effaclar + 400)
            if not found_barcodes:
                distinctive = [w for w in words if len(w) >= 4 and not w.isdigit()]
                nums = [w for w in words if w.isdigit()]
                search_terms = distinctive[:2] + nums[:1]
                if search_terms:
                    q_dist = " AND ".join(f"p.name_normalized LIKE '%{w}%'" for w in search_terms)
                    cur.execute(f"""
                        SELECT pb.barcode, p.source 
                        FROM products p
                        JOIN product_barcodes pb ON p.id = pb.product_id
                        WHERE {q_dist}
                          AND pb.barcode IS NOT NULL 
                          AND LENGTH(pb.barcode) >= 8
                          AND pb.barcode NOT GLOB '*[^0-9]*'
                          AND pb.barcode NOT LIKE '8690000%'
                          AND pb.barcode NOT LIKE '8699999%'
                          AND pb.barcode NOT LIKE '8699222%'
                        ORDER BY 
                          (CASE WHEN p.source='WEBLISTE' THEN 1 WHEN p.source='TRIA' THEN 2 ELSE 3 END) ASC,
                          (CASE WHEN p.name_normalized LIKE '%kampanya%' OR p.name_normalized LIKE '%indirim%' OR p.name_normalized LIKE '%hediye%' OR p.name_normalized LIKE '%set%' OR p.name_normalized LIKE '%promosyon%' THEN 2 ELSE 1 END) ASC,
                          LENGTH(p.name_normalized) ASC
                        LIMIT 5
                    """)
                    for r in cur.fetchall():
                        bc = str(r[0]).strip()
                        if bc and bc != exclude_b and bc not in found_barcodes:
                            found_barcodes.append(bc)

        return found_barcodes

    def resolve_canonical_barcode(self, barcode: str) -> str:
        """
        Dahili (869922...), geçici, harfli (VTR...) veya promosyon barkodlarını
        katalogdaki gerçek üretici EAN-13 barkoduna (<1ms) çözümler.
        Geçerli 12-13 haneli barkodları asla başka bir barkodla değiştirmez.
        """
        if not barcode:
            return ""
        clean_b = str(barcode).strip()
        if not clean_b:
            return ""

        # Karekod / GTIN-14 başındaki '0' karakterini 13 haneli EAN-13'e normalize et
        work_b = clean_b[1:] if (len(clean_b) == 14 and clean_b.startswith("0") and clean_b[1:].isdigit()) else clean_b

        if not hasattr(self, "_canonical_cache"):
            self._canonical_cache = {}

        if clean_b in self._canonical_cache:
            return self._canonical_cache[clean_b]

        is_suspicious = (
            work_b.startswith(("0", "8869", "8690000", "8699999", "8699222", "8690595", "8699956", "8699958", "9999", "VTR"))
            or len(work_b) < 12
            or len(work_b) > 13
            or not work_b.isdigit()
        )

        # Geçerli 12-13 haneli standart barkod ise:
        # WEBLISTE veya eczane otomasyonunda (BOTANIK/TRIA/TEBEOS) aynı ürün kartına bağlı birincil barkod varsa ona yükselt.
        if not is_suspicious:
            with self._get_connection() as conn:
                cur = conn.cursor()
                cur.execute("""
                    SELECT p.primary_barcode
                    FROM product_barcodes pb
                    JOIN products p ON pb.product_id = p.id
                    WHERE pb.barcode = ?
                      AND LENGTH(p.primary_barcode) = 13
                      AND p.primary_barcode GLOB '[1-9][0-9]*'
                      AND p.primary_barcode NOT LIKE '8690000%'
                      AND p.primary_barcode NOT LIKE '8699999%'
                      AND p.primary_barcode NOT LIKE '8699222%'
                    ORDER BY CASE WHEN p.source = 'WEBLISTE' THEN 1 ELSE 2 END ASC
                    LIMIT 1
                """, (work_b,))
                row = cur.fetchone()
                if row and row[0]:
                    res_b = str(row[0]).strip()
                    self._canonical_cache[clean_b] = res_b
                    return res_b
            self._canonical_cache[clean_b] = work_b
            return work_b

        with self._get_connection() as conn:
            cur = conn.cursor()

            # 1. Şüpheli/dahili barkod için aynı ürünün geçerli bir EAN-13 barkodu product_barcodes'ta var mı?
            cur.execute("""
                SELECT pb2.barcode
                FROM product_barcodes pb1
                JOIN product_barcodes pb2 ON pb1.product_id = pb2.product_id
                WHERE pb1.barcode = ?
                  AND pb2.barcode != ?
                  AND LENGTH(pb2.barcode) = 13
                  AND pb2.barcode GLOB '[0-9]*'
                  AND pb2.barcode NOT LIKE '8690000%'
                  AND pb2.barcode NOT LIKE '8699999%'
                  AND pb2.barcode NOT LIKE '8699222%'
                  AND pb2.barcode NOT LIKE '9999%'
                ORDER BY
                  pb2.is_primary DESC,
                  CASE WHEN pb2.barcode LIKE '3%' OR pb2.barcode LIKE '4%' OR pb2.barcode LIKE '5%' OR pb2.barcode LIKE '84%' THEN 1 ELSE 2 END
                LIMIT 1
            """, (work_b, work_b))
            row = cur.fetchone()
            if row and row[0]:
                res_b = str(row[0]).strip()
                self._canonical_cache[clean_b] = res_b
                return res_b

            # 2. Ürün adından kanonik EAN bul
            cur.execute("""
                SELECT p.name, p.id
                FROM product_barcodes pb
                JOIN products p ON pb.product_id = p.id
                WHERE pb.barcode = ?
                LIMIT 1
            """, (work_b,))
            p_row = cur.fetchone()
            if p_row:
                p_name = p_row[0]
                p_id = p_row[1]
                canonicals = self.find_canonical_barcodes_by_name(p_name, exclude_barcode=work_b)
                if canonicals:
                    res_b = canonicals[0]
                    self.add_barcode_to_product(p_id, res_b)
                    self._canonical_cache[clean_b] = res_b
                    return res_b

        self._canonical_cache[clean_b] = work_b
        return work_b

    def get_product_by_barcode(self, barcode: str) -> Optional[Dict[str, Any]]:
        """get_by_barcode uyumluluk takma adı."""
        res = self.get_by_barcode(barcode)
        if res and "psf" not in res:
            res["psf"] = float(res.get("price") or 0.0)
        return res

    def resolve_canonical_barcodes_bulk(self, barcodes: List[str]) -> Dict[str, str]:
        """Çoklu barkod listesini tek bir SQLite bağlantısı ve bellek önbelleğiyle milisaniyeler içinde kanonik EAN-13'e çözümler."""
        if not hasattr(self, "_canonical_cache"):
            self._canonical_cache = {}
        out: Dict[str, str] = {}
        uncached_std: List[Tuple[str, str]] = []
        uncached_susp: List[str] = []

        for raw in (barcodes or []):
            clean_b = str(raw or "").strip()
            if not clean_b:
                continue
            hit = self._canonical_cache.get(clean_b)
            if hit is not None:
                out[clean_b] = hit
                continue
            work_b = clean_b[1:] if (len(clean_b) == 14 and clean_b.startswith("0") and clean_b[1:].isdigit()) else clean_b
            is_susp = (
                work_b.startswith(("0", "8869", "8690000", "8699999", "8699222", "8690595", "8699956", "8699958", "9999", "VTR"))
                or len(work_b) < 12
                or len(work_b) > 13
                or not work_b.isdigit()
            )
            if is_susp:
                uncached_susp.append(clean_b)
            else:
                uncached_std.append((clean_b, work_b))

        if uncached_std:
            work_set = list({wb for _, wb in uncached_std})
            found_prim: Dict[str, str] = {}
            try:
                with self._get_connection() as conn:
                    cur = conn.cursor()
                    for i in range(0, len(work_set), 400):
                        chunk = work_set[i:i + 400]
                        ph = ",".join("?" for _ in chunk)
                        cur.execute(f"""
                            SELECT pb.barcode, p.primary_barcode, p.source
                            FROM product_barcodes pb
                            JOIN products p ON pb.product_id = p.id
                            WHERE pb.barcode IN ({ph})
                              AND LENGTH(p.primary_barcode) = 13
                              AND p.primary_barcode GLOB '[1-9][0-9]*'
                              AND p.primary_barcode NOT LIKE '8690000%'
                              AND p.primary_barcode NOT LIKE '8699999%'
                              AND p.primary_barcode NOT LIKE '8699222%'
                            ORDER BY CASE WHEN p.source = 'WEBLISTE' THEN 1 ELSE 2 END ASC
                        """, chunk)
                        for r_bc, r_prim, _ in cur.fetchall():
                            k = str(r_bc or "").strip()
                            v = str(r_prim or "").strip()
                            if k and v and k not in found_prim:
                                found_prim[k] = v
            except Exception:
                pass

            for clean_b, work_b in uncached_std:
                res_b = found_prim.get(work_b, work_b)
                self._canonical_cache[clean_b] = res_b
                out[clean_b] = res_b

        for clean_b in uncached_susp:
            out[clean_b] = self.resolve_canonical_barcode(clean_b)

        return out

    def get_psf_map_bulk(self, barcodes: List[str]) -> Dict[str, float]:
        """Çoklu barkod için katalogdaki PSF (etiket) fiyatlarını tek sorguda döner."""
        clean_list = list({str(b or "").strip() for b in (barcodes or []) if str(b or "").strip()})
        out: Dict[str, float] = {}
        if not clean_list:
            return out
        try:
            with self._get_connection() as conn:
                cur = conn.cursor()
                for i in range(0, len(clean_list), 400):
                    chunk = clean_list[i:i + 400]
                    ph = ",".join("?" for _ in chunk)
                    cur.execute(f"""
                        SELECT pb.barcode, p.price
                        FROM product_barcodes pb
                        JOIN products p ON pb.product_id = p.id
                        WHERE pb.barcode IN ({ph}) AND p.price > 0
                    """, chunk)
                    for r_bc, r_pr in cur.fetchall():
                        if r_bc and r_pr:
                            out[str(r_bc).strip()] = float(r_pr)
        except Exception:
            pass
        return out

    def get_all_related_barcodes(self, barcode: str) -> List[str]:
        """Bir barkodun aynı ürüne ait tüm alternatif/ikincil barkodlarını döner."""
        if not barcode:
            return []
        clean_b = str(barcode).strip()
        work_b = clean_b[1:] if (len(clean_b) == 14 and clean_b.startswith("0") and clean_b[1:].isdigit()) else clean_b
        if not hasattr(self, "_related_bc_cache"):
            self._related_bc_cache = {}
        if work_b in self._related_bc_cache:
            return self._related_bc_cache[work_b]

        related = {clean_b, work_b}
        try:
            with self._get_connection() as conn:
                cur = conn.cursor()
                cur.execute("""
                    SELECT pb2.barcode, p.primary_barcode
                    FROM product_barcodes pb1
                    JOIN products p ON pb1.product_id = p.id
                    JOIN product_barcodes pb2 ON pb1.product_id = pb2.product_id
                    WHERE pb1.barcode IN (?, ?)
                """, (clean_b, work_b))
                for r in cur.fetchall():
                    if r[0]:
                        related.add(str(r[0]).strip())
                    if r[1]:
                        related.add(str(r[1]).strip())
        except Exception:
            pass
        res_list = [b for b in related if b]
        self._related_bc_cache[work_b] = res_list
        return res_list

    def clean_name_for_marketplace(self, name: str) -> str:
        """Ürün adını Farmazon / Ecza1 gibi pazaryerlerinde aramak üzere sadeleştirir."""
        if not name:
            return ""
        n = re.sub(r'\(.*?\)', ' ', name)
        n = re.sub(r'[%#\*\.,\-\+\/]', ' ', n)
        skip = {"ML", "ML.", "MG", "MG.", "TB", "TB.", "ADET", "KUTU", "FTB", "KAP", "KAMPANYALI", "OZEL", "FIYAT", "INDIRIMLI"}
        tokens = [t for t in n.split() if t.upper() not in skip]
        return " ".join(tokens[:4])

# Singleton catalog instance
catalog = ProductCatalog()

