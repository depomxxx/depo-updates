# -*- coding: utf-8 -*-
"""
backend/config_manager.py
-------------------------
Eczane Depo ve Otomasyon (.env) Giriş Bilgileri & Konfigürasyon Yöneticisi.
"""

import os
from pathlib import Path
from backend.botanik_client import botanik_client

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"

_REQ_CHECKS = {
    "ALLIANCE": ["ALLIANCE_PHARMACY_CODE", "ALLIANCE_USERNAME", "ALLIANCE_PASSWORD"],
    "SELCUK": ["SELCUK_USERNAME", "SELCUK_PASSWORD"],
    "NEVZAT": ["NEVZAT_ACCOUNT_CODE", "NEVZAT_USERNAME", "NEVZAT_PASSWORD"],
    "ISKOOP": ["ISKOOP_USERNAME", "ISKOOP_PASSWORD"],
    "BEK": ["BEK_USERNAME", "BEK_PASSWORD"],
    "ECZA1": ["ECZA1_USERNAME", "ECZA1_PASSWORD"],
    "FARMAZON": ["FARMAZON_USERNAME", "FARMAZON_PASSWORD"],
    "DNA": ["DNA_USERNAME", "DNA_PASSWORD"],
    "ECZATREND": ["ECZATREND_USERNAME", "ECZATREND_PASSWORD"],
    "ECZANETAKAS": ["ECZANETAKAS_USERNAME", "ECZANETAKAS_PASSWORD"],
}


def get_active_otomasyon() -> str:
    """
    Aktif eczane otomasyonunu döner.
    .env içerisinde ACTIVE_OTOMASYON tanımlı değilse:
    1) TRIA_DB_HOST tanımlı ve Botanik config yoksa TRIA,
    2) TEBEOS_DB_HOST tanımlıysa TEBEOS,
    3) Varsayılan olarak BOTANIK döner (Botanik config dosyasından otomatik okunduğu için).
    """
    val = os.environ.get("ACTIVE_OTOMASYON", "").strip().upper()
    if val in ("TRIA", "BOTANIK", "TEBEOS", "ECZANEM"):
        return val
    if os.environ.get("ECZANEM_SERVER", "").strip():
        return "ECZANEM"
    if os.environ.get("TEBEOS_DB_HOST", "").strip():
        return "TEBEOS"
    if os.environ.get("TRIA_DB_HOST", "").strip() and not os.environ.get("BOTANIK_DB_SERVER", "").strip():
        bot_cfg = botanik_client.read_botanik_config_file()
        if not bot_cfg.get("found"):
            return "TRIA"
    return "BOTANIK"


def _heal_active_flags_in_env_file(healed_keys: dict):
    if not healed_keys or not ENV_FILE.exists():
        return
    try:
        with open(ENV_FILE, "r", encoding="utf-8-sig") as f:
            lines = f.readlines()
        updated = set()
        new_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and "=" in stripped:
                k, _ = stripped.split("=", 1)
                k = k.strip().lstrip("\ufeff")
                if k in healed_keys:
                    new_lines.append(f"{k}={healed_keys[k]}\n")
                    updated.add(k)
                    continue
            new_lines.append(line)
        for k, v in healed_keys.items():
            if k not in updated:
                new_lines.append(f"{k}={v}\n")
        with open(ENV_FILE, "w", encoding="utf-8") as f:
            f.writelines(new_lines)
    except Exception:
        pass


def load_env():
    if ENV_FILE.exists():
        with open(ENV_FILE, "r", encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    k_clean = k.strip().lstrip("\ufeff")
                    v_clean = v.strip()
                    os.environ[k_clean] = v_clean

    # Eski/alternatif kurulum anahtarlarını standart *_DB_* anahtarlarıyla eşitle
    alias_pairs = [
        ("TRIA_DB_HOST", "TRIA_ORACLE_HOST"),
        ("TRIA_DB_PORT", "TRIA_ORACLE_PORT"),
        ("TRIA_DB_SID", "TRIA_ORACLE_SID"),
        ("TRIA_DB_USER", "TRIA_ORACLE_USER"),
        ("TRIA_DB_PASSWORD", "TRIA_ORACLE_PASSWORD"),
        ("BOTANIK_DB_SERVER", "BOTANIK_SQL_SERVER"),
        ("BOTANIK_DB_DATABASE", "BOTANIK_SQL_DB"),
        ("BOTANIK_DB_USER", "BOTANIK_SQL_USER"),
        ("BOTANIK_DB_PASSWORD", "BOTANIK_SQL_PASSWORD"),
        ("BOTANIK_DB_TRUSTED", "BOTANIK_SQL_TRUSTED"),
        ("TEBEOS_DB_HOST", "TEBEOS_PG_HOST"),
        ("TEBEOS_DB_PORT", "TEBEOS_PG_PORT"),
        ("TEBEOS_DB_DATABASE", "TEBEOS_PG_DB"),
        ("TEBEOS_DB_USER", "TEBEOS_PG_USER"),
        ("TEBEOS_DB_PASSWORD", "TEBEOS_PG_PASSWORD"),
        ("ACTIVE_OTOMASYON", "OTOMASYON_TIPI"),
    ]
    for primary_k, alt_k in alias_pairs:
        if not os.environ.get(primary_k, "").strip() and os.environ.get(alt_k, "").strip():
            os.environ[primary_k] = os.environ[alt_k].strip()

    # Şifresi eksiksiz girilmiş olan depoların kazara pasif (0) kalmasını otomatik onar
    healed = {}
    for depo_prefix, fields in _REQ_CHECKS.items():
        has_all = all(bool(os.environ.get(f, "").strip()) for f in fields)
        act_key = f"{depo_prefix}_ACTIVE"
        user_pasif = os.environ.get(f"{depo_prefix}_USER_PASIF", "0").strip() == "1"
        if has_all and not user_pasif:
            if os.environ.get(act_key, "1").strip() != "1":
                os.environ[act_key] = "1"
                healed[act_key] = "1"
        elif not has_all:
            os.environ[act_key] = "0"

    if healed:
        _heal_active_flags_in_env_file(healed)

    if "ACTIVE_OTOMASYON" not in os.environ or not os.environ.get("ACTIVE_OTOMASYON", "").strip():
        os.environ["ACTIVE_OTOMASYON"] = get_active_otomasyon()


def get_current_credentials():
    def _is_active(depo: str, has_creds: bool):
        if not has_creds:
            return "0"
        prefix = depo.upper()
        if os.environ.get(f"{prefix}_USER_PASIF", "0").strip() == "1":
            return "0"
        return "1"

    def _is_user_pasif(depo: str, has_creds: bool):
        if not has_creds:
            return "0"
        return "1" if os.environ.get(f"{depo.upper()}_USER_PASIF", "0").strip() == "1" else "0"

    bot_cfg = botanik_client.get_config()
    all_ok = bool(os.environ.get("ALLIANCE_PHARMACY_CODE", "").strip() and os.environ.get("ALLIANCE_USERNAME", "").strip() and os.environ.get("ALLIANCE_PASSWORD", "").strip())
    sel_ok = bool(os.environ.get("SELCUK_USERNAME", "").strip() and os.environ.get("SELCUK_PASSWORD", "").strip())
    nev_ok = bool(os.environ.get("NEVZAT_ACCOUNT_CODE", "").strip() and os.environ.get("NEVZAT_USERNAME", "").strip() and os.environ.get("NEVZAT_PASSWORD", "").strip())
    isk_ok = bool(os.environ.get("ISKOOP_USERNAME", "").strip() and os.environ.get("ISKOOP_PASSWORD", "").strip())
    bek_ok = bool(os.environ.get("BEK_USERNAME", "").strip() and os.environ.get("BEK_PASSWORD", "").strip())
    ec1_ok = bool(os.environ.get("ECZA1_USERNAME", "").strip() and os.environ.get("ECZA1_PASSWORD", "").strip())
    far_ok = bool(os.environ.get("FARMAZON_USERNAME", "").strip() and os.environ.get("FARMAZON_PASSWORD", "").strip())
    dna_ok = bool(os.environ.get("DNA_USERNAME", "").strip() and os.environ.get("DNA_PASSWORD", "").strip())
    etr_ok = bool(os.environ.get("ECZATREND_USERNAME", "").strip() and os.environ.get("ECZATREND_PASSWORD", "").strip())
    etk_ok = bool(os.environ.get("ECZANETAKAS_USERNAME", "").strip() and os.environ.get("ECZANETAKAS_PASSWORD", "").strip())

    return {
        "alliance": {
            "pharmacy_code": os.environ.get("ALLIANCE_PHARMACY_CODE", ""),
            "username": os.environ.get("ALLIANCE_USERNAME", ""),
            "password": os.environ.get("ALLIANCE_PASSWORD", ""),
            "active": _is_active("ALLIANCE", all_ok),
            "user_pasif": _is_user_pasif("ALLIANCE", all_ok),
        },
        "selcuk": {
            "username": os.environ.get("SELCUK_USERNAME", ""),
            "password": os.environ.get("SELCUK_PASSWORD", ""),
            "active": _is_active("SELCUK", sel_ok),
            "user_pasif": _is_user_pasif("SELCUK", sel_ok),
        },
        "nevzat": {
            "account_code": os.environ.get("NEVZAT_ACCOUNT_CODE", ""),
            "username": os.environ.get("NEVZAT_USERNAME", ""),
            "password": os.environ.get("NEVZAT_PASSWORD", ""),
            "active": _is_active("NEVZAT", nev_ok),
            "user_pasif": _is_user_pasif("NEVZAT", nev_ok),
        },
        "iskoop": {
            "username": os.environ.get("ISKOOP_USERNAME", ""),
            "password": os.environ.get("ISKOOP_PASSWORD", ""),
            "active": _is_active("ISKOOP", isk_ok),
            "user_pasif": _is_user_pasif("ISKOOP", isk_ok),
        },
        "bek": {
            "username": os.environ.get("BEK_USERNAME", ""),
            "password": os.environ.get("BEK_PASSWORD", ""),
            "active": _is_active("BEK", bek_ok),
            "user_pasif": _is_user_pasif("BEK", bek_ok),
        },
        "ecza1": {
            "username": os.environ.get("ECZA1_USERNAME", ""),
            "password": os.environ.get("ECZA1_PASSWORD", ""),
            "active": _is_active("ECZA1", ec1_ok),
            "user_pasif": _is_user_pasif("ECZA1", ec1_ok),
        },
        "farmazon": {
            "username": os.environ.get("FARMAZON_USERNAME", ""),
            "password": os.environ.get("FARMAZON_PASSWORD", ""),
            "active": _is_active("FARMAZON", far_ok),
            "user_pasif": _is_user_pasif("FARMAZON", far_ok),
        },
        "dna": {
            "username": os.environ.get("DNA_USERNAME", ""),
            "password": os.environ.get("DNA_PASSWORD", ""),
            "active": _is_active("DNA", dna_ok),
            "user_pasif": _is_user_pasif("DNA", dna_ok),
        },
        "eczatrend": {
            "username": os.environ.get("ECZATREND_USERNAME", ""),
            "password": os.environ.get("ECZATREND_PASSWORD", ""),
            "active": _is_active("ECZATREND", etr_ok),
            "user_pasif": _is_user_pasif("ECZATREND", etr_ok),
        },
        "eczanetakas": {
            "username": os.environ.get("ECZANETAKAS_USERNAME", ""),
            "password": os.environ.get("ECZANETAKAS_PASSWORD", ""),
            "active": _is_active("ECZANETAKAS", etk_ok),
            "user_pasif": _is_user_pasif("ECZANETAKAS", etk_ok),
        },
        "tria": {
            "host": os.environ.get("TRIA_DB_HOST", ""),
            "port": os.environ.get("TRIA_DB_PORT", "1521"),
            "sid": os.environ.get("TRIA_DB_SID", "ORCL"),
            "user": os.environ.get("TRIA_DB_USER", ""),
            "password": os.environ.get("TRIA_DB_PASSWORD", "")
        },
        "botanik": {
            "server": os.environ.get("BOTANIK_DB_SERVER", "") or bot_cfg.get("server", r".\BOTANIKSQL"),
            "database": os.environ.get("BOTANIK_DB_DATABASE", "") or bot_cfg.get("database", "eczane"),
            "user": os.environ.get("BOTANIK_DB_USER", "") or bot_cfg.get("user", "sa"),
            "password": os.environ.get("BOTANIK_DB_PASSWORD", "") or bot_cfg.get("password", "123"),
            "trusted": os.environ.get("BOTANIK_DB_TRUSTED", "false")
        },
        "tebeos": {
            "host": os.environ.get("TEBEOS_DB_HOST", ""),
            "port": str(os.environ.get("TEBEOS_DB_PORT", "5454")),
            "database": os.environ.get("TEBEOS_DB_DATABASE", "tebeos_db"),
            "user": os.environ.get("TEBEOS_DB_USER", "tebeos"),
            "password": os.environ.get("TEBEOS_DB_PASSWORD", "123")
        },
        "eczanem": {
            "server": os.environ.get("ECZANEM_SERVER", ""),
            "port": str(os.environ.get("ECZANEM_PORT", "1433")),
            "database": os.environ.get("ECZANEM_DATABASE", "eczanem"),
            "user": os.environ.get("ECZANEM_USER", "eczanem"),
            "password": os.environ.get("ECZANEM_PASSWORD", "1234")
        },
        "active_otomasyon": os.environ.get("ACTIVE_OTOMASYON", "BOTANIK")
    }


def save_credentials_to_env(new_creds: dict):
    # Önce mevcut .env değerlerinin os.environ'da yüklü olduğundan emin ol
    load_env()

    mapping = {
        ("alliance", "pharmacy_code"): "ALLIANCE_PHARMACY_CODE",
        ("alliance", "username"): "ALLIANCE_USERNAME",
        ("alliance", "password"): "ALLIANCE_PASSWORD",
        ("alliance", "active"): "ALLIANCE_ACTIVE",
        ("selcuk", "username"): "SELCUK_USERNAME",
        ("selcuk", "password"): "SELCUK_PASSWORD",
        ("selcuk", "active"): "SELCUK_ACTIVE",
        ("nevzat", "account_code"): "NEVZAT_ACCOUNT_CODE",
        ("nevzat", "username"): "NEVZAT_USERNAME",
        ("nevzat", "password"): "NEVZAT_PASSWORD",
        ("nevzat", "active"): "NEVZAT_ACTIVE",
        ("iskoop", "username"): "ISKOOP_USERNAME",
        ("iskoop", "password"): "ISKOOP_PASSWORD",
        ("iskoop", "active"): "ISKOOP_ACTIVE",
        ("bek", "username"): "BEK_USERNAME",
        ("bek", "password"): "BEK_PASSWORD",
        ("bek", "active"): "BEK_ACTIVE",
        ("ecza1", "username"): "ECZA1_USERNAME",
        ("ecza1", "password"): "ECZA1_PASSWORD",
        ("ecza1", "active"): "ECZA1_ACTIVE",
        ("farmazon", "username"): "FARMAZON_USERNAME",
        ("farmazon", "password"): "FARMAZON_PASSWORD",
        ("farmazon", "active"): "FARMAZON_ACTIVE",
        ("dna", "username"): "DNA_USERNAME",
        ("dna", "password"): "DNA_PASSWORD",
        ("dna", "active"): "DNA_ACTIVE",
        ("eczatrend", "username"): "ECZATREND_USERNAME",
        ("eczatrend", "password"): "ECZATREND_PASSWORD",
        ("eczatrend", "active"): "ECZATREND_ACTIVE",
        ("eczanetakas", "username"): "ECZANETAKAS_USERNAME",
        ("eczanetakas", "password"): "ECZANETAKAS_PASSWORD",
        ("eczanetakas", "active"): "ECZANETAKAS_ACTIVE",
        ("tria", "host"): "TRIA_DB_HOST",
        ("tria", "port"): "TRIA_DB_PORT",
        ("tria", "sid"): "TRIA_DB_SID",
        ("tria", "user"): "TRIA_DB_USER",
        ("tria", "password"): "TRIA_DB_PASSWORD",
        ("botanik", "server"): "BOTANIK_DB_SERVER",
        ("botanik", "database"): "BOTANIK_DB_DATABASE",
        ("botanik", "user"): "BOTANIK_DB_USER",
        ("botanik", "password"): "BOTANIK_DB_PASSWORD",
        ("botanik", "trusted"): "BOTANIK_DB_TRUSTED",
        ("tebeos", "host"): "TEBEOS_DB_HOST",
        ("tebeos", "port"): "TEBEOS_DB_PORT",
        ("tebeos", "database"): "TEBEOS_DB_DATABASE",
        ("tebeos", "user"): "TEBEOS_DB_USER",
        ("tebeos", "password"): "TEBEOS_DB_PASSWORD",
        ("eczanem", "server"): "ECZANEM_SERVER",
        ("eczanem", "port"): "ECZANEM_PORT",
        ("eczanem", "database"): "ECZANEM_DATABASE",
        ("eczanem", "user"): "ECZANEM_USER",
        ("eczanem", "password"): "ECZANEM_PASSWORD",
    }

    flat_updates = {}
    for (depo, field), env_var in mapping.items():
        if depo in new_creds and isinstance(new_creds[depo], dict) and field in new_creds[depo]:
            val = str(new_creds[depo][field]).strip()
            flat_updates[env_var] = val

    for depo_prefix, fields in _REQ_CHECKS.items():
        depo_key = depo_prefix.lower()
        has_all = all(bool(flat_updates.get(f, os.environ.get(f, "")).strip()) for f in fields)
        if not has_all:
            flat_updates[f"{depo_prefix}_ACTIVE"] = "0"
            flat_updates[f"{depo_prefix}_USER_PASIF"] = "0"
        else:
            if depo_key in new_creds and isinstance(new_creds[depo_key], dict):
                req_act = str(new_creds[depo_key].get("active", "1")).strip()
                req_user_pasif = str(new_creds[depo_key].get("user_pasif", "0")).strip()
                if req_act == "0" and req_user_pasif == "1":
                    flat_updates[f"{depo_prefix}_ACTIVE"] = "0"
                    flat_updates[f"{depo_prefix}_USER_PASIF"] = "1"
                else:
                    flat_updates[f"{depo_prefix}_ACTIVE"] = "1"
                    flat_updates[f"{depo_prefix}_USER_PASIF"] = "0"
            else:
                if os.environ.get(f"{depo_prefix}_USER_PASIF", "0").strip() != "1":
                    flat_updates[f"{depo_prefix}_ACTIVE"] = "1"

    if "active_otomasyon" in new_creds:
        flat_updates["ACTIVE_OTOMASYON"] = str(new_creds["active_otomasyon"]).strip()

    lines = []
    if ENV_FILE.exists():
        with open(ENV_FILE, "r", encoding="utf-8-sig") as f:
            lines = f.readlines()

    updated_keys = set()
    new_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            k, _ = stripped.split("=", 1)
            k = k.strip().lstrip("\ufeff")
            if k in flat_updates:
                new_lines.append(f"{k}={flat_updates[k]}\n")
                updated_keys.add(k)
                os.environ[k] = flat_updates[k]
                continue
        new_lines.append(line)

    for k, v in flat_updates.items():
        if k not in updated_keys:
            new_lines.append(f"{k}={v}\n")
            os.environ[k] = v

    with open(ENV_FILE, "w", encoding="utf-8") as f:
        f.writelines(new_lines)
