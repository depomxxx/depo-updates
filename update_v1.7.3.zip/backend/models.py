from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class DepoKodu(str, Enum):
    ALLIANCE = "ALLIANCE"
    SELCUK = "SELCUK"
    ISKOOP = "ISKOOP"
    BEK = "BEK"
    NEVZAT = "NEVZAT"
    ECZA1 = "ECZA1"
    FARMAZON = "FARMAZON"
    DNA = "DNA"
    ECZATREND = "ECZATREND"
    ECZANETAKAS = "ECZANETAKAS"

class StokDurumu(str, Enum):
    VAR = "VAR"
    YOK = "YOK"
    KRITIK = "KRITIK"
    BILINMIYOR = "BILINMIYOR"

class MFKademeDetay(BaseModel):
    alinan: int
    hediye: int
    mf_text: str                          # Örn: "25+1" veya "95+5"
    net_birim_maliyet: float              # Kutu başına net (KDV Hariç)
    net_birim_maliyet_kdvli: float        # Kutu başına net (KDV Dahil)
    toplam_iskonto_yuzdesi: float         # MF'nin yüzde iskonto karşılığı

class DepoUrunSarti(BaseModel):
    depo: DepoKodu
    depo_adi: str
    barkod: str
    urun_id: Optional[str] = None
    urun_adi: str
    stok_durumu: StokDurumu = StokDurumu.BILINMIYOR
    stok_adedi: Optional[int] = None
    depocu_satis_fiyati: float = 0.0      # DSF (KDV Hariç)
    perakende_satis_fiyati: float = 0.0   # PSF
    kdv_orani: float = 10.0               # % KDV
    mf_metni: str = "YOK"                 # Örn: "25+1 / 95+5"
    kademeler: List[MFKademeDetay] = Field(default_factory=list) # Tüm MF kademelerinin net hesapları
    ticari_iskonto: float = 0.0           # %
    vade_gun: int = 30                    # Gün
    net_birim_maliyet: float = 0.0        # En iyi net kutu maliyeti (KDV Hariç)
    net_birim_maliyet_kdvli: float = 0.0  # En iyi net kutu maliyeti (KDV Dahil)
    toplam_indirim_yuzdesi: float = 0.0   # MF + İskonto toplam indirim oranı %
    miad: Optional[str] = None            # Son Kullanma Tarihi / Miad (örn: "10/2027" veya "Nis.2028")
    ozel_kampanya_notu: Optional[str] = None
    soguk_zincir: bool = False            # Soğuk Zincir (+2°C / +8°C)
    kamu_iskontosu: float = 0.0           # SGK Kamu İskontosu %
    eczaci_kari: float = 0.0              # Yasal Eczacı Kâr Oranı %
    esdeger_kodu: Optional[str] = None    # SGK Eşdeğer Grubu Kodu (Örn: E187A)
    esdegerler: List[Dict[str, Any]] = Field(default_factory=list) # Eşdeğer ilaçlar
    kamu_fiyati: float = 0.0              # Kamu Satış Fiyatı (KSF)
    kamu_kari: float = 0.0                # SGK Kamu Satışında Kutu Başı Kâr
    perakende_kari: float = 0.0           # Elden / Perakende Satışında Kâr
    pazaryeri_teklifleri: List[Dict[str, Any]] = Field(default_factory=list) # Pazaryeri (Farmazon/Ecza1) tüm satıcı teklifleri ve fiyatları
    siparis_durumu: Optional[str] = None  # Bugün verilen sipariş/sepet durumu (SIPARIS_VERILDI / SEPETTE)
    siparis_depo: Optional[str] = None    # Siparişin verildiği depo
    siparis_miktar: Optional[int] = None  # Sipariş verilen kutu adedi
    siparis_masa: Optional[str] = None    # Siparişi veren bilgisayar/masa adı
    siparis_saat: Optional[str] = None    # Sipariş saati
    katilindi: bool = False               # EczaneTakas / Eczatrend teklifine bugün katılındı mı?
    katilinan_miktar: int = 0             # Katılınan toplam kutu adedi

class DepoKarsilastirmaRaporu(BaseModel):
    barkod: str
    urun_adi: str
    en_avantajli_depo: Optional[DepoKodu] = None
    en_dusuk_maliyet: Optional[float] = None
    en_dusuk_maliyet_kdvli: Optional[float] = None
    stokta_bulunan_depolar: List[DepoKodu] = Field(default_factory=list)
    sonuclar: List[DepoUrunSarti] = Field(default_factory=list)
    soguk_zincir: bool = False            # Soğuk Zincir (+2°C / +8°C)
    kamu_iskontosu: float = 0.0           # SGK Kamu İskontosu %
    eczaci_kari: float = 0.0              # Yasal Eczacı Kâr Oranı %
    psf: float = 0.0                      # Perakende Satış Fiyatı (Etiket)
    kamu_fiyati: float = 0.0              # Kamu Satış Fiyatı (KSF)
    kamu_kari: float = 0.0                # SGK Reçeteli Satışta En İyi Kutu Kârı
    perakende_kari: float = 0.0           # Elden Satışta En İyi Kutu Kârı
    esdeger_kodu: Optional[str] = None    # SGK Eşdeğer Grubu Kodu (Örn: E187A)
    esdegerler: List[Dict[str, Any]] = Field(default_factory=list) # Eşdeğer / Muadil ilaç listesi
    tria_bilgisi: Optional[Dict[str, Any]] = None # Tria Eczane Otomasyonu Stok ve Aylık Hareket Analizi
    botanik_bilgisi: Optional[Dict[str, Any]] = None # Botanik Eczane Otomasyonu Stok, Giriş & Çıkış Analizi
    otomasyon_bilgisi: Optional[Dict[str, Any]] = None # Aktif Otomasyon (Botanik / Tria) Entegre Analizi
    en_karli_muadil: Optional[Dict[str, Any]] = None # Gruptaki en kârlı muadil ilacın özeti
    muadil_kar_avantaji: float = 0.0 # Aranan ilaca kıyasla kutu başına ekstra kâr (TL)
    bugun_siparis: Optional[Dict[str, Any]] = None # Bugün eczanedeki herhangi bir bilgisayardan verilen sipariş/sepet durumu
