# -*- coding: utf-8 -*-
"""
backend/eczanem_client.py
-------------------------
Eczanem Eczane Otomasyonu (MS SQL Server) Entegrasyon İstemcisi.

Özellikler:
1. Sıfır Ayar Otomatik Ağ Keşfi (Zero-Config LAN Auto-Discovery) & Otomatik İyileştirme (Self-Healing IP):
   - Yerel ağdaki (LAN) tüm bilgisayarları Port 1433 üzerinden paralel (~1.5 sn) tarar.
   - 'eczanem' veritabanının ONLINE olduğunu ve aktif 'eczane' tablosunu doğrular (RECOVERY_PENDING olan pasif yedekleri atlar).
   - Eczane kimlik bilgilerini (Eczane Adı, Eczacı, GLN, İlçe/Şehir) ve Base64 şifreli DepoBilgi tablosundaki
     kayıtlı depo kullanıcı adı/şifrelerini otomatik çözümler.
2. Tam Matematiksel Eşleşme:
   - Raf Stoğu: urun.stok_miktar
   - Reçeteli Çıkış: satis.satis_turu IN ('RN', 'RV', 'RB')
   - Nakit / Elden Çıkış: satis.satis_turu IN ('PN', 'PB', 'PV', 'E') (Reçeteye dönüşen emanet_miktar düşülerek çift sayım önlenir)
   - Depo Alış Faturaları (Girişler): alis + alis_fatura + cari (Adet, MF, Depocu Fiyat, İskonto, Net Maliyet, Vade)
   - SGK Eşdeğer / Muadil Analizi: urun2.kamu_esdegeri & EGrup & SgkEtkin + Kamu İskontosu + Canlı Stok & Son 30 Gün Çıkış
   - Günün Çıkışları & Kritik Stok + 6 Aylık Akıllı Toplu Sipariş + Toplu Stok/Satış Haritası
"""

import os
import re
import time
import math
import base64
import socket
import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, Dict, Any, List, Tuple

try:
    import pyodbc
except ImportError:
    pyodbc = None


def _b64_decode_safe(val: Any) -> str:
    """Eczanem DepoBilgi tablosundaki Base64 alanlarını güvenli şekilde çözer."""
    if not val:
        return ""
    s = str(val).strip()
    if not s:
        return ""
    try:
        raw = base64.b64decode(s)
        for enc in ("utf-8", "cp1254", "latin1"):
            try:
                decoded = raw.decode(enc).strip()
                if decoded and all(31 < ord(c) < 127 or c in "ğıüşöçĞİÜŞÖÇ " for c in decoded):
                    return decoded
            except Exception:
                continue
    except Exception:
        pass
    return s


def _parse_float_safe(val: Any, default: float = 0.0) -> float:
    if val is None:
        return default
    if isinstance(val, (int, float)):
        return float(val)
    s = re.sub(r"[^0-9.,-]", "", str(val).strip()).replace(",", ".")
    if not s:
        return default
    try:
        return float(s)
    except Exception:
        return default


def _parse_int_safe(val: Any, default: int = 0) -> int:
    return int(round(_parse_float_safe(val, float(default))))


class EczanemSQLClient:
    """Eczanem MS SQL Server veritabanı bağlantı ve analiz sınıfı."""

    DEFAULT_CREDENTIALS: List[Tuple[str, str]] = [
        ("eczanem", "1234"),
        ("sa", "1"),
        ("sa", "1234"),
        ("sa", "sa"),
        ("sa", ""),
    ]

    def __init__(self):
        self._cached_driver: Optional[str] = None
        self._last_discovered_server: Optional[str] = None
        self._discovery_lock = False

    def _detect_odbc_driver(self) -> str:
        if self._cached_driver:
            return self._cached_driver
        if not pyodbc:
            return "SQL Server"
        try:
            drivers = pyodbc.drivers()
            preferred = [
                "ODBC Driver 18 for SQL Server",
                "ODBC Driver 17 for SQL Server",
                "SQL Server Native Client 11.0",
                "SQL Server",
            ]
            for p in preferred:
                if p in drivers:
                    self._cached_driver = p
                    return p
            if drivers:
                self._cached_driver = drivers[0]
                return drivers[0]
        except Exception:
            pass
        return "SQL Server"

    def get_config(self) -> Dict[str, str]:
        server = os.environ.get("ECZANEM_SERVER", "").strip()
        port = os.environ.get("ECZANEM_PORT", "1433").strip() or "1433"
        database = os.environ.get("ECZANEM_DATABASE", "eczanem").strip() or "eczanem"
        user = os.environ.get("ECZANEM_USER", "eczanem").strip() or "eczanem"
        password = os.environ.get("ECZANEM_PASSWORD", "1234").strip() or "1234"
        return {
            "server": server,
            "port": port,
            "database": database,
            "user": user,
            "password": password,
        }

    def _build_conn_str(self, server: str, port: str, database: str, user: str, password: str) -> str:
        driver = self._detect_odbc_driver()
        srv = server.strip()
        if "," not in srv and "\\" not in srv and port and port != "1433":
            srv = f"{srv},{port}"
        elif "," not in srv and "\\" not in srv and srv not in ("127.0.0.1", "localhost", "."):
            srv = f"{srv},{port or '1433'}"

        extra = ""
        if "Driver 18" in driver or "Driver 17" in driver:
            extra = "TrustServerCertificate=yes;Encrypt=no;"

        if not user:
            return f"DRIVER={{{driver}}};SERVER={srv};DATABASE={database};Trusted_Connection=yes;{extra}"
        return f"DRIVER={{{driver}}};SERVER={srv};DATABASE={database};UID={user};PWD={password};{extra}"

    @staticmethod
    def _get_local_subnet_ips() -> List[str]:
        """Yerel ağdaki aktif IPv4 alt ağındaki tüm aday IP'leri üretir."""
        local_ips = []
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.5)
            s.connect(("8.8.8.8", 80))
            primary_ip = s.getsockname()[0]
            s.close()
            if primary_ip and not primary_ip.startswith("127."):
                local_ips.append(primary_ip)
        except Exception:
            pass

        try:
            hostname = socket.gethostname()
            for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
                ip = info[4][0]
                if ip and not ip.startswith("127.") and ip not in local_ips:
                    local_ips.append(ip)
        except Exception:
            pass

        candidates = ["127.0.0.1"]
        seen_prefixes = set()
        for lip in local_ips:
            parts = lip.split(".")
            if len(parts) == 4:
                prefix = f"{parts[0]}.{parts[1]}.{parts[2]}"
                if prefix not in seen_prefixes:
                    seen_prefixes.add(prefix)
                    if lip not in candidates:
                        candidates.append(lip)
                    for i in range(1, 255):
                        cip = f"{prefix}.{i}"
                        if cip not in candidates:
                            candidates.append(cip)
        return candidates

    @staticmethod
    def _check_tcp_port(ip: str, port: int = 1433, timeout: float = 0.35) -> bool:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(timeout)
                return s.connect_ex((ip, port)) == 0
        except Exception:
            return False

    def _probe_eczanem_sql(self, ip: str, port: str = "1433", database: str = "eczanem") -> Optional[Dict[str, Any]]:
        """Port 1433 açık olan bir IP'de Eczanem veritabanının ONLINE ve erişilebilir olup olmadığını test eder."""
        if not pyodbc:
            return None

        cfg = self.get_config()
        cred_list: List[Tuple[str, str]] = []
        if cfg["user"]:
            cred_list.append((cfg["user"], cfg["password"]))
        for c in self.DEFAULT_CREDENTIALS:
            if c not in cred_list:
                cred_list.append(c)
        if ip in ("127.0.0.1", "localhost"):
            cred_list.append(("", ""))

        for u, p in cred_list:
            try:
                c_str = self._build_conn_str(ip, port, database, u, p)
                with pyodbc.connect(c_str, timeout=2) as conn:
                    cur = conn.cursor()
                    cur.execute("SELECT TOP 1 eczane_adi, eczaci_adi, ilce, sehir, telefon_1, sicil_no FROM eczane WITH (NOLOCK)")
                    e_row = cur.fetchone()
                    eczane_adi = str(e_row[0] or "").strip() if e_row else "ECZANEM"
                    eczaci_adi = str(e_row[1] or "").strip() if e_row else ""
                    ilce = str(e_row[2] or "").strip() if e_row else ""
                    sehir = str(e_row[3] or "").strip() if e_row else ""
                    telefon = str(e_row[4] or "").strip() if e_row else ""
                    sicil_no = str(e_row[5] or "").strip() if e_row else ""

                    gln = ""
                    try:
                        cur.execute("SELECT TOP 1 ecz_kodu FROM its WITH (NOLOCK)")
                        i_row = cur.fetchone()
                        if i_row and i_row[0]:
                            gln = str(i_row[0]).strip()
                    except Exception:
                        pass

                    cur.execute("SELECT COUNT(*) FROM urun WITH (NOLOCK)")
                    urun_sayisi = int(cur.fetchone()[0] or 0)

                    cur.execute("SELECT COUNT(*) FROM urun WITH (NOLOCK) WHERE ISNULL(stok_miktar, 0) > 0")
                    stoklu_cesit = int(cur.fetchone()[0] or 0)

                    cur.execute("SELECT ISNULL(SUM(stok_miktar), 0) FROM urun WITH (NOLOCK) WHERE ISNULL(stok_miktar, 0) > 0")
                    toplam_kutu = int(cur.fetchone()[0] or 0)

                    son_satis = ""
                    try:
                        cur.execute("SELECT CONVERT(varchar(19), MAX(satis_tarihi), 120) FROM satis WITH (NOLOCK)")
                        s_row = cur.fetchone()
                        if s_row and s_row[0]:
                            son_satis = str(s_row[0])
                    except Exception:
                        pass

                    depo_bilgileri = self._extract_depot_credentials_from_cursor(cur)

                    return {
                        "server": ip,
                        "port": port,
                        "database": database,
                        "user": u or "Windows Auth",
                        "password": p,
                        "eczane_adi": eczane_adi,
                        "eczaci_adi": eczaci_adi,
                        "ilce": ilce,
                        "sehir": sehir,
                        "telefon": telefon,
                        "sicil_no": sicil_no,
                        "gln": gln,
                        "urun_sayisi": urun_sayisi,
                        "stoklu_cesit": stoklu_cesit,
                        "toplam_kutu": toplam_kutu,
                        "son_satis_tarihi": son_satis,
                        "depo_bilgileri": depo_bilgileri,
                    }
            except Exception:
                continue
        return None

    @staticmethod
    def _extract_depot_credentials_from_cursor(cur) -> List[Dict[str, str]]:
        """Eczanem DepoBilgi tablosundaki Base64 şifreli depo hesaplarını çözer."""
        depo_list = []
        tur_map = {
            1: ("ALLIANCE", "Alliance Healthcare / Hedef"),
            2: ("SELCUK", "Selçuk Ecza Deposu"),
            3: ("NEVZAT", "Yusufpaşa / Nevzat Ecza Deposu"),
            4: ("ISKOOP", "İstanbul Ecza Koop (İSKOOP)"),
            5: ("BEK", "Bursa Ecza Koop (BEK)"),
        }
        try:
            cur.execute("SELECT Tur, Kullanici, Sifre, EczKod FROM DepoBilgi WITH (NOLOCK) ORDER BY Tur ASC")
            for row in cur.fetchall():
                tur = int(row[0] or 0)
                kullanici = _b64_decode_safe(row[1])
                sifre = _b64_decode_safe(row[2])
                ecz_kod = _b64_decode_safe(row[3])
                if not kullanici and not ecz_kod:
                    continue
                depo_kodu, depo_adi = tur_map.get(tur, (f"DEPO_{tur}", f"Depo (Tür {tur})"))
                depo_list.append({
                    "tur": tur,
                    "depo_kodu": depo_kodu,
                    "mapped_depo": depo_kodu,
                    "depo_adi": depo_adi,
                    "kullanici": kullanici,
                    "username": kullanici,
                    "sifre": sifre,
                    "password": sifre,
                    "eczane_kodu": ecz_kod,
                    "sube_kodu": ecz_kod,
                })
        except Exception:
            pass
        return depo_list

    def discover_eczanem_host(self, save_to_env: bool = True) -> Dict[str, Any]:
        """
        Yerel ağdaki (LAN) tüm bilgisayarları Port 1433 üzerinden paralel tarayarak
        ONLINE durumdaki Eczanem SQL Server ana bilgisayarını otomatik bulur.
        """
        t0 = time.time()
        cfg = self.get_config()
        port_int = int(cfg["port"] if cfg["port"].isdigit() else 1433)

        priority_ips = []
        for p_ip in (cfg["server"], self._last_discovered_server, "127.0.0.1"):
            if p_ip:
                clean_ip = p_ip.split(",")[0].strip()
                if clean_ip and clean_ip not in priority_ips:
                    priority_ips.append(clean_ip)

        all_ips = self._get_local_subnet_ips()
        scan_ips = priority_ips + [ip for ip in all_ips if ip not in priority_ips]

        open_sql_ips: List[str] = []
        with ThreadPoolExecutor(max_workers=64) as pool:
            fut_map = {pool.submit(self._check_tcp_port, ip, port_int, 0.35): ip for ip in scan_ips}
            for fut in as_completed(fut_map):
                ip = fut_map[fut]
                try:
                    if fut.result():
                        open_sql_ips.append(ip)
                except Exception:
                    pass

        open_sql_ips.sort(key=lambda x: (0 if x in priority_ips else 1, x))

        found_servers: List[Dict[str, Any]] = []
        for ip in open_sql_ips:
            info = self._probe_eczanem_sql(ip, str(port_int), cfg["database"])
            if info:
                found_servers.append(info)

        if found_servers:
            found_servers.sort(key=lambda s: (s.get("son_satis_tarihi") or "", s.get("urun_sayisi") or 0), reverse=True)
            best = found_servers[0]
            self._last_discovered_server = best["server"]

            if save_to_env:
                os.environ["ECZANEM_SERVER"] = best["server"]
                os.environ["ECZANEM_PORT"] = str(best["port"])
                os.environ["ECZANEM_DATABASE"] = best["database"]
                if best.get("user") and best["user"] != "Windows Auth":
                    os.environ["ECZANEM_USER"] = best["user"]
                    os.environ["ECZANEM_PASSWORD"] = best["password"]
                try:
                    from backend.config_manager import save_credentials_to_env
                    save_credentials_to_env({
                        "eczanem": {
                            "server": best["server"],
                            "port": str(best["port"]),
                            "database": best["database"],
                            "user": os.environ.get("ECZANEM_USER", "eczanem"),
                            "password": os.environ.get("ECZANEM_PASSWORD", "1234"),
                        }
                    })
                except Exception:
                    pass

            return {
                "success": True,
                "found": True,
                "host": best["server"],
                "elapsed_ms": int((time.time() - t0) * 1000),
                "open_sql_hosts": open_sql_ips,
                "all_found": found_servers,
                "pharmacy": {
                    "eczane_adi": best.get("eczane_adi", ""),
                    "eczaci": best.get("eczaci_adi", ""),
                    "gln": best.get("gln", ""),
                    "ilce": best.get("ilce", ""),
                    "sehir": best.get("sehir", ""),
                    "telefon": best.get("telefon", ""),
                },
                "pharmacy_info": {
                    "pharmacy_name": best.get("eczane_adi", ""),
                    "pharmacist_name": best.get("eczaci_adi", ""),
                    "gln_no": best.get("gln", ""),
                    "phone": best.get("telefon", ""),
                    "city": f"{best.get('ilce', '')} / {best.get('sehir', '')}".strip(" /"),
                },
                "saved_depots": best.get("depo_bilgileri", []),
                "depot_credentials": best.get("depo_bilgileri", []),
                **best,
                "message": (
                    f"Eczanem sunucusu ({best['server']}) otomatik bulundu! "
                    f"{best['eczane_adi']} ({best['ilce']}/{best['sehir']}) — "
                    f"{best['urun_sayisi']:,} ürün kartı, {best['stoklu_cesit']:,} stoklu çeşit."
                ),
            }

        return {
            "success": False,
            "found": False,
            "elapsed_ms": int((time.time() - t0) * 1000),
            "open_sql_hosts": open_sql_ips,
            "message": (
                f"Ağda {len(open_sql_ips)} adet SQL Server ({', '.join(open_sql_ips) or 'yok'}) tarandı ancak "
                f"ONLINE durumda 'eczanem' veritabanı bulunamadı."
            ),
        }

    def get_connection(self, timeout: int = 4):
        """
        Eczanem MS SQL Server veritabanına pyodbc bağlantısı açar.
        Eğer sunucu IP'si boşsa veya IP değişmişse ağda otomatik keşfedip bağlanır!
        """
        if not pyodbc:
            raise RuntimeError("pyodbc modülü yüklü değil.")

        cfg = self.get_config()
        server = cfg["server"] or self._last_discovered_server or ""

        if server:
            try:
                conn_str = self._build_conn_str(server, cfg["port"], cfg["database"], cfg["user"], cfg["password"])
                return pyodbc.connect(conn_str, timeout=timeout)
            except Exception:
                pass

        if not self._discovery_lock:
            self._discovery_lock = True
            try:
                disc = self.discover_eczanem_host(save_to_env=True)
                if disc.get("found") and disc.get("server"):
                    new_cfg = self.get_config()
                    conn_str = self._build_conn_str(
                        disc["server"],
                        str(disc.get("port") or new_cfg["port"]),
                        disc.get("database") or new_cfg["database"],
                        new_cfg["user"],
                        new_cfg["password"],
                    )
                    return pyodbc.connect(conn_str, timeout=timeout)
            finally:
                self._discovery_lock = False

        raise RuntimeError(
            f"Eczanem MS SQL veritabanına bağlanılamadı (Sunucu: {server or 'Otomatik Arama Başarısız'})."
        )

    def ping(
        self,
        server: Optional[str] = None,
        port: Optional[str] = None,
        database: Optional[str] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Eczanem MS SQL bağlantısını test eder ve özet eczane/stok/satış istatistiklerini döndürür."""
        cfg = self.get_config()
        if server is not None and server.strip():
            cfg["server"] = server.strip()
        if port is not None and str(port).strip():
            cfg["port"] = str(port).strip()
        if database is not None and database.strip():
            cfg["database"] = database.strip()
        if user is not None and user.strip():
            cfg["user"] = user.strip()
        if password is not None and password != "":
            cfg["password"] = password

        try:
            if server and server.strip():
                conn_ctx = pyodbc.connect(
                    self._build_conn_str(cfg["server"], cfg["port"], cfg["database"], cfg["user"], cfg["password"]),
                    timeout=4,
                )
            else:
                conn_ctx = self.get_connection(timeout=4)
            with conn_ctx as conn:
                cur = conn.cursor()
                if not cfg["server"]:
                    cfg = self.get_config()

                cur.execute("SELECT TOP 1 eczane_adi, eczaci_adi, ilce, sehir, telefon_1 FROM eczane WITH (NOLOCK)")
                erow = cur.fetchone()
                eczane_adi = str(erow[0] or "").strip() if erow else "ECZANEM"
                eczaci_adi = str(erow[1] or "").strip() if erow else ""
                ilce = str(erow[2] or "").strip() if erow else ""
                sehir = str(erow[3] or "").strip() if erow else ""

                gln = ""
                try:
                    cur.execute("SELECT TOP 1 ecz_kodu FROM its WITH (NOLOCK)")
                    irow = cur.fetchone()
                    if irow and irow[0]:
                        gln = str(irow[0]).strip()
                except Exception:
                    pass

                cur.execute("SELECT COUNT(*) FROM urun WITH (NOLOCK)")
                urun_count = int(cur.fetchone()[0] or 0)

                cur.execute("SELECT COUNT(*) FROM urun WITH (NOLOCK) WHERE ISNULL(stok_miktar, 0) > 0")
                stoklu_count = int(cur.fetchone()[0] or 0)

                cur.execute("SELECT ISNULL(SUM(stok_miktar), 0) FROM urun WITH (NOLOCK) WHERE ISNULL(stok_miktar, 0) > 0")
                toplam_kutu = int(cur.fetchone()[0] or 0)

                cur.execute("""
                    SELECT COUNT(*) FROM satis WITH (NOLOCK)
                    WHERE satis_tarihi >= CAST(GETDATE() AS DATE)
                      AND ISNULL(silindi, '') NOT IN ('1', 'E')
                      AND ISNULL(deneme, '') NOT IN ('1', 'E')
                      AND ISNULL(cikar, 0) = 0
                """)
                bugun_satis = int(cur.fetchone()[0] or 0)

                depo_bilgileri = self._extract_depot_credentials_from_cursor(cur)

                return {
                    "success": True,
                    "connected": True,
                    "kaynak": "ECZANEM",
                    "otomasyon_adi": "Eczanem Otomasyon (MS SQL)",
                    "host": f"{cfg['server']},{cfg['port']} ({cfg['database']})",
                    "server": cfg["server"],
                    "port": cfg["port"],
                    "database": cfg["database"],
                    "eczane_adi": eczane_adi,
                    "eczaci_adi": eczaci_adi,
                    "ilce": ilce,
                    "sehir": sehir,
                    "gln": gln,
                    "pharmacy": {
                        "eczane_adi": eczane_adi,
                        "eczaci": eczaci_adi,
                        "gln": gln,
                        "ilce": ilce,
                        "sehir": sehir,
                    },
                    "product_count": urun_count,
                    "stoklu_cesit": stoklu_count,
                    "toplam_kutu": toplam_kutu,
                    "bugun_satis_adedi": bugun_satis,
                    "depo_bilgileri": depo_bilgileri,
                    "saved_depots": depo_bilgileri,
                    "message": (
                        f"Eczanem MS SQL bağlantısı başarılı! "
                        f"🏥 {eczane_adi} ({ilce}/{sehir}) | GLN: {gln} | "
                        f"📦 {urun_count:,} ürün kartı ({stoklu_count:,} stoklu çeşit, {toplam_kutu:,} kutu) | "
                        f"🔥 Bugün {bugun_satis} işlem."
                    ),
                }
        except Exception as e:
            cfg = self.get_config()
            return {
                "success": False,
                "connected": False,
                "kaynak": "ECZANEM",
                "otomasyon_adi": "Eczanem Otomasyon (MS SQL)",
                "host": f"{cfg['server'] or 'Bulunamadı'}:{cfg['port']}/{cfg['database']}",
                "error": str(e),
                "message": f"Eczanem MS SQL bağlantı hatası: {str(e)}",
            }

    def import_saved_credentials_to_farma_radar(self) -> Dict[str, Any]:
        """
        Eczanem veritabanındaki (eczane, its ve DepoBilgi tabloları) eczane kimlik bilgilerini
        ve Base64 çözümlenmiş depo şifrelerini (Alliance/Hedef, Selçuk vb.) okur ve döndürür.
        """
        try:
            with self.get_connection(timeout=4) as conn:
                cur = conn.cursor()
                cur.execute("SELECT TOP 1 eczane_adi, eczaci_adi, ilce, sehir, telefon_1 FROM eczane WITH (NOLOCK)")
                erow = cur.fetchone()
                eczane_adi = str(erow[0] or "").strip() if erow else ""
                eczaci_adi = str(erow[1] or "").strip() if erow else ""
                ilce = str(erow[2] or "").strip() if erow else ""
                sehir = str(erow[3] or "").strip() if erow else ""

                gln = ""
                try:
                    cur.execute("SELECT TOP 1 ecz_kodu FROM its WITH (NOLOCK)")
                    irow = cur.fetchone()
                    if irow and irow[0]:
                        gln = str(irow[0]).strip()
                except Exception:
                    pass

                depolar = self._extract_depot_credentials_from_cursor(cur)
                return {
                    "success": True,
                    "eczane_adi": eczane_adi,
                    "eczaci_adi": eczaci_adi,
                    "ilce": ilce,
                    "sehir": sehir,
                    "gln": gln,
                    "depolar": depolar,
                }
        except Exception as e:
            return {"success": False, "error": str(e), "depolar": []}

    def _find_product_row(self, cur, query: str, barcode: str = "") -> Optional[Tuple]:
        """
        Eczanem `urun`, `urun_barkod` ve `urun2` tablolarında barkod, kanonik EAN, urun_id veya isimle
        en doğru ürün kartını bulur.
        Dönen tuple:
        (u.id, u.urun_adi, u.stok_miktar, u.fiyati, u.kamu_fiyati,
         u2.kdv, u2.kurum_iskonto_alis, u2.ticari_iskonto,
         u2.kamu_esdegeri, u2.EGrup, u2.SgkEtkin, matched_barcode)
        """
        q = str(query or "").strip()
        bc = str(barcode or "").strip()

        bc_candidates: List[str] = []
        for cand in (bc, q):
            if cand and cand.isdigit() and len(cand) >= 8:
                if cand not in bc_candidates:
                    bc_candidates.append(cand)
                if len(cand) == 14 and cand.startswith("0"):
                    c13 = cand[1:]
                    if c13 not in bc_candidates:
                        bc_candidates.append(c13)
                elif len(cand) == 13:
                    c14 = "0" + cand
                    if c14 not in bc_candidates:
                        bc_candidates.append(c14)

        if bc_candidates:
            try:
                from backend.catalog import catalog
                for c_in in list(bc_candidates):
                    can = catalog.resolve_canonical_barcode(c_in)
                    if can and can not in bc_candidates:
                        bc_candidates.append(can)
                    cat_p = catalog.get_by_barcode(c_in)
                    if cat_p:
                        for ab in (cat_p.get("all_barcodes") or []):
                            ab_s = str(ab or "").strip()
                            if ab_s and ab_s not in bc_candidates:
                                bc_candidates.append(ab_s)
            except Exception:
                pass

        # 1. Barkod ile ara (urun_barkod)
        if bc_candidates:
            ph = ",".join("?" for _ in bc_candidates)
            cur.execute(f"""
                SELECT TOP 1
                    u.id,
                    RTRIM(LTRIM(ISNULL(u.urun_adi, ''))) AS urun_adi,
                    ISNULL(u.stok_miktar, 0) AS stok_miktar,
                    ISNULL(u.fiyati, 0) AS psf,
                    ISNULL(u.kamu_fiyati, 0) AS ksf,
                    ISNULL(u2.kdv, '10') AS kdv,
                    ISNULL(u2.kurum_iskonto_alis, 0) AS kamu_isk,
                    ISNULL(u2.ticari_iskonto, 0) AS tic_isk,
                    RTRIM(LTRIM(ISNULL(u2.kamu_esdegeri, ''))) AS kamu_esdegeri,
                    RTRIM(LTRIM(ISNULL(u2.EGrup, ''))) AS egrup,
                    RTRIM(LTRIM(ISNULL(u2.SgkEtkin, ''))) AS sgketkin,
                    RTRIM(LTRIM(ISNULL(ub.barkod, ''))) AS barkod
                FROM urun u WITH (NOLOCK)
                JOIN urun_barkod ub WITH (NOLOCK) ON u.id = ub.urun_id
                LEFT JOIN urun2 u2 WITH (NOLOCK) ON u.id = u2.urun_id
                WHERE RTRIM(LTRIM(ub.barkod)) IN ({ph})
                ORDER BY
                    ISNULL(u.stok_miktar, 0) DESC,
                    ISNULL(u.statu, 1) DESC,
                    u.id DESC
            """, tuple(bc_candidates))
            row = cur.fetchone()
            if row:
                return row

        # 2. urun.id ile ara (eğer kısa rakamsa)
        if q.isdigit() and len(q) < 8:
            cur.execute("""
                SELECT TOP 1
                    u.id,
                    RTRIM(LTRIM(ISNULL(u.urun_adi, ''))) AS urun_adi,
                    ISNULL(u.stok_miktar, 0) AS stok_miktar,
                    ISNULL(u.fiyati, 0) AS psf,
                    ISNULL(u.kamu_fiyati, 0) AS ksf,
                    ISNULL(u2.kdv, '10') AS kdv,
                    ISNULL(u2.kurum_iskonto_alis, 0) AS kamu_isk,
                    ISNULL(u2.ticari_iskonto, 0) AS tic_isk,
                    RTRIM(LTRIM(ISNULL(u2.kamu_esdegeri, ''))) AS kamu_esdegeri,
                    RTRIM(LTRIM(ISNULL(u2.EGrup, ''))) AS egrup,
                    RTRIM(LTRIM(ISNULL(u2.SgkEtkin, ''))) AS sgketkin,
                    ISNULL((
                        SELECT TOP 1 RTRIM(LTRIM(ub2.barkod))
                        FROM urun_barkod ub2 WITH (NOLOCK)
                        WHERE ub2.urun_id = u.id AND ub2.barkod IS NOT NULL AND RTRIM(LTRIM(ub2.barkod)) <> ''
                        ORDER BY ub2.sira_no ASC
                    ), '') AS barkod
                FROM urun u WITH (NOLOCK)
                LEFT JOIN urun2 u2 WITH (NOLOCK) ON u.id = u2.urun_id
                WHERE u.id = ?
            """, (int(q),))
            row = cur.fetchone()
            if row:
                return row

        # 3. Ürün adı ile ara (Tam eşleşme, sonra başlangıç, sonra parça parça)
        name_q = q if (not q.isdigit() or len(q) < 8) else ""
        if name_q:
            tr_q = name_q.replace("i", "İ").replace("ı", "I").upper()
            cur.execute("""
                SELECT TOP 1
                    u.id,
                    RTRIM(LTRIM(ISNULL(u.urun_adi, ''))) AS urun_adi,
                    ISNULL(u.stok_miktar, 0) AS stok_miktar,
                    ISNULL(u.fiyati, 0) AS psf,
                    ISNULL(u.kamu_fiyati, 0) AS ksf,
                    ISNULL(u2.kdv, '10') AS kdv,
                    ISNULL(u2.kurum_iskonto_alis, 0) AS kamu_isk,
                    ISNULL(u2.ticari_iskonto, 0) AS tic_isk,
                    RTRIM(LTRIM(ISNULL(u2.kamu_esdegeri, ''))) AS kamu_esdegeri,
                    RTRIM(LTRIM(ISNULL(u2.EGrup, ''))) AS egrup,
                    RTRIM(LTRIM(ISNULL(u2.SgkEtkin, ''))) AS sgketkin,
                    ISNULL((
                        SELECT TOP 1 RTRIM(LTRIM(ub2.barkod))
                        FROM urun_barkod ub2 WITH (NOLOCK)
                        WHERE ub2.urun_id = u.id AND ub2.barkod IS NOT NULL AND RTRIM(LTRIM(ub2.barkod)) <> ''
                        ORDER BY ub2.sira_no ASC
                    ), '') AS barkod
                FROM urun u WITH (NOLOCK)
                LEFT JOIN urun2 u2 WITH (NOLOCK) ON u.id = u2.urun_id
                WHERE u.urun_adi LIKE ? OR u.urun_adi LIKE ?
                ORDER BY
                    CASE WHEN u.urun_adi LIKE ? OR u.urun_adi LIKE ? THEN 0 ELSE 1 END,
                    ISNULL(u.stok_miktar, 0) DESC,
                    ISNULL(u.statu, 1) DESC,
                    u.id DESC
            """, (f"%{name_q}%", f"%{tr_q}%", f"{name_q}%", f"{tr_q}%"))
            row = cur.fetchone()
            if row:
                return row

            # Eczanem'de kısaltmalı kayıtlı olabilir (örn: "MAJEZIK 100 MG 15 FILM TABLET" -> "MAJEZİK 100 MG 15 FTB")
            tokens = [t for t in re.split(r"\s+", tr_q) if len(t) >= 2 and t not in ("TABLET", "FILM", "FİLM", "KAPSUL", "KAPSÜL")]
            if len(tokens) >= 2:
                first_tok = tokens[0]
                second_tok = tokens[1]
                cur.execute("""
                    SELECT TOP 1
                        u.id,
                        RTRIM(LTRIM(ISNULL(u.urun_adi, ''))) AS urun_adi,
                        ISNULL(u.stok_miktar, 0) AS stok_miktar,
                        ISNULL(u.fiyati, 0) AS psf,
                        ISNULL(u.kamu_fiyati, 0) AS ksf,
                        ISNULL(u2.kdv, '10') AS kdv,
                        ISNULL(u2.kurum_iskonto_alis, 0) AS kamu_isk,
                        ISNULL(u2.ticari_iskonto, 0) AS tic_isk,
                        RTRIM(LTRIM(ISNULL(u2.kamu_esdegeri, ''))) AS kamu_esdegeri,
                        RTRIM(LTRIM(ISNULL(u2.EGrup, ''))) AS egrup,
                        RTRIM(LTRIM(ISNULL(u2.SgkEtkin, ''))) AS sgketkin,
                        ISNULL((
                            SELECT TOP 1 RTRIM(LTRIM(ub2.barkod))
                            FROM urun_barkod ub2 WITH (NOLOCK)
                            WHERE ub2.urun_id = u.id AND ub2.barkod IS NOT NULL AND RTRIM(LTRIM(ub2.barkod)) <> ''
                            ORDER BY ub2.sira_no ASC
                        ), '') AS barkod
                    FROM urun u WITH (NOLOCK)
                    LEFT JOIN urun2 u2 WITH (NOLOCK) ON u.id = u2.urun_id
                    WHERE (u.urun_adi LIKE ? OR u.urun_adi LIKE ?)
                      AND u.urun_adi LIKE ?
                    ORDER BY
                        ISNULL(u.stok_miktar, 0) DESC,
                        ISNULL(u.statu, 1) DESC,
                        u.id DESC
                """, (f"{first_tok}%", f"{first_tok.replace('İ', 'I')}%", f"%{second_tok}%"))
                row = cur.fetchone()
                if row:
                    return row

        return None

    def get_product_vat(self, barcode_or_code: str) -> Optional[float]:
        """Ürünün Eczanem `urun2` tablosundaki resmi KDV oranını döndürür."""
        q = str(barcode_or_code or "").strip()
        if not q:
            return None
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                row = self._find_product_row(cur, q, barcode=q if q.isdigit() else "")
                if row and row[5] is not None:
                    v = _parse_float_safe(row[5], 0.0)
                    if v > 0:
                        return v
        except Exception as e:
            print(f"[Eczanem] get_product_vat hatası: {e}")
        return None

    def get_product_analysis(self, query: str, barcode: str = "") -> Dict[str, Any]:
        """
        Eczanem MS SQL veritabanından ürünün:
        - Anlık Raf Stoğunu (urun.stok_miktar)
        - Son 6 Aylık Ay-Ay Reçeteli (RN, RV, RB) ve Nakit/Elden (PN, PB, PV, E - emanet_miktar) çıkışlarını
        - Son 6 Depo Alış Faturasını (alis + alis_fatura + cari: Adet, MF, Depocu Fiyat, Net Maliyet, Fatura No)
        - Kalan Stok Gün ve Akıllı Sipariş Önerisini
        tam eşleşmeyle döndürür.
        """
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                prow = self._find_product_row(cur, query, barcode=barcode)
                if not prow:
                    return {
                        "found": False,
                        "connected": True,
                        "kaynak": "ECZANEM",
                        "otomasyon_adi": "Eczanem Otomasyon",
                        "message": f"'{query}' Eczanem veritabanında bulunamadı.",
                    }

                u_id = int(prow[0])
                u_adi = str(prow[1] or "").strip()
                stok = int(prow[2] or 0)
                psf = round(_parse_float_safe(prow[3], 0.0), 2)
                ksf = round(_parse_float_safe(prow[4], 0.0), 2)
                kdv_oran = _parse_float_safe(prow[5], 10.0)
                kamu_isk = round(_parse_float_safe(prow[6], 0.0), 2)
                esdeger_kodu = str(prow[8] or prow[9] or prow[10] or "").strip()
                matched_bc = str(prow[11] or barcode or "").strip()

                # Aynı urun_id'nin tüm barkodlarını çek
                cur.execute("""
                    SELECT RTRIM(LTRIM(barkod))
                    FROM urun_barkod WITH (NOLOCK)
                    WHERE urun_id = ? AND barkod IS NOT NULL AND RTRIM(LTRIM(barkod)) <> ''
                    ORDER BY sira_no ASC
                """, (u_id,))
                all_bcs = [str(r[0]).strip() for r in cur.fetchall() if r and r[0]]
                final_barcode = matched_bc or (all_bcs[0] if all_bcs else "")
                for b_item in all_bcs:
                    if b_item.isdigit() and len(b_item) == 13 and not b_item.startswith(("8690000", "9999")):
                        final_barcode = b_item
                        break

                if final_barcode:
                    try:
                        from backend.catalog import catalog
                        catalog.update_product_live_stock(final_barcode, stok, source="ECZANEM")
                    except Exception:
                        pass

                # 2. Son 6 Takvim Ayı Reçeteli ve Nakit Çıkışlar (satis + satis_detay)
                ay_isimleri = {
                    "01": "Ocak", "02": "Şubat", "03": "Mart", "04": "Nisan",
                    "05": "Mayıs", "06": "Haziran", "07": "Temmuz", "08": "Ağustos",
                    "09": "Eylül", "10": "Ekim", "11": "Kasım", "12": "Aralık",
                }
                today = datetime.date.today()
                start_m = today.month - 5
                start_y = today.year
                while start_m <= 0:
                    start_m += 12
                    start_y -= 1
                start_date_str = f"{start_y}-{start_m:02d}-01"

                cur.execute("""
                    SELECT
                        CONVERT(varchar(7), s.satis_tarihi, 120) AS YM,
                        SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN', 'RV', 'RB') THEN ISNULL(sd.satis_miktar, 0) ELSE 0 END) AS ReceteliAdet,
                        SUM(CASE WHEN RTRIM(s.satis_turu) IN ('PN', 'PB', 'PV', 'E') THEN ISNULL(sd.satis_miktar, 0) ELSE 0 END)
                        - SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN', 'RV', 'RB') THEN ISNULL(sd.emanet_miktar, 0) ELSE 0 END) AS NakitAdet
                    FROM satis_detay sd WITH (NOLOCK)
                    JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                    WHERE sd.urun_id = ?
                      AND s.satis_tarihi >= ?
                      AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                      AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                      AND ISNULL(s.cikar, 0) = 0
                    GROUP BY CONVERT(varchar(7), s.satis_tarihi, 120)
                """, (u_id, start_date_str))

                recete_map: Dict[str, int] = {}
                elden_map: Dict[str, int] = {}
                for r_ym, r_rec, r_nak in cur.fetchall():
                    if not r_ym:
                        continue
                    ym_s = str(r_ym).strip()
                    recete_map[ym_s] = max(0, int(r_rec or 0))
                    elden_map[ym_s] = max(0, int(r_nak or 0))

                aylik_cikislar = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    m_str = f"{m_calc:02d}"
                    ym_key = f"{y_calc}-{m_str}"
                    is_current_month = (i == 0)
                    suffix = " (Bu Ay)" if is_current_month else ""
                    ay_label = f"{ay_isimleri.get(m_str, m_str)} '{str(y_calc)[-2:]}{suffix}"

                    nakit_val = elden_map.get(ym_key, 0)
                    recete_val = recete_map.get(ym_key, 0)
                    top_cikis = nakit_val + recete_val

                    aylik_cikislar.append({
                        "ay": ym_key,
                        "label": ay_label,
                        "is_current": is_current_month,
                        "nakit": nakit_val,
                        "receteli": recete_val,
                        "toplam": top_cikis,
                    })

                gecmis_aylar = aylik_cikislar[:-1] if len(aylik_cikislar) > 1 else aylik_cikislar
                gecmis_sum = sum(x["toplam"] for x in gecmis_aylar)
                if gecmis_sum > 0:
                    ort_aylik = round(gecmis_sum / max(1, len(gecmis_aylar)), 1)
                else:
                    ort_aylik = round(sum(x["toplam"] for x in aylik_cikislar) / max(1, len(aylik_cikislar)), 1)

                ort_gunluk = round(ort_aylik / 30.0, 2)
                if ort_gunluk > 0:
                    kalan_gun = int(round(stok / ort_gunluk))
                else:
                    kalan_gun = 999 if stok > 0 else 0

                toplam_6_aylik_cikis = sum(x["toplam"] for x in aylik_cikislar)
                is_hareketsiz = (stok <= 0 and toplam_6_aylik_cikis == 0)

                if is_hareketsiz:
                    stok_status = "HAREKET YOK"
                    stok_status_color = "slate"
                    onerilen_siparis = 1
                elif stok <= 0:
                    stok_status = "TÜKENDİ"
                    stok_status_color = "red"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(1, hedef_stok - stok)
                elif kalan_gun < 10:
                    stok_status = "KRİTİK AZ"
                    stok_status_color = "amber"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                elif kalan_gun <= 30:
                    stok_status = "YETERLİ"
                    stok_status_color = "emerald"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                else:
                    stok_status = "YÜKSEK STOK"
                    stok_status_color = "sky"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)

                # 3. Son Alış Faturaları / Depo Girişleri (alis + alis_fatura + cari)
                cur.execute("""
                    SELECT TOP 6
                        CONVERT(varchar(10), ISNULL(a.alis_tarihi, af.fatura_tarihi), 120) AS Tarih,
                        RTRIM(LTRIM(ISNULL(c.kurum_adi, 'DEPO'))) AS Depo,
                        ISNULL(a.alis_miktar, 0) AS Adet,
                        ISNULL(a.mal_fazlasi, 0) AS MF,
                        ISNULL(a.depocu_fiyat_h, 0) AS BirimFiyat,
                        ISNULL(a.birim_maliyet, 0) AS Maliyet,
                        RTRIM(LTRIM(ISNULL(af.fatura_no, ''))) AS FaturaNo,
                        ISNULL(a.iskonto_yuzde_1, 0) AS Isk1,
                        ISNULL(a.ticari_iskonto_yuzde, 0) AS TicIsk,
                        ISNULL(a.vade_gun, '0') AS VadeGun
                    FROM alis a WITH (NOLOCK)
                    LEFT JOIN alis_fatura af WITH (NOLOCK) ON a.alis_sira = af.alis_sira
                    LEFT JOIN cari c WITH (NOLOCK) ON ISNULL(a.kurum_id, af.kurum_id) = c.id
                    WHERE a.urun_id = ?
                      AND ISNULL(af.IptalFat, '') NOT IN ('1', 'E')
                    ORDER BY ISNULL(a.alis_tarihi, af.fatura_tarihi) DESC, a.alis_sira DESC
                """, (u_id,))
                giris_rows = cur.fetchall()

                son_girisler = []
                toplam_giren_kutu = 0
                for gr in giris_rows:
                    g_adet = int(gr[2] or 0)
                    g_mf = int(gr[3] or 0)
                    raw_depocu = _parse_float_safe(gr[4], 0.0)
                    g_maliyet = round(_parse_float_safe(gr[5], 0.0), 2)
                    if g_adet > 1 and raw_depocu > g_maliyet * 1.6:
                        g_birim = round(raw_depocu / g_adet, 2)
                    else:
                        g_birim = round(raw_depocu, 2)
                    top_satir = g_adet + g_mf
                    toplam_giren_kutu += top_satir
                    son_girisler.append({
                        "tarih": str(gr[0] or ""),
                        "depo": str(gr[1] or "DEPO"),
                        "adet": g_adet,
                        "mf": g_mf,
                        "toplam_adet": top_satir,
                        "birim_fiyat": g_birim,
                        "maliyet": g_maliyet,
                        "fatura_no": str(gr[6] or ""),
                        "iskonto": round(_parse_float_safe(gr[7], 0.0) + _parse_float_safe(gr[8], 0.0), 2),
                        "vade_gun": _parse_int_safe(gr[9], 0),
                    })

                return {
                    "found": True,
                    "connected": True,
                    "kaynak": "ECZANEM",
                    "otomasyon_adi": "Eczanem Otomasyon",
                    "urun_id": u_id,
                    "mal_id": u_id,
                    "mal_kodu": str(u_id),
                    "urun_adi": u_adi,
                    "mal_adi": u_adi,
                    "barkod": final_barcode,
                    "all_barcodes": all_bcs,
                    "psf": psf,
                    "ksf": ksf,
                    "kamu_iskontosu": kamu_isk,
                    "kdv_orani": kdv_oran,
                    "esdeger_kodu": esdeger_kodu,
                    "stok": stok,
                    "stok_depo": 0,
                    "stok_raf": stok,
                    "stok_acik": 0,
                    "kalan_gun": kalan_gun,
                    "stok_status": stok_status,
                    "stok_status_color": stok_status_color,
                    "ort_aylik_cikis": ort_aylik,
                    "ort_gunluk_cikis": ort_gunluk,
                    "onerilen_siparis": onerilen_siparis,
                    "aylik_cikislar": aylik_cikislar,
                    "son_girisler": son_girisler,
                    "toplam_giren_kutu": toplam_giren_kutu,
                    "hareketsiz_kart": is_hareketsiz,
                    "hareketsiz_aciklama": (
                        "Eczanenizde bu ürün için son 6 aydır çıkış hareketi bulunmuyor. "
                        "Depo ve piyasa koşulları doğrudan üretici EAN barkodu üzerinden sunulmaktadır."
                    ),
                }
        except Exception as e:
            return {
                "found": False,
                "connected": False,
                "kaynak": "ECZANEM",
                "error": str(e),
                "message": f"Eczanem stok ve hareket sorgusu hatası: {str(e)}",
            }

    def get_critical_stock_sales(
        self, limit: int = 0, max_stock_threshold: int = 5, max_stock_days: int = 21
    ) -> List[Dict[str, Any]]:
        """
        Bugün Eczanem'den çıkışı olan (reçeteli veya nakit/elden) ve stoğu azalan/kritik ürünleri listeler.
        """
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                # 1. Bugün çıkışı olan ürünler
                cur.execute("""
                    SELECT
                        sd.urun_id,
                        SUM(
                            CASE
                                WHEN RTRIM(s.satis_turu) IN ('RN', 'RV', 'RB', 'PN', 'PB', 'PV', 'E') THEN ISNULL(sd.satis_miktar, 0)
                                ELSE 0
                            END
                        )
                        - SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN', 'RV', 'RB') THEN ISNULL(sd.emanet_miktar, 0) ELSE 0 END) AS BugunAdet
                    FROM satis_detay sd WITH (NOLOCK)
                    JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                    WHERE s.satis_tarihi >= CAST(GETDATE() AS DATE)
                      AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                      AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                      AND ISNULL(s.cikar, 0) = 0
                      AND sd.urun_id IS NOT NULL
                    GROUP BY sd.urun_id
                """)
                today_rows = cur.fetchall()
                if not today_rows:
                    return []

                today_map = {int(r[0]): max(1, int(r[1] or 0)) for r in today_rows if r[0] and int(r[1] or 0) > 0}
                urun_ids = list(today_map.keys())
                if not urun_ids:
                    return []

                placeholders = ",".join("?" * len(urun_ids))

                # 2. Son 30 günün çıkışları
                cur.execute(f"""
                    SELECT
                        sd.urun_id,
                        SUM(
                            CASE
                                WHEN RTRIM(s.satis_turu) IN ('RN', 'RV', 'RB', 'PN', 'PB', 'PV', 'E') THEN ISNULL(sd.satis_miktar, 0)
                                ELSE 0
                            END
                        )
                        - SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN', 'RV', 'RB') THEN ISNULL(sd.emanet_miktar, 0) ELSE 0 END) AS AyAdet
                    FROM satis_detay sd WITH (NOLOCK)
                    JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                    WHERE s.satis_tarihi >= DATEADD(day, -30, GETDATE())
                      AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                      AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                      AND ISNULL(s.cikar, 0) = 0
                      AND sd.urun_id IN ({placeholders})
                    GROUP BY sd.urun_id
                """, urun_ids)
                month_map = {int(r[0]): max(0, int(r[1] or 0)) for r in cur.fetchall() if r[0]}

                # 3. Ürün stok ve PSF bilgileri
                cur.execute(f"""
                    SELECT u.id, RTRIM(LTRIM(ISNULL(u.urun_adi, ''))), ISNULL(u.stok_miktar, 0), ISNULL(u.fiyati, 0)
                    FROM urun u WITH (NOLOCK)
                    WHERE u.id IN ({placeholders})
                """, urun_ids)
                urun_rows = cur.fetchall()

                # 4. Barkodlar
                cur.execute(f"""
                    SELECT urun_id, RTRIM(LTRIM(barkod))
                    FROM urun_barkod WITH (NOLOCK)
                    WHERE urun_id IN ({placeholders}) AND barkod IS NOT NULL AND RTRIM(LTRIM(barkod)) <> ''
                    ORDER BY sira_no ASC
                """, urun_ids)
                barkod_map: Dict[int, str] = {}
                for b_uid, b_str in cur.fetchall():
                    uid_i = int(b_uid)
                    bc_clean = str(b_str or "").strip()
                    if uid_i not in barkod_map and bc_clean:
                        barkod_map[uid_i] = bc_clean
                    elif bc_clean.isdigit() and len(bc_clean) == 13 and len(barkod_map.get(uid_i, "")) != 13:
                        barkod_map[uid_i] = bc_clean

                # 5. Geçmişte MF'li Alım Kontrolü (alis)
                mf_history_map: Dict[int, Dict[str, Any]] = {}
                try:
                    cur.execute(f"""
                        SELECT urun_id, alis_miktar, mal_fazlasi, Tarih, AlimCount
                        FROM (
                            SELECT
                                a.urun_id,
                                ISNULL(a.alis_miktar, 0) AS alis_miktar,
                                ISNULL(a.mal_fazlasi, 0) AS mal_fazlasi,
                                CONVERT(varchar(10), a.alis_tarihi, 120) AS Tarih,
                                COUNT(*) OVER (PARTITION BY a.urun_id) AS AlimCount,
                                ROW_NUMBER() OVER (PARTITION BY a.urun_id ORDER BY a.alis_tarihi DESC, a.alis_sira DESC) AS RN
                            FROM alis a WITH (NOLOCK)
                            WHERE a.urun_id IN ({placeholders})
                              AND ISNULL(a.mal_fazlasi, 0) > 0
                        ) t WHERE RN = 1
                    """, urun_ids)
                    for r in cur.fetchall():
                        uid_m = int(r[0])
                        m_adet = int(r[1] or 0)
                        m_mf = int(r[2] or 0)
                        raw_date = str(r[3] or "")
                        if raw_date and "-" in raw_date:
                            pts = raw_date.split("-")
                            fmt_date = f"{pts[2]}.{pts[1]}.{pts[0]}" if len(pts) == 3 else raw_date
                        else:
                            fmt_date = raw_date
                        alim_count = int(r[4] or 1)
                        mf_kisa = f"Son: {m_adet}+{m_mf} MF" if m_adet > 0 else f"Son: +{m_mf} MF"
                        mf_bilgi = f"Geçmişte {alim_count} kez MF ile alındı (Son Alım: {m_adet}+{m_mf} MF, {fmt_date})"
                        mf_history_map[uid_m] = {
                            "var": True,
                            "sayisi": alim_count,
                            "son_adet": m_adet,
                            "son_mf": m_mf,
                            "son_tarih": fmt_date,
                            "kisa": mf_kisa,
                            "bilgi": mf_bilgi,
                        }
                except Exception:
                    pass

                candidate_items = []
                for u_id_raw, u_adi, stok_raw, psf_raw in urun_rows:
                    u_id = int(u_id_raw)
                    u_adi_up = str(u_adi or "").upper()
                    if any(skip_w in u_adi_up for skip_w in ("FIYAT FARKI", "FİYAT FARKI", "MUAYENE", "POŞET", "POSET", "KATILIM PAYI")):
                        continue
                    stok_val = int(stok_raw or 0)
                    bugun_val = today_map.get(u_id, 0)
                    ay_val = month_map.get(u_id, 0)
                    psf_val = round(float(psf_raw or 0.0), 2)
                    raw_barkod = barkod_map.get(u_id, "")
                    barkod_val = raw_barkod

                    try:
                        from backend.catalog import catalog
                        can_bc = catalog.resolve_canonical_barcode(raw_barkod)
                        if can_bc:
                            barkod_val = can_bc
                    except Exception:
                        pass

                    effective_aylik = max(int(ay_val or 0), int(bugun_val or 1))
                    gunluk_ort = max(0.1, round(effective_aylik / 30.0, 2))
                    stok_gun = round((stok_val * 30.0) / effective_aylik, 1) if stok_val > 0 else 0.0

                    if max_stock_days > 0 and stok_val > 0 and stok_gun > max_stock_days:
                        continue

                    onerilen = max(bugun_val, int(gunluk_ort * 7) - max(0, stok_val))
                    if onerilen <= 0:
                        onerilen = max(1, bugun_val)

                    mf_hist = mf_history_map.get(u_id, {})
                    candidate_items.append({
                        "urun_id": u_id,
                        "mal_kodu": str(u_id),
                        "urun_adi": u_adi,
                        "barkod": barkod_val,
                        "raw_barkod": raw_barkod,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": ay_val,
                        "psf": psf_val,
                        "onerilen_siparis": max(1, onerilen),
                        "gecmis_mf_var": bool(mf_hist.get("var", False)),
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", ""),
                    })

                candidate_items.sort(key=lambda x: (
                    0 if x["stok"] < 0 else (1 if x["stok"] == 0 else 2),
                    x["stok"] if x["stok"] < 0 else x["stok_gun"],
                    -x["bugun_cikis"],
                ))
                if limit and limit > 0:
                    return candidate_items[:limit]
                return candidate_items
        except Exception as e:
            print(f"[Eczanem] get_critical_stock_sales hatası: {e}")
            return []

    def get_six_month_smart_order_list(
        self,
        scope: str = "today",
        search_query: str = "",
        target_days: int = 15,
        limit: int = 250,
    ) -> Dict[str, Any]:
        """
        Eczanem MS SQL veritabanından 6 aylık ay-ay satış dağılımı (Reçeteli + Nakit),
        trend/stabilite analizi, geçmiş MF rozetleri ve hedef güne göre akıllı sipariş listesi üretir.
        """
        t0 = time.time()
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                ay_kisa = {
                    1: "Oca", 2: "Şub", 3: "Mar", 4: "Nis",
                    5: "May", 6: "Haz", 7: "Tem", 8: "Ağu",
                    9: "Eyl", 10: "Eki", 11: "Kas", 12: "Ara",
                }
                today = datetime.date.today()
                months_meta = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    ym_int = y_calc * 100 + m_calc
                    ym_str = f"{y_calc}-{m_calc:02d}"
                    short_lbl = ay_kisa.get(m_calc, str(m_calc))
                    lbl = f"{short_lbl} '{str(y_calc)[-2:]}"
                    months_meta.append({
                        "ym_int": ym_int,
                        "ym": ym_str,
                        "short": short_lbl,
                        "label": lbl,
                        "is_current": (i == 0),
                    })

                start_ym = months_meta[0]["ym_int"]
                start_date_str = f"{start_ym // 100}-{start_ym % 100:02d}-01"

                # 1. Bugünkü çıkışlar
                cur.execute("""
                    SELECT
                        sd.urun_id,
                        SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN','RV','RB','PN','PB','PV','E') THEN ISNULL(sd.satis_miktar, 0) ELSE 0 END)
                        - SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN','RV','RB') THEN ISNULL(sd.emanet_miktar, 0) ELSE 0 END) AS BugunAdet
                    FROM satis_detay sd WITH (NOLOCK)
                    JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                    WHERE s.satis_tarihi >= CAST(GETDATE() AS DATE)
                      AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                      AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                      AND ISNULL(s.cikar, 0) = 0
                      AND sd.urun_id IS NOT NULL
                    GROUP BY sd.urun_id
                """)
                today_map = {int(r[0]): max(0, int(r[1] or 0)) for r in cur.fetchall() if r[0] and int(r[1] or 0) > 0}

                clean_q = (search_query or "").strip()
                scope_norm = (scope or "today").strip().lower()

                if clean_q:
                    tr_q = clean_q.replace("i", "İ").replace("ı", "I").upper()
                    cur.execute(f"""
                        SELECT TOP {int(limit or 100)} u.id
                        FROM urun u WITH (NOLOCK)
                        WHERE u.urun_adi LIKE ? OR u.urun_adi LIKE ?
                           OR u.id IN (SELECT ub.urun_id FROM urun_barkod ub WITH (NOLOCK) WHERE ub.barkod LIKE ?)
                        ORDER BY ISNULL(u.stok_miktar, 0) DESC, u.id DESC
                    """, (f"%{clean_q}%", f"%{tr_q}%", f"%{clean_q}%"))
                    urun_ids = [int(r[0]) for r in cur.fetchall() if r[0]]
                elif scope_norm in ("week", "days_7"):
                    cur.execute(f"""
                        SELECT TOP {int(limit or 250)} sd.urun_id
                        FROM satis_detay sd WITH (NOLOCK)
                        JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                        WHERE s.satis_tarihi >= DATEADD(day, -7, GETDATE())
                          AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                          AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                          AND ISNULL(s.cikar, 0) = 0
                          AND sd.urun_id IS NOT NULL
                        GROUP BY sd.urun_id
                        ORDER BY SUM(ISNULL(sd.satis_miktar, 0)) DESC
                    """)
                    urun_ids = [int(r[0]) for r in cur.fetchall() if r[0]]
                elif scope_norm in ("top6m", "top_6m"):
                    cur.execute(f"""
                        SELECT TOP {int(limit or 250)} sd.urun_id
                        FROM satis_detay sd WITH (NOLOCK)
                        JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                        WHERE s.satis_tarihi >= ?
                          AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                          AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                          AND ISNULL(s.cikar, 0) = 0
                          AND sd.urun_id IS NOT NULL
                        GROUP BY sd.urun_id
                        ORDER BY SUM(ISNULL(sd.satis_miktar, 0)) DESC
                    """, (start_date_str,))
                    urun_ids = [int(r[0]) for r in cur.fetchall() if r[0]]
                else:
                    urun_ids = list(today_map.keys())
                    if not urun_ids:
                        cur.execute(f"""
                            SELECT TOP {int(limit or 200)} sd.urun_id
                            FROM satis_detay sd WITH (NOLOCK)
                            JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                            WHERE s.satis_tarihi >= DATEADD(day, -3, GETDATE())
                              AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                              AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                              AND ISNULL(s.cikar, 0) = 0
                              AND sd.urun_id IS NOT NULL
                            GROUP BY sd.urun_id
                            ORDER BY SUM(ISNULL(sd.satis_miktar, 0)) DESC
                        """)
                        urun_ids = [int(r[0]) for r in cur.fetchall() if r[0]]

                if not urun_ids:
                    return {
                        "success": True,
                        "scope": scope,
                        "months": months_meta,
                        "items": [],
                        "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0},
                    }

                if limit and len(urun_ids) > limit:
                    urun_ids = urun_ids[:limit]

                placeholders = ",".join("?" * len(urun_ids))

                # 2. Son 6 ayın ay-ay Reçeteli ve Nakit dağılımı
                cur.execute(f"""
                    SELECT
                        sd.urun_id,
                        (YEAR(s.satis_tarihi) * 100 + MONTH(s.satis_tarihi)) AS YM,
                        SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN','RV','RB') THEN ISNULL(sd.satis_miktar, 0) ELSE 0 END) AS RecAdet,
                        SUM(CASE WHEN RTRIM(s.satis_turu) IN ('PN','PB','PV','E') THEN ISNULL(sd.satis_miktar, 0) ELSE 0 END)
                        - SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN','RV','RB') THEN ISNULL(sd.emanet_miktar, 0) ELSE 0 END) AS NakAdet
                    FROM satis_detay sd WITH (NOLOCK)
                    JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                    WHERE s.satis_tarihi >= ?
                      AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                      AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                      AND ISNULL(s.cikar, 0) = 0
                      AND sd.urun_id IN ({placeholders})
                    GROUP BY sd.urun_id, (YEAR(s.satis_tarihi) * 100 + MONTH(s.satis_tarihi))
                """, [start_date_str, *urun_ids])

                per_item_months: Dict[int, Dict[int, Dict[str, int]]] = {}
                for r_uid, r_ym, r_rec, r_nak in cur.fetchall():
                    if not r_uid or not r_ym:
                        continue
                    rec_v = max(0, int(r_rec or 0))
                    nak_v = max(0, int(r_nak or 0))
                    per_item_months.setdefault(int(r_uid), {})[int(r_ym)] = {
                        "toplam": rec_v + nak_v,
                        "receteli": rec_v,
                        "nakit": nak_v,
                    }

                # 3. Son 30 günün çıkışları
                cur.execute(f"""
                    SELECT
                        sd.urun_id,
                        SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN','RV','RB','PN','PB','PV','E') THEN ISNULL(sd.satis_miktar, 0) ELSE 0 END)
                        - SUM(CASE WHEN RTRIM(s.satis_turu) IN ('RN','RV','RB') THEN ISNULL(sd.emanet_miktar, 0) ELSE 0 END) AS AyAdet
                    FROM satis_detay sd WITH (NOLOCK)
                    JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                    WHERE s.satis_tarihi >= DATEADD(day, -30, GETDATE())
                      AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                      AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                      AND ISNULL(s.cikar, 0) = 0
                      AND sd.urun_id IN ({placeholders})
                    GROUP BY sd.urun_id
                """, urun_ids)
                last30_map = {int(r[0]): max(0, int(r[1] or 0)) for r in cur.fetchall() if r[0]}

                # 4. Ürün stok ve PSF
                cur.execute(f"""
                    SELECT u.id, RTRIM(LTRIM(ISNULL(u.urun_adi, ''))), ISNULL(u.stok_miktar, 0), ISNULL(u.fiyati, 0)
                    FROM urun u WITH (NOLOCK)
                    WHERE u.id IN ({placeholders})
                """, urun_ids)
                urun_rows = cur.fetchall()

                # 5. Barkodlar
                cur.execute(f"""
                    SELECT urun_id, RTRIM(LTRIM(barkod))
                    FROM urun_barkod WITH (NOLOCK)
                    WHERE urun_id IN ({placeholders}) AND barkod IS NOT NULL AND RTRIM(LTRIM(barkod)) <> ''
                    ORDER BY sira_no ASC
                """, urun_ids)
                barkod_map: Dict[int, str] = {}
                for b_uid, b_str in cur.fetchall():
                    uid_i = int(b_uid)
                    bc_clean = str(b_str or "").strip()
                    if uid_i not in barkod_map and bc_clean:
                        barkod_map[uid_i] = bc_clean
                    elif bc_clean.isdigit() and len(bc_clean) == 13 and len(barkod_map.get(uid_i, "")) != 13:
                        barkod_map[uid_i] = bc_clean

                # 6. Geçmiş Fatura MF Bilgisi (alis + cari)
                mf_history_map: Dict[int, Dict[str, Any]] = {}
                try:
                    cur.execute(f"""
                        SELECT urun_id, alis_miktar, mal_fazlasi, Tarih, AlimCount, DepoAdi
                        FROM (
                            SELECT
                                a.urun_id,
                                ISNULL(a.alis_miktar, 0) AS alis_miktar,
                                ISNULL(a.mal_fazlasi, 0) AS mal_fazlasi,
                                CONVERT(varchar(10), a.alis_tarihi, 120) AS Tarih,
                                RTRIM(LTRIM(ISNULL(c.kurum_adi, ''))) AS DepoAdi,
                                COUNT(*) OVER (PARTITION BY a.urun_id) AS AlimCount,
                                ROW_NUMBER() OVER (PARTITION BY a.urun_id ORDER BY a.alis_tarihi DESC, a.alis_sira DESC) AS RN
                            FROM alis a WITH (NOLOCK)
                            LEFT JOIN cari c WITH (NOLOCK) ON a.kurum_id = c.id
                            WHERE a.urun_id IN ({placeholders})
                              AND ISNULL(a.mal_fazlasi, 0) > 0
                        ) t WHERE RN = 1
                    """, urun_ids)
                    for r in cur.fetchall():
                        uid_m = int(r[0])
                        m_adet = int(r[1] or 0)
                        m_mf = int(r[2] or 0)
                        raw_dt = str(r[3] or "")
                        if raw_dt and "-" in raw_dt:
                            pts = raw_dt.split("-")
                            fmt_dt = f"{pts[2]}.{pts[1]}.{pts[0]}" if len(pts) == 3 else raw_dt
                        else:
                            fmt_dt = raw_dt
                        cnt = int(r[4] or 1)
                        depo_adi = str(r[5] or "").strip()
                        mf_kisa = f"{m_adet}+{m_mf}" if m_adet > 0 else f"+{m_mf}"
                        mf_history_map[uid_m] = {
                            "var": True,
                            "sayisi": cnt,
                            "son_adet": m_adet,
                            "son_mf": m_mf,
                            "son_tarih": fmt_dt,
                            "son_depo": depo_adi,
                            "kisa": mf_kisa,
                            "bilgi": f"Geçmişte {cnt} kez MF'li alındı (Son: {mf_kisa} MF, {fmt_dt})",
                        }
                except Exception:
                    pass

                items = []
                stabil_count = 0
                azalan_count = 0
                artan_count = 0
                tukenen_count = 0
                target_days_clean = max(1, int(target_days or 15))

                for u_id_raw, u_adi, stok_raw, psf_raw in urun_rows:
                    u_id = int(u_id_raw)
                    u_adi_up = str(u_adi or "").upper()
                    if any(skip_w in u_adi_up for skip_w in ("FIYAT FARKI", "FİYAT FARKI", "MUAYENE", "POŞET", "POSET", "KATILIM PAYI")):
                        continue
                    stok_val = int(stok_raw or 0)
                    psf_val = round(float(psf_raw or 0.0), 2)
                    bugun_val = int(today_map.get(u_id, 0))
                    son30_val = int(last30_map.get(u_id, 0))
                    raw_bc = barkod_map.get(u_id, "")
                    bc_val = raw_bc
                    try:
                        from backend.catalog import catalog
                        can_bc = catalog.resolve_canonical_barcode(raw_bc)
                        if can_bc:
                            bc_val = can_bc
                    except Exception:
                        pass

                    m_dict = per_item_months.get(u_id, {})
                    aylik_detay = []
                    toplam_6ay = 0
                    toplam_6ay_recete = 0
                    toplam_6ay_nakit = 0
                    aktif_ay_sayisi = 0

                    for m_meta in months_meta:
                        ym_i = m_meta["ym_int"]
                        cell = m_dict.get(ym_i, {"toplam": 0, "receteli": 0, "nakit": 0})
                        c_top = cell["toplam"]
                        c_rec = cell["receteli"]
                        c_nak = cell["nakit"]
                        toplam_6ay += c_top
                        toplam_6ay_recete += c_rec
                        toplam_6ay_nakit += c_nak
                        if c_top > 0:
                            aktif_ay_sayisi += 1
                        aylik_detay.append({
                            "ym": m_meta["ym"],
                            "short": m_meta["short"],
                            "label": m_meta["label"],
                            "is_current": m_meta["is_current"],
                            "toplam": c_top,
                            "receteli": c_rec,
                            "recete": c_rec,
                            "nakit": c_nak,
                        })

                    m_vals = [x["toplam"] for x in aylik_detay]
                    gecmis_5_toplam = sum(m_vals[:5])
                    ort_aylik_6m = round(gecmis_5_toplam / 5.0, 1) if gecmis_5_toplam > 0 else round(toplam_6ay / 6.0, 1)

                    onceki_4_ort = sum(m_vals[:4]) / 4.0
                    gecen_ay_val = m_vals[4] if len(m_vals) >= 5 else 0
                    son_donem_hiz = round((gecen_ay_val + son30_val) / 2.0, 1) if gecen_ay_val > 0 else float(son30_val)

                    degisim_yuzde = 0
                    if onceki_4_ort >= 1.5:
                        degisim_yuzde = int(round(((son_donem_hiz - onceki_4_ort) / onceki_4_ort) * 100))

                    if onceki_4_ort >= 2.0 and son_donem_hiz < onceki_4_ort * 0.65:
                        trend_kodu = "AZALAN"
                        trend_etiket = f"📉 Çıkışı Azalan (%{abs(degisim_yuzde)}↓)"
                        trend_renk = "amber"
                        trend_uyari = f"Son dönemde çıkış hızı {onceki_4_ort:.1f}/ay'dan {son_donem_hiz:.1f}/ay'a geriledi. Yüksek stok bağlamayın."
                        azalan_count += 1
                    elif onceki_4_ort >= 1.5 and son_donem_hiz > onceki_4_ort * 1.35 and son_donem_hiz >= 3.0:
                        trend_kodu = "ARTAN"
                        trend_etiket = f"📈 Çıkışı Artan (+%{abs(degisim_yuzde)}↑)"
                        trend_renk = "sky"
                        trend_uyari = f"Son dönemde talep hızlandı ({onceki_4_ort:.1f} → {son_donem_hiz:.1f}/ay). Güvenli stok tutun."
                        artan_count += 1
                    elif aktif_ay_sayisi >= 4 and toplam_6ay >= 5:
                        trend_kodu = "STABIL"
                        trend_etiket = f"🟢 Stabil Çıkan ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "emerald"
                        trend_uyari = f"Her ay düzenli satıyor (Ort. {ort_aylik_6m:.1f} kt/ay). MF baremli alıma uygun."
                        stabil_count += 1
                    else:
                        trend_kodu = "DUZENSIZ"
                        trend_etiket = f"⚡ Aralıklı ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "slate"
                        trend_uyari = f"Son 6 ayın {aktif_ay_sayisi} ayında çıkış yaptı (Toplam {toplam_6ay} kt). İhtiyaç kadar alın."

                    if stok_val <= 0:
                        tukenen_count += 1

                    if trend_kodu == "AZALAN":
                        etkin_aylik_hiz = max(0.5, min(ort_aylik_6m, max(1.0, son_donem_hiz)))
                    elif trend_kodu == "ARTAN":
                        etkin_aylik_hiz = max(ort_aylik_6m, son_donem_hiz, float(bugun_val))
                    else:
                        etkin_aylik_hiz = max(ort_aylik_6m, float(son30_val), float(bugun_val))

                    gunluk_hiz = round(max(0.05, etkin_aylik_hiz / 30.0), 2)
                    stok_gun = round(stok_val / gunluk_hiz, 1) if stok_val > 0 else 0.0

                    hedef_kutu = math.ceil(gunluk_hiz * target_days_clean)
                    if trend_kodu == "AZALAN":
                        kisitli_hedef = math.ceil(gunluk_hiz * min(target_days_clean, 10))
                        onerilen = max(0, kisitli_hedef - max(0, stok_val))
                        if stok_val <= 0:
                            onerilen = max(1, min(bugun_val or 1, 2))
                    else:
                        onerilen = max(0, hedef_kutu - max(0, stok_val))
                        if stok_val <= 0 and onerilen <= 0:
                            onerilen = max(1, bugun_val or 1)

                    mf_hist = mf_history_map.get(u_id, {})

                    if trend_kodu == "AZALAN":
                        oneri_metni = f"⚠️ Çıkışı azaldığı için {target_days_clean} gün yerine kısa vadeli ({max(1, onerilen)} kt) önerildi."
                    elif trend_kodu == "STABIL" and mf_hist.get("var"):
                        oneri_metni = f"💡 Düzenli çıkıyor ({ort_aylik_6m:.1f}/ay). Geçmişte {mf_hist.get('kisa')} MF ile alındı; MF baremi avantajlı!"
                    elif trend_kodu == "STABIL":
                        oneri_metni = f"✅ Stabil ürün ({ort_aylik_6m:.1f}/ay). {target_days_clean} günlük stok hedefi için {max(1, onerilen)} kt uygun."
                    elif trend_kodu == "ARTAN":
                        oneri_metni = f"🚀 Çıkış hızı artıyor ({son_donem_hiz:.1f}/ay). Stoksuz kalmamak için {max(1, onerilen)} kt önerilir."
                    else:
                        oneri_metni = f"📦 Aralıklı çıkış ({toplam_6ay} kt / 6 ay). Minimum stok ({max(1, onerilen)} kt) tutun."

                    items.append({
                        "urun_id": u_id,
                        "mal_kodu": str(u_id),
                        "urun_kodu": str(u_id),
                        "urun_adi": u_adi,
                        "barkod": bc_val,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "psf": psf_val,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": son30_val,
                        "toplam_6ay": toplam_6ay,
                        "toplam_6ay_recete": toplam_6ay_recete,
                        "toplam_6ay_nakit": toplam_6ay_nakit,
                        "ort_aylik_6m": ort_aylik_6m,
                        "onceki_4_ort": round(onceki_4_ort, 1),
                        "ilk4_ort": round(onceki_4_ort, 1),
                        "son_donem_hiz": round(son_donem_hiz, 1),
                        "son2_ort": round(son_donem_hiz, 1),
                        "gunluk_hiz": gunluk_hiz,
                        "aktif_ay_sayisi": aktif_ay_sayisi,
                        "aylik_detay": aylik_detay,
                        "trend_kodu": trend_kodu,
                        "trend_etiket": trend_etiket,
                        "trend_renk": trend_renk,
                        "trend_uyari": trend_uyari,
                        "degisim_yuzde": degisim_yuzde,
                        "onerilen_siparis": max(1, onerilen) if (stok_val <= 0 or bugun_val > 0 or onerilen > 0) else 0,
                        "ham_ihtiyac": max(0, hedef_kutu - max(0, stok_val)),
                        "oneri_metni": oneri_metni,
                        "gecmis_mf_var": bool(mf_hist.get("var", False)),
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_min_alim": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_bedelsiz": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_son_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", ""),
                    })

                items.sort(key=lambda x: (
                    0 if (x["stok"] <= 0 and x["bugun_cikis"] > 0) else (1 if x["bugun_cikis"] > 0 else 2),
                    x["stok_gun"],
                    -x["toplam_6ay"],
                ))

                return {
                    "success": True,
                    "scope": scope,
                    "target_days": target_days_clean,
                    "elapsed_ms": round((time.time() - t0) * 1000, 1),
                    "months": months_meta,
                    "items": items,
                    "stats": {
                        "total_items": len(items),
                        "stabil_count": stabil_count,
                        "azalan_count": azalan_count,
                        "artan_count": artan_count,
                        "tukenen_count": tukenen_count,
                    },
                }
        except Exception as e:
            print(f"[Eczanem] get_six_month_smart_order_list hatası: {e}")
            return {
                "success": False,
                "error": str(e),
                "months": [],
                "items": [],
                "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0},
            }

    def get_product_equivalents(self, barcode_or_code: str) -> Dict[str, Any]:
        """
        Eczanem `urun2` tablosundaki `kamu_esdegeri`, `EGrup` veya `SgkEtkin` kodu üzerinden
        SGK eşdeğer / muadil ilaçları, raf stoklarını, son 30 gün çıkışlarını,
        geçmiş MF bilgilerini ve kamu kârlılıklarını listeler.
        """
        q = str(barcode_or_code or "").strip()
        if not q:
            return {"found": False, "esdeger_kodu": None, "muadiller": []}

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                prow = self._find_product_row(cur, q, barcode=q if q.isdigit() else "")
                if not prow:
                    return {"found": False, "esdeger_kodu": None, "muadiller": [], "message": "Ürün Eczanem'de bulunamadı."}

                target_uid = int(prow[0])
                kamu_esd = str(prow[8] or "").strip()
                egrup = str(prow[9] or "").strip()
                sgk_etkin = str(prow[10] or "").strip()
                esdeger_kodu_str = kamu_esd or egrup or sgk_etkin

                if not esdeger_kodu_str:
                    return {"found": False, "esdeger_kodu": None, "muadiller": [], "message": "Bu ürün için eşdeğer grup kodu tanımlı değil."}

                cur.execute("""
                    SELECT
                        u.id,
                        RTRIM(LTRIM(ISNULL(u.urun_adi, ''))) AS UrunAdi,
                        ISNULL((
                            SELECT TOP 1 RTRIM(LTRIM(ub.barkod))
                            FROM urun_barkod ub WITH (NOLOCK)
                            WHERE ub.urun_id = u.id AND ub.barkod IS NOT NULL AND RTRIM(LTRIM(ub.barkod)) <> ''
                            ORDER BY ub.sira_no ASC
                        ), '') AS Barkod,
                        ISNULL(u.fiyati, 0) AS PSF,
                        ISNULL(u.kamu_fiyati, 0) AS KSF,
                        ISNULL(u2.kurum_iskonto_alis, 0) AS KamuIskonto,
                        ISNULL(u2.ticari_iskonto, 0) AS TicariIskonto,
                        ISNULL(u2.kdv, '10') AS KDVOran,
                        ISNULL(u.stok_miktar, 0) AS Stok,
                        ISNULL((
                            SELECT SUM(
                                CASE WHEN RTRIM(s.satis_turu) IN ('RN','RV','RB','PN','PB','PV','E') THEN ISNULL(sd.satis_miktar, 0) ELSE 0 END
                            ) - SUM(
                                CASE WHEN RTRIM(s.satis_turu) IN ('RN','RV','RB') THEN ISNULL(sd.emanet_miktar, 0) ELSE 0 END
                            )
                            FROM satis_detay sd WITH (NOLOCK)
                            JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                            WHERE sd.urun_id = u.id
                              AND s.satis_tarihi >= DATEADD(day, -30, GETDATE())
                              AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                              AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                              AND ISNULL(s.cikar, 0) = 0
                        ), 0) AS Cikis30
                    FROM urun u WITH (NOLOCK)
                    JOIN urun2 u2 WITH (NOLOCK) ON u.id = u2.urun_id
                    WHERE (
                        RTRIM(LTRIM(ISNULL(u2.kamu_esdegeri, ''))) = ?
                        OR RTRIM(LTRIM(ISNULL(u2.EGrup, ''))) = ?
                        OR RTRIM(LTRIM(ISNULL(u2.SgkEtkin, ''))) = ?
                    )
                      AND (
                          ISNULL(u2.pasif, 'H') NOT IN ('E', '1')
                          OR ISNULL(u.stok_miktar, 0) > 0
                          OR u.id = ?
                      )
                    ORDER BY ISNULL(u.stok_miktar, 0) DESC, u.id DESC
                """, (esdeger_kodu_str, esdeger_kodu_str, esdeger_kodu_str, target_uid))
                all_rows = cur.fetchall()

                eq_urun_ids = [int(r[0]) for r in all_rows]
                mf_map: Dict[int, Dict[str, Any]] = {}
                if eq_urun_ids:
                    eq_ph = ",".join("?" for _ in eq_urun_ids)
                    try:
                        cur.execute(f"""
                            SELECT urun_id, alis_miktar, mal_fazlasi, Tarih, AlimCount
                            FROM (
                                SELECT
                                    a.urun_id,
                                    ISNULL(a.alis_miktar, 0) AS alis_miktar,
                                    ISNULL(a.mal_fazlasi, 0) AS mal_fazlasi,
                                    CONVERT(varchar(10), a.alis_tarihi, 120) AS Tarih,
                                    COUNT(*) OVER (PARTITION BY a.urun_id) AS AlimCount,
                                    ROW_NUMBER() OVER (PARTITION BY a.urun_id ORDER BY a.alis_tarihi DESC, a.alis_sira DESC) AS RN
                                FROM alis a WITH (NOLOCK)
                                WHERE a.urun_id IN ({eq_ph})
                                  AND ISNULL(a.mal_fazlasi, 0) > 0
                            ) t WHERE RN = 1
                        """, eq_urun_ids)
                        for mr in cur.fetchall():
                            m_uid = int(mr[0])
                            m_adet = int(mr[1] or 0)
                            m_mf = int(mr[2] or 0)
                            raw_date = str(mr[3] or "")
                            if raw_date and "-" in raw_date:
                                pts = raw_date.split("-")
                                fmt_date = f"{pts[2]}.{pts[1]}.{pts[0]}" if len(pts) == 3 else raw_date
                            else:
                                fmt_date = raw_date
                            m_cnt = int(mr[4] or 1)
                            mf_map[m_uid] = {
                                "bilgi": f"Geçmişte {m_cnt} kez MF ile alındı (Son: {m_adet}+{m_mf} MF, {fmt_date})",
                                "kisa": f"{m_adet}+{m_mf}" if (m_adet > 0 and m_mf > 0) else f"+{m_mf}",
                                "adet": m_adet,
                                "mf": m_mf,
                                "tarih": fmt_date,
                                "sayisi": m_cnt,
                            }
                    except Exception:
                        pass

                items = []
                current_kamu_kari = 0.0
                for row in all_rows:
                    r_uid = int(row[0])
                    r_name = str(row[1] or "").strip()
                    r_bc = str(row[2] or r_uid).strip()
                    try:
                        from backend.catalog import catalog
                        can_bc = catalog.resolve_canonical_barcode(r_bc)
                        if can_bc:
                            r_bc = can_bc
                    except Exception:
                        pass
                    psf = round(_parse_float_safe(row[3], 0.0), 2)
                    ksf_raw = round(_parse_float_safe(row[4], 0.0), 2)
                    kamu_isk = round(_parse_float_safe(row[5], 0.0), 2)
                    tic_isk = round(_parse_float_safe(row[6], 0.0), 2)
                    kdv_oran = _parse_float_safe(row[7], 10.0)
                    stok = int(row[8] or 0)
                    cikis_30 = max(0, int(row[9] or 0))

                    if ksf_raw > 0:
                        ksf = ksf_raw
                        if kamu_isk <= 0.0 and psf > ksf > 0:
                            kamu_isk = round((1.0 - (ksf / psf)) * 100.0, 2)
                    else:
                        ksf = round(psf * (1.0 - (kamu_isk / 100.0)), 2) if psf > 0 else 0.0

                    psf_kdvsiz = psf / (1.0 + (kdv_oran / 100.0)) if psf > 0 else 0.0
                    dsf_kdvsiz = psf_kdvsiz * 0.71 * (1.0 - (kamu_isk / 100.0)) * (1.0 - (tic_isk / 100.0))

                    net_maliyet_kdvsiz = round(dsf_kdvsiz, 2)
                    net_maliyet_kdvli = round(dsf_kdvsiz * (1.0 + (kdv_oran / 100.0)), 2)

                    kamu_kari = round(max(0.0, ksf - net_maliyet_kdvli), 2) if ksf > 0 else 0.0
                    perakende_kari = round(max(0.0, psf - net_maliyet_kdvli), 2) if psf > 0 else 0.0

                    is_curr = (r_uid == target_uid)
                    if is_curr:
                        current_kamu_kari = kamu_kari

                    mf_obj = mf_map.get(r_uid) or {}
                    mf_bilgi = mf_obj.get("bilgi", "")
                    mf_kisa = mf_obj.get("kisa", "")

                    items.append({
                        "kod": str(r_uid),
                        "mal_kodu": str(r_uid),
                        "ad": r_name,
                        "urun_adi": r_name,
                        "barkod": r_bc,
                        "psf": psf,
                        "ksf": ksf,
                        "kamu_fiyati": ksf,
                        "kamu_iskontosu": kamu_isk,
                        "kdv_orani": kdv_oran,
                        "net_birim_maliyet": net_maliyet_kdvsiz,
                        "birim_maliyet": net_maliyet_kdvsiz,
                        "net_birim_maliyet_kdvli": net_maliyet_kdvli,
                        "birim_maliyet_kdvli": net_maliyet_kdvli,
                        "kamu_kari": kamu_kari,
                        "perakende_kari": perakende_kari,
                        "stok": stok,
                        "cikis_30gun": cikis_30,
                        "gecmis_mf_var": bool(mf_bilgi),
                        "gecmis_mf_bilgi": mf_bilgi,
                        "gecmis_mf_kisa": mf_kisa,
                        "is_current": is_curr,
                    })

                for it in items:
                    kf = round(it["kamu_kari"] - current_kamu_kari, 2)
                    it["kar_farki"] = kf
                    it["is_more_profitable"] = (kf > 0)
                    it["kar_artis_yuzdesi"] = round((kf / current_kamu_kari * 100.0), 1) if (current_kamu_kari > 0 and kf > 0) else 0.0

                items.sort(key=lambda x: (x.get("kamu_kari") or 0.0, x.get("stok") or 0), reverse=True)

                en_karli = None
                muadil_kar_avantaji = 0.0
                for it in items:
                    if it.get("kar_farki", 0.0) > 0 and not it.get("is_current"):
                        it["is_best_deal"] = True
                        en_karli = it
                        muadil_kar_avantaji = it["kar_farki"]
                        break

                return {
                    "found": True,
                    "esdeger_kodu": esdeger_kodu_str,
                    "count": len(items),
                    "en_karli_muadil": en_karli,
                    "muadil_kar_avantaji": muadil_kar_avantaji,
                    "current_kamu_kari": current_kamu_kari,
                    "muadiller": items,
                }
        except Exception as e:
            print(f"[Eczanem] get_product_equivalents hatası: {e}")
            return {"found": False, "error": str(e), "esdeger_kodu": None, "muadiller": []}

    def get_bulk_stock_and_sales_map(self, barcodes: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Verilen barkod listesi için Eczanem veritabanından tek seferde (bulk)
        anlık raf stoğu, son 30 gün çıkış ve son 90 gün çıkış sayılarını döndürür.
        """
        result: Dict[str, Dict[str, Any]] = {}
        clean_inputs = [str(b or "").strip() for b in (barcodes or []) if str(b or "").strip()]
        if not clean_inputs:
            return result

        variant_to_originals: Dict[str, set] = {}
        for orig_bc in clean_inputs:
            result[orig_bc] = {"stok": 0, "cikis_1ay": 0, "cikis_3ay": 0, "found": False}
            variants = {orig_bc}
            if orig_bc.isdigit():
                if len(orig_bc) == 13:
                    variants.add("0" + orig_bc)
                elif len(orig_bc) == 14 and orig_bc.startswith("0"):
                    variants.add(orig_bc[1:])
            try:
                from backend.catalog import catalog
                c_item = catalog.get_by_barcode(orig_bc)
                if c_item:
                    if c_item.get("barcode"):
                        variants.add(str(c_item["barcode"]).strip())
                    for ab in (c_item.get("all_barcodes") or []):
                        if str(ab).strip():
                            variants.add(str(ab).strip())
            except Exception:
                pass
            for v in variants:
                if v:
                    variant_to_originals.setdefault(v, set()).add(orig_bc)

        all_variants = list(variant_to_originals.keys())
        if not all_variants:
            return result

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                uid_to_originals: Dict[int, set] = {}
                chunk_size = 400

                for i in range(0, len(all_variants), chunk_size):
                    chunk = all_variants[i:i + chunk_size]
                    ph = ",".join(["?"] * len(chunk))
                    cur.execute(f"""
                        SELECT RTRIM(LTRIM(ub.barkod)), ub.urun_id
                        FROM urun_barkod ub WITH (NOLOCK)
                        WHERE RTRIM(LTRIM(ub.barkod)) IN ({ph})
                          AND ub.urun_id IS NOT NULL
                    """, tuple(chunk))
                    for row in cur.fetchall():
                        b_str = str(row[0] or "").strip()
                        u_id = int(row[1] or 0)
                        if u_id > 0 and b_str in variant_to_originals:
                            uid_to_originals.setdefault(u_id, set()).update(variant_to_originals[b_str])

                all_uids = list(uid_to_originals.keys())
                if not all_uids:
                    return result

                uid_stock: Dict[int, int] = {}
                uid_c30: Dict[int, int] = {}
                uid_c90: Dict[int, int] = {}
                active_uids: set = set()

                for i in range(0, len(all_uids), chunk_size):
                    u_chunk = all_uids[i:i + chunk_size]
                    ph = ",".join(["?"] * len(u_chunk))

                    cur.execute(f"""
                        SELECT u.id, ISNULL(u.stok_miktar, 0)
                        FROM urun u WITH (NOLOCK)
                        WHERE u.id IN ({ph})
                    """, tuple(u_chunk))
                    for row in cur.fetchall():
                        u_id = int(row[0] or 0)
                        active_uids.add(u_id)
                        uid_stock[u_id] = int(row[1] or 0)

                    cur.execute(f"""
                        SELECT
                            sd.urun_id,
                            SUM(CASE WHEN s.satis_tarihi >= DATEADD(day, -30, GETDATE()) AND RTRIM(s.satis_turu) IN ('RN','RV','RB','PN','PB','PV','E') THEN ISNULL(sd.satis_miktar, 0) ELSE 0 END)
                            - SUM(CASE WHEN s.satis_tarihi >= DATEADD(day, -30, GETDATE()) AND RTRIM(s.satis_turu) IN ('RN','RV','RB') THEN ISNULL(sd.emanet_miktar, 0) ELSE 0 END) AS C30,
                            SUM(CASE WHEN s.satis_tarihi >= DATEADD(day, -90, GETDATE()) AND RTRIM(s.satis_turu) IN ('RN','RV','RB','PN','PB','PV','E') THEN ISNULL(sd.satis_miktar, 0) ELSE 0 END)
                            - SUM(CASE WHEN s.satis_tarihi >= DATEADD(day, -90, GETDATE()) AND RTRIM(s.satis_turu) IN ('RN','RV','RB') THEN ISNULL(sd.emanet_miktar, 0) ELSE 0 END) AS C90
                        FROM satis_detay sd WITH (NOLOCK)
                        JOIN satis s WITH (NOLOCK) ON sd.satis_sira = s.satis_sira
                        WHERE sd.urun_id IN ({ph})
                          AND s.satis_tarihi >= DATEADD(day, -90, GETDATE())
                          AND ISNULL(s.silindi, '') NOT IN ('1', 'E')
                          AND ISNULL(s.deneme, '') NOT IN ('1', 'E')
                          AND ISNULL(s.cikar, 0) = 0
                        GROUP BY sd.urun_id
                    """, tuple(u_chunk))
                    for row in cur.fetchall():
                        u_id = int(row[0] or 0)
                        uid_c30[u_id] = max(0, int(row[1] or 0))
                        uid_c90[u_id] = max(0, int(row[2] or 0))

                orig_to_uids: Dict[str, set] = {}
                for u_id, origs in uid_to_originals.items():
                    if u_id in active_uids:
                        for obc in origs:
                            orig_to_uids.setdefault(obc, set()).add(u_id)

                for obc, uids in orig_to_uids.items():
                    tot_stok = sum(uid_stock.get(u, 0) for u in uids)
                    tot_c30 = sum(uid_c30.get(u, 0) for u in uids)
                    tot_c90 = sum(uid_c90.get(u, 0) for u in uids)
                    result[obc] = {
                        "stok": int(tot_stok),
                        "cikis_1ay": int(tot_c30),
                        "cikis_3ay": int(tot_c90),
                        "found": True,
                    }
        except Exception as e:
            print(f"[Eczanem] get_bulk_stock_and_sales_map hatası: {e}")

        return result


# Singleton instance
eczanem_client = EczanemSQLClient()
