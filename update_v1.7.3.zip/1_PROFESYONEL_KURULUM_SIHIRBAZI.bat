@echo off
chcp 65001 >nul 2>&1
title FARMA RADAR - PROFESYONEL KURULUM SIHIRBAZI
color 0B
cd /d "%~dp0"

set "PY_CMD="
if exist "%~dp0runtime\Tria.exe" set "PY_CMD=%~dp0runtime\Tria.exe"
if not defined PY_CMD if exist "%~dp0runtime\python.exe" set "PY_CMD=%~dp0runtime\python.exe"
if not defined PY_CMD if exist "C:\EczaneDepoPro\runtime\Tria.exe" set "PY_CMD=C:\EczaneDepoPro\runtime\Tria.exe"
if not defined PY_CMD if exist "C:\EczaneDepoPro\runtime\python.exe" set "PY_CMD=C:\EczaneDepoPro\runtime\python.exe"
if not defined PY_CMD if exist "C:\Users\eczac\anaconda3\python.exe" set "PY_CMD=C:\Users\eczac\anaconda3\python.exe"
if not defined PY_CMD set "PY_CMD=python"

echo ===============================================================================
echo        FARMA RADAR - PROFESYONEL KURULUM SIHIRBAZI BASLATILIYOR...
echo ===============================================================================
"%PY_CMD%" "%~dp0installer_wizard.py"
if errorlevel 1 (
    echo.
    echo [UYARI] Kurulum sihirbazi baslatilirken bir hata olustu.
    pause
)
