import os
import sys
import time
import urllib.request
import subprocess
import webbrowser

def get_base_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))

def find_python(base_dir):
    import shutil
    rt_dir = os.path.join(base_dir, "runtime")
    rt_py = os.path.join(rt_dir, "python.exe")
    rt_tria = os.path.join(rt_dir, "Tria.exe")
    if os.path.isfile(rt_py) and not os.path.isfile(rt_tria):
        try:
            shutil.copy2(rt_py, rt_tria)
        except Exception:
            pass
    candidates = [
        rt_tria,
        rt_py,
        os.path.expanduser(r"~\anaconda3\python.exe"),
        r"C:\Users\eczac\anaconda3\python.exe",
        r"C:\ProgramData\Anaconda3\python.exe",
        "python"
    ]
    for c in candidates:
        if c == "python" or os.path.isfile(c):
            return c
    return "python"

def is_server_healthy(port=8080):
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{port}/", headers={"User-Agent": "DepoLauncher"})
        with urllib.request.urlopen(req, timeout=1.5) as resp:
            return resp.status == 200
    except Exception:
        return False

def kill_port_process(port=8080):
    try:
        out = subprocess.check_output("netstat -ano -p tcp", shell=True).decode("latin1", errors="ignore")
        pids = set()
        for line in out.splitlines():
            if f":{port} " in line and "LISTENING" in line:
                parts = line.strip().split()
                if parts:
                    pid = parts[-1]
                    if pid.isdigit() and int(pid) != os.getpid():
                        pids.add(pid)
        for pid in pids:
            subprocess.run(f"taskkill /F /PID {pid}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if pids:
            time.sleep(1.0)
    except Exception:
        pass

def run_startup_update_check(base_dir, py_exe):
    """
    Program acilirken arka planda 2 saniye icinde yeni guncelleme olup olmadigini kontrol eder.
    Varsa dosyalari gunceller, yoksa veya internet yoksa akisi bekletmeden acilisa devam eder.
    """
    try:
        check_script = (
            "import sys; sys.path.insert(0, '.'); "
            "from backend.updater import updater; "
            "chk = updater.check_for_updates(timeout=2.0); "
            "if chk.get('update_available') and chk.get('download_url'): "
            "    updater.apply_update(chk['download_url'], chk.get('sha256', ''), chk.get('latest_version', '')); "
        )
        cflags = 0
        if sys.platform == "win32":
            cflags = subprocess.CREATE_NO_WINDOW
        subprocess.run(
            [py_exe, "-c", check_script],
            cwd=base_dir,
            timeout=8.0,
            creationflags=cflags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    except Exception:
        pass

def main():
    base_dir = get_base_dir()
    os.chdir(base_dir)

    server_script = os.path.join(base_dir, "server.py")
    if not os.path.isfile(server_script):
        # Fallback check
        parent = os.path.dirname(base_dir)
        if os.path.isfile(os.path.join(parent, "server.py")):
            base_dir = parent
            server_script = os.path.join(base_dir, "server.py")
            os.chdir(base_dir)

    py_exe = find_python(base_dir)

    # Eger sunucu zaten ayaktaysa ve saglikliysa direkt tarayiciyi ac
    if is_server_healthy(8080):
        webbrowser.open("http://localhost:8080")
        sys.exit(0)

    # 8080 portunu eski/kilitli python islemlerinden temizle
    kill_port_process(8080)

    # Acilis oncesi sessiz guncelleme kontrolu (2 saniye zaman asimi)
    run_startup_update_check(base_dir, py_exe)

    # server.py'yi arka planda baslat
    creationflags = 0
    if sys.platform == "win32":
        creationflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)

    subprocess.Popen(
        [py_exe, server_script],
        cwd=base_dir,
        creationflags=creationflags,
        close_fds=True
    )

    # Sunucunun hazir olmasini bekle (maksimum 15 saniye)
    ready = False
    for _ in range(30):
        time.sleep(0.5)
        if is_server_healthy(8080):
            ready = True
            break

    # Tarayiciyi ac
    webbrowser.open("http://localhost:8080")
    sys.exit(0)

if __name__ == "__main__":
    main()
