from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class MarketPlatform(str, Enum):
    TRENDYOL = "TRENDYOL"
    HEPSIBURADA = "HEPSIBURADA"
    SACHANE = "SACHANE"
    DERMOECZANEM = "DERMOECZANEM"
    DERMOKOZMETIKA = "DERMOKOZMETIKA"
    KIRMIZIBEYAZ = "KIRMIZIBEYAZ"
    DERMOJET = "DERMOJET"
    KOZVIT = "KOZVIT"
    DAFFNE = "DAFFNE"

class RetailProductOffer(BaseModel):
    platform: MarketPlatform
    platform_adi: str
    platform_domain: str
    platform_renk: str = "indigo"          # Tailwind renk kodu (örn: amber, purple, emerald, orange)
    urun_adi: str
    fiyat: float                          # Güncel Satış Fiyatı (TL, KDV Dahil)
    eski_fiyat: Optional[float] = None    # Çizili Fiyat (varsa)
    url: str                              # Doğrudan Ürün Linki
    gorsel_url: Optional[str] = None      # Ürün Fotoğrafı
    satici: Optional[str] = None          # Mağaza / Satıcı Eczane Adı
    stok_durumu: bool = True              # Stokta var mı?
    kargo_ucretsiz: bool = False          # Ücretsiz kargo mu?
    puan: Optional[float] = None          # Değerlendirme puanı
    yorum_sayisi: Optional[int] = None

class DepoOzetFiyat(BaseModel):
    depo: str                             # ALLIANCE, SELCUK, NEVZAT, ISKOOP, FARMAZON, ECZA1
    depo_adi: str
    net_birim_maliyet: float              # KDV Hariç Net
    net_birim_maliyet_kdvli: float        # KDV Dahil Net
    stok_durumu: str                      # VAR / YOK
    stok_adedi: Optional[int] = None
    mf_metni: str = "YOK"
    miad: Optional[str] = None

class MarketPriceReport(BaseModel):
    aranan_kelime: str
    barkod: Optional[str] = None
    urun_adi: Optional[str] = None
    
    # Depo & B2B Tarafı
    depo_en_dusuk_fiyat: Optional[float] = None       # En ucuz depo/pazaryeri net alış fiyatı (KDV Dahil)
    depo_en_dusuk_fiyat_kdvsiz: Optional[float] = None
    depo_en_dusuk_adi: Optional[str] = None
    depo_fiyatlari: List[DepoOzetFiyat] = Field(default_factory=list)
    
    # İnternet & Perakende Tarafı
    internet_en_dusuk_fiyat: Optional[float] = None
    internet_en_dusuk_platform: Optional[str] = None
    internet_en_yuksek_fiyat: Optional[float] = None
    internet_ortalama_fiyat: Optional[float] = None
    
    # Arbitraj & Kâr Analizi
    kar_farki_tl: Optional[float] = None              # İnternet En Düşük - Depo Alış
    kar_yuzdesi: Optional[float] = None               # % Brüt Kâr Marjı
    internet_depodan_ucuz: bool = False               # Eğer internet depodan daha ucuzsa uyarı verir
    
    # Tüm Teklifler
    teklifler: List[RetailProductOffer] = Field(default_factory=list)
    platform_sayisi: int = 0
    toplam_teklif_sayisi: int = 0
