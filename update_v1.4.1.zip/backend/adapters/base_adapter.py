from abc import ABC, abstractmethod
from typing import List, Optional
from backend.models import DepoKodu, DepoUrunSarti

class BaseDepoAdapter(ABC):
    def __init__(self, depo_kodu: DepoKodu, depo_adi: str):
        self.depo_kodu = depo_kodu
        self.depo_adi = depo_adi
        self.is_logged_in = False

    @abstractmethod
    async def login(self) -> bool:
        """Depo sistemine oturum açar ve oturumu kaydeder."""
        pass

    @abstractmethod
    async def search_product(self, query: str) -> List[DepoUrunSarti]:
        """
        Barkod veya ürün adına göre depoda arama yapar ve şartları çeker.
        """
        pass

    @abstractmethod
    async def close(self):
        """Açık oturum ve bağlantıları kapatır."""
        pass

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> dict:
        """
        Ürünü ilgili deponun sepetine/taslak siparişine ekler.
        """
        raise NotImplementedError(f"{self.depo_adi} için sepete ekleme henüz desteklenmiyor.")

    async def bulk_add_to_cart(self, items: List[dict]) -> dict:
        """
        Ürünleri toplu olarak deponun sepetine/taslak siparişine ekler.
        Varsayılan olarak tek tek add_to_cart çağırır.
        """
        results = []
        for it in items:
            u_id = it.get("urun_id") or it.get("barkod") or it.get("barcode")
            qty = int(it.get("miktar") or it.get("quantity") or 1)
            name = it.get("name") or it.get("urun_adi") or ""
            bc = it.get("barcode") or it.get("barkod") or ""
            try:
                res = await self.add_to_cart(urun_id=u_id, miktar=qty, barkod=bc)
                results.append(res)
            except Exception as e:
                results.append({"success": False, "barcode": bc, "name": name, "miktar": qty, "message": str(e)})

        success_items = [r for r in results if r.get("success")]
        return {
            "success": len(success_items) > 0,
            "depo": self.depo_kodu.value,
            "message": f"{self.depo_adi} sepetine {len(success_items)}/{len(items)} kalem ürün eklendi.",
            "total_items": len(items),
            "success_count": len(success_items),
            "failed_count": len(items) - len(success_items),
            "items": results
        }

    def get_portal_urls(self) -> dict:
        """Deponun sepet ve sipariş onaylama web arayüzü linklerini döndürür."""
        return {
            "cart_url": "",
            "checkout_url": ""
        }

    async def get_cart_status(self) -> dict:
        """Deponun mevcut sepet durumunu (ürün adedi, toplam tutar, içerik) döndürür."""
        urls = self.get_portal_urls()
        return {
            "success": True,
            "depo": self.depo_kodu.value,
            "depo_adi": self.depo_adi,
            "supported": False,
            "item_count": 0,
            "total_amount": 0.0,
            "items": [],
            "cart_url": urls.get("cart_url", ""),
            "checkout_url": urls.get("checkout_url", "")
        }

    async def clear_cart(self) -> dict:
        """Depo sepetindeki tüm ürünleri temizler."""
        raise NotImplementedError(f"{self.depo_adi} için sepet temizleme henüz desteklenmiyor.")

    async def finalize_order(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> dict:
        """
        Tekli siparişi onaylayıp doğrudan depoya iletir (sonlandırır).
        Eğer sepette başka ürünler varsa ve force=False ise uyarı döndürür.
        """
        raise NotImplementedError(f"{self.depo_adi} için doğrudan sipariş sonlandırma henüz desteklenmiyor.")

