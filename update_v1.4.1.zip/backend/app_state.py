# -*- coding: utf-8 -*-
"""
backend/app_state.py
--------------------
FastAPI uygulaması ve modüler router'lar arasında paylaşılan çalışma zamanı (runtime) durumu.
"""

from typing import Optional, Dict, Any
from backend.query_engine import DepoSorguMotoru
from backend.market.market_engine import RetailMarketEngine

motor: Optional[DepoSorguMotoru] = None
market_engine: Optional[RetailMarketEngine] = None
critical_stock_cache: Dict[str, Any] = {"time": 0.0, "data": []}
smart_order_list_cache: Dict[str, Any] = {}


def get_motor() -> DepoSorguMotoru:
    global motor
    if not motor:
        motor = DepoSorguMotoru(headless=True)
    return motor


def get_market_engine() -> RetailMarketEngine:
    global market_engine
    m = get_motor()
    if not market_engine or market_engine.depo_motoru is None:
        market_engine = RetailMarketEngine(depo_motoru=m)
    return market_engine
