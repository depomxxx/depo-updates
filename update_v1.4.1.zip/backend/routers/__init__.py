# -*- coding: utf-8 -*-
"""
backend/routers/__init__.py
---------------------------
Farma Radar FastAPI Modüler Router Paketi.
"""

from backend.routers.system_routes import router as system_router
from backend.routers.search_routes import router as search_router
from backend.routers.otomasyon_routes import router as otomasyon_router
from backend.routers.cart_routes import router as cart_router

__all__ = [
    "system_router",
    "search_router",
    "otomasyon_router",
    "cart_router",
]
