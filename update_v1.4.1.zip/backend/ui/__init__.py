# -*- coding: utf-8 -*-
"""Modüler Web Arayüzü (UI) Paket Birleştirici (Dinamik Canlı Yükleme Destekli)."""

import importlib
import os
from pathlib import Path

import backend.ui.layout_html as _layout_mod
import backend.ui.core_cart_js as _core_cart_mod
import backend.ui.settings_market_js as _settings_market_mod
import backend.ui.critical_bulk_js as _critical_bulk_mod

_UI_DIR = Path(__file__).resolve().parent
_LAST_MTIMES = {}


def _reload_if_changed():
    global _LAST_MTIMES
    modules = [
        ("layout_html.py", _layout_mod),
        ("core_cart_js.py", _core_cart_mod),
        ("settings_market_js.py", _settings_market_mod),
        ("critical_bulk_js.py", _critical_bulk_mod),
    ]
    changed = False
    current_mtimes = {}
    for fname, _ in modules:
        fpath = _UI_DIR / fname
        try:
            mtime = fpath.stat().st_mtime if fpath.exists() else 0.0
        except Exception:
            mtime = 0.0
        current_mtimes[fname] = mtime
        if _LAST_MTIMES.get(fname) != mtime:
            changed = True

    if changed and _LAST_MTIMES:
        for fname, mod in modules:
            try:
                importlib.reload(mod)
            except Exception as e:
                print(f"[UI HotReload] {fname} yenilenirken uyarı: {e}")

    _LAST_MTIMES = current_mtimes


def get_main_ui_html() -> str:
    _reload_if_changed()
    return (
        _layout_mod.LAYOUT_HTML
        + _core_cart_mod.CORE_CART_JS
        + _settings_market_mod.SETTINGS_MARKET_JS
        + _critical_bulk_mod.CRITICAL_BULK_JS
    )

