# -*- coding: utf-8 -*-
"""
backend/license_manager.py
--------------------------
Farma Radar - Ticari Lisanslama, Üye Eczacı Kayıt ve Bulut (Online) Abonelik Doğrulama Motoru.

MİMARİ (Çift Katmanlı Güvenlik + Uzaktan Bulut Kontrolü):
1. Kriptografik İmzalı Lisans Anahtarı (Offline + Online):
   - Lisans anahtarı; Eczane Adı, Eczacı Adı Soyadı, Telefon, GLN, Bitiş Tarihi (YYYY-MM-DD),
     PC Limiti ve Donanım Kimliği (HWID) bilgilerini HMAC-SHA256 imzası ile barındırır.
   - Hem FR-... hem EDP-... önekli anahtarları destekler.
2. Uzaktan Online Lisans Kontrolü (GitHub / Merkezi Sunucu Senkronizasyonu):
   - Yönetici (Admin) CRM panelinden (license_admin_tool.py) bir eczanenin süresini uzattığında,
     durumunu ASKIDA (Pasif) veya AKTİF yaptığında ya da HWID tanımladığında `licenses_cloud.json`
     otomatik olarak GitHub Canlı Portalına yüklenir.
   - Eczanedeki Farma Radar istemcisi periyodik olarak ve açılışta bu imzalı bulut listesini
     kontrol eder; yeni anahtar kopyalamaya gerek kalmadan süreyi otomatik uzatır veya
     askıya alınan/süresi biten eczanenin erişimini anında kısıtlar.
"""

import os
import sys
import json
import time
import hmac
import base64
import hashlib
import socket
import uuid
import datetime
import urllib.request
import urllib.error
from typing import Dict, Any, Optional

# Sadece geliştirici (Admin) lisans üreticide tam karşılığı bulunan doğrulama anahtarı
_MASTER_VERIFY_SALT = b"EczaneDepoPro_Commercial_v1_MasterKey_2026_!#987"


def _normalize_tr(text: str) -> str:
    """Türkçe karakter duyarsız büyük harf normalizasyonu (eşleştirme için)."""
    if not text:
        return ""
    tr_map = str.maketrans({
        "ç": "C", "Ç": "C",
        "ğ": "G", "Ğ": "G",
        "ı": "I", "I": "I", "i": "I", "İ": "I",
        "ö": "O", "Ö": "O",
        "ş": "S", "Ş": "S",
        "ü": "U", "Ü": "U",
    })
    cleaned = text.translate(tr_map).upper()
    return " ".join(cleaned.split())


class LicenseManager:
    def __init__(self, base_dir: Optional[str] = None):
        if base_dir:
            self.base_dir = base_dir
        else:
            if getattr(sys, "frozen", False):
                self.base_dir = os.path.dirname(os.path.abspath(sys.executable))
            else:
                self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        self.license_file = os.path.join(self.base_dir, "license.json")
        self.version_file = os.path.join(self.base_dir, "version.json")
        self._last_cloud_sync_ts: float = 0.0
        self._cloud_cache_ttl: float = 180.0  # 3 dakikada bir otomatik online kontrol

    def get_hardware_id(self) -> str:
        """Bu bilgisayarın benzersiz donanım kimliğini (HWID) üretir (XXXX-XXXX-XXXX)."""
        raw_id = ""
        if sys.platform == "win32":
            try:
                import subprocess
                out = subprocess.check_output(
                    "wmic csproduct get uuid",
                    shell=True,
                    stderr=subprocess.DEVNULL
                ).decode("utf-8", errors="ignore")
                lines = [ln.strip() for ln in out.splitlines() if ln.strip() and "UUID" not in ln.upper()]
                if lines:
                    raw_id = lines[0]
            except Exception:
                pass
        if not raw_id:
            raw_id = f"{socket.gethostname()}-{uuid.getnode()}"
        digest = hashlib.sha256(raw_id.encode("utf-8")).hexdigest().upper()
        return f"{digest[0:4]}-{digest[4:8]}-{digest[8:12]}"

    @staticmethod
    def generate_license_key(
        pharmacy_name: str,
        gln_no: str = "",
        expires_at: str = "2027-12-31",
        max_pcs: int = 10,
        hwid_lock: str = "ANY",
        plan: str = "PRO_YILLIK",
        pharmacist_name: str = "",
        phone: str = "",
        city: str = "",
        prefix: str = "FR"
    ) -> str:
        """
        Yönetici (Admin) için kriptografik imzalı lisans anahtarı üretir.
        Format: FR-<BASE64URL_PAYLOAD>.<HMAC_IMZA_16> (veya EDP-...)
        """
        clean_exp = expires_at.strip().replace("/", "-")
        payload_dict = {
            "e": pharmacy_name.strip().upper()[:40],
            "fn": pharmacist_name.strip()[:40],
            "tel": phone.strip()[:20],
            "ct": city.strip().upper()[:25],
            "g": gln_no.strip()[:20],
            "x": clean_exp,
            "m": int(max_pcs),
            "h": (hwid_lock or "ANY").strip().upper(),
            "p": plan.strip().upper(),
        }
        payload_json = json.dumps(payload_dict, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        b64_payload = base64.urlsafe_b64encode(payload_json).decode("ascii").rstrip("=")
        sig = hmac.new(_MASTER_VERIFY_SALT, b64_payload.encode("ascii"), hashlib.sha256).hexdigest().upper()[:16]
        pfx = (prefix or "FR").strip().upper().rstrip("-")
        return f"{pfx}-{b64_payload}.{sig}"

    @staticmethod
    def sign_cloud_registry(records: list, updated_at: str) -> str:
        """Bulut lisans listesinin (licenses_cloud.json) bütünlük imzasını üretir."""
        canonical = json.dumps(
            {"updated_at": updated_at, "count": len(records), "items": records},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":")
        ).encode("utf-8")
        return hmac.new(_MASTER_VERIFY_SALT, canonical, hashlib.sha256).hexdigest().upper()[:32]

    def verify_license_key(self, key_str: str) -> Dict[str, Any]:
        """Verilen lisans anahtarının kriptografik imzasını, donanım kilidini ve süresini doğrular."""
        clean_key = (key_str or "").strip()
        if not (clean_key.startswith("FR-") or clean_key.startswith("EDP-")) or "." not in clean_key:
            return {"valid": False, "message": "Geçersiz lisans anahtarı formatı (FR-... veya EDP-... ile başlamalıdır)."}

        try:
            body_part = clean_key.split("-", 1)[1]
            b64_payload, given_sig = body_part.rsplit(".", 1)
            expected_sig = hmac.new(
                _MASTER_VERIFY_SALT,
                b64_payload.encode("ascii"),
                hashlib.sha256
            ).hexdigest().upper()[:16]

            if not hmac.compare_digest(given_sig.upper(), expected_sig):
                return {"valid": False, "message": "Lisans imzası geçersiz veya değiştirilmiş!"}

            pad = "=" * ((4 - len(b64_payload) % 4) % 4)
            payload_bytes = base64.urlsafe_b64decode((b64_payload + pad).encode("ascii"))
            data = json.loads(payload_bytes.decode("utf-8"))

            pharmacy_name = data.get("e", "ECZANE")
            pharmacist_name = data.get("fn", "")
            phone = data.get("tel", "")
            city = data.get("ct", "")
            gln_no = data.get("g", "")
            expires_at = data.get("x", "2027-12-31")
            max_pcs = int(data.get("m", 10))
            hwid_lock = data.get("h", "ANY")
            plan = data.get("p", "PRO_YILLIK")

            my_hwid = self.get_hardware_id()
            if hwid_lock and hwid_lock != "ANY" and hwid_lock != my_hwid:
                return {
                    "valid": False,
                    "hwid_mismatch": True,
                    "pharmacy_name": pharmacy_name,
                    "my_hwid": my_hwid,
                    "hwid_lock": hwid_lock,
                    "message": f"Bu lisans başka bir bilgisayara ({hwid_lock}) tanımlanmış. Bu PC HWID: {my_hwid}"
                }

            exp_date = datetime.date.fromisoformat(expires_at[:10])
            today = datetime.date.today()
            days_left = (exp_date - today).days

            if days_left < 0:
                return {
                    "valid": False,
                    "expired": True,
                    "suspended": False,
                    "status": "SURESI_DOLDU",
                    "pharmacy_name": pharmacy_name,
                    "pharmacist_name": pharmacist_name,
                    "phone": phone,
                    "city": city,
                    "gln_no": gln_no,
                    "expires_at": expires_at,
                    "days_left": days_left,
                    "max_pcs": max_pcs,
                    "hwid_lock": hwid_lock,
                    "my_hwid": my_hwid,
                    "plan": plan,
                    "license_key": clean_key,
                    "message": f"Lisans süreniz {expires_at} tarihinde dolmuştur. Lütfen Farma Radar yöneticinizle iletişime geçin."
                }

            return {
                "valid": True,
                "expired": False,
                "suspended": False,
                "status": "AKTIF",
                "pharmacy_name": pharmacy_name,
                "pharmacist_name": pharmacist_name,
                "phone": phone,
                "city": city,
                "gln_no": gln_no,
                "expires_at": expires_at,
                "days_left": days_left,
                "max_pcs": max_pcs,
                "hwid_lock": hwid_lock,
                "my_hwid": my_hwid,
                "plan": plan,
                "license_key": clean_key,
                "message": f"Lisans Aktif ({pharmacy_name} - Kalan Süre: {days_left} gün)"
            }
        except Exception as e:
            return {"valid": False, "message": f"Lisans anahtarı çözümlenemedi: {str(e)}"}

    def _get_cloud_registry_urls(self) -> list:
        """Bulut lisans manifestosu (`licenses_cloud.json`) için kontrol edilecek URL listesini döndürür."""
        urls = []
        ts = int(time.time())
        try:
            if os.path.isfile(self.version_file):
                with open(self.version_file, "r", encoding="utf-8") as f:
                    vdata = json.load(f)
                m_url = str(vdata.get("manifest_url") or "").strip()
                if m_url.startswith("http") and "/" in m_url:
                    base_u = m_url.rsplit("/", 1)[0]
                    urls.append(f"{base_u}/licenses_cloud.json?t={ts}")
        except Exception:
            pass

        default_gh = f"https://raw.githubusercontent.com/depomxxx/depo-updates/main/licenses_cloud.json?t={ts}"
        if default_gh not in urls:
            urls.append(default_gh)

        # Yerel ağda (veya aynı bilgisayarda) Admin CRM (Port 8095) açıksa doğrudan oradan da kontrol et
        urls.append(f"http://127.0.0.1:8095/api/cloud-registry?t={ts}")
        return urls

    def _read_saved_license_file(self) -> dict:
        if os.path.isfile(self.license_file):
            try:
                with open(self.license_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _write_saved_license_file(self, data: dict):
        try:
            with open(self.license_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def sync_with_cloud(self, force: bool = False, timeout: float = 3.5) -> Dict[str, Any]:
        """
        Merkezi GitHub / Admin CRM bulut kayıt defterinden (`licenses_cloud.json`)
        bu eczanenin lisans durumunu sorgular:
        - Süresi uzatılmışsa yeni anahtarı otomatik indirip kaydeder.
        - Yönetici tarafından ASKIDA (Pasif) yapılmışsa erişimi durdurur.
        - Tekrar AKTİF yapılmışsa kilidi otomatik kaldırır.
        """
        now_ts = time.time()
        if not force and (now_ts - self._last_cloud_sync_ts) < self._cloud_cache_ttl:
            return {"synced": False, "cached": True}

        self._last_cloud_sync_ts = now_ts
        saved = self._read_saved_license_file()
        my_hwid = self.get_hardware_id()
        my_key = (saved.get("license_key") or "").strip()
        my_name_norm = _normalize_tr(saved.get("pharmacy_name") or "")
        my_gln = (saved.get("gln_no") or "").strip()
        my_crm_id = (saved.get("crm_id") or "").strip()

        cloud_data = None
        source_url = ""
        for url in self._get_cloud_registry_urls():
            try:
                req = urllib.request.Request(
                    url,
                    headers={"User-Agent": "FarmaRadar-LicenseClient/1.3", "Cache-Control": "no-cache"}
                )
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    if resp.status == 200:
                        raw = resp.read().decode("utf-8", errors="replace")
                        parsed = json.loads(raw)
                        if isinstance(parsed, dict) and isinstance(parsed.get("items"), list):
                            # İmza kontrolü (varsa doğrula)
                            given_sig = parsed.get("signature", "")
                            if given_sig:
                                exp_sig = self.sign_cloud_registry(parsed["items"], parsed.get("updated_at", ""))
                                if not hmac.compare_digest(given_sig.upper(), exp_sig):
                                    continue
                            cloud_data = parsed
                            source_url = url
                            break
            except Exception:
                continue

        if not cloud_data:
            return {"synced": False, "message": "Bulut lisans sunucusuna ulaşılamadı (Çevrimdışı mod)."}

        items = cloud_data.get("items") or []
        matched_record = None

        # 1. Öncelik: CRM ID veya birebir Lisans Anahtarı veya Donanım Kilidi (HWID) eşleşmesi
        for item in items:
            it_id = (item.get("id") or "").strip()
            it_key = (item.get("license_key") or "").strip()
            it_hwid = (item.get("hwid_lock") or "ANY").strip().upper()
            if my_crm_id and it_id and my_crm_id == it_id:
                matched_record = item
                break
            if my_key and it_key and my_key == it_key:
                matched_record = item
                break
            if it_hwid and it_hwid != "ANY" and it_hwid == my_hwid:
                matched_record = item
                break

        # 2. Öncelik: GLN Numarası veya Eczane Adı eşleşmesi (Varsayılan kurulum adı hariç veya CRM'de kayıtlıysa)
        if not matched_record:
            for item in items:
                it_gln = (item.get("gln_no") or "").strip()
                it_name_norm = _normalize_tr(item.get("pharmacy_name") or "")
                if my_gln and it_gln and my_gln == it_gln:
                    matched_record = item
                    break
                if my_name_norm and it_name_norm and my_name_norm == it_name_norm:
                    matched_record = item
                    break

        if not matched_record:
            return {"synced": True, "matched": False, "source": source_url}

        # Eşleşen kayıt bulundu! Şimdi durumu (AKTIF / ASKIDA) ve yeni lisans anahtarını uygula
        remote_status = (matched_record.get("status") or "AKTIF").strip().upper()
        remote_key = (matched_record.get("license_key") or "").strip()
        remote_exp = (matched_record.get("expires_at") or "").strip()
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if remote_key and (remote_key != my_key or saved.get("expires_at") != remote_exp):
            # Yönetici süreyi uzatmış veya bilgileri güncellemiş; yeni anahtarı doğrula ve kaydet
            v_res = self.verify_license_key(remote_key)
            if v_res.get("pharmacy_name"):
                saved["license_key"] = remote_key
                saved["pharmacy_name"] = v_res.get("pharmacy_name", matched_record.get("pharmacy_name", ""))
                saved["expires_at"] = v_res.get("expires_at", remote_exp)
                saved["max_pcs"] = v_res.get("max_pcs", matched_record.get("max_pcs", 15))
                saved["hwid_lock"] = v_res.get("hwid_lock", matched_record.get("hwid_lock", "ANY"))
                saved["plan"] = v_res.get("plan", matched_record.get("plan", "PRO_YILLIK"))

        saved["crm_id"] = matched_record.get("id", saved.get("crm_id", ""))
        saved["remote_status"] = remote_status
        saved["remote_checked_at"] = now_str
        saved["my_hwid"] = my_hwid
        self._write_saved_license_file(saved)

        return {
            "synced": True,
            "matched": True,
            "remote_status": remote_status,
            "expires_at": saved.get("expires_at", remote_exp),
            "pharmacy_name": saved.get("pharmacy_name", matched_record.get("pharmacy_name", "")),
            "checked_at": now_str
        }

    def ensure_default_license(self, force_cloud: bool = False) -> Dict[str, Any]:
        """Kurulu sistemde license.json varsa doğrular ve bulut ile senkronize eder."""
        # Önce bulut senkronizasyonunu çalıştır (3 dk önbellekli veya force_cloud=True ise anında)
        try:
            self.sync_with_cloud(force=force_cloud)
        except Exception:
            pass

        if os.path.isfile(self.license_file):
            try:
                saved = self._read_saved_license_file()
                key = saved.get("license_key", "")
                if key:
                    res = self.verify_license_key(key)
                    res["activated_at"] = saved.get("activated_at", "")
                    res["remote_checked_at"] = saved.get("remote_checked_at", "")
                    res["crm_id"] = saved.get("crm_id", "")
                    if saved.get("pharmacist_name"):
                        res["pharmacist_name"] = saved["pharmacist_name"]
                    if saved.get("phone"):
                        res["phone"] = saved["phone"]
                    if saved.get("city"):
                        res["city"] = saved["city"]

                    # Uzaktan yönetici tarafından ASKIDA (Pasif) yapıldıysa erişimi engelle!
                    remote_st = (saved.get("remote_status") or "AKTIF").strip().upper()
                    if remote_st == "ASKIDA":
                        res["valid"] = False
                        res["suspended"] = True
                        res["status"] = "ASKIDA"
                        res["message"] = (
                            f"Lisansınız ({res.get('pharmacy_name', 'Eczane')}) yönetici tarafından askıya alınmıştır. "
                            f"Lütfen Farma Radar yöneticinizle iletişime geçin."
                        )
                    return res
            except Exception:
                pass

        default_pharmacy = "FARMA RADAR ECZANESİ"
        default_key = self.generate_license_key(
            pharmacy_name=default_pharmacy,
            gln_no="",
            expires_at="2027-12-31",
            max_pcs=15,
            hwid_lock="ANY",
            plan="KURUMSAL_PRO"
        )
        self.activate_license(default_key)
        return self.verify_license_key(default_key)

    def activate_license(
        self,
        key_str: str,
        pharmacist_name: str = "",
        phone: str = "",
        city: str = ""
    ) -> Dict[str, Any]:
        """Lisans anahtarını doğrular ve üye eczacı iletişim bilgileriyle birlikte license.json'a kaydeder."""
        check = self.verify_license_key(key_str)
        if not check.get("valid"):
            return check

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        final_pharmacist = pharmacist_name.strip() or check.get("pharmacist_name", "")
        final_phone = phone.strip() or check.get("phone", "")
        final_city = city.strip() or check.get("city", "")

        save_data = {
            "license_key": key_str.strip(),
            "pharmacy_name": check["pharmacy_name"],
            "pharmacist_name": final_pharmacist,
            "phone": final_phone,
            "city": final_city,
            "gln_no": check.get("gln_no", ""),
            "expires_at": check["expires_at"],
            "max_pcs": check.get("max_pcs", 10),
            "hwid_lock": check.get("hwid_lock", "ANY"),
            "plan": check.get("plan", "PRO_YILLIK"),
            "remote_status": "AKTIF",
            "activated_at": now_str,
            "my_hwid": self.get_hardware_id(),
            "pc_name": socket.gethostname()
        }
        try:
            self._write_saved_license_file(save_data)
            # Yeni anahtar girildiğinde bulut durumuyla da senkronize et
            self.sync_with_cloud(force=True)
            saved_after = self._read_saved_license_file()
            if (saved_after.get("remote_status") or "").upper() == "ASKIDA":
                return {
                    "valid": False,
                    "suspended": True,
                    "status": "ASKIDA",
                    "pharmacy_name": check["pharmacy_name"],
                    "message": "Bu eczane lisansı yönetici panelinde ASKIDA (Pasif) durumdadır."
                }
        except Exception as e:
            return {"valid": False, "message": f"Lisans dosyası kaydedilemedi: {str(e)}"}

        check["activated_at"] = now_str
        check["pharmacist_name"] = final_pharmacist
        check["phone"] = final_phone
        check["city"] = final_city
        return check

    def get_status(self, force_cloud: bool = False) -> Dict[str, Any]:
        """Mevcut lisans durumunu (bulut doğrulaması dahil) ve bu bilgisayarın HWID bilgisini döndürür."""
        info = self.ensure_default_license(force_cloud=force_cloud)
        info["my_hwid"] = self.get_hardware_id()
        info["pc_name"] = socket.gethostname()
        return info


license_manager = LicenseManager()
