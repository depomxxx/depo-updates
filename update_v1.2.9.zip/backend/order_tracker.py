# -*- coding: utf-8 -*-
"""
backend/order_tracker.py
------------------------
Eczane İçi Tüm Bilgisayarlar Arası Ortak Günlük Sipariş & Sepet Takip Modülü.

Mimari:
- Eczanedeki tüm bilgisayarlar aynı Tria Oracle (veya Botanik MS SQL) veritabanına bağlandığı için,
  sipariş/sepet durumlarını doğrudan merkezi veritabanındaki yardımcı tabloda (`TBL_EDA_GUNLUK_SIPARIS` / `EdaGunlukSiparis`)
  ve eşzamanlı olarak yerel SQLite yedeğinde tutar.
- Böylece Masa 1'de bir ürün toplu veya tekil olarak sipariş verilip sonlandırıldığında (veya sepete eklendiğinde),
  Masa 2 ve Masa 3'teki ekranlarda da anında "SİPARİŞ VERİLDİ" / "SEPETTE" olarak görünür ve mükerrer sipariş önlenir.
"""

import os
import socket
import sqlite3
import datetime
import threading
from pathlib import Path
from typing import Dict, Any, List, Optional


class SharedOrderTracker:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = Path(base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.data_dir = self.base_dir / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.sqlite_path = self.data_dir / "shared_orders_local.db"
        self.hostname = socket.gethostname()
        self.pc_name = self.hostname
        self._lock = threading.Lock()
        self._tria_table_ready = False
        self._botanik_table_ready = False
        self._tebeos_table_ready = False
        self._init_local_sqlite()

    def _today_str(self) -> str:
        return datetime.date.today().strftime("%Y-%m-%d")

    def _now_time_str(self) -> str:
        return datetime.datetime.now().strftime("%H:%M")

    def _init_local_sqlite(self):
        try:
            with sqlite3.connect(self.sqlite_path, timeout=5) as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS daily_orders (
                        tarih TEXT NOT NULL,
                        barkod TEXT NOT NULL,
                        urun_adi TEXT,
                        durum TEXT NOT NULL,
                        depo TEXT,
                        miktar INTEGER DEFAULT 1,
                        masa_adi TEXT,
                        saat TEXT,
                        updated_at REAL,
                        PRIMARY KEY (tarih, barkod)
                    )
                """)
                conn.commit()
        except Exception as e:
            print(f"[OrderTracker] Yerel SQLite başlatma uyarısı: {e}")

    def _ensure_tria_table(self, conn) -> bool:
        if self._tria_table_ready:
            return True
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT COUNT(*) FROM USER_TABLES WHERE TABLE_NAME = 'TBL_EDA_GUNLUK_SIPARIS'
            """)
            exists = cur.fetchone()[0] > 0
            if not exists:
                cur.execute("""
                    CREATE TABLE TBL_EDA_GUNLUK_SIPARIS (
                        TARIH VARCHAR2(16) NOT NULL,
                        BARKOD VARCHAR2(32) NOT NULL,
                        URUN_ADI VARCHAR2(255),
                        DURUM VARCHAR2(32) NOT NULL,
                        DEPO VARCHAR2(64),
                        MIKTAR NUMBER(10) DEFAULT 1,
                        MASA_ADI VARCHAR2(128),
                        SAAT VARCHAR2(16),
                        GUNCELLEME_ZAMANI DATE DEFAULT SYSDATE,
                        CONSTRAINT PK_EDA_GUNLUK_SIP PRIMARY KEY (TARIH, BARKOD)
                    )
                """)
                conn.commit()
            self._tria_table_ready = True
            return True
        except Exception as e:
            if "ORA-00955" in str(e):
                self._tria_table_ready = True
                return True
            print(f"[OrderTracker] Tria tablo hazırlama uyarısı: {e}")
            return False

    def _ensure_botanik_table(self, conn) -> bool:
        if self._botanik_table_ready:
            return True
        try:
            cur = conn.cursor()
            cur.execute("""
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EdaGunlukSiparis' AND xtype='U')
                CREATE TABLE EdaGunlukSiparis (
                    Tarih VARCHAR(16) NOT NULL,
                    Barkod VARCHAR(32) NOT NULL,
                    UrunAdi NVARCHAR(255),
                    Durum VARCHAR(32) NOT NULL,
                    Depo VARCHAR(64),
                    Miktar INT DEFAULT 1,
                    MasaAdi NVARCHAR(128),
                    Saat VARCHAR(16),
                    GuncellemeZamani DATETIME DEFAULT GETDATE(),
                    CONSTRAINT PK_EdaGunlukSiparis PRIMARY KEY (Tarih, Barkod)
                )
            """)
            conn.commit()
            self._botanik_table_ready = True
            return True
        except Exception as e:
            print(f"[OrderTracker] Botanik tablo hazırlama uyarısı: {e}")
            return False

    def _ensure_tebeos_table(self, conn) -> bool:
        if self._tebeos_table_ready:
            return True
        try:
            conn.query("""
                CREATE TABLE IF NOT EXISTS public.eda_gunluk_siparis (
                    tarih VARCHAR(16) NOT NULL,
                    barkod VARCHAR(32) NOT NULL,
                    urun_adi VARCHAR(255),
                    durum VARCHAR(32) NOT NULL,
                    depo VARCHAR(64),
                    miktar INTEGER DEFAULT 1,
                    masa_adi VARCHAR(128),
                    saat VARCHAR(16),
                    guncelleme_zamani TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (tarih, barkod)
                )
            """)
            self._tebeos_table_ready = True
            return True
        except Exception as e:
            print(f"[OrderTracker] TEBEOS tablo hazırlama uyarısı: {e}")
            return False

    def _normalize_barcode(self, barcode: str, urun_adi: str = "") -> str:
        bc = str(barcode or "").strip()
        if len(bc) == 14 and bc.startswith("0"):
            bc = bc[1:]
        if bc:
            try:
                from backend.catalog import catalog
                can = catalog.resolve_canonical_barcode(bc)
                if can:
                    return can
            except Exception:
                pass
            return bc
        if urun_adi:
            try:
                from backend.catalog import catalog
                suggs = catalog.search_suggestions(urun_adi, limit=1)
                if suggs and suggs[0].get("barcode"):
                    return str(suggs[0]["barcode"]).strip()
            except Exception:
                pass
        return bc

    def mark_items(
        self,
        items: List[Dict[str, Any]],
        durum: str = "SIPARIS_VERILDI",
        default_depo: str = "",
        masa_adi: Optional[str] = None
    ) -> int:
        """
        Verilen ürün listesini ('SIPARIS_VERILDI' veya 'SEPETTE') olarak hem merkezi veritabanına
        (Tria Oracle / Botanik MS SQL) hem de yerel önbelleğe kaydeder.
        Eğer ürün zaten 'SIPARIS_VERILDI' ise ve yeni gelen durum 'SEPETTE' ise,
        'SIPARIS_VERILDI' statüsünü korur (düşürmez).
        """
        if not items:
            return 0

        tarih = self._today_str()
        saat = self._now_time_str()
        masa = (masa_adi or self.hostname or "Eczane-PC").strip()

        normalized_records = []
        for it in items:
            raw_bc = str(it.get("barkod") or it.get("barcode") or it.get("urun_id") or it.get("kod") or "").strip()
            raw_name = str(it.get("urun_adi") or it.get("name") or it.get("ad") or "").strip()
            bc = self._normalize_barcode(raw_bc, raw_name)
            if not bc and not raw_name:
                continue
            key_bc = bc or raw_name[:30].upper()
            depo = str(it.get("depo") or it.get("assigned_depo") or default_depo or "DEPO").strip().upper()
            try:
                miktar = max(1, int(it.get("miktar") or it.get("adet") or 1))
            except Exception:
                miktar = 1

            normalized_records.append({
                "tarih": tarih,
                "barkod": key_bc[:32],
                "raw_barkod": raw_bc[:32] if raw_bc else key_bc[:32],
                "urun_adi": (raw_name or key_bc)[:250],
                "durum": durum,
                "depo": depo[:60],
                "miktar": miktar,
                "masa_adi": masa[:120],
                "saat": saat
            })

        if not normalized_records:
            return 0

        # 1. Yerel SQLite'a kaydet
        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    for rec in normalized_records:
                        for b_key in {rec["barkod"], rec["raw_barkod"]}:
                            if not b_key:
                                continue
                            s_cur.execute(
                                "SELECT durum, miktar, depo FROM daily_orders WHERE tarih = ? AND barkod = ?",
                                (tarih, b_key)
                            )
                            existing = s_cur.fetchone()
                            if existing and existing[0] == "SIPARIS_VERILDI" and rec["durum"] == "SEPETTE":
                                continue
                            s_cur.execute("""
                                INSERT OR REPLACE INTO daily_orders
                                (tarih, barkod, urun_adi, durum, depo, miktar, masa_adi, saat, updated_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, strftime('%s','now'))
                            """, (
                                tarih, b_key, rec["urun_adi"], rec["durum"],
                                rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"]
                            ))
                    s_conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Yerel SQLite yazma uyarısı: {e}")

        # 2. Merkezi Veritabanına (Tria Oracle, Botanik MS SQL veya TEBEOS PostgreSQL) kaydet
        active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
        if active_oto == "TRIA":
            self._write_to_tria(normalized_records)
        elif active_oto == "BOTANIK":
            self._write_to_botanik(normalized_records)
        elif active_oto == "TEBEOS":
            self._write_to_tebeos(normalized_records)

        return len(normalized_records)

    def _write_to_tria(self, records: List[Dict[str, Any]]):
        try:
            from backend.tria_client import tria_client
            with tria_client.get_connection() as conn:
                if not self._ensure_tria_table(conn):
                    return
                cur = conn.cursor()
                for rec in records:
                    for b_key in {rec["barkod"], rec["raw_barkod"]}:
                        if not b_key:
                            continue
                        cur.execute("""
                            SELECT DURUM FROM TBL_EDA_GUNLUK_SIPARIS
                            WHERE TARIH = :t AND BARKOD = :b
                        """, {"t": rec["tarih"], "b": b_key})
                        row = cur.fetchone()
                        if row:
                            if row[0] == "SIPARIS_VERILDI" and rec["durum"] == "SEPETTE":
                                continue
                            cur.execute("""
                                UPDATE TBL_EDA_GUNLUK_SIPARIS
                                SET URUN_ADI = :u, DURUM = :d, DEPO = :dp, MIKTAR = :m,
                                    MASA_ADI = :ms, SAAT = :s, GUNCELLEME_ZAMANI = SYSDATE
                                WHERE TARIH = :t AND BARKOD = :b
                            """, {
                                "u": rec["urun_adi"], "d": rec["durum"], "dp": rec["depo"],
                                "m": rec["miktar"], "ms": rec["masa_adi"], "s": rec["saat"],
                                "t": rec["tarih"], "b": b_key
                            })
                        else:
                            cur.execute("""
                                INSERT INTO TBL_EDA_GUNLUK_SIPARIS
                                (TARIH, BARKOD, URUN_ADI, DURUM, DEPO, MIKTAR, MASA_ADI, SAAT, GUNCELLEME_ZAMANI)
                                VALUES (:t, :b, :u, :d, :dp, :m, :ms, :s, SYSDATE)
                            """, {
                                "t": rec["tarih"], "b": b_key, "u": rec["urun_adi"],
                                "d": rec["durum"], "dp": rec["depo"], "m": rec["miktar"],
                                "ms": rec["masa_adi"], "s": rec["saat"]
                            })
                conn.commit()
        except Exception as e:
            print(f"[OrderTracker] Tria merkezi sipariş kayıt uyarısı: {e}")

    def _write_to_botanik(self, records: List[Dict[str, Any]]):
        try:
            from backend.botanik_client import botanik_client
            with botanik_client.get_connection() as conn:
                if not self._ensure_botanik_table(conn):
                    return
                cur = conn.cursor()
                for rec in records:
                    for b_key in {rec["barkod"], rec["raw_barkod"]}:
                        if not b_key:
                            continue
                        cur.execute("""
                            SELECT Durum FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?
                        """, (rec["tarih"], b_key))
                        row = cur.fetchone()
                        if row:
                            if row[0] == "SIPARIS_VERILDI" and rec["durum"] == "SEPETTE":
                                continue
                            cur.execute("""
                                UPDATE EdaGunlukSiparis
                                SET UrunAdi = ?, Durum = ?, Depo = ?, Miktar = ?,
                                    MasaAdi = ?, Saat = ?, GuncellemeZamani = GETDATE()
                                WHERE Tarih = ? AND Barkod = ?
                            """, (
                                rec["urun_adi"], rec["durum"], rec["depo"], rec["miktar"],
                                rec["masa_adi"], rec["saat"], rec["tarih"], b_key
                            ))
                        else:
                            cur.execute("""
                                INSERT INTO EdaGunlukSiparis
                                (Tarih, Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat, GuncellemeZamani)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, GETDATE())
                            """, (
                                rec["tarih"], b_key, rec["urun_adi"], rec["durum"],
                                rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"]
                            ))
                conn.commit()
        except Exception as e:
            print(f"[OrderTracker] Botanik merkezi sipariş kayıt uyarısı: {e}")

    def _write_to_tebeos(self, records: List[Dict[str, Any]]):
        try:
            from backend.tebeos_client import tebeos_client, _sql_lit
            with tebeos_client.get_connection() as conn:
                if not self._ensure_tebeos_table(conn):
                    return
                for rec in records:
                    for b_key in {rec["barkod"], rec["raw_barkod"]}:
                        if not b_key:
                            continue
                        t_lit = _sql_lit(rec["tarih"])
                        b_lit = _sql_lit(b_key)
                        u_lit = _sql_lit(rec["urun_adi"])
                        d_lit = _sql_lit(rec["durum"])
                        dp_lit = _sql_lit(rec["depo"])
                        m_lit = int(rec["miktar"] or 1)
                        ms_lit = _sql_lit(rec["masa_adi"])
                        s_lit = _sql_lit(rec["saat"])
                        _, rows = conn.query(f"SELECT durum FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND barkod = {b_lit}")
                        if rows:
                            if rows[0][0] == "SIPARIS_VERILDI" and rec["durum"] == "SEPETTE":
                                continue
                            conn.query(f"""
                                UPDATE public.eda_gunluk_siparis
                                SET urun_adi = {u_lit}, durum = {d_lit}, depo = {dp_lit}, miktar = {m_lit},
                                    masa_adi = {ms_lit}, saat = {s_lit}, guncelleme_zamani = CURRENT_TIMESTAMP
                                WHERE tarih = {t_lit} AND barkod = {b_lit}
                            """)
                        else:
                            conn.query(f"""
                                INSERT INTO public.eda_gunluk_siparis
                                (tarih, barkod, urun_adi, durum, depo, miktar, masa_adi, saat, guncelleme_zamani)
                                VALUES ({t_lit}, {b_lit}, {u_lit}, {d_lit}, {dp_lit}, {m_lit}, {ms_lit}, {s_lit}, CURRENT_TIMESTAMP)
                            """)
        except Exception as e:
            print(f"[OrderTracker] TEBEOS merkezi sipariş kayıt uyarısı: {e}")

    def unmark_item(self, barcode: str, urun_adi: str = "") -> bool:
        """Ürünün 'Sipariş Verildi / Sepette' işaretini tüm bilgisayarlar için kaldırır."""
        tarih = self._today_str()
        bc = self._normalize_barcode(barcode, urun_adi)
        keys = {str(barcode or "").strip(), bc}
        keys = {k for k in keys if k}
        if not keys:
            return False

        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    for k in keys:
                        s_cur.execute("DELETE FROM daily_orders WHERE tarih = ? AND barkod = ?", (tarih, k))
                    s_conn.commit()
            except Exception:
                pass

        active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        for k in keys:
                            cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND BARKOD = :b", {"t": tarih, "b": k})
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Tria silme uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        for k in keys:
                            cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?", (tarih, k))
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Botanik silme uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        t_lit = _sql_lit(tarih)
                        for k in keys:
                            conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND barkod = {_sql_lit(k)}")
            except Exception as e:
                print(f"[OrderTracker] TEBEOS silme uyarısı: {e}")
        return True

    def clear_cart_items_for_depo(self, depo: str) -> bool:
        """İlgili deponun sepeti boşaltıldığında ('SEPETTE' durumundaki) kayıtları tüm bilgisayarlar için temizler."""
        tarih = self._today_str()
        clean_depo = str(depo or "").strip().upper()
        if not clean_depo:
            return False

        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    s_cur.execute(
                        "DELETE FROM daily_orders WHERE tarih = ? AND UPPER(depo) = ? AND durum = 'SEPETTE'",
                        (tarih, clean_depo)
                    )
                    s_conn.commit()
            except Exception:
                pass

        active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND UPPER(DEPO) = :d AND DURUM = 'SEPETTE'",
                            {"t": tarih, "d": clean_depo}
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Tria sepet temizleme uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(Depo) = ? AND Durum = 'SEPETTE'",
                            (tarih, clean_depo)
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Botanik sepet temizleme uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        t_lit = _sql_lit(tarih)
                        d_lit = _sql_lit(clean_depo)
                        conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND UPPER(depo) = {d_lit} AND durum = 'SEPETTE'")
            except Exception as e:
                print(f"[OrderTracker] TEBEOS sepet temizleme uyarısı: {e}")
        return True

    def get_today_orders_map(self) -> Dict[str, Dict[str, Any]]:
        """
        Bugün sipariş verilen veya sepete eklenen tüm ürünleri {barkod: {...}} sözlüğü olarak döner.
        Merkezi veritabanından (Tria / Botanik / TEBEOS) okur, böylece tüm bilgisayarlar aynı ekranı görür.
        """
        tarih = self._today_str()
        result: Dict[str, Dict[str, Any]] = {}

        # 1. Önce yerel SQLite'tan oku
        try:
            with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                s_cur = s_conn.cursor()
                s_cur.execute("""
                    SELECT barkod, urun_adi, durum, depo, miktar, masa_adi, saat
                    FROM daily_orders WHERE tarih = ?
                """, (tarih,))
                for r in s_cur.fetchall():
                    result[str(r[0])] = {
                        "barkod": str(r[0]),
                        "urun_adi": str(r[1] or ""),
                        "durum": str(r[2] or "SIPARIS_VERILDI"),
                        "depo": str(r[3] or "DEPO"),
                        "miktar": int(r[4] or 1),
                        "masa_adi": str(r[5] or ""),
                        "saat": str(r[6] or "")
                    }
        except Exception:
            pass

        # 2. Merkezi veritabanından (Tria Oracle / Botanik MS SQL / TEBEOS PostgreSQL) oku
        active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT BARKOD, URUN_ADI, DURUM, DEPO, MIKTAR, MASA_ADI, SAAT
                            FROM TBL_EDA_GUNLUK_SIPARIS
                            WHERE TARIH = :t
                        """, {"t": tarih})
                        for r in cur.fetchall():
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            result[bc] = {
                                "barkod": bc,
                                "urun_adi": str(r[1] or ""),
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
            except Exception as e:
                print(f"[OrderTracker] Tria okuma uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat
                            FROM EdaGunlukSiparis
                            WHERE Tarih = ?
                        """, (tarih,))
                        for r in cur.fetchall():
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            result[bc] = {
                                "barkod": bc,
                                "urun_adi": str(r[1] or ""),
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
            except Exception as e:
                print(f"[OrderTracker] Botanik okuma uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        _, rows = conn.query(f"""
                            SELECT barkod, urun_adi, durum, depo, miktar, masa_adi, saat
                            FROM public.eda_gunluk_siparis
                            WHERE tarih = {_sql_lit(tarih)}
                        """)
                        for r in rows:
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            result[bc] = {
                                "barkod": bc,
                                "urun_adi": str(r[1] or ""),
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
            except Exception as e:
                print(f"[OrderTracker] TEBEOS okuma uyarısı: {e}")

        return result


order_tracker = SharedOrderTracker()
