# -*- coding: utf-8 -*-
"""
backend/tebeos_client.py
------------------------
TEBEOS (Türk Eczacıları Birliği Eczane Otomasyon Sistemi - PostgreSQL) Veri Erişim & Analiz Modülü.
Hiçbir harici kütüphane (psycopg2 / pg8000) gerektirmeden, %100 saf Python PostgreSQL v3 Wire Protocol
üzerinden (Port 5454) eczane raf stoğu, aylık nakit ve SGK reçeteli satış hareketlerini (ÇIKIŞ),
depolardan gelen alış faturalarını (GİRİŞ) ve SGK eşdeğer ilaç gruplarını sorgular.
"""

import os
import re
import time
import socket
import struct
import hashlib
import hmac
import base64
import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any, List, Optional, Tuple


def _sql_lit(val: Any) -> str:
    """Değeri güvenli PostgreSQL SQL literal formatına dönüştürür."""
    if val is None:
        return "NULL"
    if isinstance(val, bool):
        return "TRUE" if val else "FALSE"
    if isinstance(val, (int, float)):
        return str(val)
    s = str(val).replace("\x00", "").replace("'", "''")
    return f"'{s}'"


def _sql_in(values: List[Any]) -> str:
    if not values:
        return "('')"
    return "(" + ", ".join(_sql_lit(v) for v in values) + ")"


class TebeosWireConnection:
    """
    Harici C/pip bağımlılığı olmadan (runtime/Tria.exe ile %100 uyumlu)
    PostgreSQL v3 Wire Protocol (TCP 5454) bağlantı sınıfı.
    Trust (0), Cleartext (3), MD5 (5) ve SCRAM-SHA-256 (10) kimlik doğrulamalarını destekler.
    """
    def __init__(self, host: str, port: int = 5454, user: str = "tebeos", password: str = "123", database: str = "tebeos_db", timeout: float = 5.0):
        self.host = host
        self.port = int(port)
        self.user = user
        self.password = password
        self.database = database
        self.timeout = timeout
        self.sock: Optional[socket.socket] = None

    def connect(self):
        self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        params = (
            f"user\x00{self.user}\x00"
            f"database\x00{self.database}\x00"
            f"client_encoding\x00UTF8\x00"
            f"application_name\x00EczaneDepoPro\x00\x00"
        ).encode("utf-8")
        startup_pkt = struct.pack("!II", len(params) + 8, 196608) + params
        self.sock.sendall(startup_pkt)

        while True:
            mtype, body = self._recv_msg()
            if mtype == "R":
                auth_type = struct.unpack("!I", body[:4])[0]
                if auth_type == 0:
                    continue
                elif auth_type == 3:
                    # Cleartext password
                    payload = self.password.encode("utf-8") + b"\x00"
                    self.sock.sendall(b"p" + struct.pack("!I", len(payload) + 4) + payload)
                elif auth_type == 5:
                    # MD5 password
                    salt = body[4:8]
                    h1 = hashlib.md5((self.password + self.user).encode("utf-8")).hexdigest()
                    h2 = "md5" + hashlib.md5(h1.encode("ascii") + salt).hexdigest()
                    payload = h2.encode("ascii") + b"\x00"
                    self.sock.sendall(b"p" + struct.pack("!I", len(payload) + 4) + payload)
                elif auth_type == 10:
                    # SCRAM-SHA-256
                    self._handle_scram_sha256()
                else:
                    raise RuntimeError(f"Desteklenmeyen PostgreSQL auth tipi: {auth_type}")
            elif mtype == "E":
                raise RuntimeError(self._parse_error(body))
            elif mtype == "Z":
                break
        return self

    def _handle_scram_sha256(self):
        client_nonce = base64.b64encode(os.urandom(18)).decode("ascii")
        client_first_bare = f"n=,r={client_nonce}"
        gs2_header = "n,,"
        client_first_msg = (gs2_header + client_first_bare).encode("utf-8")
        mech = b"SCRAM-SHA-256\x00"
        sasl_initial = mech + struct.pack("!I", len(client_first_msg)) + client_first_msg
        self.sock.sendall(b"p" + struct.pack("!I", len(sasl_initial) + 4) + sasl_initial)

        mtype, body = self._recv_msg()
        if mtype == "E":
            raise RuntimeError(self._parse_error(body))
        auth_sub = struct.unpack("!I", body[:4])[0]
        if auth_sub != 11:
            raise RuntimeError(f"SCRAM adım hatası: {auth_sub}")
        server_first = body[4:].decode("utf-8")
        parts = dict(item.split("=", 1) for item in server_first.split(","))
        r_nonce = parts["r"]
        salt = base64.b64decode(parts["s"])
        iters = int(parts["i"])

        salted_pwd = hashlib.pbkdf2_hmac("sha256", self.password.encode("utf-8"), salt, iters)
        client_key = hmac.new(salted_pwd, b"Client Key", hashlib.sha256).digest()
        stored_key = hashlib.sha256(client_key).digest()
        client_final_without_proof = f"c={base64.b64encode(gs2_header.encode()).decode()},r={r_nonce}"
        auth_msg = f"{client_first_bare},{server_first},{client_final_without_proof}".encode("utf-8")
        client_sig = hmac.new(stored_key, auth_msg, hashlib.sha256).digest()
        client_proof = bytes(a ^ b for a, b in zip(client_key, client_sig))
        client_final = f"{client_final_without_proof},p={base64.b64encode(client_proof).decode()}".encode("utf-8")
        self.sock.sendall(b"p" + struct.pack("!I", len(client_final) + 4) + client_final)

    def _recv_exact(self, n: int) -> bytes:
        buf = bytearray()
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("PostgreSQL bağlantısı kapandı.")
            buf.extend(chunk)
        return bytes(buf)

    def _recv_msg(self) -> Tuple[str, bytes]:
        hdr = self._recv_exact(5)
        mtype = chr(hdr[0])
        mlen = struct.unpack("!I", hdr[1:5])[0] - 4
        body = self._recv_exact(mlen) if mlen > 0 else b""
        return mtype, body

    def _parse_error(self, body: bytes) -> str:
        msgs = []
        pos = 0
        while pos < len(body):
            code = body[pos]
            if code == 0:
                break
            end = body.find(b"\x00", pos + 1)
            if end == -1:
                break
            val = body[pos + 1:end].decode("utf-8", errors="replace")
            if chr(code) in ("M", "D", "H"):
                msgs.append(val)
            pos = end + 1
        return " | ".join(msgs) if msgs else body.decode("utf-8", errors="replace")

    def query(self, sql: str) -> Tuple[List[str], List[List[Optional[str]]]]:
        """SQL sorgusunu çalıştırır ve (kolon_listesi, satir_listesi) döner."""
        q_bytes = sql.encode("utf-8") + b"\x00"
        self.sock.sendall(b"Q" + struct.pack("!I", len(q_bytes) + 4) + q_bytes)
        cols: List[str] = []
        rows: List[List[Optional[str]]] = []
        err_msg: Optional[str] = None

        while True:
            mtype, body = self._recv_msg()
            if mtype == "T":
                ncols = struct.unpack("!H", body[:2])[0]
                pos = 2
                cols = []
                for _ in range(ncols):
                    end = body.index(b"\x00", pos)
                    cols.append(body[pos:end].decode("utf-8", errors="replace"))
                    pos = end + 19
            elif mtype == "D":
                ncols = struct.unpack("!H", body[:2])[0]
                pos = 2
                row: List[Optional[str]] = []
                for _ in range(ncols):
                    clen = struct.unpack("!i", body[pos:pos + 4])[0]
                    pos += 4
                    if clen == -1:
                        row.append(None)
                    else:
                        row.append(body[pos:pos + clen].decode("utf-8", errors="replace"))
                        pos += clen
                rows.append(row)
            elif mtype == "E":
                err_msg = self._parse_error(body)
            elif mtype == "Z":
                break

        if err_msg:
            raise RuntimeError(err_msg)
        return cols, rows

    def close(self):
        if self.sock:
            try:
                self.sock.sendall(b"X\x00\x00\x00\x04")
            except Exception:
                pass
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None

    def __enter__(self):
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class TebeosPGClient:
    """
    TEBEOS Eczane Otomasyonu (PostgreSQL - Port 5454) İstemcisi.
    Botanik ve TRIA ile birebir aynı veri şemasını üretir.
    """
    # TEBEOS Hareket Tipi Grupları (public.urun_hareket_tip_lp)
    # SGK / Kurum / Medula Reçeteli Satış Çıkışları
    RECETE_CIKIS_TIPLERI = (9, 27, 29, 37, 53, 56)
    # Nakit / Elden / Veresiye / Reçetesiz Satış Çıkışları
    NAKIT_CIKIS_TIPLERI = (11, 13, 25)
    # Tüm Satış Çıkışları
    TUM_SATIS_CIKIS_TIPLERI = (9, 11, 13, 25, 27, 29, 37, 53, 56)

    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self._discovered_host: Optional[str] = None

    def get_config(self) -> Dict[str, Any]:
        host = os.environ.get("TEBEOS_DB_HOST", "").strip()
        port_str = os.environ.get("TEBEOS_DB_PORT", "5454").strip()
        database = os.environ.get("TEBEOS_DB_DATABASE", "tebeos_db").strip()
        user = os.environ.get("TEBEOS_DB_USER", "tebeos").strip()
        password = os.environ.get("TEBEOS_DB_PASSWORD", "123").strip()

        try:
            port = int(port_str or 5454)
        except Exception:
            port = 5454

        return {
            "host": host or self._discovered_host or "127.0.0.1",
            "port": port,
            "database": database or "tebeos_db",
            "user": user or "tebeos",
            "password": password or "123"
        }

    def _get_local_subnet_ips(self) -> List[str]:
        ips = []
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            parts = local_ip.split(".")
            if len(parts) == 4 and parts[0] in ("192", "10", "172"):
                prefix = f"{parts[0]}.{parts[1]}.{parts[2]}."
                ips = [f"{prefix}{i}" for i in range(1, 255) if f"{prefix}{i}" != local_ip]
        except Exception:
            pass
        return ips

    def discover_tebeos_host(self, port: int = 5454) -> Dict[str, Any]:
        """
        Yerel makinede (127.0.0.1) veya eczane yerel ağında (LAN) Port 5454 üzerinden
        çalışan TEBEOS PostgreSQL ana bilgisayarını ~150ms içinde otomatik tespit eder.
        """
        t0 = time.time()
        cfg = self.get_config()
        target_port = int(port or cfg.get("port") or 5454)

        def _probe(ip: str, timeout: float = 0.35) -> Optional[str]:
            try:
                with socket.create_connection((ip, target_port), timeout=timeout):
                    return ip
            except Exception:
                return None

        # 1. Önce yerel ve bilinen adayları hızlıca kontrol et
        priority_candidates = ["127.0.0.1"]
        if cfg.get("host") and cfg["host"] not in priority_candidates:
            priority_candidates.insert(0, cfg["host"])

        found_ip = None
        for cand in priority_candidates:
            if _probe(cand, timeout=0.35):
                found_ip = cand
                break

        # 2. Bulunamadıysa tüm yerel alt ağı (/24) paralel tara (~150 ms)
        if not found_ip:
            subnet_ips = self._get_local_subnet_ips()
            if subnet_ips:
                with ThreadPoolExecutor(max_workers=64) as ex:
                    futures = {ex.submit(_probe, ip, 0.3): ip for ip in subnet_ips}
                    for fut in as_completed(futures):
                        res_ip = fut.result()
                        if res_ip:
                            found_ip = res_ip
                            break

        elapsed_ms = round((time.time() - t0) * 1000, 1)
        if found_ip:
            self._discovered_host = found_ip
            os.environ["TEBEOS_DB_HOST"] = found_ip
            return {
                "success": True,
                "found": True,
                "host": found_ip,
                "port": target_port,
                "database": cfg.get("database") or "tebeos_db",
                "user": cfg.get("user") or "tebeos",
                "password": cfg.get("password") or "123",
                "elapsed_ms": elapsed_ms,
                "message": f"TEBEOS sunucusu bulundu: {found_ip}:{target_port} ({elapsed_ms} ms)"
            }

        return {
            "success": False,
            "found": False,
            "elapsed_ms": elapsed_ms,
            "message": f"Yerel ağda Port {target_port} üzerinde açık TEBEOS PostgreSQL sunucusu bulunamadı."
        }

    def get_connection(self, custom_cfg: Optional[Dict[str, Any]] = None, timeout: float = 4.0) -> TebeosWireConnection:
        cfg = custom_cfg or self.get_config()
        try:
            conn = TebeosWireConnection(
                host=cfg["host"],
                port=int(cfg.get("port") or 5454),
                user=cfg.get("user") or "tebeos",
                password=cfg.get("password") or "123",
                database=cfg.get("database") or "tebeos_db",
                timeout=timeout
            )
            return conn.connect()
        except Exception as first_err:
            if custom_cfg is None:
                disc = self.discover_tebeos_host(port=int(cfg.get("port") or 5454))
                if disc.get("found") and disc.get("host") != cfg["host"]:
                    conn = TebeosWireConnection(
                        host=disc["host"],
                        port=int(disc["port"]),
                        user=cfg.get("user") or "tebeos",
                        password=cfg.get("password") or "123",
                        database=cfg.get("database") or "tebeos_db",
                        timeout=timeout
                    )
                    return conn.connect()
            raise first_err

    def ping(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        database: Optional[str] = None,
        user: Optional[str] = None,
        password: Optional[str] = None
    ) -> Dict[str, Any]:
        """TEBEOS PostgreSQL veritabanına ping atar ve canlı istatistikleri döner."""
        base_cfg = self.get_config()
        custom_cfg = None
        if any(v is not None and str(v).strip() != "" for v in [host, port, database, user, password]):
            custom_cfg = {
                "host": (host or base_cfg["host"]).strip(),
                "port": int(port or base_cfg["port"] or 5454),
                "database": (database or base_cfg["database"]).strip(),
                "user": (user if user is not None else base_cfg["user"]).strip(),
                "password": (password if password is not None else base_cfg["password"]).strip()
            }
        cfg = custom_cfg or base_cfg
        t0 = time.time()
        try:
            with self.get_connection(custom_cfg=custom_cfg, timeout=3.5) as conn:
                active_cfg = custom_cfg or self.get_config()
                latency_ms = round((time.time() - t0) * 1000, 2)

                _, ver_rows = conn.query("SELECT version()")
                ver_raw = ver_rows[0][0] if ver_rows and ver_rows[0] else "PostgreSQL"
                version_short = ver_raw.split(",")[0] if ver_raw else "PostgreSQL 12"

                _, u_rows = conn.query("SELECT (SELECT COUNT(*) FROM ilac.urun_ms) + (SELECT COUNT(*) FROM public.idu_bilgi_ms)")
                urun_count = int(u_rows[0][0] or 0) if u_rows else 0

                _, f_rows = conn.query("SELECT COUNT(*) FROM public.fatura_ms WHERE COALESCE(aktif::text, '1') != '0'")
                fatura_count = int(f_rows[0][0] or 0) if f_rows else 0

                _, h_rows = conn.query(f"SELECT COUNT(*) FROM stok.stok_hareket_ms WHERE urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}")
                satis_count = int(h_rows[0][0] or 0) if h_rows else 0

                _, t_rows = conn.query(f"SELECT COUNT(*) FROM stok.stok_hareket_ms WHERE hareket_tarih >= CURRENT_DATE AND urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}")
                today_satis = int(t_rows[0][0] or 0) if t_rows else 0

                return {
                    "success": True,
                    "connected": True,
                    "message": f"TEBEOS PostgreSQL bağlantısı başarılı ({latency_ms} ms)",
                    "latency_ms": latency_ms,
                    "version": version_short,
                    "host": active_cfg["host"],
                    "port": active_cfg["port"],
                    "database": active_cfg["database"],
                    "user": active_cfg["user"],
                    "stats": {
                        "kayitli_urun_sayisi": urun_count,
                        "toplam_satis_hareketi": satis_count,
                        "fatura_sayisi": fatura_count,
                        "bugun_satis_sayisi": today_satis
                    }
                }
        except Exception as e:
            latency_ms = round((time.time() - t0) * 1000, 2)
            return {
                "success": False,
                "connected": False,
                "message": f"TEBEOS PostgreSQL bağlantı hatası: {str(e)}",
                "latency_ms": latency_ms,
                "host": cfg["host"],
                "port": cfg["port"],
                "database": cfg["database"],
                "user": cfg["user"],
                "error": str(e)
            }

    def _find_product_in_tebeos(self, conn: TebeosWireConnection, clean_q: str, barcode: str = "") -> Optional[Dict[str, Any]]:
        """
        Ürünü önce ilac.urun_ms (İlaç), bulunamazsa public.idu_bilgi_ms (İlaç Dışı Ürün / OTC / Dermo)
        tablolarında arar. İlişkili tüm barkodları ve güncel stok miktarını döner.
        """
        target_barcodes = set()
        if barcode and barcode.strip().isdigit() and len(barcode.strip()) >= 8:
            target_barcodes.add(barcode.strip())
        if clean_q and clean_q.isdigit() and len(clean_q) >= 8:
            target_barcodes.add(clean_q)

        if target_barcodes:
            try:
                from backend.catalog import catalog
                for b in list(target_barcodes):
                    can = catalog.resolve_canonical_barcode(b)
                    if can:
                        target_barcodes.add(can)
                    cat_p = catalog.get_by_barcode(b)
                    if cat_p:
                        for ab in cat_p.get("all_barcodes", []):
                            if str(ab).strip():
                                target_barcodes.add(str(ab).strip())
            except Exception:
                pass

        # 1. Barkod ile İlaç (ilac.urun_barkod_ms) araması
        if target_barcodes:
            in_bcs = _sql_in(list(target_barcodes))
            _, rows = conn.query(f"""
                SELECT u.urun_id,
                       u.urun_adi,
                       b.barkod,
                       COALESCE(f.psf, 0),
                       COALESCE(f.kdv, 10)
                FROM ilac.urun_barkod_ms b
                JOIN ilac.urun_ms u ON u.urun_id = b.urun_id
                LEFT JOIN LATERAL (
                    SELECT psf, kdv FROM ilac.urun_fiyat_ms uf
                    WHERE uf.urun_id = u.urun_id
                    ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                    LIMIT 1
                ) f ON true
                WHERE b.barkod IN {in_bcs}
                ORDER BY COALESCE(b.aktif::text, '1') DESC, u.urun_id DESC
                LIMIT 1
            """)
            if rows:
                r = rows[0]
                u_id = int(r[0])
                _, bc_rows = conn.query(f"SELECT barkod FROM ilac.urun_barkod_ms WHERE urun_id = {u_id} AND barkod IS NOT NULL AND barkod <> ''")
                all_bcs = list({x[0].strip() for x in bc_rows if x[0]} | target_barcodes)
                return {
                    "is_idu": False,
                    "id": u_id,
                    "name": str(r[1] or "").strip(),
                    "barkod": str(r[2] or "").strip(),
                    "psf": float(r[3] or 0.0),
                    "kdv": float(r[4] or 10.0),
                    "all_barcodes": all_bcs
                }

            # 2. Barkod ile İlaç Dışı Ürün / OTC (public.idu_barkod_ms) araması
            _, idu_rows = conn.query(f"""
                SELECT i.idu_bilgi_id,
                       i.idu_tanim,
                       b.barkod,
                       COALESCE(f.eczane_satis_fiyat, 0),
                       COALESCE(f.idu_kdv, 10)
                FROM public.idu_barkod_ms b
                JOIN public.idu_bilgi_ms i ON i.idu_bilgi_id = b.idu_bilgi_id
                LEFT JOIN LATERAL (
                    SELECT eczane_satis_fiyat, idu_kdv FROM public.idu_fiyat_ms uf
                    WHERE uf.idu_bilgi_id = i.idu_bilgi_id
                    ORDER BY uf.idu_fiyat_id DESC
                    LIMIT 1
                ) f ON true
                WHERE b.barkod IN {in_bcs}
                ORDER BY i.idu_bilgi_id DESC
                LIMIT 1
            """)
            if idu_rows:
                r = idu_rows[0]
                i_id = int(r[0])
                _, bc_rows = conn.query(f"SELECT barkod FROM public.idu_barkod_ms WHERE idu_bilgi_id = {i_id} AND barkod IS NOT NULL AND barkod <> ''")
                all_bcs = list({x[0].strip() for x in bc_rows if x[0]} | target_barcodes)
                return {
                    "is_idu": True,
                    "id": i_id,
                    "name": str(r[1] or "").strip(),
                    "barkod": str(r[2] or "").strip(),
                    "psf": float(r[3] or 0.0),
                    "kdv": float(r[4] or 10.0),
                    "all_barcodes": all_bcs
                }

        # 3. İsim ile arama (İlaç veya OTC)
        search_text = clean_q.strip()
        if search_text and not (search_text.isdigit() and len(search_text) >= 8):
            tr_q = search_text.replace("i", "İ").replace("ı", "I").upper()
            p1 = _sql_lit(f"%{search_text}%")
            p2 = _sql_lit(f"%{tr_q}%")
            _, rows = conn.query(f"""
                SELECT u.urun_id,
                       u.urun_adi,
                       (SELECT b.barkod FROM ilac.urun_barkod_ms b WHERE b.urun_id = u.urun_id ORDER BY COALESCE(b.aktif::text, '1') DESC, b.urun_barkod_id DESC LIMIT 1) as barkod,
                       COALESCE(f.psf, 0),
                       COALESCE(f.kdv, 10)
                FROM ilac.urun_ms u
                LEFT JOIN LATERAL (
                    SELECT psf, kdv FROM ilac.urun_fiyat_ms uf
                    WHERE uf.urun_id = u.urun_id
                    ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                    LIMIT 1
                ) f ON true
                WHERE u.urun_adi ILIKE {p1} OR u.urun_adi ILIKE {p2}
                ORDER BY u.urun_id DESC
                LIMIT 1
            """)
            if rows and rows[0][2]:
                r = rows[0]
                u_id = int(r[0])
                _, bc_rows = conn.query(f"SELECT barkod FROM ilac.urun_barkod_ms WHERE urun_id = {u_id} AND barkod IS NOT NULL AND barkod <> ''")
                all_bcs = [x[0].strip() for x in bc_rows if x[0]]
                return {
                    "is_idu": False,
                    "id": u_id,
                    "name": str(r[1] or "").strip(),
                    "barkod": str(r[2] or "").strip(),
                    "psf": float(r[3] or 0.0),
                    "kdv": float(r[4] or 10.0),
                    "all_barcodes": all_bcs or [str(r[2]).strip()]
                }

            _, idu_rows = conn.query(f"""
                SELECT i.idu_bilgi_id,
                       i.idu_tanim,
                       (SELECT b.barkod FROM public.idu_barkod_ms b WHERE b.idu_bilgi_id = i.idu_bilgi_id ORDER BY b.idu_barkod_id DESC LIMIT 1) as barkod,
                       COALESCE(f.eczane_satis_fiyat, 0),
                       COALESCE(f.idu_kdv, 10)
                FROM public.idu_bilgi_ms i
                LEFT JOIN LATERAL (
                    SELECT eczane_satis_fiyat, idu_kdv FROM public.idu_fiyat_ms uf
                    WHERE uf.idu_bilgi_id = i.idu_bilgi_id
                    ORDER BY uf.idu_fiyat_id DESC
                    LIMIT 1
                ) f ON true
                WHERE i.idu_tanim ILIKE {p1} OR i.idu_tanim ILIKE {p2}
                ORDER BY i.idu_bilgi_id DESC
                LIMIT 1
            """)
            if idu_rows and idu_rows[0][2]:
                r = idu_rows[0]
                i_id = int(r[0])
                _, bc_rows = conn.query(f"SELECT barkod FROM public.idu_barkod_ms WHERE idu_bilgi_id = {i_id} AND barkod IS NOT NULL AND barkod <> ''")
                all_bcs = [x[0].strip() for x in bc_rows if x[0]]
                return {
                    "is_idu": True,
                    "id": i_id,
                    "name": str(r[1] or "").strip(),
                    "barkod": str(r[2] or "").strip(),
                    "psf": float(r[3] or 0.0),
                    "kdv": float(r[4] or 10.0),
                    "all_barcodes": all_bcs or [str(r[2]).strip()]
                }

        return None

    def get_product_analysis(self, query: str, barcode: str = "") -> Dict[str, Any]:
        """
        Belirtilen barkod veya ürün adı için TEBEOS PostgreSQL veritabanından:
        1. Anlık raf stoğu (stok.stok_hareket_ms net toplamı)
        2. Son 6 takvim ayı Nakit (Elden) ve Reçeteli (SGK/Medula) çıkış adetleri (ÇIKIŞ)
        3. Son depolardan gelen alış faturaları (GİRİŞ - public.fatura_hareket_ms)
        4. Aylık ortalama çıkış hızı, günlük çıkış, kalan gün tahmini ve akıllı sipariş önerisi
        döndürür.
        """
        clean_q = (barcode or query or "").strip()
        if not clean_q:
            return {"found": False, "message": "Barkod veya ürün belirtilmedi."}

        try:
            with self.get_connection() as conn:
                prod = self._find_product_in_tebeos(conn, query or clean_q, barcode=barcode or clean_q)
                if not prod:
                    return {
                        "found": False,
                        "connected": True,
                        "kaynak": "TEBEOS",
                        "message": f"'{clean_q}' TEBEOS kayıtlarında bulunamadı."
                    }

                u_id = prod["id"]
                u_adi = prod["name"]
                found_barkod = prod["barkod"]
                all_bcs = prod["all_barcodes"] or ([found_barkod] if found_barkod else [clean_q])
                in_bcs = _sql_in(all_bcs)

                # 1. Güncel Net Raf Stoğu (stok.stok_hareket_ms içinde GIRIS pozitif, CIKIS negatif tutulur)
                if prod["is_idu"]:
                    where_mov = f"(h.idu_bilgi_id = {u_id} OR h.barkod IN {in_bcs})"
                else:
                    where_mov = f"(h.urun_id = {u_id} OR h.barkod IN {in_bcs})"

                _, stok_rows = conn.query(f"SELECT COALESCE(SUM(h.adet), 0) FROM stok.stok_hareket_ms h WHERE {where_mov}")
                stok = int(float(stok_rows[0][0] or 0)) if stok_rows else 0

                # 2. Son 6 Aylık Satış / Çıkış Trendi (Nakit vs Reçeteli)
                _, mov_rows = conn.query(f"""
                    SELECT TO_CHAR(h.hareket_tarih, 'YYYY-MM') as ay,
                           COALESCE(SUM(CASE WHEN h.urun_hareket_tip_id IN {self.RECETE_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) as receteli_adet,
                           COALESCE(SUM(CASE WHEN h.urun_hareket_tip_id IN {self.NAKIT_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) as nakit_adet
                    FROM stok.stok_hareket_ms h
                    WHERE {where_mov}
                      AND h.hareket_tarih >= (CURRENT_DATE - INTERVAL '6 months')
                      AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}
                    GROUP BY TO_CHAR(h.hareket_tarih, 'YYYY-MM')
                    ORDER BY ay ASC
                """)
                recete_map = {}
                elden_map = {}
                for mr in mov_rows:
                    ym = str(mr[0] or "")
                    recete_map[ym] = int(float(mr[1] or 0))
                    elden_map[ym] = int(float(mr[2] or 0))

                ay_isimleri = {
                    "01": "Ocak", "02": "Şubat", "03": "Mart", "04": "Nisan",
                    "05": "Mayıs", "06": "Haziran", "07": "Temmuz", "08": "Ağustos",
                    "09": "Eylül", "10": "Ekim", "11": "Kasım", "12": "Aralık"
                }

                today = datetime.date.today()
                aylik_cikislar = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    m_str = f"{m_calc:02d}"
                    ym_key = f"{y_calc}-{m_str}"
                    is_current_month = (i == 0)
                    suffix = " (Bu Ay)" if is_current_month else ""
                    ay_label = f"{ay_isimleri.get(m_str, m_str)} '{str(y_calc)[-2:]}{suffix}"

                    nakit_val = elden_map.get(ym_key, 0)
                    recete_val = recete_map.get(ym_key, 0)
                    top_cikis = nakit_val + recete_val

                    aylik_cikislar.append({
                        "ay": ym_key,
                        "label": ay_label,
                        "is_current": is_current_month,
                        "nakit": nakit_val,
                        "receteli": recete_val,
                        "toplam": top_cikis
                    })

                gecmis_aylar = aylik_cikislar[:-1] if len(aylik_cikislar) > 1 else aylik_cikislar
                gecmis_sum = sum(x["toplam"] for x in gecmis_aylar)
                if gecmis_sum > 0:
                    ort_aylik = round(gecmis_sum / max(1, len(gecmis_aylar)), 1)
                else:
                    ort_aylik = round(sum(x["toplam"] for x in aylik_cikislar) / max(1, len(aylik_cikislar)), 1)

                ort_gunluk = round(ort_aylik / 30.0, 2)
                if ort_gunluk > 0:
                    kalan_gun = int(round(max(0, stok) / ort_gunluk))
                else:
                    kalan_gun = 999 if stok > 0 else 0

                toplam_6_aylik_cikis = sum(x["toplam"] for x in aylik_cikislar)
                is_hareketsiz = (stok <= 0 and toplam_6_aylik_cikis == 0)

                if is_hareketsiz:
                    stok_status = "HAREKET YOK"
                    stok_status_color = "slate"
                    onerilen_siparis = 1
                elif stok <= 0:
                    stok_status = "TÜKENDİ"
                    stok_status_color = "red"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(1, hedef_stok - max(0, stok))
                elif kalan_gun < 10:
                    stok_status = "KRİTİK AZ"
                    stok_status_color = "amber"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                elif kalan_gun <= 30:
                    stok_status = "YETERLİ"
                    stok_status_color = "emerald"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                else:
                    stok_status = "YÜKSEK STOK"
                    stok_status_color = "sky"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)

                # 3. Son Alış Faturaları / Depo Girişleri (GİRİŞ)
                _, giris_rows = conn.query(f"""
                    SELECT TO_CHAR(fm.fatura_tarih, 'YYYY-MM-DD') as tarih,
                           COALESCE(d.depo, 'DİĞER DEPO') as depo,
                           COALESCE(fh.adet, 0) as adet,
                           COALESCE(fh.mf, 0) as mf,
                           COALESCE(NULLIF(fh.dsf, 0), NULLIF(fh.psf, 0), 0) as birim_fiyat,
                           COALESCE(NULLIF(fh.gecerli_maliyet, 0), NULLIF(fh.maliyet, 0), NULLIF(fh.dsf, 0), 0) as maliyet,
                           COALESCE(fm.fatura_no, '') as fatura_no
                    FROM public.fatura_hareket_ms fh
                    JOIN public.fatura_ms fm ON fm.fatura_id = fh.fatura_id
                    LEFT JOIN public.depo_ms d ON d.depo_id = fm.depo_id
                    WHERE fh.barkod IN {in_bcs}
                      AND COALESCE(fm.aktif::text, '1') != '0'
                    ORDER BY fm.fatura_tarih DESC NULLS LAST, fm.fatura_id DESC
                    LIMIT 6
                """)

                son_girisler = []
                toplam_giren_kutu = 0
                for gr in giris_rows:
                    g_adet = int(float(gr[2] or 0))
                    g_mf = int(float(gr[3] or 0))
                    g_birim = round(float(gr[4] or 0.0), 2)
                    g_maliyet = round(float(gr[5] or 0.0), 2)
                    top_satir = g_adet + g_mf
                    toplam_giren_kutu += top_satir
                    son_girisler.append({
                        "tarih": str(gr[0] or ""),
                        "depo": str(gr[1] or "DİĞER DEPO"),
                        "adet": g_adet,
                        "mf": g_mf,
                        "toplam_adet": top_satir,
                        "birim_fiyat": g_birim,
                        "maliyet": g_maliyet,
                        "fatura_no": str(gr[6] or "")
                    })

                final_barcode = barcode or found_barkod or clean_q
                try:
                    from backend.catalog import catalog
                    can_final = catalog.resolve_canonical_barcode(final_barcode)
                    if can_final:
                        final_barcode = can_final
                except Exception:
                    pass

                return {
                    "found": True,
                    "connected": True,
                    "kaynak": "TEBEOS",
                    "otomasyon_adi": "TEBEOS Eczane",
                    "urun_id": u_id,
                    "mal_id": u_id,
                    "mal_kodu": str(u_id),
                    "mal_adi": u_adi,
                    "barkod": final_barcode,
                    "stok": stok,
                    "stok_depo": 0,
                    "stok_raf": stok,
                    "stok_acik": 0,
                    "kalan_gun": kalan_gun,
                    "stok_status": stok_status,
                    "stok_status_color": stok_status_color,
                    "ort_aylik_cikis": ort_aylik,
                    "ort_gunluk_cikis": ort_gunluk,
                    "onerilen_siparis": onerilen_siparis,
                    "aylik_cikislar": aylik_cikislar,
                    "son_girisler": son_girisler,
                    "toplam_giren_kutu": toplam_giren_kutu,
                    "hareketsiz_kart": is_hareketsiz,
                    "hareketsiz_aciklama": "Eczanenizde bu ürün için son 6 aydır çıkış hareketi bulunmuyor."
                }
        except Exception as e:
            return {
                "found": False,
                "connected": False,
                "kaynak": "TEBEOS",
                "error": str(e),
                "message": f"TEBEOS stok ve hareket sorgusu hatası: {str(e)}"
            }

    def get_critical_stock_sales(self, limit: int = 0, max_stock_threshold: int = 5, max_stock_days: int = 21) -> List[Dict[str, Any]]:
        """
        Bugün TEBEOS üzerinden çıkışı olan (reçeteli veya nakit) ve stoğu azalan / kritik ürünleri listeler.
        """
        try:
            with self.get_connection() as conn:
                # 1. Bugün çıkışı olan barkodları ve çıkış adetlerini çek
                _, today_rows = conn.query(f"""
                    SELECT h.barkod,
                           COALESCE(SUM(ABS(h.adet)), 0) as bugun_adet
                    FROM stok.stok_hareket_ms h
                    WHERE h.hareket_tarih >= CURRENT_DATE
                      AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}
                      AND h.barkod IS NOT NULL AND h.barkod <> ''
                    GROUP BY h.barkod
                """)

                # Eğer bugün henüz çıkış olmadıysa son 24 saate / son işlem gününe bak
                if not today_rows:
                    _, today_rows = conn.query(f"""
                        SELECT h.barkod,
                               COALESCE(SUM(ABS(h.adet)), 0) as bugun_adet
                        FROM stok.stok_hareket_ms h
                        WHERE h.hareket_tarih >= (
                            SELECT COALESCE(DATE_TRUNC('day', MAX(hareket_tarih)), CURRENT_DATE)
                            FROM stok.stok_hareket_ms
                            WHERE urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}
                        )
                          AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}
                          AND h.barkod IS NOT NULL AND h.barkod <> ''
                        GROUP BY h.barkod
                    """)

                if not today_rows:
                    return []

                today_map = {str(r[0]).strip(): int(float(r[1] or 0)) for r in today_rows if r[0] and int(float(r[1] or 0)) > 0}
                barcodes = list(today_map.keys())
                if not barcodes:
                    return []

                in_bcs = _sql_in(barcodes)

                # 2. Bu barkodların güncel net stoğu ve son 30 günlük satış toplamını tek sorguda çek
                _, stat_rows = conn.query(f"""
                    SELECT h.barkod,
                           COALESCE(SUM(h.adet), 0) as toplam_stok,
                           COALESCE(SUM(CASE WHEN h.hareket_tarih >= (CURRENT_DATE - INTERVAL '30 days') AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) as ay_adet
                    FROM stok.stok_hareket_ms h
                    WHERE h.barkod IN {in_bcs}
                    GROUP BY h.barkod
                """)
                stok_map = {}
                month_map = {}
                for sr in stat_rows:
                    bc = str(sr[0] or "").strip()
                    stok_map[bc] = int(float(sr[1] or 0))
                    month_map[bc] = int(float(sr[2] or 0))

                # 3. Ürün isimleri ve PSF fiyatlarını hem ilac hem idu tablolarından çek
                _, info_rows = conn.query(f"""
                    SELECT b.barkod, u.urun_id, u.urun_adi, COALESCE(f.psf, 0) as psf
                    FROM ilac.urun_barkod_ms b
                    JOIN ilac.urun_ms u ON u.urun_id = b.urun_id
                    LEFT JOIN LATERAL (
                        SELECT psf FROM ilac.urun_fiyat_ms uf
                        WHERE uf.urun_id = u.urun_id
                        ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                        LIMIT 1
                    ) f ON true
                    WHERE b.barkod IN {in_bcs}
                    UNION ALL
                    SELECT ib.barkod, i.idu_bilgi_id as urun_id, i.idu_tanim as urun_adi, COALESCE(ifm.eczane_satis_fiyat, 0) as psf
                    FROM public.idu_barkod_ms ib
                    JOIN public.idu_bilgi_ms i ON i.idu_bilgi_id = ib.idu_bilgi_id
                    LEFT JOIN LATERAL (
                        SELECT eczane_satis_fiyat FROM public.idu_fiyat_ms uf2
                        WHERE uf2.idu_bilgi_id = i.idu_bilgi_id
                        ORDER BY uf2.idu_fiyat_id DESC
                        LIMIT 1
                    ) ifm ON true
                    WHERE ib.barkod IN {in_bcs}
                """)
                info_map = {}
                for ir in info_rows:
                    bc = str(ir[0] or "").strip()
                    if bc and bc not in info_map:
                        info_map[bc] = {
                            "urun_id": int(ir[1] or 0),
                            "urun_adi": str(ir[2] or bc).strip(),
                            "psf": round(float(ir[3] or 0.0), 2)
                        }

                # 4. Geçmiş MF'li alım kontrolü (public.fatura_hareket_ms)
                mf_history_map = {}
                try:
                    _, mf_rows = conn.query(f"""
                        SELECT barkod, adet, mf, tarih, alim_count FROM (
                            SELECT fh.barkod,
                                   COALESCE(fh.adet, 0) as adet,
                                   COALESCE(fh.mf, 0) as mf,
                                   TO_CHAR(fm.fatura_tarih, 'DD.MM.YYYY') as tarih,
                                   COUNT(*) OVER (PARTITION BY fh.barkod) as alim_count,
                                   ROW_NUMBER() OVER (PARTITION BY fh.barkod ORDER BY fm.fatura_tarih DESC NULLS LAST, fm.fatura_id DESC) as rn
                            FROM public.fatura_hareket_ms fh
                            JOIN public.fatura_ms fm ON fm.fatura_id = fh.fatura_id
                            WHERE fh.barkod IN {in_bcs}
                              AND COALESCE(fm.aktif::text, '1') != '0'
                              AND COALESCE(fh.mf, 0) > 0
                        ) t WHERE rn = 1
                    """)
                    for mr in mf_rows:
                        bc = str(mr[0] or "").strip()
                        m_adet = int(float(mr[1] or 0))
                        m_mf = int(float(mr[2] or 0))
                        fmt_date = str(mr[3] or "")
                        alim_count = int(float(mr[4] or 1))
                        mf_kisa = f"Son: {m_adet}+{m_mf} MF" if m_adet > 0 else f"Son: +{m_mf} MF"
                        mf_bilgi = f"Geçmişte {alim_count} kez MF ile alındı (Son Alım: {m_adet}+{m_mf} MF, {fmt_date})"
                        mf_history_map[bc] = {
                            "var": True,
                            "sayisi": alim_count,
                            "son_adet": m_adet,
                            "son_mf": m_mf,
                            "son_tarih": fmt_date,
                            "kisa": mf_kisa,
                            "bilgi": mf_bilgi
                        }
                except Exception:
                    pass

                candidate_items = []
                for bc, bugun_val in today_map.items():
                    stok_val = stok_map.get(bc, 0)
                    ay_val = month_map.get(bc, bugun_val)
                    inf = info_map.get(bc, {})
                    u_id = inf.get("urun_id") or 0
                    u_adi = inf.get("urun_adi") or ""
                    psf_val = inf.get("psf") or 0.0

                    if not u_adi:
                        try:
                            from backend.catalog import catalog
                            cat_item = catalog.get_by_barcode(bc)
                            if cat_item:
                                u_adi = cat_item.get("name") or bc
                                psf_val = psf_val or float(cat_item.get("price") or 0.0)
                        except Exception:
                            pass
                    if not u_adi:
                        u_adi = f"Ürün ({bc})"

                    effective_aylik = max(int(ay_val or 0), int(bugun_val or 1))
                    gunluk_ort = max(0.1, round(effective_aylik / 30.0, 2))
                    stok_gun = round((stok_val * 30.0) / effective_aylik, 1) if stok_val > 0 else 0.0

                    if max_stock_days > 0 and stok_val > 0 and stok_gun > max_stock_days:
                        continue

                    onerilen = max(bugun_val, int(gunluk_ort * 7) - max(0, stok_val))
                    if onerilen <= 0:
                        onerilen = max(1, bugun_val)

                    mf_hist = mf_history_map.get(bc, {})
                    has_past_mf = bool(mf_hist.get("var", False))

                    candidate_items.append({
                        "urun_id": u_id or bc,
                        "mal_kodu": str(u_id or bc),
                        "urun_adi": u_adi,
                        "barkod": bc,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": ay_val,
                        "psf": psf_val,
                        "onerilen_siparis": max(1, onerilen),
                        "gecmis_mf_var": has_past_mf,
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", "")
                    })

                candidate_items.sort(key=lambda x: (
                    0 if x["stok"] <= 0 else 1,
                    x["stok_gun"],
                    -x["bugun_cikis"]
                ))

                if limit and limit > 0:
                    return candidate_items[:limit]
                return candidate_items
        except Exception as e:
            print(f"[TEBEOS] get_critical_stock_sales hatası: {e}")
            return []

    def get_six_month_smart_order_list(
        self,
        scope: str = "today",
        search_query: str = "",
        target_days: int = 15,
        limit: int = 250
    ) -> Dict[str, Any]:
        """
        TEBEOS PostgreSQL veritabanından toplu sipariş ve 6 aylık çıkış analizi için
        son 6 takvim ayının ay-ay çıkışlarını, trend analizini, stok ve geçmiş MF bilgilerini döndürür.
        """
        import math
        t0 = time.time()
        try:
            with self.get_connection() as conn:
                ay_kisa = {
                    1: "Oca", 2: "Şub", 3: "Mar", 4: "Nis",
                    5: "May", 6: "Haz", 7: "Tem", 8: "Ağu",
                    9: "Eyl", 10: "Eki", 11: "Kas", 12: "Ara"
                }
                today = datetime.date.today()
                months_meta = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    ym_int = y_calc * 100 + m_calc
                    ym_str = f"{y_calc}-{m_calc:02d}"
                    short_lbl = ay_kisa.get(m_calc, str(m_calc))
                    lbl = f"{short_lbl} '{str(y_calc)[-2:]}"
                    months_meta.append({
                        "ym_int": ym_int,
                        "ym": ym_str,
                        "short": short_lbl,
                        "label": lbl,
                        "is_current": (i == 0)
                    })

                start_ym = months_meta[0]["ym_int"]
                start_date_str = f"{start_ym // 100}-{start_ym % 100:02d}-01"
                lim = max(10, int(limit or 250))

                _, today_rows = conn.query(f"""
                    SELECT h.barkod, COALESCE(SUM(ABS(h.adet)), 0) as bugun_adet
                    FROM stok.stok_hareket_ms h
                    WHERE h.hareket_tarih >= CURRENT_DATE
                      AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}
                      AND h.barkod IS NOT NULL AND h.barkod <> ''
                    GROUP BY h.barkod
                """)
                today_map = {str(r[0]).strip(): int(float(r[1] or 0)) for r in today_rows if r[0] and int(float(r[1] or 0)) > 0}

                clean_q = (search_query or "").strip()
                scope_norm = (scope or "today").strip().lower()
                barcodes: List[str] = []

                if clean_q:
                    p1 = _sql_quote(f"%{clean_q}%")
                    p2 = _sql_quote(f"%{clean_q.replace('i', 'İ').replace('ı', 'I').upper()}%")
                    _, s_rows = conn.query(f"""
                        SELECT b.barkod FROM ilac.urun_barkod_ms b
                        JOIN ilac.urun_ms u ON u.urun_id = b.urun_id
                        WHERE (u.urun_adi ILIKE {p1} OR u.urun_adi ILIKE {p2} OR b.barkod ILIKE {p1})
                          AND b.barkod IS NOT NULL AND b.barkod <> ''
                        LIMIT {lim}
                    """)
                    barcodes = [str(r[0]).strip() for r in s_rows if r[0]]
                elif scope_norm in ("week", "days_7"):
                    _, w_rows = conn.query(f"""
                        SELECT h.barkod, COALESCE(SUM(ABS(h.adet)), 0) as top_adet
                        FROM stok.stok_hareket_ms h
                        WHERE h.hareket_tarih >= (CURRENT_DATE - INTERVAL '7 days')
                          AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}
                          AND h.barkod IS NOT NULL AND h.barkod <> ''
                        GROUP BY h.barkod
                        HAVING COALESCE(SUM(ABS(h.adet)), 0) > 0
                        ORDER BY top_adet DESC
                        LIMIT {lim}
                    """)
                    barcodes = [str(r[0]).strip() for r in w_rows if r[0]]
                elif scope_norm in ("top6m", "top_6m"):
                    _, m6_rows = conn.query(f"""
                        SELECT h.barkod, COALESCE(SUM(ABS(h.adet)), 0) as top_adet
                        FROM stok.stok_hareket_ms h
                        WHERE h.hareket_tarih >= {_sql_quote(start_date_str)}::date
                          AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}
                          AND h.barkod IS NOT NULL AND h.barkod <> ''
                        GROUP BY h.barkod
                        HAVING COALESCE(SUM(ABS(h.adet)), 0) > 0
                        ORDER BY top_adet DESC
                        LIMIT {lim}
                    """)
                    barcodes = [str(r[0]).strip() for r in m6_rows if r[0]]
                else:
                    barcodes = list(today_map.keys())
                    if not barcodes:
                        _, d3_rows = conn.query(f"""
                            SELECT h.barkod, COALESCE(SUM(ABS(h.adet)), 0) as top_adet
                            FROM stok.stok_hareket_ms h
                            WHERE h.hareket_tarih >= (CURRENT_DATE - INTERVAL '3 days')
                              AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}
                              AND h.barkod IS NOT NULL AND h.barkod <> ''
                            GROUP BY h.barkod
                            HAVING COALESCE(SUM(ABS(h.adet)), 0) > 0
                            ORDER BY top_adet DESC
                            LIMIT {lim}
                        """)
                        barcodes = [str(r[0]).strip() for r in d3_rows if r[0]]

                if not barcodes:
                    return {
                        "success": True,
                        "source": "TEBEOS",
                        "scope": scope,
                        "months": months_meta,
                        "items": [],
                        "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
                    }

                barcodes = list(dict.fromkeys(barcodes))[:lim]
                in_bcs = _sql_in(barcodes)

                # Ay-Ay 6 aylık çıkışlar
                _, m_rows = conn.query(f"""
                    SELECT h.barkod,
                           CAST(TO_CHAR(h.hareket_tarih, 'YYYYMM') AS INTEGER) as ym,
                           COALESCE(SUM(ABS(h.adet)), 0) as top_adet,
                           COALESCE(SUM(CASE WHEN h.urun_hareket_tip_id IN {self.RECETE_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) as rec_adet,
                           COALESCE(SUM(CASE WHEN h.urun_hareket_tip_id IN {self.NAKIT_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) as nak_adet
                    FROM stok.stok_hareket_ms h
                    WHERE h.barkod IN {in_bcs}
                      AND h.hareket_tarih >= {_sql_quote(start_date_str)}::date
                      AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI}
                    GROUP BY h.barkod, CAST(TO_CHAR(h.hareket_tarih, 'YYYYMM') AS INTEGER)
                """)
                per_item_months: Dict[str, Dict[int, Dict[str, int]]] = {}
                for r_bc, r_ym, r_top, r_rec, r_nak in m_rows:
                    if not r_bc or not r_ym:
                        continue
                    per_item_months.setdefault(str(r_bc).strip(), {})[int(r_ym)] = {
                        "toplam": int(float(r_top or 0)),
                        "receteli": int(float(r_rec or 0)),
                        "nakit": int(float(r_nak or 0))
                    }

                # Stok ve son 30 gün
                _, stat_rows = conn.query(f"""
                    SELECT h.barkod,
                           COALESCE(SUM(h.adet), 0) as toplam_stok,
                           COALESCE(SUM(CASE WHEN h.hareket_tarih >= (CURRENT_DATE - INTERVAL '30 days') AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) as ay_adet
                    FROM stok.stok_hareket_ms h
                    WHERE h.barkod IN {in_bcs}
                    GROUP BY h.barkod
                """)
                stok_map = {}
                last30_map = {}
                for sr in stat_rows:
                    bc = str(sr[0] or "").strip()
                    stok_map[bc] = int(float(sr[1] or 0))
                    last30_map[bc] = int(float(sr[2] or 0))

                # İsim ve PSF
                _, info_rows = conn.query(f"""
                    SELECT b.barkod, u.urun_id, u.urun_adi, COALESCE(f.psf, 0) as psf
                    FROM ilac.urun_barkod_ms b
                    JOIN ilac.urun_ms u ON u.urun_id = b.urun_id
                    LEFT JOIN LATERAL (
                        SELECT psf FROM ilac.urun_fiyat_ms uf
                        WHERE uf.urun_id = u.urun_id
                        ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                        LIMIT 1
                    ) f ON true
                    WHERE b.barkod IN {in_bcs}
                    UNION ALL
                    SELECT ib.barkod, i.idu_bilgi_id as urun_id, i.idu_tanim as urun_adi, COALESCE(ifm.eczane_satis_fiyat, 0) as psf
                    FROM public.idu_barkod_ms ib
                    JOIN public.idu_bilgi_ms i ON i.idu_bilgi_id = ib.idu_bilgi_id
                    LEFT JOIN LATERAL (
                        SELECT eczane_satis_fiyat FROM public.idu_fiyat_ms uf2
                        WHERE uf2.idu_bilgi_id = i.idu_bilgi_id
                        ORDER BY uf2.idu_fiyat_id DESC
                        LIMIT 1
                    ) ifm ON true
                    WHERE ib.barkod IN {in_bcs}
                """)
                info_map = {}
                for ir in info_rows:
                    bc = str(ir[0] or "").strip()
                    if bc and bc not in info_map:
                        info_map[bc] = {
                            "urun_id": int(ir[1] or 0),
                            "urun_adi": str(ir[2] or bc).strip(),
                            "psf": round(float(ir[3] or 0.0), 2)
                        }

                items = []
                stabil_count = 0
                azalan_count = 0
                artan_count = 0
                tukenen_count = 0
                target_days_clean = max(1, int(target_days or 15))

                for bc in barcodes:
                    inf = info_map.get(bc, {})
                    u_id = inf.get("urun_id") or 0
                    u_adi = inf.get("urun_adi") or f"Ürün ({bc})"
                    psf_val = inf.get("psf") or 0.0
                    stok_val = stok_map.get(bc, 0)
                    bugun_val = today_map.get(bc, 0)
                    son30_val = last30_map.get(bc, 0)

                    m_dict = per_item_months.get(bc, {})
                    aylik_detay = []
                    toplam_6ay = 0
                    toplam_6ay_recete = 0
                    toplam_6ay_nakit = 0
                    aktif_ay_sayisi = 0

                    for m_meta in months_meta:
                        ym_i = m_meta["ym_int"]
                        cell = m_dict.get(ym_i, {"toplam": 0, "receteli": 0, "nakit": 0})
                        c_top = cell["toplam"]
                        c_rec = cell["receteli"]
                        c_nak = cell["nakit"]
                        toplam_6ay += c_top
                        toplam_6ay_recete += c_rec
                        toplam_6ay_nakit += c_nak
                        if c_top > 0:
                            aktif_ay_sayisi += 1
                        aylik_detay.append({
                            "ym": m_meta["ym"],
                            "short": m_meta["short"],
                            "label": m_meta["label"],
                            "is_current": m_meta["is_current"],
                            "toplam": c_top,
                            "receteli": c_rec,
                            "recete": c_rec,
                            "nakit": c_nak
                        })

                    m_vals = [x["toplam"] for x in aylik_detay]
                    gecmis_5_toplam = sum(m_vals[:5])
                    ort_aylik_6m = round(gecmis_5_toplam / 5.0, 1) if gecmis_5_toplam > 0 else round(toplam_6ay / 6.0, 1)
                    onceki_4_ort = sum(m_vals[:4]) / 4.0
                    gecen_ay_val = m_vals[4] if len(m_vals) >= 5 else 0
                    son_donem_hiz = round((gecen_ay_val + son30_val) / 2.0, 1) if gecen_ay_val > 0 else float(son30_val)

                    degisim_yuzde = 0
                    if onceki_4_ort >= 1.5:
                        degisim_yuzde = int(round(((son_donem_hiz - onceki_4_ort) / onceki_4_ort) * 100))

                    if onceki_4_ort >= 2.0 and son_donem_hiz < onceki_4_ort * 0.65:
                        trend_kodu = "AZALAN"
                        trend_etiket = f"📉 Çıkışı Azalan (%{abs(degisim_yuzde)}↓)"
                        trend_renk = "amber"
                        trend_uyari = f"Son dönemde çıkış hızı {onceki_4_ort:.1f}/ay'dan {son_donem_hiz:.1f}/ay'a geriledi."
                        azalan_count += 1
                    elif onceki_4_ort >= 1.5 and son_donem_hiz > onceki_4_ort * 1.35 and son_donem_hiz >= 3.0:
                        trend_kodu = "ARTAN"
                        trend_etiket = f"📈 Çıkışı Artan (+%{abs(degisim_yuzde)}↑)"
                        trend_renk = "sky"
                        trend_uyari = f"Son dönemde talep hızlandı ({onceki_4_ort:.1f} → {son_donem_hiz:.1f}/ay)."
                        artan_count += 1
                    elif aktif_ay_sayisi >= 4 and toplam_6ay >= 5:
                        trend_kodu = "STABIL"
                        trend_etiket = f"🟢 Stabil Çıkan ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "emerald"
                        trend_uyari = f"Her ay düzenli satıyor (Ort. {ort_aylik_6m:.1f} kt/ay)."
                        stabil_count += 1
                    else:
                        trend_kodu = "DUZENSIZ"
                        trend_etiket = f"⚡ Aralıklı ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "slate"
                        trend_uyari = f"Son 6 ayın {aktif_ay_sayisi} ayında çıkış yaptı."

                    if stok_val <= 0:
                        tukenen_count += 1

                    if trend_kodu == "AZALAN":
                        etkin_aylik_hiz = max(0.5, min(ort_aylik_6m, max(1.0, son_donem_hiz)))
                    elif trend_kodu == "ARTAN":
                        etkin_aylik_hiz = max(ort_aylik_6m, son_donem_hiz, float(bugun_val))
                    else:
                        etkin_aylik_hiz = max(ort_aylik_6m, float(son30_val), float(bugun_val))

                    gunluk_hiz = round(max(0.05, etkin_aylik_hiz / 30.0), 2)
                    stok_gun = round(stok_val / gunluk_hiz, 1) if stok_val > 0 else 0.0
                    hedef_kutu = math.ceil(gunluk_hiz * target_days_clean)
                    onerilen = max(0, hedef_kutu - max(0, stok_val))
                    if stok_val <= 0 and onerilen <= 0:
                        onerilen = max(1, bugun_val or 1)

                    items.append({
                        "urun_id": u_id or bc,
                        "mal_kodu": str(u_id or bc),
                        "urun_kodu": str(u_id or bc),
                        "urun_adi": u_adi,
                        "barkod": bc,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "psf": psf_val,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": son30_val,
                        "toplam_6ay": toplam_6ay,
                        "toplam_6ay_recete": toplam_6ay_recete,
                        "toplam_6ay_nakit": toplam_6ay_nakit,
                        "ort_aylik_6m": ort_aylik_6m,
                        "onceki_4_ort": round(onceki_4_ort, 1),
                        "ilk4_ort": round(onceki_4_ort, 1),
                        "son_donem_hiz": round(son_donem_hiz, 1),
                        "son2_ort": round(son_donem_hiz, 1),
                        "gunluk_hiz": gunluk_hiz,
                        "aktif_ay_sayisi": aktif_ay_sayisi,
                        "aylik_detay": aylik_detay,
                        "trend_kodu": trend_kodu,
                        "trend_etiket": trend_etiket,
                        "trend_renk": trend_renk,
                        "trend_uyari": trend_uyari,
                        "degisim_yuzde": degisim_yuzde,
                        "onerilen_siparis": max(1, onerilen) if (stok_val <= 0 or bugun_val > 0 or onerilen > 0) else 0,
                        "ham_ihtiyac": max(0, hedef_kutu - max(0, stok_val)),
                        "oneri_metni": f"Aylık ~{ort_aylik_6m} kt ({target_days_clean}G hedef)",
                        "gecmis_mf_var": False,
                        "gecmis_mf_sayisi": 0,
                        "gecmis_mf_son_adet": 0,
                        "gecmis_mf_min_alim": 0,
                        "gecmis_mf_son_mf": 0,
                        "gecmis_mf_bedelsiz": 0,
                        "gecmis_mf_son_tarih": "",
                        "gecmis_mf_son_depo": "",
                        "gecmis_mf_depo": "",
                        "gecmis_mf_kisa": "",
                        "gecmis_mf_bilgi": ""
                    })

                items.sort(key=lambda x: (
                    0 if (x["stok"] <= 0 and x["bugun_cikis"] > 0) else (1 if x["bugun_cikis"] > 0 else 2),
                    x["stok_gun"],
                    -x["toplam_6ay"]
                ))

                return {
                    "success": True,
                    "source": "TEBEOS",
                    "scope": scope,
                    "target_days": target_days_clean,
                    "elapsed_ms": round((time.time() - t0) * 1000, 1),
                    "months": months_meta,
                    "items": items,
                    "stats": {
                        "total_items": len(items),
                        "stabil_count": stabil_count,
                        "azalan_count": azalan_count,
                        "artan_count": artan_count,
                        "tukenen_count": tukenen_count
                    }
                }
        except Exception as e:
            print(f"[TEBEOS] get_six_month_smart_order_list hatası: {e}")
            return {
                "success": False,
                "source": "TEBEOS",
                "scope": scope,
                "error": str(e),
                "months": [],
                "items": [],
                "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
            }

    def get_product_vat(self, barcode_or_code: str) -> Optional[float]:
        """Ürünün TEBEOS veritabanındaki resmi KDV oranını döner."""
        q = str(barcode_or_code or "").strip()
        if not q:
            return None
        try:
            with self.get_connection() as conn:
                prod = self._find_product_in_tebeos(conn, q, barcode=q)
                if prod and prod.get("kdv") is not None and float(prod["kdv"]) > 0:
                    return float(prod["kdv"])
        except Exception as e:
            print(f"[TEBEOS] get_product_vat hatası: {e}")
        return None

    def get_product_equivalents(self, barcode_or_code: str) -> Dict[str, Any]:
        """TEBEOS veritabanındaki SGK eşdeğer ilaçları (ilac.urun_sgk_esdeger_ms) stok ve kârlılık verileriyle listeler."""
        q = str(barcode_or_code or "").strip()
        if not q:
            return {"found": False, "esdeger_kodu": None, "muadiller": []}

        try:
            with self.get_connection() as conn:
                prod = self._find_product_in_tebeos(conn, q, barcode=q)
                if not prod or prod.get("is_idu"):
                    return {"found": False, "esdeger_kodu": None, "muadiller": []}

                u_id = int(prod["id"])
                _, eq_rows = conn.query(f"""
                    SELECT urun_esdeger_kod
                    FROM ilac.urun_sgk_esdeger_ms
                    WHERE urun_id = {u_id}
                      AND urun_esdeger_kod IS NOT NULL AND urun_esdeger_kod <> ''
                    ORDER BY son_islem DESC NULLS LAST
                    LIMIT 1
                """)
                if not eq_rows or not eq_rows[0][0]:
                    return {"found": False, "esdeger_kodu": None, "muadiller": []}

                esdeger_kod = str(eq_rows[0][0]).strip()
                lit_eq = _sql_lit(esdeger_kod)

                _, all_rows = conn.query(f"""
                    SELECT u.urun_id,
                           u.urun_adi,
                           (SELECT b.barkod FROM ilac.urun_barkod_ms b WHERE b.urun_id = u.urun_id AND b.barkod IS NOT NULL AND b.barkod <> '' ORDER BY COALESCE(b.aktif::text, '1') DESC, b.urun_barkod_id DESC LIMIT 1) as barkod,
                           COALESCE(f.psf, 0) as psf,
                           COALESCE(f.dsf, 0) as dsf,
                           COALESCE(f.esf, 0) as esf,
                           COALESCE(f.isf, 0) as isf,
                           COALESCE(f.kdv, 10) as kdv,
                           COALESCE(st.stok, 0) as stok,
                           COALESCE(st.cikis30, 0) as cikis30
                    FROM ilac.urun_sgk_esdeger_ms ue
                    JOIN ilac.urun_ms u ON u.urun_id = ue.urun_id
                    LEFT JOIN LATERAL (
                        SELECT psf, dsf, esf, isf, kdv FROM ilac.urun_fiyat_ms uf
                        WHERE uf.urun_id = u.urun_id
                        ORDER BY uf.gecerlilik_tarihi DESC NULLS LAST, uf.urun_fiyat_id DESC
                        LIMIT 1
                    ) f ON true
                    LEFT JOIN LATERAL (
                        SELECT COALESCE(SUM(h.adet), 0) as stok,
                               COALESCE(SUM(CASE WHEN h.hareket_tarih >= (CURRENT_DATE - INTERVAL '30 days') AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) as cikis30
                        FROM stok.stok_hareket_ms h
                        WHERE h.urun_id = u.urun_id
                    ) st ON true
                    WHERE ue.urun_esdeger_kod = {lit_eq}
                    ORDER BY st.stok DESC NULLS LAST, u.urun_id DESC
                """)

                items = []
                current_kamu_kari = 0.0
                for row in all_rows:
                    r_uid = int(row[0] or 0)
                    r_name = str(row[1] or "").strip()
                    r_bc = str(row[2] or r_uid).strip()
                    psf = round(float(row[3] or 0.0), 2)
                    dsf = round(float(row[4] or 0.0), 2)
                    esf = round(float(row[5] or 0.0), 2)
                    isf = round(float(row[6] or 0.0), 2)
                    kdv_oran = float(row[7] or 10.0)
                    stok = int(float(row[8] or 0))
                    cikis_30 = int(float(row[9] or 0))

                    # KSF (Kamu Satış Fiyatı) ve Maliyet hesabı
                    ksf = psf
                    kamu_isk = 0.0
                    try:
                        from backend.catalog import catalog
                        cat_p = catalog.get_by_barcode(r_bc)
                        if cat_p and float(cat_p.get("institution_discount") or 0.0) > 0:
                            kamu_isk = float(cat_p["institution_discount"])
                            ksf = round(psf * (1.0 - (kamu_isk / 100.0)), 2)
                    except Exception:
                        pass

                    net_maliyet_kdvsiz = dsf if dsf > 0 else round((psf / (1.0 + kdv_oran / 100.0)) * 0.71, 2)
                    net_maliyet_kdvli = round(net_maliyet_kdvsiz * (1.0 + kdv_oran / 100.0), 2)

                    kamu_kari = round(max(0.0, ksf - net_maliyet_kdvli), 2) if ksf > 0 else 0.0
                    perakende_kari = round(max(0.0, psf - net_maliyet_kdvli), 2) if psf > 0 else 0.0

                    is_curr = (r_uid == u_id)
                    if is_curr:
                        current_kamu_kari = kamu_kari

                    items.append({
                        "kod": str(r_uid),
                        "mal_kodu": str(r_uid),
                        "ad": r_name,
                        "urun_adi": r_name,
                        "barkod": r_bc,
                        "psf": psf,
                        "ksf": ksf,
                        "kamu_iskontosu": kamu_isk,
                        "net_birim_maliyet": net_maliyet_kdvsiz,
                        "net_birim_maliyet_kdvli": net_maliyet_kdvli,
                        "kamu_kari": kamu_kari,
                        "perakende_kari": perakende_kari,
                        "stok": stok,
                        "cikis_30gun": cikis_30,
                        "gecmis_mf_var": False,
                        "gecmis_mf_bilgi": "",
                        "is_current": is_curr
                    })

                for it in items:
                    kf = round(it["kamu_kari"] - current_kamu_kari, 2)
                    it["kar_farki"] = kf
                    it["is_more_profitable"] = (kf > 0)
                    it["kar_artis_yuzdesi"] = round((kf / current_kamu_kari * 100.0), 1) if (current_kamu_kari > 0 and kf > 0) else 0.0

                items.sort(key=lambda x: (x.get("kamu_kari") or 0.0, x.get("stok") or 0), reverse=True)

                en_karli = None
                muadil_kar_avantaji = 0.0
                for it in items:
                    if it.get("kar_farki", 0.0) > 0 and not it.get("is_current"):
                        it["is_best_deal"] = True
                        en_karli = it
                        muadil_kar_avantaji = it["kar_farki"]
                        break

                return {
                    "found": True,
                    "esdeger_kodu": esdeger_kod,
                    "count": len(items),
                    "en_karli_muadil": en_karli,
                    "muadil_kar_avantaji": muadil_kar_avantaji,
                    "current_kamu_kari": current_kamu_kari,
                    "muadiller": items
                }
        except Exception as e:
            print(f"[TEBEOS] get_product_equivalents hatası: {e}")
            return {"found": False, "error": str(e), "esdeger_kodu": None, "muadiller": []}

    def get_bulk_stock_and_sales_map(self, barcodes: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Verilen barkod listesi için TEBEOS PostgreSQL veritabanından tek seferde (toplu/bulk)
        anlık eczane stoğu, son 1 aylık (30 gün) çıkış ve son 3 aylık (90 gün) çıkış
        sayılarını döndürür.
        """
        result: Dict[str, Dict[str, Any]] = {}
        clean_inputs = [str(b or "").strip() for b in (barcodes or []) if str(b or "").strip()]
        if not clean_inputs:
            return result

        variant_to_originals: Dict[str, set] = {}
        for orig_bc in clean_inputs:
            result[orig_bc] = {"stok": 0, "cikis_1ay": 0, "cikis_3ay": 0, "found": False}
            variants = {orig_bc}
            if orig_bc.isdigit():
                if len(orig_bc) == 13:
                    variants.add("0" + orig_bc)
                elif len(orig_bc) == 14 and orig_bc.startswith("0"):
                    variants.add(orig_bc[1:])
            try:
                from backend.catalog import catalog
                c_item = catalog.get_by_barcode(orig_bc)
                if c_item:
                    if c_item.get("barcode"):
                        variants.add(str(c_item["barcode"]).strip())
                    for ab in (c_item.get("all_barcodes") or []):
                        if str(ab).strip():
                            variants.add(str(ab).strip())
            except Exception:
                pass
            for v in variants:
                if v:
                    variant_to_originals.setdefault(v, set()).add(orig_bc)

        all_variants = list(variant_to_originals.keys())
        if not all_variants:
            return result

        try:
            with self.get_connection() as conn:
                uid_to_originals: Dict[int, set] = {}
                idu_to_originals: Dict[int, set] = {}

                chunk_size = 400
                for i in range(0, len(all_variants), chunk_size):
                    chunk = all_variants[i:i + chunk_size]
                    in_bcs = _sql_in(chunk)

                    _, rows = conn.query(f"""
                        SELECT b.barkod, b.urun_id
                        FROM ilac.urun_barkod_ms b
                        WHERE b.barkod IN {in_bcs}
                          AND b.urun_id IS NOT NULL
                    """)
                    for r in rows:
                        b_str = str(r[0] or "").strip()
                        u_id = int(r[1] or 0)
                        if u_id > 0 and b_str in variant_to_originals:
                            uid_to_originals.setdefault(u_id, set()).update(variant_to_originals[b_str])

                    try:
                        _, idu_rows = conn.query(f"""
                            SELECT b.barkod, b.idu_bilgi_id
                            FROM public.idu_barkod_ms b
                            WHERE b.barkod IN {in_bcs}
                              AND b.idu_bilgi_id IS NOT NULL
                        """)
                        for r in idu_rows:
                            b_str = str(r[0] or "").strip()
                            i_id = int(r[1] or 0)
                            if i_id > 0 and b_str in variant_to_originals:
                                idu_to_originals.setdefault(i_id, set()).update(variant_to_originals[b_str])
                    except Exception:
                        pass

                all_uids = list(uid_to_originals.keys())
                all_idus = list(idu_to_originals.keys())
                if not all_uids and not all_idus:
                    return result

                uid_metrics: Dict[int, tuple] = {}
                for i in range(0, len(all_uids), chunk_size):
                    u_chunk = all_uids[i:i + chunk_size]
                    in_uids = "(" + ",".join(str(int(x)) for x in u_chunk) + ")"
                    _, s_rows = conn.query(f"""
                        SELECT h.urun_id,
                               COALESCE(SUM(h.adet), 0) AS stok,
                               COALESCE(SUM(CASE WHEN h.hareket_tarih >= (CURRENT_DATE - INTERVAL '30 days') AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) AS c30,
                               COALESCE(SUM(CASE WHEN h.hareket_tarih >= (CURRENT_DATE - INTERVAL '90 days') AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) AS c90
                        FROM stok.stok_hareket_ms h
                        WHERE h.urun_id IN {in_uids}
                        GROUP BY h.urun_id
                    """)
                    for r in s_rows:
                        u_id = int(r[0] or 0)
                        uid_metrics[u_id] = (
                            int(float(r[1] or 0)),
                            int(float(r[2] or 0)),
                            int(float(r[3] or 0)),
                        )

                idu_metrics: Dict[int, tuple] = {}
                for i in range(0, len(all_idus), chunk_size):
                    i_chunk = all_idus[i:i + chunk_size]
                    in_idus = "(" + ",".join(str(int(x)) for x in i_chunk) + ")"
                    _, s_rows = conn.query(f"""
                        SELECT h.idu_bilgi_id,
                               COALESCE(SUM(h.adet), 0) AS stok,
                               COALESCE(SUM(CASE WHEN h.hareket_tarih >= (CURRENT_DATE - INTERVAL '30 days') AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) AS c30,
                               COALESCE(SUM(CASE WHEN h.hareket_tarih >= (CURRENT_DATE - INTERVAL '90 days') AND h.urun_hareket_tip_id IN {self.TUM_SATIS_CIKIS_TIPLERI} THEN ABS(h.adet) ELSE 0 END), 0) AS c90
                        FROM stok.stok_hareket_ms h
                        WHERE h.idu_bilgi_id IN {in_idus}
                        GROUP BY h.idu_bilgi_id
                    """)
                    for r in s_rows:
                        i_id = int(r[0] or 0)
                        idu_metrics[i_id] = (
                            int(float(r[1] or 0)),
                            int(float(r[2] or 0)),
                            int(float(r[3] or 0)),
                        )

                orig_uids: Dict[str, set] = {}
                for u_id, origs in uid_to_originals.items():
                    for obc in origs:
                        orig_uids.setdefault(obc, set()).add(u_id)

                orig_idus: Dict[str, set] = {}
                for i_id, origs in idu_to_originals.items():
                    for obc in origs:
                        orig_idus.setdefault(obc, set()).add(i_id)

                for obc in (set(orig_uids.keys()) | set(orig_idus.keys())):
                    tot_stok = 0
                    tot_c30 = 0
                    tot_c90 = 0
                    for u_id in orig_uids.get(obc, set()):
                        st, c30, c90 = uid_metrics.get(u_id, (0, 0, 0))
                        tot_stok += st
                        tot_c30 += c30
                        tot_c90 += c90
                    for i_id in orig_idus.get(obc, set()):
                        st, c30, c90 = idu_metrics.get(i_id, (0, 0, 0))
                        tot_stok += st
                        tot_c30 += c30
                        tot_c90 += c90
                    result[obc] = {
                        "stok": int(tot_stok),
                        "cikis_1ay": int(tot_c30),
                        "cikis_3ay": int(tot_c90),
                        "found": True,
                    }

        except Exception as e:
            print(f"[TEBEOS] get_bulk_stock_and_sales_map hatası: {e}")

        return result


# Singleton instance
tebeos_client = TebeosPGClient()
