# -*- coding: utf-8 -*-
"""
backend/routers/system_routes.py
--------------------------------
Sistem durumu, depo/otomasyon şifre ayarları, lisans doğrulama,
canlı güncelleme (LAN + GitHub Portal) ve sunucu yeniden başlatma uç noktaları.
"""

import os
import sys
import json
import asyncio
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response

import backend.app_state as app_state
from backend.config_manager import get_current_credentials, save_credentials_to_env
from backend.core.session_store import SessionStore
from backend.query_engine import DepoSorguMotoru
from backend.updater import updater
from backend.license_manager import license_manager

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parent.parent.parent


@router.get("/api/status")
async def get_status():
    active = [k.value for k in app_state.motor.adapters.keys()] if app_state.motor else []
    return {
        "status": "ready",
        "active_wholesalers": active,
        "count": len(active)
    }


@router.get("/api/settings/credentials")
async def get_credentials_endpoint():
    return get_current_credentials()


@router.post("/api/settings/credentials")
async def save_credentials_endpoint(request: Request):
    data = await request.json()
    old_creds = get_current_credentials()

    for depo in ["alliance", "selcuk", "nevzat", "iskoop", "bek", "ecza1", "farmazon", "dna", "eczatrend", "eczanetakas"]:
        if depo in data:
            old_d = old_creds.get(depo, {})
            new_d = data[depo]
            has_changed = any(str(new_d.get(k, "")).strip() != str(old_d.get(k, "")).strip() for k in new_d)
            if has_changed:
                print(f">> [{depo}] Bilgileri güncellendi, eski oturum temizleniyor...")
                SessionStore.clear(depo)

    save_credentials_to_env(data)
    app_state.critical_stock_cache = {"time": 0.0, "data": []}
    app_state.smart_order_list_cache.clear()

    if app_state.motor:
        await app_state.motor.reload_adapters()
    else:
        app_state.motor = DepoSorguMotoru(headless=True)

    async def _bg_prewarm_after_save():
        try:
            for dk, adp in list(app_state.motor.adapters.items()):
                try:
                    await adp.login()
                    if hasattr(adp, "_ensure_ready_page"):
                        await adp._ensure_ready_page()
                    if hasattr(adp, "get_active_offers"):
                        await adp.get_active_offers(force_refresh=True)
                except Exception:
                    pass
        except Exception:
            pass

    asyncio.create_task(_bg_prewarm_after_save())

    active = [k.value for k in app_state.motor.adapters.keys()]
    return {
        "success": True,
        "message": f"Depo giriş bilgileri başarıyla kaydedildi. {len(active)} platform hazır.",
        "active_wholesalers": active
    }


SERVER_RUNTIME_VERSION = updater.get_local_version_info().get("version", "1.4.0")


@router.get("/api/version")
async def get_version_endpoint():
    """Mevcut yerel sürüm bilgilerini ve RAM'deki aktif çalışma sürümünü döndürür."""
    info = updater.get_local_version_info()
    disk_ver = info.get("version", SERVER_RUNTIME_VERSION)
    info["runtime_version"] = SERVER_RUNTIME_VERSION
    info["restart_required"] = (disk_ver != SERVER_RUNTIME_VERSION)
    if info["restart_required"]:
        trigger_delayed_server_restart(1.2)
    return info



@router.get("/api/license/status")
async def get_license_status_endpoint(force: bool = Query(False)):
    """Mevcut eczane lisans durumunu (bulut doğrulaması dahil) ve donanım kimliğini (HWID) döndürür."""
    return await asyncio.to_thread(license_manager.get_status, force)


@router.post("/api/license/sync")
async def sync_license_cloud_endpoint():
    """Merkezi bulut lisans sunucusundan (GitHub / CRM) anlık lisans durumunu ve süre uzatımlarını çeker."""
    sync_res = await asyncio.to_thread(license_manager.sync_with_cloud, True)
    status_res = await asyncio.to_thread(license_manager.get_status, False)
    status_res["cloud_sync"] = sync_res
    return status_res


@router.post("/api/license/activate")
async def activate_license_endpoint(request: Request):
    """Yeni bir lisans anahtarını doğrular ve aktive eder."""
    try:
        body = await request.json()
        key_str = str(body.get("license_key") or "").strip()
        res = await asyncio.to_thread(license_manager.activate_license, key_str)
        return res
    except Exception as e:
        return JSONResponse(status_code=400, content={"valid": False, "message": str(e)})


def _find_release_dir() -> Optional[Path]:
    candidates = [
        BASE_DIR / "releases",
        BASE_DIR / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "releases",
        BASE_DIR.parent / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "releases",
        Path(r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases"),
    ]
    for c in candidates:
        if (c / "version.json").exists():
            return c
    return None


def _load_release_publisher_module():
    candidates = [
        BASE_DIR / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI",
        BASE_DIR.parent / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI",
        Path(r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI"),
        Path(r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI"),
    ]
    for c in candidates:
        if (c / "release_publisher.py").exists():
            if str(c) not in sys.path:
                sys.path.insert(0, str(c))
            import release_publisher
            return release_publisher
    return None


@router.get("/portal", response_class=HTMLResponse)
@router.get("/releases", response_class=HTMLResponse)
@router.get("/releases/index.html", response_class=HTMLResponse)
async def serve_release_portal_html():
    """Canlı Güncelleme Portalı web sayfasını sunar."""
    rel_dir = _find_release_dir()
    if rel_dir and (rel_dir / "index.html").exists():
        return HTMLResponse(content=(rel_dir / "index.html").read_text(encoding="utf-8"))
    return HTMLResponse(content="<h3>Canlı Güncelleme Portalı hazırlanıyor...</h3>")


@router.get("/releases/version.json")
@router.get("/api/releases/version.json")
async def serve_release_manifest_endpoint(request: Request):
    """Merkezi/Admin bilgisayarda yayınlanan güncel version.json manifestosunu ağa ve istemcilere sunar."""
    rel_dir = _find_release_dir()
    if not rel_dir or not (rel_dir / "version.json").exists():
        return JSONResponse(status_code=404, content={"error": "Yayınlanmış güncelleme manifestosu bulunamadı."})
    try:
        data = json.loads((rel_dir / "version.json").read_text(encoding="utf-8"))
        ver = data.get("version", "1.0.0")
        host_hdr = request.headers.get("host") or "127.0.0.1:8080"
        zip_name = f"update_v{ver}.zip"
        if (rel_dir / zip_name).exists():
            data["download_url"] = f"http://{host_hdr}/releases/{zip_name}"
        return data
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/releases/{filename}")
@router.get("/api/releases/{filename}")
async def serve_release_package_endpoint(filename: str):
    """Merkezi/Admin bilgisayarda yayınlanan update_vX.Y.Z.zip paketini indirilebilir olarak sunar."""
    safe_name = os.path.basename(filename)
    rel_dir = _find_release_dir()
    if not rel_dir or not (rel_dir / safe_name).exists():
        return JSONResponse(status_code=404, content={"error": "Güncelleme paketi bulunamadı."})
    if safe_name.endswith(".html"):
        return HTMLResponse(content=(rel_dir / safe_name).read_text(encoding="utf-8"))
    content_bytes = (rel_dir / safe_name).read_bytes()
    return Response(
        content=content_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{safe_name}"'}
    )


@router.post("/api/update/config")
async def update_config_endpoint(request: Request):
    """Manifest URL ve otomatik canlı güncelleme ayarlarını kaydeder."""
    try:
        body = await request.json()
        manifest_url = str(body.get("manifest_url") or "").strip()
        auto_update = body.get("auto_update")
        res = await asyncio.to_thread(updater.set_manifest_url, manifest_url, auto_update)
        return res
    except Exception as e:
        return JSONResponse(status_code=400, content={"success": False, "message": str(e)})


@router.get("/api/github-portal/config")
async def get_github_portal_config_endpoint():
    """GitHub Canlı Güncelleme Portalı ayarlarını döndürür."""
    pub = _load_release_publisher_module()
    local_v = updater.get_local_version_info()
    cur_ver = local_v.get("version", "1.0.7")
    if not pub:
        return {
            "available": False,
            "current_version": cur_ver,
            "next_version": "1.0.8",
            "manifest_url": local_v.get("manifest_url", ""),
            "auto_update": local_v.get("auto_update", True)
        }
    cfg = pub.load_github_config()
    owner = cfg.get("owner", "depomxxx")
    repo = cfg.get("repo", "depo-updates")
    branch = cfg.get("branch", "main")
    return {
        "available": True,
        "owner": owner,
        "repo": repo,
        "branch": branch,
        "has_token": bool(cfg.get("token")),
        "token_preview": (cfg["token"][:7] + "..." + cfg["token"][-4:]) if len(cfg.get("token", "")) > 12 else "",
        "current_version": cur_ver,
        "next_version": pub.bump_patch_version(cur_ver),
        "manifest_url": f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/version.json",
        "pages_url": f"https://{owner}.github.io/{repo}/",
        "auto_update": local_v.get("auto_update", True)
    }


@router.post("/api/github-portal/verify")
async def verify_github_portal_endpoint(request: Request):
    """GitHub Token ile repo oluşturur/doğrular ve Manifest URL'yi kaydeder."""
    pub = _load_release_publisher_module()
    if not pub:
        return JSONResponse(status_code=400, content={"success": False, "message": "Yayınlayıcı modülü (release_publisher.py) bu bilgisayarda bulunamadı."})
    body = await request.json()
    cfg = pub.load_github_config()
    token = str(body.get("token") or cfg.get("token") or "").strip()
    owner = str(body.get("owner") or cfg.get("owner") or "depomxxx").strip()
    repo = str(body.get("repo") or cfg.get("repo") or "depo-updates").strip()
    branch = str(body.get("branch") or cfg.get("branch") or "main").strip()
    res = await asyncio.to_thread(pub.setup_and_verify_github_portal, token, owner, repo, branch)
    if res.get("success") and res.get("manifest_url"):
        await asyncio.to_thread(updater.set_manifest_url, res["manifest_url"], True)
    return res


@router.post("/api/github-portal/publish")
async def publish_github_portal_endpoint(request: Request):
    """Yeni sürümü paketler, GitHub Canlı Portalına yükler ve ağdaki tüm bilgisayarları günceller."""
    pub = _load_release_publisher_module()
    if not pub:
        return JSONResponse(status_code=400, content={"success": False, "message": "Yayınlayıcı modülü (release_publisher.py) bu bilgisayarda bulunamadı."})
    body = await request.json()
    cfg = pub.load_github_config()
    token = str(body.get("token") or cfg.get("token") or "").strip()
    owner = str(body.get("owner") or cfg.get("owner") or "depomxxx").strip()
    repo = str(body.get("repo") or cfg.get("repo") or "depo-updates").strip()
    new_ver = str(body.get("version") or pub.bump_patch_version(updater.get_local_version_info().get("version", "1.0.7"))).strip()
    changelog = str(body.get("changelog") or "Canlı güncelleme ve performans iyileştirmeleri.").strip()

    res = await asyncio.to_thread(
        pub.build_and_publish_release,
        new_ver,
        changelog,
        "",
        True,
        token,
        owner,
        repo
    )
    return res


@router.get("/api/update/check")
async def check_update_endpoint(timeout: float = Query(6.0, ge=0.5, le=15.0)):
    """Merkezi sunucudan (GitHub ve Yerel Ağ LAN) yeni güncelleme olup olmadığını denetler."""
    res = await asyncio.to_thread(updater.check_for_updates, timeout)
    return res


_RESTART_LOCK = False


def trigger_delayed_server_restart(delay_sec: float = 1.5):
    global _RESTART_LOCK
    if _RESTART_LOCK:
        return
    _RESTART_LOCK = True

    def _delayed_restart():
        import time, subprocess
        time.sleep(delay_sec)
        base_dir = str(BASE_DIR)
        my_pid = os.getpid()

        # Önce mevcut sunucunun alt süreçlerini (Playwright node.exe / chrome.exe) kapat ki port 8080 kilitli kalmasın
        if sys.platform == "win32":
            try:
                subprocess.run(
                    [
                        "powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
                        f"Get-CimInstance Win32_Process | Where-Object {{ $_.ParentProcessId -eq {my_pid} }} | ForEach-Object {{ taskkill /F /T /PID $_.ProcessId 2>$null }}"
                    ],
                    creationflags=subprocess.CREATE_NO_WINDOW,
                    timeout=4
                )
            except Exception:
                pass

        tria_pos_cand = os.path.join(base_dir, "runtime", "TriaPcPOS.exe")
        tria_cand = os.path.join(base_dir, "runtime", "Tria.exe")
        if os.path.isfile(tria_pos_cand):
            py_exe = tria_pos_cand
        elif os.path.isfile(tria_cand):
            py_exe = tria_cand
        else:
            py_exe = sys.executable

        script = os.path.join(base_dir, "server.py")
        cflags = 0
        if sys.platform == "win32":
            cflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
        env = os.environ.copy()
        env["SERVER_RESTARTING"] = "1"
        env["TRIA_EXE_REEXEC"] = "1"
        subprocess.Popen([py_exe, script, "--restarting"], cwd=base_dir, env=env, creationflags=cflags, close_fds=True)
        os._exit(0)

    import threading
    threading.Thread(target=_delayed_restart, daemon=True).start()



@router.post("/api/update/apply")
async def apply_update_endpoint(request: Request):
    """Merkezi sunucudan (GitHub veya LAN) güncellemeyi indirip kurar ve sunucuyu yeniden başlatır."""
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass

    custom_manifest = str(body.get("manifest_url") or body.get("update_url") or "").strip()
    if custom_manifest.startswith("http"):
        try:
            updater.set_manifest_url(custom_manifest, True)
        except Exception:
            pass

    download_url = body.get("download_url")
    expected_sha256 = body.get("sha256", "")
    new_version = str(body.get("latest_version") or body.get("target_version") or body.get("version") or "").strip()

    if not download_url:
        chk = await asyncio.to_thread(updater.check_for_updates, 6.0)
        if chk.get("download_url") and (chk.get("update_available") or body.get("force")):
            download_url = chk["download_url"]
            expected_sha256 = chk.get("sha256", "")
            new_version = chk.get("latest_version", "") or new_version
        else:
            return JSONResponse(status_code=400, content={"success": False, "message": "İndirilecek yeni bir sürüm bulunamadı veya sisteminiz zaten güncel."})

    res = await asyncio.to_thread(updater.apply_update, download_url, expected_sha256, new_version)
    if res.get("success"):
        trigger_delayed_server_restart(1.5)
        res["restart"] = True
    return res


@router.post("/api/server/restart")
@router.post("/api/system/restart")
async def restart_server_endpoint():
    """Sunucuyu yeniden başlatır."""
    trigger_delayed_server_restart(1.0)
    return {"success": True, "message": "Sunucu yeniden başlatılıyor. Sayfa 3 saniye içinde yenilenecek."}
