# -*- coding: utf-8 -*-
"""
backend/botanik_client.py
-------------------------
Botanik Eczane Otomasyon Sistemi (MS SQL Server) Veri Erişim & Analiz Modülü.
Eczane raf stoğu, aylık nakit fişli ve SGK reçeteli satış hareketlerini (ÇIKIŞ),
ve depolardan gelen alış faturalarını (GİRİŞ) sorgular.
"""

import os
import sys
import time
import datetime
import xml.etree.ElementTree as ET
from typing import Dict, Any, List, Optional, Tuple

try:
    import pyodbc
except ImportError:
    pyodbc = None

class BotanikSQLClient:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.default_config_path = r"C:\BotanikEczane\BotanikEczane.exe.config"

    def read_botanik_config_file(self, config_path: Optional[str] = None) -> Dict[str, Any]:
        """Botanik config dosyasından (BotanikEczane.exe.config) bağlantı bilgilerini okur."""
        candidate_paths = []
        if config_path:
            candidate_paths.append(config_path)
        candidate_paths.extend([
            self.default_config_path,
            r"D:\BotanikEczane\BotanikEczane.exe.config",
            r"C:\Botanik\BotanikEczane.exe.config",
            r"D:\Botanik\BotanikEczane.exe.config",
            r"C:\BotanikEOS\BotanikEczane.exe.config",
            r"C:\Program Files (x86)\BotanikEczane\BotanikEczane.exe.config",
            r"C:\Program Files\BotanikEczane\BotanikEczane.exe.config",
        ])
        cfg_file = next((p for p in candidate_paths if p and os.path.exists(p)), self.default_config_path)
        if not os.path.exists(cfg_file):
            return {"success": False, "message": f"Botanik config dosyası bulunamadı ({cfg_file}). Lütfen bilgileri elle giriniz."}

        try:
            tree = ET.parse(cfg_file)
            root = tree.getroot()
            conn_entries = {}
            for add in root.findall(".//connectionStrings/add"):
                name = add.attrib.get("name")
                c_str = add.attrib.get("connectionString")
                if name and c_str:
                    conn_entries[name] = c_str

            # Öncelikli olarak 'eczanes' veya 'eczanew' bağlantı dizesini al
            target_str = conn_entries.get("eczanes") or conn_entries.get("eczanew") or next(iter(conn_entries.values()), "")
            if not target_str:
                return {"success": False, "message": "Config dosyasında geçerli bir bağlantı dizesi bulunamadı."}

            params = {}
            for item in target_str.split(";"):
                if "=" in item:
                    k, v = item.split("=", 1)
                    params[k.strip().lower()] = v.strip()

            server = params.get("server") or params.get("data source") or r".\BOTANIKSQL"
            database = params.get("initial catalog") or params.get("database") or "eczane"
            uid = params.get("user id") or params.get("uid") or "sa"
            pwd = params.get("password") or params.get("pwd") or "123"
            trusted = "true" if params.get("integrated security", "").lower() in ["true", "sspi", "yes"] else "false"

            return {
                "success": True,
                "found": True,
                "path": cfg_file,
                "server": server,
                "database": database,
                "user": uid,
                "password": pwd,
                "trusted": trusted,
                "config": {
                    "server": server,
                    "database": database,
                    "user": uid,
                    "password": pwd,
                    "trusted": trusted == "true"
                },
                "all_configs": conn_entries,
                "message": f"Botanik config başarıyla okundu ({server} / {database})"
            }
        except Exception as e:
            return {"success": False, "message": f"Config dosyası okunurken hata oluştu: {str(e)}"}

    def get_config(self) -> Dict[str, Any]:
        """Güncel Botanik bağlantı ayarlarını döndürür."""
        server = os.environ.get("BOTANIK_DB_SERVER", "").strip()
        database = os.environ.get("BOTANIK_DB_DATABASE", "").strip()
        user = os.environ.get("BOTANIK_DB_USER", "").strip()
        password = os.environ.get("BOTANIK_DB_PASSWORD", "").strip()
        trusted = os.environ.get("BOTANIK_DB_TRUSTED", "").strip().lower() in ["1", "true", "yes"]

        # Eğer ortam değişkenleri boşsa veya varsayılan yerel sunucu yazılıp kullanıcı adı girilmemişse config dosyasından otomatik tamamla
        if not server or (not user and not trusted) or server in [r".\BOTANIKSQL", r"localhost\BOTANIKSQL"]:
            auto_cfg = self.read_botanik_config_file()
            if auto_cfg.get("success"):
                if not server or server in [r".\BOTANIKSQL", r"localhost\BOTANIKSQL"]:
                    server = auto_cfg.get("server") or server
                database = database or auto_cfg.get("database")
                user = user or auto_cfg.get("user")
                password = password or auto_cfg.get("password")
                if not os.environ.get("BOTANIK_DB_TRUSTED", "").strip():
                    trusted = auto_cfg.get("trusted") == "true"

        return {
            "server": server or r".\BOTANIKSQL",
            "database": database or "eczane",
            "user": user or "sa",
            "password": password or "123",
            "trusted": trusted
        }

    def _connect_with_cfg(self, cfg: Dict[str, Any], timeout: int = 4):
        server = cfg["server"]
        database = cfg["database"]
        if cfg.get("trusted"):
            conn_str = f"DRIVER={{SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;"
        else:
            user = cfg["user"]
            pwd = cfg["password"]
            conn_str = f"DRIVER={{SQL Server}};SERVER={server};DATABASE={database};UID={user};PWD={pwd};"

        conn = pyodbc.connect(conn_str, timeout=timeout)
        try:
            conn.setdecoding(pyodbc.SQL_CHAR, encoding='cp1254')
            conn.setdecoding(pyodbc.SQL_WCHAR, encoding='utf-16le')
        except Exception:
            pass
        return conn

    def get_connection(self, custom_cfg: Optional[Dict[str, Any]] = None):
        """MS SQL Server veritabanına bağlanır. Başarısız olursa BotanikEczane.exe.config ile otomatik yedek bağlantı dener."""
        if pyodbc is None:
            raise RuntimeError("pyodbc kütüphanesi yüklü değil. 'pip install pyodbc' gereklidir.")

        cfg = custom_cfg or self.get_config()
        try:
            return self._connect_with_cfg(cfg, timeout=4)
        except Exception as first_err:
            if custom_cfg is None:
                auto_cfg = self.read_botanik_config_file()
                if auto_cfg.get("success"):
                    fallback_cfg = {
                        "server": auto_cfg.get("server") or r".\BOTANIKSQL",
                        "database": auto_cfg.get("database") or "eczane",
                        "user": auto_cfg.get("user") or "sa",
                        "password": auto_cfg.get("password") or "123",
                        "trusted": auto_cfg.get("trusted") == "true"
                    }
                    if fallback_cfg["server"] != cfg["server"] or fallback_cfg["user"] != cfg["user"] or fallback_cfg["password"] != cfg["password"]:
                        conn = self._connect_with_cfg(fallback_cfg, timeout=4)
                        os.environ["BOTANIK_DB_SERVER"] = fallback_cfg["server"]
                        os.environ["BOTANIK_DB_DATABASE"] = fallback_cfg["database"]
                        os.environ["BOTANIK_DB_USER"] = fallback_cfg["user"]
                        os.environ["BOTANIK_DB_PASSWORD"] = fallback_cfg["password"]
                        os.environ["BOTANIK_DB_TRUSTED"] = "true" if fallback_cfg["trusted"] else "false"
                        return conn
            raise first_err

    def ping(
        self,
        server: Optional[str] = None,
        database: Optional[str] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        trusted: Optional[bool] = None
    ) -> Dict[str, Any]:
        """Botanik MS SQL veritabanına ping atar ve bağlantı durumunu test eder."""
        base_cfg = self.get_config()
        custom_cfg = None
        if any(v is not None and str(v).strip() != "" for v in [server, database, user, password, trusted]):
            custom_cfg = {
                "server": (server or base_cfg["server"]).strip(),
                "database": (database or base_cfg["database"]).strip(),
                "user": (user if user is not None else base_cfg["user"]).strip(),
                "password": (password if password is not None else base_cfg["password"]).strip(),
                "trusted": bool(trusted) if trusted is not None else base_cfg["trusted"]
            }
        cfg = custom_cfg or base_cfg
        t0 = time.time()
        try:
            with self.get_connection(custom_cfg=custom_cfg) as conn:
                active_cfg = custom_cfg or self.get_config()
                latency_ms = round((time.time() - t0) * 1000, 2)
                cur = conn.cursor()

                cur.execute("SELECT COUNT(*) FROM Urun")
                urun_count = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM ReceteAna WHERE ISNULL(RxSilme, 0) = 0")
                recete_count = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM FaturaGiris WHERE ISNULL(FGSilme, 0) = 0")
                fatura_count = cur.fetchone()[0]

                # Bugün kesilen reçete sayısı
                today_str = datetime.date.today().strftime("%Y-%m-%d")
                cur.execute("SELECT COUNT(*) FROM ReceteAna WHERE RxKayitTarihi >= ? AND ISNULL(RxSilme, 0) = 0", (today_str,))
                today_recete = cur.fetchone()[0]

                # SQL Server sürümü
                cur.execute("SELECT @@VERSION")
                ver_raw = cur.fetchone()[0]
                version_short = ver_raw.split("\n")[0] if ver_raw else "MS SQL Server"

                return {
                    "success": True,
                    "connected": True,
                    "message": f"Botanik MS SQL bağlantısı başarılı ({latency_ms} ms)",
                    "latency_ms": latency_ms,
                    "version": version_short,
                    "server": active_cfg["server"],
                    "database": active_cfg["database"],
                    "user": active_cfg["user"],
                    "trusted": active_cfg["trusted"],
                    "stats": {
                        "kayitli_urun_sayisi": urun_count,
                        "toplam_recete_sayisi": recete_count,
                        "fatura_sayisi": fatura_count,
                        "bugun_recete_sayisi": today_recete
                    }
                }
        except Exception as e:
            latency_ms = round((time.time() - t0) * 1000, 2)
            return {
                "success": False,
                "connected": False,
                "message": f"Botanik SQL bağlantı hatası: {str(e)}",
                "latency_ms": latency_ms,
                "server": cfg["server"],
                "database": cfg["database"],
                "user": cfg["user"],
                "error": str(e)
            }

    def get_product_analysis(self, query: str, barcode: str = "") -> Dict[str, Any]:
        """
        Belirtilen barkod veya ürün adı için Botanik SQL veritabanından:
        1. Anlık raf/depo/açık stok
        2. Son 6 takvim ayı Nakit (Elden) ve Reçeteli (SGK) çıkış adetleri (ÇIKIŞ)
        3. Son depolardan gelen alış faturaları (GİRİŞ)
        4. Aylık ortalama çıkış hızı, günlük çıkış, kalan gün tahmini
        5. Akıllı sipariş önerisi
        döndürür.
        """
        clean_q = (barcode or query or "").strip()
        if not clean_q:
            return {"found": False, "message": "Barkod veya ürün belirtilmedi."}

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                # 1. Ürünü bul (Öncelik: Barkod, sonra UrunId, sonra İsim)
                product_row = None
                target_barcodes = set()
                if barcode and barcode.strip().isdigit() and len(barcode.strip()) >= 8:
                    target_barcodes.add(barcode.strip())
                if clean_q and clean_q.isdigit() and len(clean_q) >= 8:
                    target_barcodes.add(clean_q)
                if query and query.strip().isdigit() and len(query.strip()) >= 8:
                    target_barcodes.add(query.strip())

                if target_barcodes:
                    # Kanonik EAN, 13/14 haneli GTIN ve ilişkili tüm barkodları ekle ki Botanik'teki hem eski hem yeni kartları yakalayabilelim:
                    try:
                        from backend.catalog import catalog
                        for b in list(target_barcodes):
                            if len(b) == 14 and b.startswith("0"):
                                target_barcodes.add(b[1:])
                            elif len(b) == 13 and b.isdigit():
                                target_barcodes.add("0" + b)
                            can = catalog.resolve_canonical_barcode(b)
                            if can:
                                target_barcodes.add(can)
                            cat_p = catalog.get_by_barcode(b)
                            if cat_p:
                                for ab in cat_p.get("all_barcodes", []):
                                    if str(ab).strip():
                                        target_barcodes.add(str(ab).strip())
                    except Exception:
                        pass

                    bc_list = list(target_barcodes)
                    placeholders = ",".join("?" for _ in bc_list)
                    cur.execute(f"""
                        SELECT TOP 1 
                            u.UrunId, 
                            u.UrunAdi, 
                            ISNULL(
                                (SELECT TOP 1 b2.BarkodAdi FROM Barkod b2 WITH (NOLOCK)
                                 WHERE b2.BarkodUrunId = u.UrunId AND b2.BarkodAdi IS NOT NULL AND b2.BarkodAdi <> ''
                                 ORDER BY ISNULL(b2.BarkodSilme, 0) ASC,
                                          CASE WHEN b2.BarkodAdi IN ({placeholders}) THEN 0 ELSE 1 END,
                                          CASE WHEN LEN(b2.BarkodAdi) = 13 THEN 0 ELSE 1 END,
                                          b2.BarkodId DESC),
                                ?
                            ) AS Barkod,
                            ISNULL(u.UrunStokDepo, 0) AS StokDepo,
                            ISNULL(u.UrunStokRaf, 0) AS StokRaf,
                            ISNULL(u.UrunStokAcik, 0) AS StokAcik,
                            (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) AS ToplamStok,
                            ISNULL(u.UrunFiyatEtiket, 0) AS PSF
                        FROM Urun u WITH (NOLOCK)
                        WHERE ISNULL(u.UrunSilme, 0) = 0
                          AND u.UrunId IN (
                              SELECT b.BarkodUrunId FROM Barkod b WITH (NOLOCK) WHERE b.BarkodAdi IN ({placeholders})
                              UNION
                              SELECT fib.FBUrunId FROM FIBBarkodUrunId fib WITH (NOLOCK) WHERE fib.FBBarkod IN ({placeholders}) AND ISNULL(fib.Pasif, 0) = 0
                              UNION
                              SELECT fs.FSUrunId FROM FaturaSatir fs WITH (NOLOCK) WHERE fs.FSBarkodAdi IN ({placeholders})
                          )
                        ORDER BY 
                            (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) DESC,
                            ISNULL(u.UrunAktif, 0) DESC,
                            (SELECT COUNT(*) FROM EldenIlaclari ei WITH (NOLOCK) WHERE ei.RIUrunId = u.UrunId AND ISNULL(ei.RISilme, 0) = 0) DESC,
                            u.UrunId DESC
                    """, (*bc_list, bc_list[0], *bc_list, *bc_list, *bc_list))
                    product_row = cur.fetchone()

                # İsim veya UrunId araması
                if not product_row:
                    # Yalnızca 9 haneye kadar olan sayılar UrunId (MS SQL INT) olabilir! 13 haneli barkodlar INT taşması yaratır.
                    cand_uid = None
                    if query and query.strip().isdigit() and len(query.strip()) <= 9:
                        cand_uid = int(query.strip())
                    elif clean_q.isdigit() and len(clean_q) <= 9:
                        cand_uid = int(clean_q)
                    if cand_uid is not None:
                        cur.execute("""
                            SELECT TOP 1 
                                u.UrunId, 
                                u.UrunAdi, 
                                ISNULL(
                                    (SELECT TOP 1 b2.BarkodAdi FROM Barkod b2 WITH (NOLOCK)
                                     WHERE b2.BarkodUrunId = u.UrunId AND b2.BarkodAdi IS NOT NULL AND b2.BarkodAdi <> ''
                                     ORDER BY ISNULL(b2.BarkodSilme, 0) ASC, CASE WHEN LEN(b2.BarkodAdi) = 13 THEN 0 ELSE 1 END, b2.BarkodId DESC),
                                    ''
                                ) AS Barkod,
                                ISNULL(u.UrunStokDepo, 0) AS StokDepo,
                                ISNULL(u.UrunStokRaf, 0) AS StokRaf,
                                ISNULL(u.UrunStokAcik, 0) AS StokAcik,
                                (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) AS ToplamStok,
                                ISNULL(u.UrunFiyatEtiket, 0) AS PSF
                            FROM Urun u WITH (NOLOCK)
                            WHERE u.UrunId = ? AND ISNULL(u.UrunSilme, 0) = 0
                        """, (cand_uid,))
                        product_row = cur.fetchone()

                if not product_row:
                    search_text = query.strip() if (query and not query.strip().isdigit()) else ""
                    if not search_text:
                        try:
                            from backend.catalog import catalog
                            cat_item = catalog.get_by_barcode(clean_q)
                            if cat_item and cat_item.get("name"):
                                search_text = str(cat_item["name"]).strip()
                        except Exception:
                            pass
                    if not search_text:
                        search_text = clean_q
                    if search_text and not search_text.isdigit():
                        tr_query = search_text.replace("i", "İ").replace("ı", "I").upper()
                        cur.execute("""
                            SELECT TOP 1 
                                u.UrunId, 
                                u.UrunAdi, 
                                ISNULL(
                                    (SELECT TOP 1 b2.BarkodAdi FROM Barkod b2 WITH (NOLOCK)
                                     WHERE b2.BarkodUrunId = u.UrunId AND b2.BarkodAdi IS NOT NULL AND b2.BarkodAdi <> ''
                                     ORDER BY ISNULL(b2.BarkodSilme, 0) ASC, CASE WHEN LEN(b2.BarkodAdi) = 13 THEN 0 ELSE 1 END, b2.BarkodId DESC),
                                    ''
                                ) AS Barkod,
                                ISNULL(u.UrunStokDepo, 0) AS StokDepo,
                                ISNULL(u.UrunStokRaf, 0) AS StokRaf,
                                ISNULL(u.UrunStokAcik, 0) AS StokAcik,
                                (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) AS ToplamStok,
                                ISNULL(u.UrunFiyatEtiket, 0) AS PSF
                            FROM Urun u WITH (NOLOCK)
                            WHERE (u.UrunAdi LIKE ? OR u.UrunAdi LIKE ?)
                              AND ISNULL(u.UrunSilme, 0) = 0
                            ORDER BY (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) DESC,
                                     ISNULL(u.UrunAktif, 0) DESC,
                                     u.UrunId DESC
                        """, (f"%{search_text}%", f"%{tr_query}%"))
                        product_row = cur.fetchone()

                if not product_row:
                    return {
                        "found": False,
                        "connected": True,
                        "kaynak": "BOTANIK",
                        "message": f"'{clean_q}' Botanik kayıtlarında bulunamadı."
                    }

                u_id, u_adi, found_barkod, stok_depo, stok_raf, stok_acik, top_stok, psf = product_row
                final_barcode = barcode or found_barkod or clean_q
                try:
                    from backend.catalog import catalog
                    can_final = catalog.resolve_canonical_barcode(final_barcode)
                    if can_final:
                        final_barcode = can_final
                except Exception:
                    pass
                stok = int(top_stok or 0)

                # 2. Son 6 Aylık Satış / Çıkış Trendi (Nakit vs Reçeteli)
                # Reçeteli Çıkışlar
                cur.execute("""
                    SELECT 
                        FORMAT(ra.RxKayitTarihi, 'yyyy-MM') as Ay,
                        SUM(ri.RIAdet) as ReceteliAdet
                    FROM ReceteIlaclari ri WITH (NOLOCK)
                    JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                    WHERE ri.RIUrunId = ? 
                      AND ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0
                      AND ra.RxKayitTarihi >= DATEADD(month, -6, GETDATE())
                    GROUP BY FORMAT(ra.RxKayitTarihi, 'yyyy-MM')
                    ORDER BY Ay ASC
                """, (u_id,))
                recete_rows = cur.fetchall()
                recete_map = {str(r[0]): int(r[1] or 0) for r in recete_rows}

                # Elden (Nakit / POS) Çıkışlar
                cur.execute("""
                    SELECT 
                        FORMAT(ea.RxKayitTarihi, 'yyyy-MM') as Ay,
                        SUM(ei.RIAdet) as EldenAdet
                    FROM EldenIlaclari ei WITH (NOLOCK)
                    JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                    WHERE ei.RIUrunId = ? 
                      AND ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0
                      AND ea.RxKayitTarihi >= DATEADD(month, -6, GETDATE())
                    GROUP BY FORMAT(ea.RxKayitTarihi, 'yyyy-MM')
                    ORDER BY Ay ASC
                """, (u_id,))
                elden_rows = cur.fetchall()
                elden_map = {str(r[0]): int(r[1] or 0) for r in elden_rows}

                ay_isimleri = {
                    "01": "Ocak", "02": "Şubat", "03": "Mart", "04": "Nisan",
                    "05": "Mayıs", "06": "Haziran", "07": "Temmuz", "08": "Ağustos",
                    "09": "Eylül", "10": "Ekim", "11": "Kasım", "12": "Aralık"
                }

                # Kesintisiz son 6 takvim ayını oluştur
                today = datetime.date.today()
                aylik_cikislar = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    m_str = f"{m_calc:02d}"
                    ym_key = f"{y_calc}-{m_str}"
                    is_current_month = (i == 0)
                    suffix = " (Bu Ay)" if is_current_month else ""
                    ay_label = f"{ay_isimleri.get(m_str, m_str)} '{str(y_calc)[-2:]}{suffix}"

                    nakit_val = elden_map.get(ym_key, 0)
                    recete_val = recete_map.get(ym_key, 0)
                    top_cikis = nakit_val + recete_val

                    aylik_cikislar.append({
                        "ay": ym_key,
                        "label": ay_label,
                        "is_current": is_current_month,
                        "nakit": nakit_val,
                        "receteli": recete_val,
                        "toplam": top_cikis
                    })

                # Ortalama aylık ve günlük çıkış hesabı
                gecmis_aylar = aylik_cikislar[:-1] if len(aylik_cikislar) > 1 else aylik_cikislar
                gecmis_sum = sum(x["toplam"] for x in gecmis_aylar)
                if gecmis_sum > 0:
                    ort_aylik = round(gecmis_sum / max(1, len(gecmis_aylar)), 1)
                else:
                    ort_aylik = round(sum(x["toplam"] for x in aylik_cikislar) / max(1, len(aylik_cikislar)), 1)

                ort_gunluk = round(ort_aylik / 30.0, 2)

                # Kalan gün ve stok durumu
                if ort_gunluk > 0:
                    kalan_gun = int(round(stok / ort_gunluk))
                else:
                    kalan_gun = 999 if stok > 0 else 0

                # Durum rozeti & Hareketsiz Kart Tespiti
                toplam_6_aylik_cikis = sum(x["toplam"] for x in aylik_cikislar)
                is_hareketsiz = (stok <= 0 and toplam_6_aylik_cikis == 0)

                if is_hareketsiz:
                    stok_status = "HAREKET YOK"
                    stok_status_color = "slate"
                    onerilen_siparis = 1
                elif stok <= 0:
                    stok_status = "TÜKENDİ"
                    stok_status_color = "red"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(1, hedef_stok - stok)
                elif kalan_gun < 10:
                    stok_status = "KRİTİK AZ"
                    stok_status_color = "amber"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                elif kalan_gun <= 30:
                    stok_status = "YETERLİ"
                    stok_status_color = "emerald"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                else:
                    stok_status = "YÜKSEK STOK"
                    stok_status_color = "sky"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)

                # 3. Son Alış Faturaları / Depo Girişleri (GİRİŞ)
                cur.execute("""
                    SELECT TOP 6 
                        CONVERT(varchar(10), fg.FGFaturaTarihi, 120) as Tarih,
                        ISNULL(d.DepoAdi, 'DİĞER DEPO') as Depo,
                        ISNULL(fs.FSUrunAdet, 0) as Adet,
                        ISNULL(fs.FSUrunMf, 0) as MF,
                        CASE 
                            WHEN ISNULL(fs.FSDepocuFiyati, 0) > 0 THEN fs.FSDepocuFiyati 
                            WHEN ISNULL(fs.FSEczaciFiyati, 0) > 0 THEN fs.FSEczaciFiyati 
                            ELSE ISNULL(fs.FSBirimFiyat, 0) 
                        END as BirimFiyat,
                        ISNULL(fs.FSMaliyet, 0) as Maliyet,
                        ISNULL(fg.FGFaturaNo, '') as FaturaNo
                    FROM FaturaSatir fs WITH (NOLOCK)
                    JOIN FaturaGiris fg WITH (NOLOCK) ON fs.FSFGId = fg.FGId
                    LEFT JOIN Depo d WITH (NOLOCK) ON fg.FGIlgiliId = d.DepoId
                    WHERE fs.FSUrunId = ? AND ISNULL(fg.FGSilme, 0) = 0
                    ORDER BY fg.FGFaturaTarihi DESC, fg.FGId DESC
                """, (u_id,))
                giris_rows = cur.fetchall()

                son_girisler = []
                toplam_giren_kutu = 0
                for gr in giris_rows:
                    g_adet = int(gr[2])
                    g_mf = int(gr[3])
                    g_maliyet = round(float(gr[5] or 0.0), 2)
                    g_birim = round(float(gr[4] or 0.0), 2)
                    top_satir = g_adet + g_mf
                    toplam_giren_kutu += top_satir
                    son_girisler.append({
                        "tarih": str(gr[0]),
                        "depo": str(gr[1]),
                        "adet": g_adet,
                        "mf": g_mf,
                        "toplam_adet": top_satir,
                        "birim_fiyat": g_birim,
                        "maliyet": g_maliyet,
                        "fatura_no": str(gr[6])
                    })

                return {
                    "found": True,
                    "connected": True,
                    "kaynak": "BOTANIK",
                    "otomasyon_adi": "Botanik Eczane",
                    "urun_id": u_id,
                    "mal_id": u_id,
                    "mal_kodu": str(u_id),
                    "mal_adi": u_adi,
                    "barkod": final_barcode,
                    "stok": stok,
                    "stok_depo": int(stok_depo or 0),
                    "stok_raf": int(stok_raf or 0),
                    "stok_acik": int(stok_acik or 0),
                    "kalan_gun": kalan_gun,
                    "stok_status": stok_status,
                    "stok_status_color": stok_status_color,
                    "ort_aylik_cikis": ort_aylik,
                    "ort_gunluk_cikis": ort_gunluk,
                    "onerilen_siparis": onerilen_siparis,
                    "aylik_cikislar": aylik_cikislar,
                    "son_girisler": son_girisler,
                    "toplam_giren_kutu": toplam_giren_kutu,
                    "hareketsiz_kart": is_hareketsiz,
                    "hareketsiz_aciklama": "Eczanenizde bu ürün için son 6 aydır çıkış hareketi bulunmuyor. Depo ve piyasa koşulları doğrudan üretici EAN barkodu üzerinden sunulmaktadır."
                }

        except Exception as e:
            return {
                "found": False,
                "connected": False,
                "kaynak": "BOTANIK",
                "error": str(e),
                "message": f"Botanik stok ve hareket sorgusu hatası: {str(e)}"
            }

    def get_critical_stock_sales(self, limit: int = 0, max_stock_threshold: int = 5, max_stock_days: int = 21) -> List[Dict[str, Any]]:
        """
        Bugün eczaneden çıkışı olan (reçeteli veya nakit) ve stoğu azalan (veya kritik seviyedeki)
        ürünleri listeler. 21 günden fazla stok olan ürünleri mantıken sipariş listesine dahil etmez.
        """
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                
                # 1. Adım: Bugün çıkışı olan ürünleri ve adetlerini indeksli tarih filtresiyle çek (~10-15 ms)
                today_sql = """
                    SELECT UrunId, SUM(Adet) as BugunAdet FROM (
                        SELECT ri.RIUrunId as UrunId, ri.RIAdet as Adet
                        FROM ReceteIlaclari ri WITH (NOLOCK)
                        JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                        WHERE ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0 AND ra.RxKayitTarihi >= CONVERT(date, GETDATE())
                        UNION ALL
                        SELECT ei.RIUrunId as UrunId, ei.RIAdet as Adet
                        FROM EldenIlaclari ei WITH (NOLOCK)
                        JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                        WHERE ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0 AND ea.RxKayitTarihi >= CONVERT(date, GETDATE())
                    ) t GROUP BY UrunId
                """
                cur.execute(today_sql)
                today_rows = cur.fetchall()
                if not today_rows:
                    return []
                
                today_map = {r[0]: int(r[1] or 0) for r in today_rows if r[0]}
                urun_ids = list(today_map.keys())
                if not urun_ids:
                    return []

                # 2. Adım: Sadece bugün satılan ürünler için son 30 günün çıkışlarını çek (~80-100 ms)
                placeholders = ','.join('?' * len(urun_ids))
                month_sql = f"""
                    SELECT UrunId, SUM(Adet) as AyAdet FROM (
                        SELECT ri.RIUrunId as UrunId, ri.RIAdet as Adet
                        FROM ReceteIlaclari ri WITH (NOLOCK)
                        JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                        WHERE ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0 AND ra.RxKayitTarihi >= DATEADD(day, -30, GETDATE())
                          AND ri.RIUrunId IN ({placeholders})
                        UNION ALL
                        SELECT ei.RIUrunId as UrunId, ei.RIAdet as Adet
                        FROM EldenIlaclari ei WITH (NOLOCK)
                        JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                        WHERE ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0 AND ea.RxKayitTarihi >= DATEADD(day, -30, GETDATE())
                          AND ei.RIUrunId IN ({placeholders})
                    ) t GROUP BY UrunId
                """
                cur.execute(month_sql, urun_ids + urun_ids)
                month_map = {r[0]: int(r[1] or 0) for r in cur.fetchall() if r[0]}

                # 3. Adım: İlgili ürünlerin stok ve fiyat bilgilerini çek
                urun_sql = f"""
                    SELECT 
                        u.UrunId, 
                        u.UrunAdi,
                        (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) as ToplamStok,
                        ISNULL(u.UrunFiyatEtiket, 0) as PSF
                    FROM Urun u WITH (NOLOCK)
                    WHERE u.UrunId IN ({placeholders}) AND ISNULL(u.UrunSilme, 0) = 0
                """
                cur.execute(urun_sql, urun_ids)
                urun_rows = cur.fetchall()

                # 4. Adım: Barkodları çek (BarkodSilme NULL/0 öncelikli, gerçek EAN'lar öncelikli)
                barkod_sql = f"""
                    SELECT BarkodUrunId, BarkodAdi FROM Barkod WITH (NOLOCK)
                    WHERE BarkodUrunId IN ({placeholders}) AND BarkodAdi IS NOT NULL AND BarkodAdi <> ''
                    ORDER BY 
                        ISNULL(BarkodSilme, 0) ASC,
                        CASE WHEN BarkodAdi LIKE '3%' OR BarkodAdi LIKE '4%' OR BarkodAdi LIKE '5%' OR BarkodAdi LIKE '84%' OR (LEN(BarkodAdi) = 13 AND BarkodAdi NOT LIKE '8690000%' AND BarkodAdi NOT LIKE '8699222%') THEN 1 ELSE 2 END,
                        BarkodId DESC
                """
                cur.execute(barkod_sql, urun_ids)
                barkod_map = {}
                for b_uid, b_adi in cur.fetchall():
                    if b_uid not in barkod_map and b_adi:
                        barkod_map[b_uid] = str(b_adi).strip()

                # Eksik barkodlar için FIBBarkodUrunId ve FaturaSatir'a bak
                missing_barkods = [uid for uid in urun_ids if uid not in barkod_map]
                if missing_barkods:
                    fb_placeholders = ','.join('?' * len(missing_barkods))
                    cur.execute(f"SELECT FBUrunId, FBBarkod FROM FIBBarkodUrunId WITH (NOLOCK) WHERE FBUrunId IN ({fb_placeholders}) AND ISNULL(Pasif, 0) = 0", missing_barkods)
                    for f_uid, f_barkod in cur.fetchall():
                        if f_uid not in barkod_map and f_barkod:
                            barkod_map[f_uid] = str(f_barkod).strip()

                missing_barkods = [uid for uid in urun_ids if uid not in barkod_map]
                if missing_barkods:
                    fs_placeholders = ','.join('?' * len(missing_barkods))
                    cur.execute(f"""
                        SELECT FSUrunId, FSBarkodAdi FROM FaturaSatir WITH (NOLOCK)
                        WHERE FSUrunId IN ({fs_placeholders}) AND FSBarkodAdi IS NOT NULL AND FSBarkodAdi <> ''
                        ORDER BY FSId DESC
                    """, missing_barkods)
                    for fs_uid, fs_barkod in cur.fetchall():
                        if fs_uid not in barkod_map and fs_barkod:
                            barkod_map[fs_uid] = str(fs_barkod).strip()

                # 5. Adım: Geçmişte MF'li Alım Kontrolü (FaturaSatir)
                mf_history_map = {}
                try:
                    mf_sql = f"""
                        SELECT FSUrunId, FSUrunAdet, FSUrunMf, Tarih, AlimCount
                        FROM (
                            SELECT 
                                fs.FSUrunId,
                                fs.FSUrunAdet,
                                fs.FSUrunMf,
                                CONVERT(varchar(10), fg.FGFaturaTarihi, 120) as Tarih,
                                COUNT(*) OVER (PARTITION BY fs.FSUrunId) as AlimCount,
                                ROW_NUMBER() OVER (PARTITION BY fs.FSUrunId ORDER BY fg.FGFaturaTarihi DESC, fg.FGId DESC) as RN
                            FROM FaturaSatir fs WITH (NOLOCK)
                            JOIN FaturaGiris fg WITH (NOLOCK) ON fs.FSFGId = fg.FGId
                            WHERE fs.FSUrunId IN ({placeholders})
                              AND ISNULL(fg.FGSilme, 0) = 0
                              AND ISNULL(fs.FSUrunMf, 0) > 0
                        ) t WHERE RN = 1
                    """
                    cur.execute(mf_sql, urun_ids)
                    for r in cur.fetchall():
                        u_id = r[0]
                        m_adet = int(r[1] or 0)
                        m_mf = int(r[2] or 0)
                        raw_date = str(r[3] or '')
                        if raw_date and '-' in raw_date:
                            parts = raw_date.split('-')
                            fmt_date = f"{parts[2]}.{parts[1]}.{parts[0]}" if len(parts) == 3 else raw_date
                        else:
                            fmt_date = raw_date
                        alim_count = int(r[4] or 1)

                        mf_kisa = f"Son: {m_adet}+{m_mf} MF" if m_adet > 0 else f"Son: +{m_mf} MF"
                        mf_bilgi = f"Geçmişte {alim_count} kez MF ile alındı (Son Alım: {m_adet}+{m_mf} MF, {fmt_date})"

                        mf_history_map[u_id] = {
                            "var": True,
                            "sayisi": alim_count,
                            "son_adet": m_adet,
                            "son_mf": m_mf,
                            "son_tarih": fmt_date,
                            "kisa": mf_kisa,
                            "bilgi": mf_bilgi
                        }
                except Exception as e_mf:
                    print(f"[Botanik] Geçmiş MF sorgu uyarısı: {e_mf}")

                # Birleştirme ve Akıllı Sıralama
                candidate_items = []
                for u_id, u_adi, stok, psf in urun_rows:
                    stok_val = int(stok or 0)
                    bugun_val = today_map.get(u_id, 0)
                    ay_val = month_map.get(u_id, 0)
                    psf_val = round(float(psf or 0.0), 2)
                    raw_barkod = barkod_map.get(u_id, '')
                    barkod_val = raw_barkod

                    # EAN Çözümleme: Eğer Botanik dahili/uydurma/bozuk barkod vermişse, doğrudan gerçek üretici EAN'a dönüştür
                    try:
                        from backend.catalog import catalog
                        canonical_bc = catalog.resolve_canonical_barcode(raw_barkod)
                        if canonical_bc:
                            barkod_val = canonical_bc
                        if (
                            not barkod_val
                            or len(barkod_val) < 12
                            or not barkod_val.isdigit()
                            or barkod_val.startswith(("0", "8869", "8690000", "8699999", "8699222", "9999"))
                        ) and u_adi:
                            by_name = catalog.find_canonical_barcodes_by_name(u_adi, exclude_barcode=raw_barkod)
                            if by_name:
                                barkod_val = by_name[0]
                    except Exception:
                        pass

                    # Kalan stok gün hesabı ve 21 gün kuralı
                    effective_aylik = max(int(ay_val or 0), int(bugun_val or 1))
                    gunluk_ort = max(0.1, round(effective_aylik / 30.0, 2))
                    stok_gun = round((stok_val * 30.0) / effective_aylik, 1) if stok_val > 0 else 0.0

                    # 21 Günden fazla stok varsa mantıken sipariş listesine dahil etme
                    if max_stock_days > 0 and stok_val > 0 and stok_gun > max_stock_days:
                        continue

                    # Günlük ortalama ve ihtiyaç tahmini
                    onerilen = max(bugun_val, int(gunluk_ort * 7) - max(0, stok_val))
                    if onerilen <= 0:
                        onerilen = max(1, bugun_val)

                    mf_hist = mf_history_map.get(u_id, {})
                    has_past_mf = bool(mf_hist.get("var", False))

                    candidate_items.append({
                        "urun_id": u_id,
                        "mal_kodu": str(u_id),
                        "urun_adi": u_adi,
                        "barkod": barkod_val,
                        "raw_barkod": raw_barkod,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": ay_val,
                        "psf": psf_val,
                        "onerilen_siparis": max(1, onerilen),
                        "gecmis_mf_var": has_past_mf,
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", "")
                    })

                # Akıllı Sıralama: Önce eksiye düşenler (stok < 0), sonra tükenenler (stok == 0), sonra kalan stok gününe göre artan
                candidate_items.sort(key=lambda x: (
                    0 if x["stok"] < 0 else (1 if x["stok"] == 0 else 2),
                    x["stok"] if x["stok"] < 0 else x["stok_gun"],
                    -x["bugun_cikis"]
                ))

                if limit and limit > 0:
                    return candidate_items[:limit]
                return candidate_items
        except Exception as e:
            print(f"[Botanik] get_critical_stock_sales hatası: {e}")
            return []

    def get_six_month_smart_order_list(
        self,
        scope: str = "today",
        search_query: str = "",
        target_days: int = 15,
        limit: int = 250
    ) -> Dict[str, Any]:
        """
        Botanik MS SQL veritabanından toplu sipariş ve 6 aylık çıkış analizi için:
        - Son 6 takvim ayının ay-ay çıkış sayılarını (Reçeteli + Elden),
        - Günlük ve aylık ortalama çıkış hızını,
        - Trend ve istikrar analizini (STABİL ÇIKAN, ÇIKIŞI AZALAN, ÇIKIŞI ARTAN, ARALIKLI),
        - Hedef gün sayısına göre (örn. 7, 15, 30 gün) akıllı sipariş miktarı önerisini,
        - Geçmiş fatura MF bilgilerini ve anlık raf stoğunu
        tek seferde yüksek hızla (~250 ms) döndürür.
        """
        import math
        t0 = time.time()
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                # Son 6 takvim ayının anahtarlarını (YYYYMM) hazırla
                ay_kisa = {
                    1: "Oca", 2: "Şub", 3: "Mar", 4: "Nis",
                    5: "May", 6: "Haz", 7: "Tem", 8: "Ağu",
                    9: "Eyl", 10: "Eki", 11: "Kas", 12: "Ara"
                }
                today = datetime.date.today()
                months_meta = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    ym_int = y_calc * 100 + m_calc
                    ym_str = f"{y_calc}-{m_calc:02d}"
                    short_lbl = ay_kisa.get(m_calc, str(m_calc))
                    lbl = f"{short_lbl} '{str(y_calc)[-2:]}"
                    months_meta.append({
                        "ym_int": ym_int,
                        "ym": ym_str,
                        "short": short_lbl,
                        "label": lbl,
                        "is_current": (i == 0)
                    })

                start_ym = months_meta[0]["ym_int"]
                start_date_str = f"{start_ym // 100}-{start_ym % 100:02d}-01"

                # 1. Hedef Ürün ID'lerini ve Bugünkü Çıkışları Belirle
                cur.execute("""
                    SELECT UrunId, SUM(Adet) as BugunAdet FROM (
                        SELECT ri.RIUrunId as UrunId, ri.RIAdet as Adet
                        FROM ReceteIlaclari ri WITH (NOLOCK)
                        JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                        WHERE ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0 AND ra.RxKayitTarihi >= CONVERT(date, GETDATE())
                        UNION ALL
                        SELECT ei.RIUrunId as UrunId, ei.RIAdet as Adet
                        FROM EldenIlaclari ei WITH (NOLOCK)
                        JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                        WHERE ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0 AND ea.RxKayitTarihi >= CONVERT(date, GETDATE())
                    ) t GROUP BY UrunId
                """)
                today_map = {r[0]: int(r[1] or 0) for r in cur.fetchall() if r[0]}

                clean_q = (search_query or "").strip()
                scope_norm = (scope or "today").strip().lower()
                if clean_q:
                    tr_q = clean_q.replace("i", "İ").replace("ı", "I").upper()
                    cur.execute(f"""
                        SELECT TOP {int(limit or 100)} u.UrunId
                        FROM Urun u WITH (NOLOCK)
                        WHERE ISNULL(u.UrunSilme, 0) = 0
                          AND (
                              u.UrunAdi LIKE ? OR u.UrunAdi LIKE ?
                              OR u.UrunId IN (SELECT b.BarkodUrunId FROM Barkod b WITH (NOLOCK) WHERE b.BarkodAdi LIKE ?)
                          )
                        ORDER BY (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) DESC, u.UrunId DESC
                    """, (f"%{clean_q}%", f"%{tr_q}%", f"%{clean_q}%"))
                    urun_ids = [r[0] for r in cur.fetchall() if r[0]]
                elif scope_norm in ("week", "days_7"):
                    cur.execute(f"""
                        SELECT TOP {int(limit or 250)} UrunId, SUM(Adet) as YediGunAdet FROM (
                            SELECT ri.RIUrunId as UrunId, ri.RIAdet as Adet
                            FROM ReceteIlaclari ri WITH (NOLOCK)
                            JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                            WHERE ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0 AND ra.RxKayitTarihi >= DATEADD(day, -7, GETDATE())
                            UNION ALL
                            SELECT ei.RIUrunId as UrunId, ei.RIAdet as Adet
                            FROM EldenIlaclari ei WITH (NOLOCK)
                            JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                            WHERE ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0 AND ea.RxKayitTarihi >= DATEADD(day, -7, GETDATE())
                        ) t WHERE UrunId IS NOT NULL GROUP BY UrunId ORDER BY SUM(Adet) DESC
                    """)
                    urun_ids = [r[0] for r in cur.fetchall() if r[0]]
                elif scope_norm in ("top6m", "top_6m"):
                    cur.execute(f"""
                        SELECT TOP {int(limit or 250)} UrunId, SUM(Adet) as Top6MAdet FROM (
                            SELECT ri.RIUrunId as UrunId, ri.RIAdet as Adet
                            FROM ReceteIlaclari ri WITH (NOLOCK)
                            JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                            WHERE ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0 AND ra.RxKayitTarihi >= ?
                            UNION ALL
                            SELECT ei.RIUrunId as UrunId, ei.RIAdet as Adet
                            FROM EldenIlaclari ei WITH (NOLOCK)
                            JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                            WHERE ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0 AND ea.RxKayitTarihi >= ?
                        ) t WHERE UrunId IS NOT NULL GROUP BY UrunId ORDER BY SUM(Adet) DESC
                    """, (start_date_str, start_date_str))
                    urun_ids = [r[0] for r in cur.fetchall() if r[0]]
                else:
                    # Varsayılan: Bugün çıkışı olan ürünler (Eğer bugün henüz çıkış yoksa son 3 günün çıkışlarını getir)
                    urun_ids = list(today_map.keys())
                    if not urun_ids:
                        cur.execute(f"""
                            SELECT TOP {int(limit or 200)} UrunId FROM (
                                SELECT ri.RIUrunId as UrunId, ri.RIAdet as Adet
                                FROM ReceteIlaclari ri WITH (NOLOCK)
                                JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                                WHERE ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0 AND ra.RxKayitTarihi >= DATEADD(day, -3, GETDATE())
                                UNION ALL
                                SELECT ei.RIUrunId as UrunId, ei.RIAdet as Adet
                                FROM EldenIlaclari ei WITH (NOLOCK)
                                JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                                WHERE ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0 AND ea.RxKayitTarihi >= DATEADD(day, -3, GETDATE())
                            ) t WHERE UrunId IS NOT NULL GROUP BY UrunId ORDER BY SUM(Adet) DESC
                        """)
                        urun_ids = [r[0] for r in cur.fetchall() if r[0]]

                if not urun_ids:
                    return {
                        "success": True,
                        "scope": scope,
                        "months": months_meta,
                        "items": [],
                        "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
                    }

                if limit and len(urun_ids) > limit:
                    urun_ids = urun_ids[:limit]

                placeholders = ",".join("?" * len(urun_ids))

                # 2. Son 6 Ayın Ay-Ay Reçeteli ve Nakit Çıkış Dağılımını Çek
                monthly_sql = f"""
                    SELECT UrunId, YM, SUM(Adet) as TopAdet, SUM(ReceteAdet) as RecAdet, SUM(NakitAdet) as NakAdet FROM (
                        SELECT ri.RIUrunId as UrunId, (YEAR(ra.RxKayitTarihi)*100 + MONTH(ra.RxKayitTarihi)) as YM,
                               ri.RIAdet as Adet, ri.RIAdet as ReceteAdet, 0 as NakitAdet
                        FROM ReceteIlaclari ri WITH (NOLOCK)
                        JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                        WHERE ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0
                          AND ra.RxKayitTarihi >= ?
                          AND ri.RIUrunId IN ({placeholders})
                        UNION ALL
                        SELECT ei.RIUrunId as UrunId, (YEAR(ea.RxKayitTarihi)*100 + MONTH(ea.RxKayitTarihi)) as YM,
                               ei.RIAdet as Adet, 0 as ReceteAdet, ei.RIAdet as NakitAdet
                        FROM EldenIlaclari ei WITH (NOLOCK)
                        JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                        WHERE ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0
                          AND ea.RxKayitTarihi >= ?
                          AND ei.RIUrunId IN ({placeholders})
                    ) m GROUP BY UrunId, YM
                """
                cur.execute(monthly_sql, [start_date_str, *urun_ids, start_date_str, *urun_ids])
                per_item_months: Dict[int, Dict[int, Dict[str, int]]] = {}
                for r_uid, r_ym, r_top, r_rec, r_nak in cur.fetchall():
                    if not r_uid or not r_ym:
                        continue
                    per_item_months.setdefault(int(r_uid), {})[int(r_ym)] = {
                        "toplam": int(r_top or 0),
                        "receteli": int(r_rec or 0),
                        "nakit": int(r_nak or 0)
                    }

                # 3. Son 30 Günün Çıkışlarını Çek (Trend ve güncel hız doğruluğu için)
                cur.execute(f"""
                    SELECT UrunId, SUM(Adet) as AyAdet FROM (
                        SELECT ri.RIUrunId as UrunId, ri.RIAdet as Adet
                        FROM ReceteIlaclari ri WITH (NOLOCK)
                        JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                        WHERE ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0 AND ra.RxKayitTarihi >= DATEADD(day, -30, GETDATE())
                          AND ri.RIUrunId IN ({placeholders})
                        UNION ALL
                        SELECT ei.RIUrunId as UrunId, ei.RIAdet as Adet
                        FROM EldenIlaclari ei WITH (NOLOCK)
                        JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                        WHERE ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0 AND ea.RxKayitTarihi >= DATEADD(day, -30, GETDATE())
                          AND ei.RIUrunId IN ({placeholders})
                    ) t GROUP BY UrunId
                """, urun_ids + urun_ids)
                last30_map = {int(r[0]): int(r[1] or 0) for r in cur.fetchall() if r[0]}

                # 4. Ürün Stok & Etiket Fiyatı
                cur.execute(f"""
                    SELECT u.UrunId, u.UrunAdi,
                           (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) as ToplamStok,
                           ISNULL(u.UrunFiyatEtiket, 0) as PSF
                    FROM Urun u WITH (NOLOCK)
                    WHERE u.UrunId IN ({placeholders}) AND ISNULL(u.UrunSilme, 0) = 0
                """, urun_ids)
                urun_rows = cur.fetchall()

                # 5. Barkod Çözümleme
                cur.execute(f"""
                    SELECT BarkodUrunId, BarkodAdi FROM Barkod WITH (NOLOCK)
                    WHERE BarkodUrunId IN ({placeholders}) AND BarkodAdi IS NOT NULL AND BarkodAdi <> ''
                    ORDER BY
                        ISNULL(BarkodSilme, 0) ASC,
                        CASE WHEN BarkodAdi LIKE '3%' OR BarkodAdi LIKE '4%' OR BarkodAdi LIKE '5%' OR BarkodAdi LIKE '84%' OR (LEN(BarkodAdi) = 13 AND BarkodAdi NOT LIKE '8690000%' AND BarkodAdi NOT LIKE '8699222%') THEN 1 ELSE 2 END,
                        BarkodId DESC
                """, urun_ids)
                barkod_map = {}
                for b_uid, b_adi in cur.fetchall():
                    if b_uid not in barkod_map and b_adi:
                        barkod_map[b_uid] = str(b_adi).strip()

                missing_bcs = [uid for uid in urun_ids if uid not in barkod_map]
                if missing_bcs:
                    fb_ph = ",".join("?" * len(missing_bcs))
                    cur.execute(f"SELECT FBUrunId, FBBarkod FROM FIBBarkodUrunId WITH (NOLOCK) WHERE FBUrunId IN ({fb_ph}) AND ISNULL(Pasif, 0) = 0", missing_bcs)
                    for f_uid, f_bc in cur.fetchall():
                        if f_uid not in barkod_map and f_bc:
                            barkod_map[f_uid] = str(f_bc).strip()

                # 6. Geçmiş Fatura MF Bilgisi
                mf_history_map = {}
                try:
                    cur.execute(f"""
                        SELECT FSUrunId, FSUrunAdet, FSUrunMf, Tarih, AlimCount, DepoAdi
                        FROM (
                            SELECT
                                fs.FSUrunId,
                                fs.FSUrunAdet,
                                fs.FSUrunMf,
                                CONVERT(varchar(10), fg.FGFaturaTarihi, 120) as Tarih,
                                ISNULL(d.DepoAdi, '') as DepoAdi,
                                COUNT(*) OVER (PARTITION BY fs.FSUrunId) as AlimCount,
                                ROW_NUMBER() OVER (PARTITION BY fs.FSUrunId ORDER BY fg.FGFaturaTarihi DESC, fg.FGId DESC) as RN
                            FROM FaturaSatir fs WITH (NOLOCK)
                            JOIN FaturaGiris fg WITH (NOLOCK) ON fs.FSFGId = fg.FGId
                            LEFT JOIN Depo d WITH (NOLOCK) ON fg.FGIlgiliId = d.DepoId
                            WHERE fs.FSUrunId IN ({placeholders})
                              AND ISNULL(fg.FGSilme, 0) = 0
                              AND ISNULL(fs.FSUrunMf, 0) > 0
                        ) t WHERE RN = 1
                    """, urun_ids)
                    for r in cur.fetchall():
                        uid_m = int(r[0])
                        m_adet = int(r[1] or 0)
                        m_mf = int(r[2] or 0)
                        raw_dt = str(r[3] or "")
                        if raw_dt and "-" in raw_dt:
                            pts = raw_dt.split("-")
                            fmt_dt = f"{pts[2]}.{pts[1]}.{pts[0]}" if len(pts) == 3 else raw_dt
                        else:
                            fmt_dt = raw_dt
                        cnt = int(r[4] or 1)
                        depo_adi = str(r[5] or "").strip()
                        mf_kisa = f"{m_adet}+{m_mf}" if m_adet > 0 else f"+{m_mf}"
                        mf_history_map[uid_m] = {
                            "var": True,
                            "sayisi": cnt,
                            "son_adet": m_adet,
                            "son_mf": m_mf,
                            "son_tarih": fmt_dt,
                            "son_depo": depo_adi,
                            "kisa": mf_kisa,
                            "bilgi": f"Geçmişte {cnt} kez MF'li alındı (Son: {mf_kisa} MF, {fmt_dt})"
                        }
                except Exception:
                    pass

                # 7. Her Ürün İçin 6 Aylık Trend, Stabilite ve Hedef Günlük Sipariş Hesabı
                items = []
                stabil_count = 0
                azalan_count = 0
                artan_count = 0
                tukenen_count = 0

                target_days_clean = max(1, int(target_days or 15))

                for u_id, u_adi, stok_raw, psf_raw in urun_rows:
                    u_id = int(u_id)
                    stok_val = int(stok_raw or 0)
                    psf_val = round(float(psf_raw or 0.0), 2)
                    bugun_val = int(today_map.get(u_id, 0))
                    son30_val = int(last30_map.get(u_id, 0))
                    raw_bc = barkod_map.get(u_id, "")
                    bc_val = raw_bc
                    try:
                        from backend.catalog import catalog
                        can_bc = catalog.resolve_canonical_barcode(raw_bc)
                        if can_bc:
                            bc_val = can_bc
                        if (
                            not bc_val
                            or len(bc_val) < 12
                            or not bc_val.isdigit()
                            or bc_val.startswith(("0", "8869", "8690000", "8699999", "8699222", "9999"))
                        ) and u_adi:
                            by_name = catalog.find_canonical_barcodes_by_name(u_adi, exclude_barcode=raw_bc)
                            if by_name:
                                bc_val = by_name[0]
                    except Exception:
                        pass

                    m_dict = per_item_months.get(u_id, {})
                    aylik_detay = []
                    toplam_6ay = 0
                    toplam_6ay_recete = 0
                    toplam_6ay_nakit = 0
                    aktif_ay_sayisi = 0

                    for m_meta in months_meta:
                        ym_i = m_meta["ym_int"]
                        cell = m_dict.get(ym_i, {"toplam": 0, "receteli": 0, "nakit": 0})
                        c_top = cell["toplam"]
                        c_rec = cell["receteli"]
                        c_nak = cell["nakit"]
                        toplam_6ay += c_top
                        toplam_6ay_recete += c_rec
                        toplam_6ay_nakit += c_nak
                        if c_top > 0:
                            aktif_ay_sayisi += 1
                        aylik_detay.append({
                            "ym": m_meta["ym"],
                            "short": m_meta["short"],
                            "label": m_meta["label"],
                            "is_current": m_meta["is_current"],
                            "toplam": c_top,
                            "receteli": c_rec,
                            "recete": c_rec,
                            "nakit": c_nak
                        })

                    # Geçmiş 5 tam ay ve önceki 4 ay ortalaması
                    m_vals = [x["toplam"] for x in aylik_detay]
                    gecmis_5_toplam = sum(m_vals[:5])
                    ort_aylik_6m = round(gecmis_5_toplam / 5.0, 1) if gecmis_5_toplam > 0 else round(toplam_6ay / 6.0, 1)

                    onceki_4_ort = sum(m_vals[:4]) / 4.0
                    gecen_ay_val = m_vals[4] if len(m_vals) >= 5 else 0
                    son_donem_hiz = round((gecen_ay_val + son30_val) / 2.0, 1) if gecen_ay_val > 0 else float(son30_val)

                    # Trend ve İstikrar Analizi
                    degisim_yuzde = 0
                    if onceki_4_ort >= 1.5:
                        degisim_yuzde = int(round(((son_donem_hiz - onceki_4_ort) / onceki_4_ort) * 100))

                    if onceki_4_ort >= 2.0 and son_donem_hiz < onceki_4_ort * 0.65:
                        trend_kodu = "AZALAN"
                        trend_etiket = f"📉 Çıkışı Azalan (%{abs(degisim_yuzde)}↓)"
                        trend_renk = "amber"
                        trend_uyari = f"Son dönemde çıkış hızı {onceki_4_ort:.1f}/ay'dan {son_donem_hiz:.1f}/ay'a geriledi. Yüksek stok bağlamayın."
                        azalan_count += 1
                    elif onceki_4_ort >= 1.5 and son_donem_hiz > onceki_4_ort * 1.35 and son_donem_hiz >= 3.0:
                        trend_kodu = "ARTAN"
                        trend_etiket = f"📈 Çıkışı Artan (+%{abs(degisim_yuzde)}↑)"
                        trend_renk = "sky"
                        trend_uyari = f"Son dönemde talep hızlandı ({onceki_4_ort:.1f} → {son_donem_hiz:.1f}/ay). Güvenli stok tutun."
                        artan_count += 1
                    elif aktif_ay_sayisi >= 4 and toplam_6ay >= 5:
                        trend_kodu = "STABIL"
                        trend_etiket = f"🟢 Stabil Çıkan ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "emerald"
                        trend_uyari = f"Her ay düzenli satıyor (Ort. {ort_aylik_6m:.1f} kt/ay). MF baremli alıma uygun."
                        stabil_count += 1
                    else:
                        trend_kodu = "DUZENSIZ"
                        trend_etiket = f"⚡ Aralıklı ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "slate"
                        trend_uyari = f"Son 6 ayın {aktif_ay_sayisi} ayında çıkış yaptı (Toplam {toplam_6ay} kt). İhtiyaç kadar alın."

                    if stok_val <= 0:
                        tukenen_count += 1

                    # Günlük tahmini çıkış hızı (Azalan ürünlerde son dönem düşük hızı baz al, stabil/artanlarda etkin hızı baz al)
                    if trend_kodu == "AZALAN":
                        etkin_aylik_hiz = max(0.5, min(ort_aylik_6m, max(1.0, son_donem_hiz)))
                    elif trend_kodu == "ARTAN":
                        etkin_aylik_hiz = max(ort_aylik_6m, son_donem_hiz, float(bugun_val))
                    else:
                        etkin_aylik_hiz = max(ort_aylik_6m, float(son30_val), float(bugun_val))

                    gunluk_hiz = round(max(0.05, etkin_aylik_hiz / 30.0), 2)
                    stok_gun = round(stok_val / gunluk_hiz, 1) if stok_val > 0 else 0.0

                    # Hedef güne göre önerilen sipariş
                    hedef_kutu = math.ceil(gunluk_hiz * target_days_clean)
                    if trend_kodu == "AZALAN":
                        # Çıkışı azalan üründe aşırı siparişi otomatik sınırla (maks 10 günlük ihtiyaç veya bugünkü çıkış)
                        kisitli_hedef = math.ceil(gunluk_hiz * min(target_days_clean, 10))
                        onerilen = max(0, kisitli_hedef - max(0, stok_val))
                        if stok_val <= 0:
                            onerilen = max(1, min(bugun_val or 1, 2))
                    else:
                        onerilen = max(0, hedef_kutu - max(0, stok_val))
                        if stok_val <= 0 and onerilen <= 0:
                            onerilen = max(1, bugun_val or 1)

                    mf_hist = mf_history_map.get(u_id, {})

                    # Akıllı Öneri Metni
                    if trend_kodu == "AZALAN":
                        oneri_metni = f"⚠️ Çıkışı azaldığı için {target_days_clean} gün yerine kısa vadeli ({max(1, onerilen)} kt) önerildi."
                    elif trend_kodu == "STABIL" and mf_hist.get("var"):
                        oneri_metni = f"💡 Düzenli çıkıyor ({ort_aylik_6m:.1f}/ay). Geçmişte {mf_hist.get('kisa')} MF ile alındı; MF baremi avantajlı!"
                    elif trend_kodu == "STABIL":
                        oneri_metni = f"✅ Stabil ürün ({ort_aylik_6m:.1f}/ay). {target_days_clean} günlük stok hedefi için {max(1, onerilen)} kt uygun."
                    elif trend_kodu == "ARTAN":
                        oneri_metni = f"🚀 Çıkış hızı artıyor ({son_donem_hiz:.1f}/ay). Stoksuz kalmamak için {max(1, onerilen)} kt önerilir."
                    else:
                        oneri_metni = f"📦 Aralıklı çıkış ({toplam_6ay} kt / 6 ay). Minimum stok ({max(1, onerilen)} kt) tutun."

                    items.append({
                        "urun_id": u_id,
                        "mal_kodu": str(u_id),
                        "urun_kodu": str(u_id),
                        "urun_adi": u_adi,
                        "barkod": bc_val,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "psf": psf_val,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": son30_val,
                        "toplam_6ay": toplam_6ay,
                        "toplam_6ay_recete": toplam_6ay_recete,
                        "toplam_6ay_nakit": toplam_6ay_nakit,
                        "ort_aylik_6m": ort_aylik_6m,
                        "onceki_4_ort": round(onceki_4_ort, 1),
                        "ilk4_ort": round(onceki_4_ort, 1),
                        "son_donem_hiz": round(son_donem_hiz, 1),
                        "son2_ort": round(son_donem_hiz, 1),
                        "gunluk_hiz": gunluk_hiz,
                        "aktif_ay_sayisi": aktif_ay_sayisi,
                        "aylik_detay": aylik_detay,
                        "trend_kodu": trend_kodu,
                        "trend_etiket": trend_etiket,
                        "trend_renk": trend_renk,
                        "trend_uyari": trend_uyari,
                        "degisim_yuzde": degisim_yuzde,
                        "onerilen_siparis": max(1, onerilen) if (stok_val <= 0 or bugun_val > 0 or onerilen > 0) else 0,
                        "ham_ihtiyac": max(0, hedef_kutu - max(0, stok_val)),
                        "oneri_metni": oneri_metni,
                        "gecmis_mf_var": bool(mf_hist.get("var", False)),
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_min_alim": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_bedelsiz": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_son_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", "")
                    })

                # Sıralama: Önce stoğu tükenen ve bugün çıkanlar, sonra 6 aylık toplam çıkışı yüksek olanlar
                items.sort(key=lambda x: (
                    0 if (x["stok"] <= 0 and x["bugun_cikis"] > 0) else (1 if x["bugun_cikis"] > 0 else 2),
                    x["stok_gun"],
                    -x["toplam_6ay"]
                ))

                return {
                    "success": True,
                    "scope": scope,
                    "target_days": target_days_clean,
                    "elapsed_ms": round((time.time() - t0) * 1000, 1),
                    "months": months_meta,
                    "items": items,
                    "stats": {
                        "total_items": len(items),
                        "stabil_count": stabil_count,
                        "azalan_count": azalan_count,
                        "artan_count": artan_count,
                        "tukenen_count": tukenen_count
                    }
                }
        except Exception as e:
            print(f"[Botanik] get_six_month_smart_order_list hatası: {e}")
            return {
                "success": False,
                "error": str(e),
                "months": [],
                "items": [],
                "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
            }

    def get_product_vat(self, barcode_or_code: str) -> Optional[float]:
        """Ürünün Botanik veritabanındaki resmi KDV oranını (KDV tablosundan) döner."""
        q = str(barcode_or_code or "").strip()
        if not q:
            return None
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                if q.isdigit() and len(q) < 8:
                    cur.execute("""
                        SELECT TOP 1 ISNULL(k.KDVOran, 10.0)
                        FROM Urun u WITH (NOLOCK)
                        LEFT JOIN KDV k WITH (NOLOCK) ON u.UrunKDVId = k.KDVId
                        WHERE u.UrunId = ? AND ISNULL(u.UrunSilme, 0) = 0
                    """, (int(q),))
                    row = cur.fetchone()
                    if row and row[0] is not None:
                        return float(row[0])

                bc_set = {q}
                if q.isdigit() and len(q) >= 8:
                    try:
                        from backend.catalog import catalog
                        can = catalog.resolve_canonical_barcode(q)
                        if can:
                            bc_set.add(can)
                    except Exception:
                        pass
                bc_list = list(bc_set)
                placeholders = ",".join("?" for _ in bc_list)

                cur.execute(f"""
                    SELECT TOP 1 ISNULL(k.KDVOran, 10.0)
                    FROM Urun u WITH (NOLOCK)
                    LEFT JOIN KDV k WITH (NOLOCK) ON u.UrunKDVId = k.KDVId
                    WHERE ISNULL(u.UrunSilme, 0) = 0
                      AND u.UrunId IN (
                          SELECT b.BarkodUrunId FROM Barkod b WITH (NOLOCK) WHERE b.BarkodAdi IN ({placeholders})
                          UNION
                          SELECT fib.FBUrunId FROM FIBBarkodUrunId fib WITH (NOLOCK) WHERE fib.FBBarkod IN ({placeholders}) AND ISNULL(fib.Pasif, 0) = 0
                          UNION
                          SELECT fs.FSUrunId FROM FaturaSatir fs WITH (NOLOCK) WHERE fs.FSBarkodAdi IN ({placeholders})
                      )
                    ORDER BY (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) DESC,
                             ISNULL(u.UrunAktif, 0) DESC,
                             u.UrunId DESC
                """, (*bc_list, *bc_list, *bc_list))
                row = cur.fetchone()
                if row and row[0] is not None:
                    return float(row[0])
        except Exception as e:
            print(f"[Botanik] get_product_vat hatası: {e}")
        return None

    def get_product_equivalents(self, barcode_or_code: str) -> Dict[str, Any]:
        """Botanik veritabanındaki eşdeğer ilaçları (UrunEsdegerId + Etkin + kârlılık ve stok verileriyle) listeler."""
        q = str(barcode_or_code or "").strip()
        if not q:
            return {"found": False, "esdeger_kodu": None, "muadiller": []}

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                target_row = None

                # 1. Barkod ile ara (Kanonik EAN ve ilişkili barkodlar dahil)
                if q.isdigit() and len(q) >= 8:
                    bc_set = {q}
                    try:
                        from backend.catalog import catalog
                        can = catalog.resolve_canonical_barcode(q)
                        if can:
                            bc_set.add(can)
                        cat_p = catalog.get_by_barcode(q)
                        if cat_p:
                            for ab in cat_p.get("all_barcodes", []):
                                if str(ab).strip():
                                    bc_set.add(str(ab).strip())
                    except Exception:
                        pass
                    bc_list = list(bc_set)
                    placeholders = ",".join("?" for _ in bc_list)
                    cur.execute(f"""
                        SELECT TOP 1 
                            u.UrunId, 
                            u.UrunAdi, 
                            ISNULL(u.UrunEsdegerId, 0) AS EsdegerId,
                            ISNULL(u.UrunAmbalajMiktari, 0) AS AmbalajMiktari,
                            ISNULL(e.EtkinKodu, '') AS EtkinKodu
                        FROM Urun u WITH (NOLOCK)
                        LEFT JOIN Etkin e WITH (NOLOCK) ON u.UrunSGKKodId = e.EtkinId
                        WHERE ISNULL(u.UrunSilme, 0) = 0
                          AND u.UrunId IN (
                              SELECT b.BarkodUrunId FROM Barkod b WITH (NOLOCK) WHERE b.BarkodAdi IN ({placeholders})
                              UNION
                              SELECT fib.FBUrunId FROM FIBBarkodUrunId fib WITH (NOLOCK) WHERE fib.FBBarkod IN ({placeholders}) AND ISNULL(fib.Pasif, 0) = 0
                              UNION
                              SELECT fs.FSUrunId FROM FaturaSatir fs WITH (NOLOCK) WHERE fs.FSBarkodAdi IN ({placeholders})
                          )
                        ORDER BY 
                            CASE WHEN ISNULL(u.UrunEsdegerId, 0) > 0 THEN 0 ELSE 1 END,
                            (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) DESC,
                            ISNULL(u.UrunAktif, 0) DESC,
                            u.UrunId DESC
                    """, (*bc_list, *bc_list, *bc_list))
                    target_row = cur.fetchone()

                # 2. UrunId ile ara
                if not target_row and q.isdigit():
                    cur.execute("""
                        SELECT TOP 1 
                            u.UrunId, 
                            u.UrunAdi, 
                            ISNULL(u.UrunEsdegerId, 0) AS EsdegerId,
                            ISNULL(u.UrunAmbalajMiktari, 0) AS AmbalajMiktari,
                            ISNULL(e.EtkinKodu, '') AS EtkinKodu
                        FROM Urun u WITH (NOLOCK)
                        LEFT JOIN Etkin e WITH (NOLOCK) ON u.UrunSGKKodId = e.EtkinId
                        WHERE u.UrunId = ? AND ISNULL(u.UrunSilme, 0) = 0
                    """, (int(q),))
                    target_row = cur.fetchone()

                # 3. İsim ile ara
                if not target_row:
                    tr_q = q.replace("i", "İ").replace("ı", "I").upper()
                    cur.execute("""
                        SELECT TOP 1 
                            u.UrunId, 
                            u.UrunAdi, 
                            ISNULL(u.UrunEsdegerId, 0) AS EsdegerId,
                            ISNULL(u.UrunAmbalajMiktari, 0) AS AmbalajMiktari,
                            ISNULL(e.EtkinKodu, '') AS EtkinKodu
                        FROM Urun u WITH (NOLOCK)
                        LEFT JOIN Etkin e WITH (NOLOCK) ON u.UrunSGKKodId = e.EtkinId
                        WHERE (u.UrunAdi LIKE ? OR u.UrunAdi LIKE ?)
                          AND ISNULL(u.UrunSilme, 0) = 0
                        ORDER BY 
                            CASE WHEN ISNULL(u.UrunEsdegerId, 0) > 0 THEN 0 ELSE 1 END,
                            (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) DESC,
                            ISNULL(u.UrunAktif, 0) DESC,
                            u.UrunId DESC
                    """, (f"%{q}%", f"%{tr_q}%"))
                    target_row = cur.fetchone()

                if not target_row or int(target_row[2] or 0) <= 0:
                    return {"found": False, "esdeger_kodu": None, "muadiller": [], "message": "Eşdeğer grubu bulunamadı."}

                u_id = int(target_row[0])
                u_adi = str(target_row[1] or "")
                esdeger_id = int(target_row[2])
                ambalaj_mik = float(target_row[3] or 0.0)
                etkin_kodu = str(target_row[4] or "").strip()
                esdeger_kodu_str = etkin_kodu if etkin_kodu else f"EQ{esdeger_id}"

                # Aynı eşdeğer gruptaki aktif veya stoklu ürünleri çek
                cur.execute("""
                    SELECT 
                        u.UrunId,
                        u.UrunAdi,
                        (
                            SELECT TOP 1 b2.BarkodAdi FROM Barkod b2 WITH (NOLOCK)
                            WHERE b2.BarkodUrunId = u.UrunId AND b2.BarkodAdi IS NOT NULL AND b2.BarkodAdi <> ''
                            ORDER BY ISNULL(b2.BarkodSilme, 0) ASC,
                                     CASE WHEN LEN(b2.BarkodAdi) = 13 AND b2.BarkodAdi NOT LIKE '8690000%' AND b2.BarkodAdi NOT LIKE '8699222%' THEN 0 ELSE 1 END,
                                     b2.BarkodId DESC
                        ) AS Barkod,
                        ISNULL(u.UrunFiyatEtiket, 0) AS PSF,
                        ISNULL(u.UrunFiyatKamu, 0) AS KSF,
                        ISNULL(u.UrunIskontoKamu, 0) AS KamuIskonto,
                        ISNULL(u.UrunIskontoEczane, 0) AS EczaneIskonto,
                        ISNULL(u.UrunIskontoTicari, 0) AS TicariIskonto,
                        ISNULL(k.KDVOran, 10.0) AS KDVOran,
                        (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) AS Stok,
                        (
                            SELECT ISNULL(SUM(s.Adet), 0) FROM (
                                SELECT ri.RIAdet as Adet
                                FROM ReceteIlaclari ri WITH (NOLOCK)
                                JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                                WHERE ri.RIUrunId = u.UrunId AND ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0 AND ra.RxKayitTarihi >= DATEADD(day, -30, GETDATE())
                                UNION ALL
                                SELECT ei.RIAdet as Adet
                                FROM EldenIlaclari ei WITH (NOLOCK)
                                JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                                WHERE ei.RIUrunId = u.UrunId AND ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0 AND ea.RxKayitTarihi >= DATEADD(day, -30, GETDATE())
                            ) s
                        ) AS Cikis30,
                        ISNULL(u.UrunAmbalajMiktari, 0) AS AmbalajMiktari
                    FROM Urun u WITH (NOLOCK)
                    LEFT JOIN KDV k WITH (NOLOCK) ON u.UrunKDVId = k.KDVId
                    WHERE u.UrunEsdegerId = ?
                      AND ISNULL(u.UrunSilme, 0) = 0
                      AND (
                          ISNULL(u.UrunAktif, 0) = 1
                          OR (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) > 0
                          OR u.UrunId = ?
                      )
                    ORDER BY Stok DESC, ISNULL(u.UrunAktif, 0) DESC, u.UrunId DESC
                """, (esdeger_id, u_id))
                all_rows = cur.fetchall()

                # Eğer hedef ilacın ambalaj miktarı belli ise (örn: 14 TB vs 10 TB veya 20 TB vs 30 TB)
                # ve aynı ambalaj miktarında eşdeğerler mevcutsa, ambalaj miktarına göre filtrele:
                if ambalaj_mik > 0:
                    same_pack_rows = [
                        r for r in all_rows
                        if abs(float(r[11] or 0.0) - ambalaj_mik) < 0.01 or int(r[0]) == u_id
                    ]
                    if len(same_pack_rows) >= 2:
                        all_rows = same_pack_rows

                # Geçmiş MF bilgisini toplu çek
                eq_urun_ids = [int(r[0]) for r in all_rows]
                mf_map = {}
                if eq_urun_ids:
                    eq_placeholders = ",".join("?" for _ in eq_urun_ids)
                    try:
                        cur.execute(f"""
                            SELECT FSUrunId, FSUrunAdet, FSUrunMf, Tarih, AlimCount
                            FROM (
                                SELECT 
                                    fs.FSUrunId,
                                    fs.FSUrunAdet,
                                    fs.FSUrunMf,
                                    CONVERT(varchar(10), fg.FGFaturaTarihi, 120) as Tarih,
                                    COUNT(*) OVER (PARTITION BY fs.FSUrunId) as AlimCount,
                                    ROW_NUMBER() OVER (PARTITION BY fs.FSUrunId ORDER BY fg.FGFaturaTarihi DESC, fg.FGId DESC) as RN
                                FROM FaturaSatir fs WITH (NOLOCK)
                                JOIN FaturaGiris fg WITH (NOLOCK) ON fs.FSFGId = fg.FGId
                                WHERE fs.FSUrunId IN ({eq_placeholders})
                                  AND ISNULL(fg.FGSilme, 0) = 0
                                  AND ISNULL(fs.FSUrunMf, 0) > 0
                            ) t WHERE RN = 1
                        """, eq_urun_ids)
                        for mr in cur.fetchall():
                            m_uid = int(mr[0])
                            m_adet = int(mr[1] or 0)
                            m_mf = int(mr[2] or 0)
                            raw_date = str(mr[3] or "")
                            if raw_date and "-" in raw_date:
                                parts = raw_date.split("-")
                                fmt_date = f"{parts[2]}.{parts[1]}.{parts[0]}" if len(parts) == 3 else raw_date
                            else:
                                fmt_date = raw_date
                            m_cnt = int(mr[4] or 1)
                            mf_map[m_uid] = {
                                "bilgi": f"Geçmişte {m_cnt} kez MF ile alındı (Son: {m_adet}+{m_mf} MF, {fmt_date})",
                                "kisa": f"{m_adet}+{m_mf}" if (m_adet > 0 and m_mf > 0) else "",
                                "adet": m_adet,
                                "mf": m_mf,
                                "tarih": fmt_date,
                                "sayisi": m_cnt
                            }
                    except Exception:
                        pass

                items = []
                current_kamu_kari = 0.0
                for row in all_rows:
                    r_uid = int(row[0])
                    r_name = str(row[1] or "").strip()
                    r_bc = str(row[2] or r_uid).strip()
                    try:
                        from backend.catalog import catalog
                        can_bc = catalog.resolve_canonical_barcode(r_bc)
                        if can_bc:
                            r_bc = can_bc
                    except Exception:
                        pass
                    psf = round(float(row[3] or 0.0), 2)
                    ksf_raw = round(float(row[4] or 0.0), 2)
                    kamu_isk = round(float(row[5] or 0.0), 2)
                    ecz_isk = round(float(row[6] or 0.0), 2)
                    tic_isk = round(float(row[7] or 0.0), 2)
                    kdv_oran = float(row[8] or 10.0)
                    stok = int(row[9] or 0)
                    cikis_30 = int(row[10] or 0)

                    # KSF (Kamu Satış Fiyatı) ve Depocu/Maliyet hesabı
                    if ksf_raw > 0:
                        ksf = ksf_raw
                        if kamu_isk <= 0.0 and psf > ksf > 0:
                            kamu_isk = round((1.0 - (ksf / psf)) * 100.0, 2)
                    else:
                        ksf = round(psf * (1.0 - (kamu_isk / 100.0)), 2) if psf > 0 else 0.0

                    # Eczacı alış maliyeti (KDV Hariç ve KDV Dahil yaklaşık standart hesap)
                    psf_kdvsiz = psf / (1.0 + (kdv_oran / 100.0)) if psf > 0 else 0.0
                    dsf_kdvsiz = psf_kdvsiz * 0.71 * (1.0 - (kamu_isk / 100.0)) * (1.0 - (tic_isk / 100.0))
                    net_maliyet_kdvsiz = round(dsf_kdvsiz, 2)
                    net_maliyet_kdvli = round(dsf_kdvsiz * (1.0 + (kdv_oran / 100.0)), 2)

                    kamu_kari = round(max(0.0, ksf - net_maliyet_kdvli), 2) if ksf > 0 else 0.0
                    perakende_kari = round(max(0.0, psf - net_maliyet_kdvli), 2) if psf > 0 else 0.0

                    is_curr = (r_uid == u_id)
                    if is_curr:
                        current_kamu_kari = kamu_kari

                    mf_obj = mf_map.get(r_uid) or {}
                    mf_bilgi = mf_obj.get("bilgi", "") if isinstance(mf_obj, dict) else str(mf_obj)
                    mf_kisa = mf_obj.get("kisa", "") if isinstance(mf_obj, dict) else ""
                    items.append({
                        "kod": str(r_uid),
                        "mal_kodu": str(r_uid),
                        "ad": r_name,
                        "urun_adi": r_name,
                        "barkod": r_bc,
                        "psf": psf,
                        "ksf": ksf,
                        "kamu_fiyati": ksf,
                        "kamu_iskontosu": kamu_isk,
                        "kdv_orani": kdv_oran,
                        "net_birim_maliyet": net_maliyet_kdvsiz,
                        "birim_maliyet": net_maliyet_kdvsiz,
                        "net_birim_maliyet_kdvli": net_maliyet_kdvli,
                        "birim_maliyet_kdvli": net_maliyet_kdvli,
                        "kamu_kari": kamu_kari,
                        "perakende_kari": perakende_kari,
                        "stok": stok,
                        "cikis_30gun": cikis_30,
                        "gecmis_mf_var": bool(mf_bilgi),
                        "gecmis_mf_bilgi": mf_bilgi,
                        "gecmis_mf_kisa": mf_kisa,
                        "is_current": is_curr
                    })

                # Kâr farklarını ve en avantajlı muadili hesapla
                for it in items:
                    kf = round(it["kamu_kari"] - current_kamu_kari, 2)
                    it["kar_farki"] = kf
                    it["is_more_profitable"] = (kf > 0)
                    it["kar_artis_yuzdesi"] = round((kf / current_kamu_kari * 100.0), 1) if (current_kamu_kari > 0 and kf > 0) else 0.0

                items.sort(key=lambda x: (x.get("kamu_kari") or 0.0, x.get("stok") or 0), reverse=True)

                en_karli = None
                muadil_kar_avantaji = 0.0
                for it in items:
                    if it.get("kar_farki", 0.0) > 0 and not it.get("is_current"):
                        it["is_best_deal"] = True
                        en_karli = it
                        muadil_kar_avantaji = it["kar_farki"]
                        break

                return {
                    "found": True,
                    "esdeger_kodu": esdeger_kodu_str,
                    "count": len(items),
                    "en_karli_muadil": en_karli,
                    "muadil_kar_avantaji": muadil_kar_avantaji,
                    "current_kamu_kari": current_kamu_kari,
                    "muadiller": items
                }
        except Exception as e:
            print(f"[Botanik] get_product_equivalents hatası: {e}")
            return {"found": False, "error": str(e), "esdeger_kodu": None, "muadiller": []}

    def get_bulk_stock_and_sales_map(self, barcodes: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Verilen barkod listesi için Botanik EOS veritabanından tek seferde (toplu/bulk)
        anlık eczane stoğu, son 1 aylık (30 gün) çıkış ve son 3 aylık (90 gün) çıkış
        sayılarını döndürür.
        """
        result: Dict[str, Dict[str, Any]] = {}
        clean_inputs = [str(b or "").strip() for b in (barcodes or []) if str(b or "").strip()]
        if not clean_inputs:
            return result

        # Her giriş barkodunu 13/14 hane varyantları ve katalog kardeş barkodlarıyla genişlet
        variant_to_originals: Dict[str, set] = {}
        for orig_bc in clean_inputs:
            result[orig_bc] = {"stok": 0, "cikis_1ay": 0, "cikis_3ay": 0, "found": False}
            variants = {orig_bc}
            if orig_bc.isdigit():
                if len(orig_bc) == 13:
                    variants.add("0" + orig_bc)
                elif len(orig_bc) == 14 and orig_bc.startswith("0"):
                    variants.add(orig_bc[1:])
            try:
                from backend.catalog import catalog
                c_item = catalog.get_by_barcode(orig_bc)
                if c_item:
                    if c_item.get("barcode"):
                        variants.add(str(c_item["barcode"]).strip())
                    for ab in (c_item.get("all_barcodes") or []):
                        if str(ab).strip():
                            variants.add(str(ab).strip())
            except Exception:
                pass
            for v in variants:
                if v:
                    variant_to_originals.setdefault(v, set()).add(orig_bc)

        all_variants = list(variant_to_originals.keys())
        if not all_variants:
            return result

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                uid_to_originals: Dict[int, set] = {}

                # MS SQL 2100 parametre limitine takılmamak için 400'lük bloklar halinde sorgula
                chunk_size = 400
                for i in range(0, len(all_variants), chunk_size):
                    chunk = all_variants[i:i + chunk_size]
                    ph = ",".join(["?"] * len(chunk))
                    cur.execute(f"""
                        SELECT b.BarkodAdi, b.BarkodUrunId
                        FROM Barkod b WITH (NOLOCK)
                        WHERE b.BarkodAdi IN ({ph})
                          AND b.BarkodUrunId IS NOT NULL
                    """, tuple(chunk))
                    for row in cur.fetchall():
                        b_str = str(row[0] or "").strip()
                        u_id = int(row[1] or 0)
                        if u_id > 0 and b_str in variant_to_originals:
                            uid_to_originals.setdefault(u_id, set()).update(variant_to_originals[b_str])

                    try:
                        cur.execute(f"""
                            SELECT fib.FBBarkod, fib.FBUrunId
                            FROM FIBBarkodUrunId fib WITH (NOLOCK)
                            WHERE fib.FBBarkod IN ({ph})
                              AND ISNULL(fib.Pasif, 0) = 0
                              AND fib.FBUrunId IS NOT NULL
                        """, tuple(chunk))
                        for row in cur.fetchall():
                            b_str = str(row[0] or "").strip()
                            u_id = int(row[1] or 0)
                            if u_id > 0 and b_str in variant_to_originals:
                                uid_to_originals.setdefault(u_id, set()).update(variant_to_originals[b_str])
                    except Exception:
                        pass

                all_uids = list(uid_to_originals.keys())
                if not all_uids:
                    return result

                uid_stock: Dict[int, int] = {}
                uid_c30: Dict[int, int] = {}
                uid_c90: Dict[int, int] = {}
                active_uids: set = set()

                for i in range(0, len(all_uids), chunk_size):
                    u_chunk = all_uids[i:i + chunk_size]
                    ph = ",".join(["?"] * len(u_chunk))

                    # 1. Anlık Stok
                    cur.execute(f"""
                        SELECT u.UrunId,
                               (ISNULL(u.UrunStokDepo, 0) + ISNULL(u.UrunStokRaf, 0) + ISNULL(u.UrunStokAcik, 0)) AS ToplamStok
                        FROM Urun u WITH (NOLOCK)
                        WHERE u.UrunId IN ({ph})
                          AND ISNULL(u.UrunSilme, 0) = 0
                    """, tuple(u_chunk))
                    for row in cur.fetchall():
                        u_id = int(row[0] or 0)
                        active_uids.add(u_id)
                        uid_stock[u_id] = int(row[1] or 0)

                    # 2. Reçeteli Çıkışlar (Son 30 ve 90 gün)
                    cur.execute(f"""
                        SELECT ri.RIUrunId,
                               SUM(CASE WHEN ra.RxKayitTarihi >= DATEADD(day, -30, GETDATE()) THEN ISNULL(ri.RIAdet, 0) ELSE 0 END) AS C30,
                               SUM(CASE WHEN ra.RxKayitTarihi >= DATEADD(day, -90, GETDATE()) THEN ISNULL(ri.RIAdet, 0) ELSE 0 END) AS C90
                        FROM ReceteIlaclari ri WITH (NOLOCK)
                        JOIN ReceteAna ra WITH (NOLOCK) ON ri.RIRxId = ra.RxId
                        WHERE ri.RIUrunId IN ({ph})
                          AND ISNULL(ra.RxSilme, 0) = 0 AND ISNULL(ri.RISilme, 0) = 0
                          AND ra.RxKayitTarihi >= DATEADD(day, -90, GETDATE())
                        GROUP BY ri.RIUrunId
                    """, tuple(u_chunk))
                    for row in cur.fetchall():
                        u_id = int(row[0] or 0)
                        uid_c30[u_id] = uid_c30.get(u_id, 0) + int(row[1] or 0)
                        uid_c90[u_id] = uid_c90.get(u_id, 0) + int(row[2] or 0)

                    # 3. Elden / Nakit Çıkışlar (Son 30 ve 90 gün)
                    cur.execute(f"""
                        SELECT ei.RIUrunId,
                               SUM(CASE WHEN ea.RxKayitTarihi >= DATEADD(day, -30, GETDATE()) THEN ISNULL(ei.RIAdet, 0) ELSE 0 END) AS C30,
                               SUM(CASE WHEN ea.RxKayitTarihi >= DATEADD(day, -90, GETDATE()) THEN ISNULL(ei.RIAdet, 0) ELSE 0 END) AS C90
                        FROM EldenIlaclari ei WITH (NOLOCK)
                        JOIN EldenAna ea WITH (NOLOCK) ON ei.RIRxId = ea.RxId
                        WHERE ei.RIUrunId IN ({ph})
                          AND ISNULL(ea.RxSilme, 0) = 0 AND ISNULL(ei.RISilme, 0) = 0
                          AND ea.RxKayitTarihi >= DATEADD(day, -90, GETDATE())
                        GROUP BY ei.RIUrunId
                    """, tuple(u_chunk))
                    for row in cur.fetchall():
                        u_id = int(row[0] or 0)
                        uid_c30[u_id] = uid_c30.get(u_id, 0) + int(row[1] or 0)
                        uid_c90[u_id] = uid_c90.get(u_id, 0) + int(row[2] or 0)

                # Orijinal barkodlara göre birleştir
                orig_to_uids: Dict[str, set] = {}
                for u_id, origs in uid_to_originals.items():
                    if u_id in active_uids:
                        for obc in origs:
                            orig_to_uids.setdefault(obc, set()).add(u_id)

                for obc, uids in orig_to_uids.items():
                    tot_stok = sum(uid_stock.get(u, 0) for u in uids)
                    tot_c30 = sum(uid_c30.get(u, 0) for u in uids)
                    tot_c90 = sum(uid_c90.get(u, 0) for u in uids)
                    result[obc] = {
                        "stok": int(tot_stok),
                        "cikis_1ay": int(tot_c30),
                        "cikis_3ay": int(tot_c90),
                        "found": True,
                    }

        except Exception as e:
            print(f"[Botanik] get_bulk_stock_and_sales_map hatası: {e}")

        return result

# Singleton instance
botanik_client = BotanikSQLClient()
