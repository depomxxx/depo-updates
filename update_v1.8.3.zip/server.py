# -*- coding: utf-8 -*-
"""
server.py
---------
Farma Radar — Eczane Depo Şart & Net Maliyet Karşılaştırma Sistemi
Ana Sunucu Giriş Noktası (Modüler Mimari v2.1)

Tüm alt modüller `backend/` dizini altında düzenli parçalara ayrılmıştır:
- `backend/config_manager.py`         : .env ve depo/otomasyon şifre yönetimi
- `backend/app_state.py`              : Paylaşılan motor ve önbellek durumu
- `backend/routers/system_routes.py`  : Durum, ayarlar, lisans ve canlı güncelleme API'leri
- `backend/routers/search_routes.py`  : Katalog, ilaç arama ve piyasa kıyaslama API'leri
- `backend/routers/otomasyon_routes.py`: Botanik/Tria/Tebeos, günün çıkışları, 6 aylık analiz ve muadil API'leri
- `backend/routers/cart_routes.py`    : Sepet, sipariş sonlandırma ve ortak sipariş/verilmeyecek takibi API'leri
- `backend/ui/`                       : Modüler HTML Arayüzü ve JavaScript bileşenleri
"""

import asyncio
import os
import sys
import time
from pathlib import Path
from typing import Optional

# Ensure script directory is always at the very front of sys.path
_script_dir = str(Path(__file__).resolve().parent)
if _script_dir in sys.path:
    sys.path.remove(_script_dir)
sys.path.insert(0, _script_dir)

# Ensure process runs as Tria.exe on Windows so TriaWinService.exe never kills Oracle sessions (ORA-00028 / DPY-4011)
if __name__ == "__main__" and sys.platform == "win32" and os.environ.get("TRIA_EXE_REEXEC") != "1":
    _exe_name = os.path.basename(sys.executable).lower()
    if _exe_name in ("python.exe", "pythonw.exe"):
        import shutil
        import subprocess
        _exe_dir = Path(sys.executable).resolve().parent
        _target_name = "TriaPcPOS.exe" if _exe_name == "pythonw.exe" else "Tria.exe"
        _tria_exe = _exe_dir / _target_name
        if not _tria_exe.exists():
            try:
                shutil.copy2(sys.executable, _tria_exe)
            except Exception:
                pass
        if not _tria_exe.exists():
            _rt_tria = Path(__file__).resolve().parent / "runtime" / "Tria.exe"
            if _rt_tria.exists():
                _tria_exe = _rt_tria
        if _tria_exe.exists():
            _env = os.environ.copy()
            _env["TRIA_EXE_REEXEC"] = "1"
            _cflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
            subprocess.Popen(
                [str(_tria_exe), *sys.argv],
                cwd=str(Path(__file__).resolve().parent),
                env=_env,
                creationflags=_cflags,
                close_fds=True
            )
            os._exit(0)

# Ensure UTF-8 and valid stdout/stderr handles on Windows (including pythonw / detached mode)
if sys.platform == "win32":
    _log_path = Path(__file__).resolve().parent / "server.log"
    try:
        if sys.stdout is None or not hasattr(sys.stdout, "write"):
            sys.stdout = open(_log_path, "a", encoding="utf-8", buffering=1)
        else:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            sys.stdout.write("")
    except Exception:
        sys.stdout = open(_log_path, "a", encoding="utf-8", buffering=1)
    try:
        if sys.stderr is None or not hasattr(sys.stderr, "write"):
            sys.stderr = sys.stdout
        else:
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
            sys.stderr.write("")
    except Exception:
        sys.stderr = sys.stdout

from backend.config_manager import load_env, get_current_credentials, save_credentials_to_env
load_env()

# Auto-configure PLAYWRIGHT_BROWSERS_PATH if bundled in runtime/playwright-browsers
_base_dir = Path(__file__).resolve().parent
_bundled_browsers = _base_dir / "runtime" / "playwright-browsers"
if _bundled_browsers.exists():
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(_bundled_browsers)

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

import backend.app_state as app_state
from backend.query_engine import DepoSorguMotoru
from backend.models import DepoKodu
from backend.tria_client import tria_client
from backend.botanik_client import botanik_client
from backend.tebeos_client import tebeos_client
from backend.mf_resolver import mf_resolver
from backend.updater import updater
from backend.license_manager import license_manager
from backend.routers import system_router, search_router, otomasyon_router, cart_router
from backend.routers.system_routes import trigger_delayed_server_restart

# Eski sürümlerden kalmış olabilecek tekil backend/ui.py dosyasını temizle ki modüler backend/ui/ paketi yüklensin
try:
    _legacy_ui_file = _base_dir / "backend" / "ui.py"
    _mod_ui_init = _base_dir / "backend" / "ui" / "__init__.py"
    if _legacy_ui_file.is_file() and _mod_ui_init.is_file():
        _legacy_ui_file.unlink()
except Exception:
    pass

from backend.ui import get_main_ui_html

app = FastAPI(title="Eczane Depo Şart & Maliyet Karşılaştırma", version="2.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Kurumsal Lisans Kısıtlama & İlk Kurulum Kilidi Middleware'i
_LICENSE_RESTRICTED_PATHS = (
    "/api/search",
    "/api/market/",
    "/api/eczanetakas/",
    "/api/eczatrend/",
    "/api/portal/",
    "/api/orders/today/check-yok-list",
    "/api/cart/add",
    "/api/cart/bulk-add",
    "/api/cart/cascade-bulk-add",
    "/api/cart/quick-finalize-check",
    "/api/cart/finalize",
    "/api/cart/bulk-finalize-check",
    "/api/cart/bulk-finalize-clean-submit",
    "/api/otomasyon/smart-order-list",
    "/api/botanik/smart-order-list",
    "/api/otomasyon/resolve-mf",
)


@app.middleware("http")
async def license_enforcement_middleware(request: Request, call_next):
    path = request.url.path
    if path.startswith("/api/") and not path.startswith(("/api/license/", "/api/version", "/api/update/", "/api/releases/", "/api/status", "/api/server/", "/api/system/")):
        is_protected = any(path == p or path.startswith(p) for p in _LICENSE_RESTRICTED_PATHS)
        if is_protected or path.startswith("/api/otomasyon/critical-stock"):
            allowed, lic_st = await asyncio.to_thread(license_manager.is_feature_allowed)
            if not allowed:
                is_unactivated = bool(lic_st.get("unactivated", False))
                # İlk kurulumda (anahtar girilmemişse) tüm korumalı + kritik stok uç noktalarını kapat;
                # Süre dolumu veya ASKIDA durumunda ise 4 ana özelliği (Depo Sorgu, Sepete Ekleme, Toplu Sipariş, MF Asistanı) kısıtla.
                if is_unactivated or is_protected:
                    msg = lic_st.get("message") or (
                        "Lisans süreniz dolmuş veya yönetici tarafından kısıtlanmıştır. "
                        "Depo Sorgulama, Sepete Ekleme, Toplu Sipariş ve MF Asistanı özellikleri devre dışıdır."
                    )
                    return JSONResponse(
                        status_code=403,
                        content={
                            "success": False,
                            "valid": False,
                            "license_restricted": True,
                            "unactivated": is_unactivated,
                            "status": lic_st.get("status", "ASKIDA"),
                            "expires_at": lic_st.get("expires_at", "-"),
                            "days_left": lic_st.get("days_left", 0),
                            "pharmacy_name": lic_st.get("pharmacy_name", ""),
                            "error": msg,
                            "message": msg,
                            "items": [],
                            "results": {}
                        }
                    )
            else:
                try:
                    if path.startswith(("/api/search", "/api/stream-search")):
                        license_manager.record_activity("search", "Depo Fiyat Sorgulama")
                    elif path.startswith("/api/cart/"):
                        license_manager.record_activity("cart", "Sepete Ürün / Sipariş Aktarımı")
                    elif path.startswith(("/api/otomasyon/smart-order-list", "/api/botanik/smart-order-list")):
                        license_manager.record_activity("smart_order", "Toplu Sipariş Planlama")
                    elif path.startswith("/api/otomasyon/critical-stock"):
                        license_manager.record_activity("critical_stock", "Günün Çıkışları / Kritik Stok")
                    elif path.startswith("/api/otomasyon/resolve-mf"):
                        license_manager.record_activity("mf_resolve", "Canlı MF Taraması")
                except Exception:
                    pass
    return await call_next(request)

# Modüler API Router'larını kaydet
app.include_router(system_router)
app.include_router(search_router)
app.include_router(otomasyon_router)
app.include_router(cart_router)


def _refresh_desktop_shortcut_icons() -> dict:
    """Masaüstündeki tüm Farma Radar / Eczane Depo / Eda Depo kısayol ikonlarını yeni yüksek çözünürlüklü farma_radar.ico ile anında günceller."""
    report = {"success": False, "desktops": [], "updated": [], "all_shortcuts": []}
    if os.name != "nt":
        return report
    try:
        import json
        import shutil
        import socket
        import subprocess
        import ctypes

        base_dir = Path(__file__).resolve().parent
        src_ico = base_dir / "backend" / "ui" / "farma_radar.ico"
        if not src_ico.exists():
            return report
        dst_ico = base_dir / "farma_radar_v167.ico"
        try:
            shutil.copy2(src_ico, dst_ico)
        except Exception:
            dst_ico = src_ico

        admin_src_ico = base_dir / "backend" / "ui" / "farma_radar_admin.ico"
        admin_dst_ico = base_dir / "farma_radar_admin_v167.ico"
        if admin_src_ico.exists():
            try:
                shutil.copy2(admin_src_ico, admin_dst_ico)
            except Exception:
                admin_dst_ico = admin_src_ico

        # Eğer bu bilgisayarda Yönetici Lisans Paneli (license_admin_tool.py) varsa C:\EczaneDepoPro içine de senkronize et ve arka planda 8095 portunu hazır tut
        admin_tool_candidates = [
            base_dir / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "license_admin_tool.py",
            Path.home() / "OneDrive" / "Masaüstü" / "depoprogrami" / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "license_admin_tool.py",
            Path.home() / "Desktop" / "depoprogrami" / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "license_admin_tool.py",
            base_dir / "license_admin_tool.py",
        ]
        admin_tool_src = next((p for p in admin_tool_candidates if p.exists()), None)
        admin_tool_local = base_dir / "license_admin_tool.py"
        if admin_tool_src:
            try:
                if admin_tool_src.resolve() != admin_tool_local.resolve():
                    shutil.copy2(admin_tool_src, admin_tool_local)
            except Exception:
                pass
            # Port 8095 kapalıysa arka planda --no-browser ile başlat
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(0.3)
                    port_open = (s.connect_ex(("127.0.0.1", 8095)) == 0)
                if not port_open:
                    pyw = base_dir / "runtime" / "pythonw.exe"
                    if not pyw.exists():
                        pyw = Path(sys.executable)
                    cflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
                    subprocess.Popen(
                        [str(pyw), str(admin_tool_local if admin_tool_local.exists() else admin_tool_src), "--no-browser"],
                        cwd=str(base_dir),
                        creationflags=cflags,
                        close_fds=True
                    )
            except Exception:
                pass

        data_dir = base_dir / "data"
        data_dir.mkdir(parents=True, exist_ok=True)
        ps1_path = data_dir / "_refresh_icons.ps1"
        out_json_path = data_dir / "_refresh_icons_out.json"

        dst_ico_str = str(dst_ico).replace("'", "''")
        admin_ico_str = str(admin_dst_ico).replace("'", "''")
        base_dir_str = str(base_dir).replace("'", "''")
        out_json_str = str(out_json_path).replace("'", "''")
        admin_tool_str = str(admin_tool_local if admin_tool_local.exists() else (admin_tool_src or "")).replace("'", "''")

        ps_script = f"""$ErrorActionPreference = 'SilentlyContinue'
$WshShell = New-Object -ComObject WScript.Shell
$Desktops = @(
    [Environment]::GetFolderPath('Desktop'),
    [Environment]::GetFolderPath('CommonDesktopDirectory'),
    (Join-Path $env:USERPROFILE 'Desktop'),
    (Join-Path $env:USERPROFILE 'Masaüstü'),
    (Join-Path $env:USERPROFILE 'OneDrive\\Masaüstü'),
    (Join-Path $env:USERPROFILE 'OneDrive\\Desktop')
) | Where-Object {{ $_ -and (Test-Path $_) }} | Select-Object -Unique

$UpdatedList = @()
$AllList = @()
$FoundMainShortcut = $false

foreach ($d in $Desktops) {{
    $lnks = Get-ChildItem -Path $d -Filter '*.lnk' -ErrorAction SilentlyContinue
    foreach ($f in $lnks) {{
        try {{
            $sc = $WshShell.CreateShortcut($f.FullName)
            $nm = $f.Name.ToLower()
            $tp = ($sc.TargetPath + ' ' + $sc.WorkingDirectory + ' ' + $sc.Arguments + ' ' + $sc.Description).ToLower()
            $AllList += [PSCustomObject]@{{
                name = $f.Name
                path = $f.FullName
                target = $sc.TargetPath
                args = $sc.Arguments
                icon = $sc.IconLocation
            }}

            if (($nm -match 'lisans|yönetici|yonetici') -or ($tp -match 'license_admin_tool|8095')) {{
                if (Test-Path '{admin_ico_str}') {{
                    $origTarget = $sc.TargetPath
                    $origArgs = $sc.Arguments
                    $origWd = $sc.WorkingDirectory
                    $origDesc = $sc.Description
                    if ('{admin_tool_str}' -ne '' -and (Test-Path '{admin_tool_str}')) {{
                        $pywCand = Join-Path '{base_dir_str}' 'runtime\\pythonw.exe'
                        if (Test-Path $pywCand) {{
                            $origTarget = $pywCand
                            $origArgs = '"' + '{admin_tool_str}' + '"'
                            $origWd = '{base_dir_str}'
                        }}
                    }}
                    Remove-Item -Path $f.FullName -Force -ErrorAction SilentlyContinue
                    $scNew = $WshShell.CreateShortcut($f.FullName)
                    $scNew.TargetPath = $origTarget
                    $scNew.Arguments = $origArgs
                    $scNew.WorkingDirectory = $origWd
                    $scNew.Description = $origDesc
                    $scNew.IconLocation = '{admin_ico_str},0'
                    $scNew.Save()
                    $UpdatedList += $f.FullName
                }}
            }} elseif (
                ($nm -notmatch 'botanik|medula|e-fatura|efatura|uzaktan|edaglobal|betaprim|ruya|rüya|alternet|chrome|edge|steam|antigravity') -and (
                    ($nm -match 'farma|radar|eczane depo|eda eczanesi|eda depo|eda_depo|depo sistemi|depo pro|depo program|tria depo') -or
                    ($tp -match 'eczanedepopro|eda_depo|depoprogrami|2_eda_depo|3_eda_depo|farma_radar|launcher\\.py|server\\.py|:8080')
                )
            ) {{
                $origTarget = $sc.TargetPath
                $origArgs = $sc.Arguments
                $origWd = $sc.WorkingDirectory
                $pywMain = Join-Path '{base_dir_str}' 'runtime\\pythonw.exe'
                $launcherPy = Join-Path '{base_dir_str}' 'launcher.py'
                if ((Test-Path $pywMain) -and (Test-Path $launcherPy) -and ($origTarget -match 'Eda_Depo\\.exe|Depo\\.exe|\\.bat$')) {{
                    $origTarget = $pywMain
                    $origArgs = '"' + $launcherPy + '"'
                    $origWd = '{base_dir_str}'
                }}
                Remove-Item -Path $f.FullName -Force -ErrorAction SilentlyContinue
                $scNew = $WshShell.CreateShortcut($f.FullName)
                $scNew.TargetPath = $origTarget
                $scNew.Arguments = $origArgs
                $scNew.WorkingDirectory = $origWd
                $scNew.WindowStyle = 7
                $scNew.Description = 'Farma Radar - Akıllı Depo & MF Karşılaştırma Sistemi'
                $scNew.IconLocation = '{dst_ico_str},0'
                $scNew.Save()
                $UpdatedList += $f.FullName
                $FoundMainShortcut = $true
            }}
        }} catch {{}}
    }}

    # Masaüstünde doğrudan .url (Internet Kısayolu) varsa ve 8080 / Farma Radar içeriyorsa ikonunu güncelle
    $urls = Get-ChildItem -Path $d -Filter '*.url' -ErrorAction SilentlyContinue
    foreach ($u in $urls) {{
        try {{
            $uContent = Get-Content -Path $u.FullName -Raw -ErrorAction SilentlyContinue
            $uName = $u.Name.ToLower()
            if (($uName -match 'farma|radar|eczane depo|eda depo|depo pro') -or ($uContent -match ':8080')) {{
                if ($uContent -notmatch 'IconFile=') {{
                    $uContent = $uContent.TrimEnd() + "`r`nIconFile={dst_ico_str}`r`nIconIndex=0`r`n"
                }} else {{
                    $uContent = [regex]::Replace($uContent, 'IconFile=.*', 'IconFile={dst_ico_str}')
                    if ($uContent -notmatch 'IconIndex=') {{
                        $uContent = $uContent.TrimEnd() + "`r`nIconIndex=0`r`n"
                    }}
                }}
                Set-Content -Path $u.FullName -Value $uContent -Encoding UTF8 -Force
                $UpdatedList += $u.FullName
                $FoundMainShortcut = $true
            }}
        }} catch {{}}
    }}
}}

# Eğer masaüstünde hiç Farma Radar kısayolu yoksa birincil masaüstüne otomatik oluştur
if (-not $FoundMainShortcut -and $Desktops.Count -gt 0) {{
    try {{
        $primaryDesk = $Desktops[0]
        $exeCand = Join-Path '{base_dir_str}' 'Eda_Depo.exe'
        if (-not (Test-Path $exeCand)) {{
            $exeCand = Join-Path '{base_dir_str}' '2_EDA_DEPO_BASLAT.bat'
        }}
        if (Test-Path $exeCand) {{
            $newLnk = Join-Path $primaryDesk 'Farma Radar.lnk'
            $scNew = $WshShell.CreateShortcut($newLnk)
            $scNew.TargetPath = $exeCand
            $scNew.WorkingDirectory = '{base_dir_str}'
            $scNew.Description = 'Farma Radar - Akıllı Depo & MF Karşılaştırma Sistemi'
            $scNew.IconLocation = '{dst_ico_str},0'
            $scNew.Save()
            $UpdatedList += $newLnk
        }}
    }} catch {{}}
}}

$OutObj = [PSCustomObject]@{{
    desktops = $Desktops
    updated = $UpdatedList
    all_shortcuts = $AllList
}}
$OutObj | ConvertTo-Json -Depth 4 | Set-Content -Path '{out_json_str}' -Encoding UTF8 -Force
"""
        ps1_path.write_text(ps_script, encoding="utf-8-sig")
        _no_win = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        _si = subprocess.STARTUPINFO()
        _si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        _si.wShowWindow = getattr(subprocess, "SW_HIDE", 0)
        subprocess.run(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", str(ps1_path)],
            creationflags=_no_win,
            startupinfo=_si,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=12
        )
        if out_json_path.exists():
            try:
                parsed = json.loads(out_json_path.read_text(encoding="utf-8-sig"))
                report["success"] = True
                report["desktops"] = parsed.get("desktops") or []
                report["updated"] = parsed.get("updated") or []
                report["all_shortcuts"] = parsed.get("all_shortcuts") or []
            except Exception:
                report["success"] = True

        try:
            ctypes.windll.shell32.SHChangeNotify(0x08000000, 0x0000, None, None)
        except Exception:
            pass
        for ie_arg in ("-ClearIconCache", "-show"):
            try:
                subprocess.Popen(
                    ["ie4uinit.exe", ie_arg],
                    creationflags=_no_win,
                    startupinfo=_si,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            except Exception:
                pass
    except Exception as e:
        report["error"] = str(e)
    return report


@app.on_event("startup")
async def startup_event():
    try:
        import threading
        threading.Thread(target=_refresh_desktop_shortcut_icons, daemon=True).start()
    except Exception:
        pass
    try:
        import threading
        import socket
        def _ensure_admin_crm_server():
            try:
                base_d = Path(__file__).resolve().parent
                cand = base_d / "license_admin_tool.py"
                if not cand.exists():
                    for p in (
                        base_d / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "license_admin_tool.py",
                        Path.home() / "OneDrive" / "Masaüstü" / "depoprogrami" / "ECZANE_DEPO_PRO_MERKEZ" / "2_GUNCELLEME_VE_LISANS_YONETIMI" / "license_admin_tool.py",
                    ):
                        if p.exists():
                            cand = p
                            break
                if not cand.exists():
                    return
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(0.3)
                    if s.connect_ex(("127.0.0.1", 8095)) == 0:
                        return
                import importlib.util
                spec = importlib.util.spec_from_file_location("license_admin_tool", str(cand))
                if spec and spec.loader:
                    mod = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(mod)
                    mod.init_crm_db()
                    srv = mod.ThreadedHTTPServer(("127.0.0.1", 8095), mod.AdminRequestHandler)
                    srv.serve_forever()
            except Exception:
                pass
        threading.Thread(target=_ensure_admin_crm_server, daemon=True).start()
    except Exception:
        pass
    try:
        license_manager.record_activity("heartbeat", "Program Açıldı (Canlı)", force_cloud=True)
    except Exception:
        pass
    app_state.motor = DepoSorguMotoru(headless=True)
    print(">> Depo Sorgu Motoru başlatıldı. Aktif depolar:", list(app_state.motor.adapters.keys()))

    _prewarm_done_event = asyncio.Event()

    async def _prewarm_single_depot(depo_kodu: DepoKodu, label: str):
        try:
            if app_state.motor and depo_kodu in app_state.motor.adapters:
                adp = app_state.motor.adapters[depo_kodu]
                await adp.login()
                if hasattr(adp, "_ensure_ready_page"):
                    await adp._ensure_ready_page()
                if hasattr(adp, "get_active_offers"):
                    try:
                        await adp.get_active_offers(force_refresh=True)
                    except Exception:
                        pass
                print(f">> [{label}] Arka plan hızlı sipariş ve katılım oturumu hazırlandı.")
        except Exception as e:
            print(f">> [{label}] Oturum ön-ısıtma uyarısı: {e}")

    async def _prewarm_all_depot_sessions():
        try:
            await asyncio.sleep(0.2)
            await asyncio.gather(
                _prewarm_single_depot(DepoKodu.SELCUK, "Selçuk"),
                _prewarm_single_depot(DepoKodu.NEVZAT, "Nevzat"),
                _prewarm_single_depot(DepoKodu.ALLIANCE, "Hedef (Alliance)"),
                _prewarm_single_depot(DepoKodu.ISKOOP, "İSKOOP"),
                _prewarm_single_depot(DepoKodu.ECZATREND, "Eczatrend"),
                _prewarm_single_depot(DepoKodu.ECZANETAKAS, "EczaneTakas"),
                return_exceptions=True
            )
        finally:
            _prewarm_done_event.set()

    async def _keep_alive_depot_sessions():
        """Tüm 6 depo ve takas platformu oturumunu gün boyu arka planda canlı tutar."""
        await _prewarm_done_event.wait()
        while True:
            await asyncio.sleep(480)  # 8 dakikada bir kontrol
            try:
                if not app_state.motor:
                    continue
                for dk, lbl in (
                    (DepoKodu.ECZANETAKAS, "EczaneTakas"),
                    (DepoKodu.ECZATREND, "Eczatrend"),
                    (DepoKodu.SELCUK, "Selçuk"),
                    (DepoKodu.NEVZAT, "Nevzat"),
                    (DepoKodu.ALLIANCE, "Hedef (Alliance)"),
                    (DepoKodu.ISKOOP, "İSKOOP"),
                ):
                    adp = app_state.motor.adapters.get(dk)
                    if not adp:
                        continue
                    try:
                        await adp.login()
                        if hasattr(adp, "get_active_offers"):
                            await adp.get_active_offers(force_refresh=True)
                    except Exception as ke:
                        print(f">> [{lbl}] Oturum yenileme uyarısı: {ke}")
            except Exception:
                pass

    asyncio.create_task(_prewarm_all_depot_sessions())
    asyncio.create_task(_keep_alive_depot_sessions())

    async def _prewarm_cache():
        try:
            await asyncio.sleep(0.5)
            active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
            items = []
            source_used = active_oto
            if active_oto == "TRIA":
                print(">> [Tria] Arka planda kritik stok ve günün çıkışları taranıyor...")
                try:
                    items = await asyncio.to_thread(tria_client.get_critical_stock_sales)
                except Exception as e:
                    print(f">> [Tria] Önbellek çekme uyarısı: {e}")
            elif active_oto == "TEBEOS":
                print(">> [TEBEOS] Arka planda kritik stok ve günün çıkışları taranıyor...")
                try:
                    items = await asyncio.to_thread(tebeos_client.get_critical_stock_sales)
                    source_used = "TEBEOS"
                except Exception as e:
                    print(f">> [TEBEOS] Bağlantı uyarısı: {e}")
                    items = []
            else:
                print(">> [Botanik] Arka planda kritik stok önbelleği ısıtılıyor...")
                try:
                    items = await asyncio.to_thread(botanik_client.get_critical_stock_sales)
                    source_used = "BOTANIK"
                except Exception as e:
                    print(f">> [Botanik] Bağlantı uyarısı: {e}")
                    items = []

            app_state.critical_stock_cache = {"time": time.time(), "data": items, "source": source_used}
            print(f">> [{source_used}] Kritik stok önbelleği hazır: {len(items)} kalem ürün yüklendi.")

            async def _sync_pharmacy_catalog_worker():
                try:
                    await asyncio.sleep(1.0)
                    from backend.catalog import catalog
                    for it in items:
                        bc = str(it.get("barkod") or "").strip()
                        st = it.get("mevcut_stok", 0)
                        if bc:
                            catalog.update_product_live_stock(bc, st, source_used)
                    print(f">> [{source_used}] Eczane veritabanı öncelik indeksi arka planda senkronize ediliyor...")
                    await asyncio.to_thread(catalog.sync_from_active_erp, source_used)
                except Exception as ce:
                    print(f">> [Catalog] Arka plan eczane indeksleme uyarısı: {ce}")

            asyncio.create_task(_sync_pharmacy_catalog_worker())

            async def _prewarm_mf_worker():
                try:
                    try:
                        await asyncio.wait_for(_prewarm_done_event.wait(), timeout=20.0)
                    except asyncio.TimeoutError:
                        pass
                    await asyncio.sleep(1.5)
                    top_barcodes = [str(x.get("barkod") or "").strip() for x in items[:35] if str(x.get("barkod") or "").strip()]
                    if top_barcodes and app_state.motor:
                        print(f">> [MF Motoru] İlk {len(top_barcodes)} azalan ürün için MF şartları arka planda taranıyor...")
                        await mf_resolver.resolve_batch(app_state.motor, top_barcodes, max_concurrency=4)
                        print(">> [MF Motoru] İlk parti MF şartları başarıyla önbelleğe alındı.")
                except Exception as e:
                    print(f">> [MF Motoru] Arka plan MF tarama uyarısı: {e}")

            asyncio.create_task(_prewarm_mf_worker())
        except Exception as e:
            print(f">> [Otomasyon] Önbellek ısıtma hatası: {e}")

    asyncio.create_task(_prewarm_cache())

    async def _auto_sync_active_dermo_worker():
        try:
            active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
            if active_oto != "BOTANIK":
                return
            await asyncio.sleep(2.0)
            from backend.dermo_sync import auto_sync_active_dermo_in_background
            print(">> [Taban Motoru] Botanik dermo ve OTC ürünleri arka planda taranıyor...")
            res = await asyncio.to_thread(auto_sync_active_dermo_in_background, 80)
            print(f">> [Taban Motoru] {res.get('message')}")
        except Exception as e:
            print(f">> [Taban Motoru] Arka plan eşleme notu: {e}")

    async def _live_auto_update_worker():
        """Arka planda GitHub Canlı Portalını ve LAN dağıtım sunucusunu periyodik denetler; yeni sürüm varsa canlı kurar."""
        await asyncio.sleep(10.0)
        while True:
            try:
                await asyncio.to_thread(license_manager.record_activity, "heartbeat", "Program Açık (Canlı)", False)
            except Exception:
                pass
            try:
                chk = await asyncio.to_thread(updater.check_for_updates, 8.0)
                if chk.get("update_available") and chk.get("download_url"):
                    if chk.get("auto_update", True) or chk.get("mandatory", False):
                        print(f">> [Canlı Güncelleme] Yeni sürüm tespit edildi: v{chk.get('latest_version')}. Otomatik kuruluyor...")
                        apply_res = await asyncio.to_thread(
                            updater.apply_update,
                            chk["download_url"],
                            chk.get("sha256", ""),
                            chk.get("latest_version", "")
                        )
                        if apply_res.get("success"):
                            print(f">> [Canlı Güncelleme] v{chk.get('latest_version')} başarıyla kuruldu, sunucu yeniden başlatılıyor...")
                            trigger_delayed_server_restart(1.5)
                            return
            except Exception as e:
                print(f">> [Canlı Güncelleme] Kontrol notu: {e}")
            await asyncio.sleep(90.0)

    asyncio.create_task(_auto_sync_active_dermo_worker())
    asyncio.create_task(_live_auto_update_worker())


@app.on_event("shutdown")
async def shutdown_event():
    if app_state.motor:
        await app_state.motor.close_all()
        print(">> Depo oturumları kapatıldı.")


def _start_background_auto_update_watcher():
    """Arka planda periyodik olarak hem yerel ağı (LAN) hem de GitHub portalını kontrol eder; yeni sürüm varsa otomatik günceller."""
    import threading
    def _watcher_loop():
        time.sleep(25)
        while True:
            try:
                vinfo = updater.get_local_version_info()
                if vinfo.get("auto_update", True):
                    chk = updater.check_for_updates(timeout=8.0)
                    if chk.get("update_available") and chk.get("download_url"):
                        dl_url = chk["download_url"]
                        sha = chk.get("sha256", "")
                        lat_ver = chk.get("latest_version", "")
                        print(f"[AUTO-UPDATE] Yeni sürüm tespit edildi: v{lat_ver} ({dl_url}) -> Otomatik kuruluyor...")
                        res = updater.apply_update(dl_url, sha, lat_ver)
                        if res.get("success"):
                            print(f"[AUTO-UPDATE] v{lat_ver} başarıyla kuruldu, sunucu yeniden başlatılıyor...")
                            trigger_delayed_server_restart(2.0)
                            return
            except Exception as e:
                print(f"[AUTO-UPDATE] Kontrol hatası: {e}")
            time.sleep(180)

    t = threading.Thread(target=_watcher_loop, daemon=True, name="AutoUpdateWatcher")
    t.start()


_start_background_auto_update_watcher()


@app.get("/", response_class=HTMLResponse)
async def get_ui():
    return HTMLResponse(
        content=get_main_ui_html(),
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )


if __name__ == "__main__":
    import uvicorn
    import socket
    import threading
    import webbrowser
    import subprocess
    import urllib.request
    import json

    host = os.environ.get("SERVER_HOST", "0.0.0.0")
    port = int(os.environ.get("SERVER_PORT", "8080"))

    local_ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass

    print("\n" + "=" * 65)
    print("  🚀 FARMA RADAR — AKILLI DEPO & MF SİSTEMİ ÇALIŞIYOR")
    print(f"  📍 Bu Bilgisayardan Erişim : http://localhost:{port}")
    print(f"  🌐 Eczane Ağından Erişim   : http://{local_ip}:{port}")
    print("=" * 65 + "\n")

    def _auto_open_browser():
        time.sleep(1.0)
        url = f"http://localhost:{port}"
        chrome_candidates = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
        ]
        opened = False
        for c_exe in chrome_candidates:
            if os.path.exists(c_exe):
                try:
                    subprocess.Popen([c_exe, f"--app={url}", "--window-size=1440,920"])
                    opened = True
                    break
                except Exception:
                    pass
        if not opened:
            try:
                webbrowser.open(url)
            except Exception:
                pass

    def _is_port_busy(p):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            return s.connect_ex(('127.0.0.1', p)) == 0

    def _kill_processes_on_port(p):
        if sys.platform != "win32":
            return
        my_pid = os.getpid()
        try:
            out = subprocess.check_output(
                ["netstat", "-ano"],
                creationflags=subprocess.CREATE_NO_WINDOW,
                text=True,
                errors="ignore",
                timeout=4
            )
            pids_to_kill = set()
            for line in out.splitlines():
                if f":{p}" in line and "LISTENING" in line.upper():
                    parts = line.split()
                    if parts:
                        try:
                            pid = int(parts[-1])
                            if pid > 0 and pid != my_pid:
                                pids_to_kill.add(pid)
                        except Exception:
                            pass
            for pid in pids_to_kill:
                try:
                    subprocess.run(
                        ["taskkill", "/F", "/T", "/PID", str(pid)],
                        creationflags=subprocess.CREATE_NO_WINDOW,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        timeout=4
                    )
                except Exception:
                    pass
        except Exception:
            pass

    def _is_running_server_up_to_date(p) -> bool:
        disk_ver = updater.get_local_version_info().get("version", "1.4.0")
        try:
            req = urllib.request.Request(
                f"http://127.0.0.1:{p}/api/version",
                headers={"Cache-Control": "no-cache"}
            )
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode("utf-8"))
                    rt_ver = data.get("runtime_version")
                    if rt_ver and rt_ver == disk_ver and not data.get("restart_required"):
                        return True
        except Exception:
            pass
        return False

    is_restarting = (os.environ.get("SERVER_RESTARTING") == "1") or ("--restarting" in sys.argv)
    no_browser = is_restarting or (os.environ.get("NO_AUTO_BROWSER") == "1") or ("--no-browser" in sys.argv)

    if _is_port_busy(port):
        if is_restarting or not _is_running_server_up_to_date(port):
            print(f"[GUNCELLEME/RESTART] Port {port} uzerindeki eski oturum kapatilip yeni surum baslatiliyor...")
            _kill_processes_on_port(port)
            for _ in range(30):
                if not _is_port_busy(port):
                    break
                time.sleep(0.3)
        else:
            print(f"\n[BILGI] Sistem zaten {port} portunda guncel surumle calisiyor!")
            if not no_browser:
                print(f"Tarayici aciliyor: http://localhost:{port}\n")
                _auto_open_browser()
                time.sleep(1.5)
            sys.exit(0)

    if not no_browser:
        threading.Thread(target=_auto_open_browser, daemon=True).start()

    uvicorn.run(app, host=host, port=port, reload=False)

