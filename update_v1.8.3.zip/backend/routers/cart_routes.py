# -*- coding: utf-8 -*-
"""
backend/routers/cart_routes.py
------------------------------
Depo sepet işlemleri (tekil ekleme, toplu ekleme, şelale ekleme, sepet durumu,
hızlı/toplu sipariş sonlandırma ve çoklu bilgisayar ortak sipariş/verilmeyecek takibi) uç noktaları.
"""

import re
import time
import asyncio
from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse

import backend.app_state as app_state
from backend.order_tracker import order_tracker
from backend.license_manager import license_manager
from backend.catalog import catalog

router = APIRouter()


@router.post("/api/cart/add")
async def add_to_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        barkod = str(data.get("barkod", "")).strip()
        satis_sekli = str(data.get("satis_sekli", "")).strip()
        name = str(data.get("name") or data.get("urun_adi") or "").strip()

        if not depo:
            return JSONResponse({"success": False, "message": "Depo belirtilmedi."}, status_code=400)

        res = await motor.add_to_cart(
            depo=depo,
            urun_id=urun_id or barkod,
            miktar=miktar,
            barkod=barkod,
            satis_sekli=satis_sekli,
            name=name,
            urun_adi=name
        )
        if res.get("success"):
            resolved_name = str(name or res.get("urun_adi") or "").strip()
            try:
                await asyncio.to_thread(
                    order_tracker.mark_items,
                    [{"barkod": barkod or urun_id, "urun_adi": resolved_name, "depo": depo, "miktar": miktar}],
                    "SEPETTE",
                    depo
                )
            except Exception as e:
                print(f"[OrderTracker] add_to_cart kayıt uyarısı: {e}")
            try:
                license_manager.record_activity("cart", f"Sepete Ekle ({depo.upper()}): {(name or barkod or urun_id)[:28]} x{miktar}")
            except Exception:
                pass
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepete ekleme hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/bulk-add")
async def bulk_add_to_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "ALLIANCE")).strip()
        items = data.get("items", [])
        cascade = bool(data.get("cascade", False))

        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek ürün listesi boş."}, status_code=400)

        if cascade:
            res = await motor.cascade_bulk_add_to_cart(start_depo=depo, items=items)
        else:
            res = await motor.bulk_add_to_cart(depo=depo, items=items)

        try:
            raw_res_items = res.get("items") or res.get("items_trace") or []
            succ_items = [
                {
                    "barkod": r.get("barcode") or r.get("barkod"),
                    "urun_adi": r.get("name") or r.get("urun_adi"),
                    "depo": r.get("assigned_depo") or depo,
                    "miktar": r.get("miktar", 1)
                }
                for r in raw_res_items if r.get("success")
            ]
            failed_items = [
                r for r in raw_res_items if not r.get("success")
            ]
            if failed_items:
                cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
                for fr in failed_items:
                    f_bc = str(fr.get("barcode") or fr.get("barkod") or "").strip()
                    f_nm = str(fr.get("name") or fr.get("urun_adi") or "").strip()
                    existing = (f_bc and cur_orders.get(f_bc)) or (f_nm and cur_orders.get(f_nm.upper()))
                    if isinstance(existing, dict) and existing.get("durum") == "SEPETTE" and depo.upper() in str(existing.get("depo") or "").upper():
                        await asyncio.to_thread(order_tracker.unmark_item, f_bc, f_nm, False, depo)
            if succ_items:
                await asyncio.to_thread(order_tracker.mark_items, succ_items, "SEPETTE", depo)
                try:
                    license_manager.record_activity("cart", f"Toplu Sepet ({depo.upper()}): {len(succ_items)} Kalem")
                except Exception:
                    pass
        except Exception as e:
            print(f"[OrderTracker] bulk_add kayıt uyarısı: {e}")

        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Toplu sepete ekleme hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/cascade-bulk-add")
async def cascade_bulk_add_to_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "ALLIANCE")).strip()
        items = data.get("items", [])
        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek ürün listesi boş."}, status_code=400)
        res = await motor.cascade_bulk_add_to_cart(start_depo=depo, items=items)
        try:
            raw_res_items = res.get("items") or res.get("items_trace") or []
            succ_items = [
                {
                    "barkod": r.get("barcode") or r.get("barkod"),
                    "urun_adi": r.get("name") or r.get("urun_adi"),
                    "depo": r.get("assigned_depo") or depo,
                    "miktar": r.get("miktar", 1)
                }
                for r in raw_res_items if r.get("success")
            ]
            if succ_items:
                await asyncio.to_thread(order_tracker.mark_items, succ_items, "SEPETTE", depo)
                try:
                    license_manager.record_activity("cart", f"Toplu Sepet ({depo.upper()}): {len(succ_items)} Kalem")
                except Exception:
                    pass
        except Exception as e:
            print(f"[OrderTracker] cascade_bulk_add kayıt uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Şelale sepete ekleme hatası: {str(e)}"}, status_code=500)


@router.get("/api/cart/status")
async def cart_status_endpoint(depo: str = Query("SELCUK")):
    motor = app_state.get_motor()
    try:
        res = await motor.get_cart_status(depo=depo)
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepet sorgulama hatası: {str(e)}"}, status_code=500)


_cart_catalog_alias_cache: dict = {}


def _depo_matches(raw_depo_str: str, target_depo: str) -> bool:
    if not raw_depo_str or not target_depo:
        return False
    t_up = str(target_depo).strip().upper()
    parts = [p.strip().upper() for p in re.split(r"[+,;/|]", str(raw_depo_str)) if p.strip()]
    return t_up in parts


def _get_recent_adapter_added_items(motor, depo: str) -> list:
    try:
        adapter = motor._get_adapter_by_depo(depo)
        if adapter is None:
            return []
        last_ts = float(getattr(adapter, "_last_added_time", 0.0) or 0.0)
        last_items = getattr(adapter, "_last_added_items", None) or []
        if last_items and (last_ts <= 0 or (time.time() - last_ts) < 21600):
            return [dict(x) for x in last_items if isinstance(x, dict)]
    except Exception:
        pass
    return []


def _get_catalog_aliases_for_code(bc_or_code: str) -> tuple:
    """Verilen barkod veya kod için katalogdaki alternatif barkodları, depo kodlarını ve tüm kayıtlı ürün isimlerini döner."""
    raw = str(bc_or_code or "").strip()
    if not raw or len(raw) < 4:
        return set(), []
    if raw in _cart_catalog_alias_cache:
        return _cart_catalog_alias_cache[raw]

    codes = {raw}
    if len(raw) == 14 and raw.startswith("0"):
        codes.add(raw[1:])
    names = []
    try:
        rel_bcs = catalog.get_all_related_barcodes(raw)
        for b in rel_bcs:
            b_str = str(b or "").strip()
            if b_str:
                codes.add(b_str)
                if len(b_str) == 14 and b_str.startswith("0"):
                    codes.add(b_str[1:])
        lookup_list = [c for c in list(codes) if len(c) >= 6][:8]
        if lookup_list:
            placeholders = ",".join("?" for _ in lookup_list)
            with catalog._get_connection() as conn:
                cur = conn.cursor()
                cur.execute(
                    f"""
                    SELECT DISTINCT p.name
                    FROM product_barcodes pb
                    JOIN products p ON pb.product_id = p.id
                    WHERE pb.barcode IN ({placeholders})
                    LIMIT 8
                    """,
                    tuple(lookup_list)
                )
                for r in cur.fetchall():
                    if r and r[0]:
                        nm = str(r[0]).strip()
                        if nm and nm not in names:
                            names.append(nm)
    except Exception:
        pass

    if len(_cart_catalog_alias_cache) > 4000:
        _cart_catalog_alias_cache.clear()
    res_tuple = (codes, names)
    _cart_catalog_alias_cache[raw] = res_tuple
    return res_tuple


def _normalize_tr_cart_text(text: str) -> str:
    if not text:
        return ""
    res = str(text)
    # Olası UTF-8 -> Latin-1 mojibake karakterlerini düzelt (Alliance b64 vb.)
    mojibake_map = {
        "Ãœ": "u", "Ã¼": "u", "Ã–": "o", "Ã¶": "o",
        "Ã‡": "c", "Ã§": "c", "ÅŸ": "s", "Åž": "s",
        "Ä±": "i", "Ä°": "i", "ÄŸ": "g", "Äž": "g",
    }
    for mk, mv in mojibake_map.items():
        if mk in res:
            res = res.replace(mk, mv)
    tr_map = {
        'İ': 'i', 'I': 'i', 'ı': 'i',
        'Ş': 's', 'ş': 's',
        'Ğ': 'g', 'ğ': 'g',
        'Ü': 'u', 'ü': 'u',
        'Ö': 'o', 'ö': 'o',
        'Ç': 'c', 'ç': 'c'
    }
    for k, v in tr_map.items():
        res = res.replace(k, v)
    return res.lower().strip()


_CART_SYNONYM_MAP = {
    "forte": "fort",
    "pls": "plus",
    "pediatrik": "ped",
    "pediyatrik": "ped",
    "efervesan": "ef",
    "eff": "ef",
    "effervescent": "ef",
    "poset": "sase",
    "sachet": "sase",
    "merhem": "pomad",
    "pom": "pomad",
    "kaps": "kap",
    "kapsul": "kap",
    "softgel": "kap",
    "vitamin": "vit",
    "vitamini": "vit",
    "ampul": "amp",
    "flakon": "flk",
    "suspansiyon": "susp",
    "solusyon": "sol",
    "cozelti": "sol",
}

_CART_SKIP_UNITS = {
    'mg', 'mcg', 'ml', 'gr', 'g', 'iu', 'ui', 'tb', 'ftb', 'tab', 'tablet', 'film', 'kapli',
    'sus', 'susp', 'surup', 'kap', 'adet', 'kutu', 'kt', 'flk', 'amp',
    'krem', 'pomad', 'jel', 'gel', 'losyon', 'sprey', 'damla', 'sase', 'ef', 'sol', 'ovul', 'sup', 'supp'
}

_CART_VARIANT_MODIFIERS = {
    'plus', 'fort', 'duo', 'extra', 'ekstra', 'retard', 'sr', 'mr', 'cr', 'xl', 'xr', 'la',
    'ped', 'junior', 'baby', 'kids', 'gece', 'night', 'day', 'gunduz', 'cold', 'flu', 'sinus', 'c'
}


def _extract_cart_tokens(name: str):
    norm = _normalize_tr_cart_text(name)
    if not norm:
        return "", "", [], set(), set(), set()

    # Binlik noktaları birleştir: 1.200.000 -> 1200000, 20.000 -> 20000, 1.000 -> 1000; ondalık virgülü noktaya çevir
    norm = re.sub(r"\b(\d{1,3})\.(\d{3})\.(\d{3})\b", r"\1\2\3", norm)
    norm = re.sub(r"\b(\d{1,3})\.(\d{3})\b", r"\1\2", norm)
    norm = re.sub(r"(\d),(\d)", r"\1.\2", norm)
    # 1 gr / 1g -> 1000 mg, 0.5 gr -> 500 mg
    norm = re.sub(r"\b0\.5\s*(gr|g)\b", "500 mg", norm)
    norm = re.sub(r"\b1\s*(gr|g)\b", "1000 mg", norm)
    norm = re.sub(r"\b2\s*(gr|g)\b", "2000 mg", norm)

    # Vitamin kodlarını (d3, b12, b1, b6, k2) tek parça koru ki "3" veya "12" yanlışlıkla kutu/mg sayısı sanılmasın!
    vit_tokens = set(re.findall(r"\b(?:d3|b12|b1|b6|b2|k2)\b", norm))
    norm_for_nums = re.sub(r"\b(?:d3|b12|b1|b6|b2|k2)\b", " ", norm)

    # Dozaj sayıları ile kutu/ambalaj adedi sayılarını ayır
    dose_nums = set()
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*(mg|mcg|gr|g|iu|ui|ml|%|lt)\b", norm_for_nums):
        dose_nums.add(m.group(1).rstrip("0").rstrip(".") if "." in m.group(1) else m.group(1))
    pack_nums = set()
    for m in re.finditer(r"(\d+)\s*(tb|ftb|tab|tablet|drj|draje|kap|kapsul|sase|poset|ef|eff|efervesan|amp|ampul|flk|flakon|adet|kutu|kt|ovul|sup|supp|li|lu|lik|luk)\b", norm_for_nums):
        pack_nums.add(m.group(1))

    all_nums = set()
    series_nums = set()
    for n_str in re.findall(r"\d+(?:\.\d+)?", norm_for_nums):
        clean_n = n_str.rstrip("0").rstrip(".") if "." in n_str else n_str
        if clean_n:
            all_nums.add(clean_n)
            if clean_n not in pack_nums and "." not in clean_n and int(clean_n) >= 100:
                dose_nums.add(clean_n)
            elif clean_n not in pack_nums and clean_n not in dose_nums:
                series_nums.add(clean_n)

    raw_tokens = re.findall(r"[a-z0-9]+", norm)
    norm_tokens = [_CART_SYNONYM_MAP.get(t, t) for t in raw_tokens]

    # Tireli / tek harf önekli markaları birleştir: "a-ferin" -> ["a","ferin"] -> brand_glued = "aferin", "tylol hot" -> "tylolhot"
    alpha_tokens = [t for t in norm_tokens if not t.isdigit() and t not in _CART_SKIP_UNITS]
    brand = ""
    glued_brand = ""
    merged_single_prefix = False
    if alpha_tokens:
        if len(alpha_tokens[0]) == 1 and len(alpha_tokens) >= 2 and alpha_tokens[0] in {"a", "b", "c", "d", "e", "k", "l", "o", "u"}:
            # Örn: "A-FERIN" -> "aferin", "D-COLEFOR" -> "dcolefor", "B-GOOD" -> "bgood", "L-THYROXIN" -> "lthyroxin"
            brand = alpha_tokens[0] + alpha_tokens[1]
            glued_brand = brand
            merged_single_prefix = True
        else:
            brand = alpha_tokens[0]
            if len(alpha_tokens) >= 2:
                glued_brand = alpha_tokens[0] + alpha_tokens[1]
            else:
                glued_brand = brand

    words = []
    if merged_single_prefix:
        words.append(brand)
        iter_alpha = alpha_tokens[2:]
    else:
        iter_alpha = alpha_tokens
    for t in iter_alpha:
        if len(t) >= 2 or t in {"c", "d"}:
            words.append(t)
    for vt in vit_tokens:
        if vt not in words:
            words.append(vt)

    modifiers = {w for w in words[1:] if w in _CART_VARIANT_MODIFIERS} if len(words) > 1 else set()
    return brand, glued_brand, words, all_nums, dose_nums, pack_nums, series_nums, modifiers


def _names_match_cart_product(c_ad: str, e_ad: str) -> bool:
    c_norm = _normalize_tr_cart_text(c_ad)
    e_norm = _normalize_tr_cart_text(e_ad)
    if not c_norm or not e_norm:
        return False

    c_compact = re.sub(r"[^a-z0-9]+", "", c_norm)
    e_compact = re.sub(r"[^a-z0-9]+", "", e_norm)
    if c_compact and e_compact and c_compact == e_compact:
        return True

    c_brand, c_glued, c_words, c_nums, c_doses, c_packs, c_series, c_mods = _extract_cart_tokens(c_ad)
    e_brand, e_glued, e_words, e_nums, e_doses, e_packs, e_series, e_mods = _extract_cart_tokens(e_ad)
    if not c_brand or not e_brand:
        return False

    # Alt-dize eşleşmesi (ancak çelişen varyant eki veya seri numarası olmamalı)
    sym_diff_mods = c_mods.symmetric_difference(e_mods)
    if (len(c_norm) >= 5 and len(e_norm) >= 5) and (c_norm in e_norm or e_norm in c_norm):
        if not sym_diff_mods and not (c_series and e_series and not c_series.intersection(e_series)):
            return True

    brand_ok = (
        c_brand == e_brand
        or c_brand == e_glued
        or e_brand == c_glued
        or (c_glued and e_glued and c_glued == e_glued)
        or (len(c_brand) >= 5 and len(e_brand) >= 5 and (c_brand.startswith(e_brand[:5]) or e_brand.startswith(c_brand[:5])))
    )
    if not brand_ok:
        return False

    # Çelişen kritik varyant eki kontrolü (örn. biri DAY diğeri NIGHT/C, veya biri PLUS diğeri sade 500 MG)
    strict_conflict_mods = {'plus', 'duo', 'gece', 'night', 'day', 'gunduz', 'cold', 'flu', 'sinus', 'ped', 'junior', 'baby'}
    if sym_diff_mods.intersection(strict_conflict_mods):
        return False
    # "C" vitamini varyantı (örn. TYLOL HOT DAY vs TYLOL HOT C, fakat REDOXON C VIT <-> REDOXON TRIPLE C sorun çıkarmasın)
    if ('c' in sym_diff_mods) and ('vit' not in c_words) and ('vit' not in e_words):
        return False

    # Seri / numara çelişkisi kontrolü (örn. APTAMIL 1 800 GR != APTAMIL 2 800 GR, OMEGA 3 != OMEGA 6)
    if c_series and e_series and not c_series.intersection(e_series):
        return False

    # Her ikisinde de açık ambalaj adedi yazılıysa çelişmemeli (örn. PAROL 500 MG 20 TB != PAROL 500 MG 30 TB)
    if c_packs and e_packs and not c_packs.intersection(e_packs):
        return False

    # Her ikisinde de dozaj (mg/ml/iu vb.) varsa en az bir dozaj sayısı ortak olmalı (örn. AUGMENTIN 1000 != AUGMENTIN 625)
    if c_doses and e_doses:
        if c_doses.intersection(e_doses):
            return True
        return False

    # Genel sayılar varsa ortak sayı kontrolü
    if c_nums and e_nums:
        if c_nums.intersection(e_nums):
            return True
        # Bir taraf sadece ambalaj adedi (örn. "OCEAN VIT D 20 ML" -> 20) diğer taraf sadece IU ("OCEAN D3 400 IU" -> 400) yazdıysa:
        # En az 2 anlamlı ortak kelime varsa (örn. ocean + vit/d/d3) aynı üründür
        norm_c_set = {('d' if w == 'd3' else w) for w in c_words}
        norm_e_set = {('d' if w == 'd3' else w) for w in e_words}
        if len(norm_c_set.intersection(norm_e_set)) >= 2 and not sym_diff_mods:
            return True
        return False

    # Bir tarafta sayı hiç yazılmamışsa (örn. "BACTROBAN POMAD" vs "BACTROBAN %2 15 GR POMAD")
    if not sym_diff_mods:
        norm_c_set = {('d' if w == 'd3' else w) for w in c_words}
        norm_e_set = {('d' if w == 'd3' else w) for w in e_words}
        common_words = norm_c_set.intersection(norm_e_set)
        if len(common_words) >= min(2, len(norm_c_set), len(norm_e_set)):
            return True
        # Tek kelimelik özgün ilaç markası + aynı/uyumlu form (örn. "BACTROBAN POMAD" <-> "BACTROBAN %2 15G")
        if len(c_brand) >= 5 and (len(norm_c_set) == 1 or len(norm_e_set) == 1):
            return True

    return False


def _is_same_cart_product(cart_it: dict, exp_it: dict) -> bool:
    """Depo sepetindeki bir satırın, beklenen/az önce eklenen ürünle aynı olup olmadığını katalog ve farmasötik token zekasıyla tespit eder."""
    c_kod = str(cart_it.get("kod") or cart_it.get("urun_id") or cart_it.get("matnr") or cart_it.get("id") or "").strip()
    c_bc = str(cart_it.get("barkod") or cart_it.get("barcode") or "").strip()
    c_ad = str(cart_it.get("ad") or cart_it.get("urun_adi") or cart_it.get("name") or "").strip()

    e_id = str(exp_it.get("urun_id") or exp_it.get("matnr") or exp_it.get("kod") or exp_it.get("id") or "").strip()
    e_bc = str(exp_it.get("barcode") or exp_it.get("barkod") or "").strip()
    e_ad = str(exp_it.get("name") or exp_it.get("urun_adi") or exp_it.get("ad") or "").strip()
    e_extra_names = exp_it.get("_alias_names") or []

    def _expand_code_variants(raw_vals) -> set:
        out = set()
        for rv in raw_vals:
            v = str(rv or "").strip()
            if not v:
                continue
            out.add(v)
            if v.isdigit():
                stripped = v.lstrip("0")
                if stripped:
                    out.add(stripped)
        return out

    c_codes = _expand_code_variants((c_kod, c_bc))
    e_codes = _expand_code_variants((e_id, e_bc))
    if c_codes and e_codes and c_codes.intersection(e_codes):
        return True

    # Eğer her iki tarafta da GTIN/EAN barkod dışı (depo içi malzeme kodu, örn. 4-10 haneli) kod biliniyor ve birbirinden farklıysa farklı SKU'dur!
    def _clean_internal_code(val: str) -> str:
        s = str(val or "").strip().lstrip("0")
        if not s or len(s) >= 12:
            return ""
        return s

    c_int = _clean_internal_code(c_kod)
    e_int = _clean_internal_code(e_id) if (e_id and e_id != e_bc) else ""
    if c_int and e_int and c_int != e_int:
        return False

    # Katalog (products.db) üzerinden alternatif barkod ve WEBLISTE/otomasyon isim eşanlamlılarını genişlet
    alias_names_to_check = [e_ad] + [x for x in e_extra_names if x]
    if e_bc or (e_id and len(e_id) >= 8):
        cat_codes, cat_names = _get_catalog_aliases_for_code(e_bc or e_id)
        if cat_codes:
            e_codes_ext = _expand_code_variants(cat_codes)
            if c_codes and c_codes.intersection(e_codes_ext):
                return True
        for cn in cat_names:
            if cn not in alias_names_to_check:
                alias_names_to_check.append(cn)

    if c_bc or (c_kod and len(c_kod) >= 12):
        c_cat_codes, c_cat_names = _get_catalog_aliases_for_code(c_bc or c_kod)
        if c_cat_codes and e_codes and _expand_code_variants(c_cat_codes).intersection(e_codes):
            return True
        for c_alias in ([c_ad] + c_cat_names):
            if not c_alias:
                continue
            for e_alias in alias_names_to_check:
                if e_alias and _names_match_cart_product(c_alias, e_alias):
                    return True
        return False

    for e_alias in alias_names_to_check:
        if e_alias and _names_match_cart_product(c_ad, e_alias):
            return True

    return False


@router.post("/api/cart/quick-finalize-check")
async def quick_finalize_check_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        barkod = str(data.get("barkod", "")).strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        urun_adi = str(data.get("urun_adi", "")).strip()

        cart_status = await motor.get_cart_status(depo=depo)
        items = cart_status.get("items", [])

        today_session_items = []
        try:
            cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
            for val in _deduplicate_today_orders(cur_orders):
                if isinstance(val, dict) and _depo_matches(val.get("depo"), depo) and val.get("durum") == "SEPETTE":
                    today_session_items.append({
                        "barcode": str(val.get("barkod") or "").strip(),
                        "name": str(val.get("urun_adi") or "").strip(),
                        "miktar": int(val.get("miktar") or 1)
                    })
        except Exception:
            pass

        for ad_it in _get_recent_adapter_added_items(motor, depo):
            today_session_items.append({
                "barcode": str(ad_it.get("barcode") or ad_it.get("barkod") or "").strip(),
                "urun_id": str(ad_it.get("urun_id") or ad_it.get("kod") or ad_it.get("matnr") or ad_it.get("id") or "").strip(),
                "name": str(ad_it.get("name") or ad_it.get("ad") or ad_it.get("urun_adi") or "").strip(),
                "miktar": int(ad_it.get("miktar") or 1)
            })

        target_exp = {"urun_id": urun_id, "barkod": barkod, "urun_adi": urun_adi}
        already_in_cart = False
        session_items = []
        foreign_items = []
        annotated_items = []

        for it in items:
            it_copy = dict(it)
            if _is_same_cart_product(it_copy, target_exp):
                it_copy["item_origin"] = "CURRENT_TARGET"
                already_in_cart = True
                session_items.append(it_copy)
            elif any(_is_same_cart_product(it_copy, s_it) for s_it in today_session_items):
                it_copy["item_origin"] = "ADDED_THIS_SESSION"
                session_items.append(it_copy)
            else:
                it_copy["item_origin"] = "FOREIGN_OTHER"
                foreign_items.append(it_copy)
            annotated_items.append(it_copy)

        item_count = len(annotated_items)
        has_other_items = len(foreign_items) > 0
        foreign_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in foreign_items)
        session_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in session_items)

        return JSONResponse({
            "success": True,
            "depo": depo,
            "can_finalize_directly": not has_other_items,
            "has_other_items": has_other_items,
            "already_in_cart": already_in_cart,
            "item_count": item_count,
            "items": annotated_items,
            "session_items": session_items,
            "session_count": len(session_items),
            "session_total": round(session_total, 2),
            "foreign_items": foreign_items,
            "foreign_count": len(foreign_items),
            "foreign_total": round(foreign_total, 2),
            "total_amount": cart_status.get("total_amount", 0.0),
            "cart_url": cart_status.get("cart_url", ""),
            "checkout_url": cart_status.get("checkout_url", ""),
            "supported": cart_status.get("supported", False)
        })
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Hızlı sipariş kontrol hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/finalize")
async def finalize_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        barkod = str(data.get("barkod", "")).strip()
        urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        force = bool(data.get("force", False))
        already_in_cart = bool(data.get("already_in_cart", False))
        satis_sekli = str(data.get("satis_sekli", "")).strip()
        bulk_items = data.get("items", [])
        missing_items = data.get("missing_items", []) or []

        effective_urun_id = "" if already_in_cart else (urun_id or barkod)
        effective_barkod = "" if already_in_cart else barkod
        effective_force = True if already_in_cart else force

        res = await motor.finalize_order(
            depo=depo,
            urun_id=effective_urun_id,
            miktar=miktar,
            force=effective_force,
            barkod=effective_barkod,
            satis_sekli=satis_sekli,
            name=urun_adi,
            urun_adi=urun_adi,
            items=bulk_items
        )
        # Eğer sepet depo tarafında zaten onaylanmış/boşalmışsa ve bizde SEPETTE kaydı varsa, takılı kalmasını önle
        if not res.get("success") and not effective_urun_id:
            msg_low = str(res.get("message") or "").lower()
            if "bulunamadı" in msg_low or "boş" in msg_low:
                try:
                    promoted_cnt = await asyncio.to_thread(order_tracker.promote_cart_items_to_ordered_for_depo, depo)
                    if promoted_cnt > 0:
                        res = {
                            "success": True,
                            "depo": depo,
                            "message": f"{depo} sepetindeki ürünler sipariş verildi olarak güncellendi."
                        }
                except Exception:
                    pass

        if res.get("success"):
            try:
                adapter = motor._get_adapter_by_depo(depo)
                if adapter is not None:
                    if hasattr(adapter, "_last_added_items"):
                        adapter._last_added_items = []
                    if hasattr(adapter, "_last_added_time"):
                        adapter._last_added_time = 0.0

                to_mark = []
                seen_keys = set()
                seen_names = set()
                if barkod or urun_id or urun_adi:
                    k0 = (barkod or urun_id or urun_adi).strip().upper()
                    if k0:
                        seen_keys.add(k0)
                    if urun_adi and urun_adi.strip():
                        seen_names.add(urun_adi.strip().upper())
                    to_mark.append({
                        "barkod": barkod or urun_id,
                        "urun_adi": urun_adi,
                        "depo": depo,
                        "miktar": miktar
                    })
                if bulk_items and isinstance(bulk_items, list):
                    for bi in bulk_items:
                        b_bc = str(bi.get("barcode") or bi.get("barkod") or bi.get("urun_id") or "").strip()
                        b_nm = str(bi.get("name") or bi.get("urun_adi") or "").strip()
                        k_bi = (b_bc or b_nm).upper()
                        nm_up = b_nm.upper()
                        if k_bi and k_bi not in seen_keys and (not nm_up or nm_up not in seen_names):
                            seen_keys.add(k_bi)
                            if nm_up:
                                seen_names.add(nm_up)
                            to_mark.append({
                                "barkod": b_bc,
                                "urun_adi": b_nm,
                                "depo": depo,
                                "miktar": bi.get("miktar", 1)
                            })
                # Canlı depo sepetinde yer almadığı tespit edilen eksik kalemleri ASLA 'SIPARIS_VERILDI' yapma!
                missing_bc_set = set()
                missing_nm_set = set()
                if isinstance(missing_items, list):
                    for mi in missing_items:
                        if not isinstance(mi, dict):
                            continue
                        m_bc = str(mi.get("barcode") or mi.get("barkod") or "").strip()
                        m_nm = str(mi.get("name") or mi.get("urun_adi") or "").strip()
                        if m_bc:
                            missing_bc_set.add(m_bc.upper())
                        if m_nm:
                            missing_nm_set.add(m_nm.upper())
                        try:
                            await asyncio.to_thread(order_tracker.unmark_item, m_bc, m_nm, False, depo)
                        except Exception:
                            pass

                cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
                for val in _deduplicate_today_orders(cur_orders):
                    if isinstance(val, dict) and _depo_matches(val.get("depo"), depo) and val.get("durum") == "SEPETTE":
                        v_bc = str(val.get("barkod") or "").strip()
                        v_nm = str(val.get("urun_adi") or "").strip()
                        if (v_bc and v_bc.upper() in missing_bc_set) or (v_nm and v_nm.upper() in missing_nm_set):
                            continue
                        k_val = (v_bc or v_nm).upper()
                        nm_up = v_nm.upper()
                        if k_val and k_val not in seen_keys and (not nm_up or nm_up not in seen_names):
                            seen_keys.add(k_val)
                            if nm_up:
                                seen_names.add(nm_up)
                            to_mark.append({
                                "barkod": v_bc,
                                "urun_adi": v_nm,
                                "depo": depo,
                                "miktar": val.get("miktar", 1)
                            })
                if missing_bc_set or missing_nm_set:
                    to_mark = [
                        tm for tm in to_mark
                        if (str(tm.get("barkod") or "").strip().upper() not in missing_bc_set)
                        and (str(tm.get("urun_adi") or "").strip().upper() not in missing_nm_set)
                    ]
                # Önce bu depoya ait kalan SEPETTE kayıtlarını SIPARIS_VERILDI'ye yükselt ve temizle
                await asyncio.to_thread(order_tracker.promote_cart_items_to_ordered_for_depo, depo)
                await asyncio.to_thread(order_tracker.clear_cart_items_for_depo, depo)
                if to_mark:
                    await asyncio.to_thread(order_tracker.mark_items, to_mark, "SIPARIS_VERILDI", depo)
            except Exception as e:
                print(f"[OrderTracker] finalize_order kayıt uyarısı: {e}")

        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sipariş sonlandırma hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/clear")
async def clear_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        res = await motor.clear_cart(depo=depo)
        try:
            await asyncio.to_thread(order_tracker.clear_cart_items_for_depo, depo)
        except Exception as e:
            print(f"[OrderTracker] clear_cart kayıt silme uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepet temizleme hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/bulk-finalize-check")
async def bulk_finalize_check_endpoint(request: Request):
    """
    Günlük toplu sipariş sonlandırma öncesi sepeti kontrol eder.
    Sepetteki ürünleri, bugün sipariş edilmek istenen beklenen ürünlerle karşılaştırır.
    Farklı/önceden sepette olan ürünleri ayıklar.
    """
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        raw_expected = data.get("items", []) or []

        # 1. Kullanıcının bu depoda beklediği kalemler (İstemciden gelen + Ortak Sipariş Takibinde SEPETTE olanlar)
        user_expected_items = []
        seen_exp_keys = set()

        def _add_user_expected(bc_val: str, nm_val: str, mik_val: int, uid_val: str = ""):
            b_clean = str(bc_val or "").strip()
            n_clean = str(nm_val or "").strip()
            u_clean = str(uid_val or "").strip()
            if u_clean == b_clean and len(b_clean) >= 12:
                u_clean = ""
            dedup_b = b_clean[1:] if (len(b_clean) == 14 and b_clean.startswith("0")) else b_clean
            k_b = f"BC:{dedup_b}" if dedup_b else ""
            k_n = f"NM:{_normalize_tr_cart_text(n_clean)}" if n_clean else ""
            if (k_b and k_b in seen_exp_keys) or (k_n and k_n in seen_exp_keys):
                for prev in user_expected_items:
                    if (dedup_b and prev.get("barcode") == b_clean) or (n_clean and _normalize_tr_cart_text(prev.get("name", "")) == _normalize_tr_cart_text(n_clean)):
                        if u_clean and not prev.get("urun_id"):
                            prev["urun_id"] = u_clean
                        break
                return
            if not k_b and not k_n:
                return
            if k_b:
                seen_exp_keys.add(k_b)
            if k_n:
                seen_exp_keys.add(k_n)
            user_expected_items.append({
                "barcode": b_clean,
                "name": n_clean,
                "miktar": max(1, int(mik_val or 1)),
                "urun_id": u_clean,
                "_alias_names": []
            })

        for it in raw_expected:
            if isinstance(it, dict):
                _add_user_expected(
                    it.get("barcode") or it.get("barkod") or "",
                    it.get("name") or it.get("urun_adi") or "",
                    it.get("miktar") or 1,
                    it.get("urun_id") or it.get("matnr") or it.get("kod") or ""
                )

        try:
            cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
            for val in _deduplicate_today_orders(cur_orders):
                if isinstance(val, dict) and _depo_matches(val.get("depo"), depo) and val.get("durum") == "SEPETTE":
                    _add_user_expected(
                        val.get("barkod") or "",
                        val.get("urun_adi") or "",
                        val.get("miktar") or 1,
                        val.get("urun_id") or ""
                    )
        except Exception:
            pass

        # 2. Adaptörün bu oturumda eklediği son ürünleri (dahili depo kodu urun_id + depo ürün adı ile) eşleştirme havuzuna dahil et!
        adapter_recent = _get_recent_adapter_added_items(motor, depo)
        for u_exp in user_expected_items:
            for ad_it in adapter_recent:
                ad_bc = str(ad_it.get("barcode") or ad_it.get("barkod") or "").strip()
                ad_uid = str(ad_it.get("urun_id") or ad_it.get("kod") or ad_it.get("matnr") or ad_it.get("id") or "").strip()
                ad_nm = str(ad_it.get("name") or ad_it.get("ad") or ad_it.get("urun_adi") or "").strip()
                if (ad_bc and u_exp["barcode"] and ad_bc.lstrip("0") == u_exp["barcode"].lstrip("0")) or (ad_nm and u_exp["name"] and _names_match_cart_product(ad_nm, u_exp["name"])):
                    if ad_uid and not u_exp.get("urun_id"):
                        u_exp["urun_id"] = ad_uid
                    if ad_nm and ad_nm not in u_exp["_alias_names"]:
                        u_exp["_alias_names"].append(ad_nm)

        expected_items = list(user_expected_items)
        for ad_it in adapter_recent:
            ad_entry = {
                "barcode": str(ad_it.get("barcode") or ad_it.get("barkod") or "").strip(),
                "urun_id": str(ad_it.get("urun_id") or ad_it.get("kod") or ad_it.get("matnr") or ad_it.get("id") or "").strip(),
                "name": str(ad_it.get("name") or ad_it.get("ad") or ad_it.get("urun_adi") or "").strip(),
                "miktar": int(ad_it.get("miktar") or 1)
            }
            if not any(_is_same_cart_product(ad_entry, ex) for ex in expected_items):
                expected_items.append(ad_entry)

        cart_status = await motor.get_cart_status(depo=depo)
        cart_items = cart_status.get("items", [])

        # NOT: Sepet boş döndüğünde ürünleri otomatik yeniden sepete EKLEME!
        # Çünkü sipariş zaten verilmiş / onaylanmış olabilir; yeniden eklemek siparişi verilen ürünün
        # tekrar "Sepette" görünmesine ve mükerrer siparişe yol açıyordu.
        total_amount = cart_status.get("total_amount", 0.0)

        matched_items = []
        extra_items = []

        for c_it in cart_items:
            c_copy = dict(c_it)
            is_matched = any(_is_same_cart_product(c_copy, exp_it) for exp_it in expected_items)
            if is_matched:
                c_copy["item_origin"] = "ADDED_THIS_SESSION"
                matched_items.append(c_copy)
            else:
                c_copy["item_origin"] = "FOREIGN_OTHER"
                extra_items.append(c_copy)

        # Ters Yönlü Mutabakat: Listede "Sepette / Eklendi" görünüp canlı depo sepetinde OLMAYAN kalemleri tespit et!
        # (Örn: "17 kalem eklendi gösterip sepette 15 kalem çıkması" durumunda kayıp 2 kalemin akıbetini net olarak gösterir!)
        missing_from_cart = []
        used_cart_for_exp = set()
        matched_exp_indices = set()
        if len(cart_items) > 0 and user_expected_items:
            # 1. Aşama: Önce TÜM beklenen kalemler için kesin kod / barkod eşleşmelerini kilitle (başka satırın çalmasını önler!)
            for u_idx, u_exp in enumerate(user_expected_items):
                u_uid = str(u_exp.get("urun_id") or "").strip().lstrip("0")
                u_bc = str(u_exp.get("barcode") or "").strip().lstrip("0")
                for c_idx, c_it in enumerate(cart_items):
                    if c_idx in used_cart_for_exp:
                        continue
                    c_kod = str(c_it.get("kod") or c_it.get("id") or "").strip().lstrip("0")
                    c_bc = str(c_it.get("barkod") or c_it.get("barcode") or "").strip().lstrip("0")
                    if (u_uid and c_kod and u_uid == c_kod) or (u_bc and ((c_kod and u_bc == c_kod) or (c_bc and u_bc == c_bc))):
                        used_cart_for_exp.add(c_idx)
                        matched_exp_indices.add(u_idx)
                        break

            # 2. Aşama: Kodla eşleşmemiş kalan kalemler için boştaki sepet satırları üzerinde akıllı ürün eşleşmesi ara
            for u_idx, u_exp in enumerate(user_expected_items):
                if u_idx in matched_exp_indices:
                    continue
                found_idx = None
                for c_idx, c_it in enumerate(cart_items):
                    if c_idx in used_cart_for_exp:
                        continue
                    if _is_same_cart_product(c_it, u_exp):
                        found_idx = c_idx
                        break
                if found_idx is not None:
                    used_cart_for_exp.add(found_idx)
                    matched_exp_indices.add(u_idx)
                else:
                    missing_from_cart.append({
                        "barcode": u_exp.get("barcode") or "",
                        "name": u_exp.get("name") or u_exp.get("barcode") or "Ürün",
                        "miktar": int(u_exp.get("miktar") or 1),
                        "urun_id": u_exp.get("urun_id") or ""
                    })

        has_extra_items = len(extra_items) > 0
        can_finalize_directly = (not has_extra_items) and (len(cart_items) > 0)

        extra_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in extra_items)

        return JSONResponse({
            "success": True,
            "depo": depo,
            "can_finalize_directly": can_finalize_directly,
            "has_extra_items": has_extra_items,
            "cart_count": len(cart_items),
            "expected_count": len(user_expected_items),
            "matched_count": len(matched_items),
            "extra_count": len(extra_items),
            "extra_total": round(extra_total, 2),
            "missing_count": len(missing_from_cart),
            "missing_from_cart": missing_from_cart,
            "total_amount": total_amount,
            "matched_items": matched_items,
            "extra_items": extra_items,
            "all_items": matched_items + extra_items,
            "cart_url": cart_status.get("cart_url", ""),
            "checkout_url": cart_status.get("checkout_url", ""),
            "supported": cart_status.get("supported", False)
        })
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Günlük sipariş sepet kontrol hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/bulk-finalize-clean-submit")
async def bulk_finalize_clean_submit_endpoint(request: Request):
    """
    Sepetteki farklı ürünleri temizler:
    1. Sepeti tamamen boşaltır (/api/cart/clear)
    2. Sadece bugün gönderilmek istenen günlük sipariş ürünlerini yeniden sepete ekler
    3. Siparişi depoya onaylayıp sonlandırır (/api/cart/finalize force=True)
    """
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        items = data.get("items", []) or []

        if not items:
            try:
                cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
                seen_bcs = set()
                for val in _deduplicate_today_orders(cur_orders):
                    if isinstance(val, dict) and _depo_matches(val.get("depo"), depo) and val.get("durum") == "SEPETTE":
                        v_bc = str(val.get("barkod") or "").strip()
                        v_nm = str(val.get("urun_adi") or "").strip()
                        dedup_k = v_bc or v_nm
                        if dedup_k and dedup_k not in seen_bcs:
                            seen_bcs.add(dedup_k)
                            items.append({
                                "barcode": v_bc,
                                "name": v_nm,
                                "miktar": int(val.get("miktar") or 1)
                            })
            except Exception:
                pass

        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek günlük sipariş kalemi bulunamadı."}, status_code=400)

        await motor.clear_cart(depo=depo)

        added_count = 0
        adapter = motor._get_adapter_by_depo(depo)
        if not adapter:
            return JSONResponse({"success": False, "message": f"'{depo}' için adaptör bulunamadı."}, status_code=400)

        successfully_readded = []
        failed_readd = []
        for it in items:
            bc = str(it.get("barcode") or it.get("barkod") or "").strip()
            u_id = str(it.get("urun_id") or "").strip()
            nm = str(it.get("name") or it.get("urun_adi") or "").strip()
            mik = int(it.get("miktar") or 1)
            try:
                target_id = u_id if u_id else (bc or nm)
                add_res = await adapter.add_to_cart(urun_id=target_id, miktar=mik, barkod=bc, name=nm, urun_adi=nm)
                if add_res.get("success"):
                    added_count += 1
                    successfully_readded.append(it)
                else:
                    failed_readd.append(it)
            except Exception as e:
                failed_readd.append(it)
                print(f"[Bulk Finalize Clean] Ürün ekleme hatası ({bc}): {e}")

        if added_count == 0:
            return JSONResponse({"success": False, "message": "Günlük sipariş ürünleri sepete yeniden eklenemedi."}, status_code=500)

        fin_res = await motor.finalize_order(depo=depo, urun_id="", force=True)
        if fin_res.get("success"):
            try:
                for fr in failed_readd:
                    await asyncio.to_thread(
                        order_tracker.unmark_item,
                        str(fr.get("barcode") or fr.get("barkod") or ""),
                        str(fr.get("name") or fr.get("urun_adi") or ""),
                        False,
                        depo
                    )
                await asyncio.to_thread(order_tracker.clear_cart_items_for_depo, depo)
                if successfully_readded:
                    await asyncio.to_thread(order_tracker.mark_items, successfully_readded, "SIPARIS_VERILDI", depo)
            except Exception as e:
                print(f"[OrderTracker] bulk_finalize_clean_submit kayıt uyarısı: {e}")
            fin_res["readded_count"] = len(successfully_readded)
            fin_res["failed_readd"] = failed_readd
        return JSONResponse(fin_res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Temizleyip sonlandırma hatası: {str(e)}"}, status_code=500)


# --- Çoklu Bilgisayar (Multi-PC) Günlük Sipariş & Verilmeyecek Senkronizasyon Endpoints ---
@router.get("/api/orders/today")
async def get_today_orders_endpoint():
    """Tüm eczane bilgisayarlarında bugün verilen / sepete eklenen / verilmeyecek işaretlenen siparişlerin anlık haritasını döner."""
    try:
        orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
        recent_takas = await asyncio.to_thread(order_tracker.get_recent_takas_orders_map, 7)
        return {"success": True, "orders": orders, "recent_takas": recent_takas, "pc_name": order_tracker.pc_name}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/mark")
@router.post("/api/orders/today/mark")
async def mark_orders_endpoint(request: Request):
    """Bir veya birden fazla ürünü tüm bilgisayarlarda 'SIPARIS_VERILDI', 'SEPETTE' veya 'SIPARIS_VERILMEYECEK' olarak işaretler."""
    try:
        data = await request.json()
        items = data.get("items", [])
        durum = str(data.get("durum", "SIPARIS_VERILDI")).strip()
        depo = str(data.get("depo", "MANUEL")).strip()
        clear_depo_cart = bool(data.get("clear_depo_cart", False))
        if clear_depo_cart and depo and depo.upper() not in ("MANUEL", "TOPLU", "VERILMEYECEK", "YOK_LISTESI"):
            if durum == "SIPARIS_VERILDI":
                await asyncio.to_thread(order_tracker.promote_cart_items_to_ordered_for_depo, depo)
            await asyncio.to_thread(order_tracker.clear_cart_items_for_depo, depo)
            try:
                motor = app_state.get_motor()
                adapter = motor._get_adapter_by_depo(depo)
                if adapter is not None:
                    if hasattr(adapter, "_last_added_items"):
                        adapter._last_added_items = []
                    if hasattr(adapter, "_last_added_time"):
                        adapter._last_added_time = 0.0
            except Exception:
                pass
        count = await asyncio.to_thread(order_tracker.mark_items, items, durum, depo)
        return JSONResponse({"success": True, "count": count, "pc_name": order_tracker.pc_name})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/unmark")
@router.post("/api/orders/today/unmark")
async def unmark_order_endpoint(request: Request):
    """Sipariş verildi veya sipariş verilmeyecek işaretini geri alır (tüm bilgisayarlarda tekrar aktif listeye sokar)."""
    try:
        data = await request.json()
        barkod = str(data.get("barkod") or data.get("barcode") or "").strip()
        urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
        clear_takas_7d = bool(data.get("clear_takas_7d", False))
        depo = str(data.get("depo") or "").strip()
        ok = await asyncio.to_thread(order_tracker.unmark_item, barkod, urun_adi, clear_takas_7d, depo)
        return JSONResponse({"success": bool(ok), "pc_name": order_tracker.pc_name})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


# --- GÜN SONU DEPO SİPARİŞ ÖZETİ & SİPARİŞ VERİLMEYECEKLERDEN YOK LİSTESİ OLUŞTURMA (v1.4.1) ---
def _get_yok_scan_file_path():
    from pathlib import Path
    p = Path(__file__).resolve().parent.parent.parent / "data"
    p.mkdir(parents=True, exist_ok=True)
    return p / "today_yok_scan.json"


def _load_today_yok_scan(today_str: str) -> dict:
    import json
    fp = _get_yok_scan_file_path()
    data = {"date": today_str, "last_scan_time": None, "active_depots": [], "yok_items": [], "var_items": []}
    file_existed = fp.exists()
    if file_existed:
        try:
            loaded = json.loads(fp.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                data = loaded
        except Exception:
            pass

    try:
        yok_items = data.get("yok_items") if isinstance(data.get("yok_items"), list) else []
        var_items = data.get("var_items") if isinstance(data.get("var_items"), list) else []
        changed_any = False

        # Sadece gerçekten Yok Listesi'ne eklenen ürünleri (manuel_eklendi=True) ve Yok Listesi'ndeyken stoğa girenleri (from_yok_list=True) tut;
        # geçmişte 'Verilmeyecekler' taramasından yanlışlıkla yok_items veya var_items'a düşmüş ürünleri temizle
        clean_yok = [y for y in yok_items if isinstance(y, dict) and y.get("manuel_eklendi") is True]
        if len(clean_yok) != len(yok_items):
            yok_items = clean_yok
            changed_any = True

        clean_var = [v for v in var_items if isinstance(v, dict) and v.get("from_yok_list") is True]
        if len(clean_var) != len(var_items):
            var_items = clean_var
            changed_any = True

        # Sipariş verilen, sepete atılan veya başka bilgisayardan Yok Listesi'ne eklenen/silinen ürünleri ortak SQL'den senkronize et
        try:
            orders_map = order_tracker.get_today_orders_map() or {}
            central_ok = getattr(order_tracker, "last_central_read_ok", False)

            # Ortak veritabanındaki aktif YOK_LISTESI anahtarlarını çıkar
            central_yok_keys = set()
            for o_val in _deduplicate_today_orders(orders_map):
                if o_val.get("durum") == "SIPARIS_VERILMEYECEK" and str(o_val.get("depo") or "").upper() == "YOK_LISTESI":
                    o_bc = str(o_val.get("barkod") or "").strip().upper()
                    o_nm = str(o_val.get("urun_adi") or "").strip().upper()
                    if o_bc:
                        central_yok_keys.add(o_bc)
                    if o_nm:
                        central_yok_keys.add(o_nm)

            if yok_items:
                filtered_yok = []
                for y_it in yok_items:
                    y_bc = str(y_it.get("barkod") or "").strip()
                    y_nm = str(y_it.get("urun_adi") or "").strip().upper()
                    ord_entry = (
                        (orders_map.get(y_bc) if y_bc else None)
                        or (orders_map.get(y_nm) if y_nm else None)
                    )
                    if isinstance(ord_entry, dict) and ord_entry.get("durum") in ("SIPARIS_VERILDI", "SEPETTE"):
                        changed_any = True
                        continue
                    # Eğer merkezi SQL okuması başarılıysa ve bu ürün merkezi YOK_LISTESI'nden silinmişse yerel listeden de düşür
                    if central_ok:
                        in_central = (y_bc and y_bc.upper() in central_yok_keys) or (y_nm and y_nm in central_yok_keys)
                        if not in_central:
                            changed_any = True
                            continue
                    filtered_yok.append(y_it)
                yok_items = filtered_yok

            if var_items and orders_map:
                filtered_var = []
                for v_it in var_items:
                    v_bc = str(v_it.get("barkod") or "").strip()
                    v_nm = str(v_it.get("urun_adi") or "").strip().upper()
                    ord_entry = (
                        (orders_map.get(v_bc) if v_bc else None)
                        or (orders_map.get(v_nm) if v_nm else None)
                    )
                    if isinstance(ord_entry, dict) and ord_entry.get("durum") in ("SIPARIS_VERILDI", "SEPETTE"):
                        changed_any = True
                        continue
                    filtered_var.append(v_it)
                var_items = filtered_var

            # Ortak sipariş takibinde (orders_map) doğrudan YOK_LISTESI olarak işaretlenmiş ama yok_items'ta eksik olan ürünleri senkronize et
            existing_keys = set()
            for ex_it in (yok_items + var_items):
                ex_bc = str(ex_it.get("barkod") or "").strip().upper()
                ex_nm = str(ex_it.get("urun_adi") or "").strip().upper()
                if ex_bc:
                    existing_keys.add(ex_bc)
                if ex_nm:
                    existing_keys.add(ex_nm)
            for o_val in _deduplicate_today_orders(orders_map):
                if o_val.get("durum") == "SIPARIS_VERILMEYECEK" and str(o_val.get("depo") or "").upper() == "YOK_LISTESI":
                    o_bc = str(o_val.get("barkod") or "").strip()
                    o_nm = str(o_val.get("urun_adi") or "").strip()
                    if (o_bc and o_bc.upper() in existing_keys) or (o_nm and o_nm.upper() in existing_keys):
                        continue
                    yok_items.append({
                        "barkod": o_bc,
                        "urun_adi": o_nm or o_bc,
                        "masa_adi": o_val.get("masa_adi") or order_tracker.pc_name,
                        "saat": o_val.get("saat") or "",
                        "stokta_var": False,
                        "bulunan_depolar": [],
                        "yok_depolar": ["Manuel Eklendi"],
                        "manuel_eklendi": True
                    })
                    if o_bc:
                        existing_keys.add(o_bc.upper())
                    if o_nm:
                        existing_keys.add(o_nm.upper())
                    changed_any = True
        except Exception:
            pass

        data["yok_items"] = yok_items
        data["var_items"] = var_items
        if changed_any or (file_existed and data.get("date") != today_str) or (not file_existed and (yok_items or var_items)):
            data["date"] = today_str
            _save_today_yok_scan(data)
        return {
            "date": today_str,
            "last_scan_time": data.get("last_scan_time"),
            "active_depots": data.get("active_depots") or [],
            "yok_items": yok_items,
            "var_items": var_items
        }
    except Exception:
        return {"date": today_str, "last_scan_time": None, "yok_items": [], "var_items": []}


def _save_today_yok_scan(scan_data: dict):
    import json
    fp = _get_yok_scan_file_path()
    try:
        fp.write_text(json.dumps(scan_data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"[YokScan] Kayıt uyarısı: {e}")


def _deduplicate_today_orders(orders_map: dict) -> list:
    """
    orders_map içerisindeki 13/14 haneli barkod, alternatif/eski barkodlar,
    NAME:..., ET_..., ETR_... ve ürün adı kopyalarını tekilleştirir.
    Aynı ürün adına (urun_adi) veya aynı kanonik barkoda sahip kayıtlar tek kalemde birleştirilir.
    """
    unique_by_key = {}
    name_to_bc = {}
    bc_to_name_key = {}

    def _resolve_bc(raw_b: str) -> str:
        b = str(raw_b or "").strip()
        if b.startswith("CART:"):
            parts = b.split(":", 2)
            b = parts[2].strip() if len(parts) == 3 else ""
        if b.startswith(("NAME:", "ET_", "ETR_")):
            return ""
        if b and not b.isdigit() and len(b) > 15:
            return ""
        if len(b) == 14 and b.startswith("0"):
            b = b[1:]
        if b and b.isdigit():
            try:
                from backend.catalog import catalog
                cb = catalog.resolve_canonical_barcode(b)
                if cb and cb.isdigit():
                    b = cb[1:] if (len(cb) == 14 and cb.startswith("0")) else cb
            except Exception:
                pass
        return b if (b and b.isdigit()) else ""

    for k, val in (orders_map or {}).items():
        if not isinstance(val, dict) or str(k or "").startswith("CART:"):
            continue
        canon_bc = _resolve_bc(val.get("barkod") or k)
        unm_up = str(val.get("urun_adi") or "").strip().upper()
        is_real_name = bool(unm_up and not unm_up.isdigit() and not unm_up.startswith(("NAME:", "ET_", "ETR_", "CART:")))
        if canon_bc and is_real_name:
            if unm_up not in name_to_bc:
                name_to_bc[unm_up] = canon_bc
            bc_to_name_key[canon_bc] = unm_up

    status_prio = {"SIPARIS_VERILDI": 3, "SIPARIS_VERILMEYECEK": 2, "SEPETTE": 1}

    for k, val in (orders_map or {}).items():
        if not isinstance(val, dict) or str(k or "").startswith("CART:"):
            continue
        depo_up = str(val.get("depo") or "DEPO").strip().upper()
        depo_parts = [d.strip() for d in depo_up.split("+") if d.strip()] or ["DEPO"]
        canon_bc = _resolve_bc(val.get("barkod") or k)
        unm = str(val.get("urun_adi") or "").strip()
        unm_upper = unm.upper()
        is_real_name = bool(unm_upper and not unm_upper.isdigit() and not unm_upper.startswith(("NAME:", "ET_", "ETR_", "CART:")))

        if is_real_name and unm_upper in name_to_bc:
            canon_bc = name_to_bc[unm_upper]

        # Ürün adı gerçek bir isimse aynı ürün adına sahip alternatif barkodları da tekilleştir
        if is_real_name:
            base_key = f"NM:{unm_upper}"
        elif canon_bc and canon_bc in bc_to_name_key:
            base_key = f"NM:{bc_to_name_key[canon_bc]}"
        elif canon_bc:
            base_key = f"BC:{canon_bc}"
        else:
            base_key = unm_upper or str(k or "").strip().upper()

        if not base_key:
            continue

        new_durum = str(val.get("durum") or "SIPARIS_VERILDI")
        for single_depo in depo_parts:
            if new_durum in ("SEPETTE", "SIPARIS_VERILDI"):
                dedup_key = f"{single_depo}:{base_key}"
            else:
                dedup_key = f"SKIP:{base_key}"

            existing = unique_by_key.get(dedup_key)
            if existing:
                old_prio = status_prio.get(str(existing.get("durum") or ""), 0)
                new_prio = status_prio.get(new_durum, 0)
                if new_prio > old_prio or (new_prio == old_prio and not existing.get("barkod") and canon_bc):
                    unique_by_key[dedup_key] = {
                        "barkod": canon_bc or existing.get("barkod") or "",
                        "urun_adi": (unm if is_real_name else existing.get("urun_adi")) or canon_bc,
                        "durum": new_durum,
                        "depo": single_depo,
                        "miktar": int(val.get("miktar") or existing.get("miktar") or 1),
                        "masa_adi": str(val.get("masa_adi") or existing.get("masa_adi") or "Eczane PC"),
                        "saat": str(val.get("saat") or existing.get("saat") or "")
                    }
            else:
                unique_by_key[dedup_key] = {
                    "barkod": canon_bc,
                    "urun_adi": unm or canon_bc,
                    "durum": new_durum,
                    "depo": single_depo,
                    "miktar": int(val.get("miktar") or 1),
                    "masa_adi": str(val.get("masa_adi") or "Eczane PC"),
                    "saat": str(val.get("saat") or "")
                }
    return list(unique_by_key.values())


@router.get("/api/orders/today/summary")
async def get_today_end_of_day_summary_endpoint():
    """
    Gün Sonu Depo Sipariş Özeti:
    - Depo bazlı sipariş verilen (SIPARIS_VERILDI) ve sepette bekleyen (SEPETTE) kalem/kutu dökümü
    - Bugün 'Sipariş Verilmeyecek' (SIPARIS_VERILMEYECEK) işaretlenen ürünler listesi
    - Depolarda sorgulanıp 'Yok Listesi'ne alınan ürünlerin güncel durumu
    """
    try:
        import datetime
        today_str = datetime.date.today().strftime("%Y-%m-%d")
        orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
        unique_items = _deduplicate_today_orders(orders_map)

        ordered_items = []
        cart_items = []
        skipped_items = []
        depots_summary = {}

        for it in unique_items:
            durum = it.get("durum")
            depo = it.get("depo") or "MANUEL"
            miktar = int(it.get("miktar") or 1)
            if durum == "SIPARIS_VERILMEYECEK":
                skipped_items.append(it)
            elif durum == "SEPETTE":
                cart_items.append(it)
                d_entry = depots_summary.setdefault(depo, {
                    "depo": depo,
                    "ordered_count": 0,
                    "ordered_boxes": 0,
                    "cart_count": 0,
                    "cart_boxes": 0,
                    "items": []
                })
                d_entry["cart_count"] += 1
                d_entry["cart_boxes"] += miktar
                d_entry["items"].append(it)
            else:
                ordered_items.append(it)
                d_entry = depots_summary.setdefault(depo, {
                    "depo": depo,
                    "ordered_count": 0,
                    "ordered_boxes": 0,
                    "cart_count": 0,
                    "cart_boxes": 0,
                    "items": []
                })
                d_entry["ordered_count"] += 1
                d_entry["ordered_boxes"] += miktar
                d_entry["items"].append(it)

        yok_scan = await asyncio.to_thread(_load_today_yok_scan, today_str)

        return {
            "success": True,
            "date": today_str,
            "pc_name": order_tracker.pc_name,
            "totals": {
                "ordered_count": len(ordered_items),
                "ordered_boxes": sum(int(x.get("miktar") or 1) for x in ordered_items),
                "cart_count": len(cart_items),
                "cart_boxes": sum(int(x.get("miktar") or 1) for x in cart_items),
                "skipped_count": len(skipped_items),
                "yok_count": len(yok_scan.get("yok_items") or [])
            },
            "depots": list(depots_summary.values()),
            "ordered_items": ordered_items,
            "cart_items": cart_items,
            "skipped_items": skipped_items,
            "yok_scan": yok_scan
        }
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/today/check-yok-list")
async def check_skipped_items_for_yok_list_endpoint(request: Request):
    """
    Bugün 'Sipariş Verilmeyecek' olarak işaretlenen (veya gönderilen listedeki) ürünleri
    aktif ecza depolarında (Alliance, Selçuk, İSKOOP, Nevzat, BEK, DNA) paralel sorgular.
    Hiçbir depoda stoğu olmayan ürünleri otomatik olarak 'YOK LİSTESİ'ne ekler;
    stoğu bulunanlar için ise hangi depoda hangi şartla bulunduğunu raporlar.
    """
    import datetime
    from backend.models import DepoKodu, StokDurumu
    motor = app_state.get_motor()
    try:
        body = {}
        try:
            body = await request.json()
        except Exception:
            pass

        today_str = datetime.date.today().strftime("%Y-%m-%d")
        mode = str(body.get("mode") or "yok_only").strip().lower()
        existing_scan = await asyncio.to_thread(_load_today_yok_scan, today_str)
        input_items = body.get("items")
        if not input_items:
            if mode == "yok_only":
                input_items = list(existing_scan.get("yok_items") or [])
            else:
                orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
                unique_all = _deduplicate_today_orders(orders_map)
                input_items = [it for it in unique_all if it.get("durum") == "SIPARIS_VERILMEYECEK"]

        if not input_items:
            return {
                "success": True,
                "message": "Sorgulanacak Yok Listesi ürünü bulunamadı." if mode == "yok_only" else "Sorgulanacak 'Sipariş Verilmeyecek' işaretli ürün bulunamadı.",
                "checked_count": 0,
                "yok_items": existing_scan.get("yok_items") or [],
                "var_items": existing_scan.get("var_items") or []
            }

        b2b_depo_codes = [
            DepoKodu.ALLIANCE,
            DepoKodu.SELCUK,
            DepoKodu.ISKOOP,
            DepoKodu.NEVZAT,
            DepoKodu.BEK,
            DepoKodu.DNA
        ]
        active_adapters = [
            (code.value, motor.adapters[code])
            for code in b2b_depo_codes
            if code in motor.adapters
        ]

        sem = asyncio.Semaphore(4)

        async def _probe_single_item(item_obj: dict) -> dict:
            bc = str(item_obj.get("barkod") or item_obj.get("barcode") or "").strip()
            nm = str(item_obj.get("urun_adi") or item_obj.get("name") or "").strip()
            query_term = bc if (bc and bc.isdigit() and len(bc) >= 8) else nm
            if not query_term:
                return {
                    "barkod": bc,
                    "urun_adi": nm,
                    "stokta_var": False,
                    "bulunan_depolar": [],
                    "yok_depolar": [c for c, _ in active_adapters],
                    "en_uygun_depo": None,
                    "en_uygun_fiyat": None,
                    "en_uygun_mf": None
                }

            async with sem:
                async def _ask_depo(depo_code: str, adapter):
                    try:
                        try:
                            res_list = await asyncio.wait_for(
                                adapter.search_product(query_term, include_equivalents=False, is_background=True),
                                timeout=8.5
                            )
                        except TypeError:
                            res_list = await asyncio.wait_for(
                                adapter.search_product(query_term),
                                timeout=8.5
                            )
                        if res_list:
                            for r in res_list:
                                if getattr(r, "stok_durumu", None) == StokDurumu.VAR:
                                    return {
                                        "depo": depo_code,
                                        "depo_adi": getattr(r, "depo_adi", depo_code),
                                        "var": True,
                                        "net_maliyet": float(getattr(r, "net_birim_maliyet_kdvli", 0) or getattr(r, "net_birim_maliyet", 0) or getattr(r, "depocu_fiyat", 0) or 0),
                                        "mf": str(getattr(r, "mf_metni", "") or "YOK"),
                                        "barkod": str(getattr(r, "barkod", "") or bc),
                                        "urun_adi": str(getattr(r, "urun_adi", "") or nm)
                                    }
                    except Exception:
                        pass
                    return {"depo": depo_code, "depo_adi": depo_code, "var": False}

                depo_results = await asyncio.gather(*[_ask_depo(c, ad) for c, ad in active_adapters])
                bulunan = [dr for dr in depo_results if dr.get("var")]
                yok_olan = [dr["depo"] for dr in depo_results if not dr.get("var")]
                bulunan.sort(key=lambda x: (x.get("net_maliyet") or 999999.0))
                best = bulunan[0] if bulunan else None
                resolved_bc = (best.get("barkod") if best else "") or bc
                resolved_nm = nm or (best.get("urun_adi") if best else "") or query_term

                return {
                    "barkod": resolved_bc,
                    "urun_adi": resolved_nm,
                    "masa_adi": item_obj.get("masa_adi") or "Eczane PC",
                    "saat": item_obj.get("saat") or datetime.datetime.now().strftime("%H:%M"),
                    "stokta_var": len(bulunan) > 0,
                    "bulunan_depolar": bulunan,
                    "yok_depolar": yok_olan,
                    "en_uygun_depo": best["depo"] if best else None,
                    "en_uygun_depo_adi": best["depo_adi"] if best else None,
                    "en_uygun_fiyat": round(best["net_maliyet"], 2) if (best and best.get("net_maliyet")) else None,
                    "en_uygun_mf": best["mf"] if best else None
                }

        probed_list = await asyncio.gather(*[_probe_single_item(it) for it in input_items[:50]])
        yok_items = [p for p in probed_list if not p.get("stokta_var")]
        var_items = [p for p in probed_list if p.get("stokta_var")]

        now_time = datetime.datetime.now().strftime("%H:%M:%S")

        # Eğer 'Sipariş Verilmeyecekler' (skipped) sorgulandıysa, sonuçları Yok Listesi'ne veya üstteki Sabit Yok Banner'ına ASLA yazma!
        if mode != "yok_only":
            return {
                "success": True,
                "date": today_str,
                "last_scan_time": now_time,
                "checked_count": len(probed_list),
                "active_depots": [c for c, _ in active_adapters],
                "yok_count": len(yok_items),
                "var_count": len(var_items),
                "skipped_results": probed_list,
                "yok_items": existing_scan.get("yok_items") or [],
                "var_items": existing_scan.get("var_items") or []
            }

        # Sadece Yok Listesi (mode == "yok_only") sorgulandığında mevcut yok listesini güncelle
        existing_yok_keys = set()
        merged_yok_map = {}
        for old_y in (existing_scan.get("yok_items") or []):
            old_bc = str(old_y.get("barkod") or "").strip().upper()
            old_nm = str(old_y.get("urun_adi") or "").strip().upper()
            if old_bc:
                existing_yok_keys.add(old_bc)
            if old_nm:
                existing_yok_keys.add(old_nm)
            k = old_bc or old_nm
            if k:
                merged_yok_map[k] = old_y
        # Yeni taramada stokta bulunanları yok listesinden çıkar (ortak SQL'den de YOK_LISTESI kaydını düşür), bulunmayanları tut
        for v_it in var_items:
            v_bc_raw = str(v_it.get("barkod") or "").strip()
            v_nm_raw = str(v_it.get("urun_adi") or "").strip()
            k_bc = v_bc_raw.upper()
            k_nm = v_nm_raw.upper()
            if k_bc:
                merged_yok_map.pop(k_bc, None)
            if k_nm:
                merged_yok_map.pop(k_nm, None)
            try:
                order_tracker.unmark_item(v_bc_raw, v_nm_raw)
            except Exception:
                pass
        for y_it in yok_items:
            y_it["manuel_eklendi"] = True
            k = str(y_it.get("barkod") or y_it.get("urun_adi") or "").strip().upper()
            if k:
                merged_yok_map[k] = y_it

        # Stoğa girenler (var_items) SADECE daha önce gerçekten Yok Listesi'nde olup stoğa giren ürünleri tutar
        merged_var_map = {}
        for old_v in (existing_scan.get("var_items") or []):
            if not old_v.get("from_yok_list"):
                continue
            k = str(old_v.get("barkod") or old_v.get("urun_adi") or "").strip().upper()
            if k:
                merged_var_map[k] = old_v
        for v_it in var_items:
            k_bc = str(v_it.get("barkod") or "").strip().upper()
            k_nm = str(v_it.get("urun_adi") or "").strip().upper()
            v_it["from_yok_list"] = True
            k = k_bc or k_nm
            if k:
                merged_var_map[k] = v_it

        scan_payload = {
            "date": today_str,
            "last_scan_time": now_time,
            "active_depots": [c for c, _ in active_adapters],
            "yok_items": list(merged_yok_map.values()),
            "var_items": list(merged_var_map.values())
        }
        await asyncio.to_thread(_save_today_yok_scan, scan_payload)

        return {
            "success": True,
            "date": today_str,
            "last_scan_time": now_time,
            "checked_count": len(probed_list),
            "active_depots": [c for c, _ in active_adapters],
            "yok_count": len(scan_payload["yok_items"]),
            "var_count": len(var_items),
            "yok_items": scan_payload["yok_items"],
            "var_items": scan_payload["var_items"]
        }
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/today/yok-list/add")
async def add_to_today_yok_list_endpoint(request: Request):
    """Bir veya birden fazla ürünü doğrudan bugünkü Yok Listesine manuel ekler ve tüm PC'lerde işaretler."""
    import datetime
    try:
        body = await request.json()
        raw_items = body.get("items")
        if not raw_items:
            bc_single = str(body.get("barkod") or body.get("barcode") or "").strip()
            nm_single = str(body.get("urun_adi") or body.get("name") or "").strip()
            if bc_single or nm_single:
                raw_items = [{"barkod": bc_single, "urun_adi": nm_single}]
            else:
                raw_items = []

        if not raw_items:
            return JSONResponse({"success": False, "error": "Eklenecek ürün adı veya barkod girilmedi."}, status_code=400)

        today_str = datetime.date.today().strftime("%Y-%m-%d")
        now_hm = datetime.datetime.now().strftime("%H:%M")

        tracker_payload = []
        added_keys = set()
        new_yok_entries = {}
        added_count = 0
        for r in raw_items:
            bc = str(r.get("barkod") or r.get("barcode") or "").strip()
            nm = str(r.get("urun_adi") or r.get("name") or "").strip()
            if not bc and nm and nm.isdigit() and len(nm) >= 8:
                bc = nm
            if not nm and bc:
                nm = bc
            key = (bc or nm).strip().upper()
            if not key:
                continue
            # Eğer ürün bugün daha önce SEPETTE veya SIPARIS_VERILDI olarak işaretlenmişse önce eski işareti kaldır ki Yok Listesi ezilmesin
            try:
                await asyncio.to_thread(order_tracker.unmark_item, bc, nm)
            except Exception:
                pass
            new_yok_entries[key] = {
                "barkod": bc,
                "urun_adi": nm,
                "masa_adi": order_tracker.pc_name,
                "saat": now_hm,
                "stokta_var": False,
                "bulunan_depolar": [],
                "yok_depolar": ["Manuel Eklendi"],
                "manuel_eklendi": True
            }
            if bc:
                added_keys.add(bc.upper())
            if nm:
                added_keys.add(nm.upper())
            tracker_payload.append({"barcode": bc, "name": nm, "miktar": 1})
            added_count += 1

        if tracker_payload and body.get("mark_skipped", True):
            try:
                await asyncio.to_thread(order_tracker.mark_items, tracker_payload, "SIPARIS_VERILMEYECEK", "YOK_LISTESI")
            except Exception:
                pass

        scan = await asyncio.to_thread(_load_today_yok_scan, today_str)
        yok_map = {}
        for it in (scan.get("yok_items") or []):
            k = str(it.get("barkod") or it.get("urun_adi") or "").strip().upper()
            if k:
                yok_map[k] = it
        for k, val in new_yok_entries.items():
            yok_map[k] = val

        # Yok listesine yeni eklenen ürünü stoğa girenler (var_items) listesinden çıkar
        old_var = scan.get("var_items") or []
        scan["var_items"] = [
            v for v in old_var
            if str(v.get("barkod") or "").strip().upper() not in added_keys
            and str(v.get("urun_adi") or "").strip().upper() not in added_keys
        ]
        scan["yok_items"] = list(yok_map.values())
        scan["date"] = today_str
        await asyncio.to_thread(_save_today_yok_scan, scan)

        return {"success": True, "added_count": added_count, "yok_items": scan["yok_items"], "var_items": scan["var_items"]}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/today/yok-list/remove")
async def remove_from_today_yok_list_endpoint(request: Request):
    """Belirtilen ürünü (veya tüm listeyi) Yok Listesinden ve Stoğa Girenler (var_items) listesinden çıkarır."""
    import datetime
    try:
        body = await request.json()
        bc = str(body.get("barkod") or "").strip().upper()
        nm = str(body.get("urun_adi") or "").strip().upper()
        clear_mode = str(body.get("clear_mode") or "").strip().lower()
        today_str = datetime.date.today().strftime("%Y-%m-%d")
        scan = await asyncio.to_thread(_load_today_yok_scan, today_str)
        old_yok_list = scan.get("yok_items") or []
        old_var_list = scan.get("var_items") or []

        if clear_mode in ("all", "yok"):
            for y_it in old_yok_list:
                try:
                    await asyncio.to_thread(
                        order_tracker.unmark_item,
                        str(y_it.get("barkod") or "").strip(),
                        str(y_it.get("urun_adi") or "").strip()
                    )
                except Exception:
                    pass

        if clear_mode == "all":
            new_yok_list = []
            new_var_list = []
        elif clear_mode == "yok":
            new_yok_list = []
            new_var_list = old_var_list
        elif clear_mode == "var":
            new_yok_list = old_yok_list
            new_var_list = []
        else:
            def _matches_item(it: dict) -> bool:
                it_bc = str(it.get("barkod") or "").strip().upper()
                it_nm = str(it.get("urun_adi") or "").strip().upper()
                if bc and it_bc and it_bc == bc:
                    return True
                if nm and it_nm and it_nm == nm:
                    return True
                return False

            new_yok_list = [it for it in old_yok_list if not _matches_item(it)]
            new_var_list = [it for it in old_var_list if not _matches_item(it)]

        scan["yok_items"] = new_yok_list
        scan["var_items"] = new_var_list
        await asyncio.to_thread(_save_today_yok_scan, scan)
        if not clear_mode and (bc or nm) and body.get("unmark_order", True):
            try:
                await asyncio.to_thread(order_tracker.unmark_item, bc, nm)
            except Exception:
                pass
        return {"success": True, "yok_items": new_yok_list, "var_items": new_var_list}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


