# -*- coding: utf-8 -*-
"""
backend/eczanem_client.py
-------------------------
PASİF DURUMDA: Eczanem Eczane Otomasyonu entegrasyonu geçici olarak devre dışı bırakılmıştır.
Hiçbir ağ taraması, port 1433 kontrolü veya MS SQL bağlantısı gerçekleştirmez.
"""

from contextlib import contextmanager
from typing import Any, Dict, List, Optional

ECZANEM_ENABLED = False
_DISABLED_MSG = "Eczanem otomasyon entegrasyonu pasif durumdadır."


class EczanemSQLClient:
    """Pasif Eczanem istemci vekili (hiçbir veritabanı veya ağ bağlantısı kurmaz)."""

    enabled: bool = False

    @contextmanager
    def get_connection(self, *args, **kwargs):
        raise RuntimeError(_DISABLED_MSG)
        yield  # pragma: no cover

    def ping(self, *args, **kwargs) -> Dict[str, Any]:
        return {
            "success": False,
            "connected": False,
            "disabled": True,
            "kaynak": "PASIF",
            "message": _DISABLED_MSG,
        }

    def discover_eczanem_host(self, *args, **kwargs) -> Dict[str, Any]:
        return {
            "success": False,
            "found": False,
            "disabled": True,
            "message": _DISABLED_MSG,
        }

    def import_saved_credentials_to_farma_radar(self, *args, **kwargs) -> Dict[str, Any]:
        return {
            "success": False,
            "disabled": True,
            "depolar": [],
            "message": _DISABLED_MSG,
        }

    def get_product_analysis(self, *args, **kwargs) -> Dict[str, Any]:
        return {
            "found": False,
            "connected": False,
            "disabled": True,
            "kaynak": "PASIF",
            "message": _DISABLED_MSG,
        }

    def get_product_equivalents(self, *args, **kwargs) -> Dict[str, Any]:
        return {"found": False, "disabled": True, "muadiller": []}

    def get_product_vat(self, *args, **kwargs) -> Optional[float]:
        return None

    def get_bulk_stock_and_sales_map(self, *args, **kwargs) -> Dict[str, Dict[str, Any]]:
        return {}

    def get_critical_stock_sales(self, *args, **kwargs) -> List[Dict[str, Any]]:
        return []

    def get_six_month_smart_order_list(self, *args, **kwargs) -> Dict[str, Any]:
        return {
            "success": False,
            "disabled": True,
            "items": [],
            "months": [],
            "error": _DISABLED_MSG,
        }


eczanem_client = EczanemSQLClient()
