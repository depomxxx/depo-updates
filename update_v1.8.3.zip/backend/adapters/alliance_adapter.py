import asyncio
import base64
import json
import re
import time
from typing import List, Optional, Dict, Any
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu, MFKademeDetay
from backend.core.cost_calculator import CostCalculator
from backend.core.session_store import SessionStore

class AllianceAdapter(BaseDepoAdapter):
    BASE_URL = "https://esiparisv2.alliance-healthcare.com.tr/"
    MAIN_URL = "https://esiparisv2.alliance-healthcare.com.tr/Home/MainPage"

    def __init__(self, pharmacy_code: str = "", username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ALLIANCE, "Alliance Healthcare")
        self.pharmacy_code = pharmacy_code
        self.username = username
        self.password = password
        self.headless = headless
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
        self._lock = asyncio.Lock()
        self._cart_busy: int = 0
        self._search_busy: int = 0
        self._fast_cart_cache: Dict[str, Dict[str, Any]] = {}
        self._last_added_items: List[Dict[str, Any]] = []
        self._last_added_time: float = 0.0

    def _merge_last_added_items(self, new_items: List[Dict[str, Any]]) -> None:
        if not new_items:
            return
        now = time.time()
        existing = list(self._last_added_items or []) if (now - float(self._last_added_time or 0.0)) < 21600 else []
        merged: List[Dict[str, Any]] = []
        index_by_key: Dict[str, int] = {}

        def _keys_for(entry: Dict[str, Any]) -> List[str]:
            ks = []
            for field in ("urun_id", "kod", "barcode", "barkod", "id"):
                val = str(entry.get(field) or "").strip()
                if val:
                    ks.append(f"ID:{val.lstrip('0') or val}")
            nm = str(entry.get("ad") or entry.get("name") or entry.get("urun_adi") or "").strip().upper()
            if nm:
                ks.append(f"NM:{nm}")
            return ks

        for item in existing + list(new_items):
            if not isinstance(item, dict):
                continue
            keys = _keys_for(item)
            hit_idx = next((index_by_key[k] for k in keys if k in index_by_key), None)
            if hit_idx is not None:
                prev = merged[hit_idx]
                updated = dict(prev)
                for k, v in item.items():
                    if v not in (None, ""):
                        updated[k] = v
                merged[hit_idx] = updated
                for k in _keys_for(updated):
                    index_by_key[k] = hit_idx
            else:
                new_idx = len(merged)
                merged.append(dict(item))
                for k in keys:
                    index_by_key[k] = new_idx

        self._last_added_items = merged
        self._last_added_time = now

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-setuid-sandbox"]
            )
            
            session_file = SessionStore.get_session_file("alliance")
            if session_file.exists():
                try:
                    self._context = await self._browser.new_context(storage_state=str(session_file))
                except Exception:
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()
                
            self._page = await self._context.new_page()

    async def is_session_valid(self) -> bool:
        if not self._page:
            await self._init_browser()
            
        try:
            cur_url = (self._page.url or "").lower()
            if "alliance-healthcare.com.tr" in cur_url and "login" not in cur_url and "sales/cart" not in cur_url:
                is_ready = await self._page.evaluate("() => typeof AjaxPostWithoutOverlay === 'function' && !document.querySelector('#pharmacyCode')")
                if is_ready:
                    return True

            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            await self._page.wait_for_selector("#searchArea, #searchedItems", timeout=4000)
            return True
        except Exception:
            return False

    async def _login_unlocked(self) -> bool:
        """Alliance eSiparis v2'ye giriş yapar ve oturum kaydeder."""
        if not self.pharmacy_code or not self.username or not self.password:
            raise ValueError("Alliance için Eczane Kodu, Kullanıcı Adı ve Şifre zorunludur.")

        await self._init_browser()
        
        if await self.is_session_valid():
            print("[Alliance] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            return True

        print("[Alliance] Giriş sayfası açılıyor...")
        await self._page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=15000)

        await self._page.wait_for_selector("#pharmacyCode", timeout=8000)
        await self._page.fill("#pharmacyCode", str(self.pharmacy_code))
        await self._page.click("#Customer_username")
        await self._page.fill("#Customer_username", str(self.username))
        await self._page.fill("#Customer_password", str(self.password))
        
        login_result = {}

        async def handle_response(response):
            if "/Home/Login" in response.url and response.request.method == "POST":
                try:
                    data = await response.json()
                    login_result.update(data)
                except Exception:
                    pass

        self._page.on("response", handle_response)
        try:
            print("[Alliance] Giriş yapılıyor...")
            await self._page.click(".Customer_login__button")
            
            for _ in range(25):
                await asyncio.sleep(0.25)
                if login_result:
                    break

            if login_result.get("Result") is False:
                error_msg = login_result.get("Message", "Giriş başarısız oldu!")
                raise RuntimeError(f"Alliance Giriş Hatası: {error_msg}")

            await self._page.wait_for_url("**/Home/MainPage**", timeout=12000)
            await self._page.wait_for_function("() => typeof AjaxPostWithoutOverlay === 'function'", timeout=10000)
            
            session_file = SessionStore.get_session_file("alliance")
            await self._context.storage_state(path=str(session_file))
            print("[Alliance] Oturum başarıyla açıldı ve kaydedildi.")
            self.is_logged_in = True
            return True
        finally:
            try:
                self._page.remove_listener("response", handle_response)
            except Exception:
                pass

    async def login(self) -> bool:
        async with self._lock:
            return await self._login_unlocked()

    async def _ensure_ready_page(self):
        """Arama fonksiyonunun hazır olduğundan emin olur."""
        if not self._page:
            await self._init_browser()
            
        is_ready = False
        try:
            cur_u = (self._page.url or "").lower()
            if "sales/cart" not in cur_u and "order" not in cur_u:
                is_ready = await self._page.evaluate("() => typeof AjaxPostWithoutOverlay === 'function' && !document.querySelector('#pharmacyCode')")
        except Exception:
            is_ready = False

        if not is_ready:
            print("[Alliance] Sayfa hazırlanıyor...")
            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            cur_url = (self._page.url or "").lower()
            if "login" in cur_url or await self._page.evaluate("() => !!document.querySelector('#pharmacyCode')"):
                self.is_logged_in = False
                await self._login_unlocked()
            else:
                await self._page.wait_for_function("() => typeof AjaxPostWithoutOverlay === 'function'", timeout=10000)

    async def search_product(self, query: str, include_equivalents: bool = True, is_background: bool = False) -> List[DepoUrunSarti]:
        """
        Barkod veya ürün adına göre depoda arama yapar (Tek seferlik birleşik AJAX motoru).
        """
        if is_background and (getattr(self, "_cart_busy", 0) > 0 or getattr(self, "_search_busy", 0) > 0):
            return []
        if not is_background:
            self._search_busy += 1
        try:
            async with self._lock:
                if is_background and (getattr(self, "_cart_busy", 0) > 0 or getattr(self, "_search_busy", 0) > 0):
                    return []
                if not self.is_logged_in:
                    await self._login_unlocked()

                await self._ensure_ready_page()
                clean_q = str(query or "").strip()
                if not is_background:
                    print(f"[Alliance] '{clean_q}' sorgulanıyor...")

                # SearchItems + ItemsBranchDetail tek evaluate çağrısında tarayıcı içinde birleşik çalışır (0 Python-HTML gecikmesi)
                branch_data = await self._page.evaluate("""async (q) => {
                    function postNoOverlay(url, data, timeoutMs = 6500) {
                        return new Promise((resolve) => {
                            let done = false;
                            const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, timeoutMs);
                            try {
                                if (typeof $ !== 'undefined' && $.ajax) {
                                    $.ajax({
                                        url: url,
                                        type: 'POST',
                                        data: data,
                                        timeout: timeoutMs,
                                        success: function(res) { if (!done) { done = true; clearTimeout(timer); resolve(res); } },
                                        error: function() { if (!done) { done = true; clearTimeout(timer); resolve(null); } }
                                    });
                                    return;
                                }
                                AjaxPostWithoutOverlay(url, data, function(res) {
                                    if (!done) { done = true; clearTimeout(timer); resolve(res); }
                                });
                            } catch (e) {
                                if (!done) { done = true; clearTimeout(timer); resolve(null); }
                            }
                        });
                    }

                    let searchHtml = await postNoOverlay('/Sales/SearchItems', {
                        SearchText: q,
                        OnlyStock: false,
                        SearchContains: false,
                        SelectedClass: '3',
                        Sorter: 0,
                        ManufacturerID: '0',
                        WithEQ: false,
                        RequestedPage: 1,
                        BeforeSearchRequest: ''
                    });

                    function extractIds(html) {
                        if (!html || typeof html !== 'string') return [];
                        const ids = [];
                        const re = /id=["']branchdetailstring_(\\d+)["']/g;
                        let m;
                        while ((m = re.exec(html)) !== null) {
                            if (ids.length < 10) ids.push(m[1]);
                        }
                        return ids;
                    }

                    let itemIds = extractIds(searchHtml);

                    // GTIN-14 fallback: 13 haneli barkod bulunamazsa başına '0' ekleyip aynı turda dene
                    if (itemIds.length === 0 && /^\\d{13}$/.test(q)) {
                        searchHtml = await postNoOverlay('/Sales/SearchItems', {
                            SearchText: '0' + q,
                            OnlyStock: false,
                            SearchContains: false,
                            SelectedClass: '3',
                            Sorter: 0,
                            ManufacturerID: '0',
                            WithEQ: false,
                            RequestedPage: 1,
                            BeforeSearchRequest: ''
                        });
                        itemIds = extractIds(searchHtml);
                    }

                    if (itemIds.length === 0) return [];

                    const bData = await postNoOverlay('/Sales/ItemsBranchDetail', {
                        ItemIDs: itemIds.join(','),
                        NonDrugInventoryItems: ''
                    });
                    return Array.isArray(bData) ? bData : [];
                }""", clean_q)

                sonuclar: List[DepoUrunSarti] = []

                if isinstance(branch_data, list):
                    for b_item in branch_data:
                        item_id = str(b_item.get("ItemID", ""))
                        b64_detail = b_item.get("BranchItemDetailString", "")
                        if not b64_detail:
                            continue
                        try:
                            detail = json.loads(base64.b64decode(b64_detail).decode("utf-8"))
                            eq_string = b_item.get("EQString", "") or ""
                            sarti = self._parse_branch_item(detail, eq_string, clean_q)
                            sonuclar.append(sarti)

                            # Hızlı sepet önbelleğine kaydet (Sepete Ekle tıklandığında SearchItems ve ItemsBranchDetail atlanır!)
                            offers = detail.get("Offers") or []
                            if offers:
                                chosen_offer = offers[0]
                                offer_b64 = base64.b64encode(json.dumps(chosen_offer).encode("utf-8")).decode("utf-8")
                                cache_entry = {
                                    "item_id": item_id,
                                    "b64_detail": b64_detail,
                                    "offer_b64": offer_b64,
                                    "name": detail.get("Name", sarti.urun_adi),
                                    "vade": int(chosen_offer.get("DaysDue") or 30),
                                    "net_fiyat": float(chosen_offer.get("NetPrice") or sarti.net_birim_maliyet or 0.0),
                                    "has_stock": bool(detail.get("HasStock", True))
                                }
                                if item_id:
                                    self._fast_cart_cache[item_id] = cache_entry
                                bc_val = str(detail.get("Barcode") or "").strip()
                                if bc_val:
                                    self._fast_cart_cache[bc_val] = cache_entry
                                    self._fast_cart_cache[bc_val.lstrip("0")] = cache_entry
                                if clean_q.isdigit():
                                    self._fast_cart_cache[clean_q] = cache_entry
                        except Exception as e:
                            print(f"[Alliance] Ürün ayrıştırma hatası ({item_id}): {e}")

                return sonuclar
        finally:
            if not is_background:
                self._search_busy = max(0, self._search_busy - 1)

    def _parse_branch_item(self, detail: Dict[str, Any], eq_string: str, query: str) -> DepoUrunSarti:
        item_id = str(detail.get("ID", ""))
        name = detail.get("Name", "")
        barcode = detail.get("Barcode") or query
        
        has_stock = bool(detail.get("HasStock", False))
        stock_qty = int(detail.get("QA", 0) or 0)
        stok_durumu = StokDurumu.VAR if has_stock else StokDurumu.YOK

        price_tag = detail.get("PriceTag") or {}
        psf = float(price_tag.get("ListPrice") or 0.0)
        dsf_taxed = float(price_tag.get("SalesPrice") or 0.0)
        dsf_notax = float(price_tag.get("SalesPriceOutOfTaxes") or 0.0)
        dsf = dsf_notax if dsf_notax > 0 else dsf_taxed
        kdv_orani = float(price_tag.get("TaxRate") or 10.0)
        eczaci_kari = float(price_tag.get("CustomerProfitRate") or 0.0)
        is_cold = bool(detail.get("MustShipCold", False))

        # İskontolar
        kurum_isk = float(detail.get("KurumOran") or 0.0)
        ticari_isk = float(detail.get("TicariOran") or 0.0)
        ticari2_isk = float(detail.get("Ticari2Oran") or 0.0)
        web_prim = float(detail.get("WebPrimOran") or 0.0)
        deal_rate = float(detail.get("DealRate") or 0.0)
        offer_rate = float(detail.get("OfferRate") or 0.0)

        # Teklifler (Offers)
        offers = detail.get("Offers") or []
        en_iyi_vade = 30
        en_iyi_net_fiyat = 0.0
        kampanya_notu = ""
        secilen_teklif = None

        min_offer_net = 999999.0
        base_offer_net = 0.0

        if offers:
            for off in offers:
                o_net = float(off.get("NetPrice") or 0.0)
                o_min_qty = int(off.get("MinQuantity") or 1)
                o_days = int(off.get("DaysDue") or 30)

                if o_min_qty <= 1 and base_offer_net == 0.0 and o_net > 0:
                    base_offer_net = o_net

                if o_net > 0 and o_net < min_offer_net:
                    min_offer_net = o_net
                    en_iyi_vade = o_days
                    secilen_teklif = off

            if not secilen_teklif:
                secilen_teklif = offers[0]
                en_iyi_vade = int(secilen_teklif.get("DaysDue") or 30)
                min_offer_net = float(secilen_teklif.get("NetPrice") or dsf)

            en_iyi_net_fiyat = min_offer_net
            min_q = secilen_teklif.get("MinQuantity", 1)
            kampanya_notu = f"{secilen_teklif.get('Name')} (Min: {min_q} Adet, {en_iyi_vade} Gün)"

        # Açık ticari iskontoların toplamı
        toplam_ticari = ticari_isk + ticari2_isk + web_prim + deal_rate + offer_rate
        if secilen_teklif:
            off_rate = float(secilen_teklif.get("Rate") or 0.0)
            off_extra = float(secilen_teklif.get("ExtraDiscountRate") or 0.0)
            off_cash = float(secilen_teklif.get("CashDiscountRate") or 0.0)
            toplam_ticari = max(toplam_ticari, off_rate + off_extra + off_cash)

        # Eczane İskonto Çarpanı:
        # Kurum/Kamu İskontosu ve Ticari İskonto birlikte DSF'den düşülür
        # Formül: Net = DSF * (1 - Kurum / 100) * (1 - Ticari / 100)
        birlesik_isk_carpan = (1.0 - (kurum_isk / 100.0)) * (1.0 - (toplam_ticari / 100.0))
        birlesik_iskonto_yuzdesi = round((1.0 - birlesik_isk_carpan) * 100.0, 2)

        # Eğer Alliance'ın doğrudan bildirdiği teklif net fiyatı daha avantajlıysa (örn. özel kampanya)
        if dsf > 0 and en_iyi_net_fiyat > 0 and en_iyi_net_fiyat < (dsf - 0.01):
            derived_disc = round((1.0 - (en_iyi_net_fiyat / dsf)) * 100.0, 2)
            if not eq_string or eq_string.strip().upper() in ["YOK", "-", ""]:
                birlesik_iskonto_yuzdesi = max(birlesik_iskonto_yuzdesi, derived_disc)

        # MF formatlama
        mf_text = eq_string.strip() if eq_string else "YOK"

        # Maliyet motoru (Tüm kademeleri hesaplar)
        maliyet = CostCalculator.calculate(
            dsf=dsf,
            psf=psf,
            kdv_orani=kdv_orani,
            mf_str=mf_text,
            ticari_iskonto=birlesik_iskonto_yuzdesi,
            vade_gun=en_iyi_vade
        )

        final_net = maliyet.net_birim_maliyet
        if en_iyi_net_fiyat > 0 and (final_net == 0 or en_iyi_net_fiyat < final_net):
            final_net = round(en_iyi_net_fiyat, 2)

        final_net_kdvli = round(final_net * (1.0 + (kdv_orani / 100.0)), 2)

        # Eğer MF yok ama tekliflerde farklı ve daha avantajlı alım kademeleri varsa kademelere ekle
        kademeler = list(maliyet.kademeler)
        if not kademeler and len(offers) > 1:
            for off in sorted(offers, key=lambda x: int(x.get("MinQuantity") or 1)):
                q = int(off.get("MinQuantity") or 1)
                np = float(off.get("NetPrice") or 0.0)
                if q > 1 and np > 0 and np < (final_net - 0.01):
                    np_kdvli = round(np * (1.0 + (kdv_orani / 100.0)), 2)
                    off_disc = round((1.0 - (np / dsf)) * 100.0, 2) if dsf > 0 else 0.0
                    kademeler.append(MFKademeDetay(
                        alinan=q,
                        hediye=0,
                        mf_text=f"{q} Kutu",
                        net_birim_maliyet=round(np, 2),
                        net_birim_maliyet_kdvli=np_kdvli,
                        toplam_iskonto_yuzdesi=off_disc
                    ))

        # Kampanya ve vade notunu zenginleştir
        notlar = [f"{en_iyi_vade} Gün Vade"]
        if mf_text != "YOK":
            notlar.append(f"MF: {mf_text}")
        if toplam_ticari > 0:
            notlar.append(f"İsk: %{round(toplam_ticari, 2)}")
        if kurum_isk > 0:
            notlar.append(f"Kamu İsk: %{round(kurum_isk, 2)}")
        if notlar:
            kampanya_notu = " • ".join(notlar)

        return DepoUrunSarti(
            depo=DepoKodu.ALLIANCE,
            depo_adi=self.depo_adi,
            barkod=barcode,
            urun_id=item_id,
            urun_adi=name,
            stok_durumu=stok_durumu,
            stok_adedi=stock_qty if has_stock else 0,
            depocu_satis_fiyati=round(dsf, 2),
            perakende_satis_fiyati=round(psf, 2),
            kdv_orani=kdv_orani,
            mf_metni=mf_text,
            kademeler=kademeler,
            ticari_iskonto=round(toplam_ticari, 2),
            vade_gun=en_iyi_vade,
            net_birim_maliyet=round(final_net, 2),
            net_birim_maliyet_kdvli=final_net_kdvli,
            toplam_indirim_yuzdesi=round((1.0 - (final_net / dsf)) * 100.0, 2) if dsf > 0 else 0.0,
            ozel_kampanya_notu=kampanya_notu,
            soguk_zincir=is_cold,
            kamu_iskontosu=round(kurum_isk, 2),
            eczaci_kari=round(eczaci_kari, 2)
        )

    async def _add_to_cart_unlocked(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        barkod = str(kwargs.get("barkod") or "").strip()
        if len(barkod) == 14 and barkod.startswith("0"):
            barkod = barkod[1:]
        actual_id = str(urun_id or "").strip()

        # 1. HIZLI YOL: Arama sırasında önbelleğe alınmış ürün ise (SearchItems + ItemsBranchDetail atlanır, tek adımda ~80ms!)
        cached = self._fast_cart_cache.get(actual_id) or (self._fast_cart_cache.get(barkod) if barkod else None)
        if cached and cached.get("b64_detail") and cached.get("offer_b64"):
            if not cached.get("has_stock", True):
                return {"success": False, "message": "Ürün Alliance deposunda stokta yok."}

            add_resp = await self._page.evaluate("""async (param) => {
                return new Promise((resolve) => {
                    let done = false;
                    const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, 6500);
                    const finish = (res) => {
                        if (done) return;
                        done = true;
                        clearTimeout(timer);
                        if (res && res.Result && typeof RebindQuickCart === 'function') {
                            try { RebindQuickCart(); } catch(e) {}
                        }
                        resolve(res);
                    };
                    try {
                        if (typeof $ !== 'undefined' && $.ajax) {
                            $.ajax({
                                url: "/Sales/AddItemToBasket",
                                type: "POST",
                                data: {
                                    ItemString: param.itemString,
                                    OfferString: param.offerString,
                                    Quantity: param.quantity,
                                    SupplierControlParam: false
                                },
                                timeout: 6500,
                                success: finish,
                                error: () => finish(null)
                            });
                            return;
                        }
                        const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                        postFn("/Sales/AddItemToBasket", {
                            ItemString: param.itemString,
                            OfferString: param.offerString,
                            Quantity: param.quantity,
                            SupplierControlParam: false
                        }, finish);
                    } catch (e) {
                        finish(null);
                    }
                });
            }""", {
                "itemString": cached["b64_detail"],
                "offerString": cached["offer_b64"],
                "quantity": int(miktar)
            })

            if add_resp and add_resp.get("Result"):
                prod_name = cached.get("name", "Ürün")
                self._last_added_time = time.time()
                return {
                    "success": True,
                    "depo": "ALLIANCE",
                    "message": f"{prod_name} başarıyla Alliance sepetine eklendi.",
                    "urun_adi": prod_name,
                    "miktar": int(miktar),
                    "vade": cached.get("vade", 30),
                    "net_fiyat": cached.get("net_fiyat", 0.0)
                }

        # 2. YEDEK YOL: Önbellekte yoksa (veya hızlı yol başarısız olduysa) TEK JS çağrısında çöz ve ekle
        is_direct_id = actual_id.isdigit() and len(actual_id) <= 8 and not actual_id.startswith("869")
        search_target = barkod or actual_id

        single_res = await self._page.evaluate("""async (params) => {
            function postAsync(url, data, timeoutMs = 6500) {
                return new Promise((resolve) => {
                    let done = false;
                    const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, timeoutMs);
                    try {
                        if (typeof $ !== 'undefined' && $.ajax) {
                            $.ajax({
                                url: url,
                                type: 'POST',
                                data: data,
                                timeout: timeoutMs,
                                success: function(res) { if (!done) { done = true; clearTimeout(timer); resolve(res); } },
                                error: function() { if (!done) { done = true; clearTimeout(timer); resolve(null); } }
                            });
                            return;
                        }
                        const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                        postFn(url, data, function(res) { if (!done) { done = true; clearTimeout(timer); resolve(res); } });
                    } catch (e) {
                        if (!done) { done = true; clearTimeout(timer); resolve(null); }
                    }
                });
            }
            try {
                let targetId = params.isDirectId ? params.actualId : '';
                if (!targetId) {
                    const searchHtml = await postAsync('/Sales/SearchItems', {
                        SearchText: params.searchTarget,
                        OnlyStock: false,
                        SearchContains: false,
                        SelectedClass: '3',
                        Sorter: 0,
                        ManufacturerID: '0',
                        WithEQ: false,
                        RequestedPage: 1,
                        BeforeSearchRequest: ''
                    });
                    if (searchHtml && typeof searchHtml === 'string') {
                        const m = /id=["']branchdetailstring_(\\d+)["']/i.exec(searchHtml);
                        if (m && m[1]) targetId = m[1];
                    }
                }
                if (!targetId) {
                    return { success: false, message: 'Alliance deposunda ürün bulunamadı.' };
                }

                const branchData = await postAsync('/Sales/ItemsBranchDetail', {
                    ItemIDs: targetId,
                    NonDrugInventoryItems: ''
                });
                if (!branchData || !Array.isArray(branchData) || !branchData[0] || !branchData[0].BranchItemDetailString) {
                    return { success: false, message: 'Alliance ürün şube bilgisi alınamadı.' };
                }

                const b64Detail = branchData[0].BranchItemDetailString;
                let detail = null;
                try {
                    const bytes = Uint8Array.from(atob(b64Detail), c => c.charCodeAt(0));
                    detail = JSON.parse(new TextDecoder('utf-8').decode(bytes));
                } catch (_utfErr) {
                    detail = JSON.parse(atob(b64Detail));
                }
                const rawLatinDetail = JSON.parse(atob(b64Detail));
                const offers = detail.Offers || [];
                const rawOffers = rawLatinDetail.Offers || [];
                if (!offers.length) {
                    return { success: false, message: 'Ürün için geçerli kampanya veya satış şartı bulunamadı.' };
                }

                const chosenOffer = offers[0];
                let offerB64 = '';
                try {
                    if (rawOffers.length > 0) {
                        offerB64 = btoa(JSON.stringify(rawOffers[0]));
                    } else {
                        const u8 = new TextEncoder().encode(JSON.stringify(chosenOffer));
                        let bin = '';
                        for (let bi = 0; bi < u8.length; bi++) bin += String.fromCharCode(u8[bi]);
                        offerB64 = btoa(bin);
                    }
                } catch (_b64Err) {
                    const u8 = new TextEncoder().encode(JSON.stringify(chosenOffer));
                    let bin = '';
                    for (let bi = 0; bi < u8.length; bi++) bin += String.fromCharCode(u8[bi]);
                    offerB64 = btoa(bin);
                }
                const addResp = await postAsync('/Sales/AddItemToBasket', {
                    ItemString: b64Detail,
                    OfferString: offerB64,
                    Quantity: params.quantity,
                    SupplierControlParam: false
                });

                if (addResp && addResp.Result) {
                    if (typeof RebindQuickCart === 'function') {
                        try { RebindQuickCart(); } catch(e) {}
                    }
                    return {
                        success: true,
                        depo: 'ALLIANCE',
                        urun_adi: detail.Name || 'Ürün',
                        vade: chosenOffer.DaysDue || 30,
                        net_fiyat: chosenOffer.NetPrice || 0.0,
                        b64_detail: b64Detail,
                        offer_b64: offerB64,
                        item_id: targetId
                    };
                }
                return {
                    success: false,
                    message: (addResp && addResp.Message) || 'Alliance sepete ekleme reddedildi.'
                };
            } catch (e) {
                return { success: false, message: 'Alliance işlem hatası: ' + e.toString() };
            }
        }""", {
            "actualId": actual_id,
            "isDirectId": is_direct_id,
            "searchTarget": search_target,
            "quantity": int(miktar)
        })

        if single_res and single_res.get("success"):
            prod_name = single_res.get("urun_adi", "Ürün")
            resolved_item_id = str(single_res.get("item_id") or actual_id or "").strip()
            if single_res.get("b64_detail") and single_res.get("offer_b64"):
                ce = {
                    "item_id": resolved_item_id,
                    "b64_detail": single_res["b64_detail"],
                    "offer_b64": single_res["offer_b64"],
                    "name": prod_name,
                    "vade": int(single_res.get("vade") or 30),
                    "net_fiyat": float(single_res.get("net_fiyat") or 0.0),
                    "has_stock": True
                }
                if ce["item_id"]:
                    self._fast_cart_cache[ce["item_id"]] = ce
                if barkod:
                    self._fast_cart_cache[barkod] = ce
            self._merge_last_added_items([{
                "id": resolved_item_id or barkod,
                "kod": resolved_item_id,
                "urun_id": resolved_item_id,
                "barcode": barkod or "",
                "ad": prod_name,
                "name": prod_name,
                "miktar": int(miktar),
                "mf": "0",
                "birim_fiyat": float(single_res.get("net_fiyat") or 0.0),
                "tutar": round(float(single_res.get("net_fiyat") or 0.0) * int(miktar), 2)
            }])
            return {
                "success": True,
                "depo": "ALLIANCE",
                "message": f"{prod_name} başarıyla Alliance sepetine eklendi.",
                "urun_adi": prod_name,
                "urun_id": resolved_item_id,
                "miktar": int(miktar),
                "vade": single_res.get("vade", 30),
                "net_fiyat": float(single_res.get("net_fiyat") or 0.0)
            }

        return {
            "success": False,
            "message": (single_res.get("message") if single_res else "") or "Alliance sepete ekleme başarısız."
        }

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """Alliance Healthcare sepetine ürün ekler (ID veya barkod destekli, önbellek hızlandırmalı)."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def bulk_add_to_cart(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Alliance Healthcare sepetine toplu (batch/paralel) ürün ekler.
        items: [{"barcode": "...", "miktar": 1, "name": "...", "urun_id": "..."}]
        """
        if not items:
            return {
                "success": False,
                "message": "Eklenecek ürün listesi boş.",
                "total_items": 0,
                "success_count": 0,
                "failed_count": 0,
                "total_amount": 0.0,
                "items": []
            }

        self._cart_busy += 1
        try:
            async with self._lock:
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()
                await self._ensure_ready_page()

                clean_items = []
                for it in items:
                    bc = str(it.get("barcode") or it.get("barkod") or "").strip()
                    if len(bc) == 14 and bc.startswith("0"):
                        bc = bc[1:]
                    qty = int(it.get("miktar") or it.get("quantity") or 1)
                    name = str(it.get("name") or it.get("urun_adi") or "").strip()
                    u_id = str(it.get("urun_id") or "").strip()
                    cached = self._fast_cart_cache.get(u_id) or (self._fast_cart_cache.get(bc) if bc else None)
                    clean_items.append({
                        "barcode": bc,
                        "miktar": max(1, qty),
                        "name": name,
                        "urun_id": (cached.get("item_id") if cached and cached.get("item_id") else u_id),
                        "cached_b64": cached.get("b64_detail") if cached else None,
                        "cached_offer": cached.get("offer_b64") if cached else None,
                        "cached_name": cached.get("name") if cached else None,
                        "cached_vade": cached.get("vade") if cached else None,
                        "cached_price": cached.get("net_fiyat") if cached else None,
                        "cached_stock": cached.get("has_stock", True) if cached else True
                    })

                results = await self._page.evaluate("""async (items) => {
                    function postAsync(url, data, timeoutMs = 6500) {
                        return new Promise((resolve) => {
                            let done = false;
                            const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, timeoutMs);
                            try {
                                if (typeof $ !== 'undefined' && $.ajax) {
                                    $.ajax({
                                        url: url,
                                        type: 'POST',
                                        data: data,
                                        timeout: timeoutMs,
                                        success: function(res) { if (!done) { done = true; clearTimeout(timer); resolve(res); } },
                                        error: function() { if (!done) { done = true; clearTimeout(timer); resolve(null); } }
                                    });
                                    return;
                                }
                                const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                                postFn(url, data, function(res) {
                                    if (!done) { done = true; clearTimeout(timer); resolve(res); }
                                });
                            } catch (e) {
                                if (!done) { done = true; clearTimeout(timer); resolve(null); }
                            }
                        });
                    }

                    function decodeDetailUtf8(b64Str) {
                        try {
                            const bytes = Uint8Array.from(atob(b64Str), c => c.charCodeAt(0));
                            return JSON.parse(new TextDecoder('utf-8').decode(bytes));
                        } catch (_e) {
                            return JSON.parse(atob(b64Str));
                        }
                    }

                    function encodeOfferB64Safe(rawOfferObj, utfOfferObj) {
                        try {
                            if (rawOfferObj) return btoa(JSON.stringify(rawOfferObj));
                        } catch (_e) {}
                        const u8 = new TextEncoder().encode(JSON.stringify(utfOfferObj || rawOfferObj || {}));
                        let bin = '';
                        for (let bi = 0; bi < u8.length; bi++) bin += String.fromCharCode(u8[bi]);
                        return btoa(bin);
                    }

                    // 1. AŞAMA (Salt-Okunur Ön Hazırlık): Ürün ID ve Şube Kampanya bilgilerini 4'lü gruplarla hazırla (Sepet oturumuna dokunmaz!)
                    async function prepareSingleItem(item) {
                        const prep = {
                            item: item,
                            ready: false,
                            rowId: item.urun_id || '',
                            b64Detail: item.cached_b64 || '',
                            offerB64: item.cached_offer || '',
                            urunAdi: item.cached_name || item.name || '',
                            vade: item.cached_vade || 30,
                            netFiyat: item.cached_price || 0,
                            noStock: false,
                            failMessage: ''
                        };
                        try {
                            if (item.cached_b64 && item.cached_offer) {
                                if (item.cached_stock === false) {
                                    prep.noStock = true;
                                    prep.failMessage = 'Ürün Stokta Yok (Depo mevcudu 0)';
                                    return prep;
                                }
                                if (!prep.rowId) {
                                    try {
                                        const cd = decodeDetailUtf8(item.cached_b64);
                                        if (cd && (cd.ItemID || cd.Id || cd.ID)) prep.rowId = String(cd.ItemID || cd.Id || cd.ID);
                                    } catch (_e) {}
                                }
                                prep.ready = true;
                                prep.fromCache = true;
                                return prep;
                            }

                            let rowId = '';
                            const searchTarget = (item.barcode && item.barcode.trim()) ? item.barcode.trim() : (item.name || '').trim();
                            if (searchTarget) {
                                let searchHtml = await postAsync('/Sales/SearchItems', {
                                    SearchText: searchTarget,
                                    OnlyStock: false,
                                    SearchContains: false,
                                    SelectedClass: '3',
                                    Sorter: 0,
                                    ManufacturerID: '0',
                                    WithEQ: false,
                                    RequestedPage: 1,
                                    BeforeSearchRequest: ''
                                });
                                let m = /id=["']branchdetailstring_(\\d+)["']/i.exec(searchHtml || '');

                                if (!m && item.barcode && item.barcode.length === 13) {
                                    searchHtml = await postAsync('/Sales/SearchItems', {
                                        SearchText: '0' + item.barcode,
                                        OnlyStock: false,
                                        SearchContains: false,
                                        SelectedClass: '3',
                                        Sorter: 0,
                                        ManufacturerID: '0',
                                        WithEQ: false,
                                        RequestedPage: 1,
                                        BeforeSearchRequest: ''
                                    });
                                    m = /id=["']branchdetailstring_(\\d+)["']/i.exec(searchHtml || '');
                                }

                                if (!m && item.name) {
                                    const cleanWords = item.name.replace(/[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]/g, ' ').trim().split(/\\s+/).slice(0, 3).join(' ');
                                    if (cleanWords.length >= 3) {
                                        searchHtml = await postAsync('/Sales/SearchItems', {
                                            SearchText: cleanWords,
                                            OnlyStock: false,
                                            SearchContains: false,
                                            SelectedClass: '3',
                                            Sorter: 0,
                                            ManufacturerID: '0',
                                            WithEQ: false,
                                            RequestedPage: 1,
                                            BeforeSearchRequest: ''
                                        });
                                        m = /id=["']branchdetailstring_(\\d+)["']/i.exec(searchHtml || '');
                                    }
                                }

                                if (!m || !m[1]) {
                                    prep.noStock = true;
                                    prep.failMessage = 'Alliance deposunda bulunamadı (Stok yok veya kapalı)';
                                    return prep;
                                }
                                rowId = m[1];
                            } else if (item.urun_id) {
                                rowId = item.urun_id;
                            }

                            if (!rowId) {
                                prep.failMessage = 'Ürün şube ID belirlenemedi';
                                return prep;
                            }

                            const branchData = await postAsync('/Sales/ItemsBranchDetail', {
                                ItemIDs: rowId,
                                NonDrugInventoryItems: ''
                            });
                            if (!branchData || !Array.isArray(branchData) || branchData.length === 0 || !branchData[0].BranchItemDetailString) {
                                prep.failMessage = 'Şube detayı bulunamadı';
                                return prep;
                            }

                            const b64Detail = branchData[0].BranchItemDetailString;
                            const detail = decodeDetailUtf8(b64Detail);
                            const rawLatinDetail = JSON.parse(atob(b64Detail));
                            if (detail.HasStock === false) {
                                prep.noStock = true;
                                prep.failMessage = 'Ürün Stokta Yok (Depo mevcudu 0)';
                                return prep;
                            }

                            const offers = detail.Offers || [];
                            const rawOffers = rawLatinDetail.Offers || [];
                            if (!offers || offers.length === 0) {
                                prep.noStock = true;
                                prep.failMessage = 'Satış şartı / kampanya teklifi bulunamadı';
                                return prep;
                            }

                            const chosenOffer = offers[0];
                            const offerB64 = encodeOfferB64Safe(rawOffers[0], chosenOffer);
                            const price = chosenOffer.NetPrice || (detail.PriceTag ? (detail.PriceTag.SalesPriceOutOfTaxes || detail.PriceTag.SalesPrice) : 0) || 0;

                            prep.ready = true;
                            prep.rowId = String(detail.ItemID || rowId || '');
                            prep.b64Detail = b64Detail;
                            prep.offerB64 = offerB64;
                            prep.urunAdi = detail.Name || item.name;
                            prep.vade = chosenOffer.DaysDue || 30;
                            prep.netFiyat = Math.round(price * 100) / 100;
                            return prep;
                        } catch (e) {
                            prep.failMessage = 'Hazırlık hatası: ' + e.message;
                            return prep;
                        }
                    }

                    const preparedList = [];
                    const prepChunkSize = 4;
                    for (let i = 0; i < items.length; i += prepChunkSize) {
                        const chunk = items.slice(i, i + prepChunkSize);
                        const pRes = await Promise.all(chunk.map(it => prepareSingleItem(it)));
                        preparedList.push(...pRes);
                    }

                    // 2. AŞAMA (Sıralı Sepet Yazma): ASP.NET Session çakışması ve kalem kaybını %100 önlemek için AddItemToBasket tek tek sıralı gönderilir!
                    const results = [];
                    for (let i = 0; i < preparedList.length; i++) {
                        const p = preparedList[i];
                        const item = p.item;
                        const itemRes = {
                            barcode: item.barcode,
                            name: item.name,
                            miktar: item.miktar,
                            urun_id: String(p.rowId || item.urun_id || ''),
                            success: false,
                            no_stock: !!p.noStock,
                            message: p.failMessage || '',
                            urun_adi: p.urunAdi || item.name,
                            net_fiyat: p.netFiyat || 0,
                            vade: p.vade || 30,
                            toplam_tutar: 0,
                            b64_detail: p.b64Detail || '',
                            offer_b64: p.offerB64 || ''
                        };

                        if (!p.ready) {
                            results.push(itemRes);
                            continue;
                        }

                        try {
                            let addResp = await postAsync('/Sales/AddItemToBasket', {
                                ItemString: p.b64Detail,
                                OfferString: p.offerB64,
                                Quantity: item.miktar,
                                SupplierControlParam: false
                            });

                            // Önbellekten ekleme reddedildiyse (kampanya değişimi vb.) canlı şube detayını çekip anında yenile
                            if ((!addResp || !addResp.Result) && p.fromCache) {
                                const freshPrep = await prepareSingleItem({ ...item, cached_b64: null, cached_offer: null });
                                if (freshPrep.ready) {
                                    itemRes.urun_id = String(freshPrep.rowId || itemRes.urun_id || '');
                                    itemRes.urun_adi = freshPrep.urunAdi || itemRes.urun_adi;
                                    itemRes.vade = freshPrep.vade || 30;
                                    itemRes.net_fiyat = freshPrep.netFiyat || 0;
                                    itemRes.b64_detail = freshPrep.b64Detail || '';
                                    itemRes.offer_b64 = freshPrep.offerB64 || '';
                                    addResp = await postAsync('/Sales/AddItemToBasket', {
                                        ItemString: freshPrep.b64Detail,
                                        OfferString: freshPrep.offerB64,
                                        Quantity: item.miktar,
                                        SupplierControlParam: false
                                    });
                                } else {
                                    itemRes.no_stock = !!freshPrep.noStock;
                                    itemRes.message = freshPrep.failMessage || 'Şube satış şartı güncellenemedi';
                                }
                            }

                            if (addResp && addResp.Result) {
                                itemRes.success = true;
                                itemRes.message = 'Alliance sepetine eklendi';
                                itemRes.toplam_tutar = Math.round((itemRes.net_fiyat || 0) * item.miktar * 100) / 100;
                            } else if (!itemRes.message) {
                                itemRes.message = (addResp && addResp.Message) ? addResp.Message : 'Sepete ekleme reddedildi';
                            }
                        } catch (e) {
                            itemRes.message = 'İşlem hatası: ' + e.message;
                        }
                        results.push(itemRes);
                        await new Promise(r => setTimeout(r, 25));
                    }

                    if (typeof RebindQuickCart === 'function') {
                        try { RebindQuickCart(); } catch(e) {}
                    }

                    return results;
                }""", clean_items)

                # Önbelleği tazele
                for r in results:
                    if r.get("success") and r.get("b64_detail") and r.get("offer_b64"):
                        r_uid = str(r.get("urun_id") or "").strip()
                        r_bc = str(r.get("barcode") or "").strip()
                        ce = {
                            "item_id": r_uid,
                            "b64_detail": r["b64_detail"],
                            "offer_b64": r["offer_b64"],
                            "name": r.get("urun_adi") or r.get("name") or "Ürün",
                            "vade": int(r.get("vade") or 30),
                            "net_fiyat": float(r.get("net_fiyat") or 0.0),
                            "has_stock": True
                        }
                        if r_uid:
                            self._fast_cart_cache[r_uid] = ce
                        if r_bc:
                            self._fast_cart_cache[r_bc] = ce

                # 3. AŞAMA (Canlı Sepet Doğrulaması + Düşen Kalem İçin 1 Kez Sıralı Otomatik Tekrar):
                # "17 kalem eklendi görünüp sepette 15 kalem çıkması" sorununu kesin olarak engeller!
                def _norm_tr(s: str) -> str:
                    tr_m = str.maketrans("İIıŞşĞğÜüÖöÇç", "iiissgguuoocc")
                    return re.sub(r"[^a-z0-9]+", " ", str(s or "").translate(tr_m).lower()).strip()

                def _match_alliance_row(r_item: Dict[str, Any], c_items: List[Dict[str, Any]], used_idx: set) -> Optional[Dict[str, Any]]:
                    r_uid = str(r_item.get("urun_id") or "").strip().lstrip("0")
                    r_bc = str(r_item.get("barcode") or "").strip().lstrip("0")
                    # 1. Kesin ID eşleşmesi
                    for idx_c, ci in enumerate(c_items):
                        if idx_c in used_idx:
                            continue
                        ci_kod = str(ci.get("kod") or ci.get("id") or "").strip().lstrip("0")
                        if r_uid and ci_kod and r_uid == ci_kod:
                            used_idx.add(idx_c)
                            return ci
                        if r_bc and ci_kod and r_bc == ci_kod:
                            used_idx.add(idx_c)
                            return ci
                    # 2. Tam normalize isim / token eşleşmesi (her sepet satırı yalnızca 1 kez eşleşebilir!)
                    r_nm = _norm_tr(r_item.get("urun_adi") or r_item.get("name") or "")
                    if not r_nm:
                        return None
                    r_tokens = [w for w in r_nm.split() if len(w) >= 2]
                    r_nums = {w for w in r_nm.split() if w.isdigit()}
                    for idx_c, ci in enumerate(c_items):
                        if idx_c in used_idx:
                            continue
                        ci_nm = _norm_tr(ci.get("ad") or "")
                        if not ci_nm:
                            continue
                        if r_nm == ci_nm or (len(r_nm) >= 6 and (r_nm in ci_nm or ci_nm in r_nm)):
                            used_idx.add(idx_c)
                            return ci
                        ci_tokens = [w for w in ci_nm.split() if len(w) >= 2]
                        ci_nums = {w for w in ci_nm.split() if w.isdigit()}
                        if r_tokens and ci_tokens and r_tokens[0] == ci_tokens[0]:
                            if r_nums and ci_nums and not r_nums.intersection(ci_nums):
                                continue
                            common = set(r_tokens).intersection(set(ci_tokens))
                            if len(common) >= min(2, len(r_tokens), len(ci_tokens)):
                                used_idx.add(idx_c)
                                return ci
                    return None

                live_total = 0.0
                try:
                    live_cart = await self._get_cart_status_unlocked()
                    live_items = live_cart.get("items", []) or []
                    used_indices: set = set()
                    missing_for_retry = []
                    for r in results:
                        m_ci = _match_alliance_row(r, live_items, used_indices)
                        if m_ci:
                            r["_verified_ci"] = m_ci
                        elif r.get("success") or (not r.get("no_stock") and "stokta yok" not in str(r.get("message") or "").lower() and "bulunamadı" not in str(r.get("message") or "").lower()):
                            missing_for_retry.append(r)

                    if missing_for_retry:
                        retried_ok = False
                        for r in missing_for_retry:
                            try:
                                retry_res = await self._add_to_cart_unlocked(
                                    urun_id=str(r.get("urun_id") or r.get("barcode") or r.get("name") or ""),
                                    miktar=int(r.get("miktar") or 1),
                                    barkod=str(r.get("barcode") or ""),
                                    name=str(r.get("name") or "")
                                )
                                if retry_res.get("urun_id"):
                                    r["urun_id"] = str(retry_res.get("urun_id")).strip()
                                if retry_res.get("success"):
                                    r["success"] = True
                                    r["urun_adi"] = retry_res.get("urun_adi") or r.get("urun_adi") or r.get("name")
                                    retried_ok = True
                                else:
                                    r["message"] = retry_res.get("message") or r.get("message") or "Alliance sepete ekleme reddedildi."
                            except Exception:
                                pass
                        if retried_ok or missing_for_retry:
                            live_cart = await self._get_cart_status_unlocked()
                            live_items = live_cart.get("items", []) or []

                    used_final: set = set()
                    for r in results:
                        r.pop("_verified_ci", None)
                        r.pop("b64_detail", None)
                        r.pop("offer_b64", None)
                        m_ci = _match_alliance_row(r, live_items, used_final)
                        if m_ci:
                            r["success"] = True
                            if m_ci.get("kod"):
                                r["urun_id"] = str(m_ci.get("kod")).strip()
                            if m_ci.get("ad"):
                                r["urun_adi"] = m_ci.get("ad")
                            if m_ci.get("birim_fiyat"):
                                r["net_fiyat"] = float(m_ci.get("birim_fiyat") or r.get("net_fiyat") or 0.0)
                            if m_ci.get("tutar"):
                                r["toplam_tutar"] = float(m_ci.get("tutar") or r.get("toplam_tutar") or 0.0)
                        elif r.get("success") and live_cart.get("success") and not live_cart.get("timeout"):
                            r["success"] = False
                            r["toplam_tutar"] = 0.0
                            r["message"] = "Alliance canlı sepet doğrulamasında ürün sepette görülmedi (Kota/Tevzi/Şube stok kısıtı olabilir)."

                    live_total = float(live_cart.get("total_amount") or 0.0)
                except Exception:
                    for r in results:
                        r.pop("_verified_ci", None)
                        r.pop("b64_detail", None)
                        r.pop("offer_b64", None)

                success_items = [r for r in results if r.get("success")]
                failed_items = [r for r in results if not r.get("success")]
                calc_total = round(sum(float(r.get("toplam_tutar") or 0.0) for r in success_items), 2)
                total_amount = round(live_total, 2) if live_total > 0 else calc_total
                if success_items:
                    self._merge_last_added_items([
                        {
                            "id": r.get("urun_id") or r.get("barcode") or "",
                            "kod": r.get("urun_id") or "",
                            "urun_id": r.get("urun_id") or "",
                            "barcode": r.get("barcode") or "",
                            "ad": r.get("urun_adi") or r.get("name") or "",
                            "name": r.get("urun_adi") or r.get("name") or "",
                            "miktar": int(r.get("miktar") or 1),
                            "mf": "0",
                            "birim_fiyat": float(r.get("net_fiyat") or 0.0),
                            "tutar": float(r.get("toplam_tutar") or 0.0)
                        }
                        for r in success_items
                    ])

                return {
                    "success": len(success_items) > 0,
                    "depo": "ALLIANCE",
                    "message": f"Alliance sepetine {len(success_items)}/{len(items)} kalem ürün doğrulamalı olarak eklendi (Toplam: {total_amount:,.2f} ₺).",
                    "total_items": len(items),
                    "success_count": len(success_items),
                    "failed_count": len(failed_items),
                    "total_amount": total_amount,
                    "items": results
                }
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    def get_portal_urls(self) -> dict:
        """Alliance Healthcare sepet ve sipariş web arayüzü linklerini döndürür."""
        return {
            "cart_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart",
            "checkout_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart"
        }

    async def _get_cart_status_unlocked(self) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        parsed = await self._page.evaluate("""async () => {
            function parseTrFloat(raw) {
                if (!raw) return 0.0;
                const cl = String(raw).replace(/[^0-9.,-]/g, '').replace(/\\./g, '').replace(',', '.').trim();
                return parseFloat(cl) || 0.0;
            }

            function parseCartHtml(html) {
                if (!html || typeof html !== 'string') {
                    return { item_count: 0, total_amount: 0.0, declared_count: 0, items: [] };
                }
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = html;
                const rows = tempDiv.querySelectorAll('table.tbl-cart tr, table tr');
                const items = [];
                const seenKeys = new Set();

                rows.forEach(tr => {
                    const chk = tr.querySelector('input[data-basketitem], input[data-itemid], [data-basketitem]');
                    if (!chk) return;
                    const basketId = chk.getAttribute('data-basketitem') || '';
                    const itemId = chk.getAttribute('data-itemid') || '';
                    const dedup = basketId || itemId;
                    if (dedup && seenKeys.has(dedup)) return;
                    const tds = tr.querySelectorAll('td');
                    if (tds.length < 6) return;

                    let name = (tds[1]?.innerText || '').trim();
                    if (!name || /^\\d+$/.test(name)) {
                        const altLink = tr.querySelector('a[onclick*="Item"], td:nth-child(3), .item-name, .product-name');
                        if (altLink && (altLink.innerText || '').trim().length > 2) {
                            name = (altLink.innerText || '').trim();
                        }
                    }

                    let qty = 1;
                    const qtyInp = tr.querySelector('input[type="number"], input.qty, input[name*="Quantity"], input[id*="qty"], input[onchange*="Basket"]');
                    if (qtyInp && qtyInp.value) {
                        qty = parseInt(String(qtyInp.value).trim(), 10) || 1;
                    } else if (tds[5]) {
                        const td5Inp = tds[5].querySelector('input');
                        qty = parseInt((td5Inp ? td5Inp.value : tds[5].innerText || '1').trim(), 10) || 1;
                    }

                    const mf = (tds[6]?.innerText || '0').trim();
                    let unitPrice = 0.0;
                    let total = 0.0;
                    if (tds.length >= 12) {
                        unitPrice = parseTrFloat(tds[10]?.innerText || tds[9]?.innerText || '0');
                        total = parseTrFloat(tds[11]?.innerText || '0') || (qty * unitPrice);
                    } else {
                        unitPrice = parseTrFloat(tds[tds.length - 2]?.innerText || '0');
                        total = parseTrFloat(tds[tds.length - 1]?.innerText || '0') || (qty * unitPrice);
                    }

                    if (dedup) seenKeys.add(dedup);
                    items.push({
                        id: basketId,
                        kod: itemId,
                        ad: name,
                        miktar: qty,
                        mf: mf,
                        birim_fiyat: unitPrice,
                        tutar: total
                    });
                });

                const topText = tempDiv.innerText || '';
                let topTutar = 0.0;
                const match = topText.match(/Toplam[^\\d]{0,15}([\\d.,]+)\\s*TL/i) || topText.match(/Genel\\s*Toplam[^\\d]{0,15}([\\d.,]+)/i);
                if (match) {
                    topTutar = parseTrFloat(match[1]);
                }
                const sumItems = items.reduce((acc, it) => acc + (it.tutar || 0), 0);
                if (!topTutar || (sumItems > topTutar * 1.05)) {
                    topTutar = sumItems;
                }

                let declaredCount = 0;
                const cntMatch = topText.match(/(\\d+)\\s*(?:Kalem|Ürün|Çeşit)/i);
                if (cntMatch) {
                    declaredCount = parseInt(cntMatch[1], 10) || 0;
                }

                return {
                    item_count: items.length,
                    declared_count: declaredCount,
                    sum_items: sumItems,
                    total_amount: topTutar,
                    items: items
                };
            }

            function fetchAjaxHtml(url, method = 'POST', timeoutMs = 6500) {
                return new Promise((resolve) => {
                    let done = false;
                    const timer = setTimeout(() => { if (!done) { done = true; resolve(''); } }, timeoutMs);
                    try {
                        if (typeof $ !== 'undefined' && $.ajax) {
                            $.ajax({
                                url: url,
                                type: method,
                                data: {},
                                timeout: timeoutMs,
                                success: (h) => { if (!done) { done = true; clearTimeout(timer); resolve(typeof h === 'string' ? h : ''); } },
                                error: () => { if (!done) { done = true; clearTimeout(timer); resolve(''); } }
                            });
                            return;
                        }
                        fetch(url, { method: method, credentials: 'same-origin' })
                            .then(r => r.text())
                            .then(h => { if (!done) { done = true; clearTimeout(timer); resolve(h || ''); } })
                            .catch(() => { if (!done) { done = true; clearTimeout(timer); resolve(''); } });
                    } catch (_e) {
                        if (!done) { done = true; clearTimeout(timer); resolve(''); }
                    }
                });
            }

            const quickHtml = await fetchAjaxHtml('/Home/QuickCart', 'POST', 6000);
            const quickParsed = parseCartHtml(quickHtml);

            // ÖNEMLİ: QuickCart mini-dropdown 10-15 kalemde satır sınırına takılabilir veya toplam tutar > satır toplamı kalabilir!
            // Böyle bir durumda tam sepet sayfası (/Sales/Cart) HTML'ini de çekerek 17, 30, 50+ kalemin tamamını eksiksiz oku!
            let domBadgeCount = 0;
            try {
                const badgeEl = document.querySelector('#spanBasketCount, #basketItemCount, .basket-count, .cart-count');
                if (badgeEl) domBadgeCount = parseInt((badgeEl.innerText || '').replace(/\\D/g, ''), 10) || 0;
            } catch (_e) {}

            const sumDiff = Math.abs((quickParsed.total_amount || 0) - (quickParsed.sum_items || 0));
            const mayBeTruncated = (
                quickParsed.items.length >= 10 ||
                (quickParsed.declared_count > quickParsed.items.length) ||
                (domBadgeCount > quickParsed.items.length) ||
                (quickParsed.total_amount > 0 && sumDiff > 2.0)
            );

            if (mayBeTruncated) {
                const fullCartHtml = await fetchAjaxHtml('/Sales/Cart', 'GET', 6500);
                const fullParsed = parseCartHtml(fullCartHtml);
                if (fullParsed.items.length > quickParsed.items.length) {
                    if (!fullParsed.total_amount && quickParsed.total_amount) {
                        fullParsed.total_amount = quickParsed.total_amount;
                    }
                    return fullParsed;
                }
            }

            return quickParsed;
        }""")

        items = parsed.get("items", [])
        total_amount = float(parsed.get("total_amount") or 0.0)

        return {
            "success": True,
            "depo": "ALLIANCE",
            "depo_adi": self.depo_adi,
            "supported": True,
            "item_count": len(items),
            "total_amount": round(total_amount, 2),
            "items": items,
            "cart_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart",
            "checkout_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart"
        }

    async def get_cart_status(self) -> Dict[str, Any]:
        """Alliance Healthcare sepetinin anlık içeriğini ve toplam tutarını sorgular."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._get_cart_status_unlocked()
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def clear_cart(self) -> Dict[str, Any]:
        """Alliance Healthcare sepetindeki tüm ürünleri temizler."""
        self._cart_busy += 1
        try:
            async with self._lock:
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()
                await self._ensure_ready_page()

                res = await self._page.evaluate("""async () => {
                    return new Promise((resolve) => {
                        let done = false;
                        const timer = setTimeout(() => {
                            if (!done) { done = true; resolve({ success: false, message: "Alliance sepet temizleme zaman aşımı." }); }
                        }, 6500);
                        const finish = (resp) => {
                            if (done) return;
                            done = true;
                            clearTimeout(timer);
                            if (resp && resp.Result) {
                                if (typeof RebindQuickCart === 'function') {
                                    try { RebindQuickCart(); } catch(e) {}
                                }
                                resolve({ success: true, message: "Alliance sepeti başarıyla temizlendi." });
                            } else {
                                resolve({ success: false, message: (resp && resp.Message) || "Sepet temizlenemedi." });
                            }
                        };
                        try {
                            if (typeof $ !== 'undefined' && $.ajax) {
                                $.ajax({
                                    url: "/Sales/RemoveBasketItems",
                                    type: "POST",
                                    data: { Clear: true, BasketItemStrings: [] },
                                    timeout: 6500,
                                    success: finish,
                                    error: () => finish(null)
                                });
                                return;
                            }
                            const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                            if (typeof postFn !== 'function') {
                                finish(null);
                                return;
                            }
                            postFn("/Sales/RemoveBasketItems", { Clear: true, BasketItemStrings: [] }, finish);
                        } catch (e) {
                            finish(null);
                        }
                    });
                }""")
                self._last_added_items = []
                self._last_added_time = 0.0
                return res
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def finalize_order(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        """Tekli veya toplu siparişi Alliance sepetine ekler ve depoya iletir."""
        self._cart_busy += 1
        try:
            async with self._lock:
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()
                await self._ensure_ready_page()

                cart_status = await self._get_cart_status_unlocked()
                existing_items = cart_status.get("items", [])

                if urun_id:
                    u_clean = str(urun_id).strip()
                    already_in_cart = any(it.get("kod") == u_clean or it.get("id") == u_clean for it in existing_items)
                    if not already_in_cart:
                        added_res = await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
                        if not added_res.get("success"):
                            return {
                                "success": False,
                                "message": f"Ürün sepete eklenemediği için sipariş sonlandırılamadı: {added_res.get('message')}"
                            }
                        cart_status = await self._get_cart_status_unlocked()
                        existing_items = cart_status.get("items", [])

                pre_count = len(existing_items)
                if not existing_items:
                    return {"success": False, "message": "Alliance sepetinde siparişe dönüştürülecek ürün bulunamadı."}

                if len(existing_items) > 1 and not force:
                    return {
                        "success": False,
                        "need_confirmation": True,
                        "item_count": len(existing_items),
                        "items": existing_items,
                        "total_amount": cart_status.get("total_amount", 0.0),
                        "message": f"Alliance Healthcare sepetinizde önceden eklenmiş {len(existing_items)} farklı ürün bulunmaktadır (Toplam: {cart_status.get('total_amount', 0.0):,.2f} ₺). Tüm sepeti depoya göndermek için onay veriniz."
                    }

                # Alliance sepet sayfasına git (SubmitBasketRequest ve sipariş gönderme bu sayfada tanımlıdır)
                if "sales/cart" not in (self._page.url or "").lower():
                    try:
                        await self._page.goto("https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart", wait_until="domcontentloaded", timeout=10000)
                    except Exception:
                        pass

                # Alliance siparişini onayla (Çift aşamalı BasketToSalesOrder + ErrorAlert/Result ters mantık korumalı)
                res = {"success": False, "message": "Sipariş onaylanamadı."}
                try:
                    res = await self._page.evaluate("""async () => {
                        return new Promise((resolve) => {
                            let done = false;
                            const finish = (val) => {
                                if (done) return;
                                done = true;
                                clearTimeout(timer);
                                resolve(val);
                            };
                            const timer = setTimeout(() => {
                                finish({ success: false, timeout: true, message: "Zaman aşımı" });
                            }, 16000);

                            const extractOrderConfirmation = (htmlStr) => {
                                if (typeof htmlStr !== 'string') return null;
                                const mNo = htmlStr.match(/<b>\\s*(\\d+)\\s*<\\/b>\\s*numaral[ıi]\\s*sipari[şs]/i)
                                         || htmlStr.match(/(\\d{4,})\\s*numaral[ıi]\\s*sipari[şs]/i);
                                const orderNo = (mNo && mNo[1]) ? mNo[1] : '';
                                const lower = htmlStr.toLowerCase();
                                const isConfirmed = Boolean(
                                    orderNo
                                    || lower.includes('sipariş detay')
                                    || lower.includes('siparis detay')
                                    || lower.includes('order-detail')
                                    || lower.includes('/sales/orderdetail')
                                    || /numaral[ıi]\\s*sipari[şs]/i.test(htmlStr)
                                    || /sipari[şs]iniz\\s*(ba[şs]ar[ıi]yla\\s*)?(al[ıi]nm[ıi][şs]t[ıi]r|olu[şs]turulmu[şs]tur|iletilmi[şs]tir)/i.test(htmlStr)
                                );
                                if (!isConfirmed) return null;
                                return {
                                    success: true,
                                    order_confirmed: true,
                                    order_no: orderNo,
                                    message: `Alliance siparişi başarıyla depoya iletildi.${orderNo ? ' (Sipariş No: ' + orderNo + ')' : ''}`
                                };
                            };

                            const extractModalWarningText = (htmlStr) => {
                                try {
                                    const temp = document.createElement('div');
                                    temp.innerHTML = htmlStr || '';
                                    temp.querySelectorAll('script, style, button, a.btn').forEach(el => el.remove());
                                    const sel = temp.querySelector('.alert-danger, .alert-warning, .validation-summary-errors, .error, .modal-body, .modal-v2inner');
                                    const raw = ((sel ? sel.innerText : temp.innerText) || '').replace(/\\s+/g, ' ').trim();
                                    return raw.slice(0, 280);
                                } catch (e) {
                                    return '';
                                }
                            };

                            // Alliance sepet formundaki gerçek parametreleri (ShippingMethods, Note, Clone, IsDuty) topla
                            const collectFormParams = () => {
                                const isCartPage = window.location.href.toLowerCase().includes('/sales/cart');
                                const baseArea = isCartPage ? '.cartpage' : '#right-cart';
                                const noteEl = document.querySelector(`${baseArea} #orderNote`) || document.querySelector('#orderNote');
                                const cloneEl = document.querySelector(`${baseArea} #cloneAfterAfterProcessing`) || document.querySelector('#cloneAfterAfterProcessing');
                                const dutyEl = document.querySelector(`${baseArea} #ImDuty`) || document.querySelector('#ImDuty');
                                const selects = Array.from(document.querySelectorAll(`${baseArea} select[name=OrderPriority], select[name=OrderPriority]`));
                                const seen = new Set();
                                const parts = [];
                                for (const s of selects) {
                                    const val = (s.value || '').trim();
                                    const wh = (s.getAttribute('data-warehouseid') || s.dataset?.warehouseid || '').trim();
                                    const token = (wh && val && !val.includes(':')) ? `${wh}:${val}` : val;
                                    if (token && !seen.has(token)) {
                                        seen.add(token);
                                        parts.push(token);
                                    }
                                }
                                return {
                                    shippingMethods: parts.join(','),
                                    note: noteEl ? (noteEl.value || '') : '',
                                    cloneAfter: Boolean(cloneEl && cloneEl.checked),
                                    isDuty: Boolean(dutyEl && dutyEl.checked)
                                };
                            };

                            let formParams = collectFormParams();

                            const handleStep2Response = (resp2) => {
                                try {
                                    if (typeof resp2 === 'string') {
                                        const conf2 = extractOrderConfirmation(resp2);
                                        if (conf2) {
                                            finish(conf2);
                                            return;
                                        }
                                        const warn2 = extractModalWarningText(resp2);
                                        finish({
                                            success: false,
                                            needs_cart_check: true,
                                            message: warn2 || "Alliance 2. aşama sipariş onayı tamamlanamadı."
                                        });
                                        return;
                                    }
                                    // Alliance BasketToSalesOrder: n.Result === true => ErrorAlert(n.Message)!
                                    if (resp2 && resp2.Result) {
                                        finish({
                                            success: false,
                                            explicit_error: true,
                                            message: resp2.Message || "Alliance siparişi reddetti (Depo kısıtı / minimum tutar uyarısı)."
                                        });
                                        return;
                                    }
                                    if (resp2 && resp2.Result === false) {
                                        finish({
                                            success: true,
                                            needs_cart_check: true,
                                            message: resp2.Message || "Alliance siparişi işleme alındı."
                                        });
                                        return;
                                    }
                                    finish({
                                        success: false,
                                        needs_cart_check: true,
                                        message: (resp2 && resp2.Message) || "Alliance sipariş yanıtı doğrulanamadı."
                                    });
                                } catch (e2) {
                                    finish({ success: false, message: "2. aşama yanıt hatası: " + e2.toString() });
                                }
                            };

                            const handleStep1Response = (resp) => {
                                try {
                                    // DİKKAT: Alliance SubmitBasketRequest içinde `n.Result == undefined` HTML modal demektir;
                                    // `n.Result !== undefined` (özellikle `n.Result === true`) ise DOĞRUDAN ErrorAlert(n.Message) hatasıdır!
                                    if (typeof resp === 'string') {
                                        const conf1 = extractOrderConfirmation(resp);
                                        if (conf1) {
                                            finish(conf1);
                                            return;
                                        }
                                        // Eğer 2. aşama onay modalı (BasketToSalesOrder) geldiyse otomatik olarak 2. adımı çağır
                                        if (resp.includes('BasketToSalesOrder') && typeof AjaxPost === 'function') {
                                            AjaxPost(
                                                '/Sales/BasketToSalesOrder',
                                                {
                                                    Note: formParams.note,
                                                    IsDuty: formParams.isDuty,
                                                    CloneAfterAfterProcessing: formParams.cloneAfter,
                                                    ShippingMethods: formParams.shippingMethods
                                                },
                                                handleStep2Response
                                            );
                                            return;
                                        }
                                        const warnText = extractModalWarningText(resp);
                                        finish({
                                            success: false,
                                            needs_cart_check: true,
                                            message: warnText || "Alliance sepet onayı tamamlanmadı (Minimum tutar veya depo uyarısını kontrol ediniz)."
                                        });
                                        return;
                                    }
                                    if (resp && typeof resp === 'object') {
                                        finish({
                                            success: false,
                                            explicit_error: true,
                                            message: resp.Message || "Alliance siparişi onaylanamadı (Depo uyarısı)."
                                        });
                                        return;
                                    }
                                    finish({ success: false, needs_cart_check: true, message: "Sipariş onaylanamadı." });
                                } catch (e) {
                                    finish({ success: false, message: "Sipariş yanıtı işlenirken hata oluştu: " + e.toString() });
                                }
                            };

                            // Sayfanın kendi SumbitBasket() fonksiyonu varsa ShippingMethods argümanını birebir ondan yakala
                            if (typeof SumbitBasket === 'function' && typeof AjaxPost === 'function') {
                                const origSubmitReq = window.SubmitBasketRequest;
                                const origErrorAlert = window.ErrorAlert;
                                let intercepted = false;
                                try {
                                    window.ErrorAlert = function(msg) {
                                        if (!intercepted) {
                                            intercepted = true;
                                            window.SubmitBasketRequest = origSubmitReq;
                                            window.ErrorAlert = origErrorAlert;
                                            finish({ success: false, explicit_error: true, message: String(msg || 'Alliance sepet uyarısı') });
                                        }
                                    };
                                    window.SubmitBasketRequest = function(shipStr, noteVal, cloneVal, dutyVal) {
                                        intercepted = true;
                                        window.SubmitBasketRequest = origSubmitReq;
                                        window.ErrorAlert = origErrorAlert;
                                        formParams = {
                                            shippingMethods: (shipStr != null ? String(shipStr) : formParams.shippingMethods),
                                            note: (noteVal != null ? String(noteVal) : formParams.note),
                                            cloneAfter: Boolean(cloneVal),
                                            isDuty: Boolean(dutyVal)
                                        };
                                        AjaxPost(
                                            '/Sales/SubmitBasket',
                                            {
                                                Note: formParams.note,
                                                IsDuty: formParams.isDuty,
                                                CloneAfterAfterProcessing: formParams.cloneAfter,
                                                ShippingMethods: formParams.shippingMethods
                                            },
                                            handleStep1Response
                                        );
                                    };
                                    SumbitBasket();
                                    if (!intercepted) {
                                        window.SubmitBasketRequest = origSubmitReq;
                                        window.ErrorAlert = origErrorAlert;
                                        AjaxPost(
                                            '/Sales/SubmitBasket',
                                            {
                                                Note: formParams.note,
                                                IsDuty: formParams.isDuty,
                                                CloneAfterAfterProcessing: formParams.cloneAfter,
                                                ShippingMethods: formParams.shippingMethods
                                            },
                                            handleStep1Response
                                        );
                                    }
                                } catch (e) {
                                    window.SubmitBasketRequest = origSubmitReq;
                                    window.ErrorAlert = origErrorAlert;
                                    finish({ success: false, message: "Sipariş gönderme hatası: " + e.toString() });
                                }
                            } else if (typeof AjaxPost === 'function') {
                                AjaxPost(
                                    '/Sales/SubmitBasket',
                                    {
                                        Note: formParams.note,
                                        IsDuty: formParams.isDuty,
                                        CloneAfterAfterProcessing: formParams.cloneAfter,
                                        ShippingMethods: formParams.shippingMethods
                                    },
                                    handleStep1Response
                                );
                            } else if (typeof SubmitBasketRequest === 'function') {
                                SubmitBasketRequest(
                                    formParams.shippingMethods,
                                    formParams.note,
                                    formParams.cloneAfter,
                                    formParams.isDuty,
                                    handleStep1Response
                                );
                            } else {
                                const btn = document.querySelector('#btnSubmitBasket, .btn-submit-basket, button[onclick*="SubmitBasket"], button[onclick*="SumbitBasket"]');
                                if (btn) {
                                    btn.click();
                                    finish({ success: false, needs_cart_check: true, message: "Alliance sipariş butonu tetiklendi, sepet kontrol ediliyor..." });
                                } else {
                                    finish({ success: false, message: "SubmitBasketRequest fonksiyonu bulunamadı." });
                                }
                            }
                        });
                    }""")
                except Exception as nav_err:
                    print(f"[Alliance] Finalize evaluate/navigation: {nav_err}")

                # Her durumda ana sayfaya dön ve canlı sepetin gerçekten boşaldığını ZORUNLU doğrula!
                # (Ürünler hala sepette duruyorsa ASLA success=True döndürme!)
                try:
                    await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=8000)
                except Exception:
                    pass

                if pre_count > 0:
                    last_post_cart = None
                    for wait_s in (0.5, 0.9, 1.3):
                        try:
                            await asyncio.sleep(wait_s)
                            post_cart = await self._get_cart_status_unlocked()
                            if post_cart.get("success"):
                                last_post_cart = post_cart
                                if post_cart.get("item_count", -1) == 0:
                                    if not res.get("success"):
                                        res = {
                                            "success": True,
                                            "depo": "ALLIANCE",
                                            "message": "Alliance Healthcare siparişiniz başarıyla depoya iletildi ve sepet onaylandı!"
                                        }
                                    break
                                # Eğer açık bir hata (ErrorAlert / Result:true) döndüyse ilk kontrolde hemen çık
                                if res.get("explicit_error"):
                                    break
                        except Exception:
                            pass

                    # KRİTİK GÜVENLİK KİLİDİ: Sepette hala ürün varsa sipariş depoya DÜŞMEMİŞTİR!
                    if last_post_cart and last_post_cart.get("item_count", 0) > 0:
                        rem_cnt = last_post_cart.get("item_count", 0)
                        raw_msg = (res.get("message") or "").strip()
                        if (
                            not raw_msg
                            or "başarıyla" in raw_msg.lower()
                            or "iletildi" in raw_msg.lower()
                            or "işleme" in raw_msg.lower()
                            or "tetiklendi" in raw_msg.lower()
                        ):
                            raw_msg = "Minimum sepet tutarı veya depo onay kısıtı nedeniyle sipariş tamamlanmadı."
                        res = {
                            "success": False,
                            "depo": "ALLIANCE",
                            "remaining_count": rem_cnt,
                            "cart_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart",
                            "message": f"Alliance siparişi depoya DÜŞMEDİ ({raw_msg}) — Ürünler hala Alliance sepetinde bekliyor ({rem_cnt} kalem)!"
                        }

                if res.get("success"):
                    self._last_added_items = []
                    self._last_added_time = 0.0

                return res
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)




    async def close(self):
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
