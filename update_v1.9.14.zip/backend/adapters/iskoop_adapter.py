import asyncio
import json
import re
import time
from typing import List, Optional, Dict, Any
from pathlib import Path
import httpx
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.core.cost_calculator import CostCalculator
from backend.core.session_store import SessionStore, SESSIONS_DIR

class IskoopAdapter(BaseDepoAdapter):
    PORTAL_URL = "https://esube.iskoop.org/irj/portal"
    FRAMEWORK_URL = "https://esube.iskoop.org/FrameWorkT1/"

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ISKOOP, "İstanbul Eczacılar Kooperatifi (İSKOOP)")
        import os
        self.username = (username or os.environ.get("ISKOOP_USERNAME", "")).strip()
        self.password = (password or os.environ.get("ISKOOP_PASSWORD", "")).strip()
        self.headless = headless
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
        self._token: Optional[str] = None
        self._sln: str = "1"
        self._lock = asyncio.Lock()
        self._cart_busy: int = 0
        self._search_busy: int = 0
        # Barkod / Ürün ID -> 18 haneli SAP MATNR kalıcı önbelleği (Disk + RAM)
        self._matnr_cache_file: Path = SESSIONS_DIR / "iskoop_matnr_cache.json"
        self._api_token_file: Path = SESSIONS_DIR / "iskoop_api_state.json"
        self._matnr_cache: Dict[str, str] = {}
        self._hot_search_cache: Dict[str, Any] = {}
        self._http_client: Optional[httpx.AsyncClient] = None
        self._http_has_cookies: bool = False
        self._last_relogin_ts: float = 0.0
        self._last_added_items: List[Dict[str, Any]] = []
        self._last_added_time: float = 0.0
        self._load_matnr_cache()
        self._load_api_state_from_disk()

    def _load_matnr_cache(self) -> None:
        try:
            if self._matnr_cache_file.exists():
                raw = json.loads(self._matnr_cache_file.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    self._matnr_cache = {str(k).strip(): str(v).strip() for k, v in raw.items() if k and v}
        except Exception:
            self._matnr_cache = {}

    def _save_matnr_cache(self) -> None:
        try:
            if len(self._matnr_cache) > 15000:
                keys = list(self._matnr_cache.keys())[-12000:]
                self._matnr_cache = {k: self._matnr_cache[k] for k in keys}
            self._matnr_cache_file.write_text(json.dumps(self._matnr_cache, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _set_matnr_mapping(self, key: str, matnr: str) -> bool:
        k = str(key or "").strip()
        m = str(matnr or "").strip()
        if not k or not m:
            return False
        padded = m.zfill(18)
        changed = self._matnr_cache.get(k) != padded
        self._matnr_cache[k] = padded
        stripped = k.lstrip("0")
        if stripped and len(stripped) >= 8 and self._matnr_cache.get(stripped) != padded:
            self._matnr_cache[stripped] = padded
            changed = True
        return changed

    def _ensure_http_client(self) -> httpx.AsyncClient:
        if self._http_client is None or self._http_client.is_closed:
            self._http_client = httpx.AsyncClient(
                base_url="https://esube.iskoop.org",
                http2=False,
                follow_redirects=False,
                limits=httpx.Limits(max_keepalive_connections=12, max_connections=24, keepalive_expiry=60.0),
                timeout=httpx.Timeout(7.5, connect=4.0),
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                    "Accept": "application/json;charset=UTF-8",
                    "Origin": "https://esube.iskoop.org",
                    "Referer": "https://esube.iskoop.org/FrameWorkT1/",
                },
            )
        return self._http_client

    def _save_api_token_to_disk(self) -> None:
        if not self._token:
            return
        try:
            self._api_token_file.write_text(
                json.dumps({"token": self._token, "sln": self._sln or "1", "ts": time.time()}, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _load_api_state_from_disk(self) -> bool:
        try:
            if self._api_token_file.exists():
                td = json.loads(self._api_token_file.read_text(encoding="utf-8"))
                if isinstance(td, dict) and td.get("token"):
                    self._token = str(td["token"]).strip()
                    self._sln = str(td.get("sln") or "1").strip()
            state = SessionStore.load_state("iskoop")
            cookies = (state or {}).get("cookies") or []
            if not cookies:
                return False
            client = self._ensure_http_client()
            client.cookies.clear()
            cnt = 0
            for c in cookies:
                nm = c.get("name")
                val = c.get("value")
                dom = str(c.get("domain") or "esube.iskoop.org").lstrip(".")
                if nm and val is not None and "iskoop" in dom:
                    client.cookies.set(nm, val, domain=dom, path=c.get("path") or "/")
                    cnt += 1
            self._http_has_cookies = cnt > 0
            return bool(self._http_has_cookies and self._token)
        except Exception:
            self._http_has_cookies = False
            return False

    async def _sync_http_state_from_context(self) -> None:
        if self._page and not self._token:
            try:
                tok_d = await self._page.evaluate("""() => {
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = el ? el.__vue__ : null;
                    while (cur && cur.$parent) cur = cur.$parent;
                    const store = cur ? cur.$store : null;
                    const auth = (store && store.state && store.state.authentication) || {};
                    if (auth.token) {
                        const sln = (auth.challenge && auth.challenge.solution && String(auth.challenge.solution.number)) || '1';
                        return { token: auth.token, sln };
                    }
                    return null;
                }""")
                if isinstance(tok_d, dict) and tok_d.get("token"):
                    self._token = str(tok_d["token"]).strip()
                    self._sln = str(tok_d.get("sln") or "1").strip()
            except Exception:
                pass
        if self._token:
            self._save_api_token_to_disk()
        if not self._context:
            return
        try:
            cookies = await self._context.cookies()
            client = self._ensure_http_client()
            client.cookies.clear()
            cnt = 0
            for c in cookies:
                nm = c.get("name")
                val = c.get("value")
                dom = str(c.get("domain") or "esube.iskoop.org").lstrip(".")
                if nm and val is not None and "iskoop" in dom:
                    client.cookies.set(nm, val, domain=dom, path=c.get("path") or "/")
                    cnt += 1
            self._http_has_cookies = cnt > 0
        except Exception:
            pass

    def _merge_last_added_items(self, new_items: List[Dict[str, Any]]) -> None:
        import time as _t
        if not new_items:
            return
        now = _t.time()
        existing = list(self._last_added_items or []) if (now - float(self._last_added_time or 0.0)) < 21600 else []
        merged: List[Dict[str, Any]] = []
        idx_map: Dict[str, int] = {}

        def _keys(entry: Dict[str, Any]) -> List[str]:
            ks = []
            for f in ("urun_id", "matnr", "kod", "barcode", "barkod"):
                v = str(entry.get(f) or "").strip().lstrip("0")
                if v:
                    ks.append(f"ID:{v}")
            nm = str(entry.get("name") or entry.get("ad") or entry.get("urun_adi") or "").strip().upper()
            if nm:
                ks.append(f"NM:{nm}")
            return ks

        for it in existing + list(new_items):
            if not isinstance(it, dict):
                continue
            ks = _keys(it)
            hit = next((idx_map[k] for k in ks if k in idx_map), None)
            if hit is not None:
                upd = dict(merged[hit])
                for k, v in it.items():
                    if v not in (None, ""):
                        upd[k] = v
                merged[hit] = upd
                for k in _keys(upd):
                    idx_map[k] = hit
            else:
                ni = len(merged)
                merged.append(dict(it))
                for k in ks:
                    idx_map[k] = ni
        self._last_added_items = merged
        self._last_added_time = now

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-setuid-sandbox"]
            )
            
            session_file = SessionStore.get_session_file("iskoop")
            use_saved = False
            if session_file.exists():
                try:
                    raw_state = json.loads(session_file.read_text(encoding="utf-8"))
                    cookie_names = {str(c.get("name") or "") for c in (raw_state.get("cookies") or [])}
                    # SAP portal oturumu yoksa (ör. sadece original_application_url ve loginRedirectCount kaldıysa) bozuk çerezi sil
                    if "MYSAPSSO2" in cookie_names or any("JSESSION" in cn.upper() for cn in cookie_names):
                        use_saved = True
                    else:
                        SessionStore.clear("iskoop")
                except Exception:
                    SessionStore.clear("iskoop")

            if use_saved and session_file.exists():
                try:
                    self._context = await self._browser.new_context(storage_state=str(session_file))
                except Exception:
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()
                
            self._page = await self._context.new_page()

            # Ağ isteklerinden güncel oturum token'ını dinamik yakala
            def on_req(r):
                t = r.headers.get("token")
                if t:
                    changed_tok = (t != self._token)
                    self._token = t
                    self._sln = r.headers.get("sln", "1")
                    if changed_tok:
                        self._save_api_token_to_disk()
            self._page.on("request", on_req)

    async def _clear_browser_session(self):
        """Bozuk çerezleri, localStorage loginRedirectCount kilidini ve eski oturum dosyasını tamamen temizler."""
        self._token = None
        self._http_has_cookies = False
        self.is_logged_in = False
        SessionStore.clear("iskoop")
        try:
            if self._api_token_file.exists():
                self._api_token_file.unlink(missing_ok=True)
        except Exception:
            pass
        if self._context:
            try:
                await self._context.clear_cookies()
            except Exception:
                pass
        if self._page:
            try:
                await self._page.evaluate("""() => {
                    try { localStorage.clear(); } catch(e) {}
                    try { sessionStorage.clear(); } catch(e) {}
                }""")
            except Exception:
                pass

    async def is_session_valid(self) -> bool:
        if not self._page:
            await self._init_browser()
            
        try:
            cur_url = self._page.url or ""
            if "FrameWorkT1" in cur_url:
                state_check = await self._page.evaluate("""() => {
                    try { localStorage.removeItem('loginRedirectCount'); } catch(e) {}
                    const bodyTxt = (document.body && document.body.innerText) || '';
                    if (bodyTxt.includes('Oturumunuz sonlandırıldı') || document.querySelector('#logonuidfield')) {
                        return { valid: false, expiredText: true };
                    }
                    const hasDom = !!(document.querySelector('#input-99') || document.querySelector('.basket-chip') || document.querySelector("input[placeholder*='Barkod']"));
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = el ? el.__vue__ : null;
                    while (cur && cur.$parent) cur = cur.$parent;
                    const store = cur ? cur.$store : null;
                    const tok = (store && store.state && store.state.authentication && store.state.authentication.token) || '';
                    const sln = (store && store.state && store.state.authentication && store.state.authentication.challenge && store.state.authentication.challenge.solution && String(store.state.authentication.challenge.solution.number)) || '1';
                    return { valid: !!(hasDom && tok), token: tok, sln: sln };
                }""")
                if isinstance(state_check, dict) and state_check.get("valid"):
                    if state_check.get("token"):
                        self._token = state_check["token"]
                        self._sln = state_check.get("sln") or "1"
                    await self._sync_http_state_from_context()
                    return True
                if isinstance(state_check, dict) and state_check.get("expiredText"):
                    return False

            await self._page.goto(self.FRAMEWORK_URL, wait_until="domcontentloaded", timeout=15000)
            await self._page.wait_for_selector("input[placeholder*='Barkod'], #input-99, .basket-chip", timeout=6000)
            post_check = await self._page.evaluate("""() => {
                try { localStorage.removeItem('loginRedirectCount'); } catch(e) {}
                const bodyTxt = (document.body && document.body.innerText) || '';
                if (bodyTxt.includes('Oturumunuz sonlandırıldı') || document.querySelector('#logonuidfield')) {
                    return false;
                }
                return !!(document.querySelector('#input-99') || document.querySelector('.basket-chip') || document.querySelector("input[placeholder*='Barkod']"));
            }""")
            if post_check:
                await self._sync_http_state_from_context()
            return bool(post_check)
        except Exception:
            return False

    async def _login_unlocked(self, force_fresh: bool = False) -> bool:
        """İSKOOP Portalına giriş yapar (kilit içerisinden çağrılır)."""
        await self._init_browser()
        
        if not force_fresh and await self.is_session_valid():
            print("[İSKOOP] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            self._last_relogin_ts = time.time()
            return True

        if not self.username or not self.password:
            raise ValueError("İSKOOP için Kullanıcı Adı ve Şifre zorunludur.")

        # Önce bozuk/eski çerezleri ve loginRedirectCount sayacını tamamen temizle
        await self._clear_browser_session()

        print("[İSKOOP] Giriş yapılıyor...")
        pw_candidates = [str(self.password)]
        m_alpha = re.search(r"[a-zA-Z]", str(self.password))
        if m_alpha:
            idx = m_alpha.start()
            ch = str(self.password)[idx]
            alt_pw = str(self.password)[:idx] + (ch.lower() if ch.isupper() else ch.upper()) + str(self.password)[idx + 1:]
            if alt_pw not in pw_candidates:
                pw_candidates.append(alt_pw)

        login_ok = False
        for attempt_idx, pw_try in enumerate(pw_candidates):
            if attempt_idx > 0:
                await self._clear_browser_session()
            await self._page.goto(self.PORTAL_URL, wait_until="domcontentloaded", timeout=20000)
            await self._page.fill("#logonuidfield", str(self.username))
            await self._page.fill("#logonpassfield", pw_try)
            await self._page.click('input[name="login"]')
            await self._page.wait_for_load_state("domcontentloaded")

            # Sabit 2.2 sn bekleme yerine 120ms aralıklarla anlık SSO geçiş kontrolü (~1.5 sn kazanç!)
            auth_failed = True
            for _ in range(20):
                await asyncio.sleep(0.12)
                try:
                    st = await self._page.evaluate("""() => {
                        const txt = (document.body && document.body.innerText) || '';
                        const hasLoginBox = !!document.querySelector('#logonuidfield');
                        const explicitErr = txt.includes('authentication failed') || txt.includes('hatalı') || txt.includes('bulunamadı');
                        return { hasLoginBox, explicitErr };
                    }""")
                    if not st.get("hasLoginBox"):
                        auth_failed = False
                        break
                    if st.get("explicitErr"):
                        auth_failed = True
                        break
                except Exception:
                    # Sayfa yönlendirme anında context yenileniyorsa bekle
                    pass

            if not auth_failed:
                login_ok = True
                if pw_try != self.password:
                    self.password = pw_try
                break

        if not login_ok:
            await self._clear_browser_session()
            raise RuntimeError("İSKOOP Giriş Başarısız! Kullanıcı adı veya şifre hatalı.")

        try:
            await self._page.goto(self.FRAMEWORK_URL, wait_until="domcontentloaded", timeout=15000)
            await self._page.evaluate("() => { try { localStorage.removeItem('loginRedirectCount'); } catch(e) {} }")
            await self._page.wait_for_selector("input[placeholder*='Barkod'], #input-99, .basket-chip", timeout=8000)
        except Exception:
            pass

        session_file = SessionStore.get_session_file("iskoop")
        await self._context.storage_state(path=str(session_file))
        await self._sync_http_state_from_context()
        self._last_relogin_ts = time.time()
        print("[İSKOOP] Başarıyla giriş yapıldı ve oturum kaydedildi.")
        self.is_logged_in = True
        return True

    async def login(self) -> bool:
        """İSKOOP Portalına giriş yapar."""
        async with self._lock:
            return await self._login_unlocked()

    async def _ensure_ready_page(self):
        if not self._page:
            await self._init_browser()
        cur_url = self._page.url or ""
        if "FrameWorkT1" not in cur_url:
            await self._page.goto(self.FRAMEWORK_URL, wait_until="domcontentloaded", timeout=15000)
            try:
                await self._page.wait_for_selector("input[placeholder*='Barkod'], #input-99, .basket-chip", timeout=5000)
            except Exception:
                pass
        try:
            page_expired = await self._page.evaluate("""() => {
                try { localStorage.removeItem('loginRedirectCount'); } catch(e) {}
                const txt = (document.body && document.body.innerText) || '';
                return txt.includes('Oturumunuz sonlandırıldı') || !!document.querySelector('#logonuidfield');
            }""")
            if page_expired:
                await self._login_unlocked(force_fresh=True)
        except Exception:
            pass
        if not self._token:
            try:
                tok_info = await self._page.evaluate("""async () => {
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = el ? el.__vue__ : null;
                    while (cur && cur.$parent) cur = cur.$parent;
                    const store = cur ? cur.$store : null;
                    if (store && store.state && store.state.authentication && store.state.authentication.token) {
                        const auth = store.state.authentication;
                        const sln = (auth.challenge && auth.challenge.solution && String(auth.challenge.solution.number)) || '1';
                        return { token: auth.token, sln: sln };
                    }
                    if (store) {
                        try {
                            await Promise.race([
                                store.dispatch('basket/fetchBaskets', { basketOwnerType: 'T' }),
                                new Promise(r => setTimeout(r, 3500))
                            ]);
                        } catch(e) {}
                    }
                    return null;
                }""")
                if tok_info and tok_info.get("token"):
                    self._token = tok_info["token"]
                    self._sln = tok_info.get("sln") or "1"
                    await self._sync_http_state_from_context()
            except Exception:
                pass
            if not self._token:
                try:
                    await self._login_unlocked(force_fresh=True)
                except Exception:
                    pass

    @staticmethod
    def _parse_iskoop_http_resp(resp: httpx.Response) -> Any:
        if resp.status_code in (301, 302, 303, 307, 308, 401, 403):
            return {"_session_expired": True}
        loc = str(resp.headers.get("location") or "").lower()
        if "irj/portal" in loc or "login" in loc:
            return {"_session_expired": True}
        raw = (resp.text or "").strip()
        if not raw:
            return None
        if raw.startswith("<") or "logonuidfield" in raw or "Oturumunuz sonlandırıldı" in raw:
            return {"_session_expired": True}
        if resp.status_code >= 400:
            return None
        try:
            return json.loads(raw)
        except Exception:
            return None

    async def _search_via_httpx(
        self,
        search_queries: List[str],
        target_barcode: str,
        stripped_bc: str,
        name_tokens: List[str],
        cached_matnr: Optional[str],
    ) -> Any:
        """
        Tarayıcı kilidine (self._lock) girmeden keep-alive HTTP havuzu üzerinden
        SAP RFC (mat/ms ve mat/sm) sorgusunu paralel ve anlık çalıştırır.
        """
        if (not self._http_has_cookies or not self._token) and not self._load_api_state_from_disk():
            return {"_need_login": True}

        client = self._ensure_http_client()
        tok = self._token or ""
        sln = self._sln or "1"
        if not tok:
            return {"_need_login": True}

        h_get = {"accept": "application/json;charset=UTF-8", "token": tok, "sln": sln}
        h_post = {"accept": "application/json;charset=UTF-8", "content-type": "application/json", "token": tok, "sln": sln}
        discovered: Dict[str, str] = {}

        async def _fetch_detail(matnr_val: str) -> Any:
            padded = str(matnr_val).strip().zfill(18)
            r2 = await client.post(f"/MainService/api/rfc/mat/ms?MATNR={padded}", headers=h_post, content="{}")
            d2 = self._parse_iskoop_http_resp(r2)
            if not d2:
                return None
            if isinstance(d2, dict) and d2.get("_session_expired"):
                return {"_session_expired": True}
            mk = d2.get("EP_S_MALZEME_KARTI") or {}
            if not mk.get("MATNR") and padded:
                mk["MATNR"] = padded
            if mk.get("BARKOD") and mk.get("MATNR"):
                discovered[str(mk["BARKOD"]).strip()] = str(mk["MATNR"]).strip()
            return d2

        # A) Kalıcı disk/RAM önbelleğinde MATNR varsa TEK İSTEKTE doğrudan çek!
        if cached_matnr:
            direct_d = await _fetch_detail(cached_matnr)
            if isinstance(direct_d, dict) and direct_d.get("_session_expired"):
                return {"_session_expired": True}
            if isinstance(direct_d, dict) and (direct_d.get("EP_S_MALZEME_KARTI") or {}).get("MAKTX"):
                return {"data": direct_d, "discovered": discovered}

        # B) MATNR henüz bilinmiyorsa mat/sm ile çöz ve kalıcı önbelleğe yaz
        sem = asyncio.Semaphore(8)
        for q_str in search_queries:
            is_bc_q = q_str.isdigit() and 8 <= len(q_str) <= 14
            r1 = await client.get("/MainService/api/rfc/mat/sm", params={"ST": q_str, "TYP": "3"}, headers=h_get)
            d1 = self._parse_iskoop_http_resp(r1)
            if isinstance(d1, dict) and d1.get("_session_expired"):
                return {"_session_expired": True}
            if not isinstance(d1, dict):
                continue
            mat_list = list(d1.get("ET_MAKTX") or [])
            if not mat_list:
                continue

            if is_bc_q and len(mat_list) == 1 and mat_list[0].get("MATNR"):
                d2 = await _fetch_detail(mat_list[0]["MATNR"])
                if isinstance(d2, dict) and d2.get("_session_expired"):
                    return {"_session_expired": True}
                if isinstance(d2, dict) and (d2.get("EP_S_MALZEME_KARTI") or {}).get("MAKTX"):
                    return {"data": d2, "discovered": discovered}

            if target_barcode:
                if len(name_tokens) > 1:
                    def _score(m_obj: Dict[str, Any]) -> int:
                        mx = str(m_obj.get("MAKTX") or "").upper()
                        return sum(1 for t in name_tokens if t in mx)
                    mat_list.sort(key=_score, reverse=True)

                candidates = [it.get("MATNR") for it in mat_list[:18] if it.get("MATNR")]
                for i in range(0, len(candidates), 8):
                    chunk = candidates[i:i + 8]
                    async def _guarded_detail(mv: str):
                        async with sem:
                            return await _fetch_detail(mv)
                    chunk_res = await asyncio.gather(*[_guarded_detail(mv) for mv in chunk])
                    for d2 in chunk_res:
                        if isinstance(d2, dict) and d2.get("_session_expired"):
                            return {"_session_expired": True}
                        if isinstance(d2, dict) and d2.get("EP_S_MALZEME_KARTI"):
                            found_bc = str(d2["EP_S_MALZEME_KARTI"].get("BARKOD") or "").strip()
                            if found_bc == target_barcode or (stripped_bc and found_bc.lstrip("0") == stripped_bc):
                                return {"data": d2, "discovered": discovered}
            else:
                first_m = mat_list[0].get("MATNR")
                if not first_m:
                    continue
                d2 = await _fetch_detail(first_m)
                if isinstance(d2, dict) and d2.get("_session_expired"):
                    return {"_session_expired": True}
                if isinstance(d2, dict):
                    return {"data": d2, "discovered": discovered}

        return {"items": [], "discovered": discovered}

    async def search_product(self, query: str, include_equivalents: bool = True, is_background: bool = False) -> List[DepoUrunSarti]:
        """İSKOOP'ta ürün ara ve şartları getir (Kilitsiz HTTPX + Kalıcı Disk MATNR Önbellekli Hızlı Motor)."""
        if is_background and getattr(self, "_cart_busy", 0) > 0:
            return []

        clean_q = str(query or "").strip()
        if len(clean_q) == 14 and clean_q.startswith("0"):
            clean_q = clean_q[1:]
        if not clean_q:
            return []

        now_ts = time.time()
        hot = self._hot_search_cache.get(clean_q)
        if hot and (now_ts - hot[0]) < 20.0:
            return [r.model_copy(deep=True) for r in hot[1]]

        if not is_background:
            self._search_busy += 1
        try:
            if not is_background:
                print(f"[İSKOOP] '{clean_q}' sorgulanıyor...")

            target_barcode = clean_q if (clean_q.isdigit() and len(clean_q) >= 8) else ""
            stripped_bc = target_barcode.lstrip("0") if target_barcode else ""
            fallback_word = ""
            name_tokens: List[str] = []

            if target_barcode:
                try:
                    from backend.catalog import catalog
                    cp = catalog.get_by_barcode(target_barcode)
                    if cp and cp.get("name"):
                        words = re.sub(r'[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]', ' ', cp["name"]).strip().split()
                        if words:
                            fallback_word = words[0].upper()
                            name_tokens = [w.upper() for w in words if len(w) >= 2]
                except Exception:
                    pass

            cached_matnr = (
                self._matnr_cache.get(clean_q)
                or (self._matnr_cache.get(target_barcode) if target_barcode else None)
                or (self._matnr_cache.get(stripped_bc) if stripped_bc else None)
            )

            search_queries = []
            if target_barcode:
                search_queries.append(target_barcode)
                if stripped_bc and stripped_bc != target_barcode:
                    search_queries.append(stripped_bc)
                if fallback_word and fallback_word not in search_queries:
                    search_queries.append(fallback_word)
            else:
                search_queries.append(clean_q)

            # 1. KİLİTSİZ (LOCK-FREE) KEEP-ALIVE HTTPX HIZLI YOLU
            try:
                http_res = await self._search_via_httpx(
                    search_queries=search_queries,
                    target_barcode=target_barcode,
                    stripped_bc=stripped_bc,
                    name_tokens=name_tokens,
                    cached_matnr=cached_matnr,
                )
                if isinstance(http_res, dict) and (http_res.get("_need_login") or http_res.get("_session_expired")):
                    req_ts = time.time()
                    async with self._lock:
                        if self._last_relogin_ts < (req_ts - 3.0) or not self._token or not self._http_has_cookies:
                            if http_res.get("_session_expired"):
                                print("[İSKOOP] HTTP oturum/token yenileniyor...")
                            await self._login_unlocked(force_fresh=bool(http_res.get("_session_expired")))
                            await self._ensure_ready_page()
                            await self._sync_http_state_from_context()
                    http_res = await self._search_via_httpx(
                        search_queries=search_queries,
                        target_barcode=target_barcode,
                        stripped_bc=stripped_bc,
                        name_tokens=name_tokens,
                        cached_matnr=cached_matnr,
                    )

                if isinstance(http_res, dict):
                    matnr_dirty = False
                    if isinstance(http_res.get("discovered"), dict):
                        for bc_k, mat_v in http_res["discovered"].items():
                            if self._set_matnr_mapping(bc_k, mat_v):
                                matnr_dirty = True
                    if matnr_dirty:
                        self._save_matnr_cache()
                    if http_res.get("data"):
                        parsed_fast = self._parse_iskoop_detail(http_res["data"], clean_q)
                        if parsed_fast:
                            self._hot_search_cache[clean_q] = (time.time(), parsed_fast)
                        return parsed_fast
                    if "items" in http_res and len(http_res["items"]) == 0:
                        return []
            except Exception as http_err:
                if not is_background:
                    print(f"[İSKOOP] Hızlı HTTP arama uyarısı ({clean_q}), tarayıcı yedeğine geçiliyor: {http_err}")

            # 2. PLAYWRIGHT TARAYICI YEDEK YOLU
            async with self._lock:
                if is_background and getattr(self, "_cart_busy", 0) > 0:
                    return []
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()

                await self._ensure_ready_page()

                js_iskoop_search = '''async (info) => {
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = el ? el.__vue__ : null;
                    while (cur && cur.$parent) cur = cur.$parent;
                    const store = cur ? cur.$store : null;
                    const auth = (store && store.state && store.state.authentication) || {};
                    const activeToken = auth.token || info.token || '';
                    const activeSln = (auth.challenge && auth.challenge.solution && String(auth.challenge.solution.number)) || info.sln || '1';
                    if (!activeToken) return { _session_expired: true };

                    const headersGet = {
                        'accept': 'application/json;charset=UTF-8',
                        'token': activeToken,
                        'sln': activeSln
                    };
                    const headersPost = {
                        'accept': 'application/json;charset=UTF-8',
                        'content-type': 'application/json',
                        'token': activeToken,
                        'sln': activeSln
                    };
                    const discovered = {};

                    async function fetchWithTimeout(url, opts, timeoutMs = 4500) {
                        const ctrl = new AbortController();
                        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
                        try {
                            return await fetch(url, { ...opts, signal: ctrl.signal });
                        } finally {
                            clearTimeout(timer);
                        }
                    }

                    async function parseJsonOrExpired(resp) {
                        if (!resp) return null;
                        if (resp.status === 401 || resp.status === 403 || resp.redirected || (resp.url && (resp.url.includes('irj/portal') || resp.url.toLowerCase().includes('login')))) {
                            return { _session_expired: true };
                        }
                        const raw = await resp.text();
                        if (!raw) return null;
                        const trimmed = raw.trim();
                        if (trimmed.startsWith('<') || trimmed.includes('logonuidfield') || trimmed.includes('Oturumunuz sonlandırıldı')) {
                            return { _session_expired: true };
                        }
                        if (!resp.ok) return null;
                        try {
                            return JSON.parse(trimmed);
                        } catch (e) {
                            return null;
                        }
                    }

                    async function fetchDetail(matnr) {
                        const r2 = await fetchWithTimeout('/MainService/api/rfc/mat/ms?MATNR=' + encodeURIComponent(matnr), {
                            method: 'POST',
                            headers: headersPost,
                            body: '{}'
                        }, 4500);
                        const d2 = await parseJsonOrExpired(r2);
                        if (!d2) return null;
                        if (d2._session_expired) return { _session_expired: true };
                        const mk = d2.EP_S_MALZEME_KARTI || {};
                        if (!mk.MATNR && matnr) mk.MATNR = matnr;
                        if (mk.BARKOD && mk.MATNR) {
                            discovered[mk.BARKOD] = mk.MATNR;
                        }
                        return d2;
                    }

                    try {
                        if (info.cachedMatnr) {
                            const directData = await fetchDetail(info.cachedMatnr);
                            if (directData && directData._session_expired) return { _session_expired: true };
                            if (directData && directData.EP_S_MALZEME_KARTI && directData.EP_S_MALZEME_KARTI.MAKTX) {
                                return { data: directData, discovered, token: activeToken, sln: activeSln };
                            }
                        }

                        for (const qStr of (info.queries || [])) {
                            const isBcQuery = /^\\d{8,14}$/.test(qStr);
                            const r1 = await fetchWithTimeout('/MainService/api/rfc/mat/sm?ST=' + encodeURIComponent(qStr) + '&TYP=3', {
                                headers: headersGet
                            }, 4500);
                            const d1 = await parseJsonOrExpired(r1);
                            if (d1 && d1._session_expired) {
                                return { _session_expired: true };
                            }
                            if (!d1) continue;
                            let matList = d1.ET_MAKTX || [];
                            if (matList.length === 0) continue;

                            if (isBcQuery && matList.length === 1 && matList[0].MATNR) {
                                const d2 = await fetchDetail(matList[0].MATNR);
                                if (d2 && d2._session_expired) return { _session_expired: true };
                                if (d2 && d2.EP_S_MALZEME_KARTI && d2.EP_S_MALZEME_KARTI.MAKTX) {
                                    return { data: d2, discovered, token: activeToken, sln: activeSln };
                                }
                            }

                            if (info.barcode) {
                                const tokens = info.tokens || [];
                                if (tokens.length > 1) {
                                    matList = matList.slice().sort((a, b) => {
                                        const ma = String(a.MAKTX || '').toUpperCase();
                                        const mb = String(b.MAKTX || '').toUpperCase();
                                        let sa = 0, sb = 0;
                                        for (const t of tokens) {
                                            if (ma.includes(t)) sa++;
                                            if (mb.includes(t)) sb++;
                                        }
                                        return sb - sa;
                                    });
                                }

                                const maxCheck = Math.min(matList.length, 18);
                                const chunkSize = 6;
                                for (let i = 0; i < maxCheck; i += chunkSize) {
                                    const chunk = matList.slice(i, i + chunkSize);
                                    const chunkResults = await Promise.all(chunk.map(it => fetchDetail(it.MATNR)));
                                    for (const d2 of chunkResults) {
                                        if (d2 && d2._session_expired) return { _session_expired: true };
                                        if (d2 && d2.EP_S_MALZEME_KARTI) {
                                            const foundBc = String(d2.EP_S_MALZEME_KARTI.BARKOD || '').trim();
                                            if (foundBc === info.barcode || foundBc.replace(/^0+/, '') === info.strippedBarcode) {
                                                return { data: d2, discovered, token: activeToken, sln: activeSln };
                                            }
                                        }
                                    }
                                }
                            } else {
                                const matnr = matList[0].MATNR;
                                if (!matnr) continue;
                                const d2 = await fetchDetail(matnr);
                                if (d2 && d2._session_expired) return { _session_expired: true };
                                if (d2) return { data: d2, discovered, token: activeToken, sln: activeSln };
                            }
                        }
                        return { items: [], discovered, token: activeToken, sln: activeSln };
                    } catch (e) {
                        return { error: e.toString(), discovered };
                    }
                }'''

                try:
                    payload = {
                        "queries": search_queries,
                        "barcode": target_barcode,
                        "strippedBarcode": stripped_bc,
                        "tokens": name_tokens,
                        "cachedMatnr": cached_matnr,
                        "token": self._token or "",
                        "sln": self._sln or "1"
                    }
                    res_api = await self._page.evaluate(js_iskoop_search, payload)

                    if isinstance(res_api, dict) and res_api.get("_session_expired"):
                        print("[İSKOOP] Oturum veya token süresi dolmuş, otomatik yenileniyor...")
                        await self._login_unlocked(force_fresh=True)
                        await self._ensure_ready_page()
                        payload["token"] = self._token or ""
                        payload["sln"] = self._sln or "1"
                        res_api = await self._page.evaluate(js_iskoop_search, payload)

                    if isinstance(res_api, dict):
                        if res_api.get("token"):
                            self._token = res_api["token"]
                            self._sln = res_api.get("sln") or "1"
                            self._save_api_token_to_disk()
                        matnr_dirty = False
                        if isinstance(res_api.get("discovered"), dict):
                            for bc_k, mat_v in res_api["discovered"].items():
                                if self._set_matnr_mapping(bc_k, mat_v):
                                    matnr_dirty = True
                        if matnr_dirty:
                            self._save_matnr_cache()

                        if res_api.get("data"):
                            parsed_pw = self._parse_iskoop_detail(res_api["data"], clean_q)
                            if parsed_pw:
                                self._hot_search_cache[clean_q] = (time.time(), parsed_pw)
                            return parsed_pw
                        elif "items" in res_api and len(res_api["items"]) == 0:
                            return []
                except Exception as e:
                    print(f"[İSKOOP] Hızlı API arama uyarısı: {e}, UI aramasına geçiliyor...")

                # 3. UI Arama Fallback
                captured_ms = {}
                ms_event = asyncio.Event()
                async def on_response(res):
                    if "mat/ms" in res.url:
                        try:
                            captured_ms["data"] = await res.json()
                            ms_event.set()
                        except Exception:
                            pass

                self._page.on("response", on_response)

                try:
                    try:
                        await self._page.evaluate("() => document.querySelectorAll('.v-overlay--active').forEach(el => el.remove())")
                    except Exception:
                        pass

                    search_input = await self._page.wait_for_selector('input[placeholder*="Barkod"], #input-99', timeout=4000)
                    await search_input.fill(clean_q)
                    await search_input.press("Enter")

                    try:
                        await asyncio.wait_for(ms_event.wait(), timeout=2.5)
                    except asyncio.TimeoutError:
                        pass

                    if "data" not in captured_ms:
                        return []

                    detail = captured_ms["data"]
                    parsed_ui = self._parse_iskoop_detail(detail, clean_q)
                    if parsed_ui:
                        self._hot_search_cache[clean_q] = (time.time(), parsed_ui)
                    return parsed_ui
                except Exception as e:
                    print(f"[İSKOOP] Arama hatası: {e}")
                    return []
                finally:
                    try:
                        self._page.remove_listener("response", on_response)
                    except Exception:
                        pass
        finally:
            if not is_background:
                self._search_busy = max(0, self._search_busy - 1)

    def _parse_iskoop_detail(self, detail: Dict[str, Any], query: str) -> List[DepoUrunSarti]:
        mat_kart = detail.get("EP_S_MALZEME_KARTI") or {}
        vwerk = detail.get("EP_S_VWERK") or {}
        baremler = detail.get("EP_T_BAREM") or []
        klasm = detail.get("EP_T_KLASM") or []

        ad = mat_kart.get("MAKTX", "")
        if not ad:
            return []

        barkod = str(mat_kart.get("BARKOD") or query).strip()
        raw_matnr = str(mat_kart.get("MATNR", "")).strip()
        matnr = raw_matnr.lstrip("0")

        # Kalıcı sepet ve arama önbelleğine kaydet
        if raw_matnr:
            dirty = False
            if barkod and self._set_matnr_mapping(barkod, raw_matnr):
                dirty = True
            if matnr and self._set_matnr_mapping(matnr, raw_matnr):
                dirty = True
            if query and str(query).strip().isdigit() and self._set_matnr_mapping(str(query).strip(), raw_matnr):
                dirty = True
            if dirty:
                self._save_matnr_cache()

        psf = float(mat_kart.get("PSF") or 0.0)
        dsf = float(mat_kart.get("DSF") or 0.0)
        if dsf == 0.0 and psf > 0:
            dsf = round(psf * 0.7102, 2)
        kdv_orani = float(mat_kart.get("KDV") or 10.0)
        kamu_iskontosu = float(str(mat_kart.get("KIST") or 0.0).replace(",", "."))
        eczaci_kari = float(str(mat_kart.get("ECKAR") or 0.0).replace(",", "."))
        esdeger_kodu = str(mat_kart.get("ZZSES") or "").strip() or None

        # Stok durumu
        stok_mevcut = vwerk.get("STOK_MEVCUT") or ""
        stok_durumu = StokDurumu.VAR if stok_mevcut in ["T", "X", "1", "Var"] else StokDurumu.YOK
        if not hasattr(self, "_stock_cache"):
            self._stock_cache = {}
        is_in_stock = (stok_durumu == StokDurumu.VAR)
        if barkod:
            self._stock_cache[barkod] = is_in_stock
        if matnr:
            self._stock_cache[matnr] = is_in_stock

        if not klasm:
            klasm = [{"KLASM": "030", "VADE_ADI": "30 Gün", "DSF": dsf, "NETFIYAT": dsf, "ZTC1": 0.0}]

        sonuclar: List[DepoUrunSarti] = []

        # Her bir ödeme seçeneğini (KLASM) ayrı bir şart olarak değerlendir (90 Gün Vade & Kredi Kartı)
        for k in klasm:
            k_klasm = str(k.get("KLASM", "")).strip()
            vade_adi = str(k.get("VADE_ADI", "")).strip()

            is_kk = ("Kredi Kartı" in vade_adi or "Peşin" in vade_adi or "Online" in vade_adi or k_klasm == "004")
            vade = 0 if is_kk else 30
            if not is_kk:
                v_match = re.search(r"\d+", vade_adi)
                if v_match:
                    vade = int(v_match.group(0))

            # İsimlendirme: Tek şart varsa "İSKOOP", çoklu şart varsa "İSKOOP (Kredi Kartı)" / "İSKOOP (90 Gün Vade)"
            if len(klasm) > 1:
                if is_kk:
                    depo_gorunen_ad = "İSKOOP (Kredi Kartı)"
                else:
                    depo_gorunen_ad = f"İSKOOP ({vade} Gün Vade)"
            else:
                depo_gorunen_ad = self.depo_adi

            # Bu KLASM'a ait baremleri filtrele
            matching_baremler = [b for b in baremler if str(b.get("KLASM", "")).strip() == k_klasm]
            if not matching_baremler and len(klasm) == 1:
                matching_baremler = baremler

            k_dsf = float(k.get("DSF") or dsf)
            if k_dsf == 0.0:
                k_dsf = dsf

            k_net = float(k.get("NETFIYAT") or k_dsf)
            en_iyi_net = k_net
            ticari_iskonto = 0.0

            # 1. k içinden iskonto (ZTC1, TEXT_ZTC)
            k_ztc1 = float(str(k.get("ZTC1") or 0).replace(",", "."))
            k_text_ztc = str(k.get("TEXT_ZTC") or "").replace(",", ".").strip()
            if k_ztc1 > 0:
                ticari_iskonto = max(ticari_iskonto, k_ztc1)
            elif k_text_ztc.replace(".", "", 1).isdigit() and float(k_text_ztc) > 0:
                ticari_iskonto = max(ticari_iskonto, float(k_text_ztc))

            # 2. k_net vs k_dsf
            if k_dsf > 0 and k_net > 0 and k_net < (k_dsf - 0.01):
                isk_from_knet = round((1.0 - (k_net / k_dsf)) * 100.0, 2)
                ticari_iskonto = max(ticari_iskonto, isk_from_knet)

            # 3. Baremleri tara
            mf_set = set()
            for b in matching_baremler:
                b_adi = str(b.get("BAREM_ADI", "")).strip()
                if "+" in b_adi:
                    mf_set.add(b_adi.replace(" ", ""))

                b_isk = float(str(b.get("ZTC8_ISK") or 0).replace(",", "."))
                if b_isk > 0:
                    ticari_iskonto = max(ticari_iskonto, b_isk)

                b_nf = float(b.get("NETFIYAT") or 0.0)
                if k_dsf > 0 and b_nf > 0 and b_nf < (k_dsf - 0.01):
                    isk_from_bnf = round((1.0 - (b_nf / k_dsf)) * 100.0, 2)
                    ticari_iskonto = max(ticari_iskonto, isk_from_bnf)

                bf = float(b.get("BIRIMFIYAT") or 0.0)
                fiyat_aday = bf if bf > 0 else b_nf
                if fiyat_aday > 0:
                    if en_iyi_net == 0 or fiyat_aday < en_iyi_net:
                        en_iyi_net = fiyat_aday

            mf_text = " / ".join(sorted(list(mf_set))) if mf_set else "YOK"

            # 4. MF ve ticari iskonto korelasyonu (MF varken de iskonto kontrolü)
            pairs = CostCalculator.parse_mf_pairs(mf_text)
            best_mf_carpan = min((a / (a + h)) for a, h in pairs) if pairs else 1.0
            expected_net_mf = k_dsf * best_mf_carpan

            if k_dsf > 0 and en_iyi_net > 0 and expected_net_mf > 0:
                if en_iyi_net < (expected_net_mf - 0.05):
                    derived_isk = round((1.0 - (en_iyi_net / expected_net_mf)) * 100.0, 2)
                    ticari_iskonto = max(ticari_iskonto, derived_isk)

            maliyet = CostCalculator.calculate(
                dsf=k_dsf if k_dsf > 0 else en_iyi_net,
                psf=psf,
                kdv_orani=kdv_orani,
                mf_str=mf_text,
                ticari_iskonto=ticari_iskonto,
                vade_gun=vade
            )

            final_net = min(en_iyi_net, maliyet.net_birim_maliyet) if (en_iyi_net > 0 and maliyet.net_birim_maliyet > 0) else maliyet.net_birim_maliyet
            final_net_kdvli = round(final_net * (1.0 + (kdv_orani / 100.0)), 2)

            notlar = [f"{vade} Gün Vade" if vade > 0 else "Peşin / Kredi Kartı"]
            if mf_text != "YOK":
                notlar.append(f"MF: {mf_text}")
            if ticari_iskonto > 0:
                notlar.append(f"İsk: %{ticari_iskonto}")

            sarti = DepoUrunSarti(
                depo=DepoKodu.ISKOOP,
                depo_adi=depo_gorunen_ad,
                barkod=barkod,
                urun_id=matnr,
                urun_adi=ad,
                esdeger_kodu=esdeger_kodu,
                stok_durumu=stok_durumu,
                stok_adedi=None,
                depocu_satis_fiyati=round(k_dsf, 2),
                perakende_satis_fiyati=round(psf, 2),
                kdv_orani=kdv_orani,
                mf_metni=mf_text,
                kademeler=maliyet.kademeler,
                ticari_iskonto=round(ticari_iskonto, 2),
                vade_gun=vade,
                net_birim_maliyet=round(final_net, 2),
                net_birim_maliyet_kdvli=final_net_kdvli,
                toplam_indirim_yuzdesi=maliyet.toplam_iskonto_orani,
                ozel_kampanya_notu=" • ".join(notlar),
                kamu_iskontosu=round(kamu_iskontosu, 2),
                eczaci_kari=round(eczaci_kari, 2)
            )
            sonuclar.append(sarti)

        return sonuclar

    async def _resolve_matnr(self, urun_id: str = "", barcode: str = "", product_name: str = "") -> Optional[str]:
        """İSKOOP SAP MATNR kodunu çözer (Disk/RAM önbellekte varsa 0ms, değilse HTTPX ile hızlı çözer)."""
        target_uid = str(urun_id or "").strip()
        clean_bc = str(barcode or "").strip()
        if len(clean_bc) == 14 and clean_bc.startswith("0"):
            clean_bc = clean_bc[1:]

        # 0. Önbellek kontrolü (0ms)
        if target_uid and target_uid in self._matnr_cache:
            cached = self._matnr_cache[target_uid]
            if len(str(cached).lstrip("0")) <= 8:
                return cached
        if clean_bc and clean_bc in self._matnr_cache:
            cached = self._matnr_cache[clean_bc]
            if len(str(cached).lstrip("0")) <= 8:
                return cached

        uid_stripped = target_uid.lstrip("0")
        bc_stripped = clean_bc.lstrip("0")
        if (
            target_uid.isdigit()
            and 1 <= len(uid_stripped) <= 8
            and (not bc_stripped or uid_stripped != bc_stripped)
            and not uid_stripped.startswith(("869", "868"))
        ):
            padded = uid_stripped.zfill(18)
            dirty = self._set_matnr_mapping(target_uid, padded)
            if clean_bc and self._set_matnr_mapping(clean_bc, padded):
                dirty = True
            if dirty:
                self._save_matnr_cache()
            return padded

        name = str(product_name or "").strip()
        if not name and clean_bc and clean_bc.isdigit() and len(clean_bc) >= 8:
            try:
                from backend.catalog import catalog
                cp = catalog.get_by_barcode(clean_bc)
                if cp and cp.get("name"):
                    name = cp["name"]
            except Exception:
                pass

        if not name and clean_bc:
            name = clean_bc

        if not name:
            return None

        words = re.sub(r'[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]', ' ', name).strip().split()
        first_word = words[0].upper() if words else name
        tokens = [w.upper() for w in words if len(w) >= 2]
        valid_bc = clean_bc if (clean_bc.isdigit() and len(clean_bc) >= 8) else ""
        stripped_bc = valid_bc.lstrip("0") if valid_bc else ""

        # 1. Hızlı HTTPX ile MATNR çözümü (Paralel çalışabilir, DOM beklemez!)
        if (self._http_has_cookies and self._token) or self._load_api_state_from_disk():
            try:
                q_list = []
                if valid_bc:
                    q_list.append(valid_bc)
                    if stripped_bc and stripped_bc != valid_bc:
                        q_list.append(stripped_bc)
                    if first_word and first_word not in q_list:
                        q_list.append(first_word)
                else:
                    q_list.append(first_word)
                h_res = await self._search_via_httpx(
                    search_queries=q_list,
                    target_barcode=valid_bc,
                    stripped_bc=stripped_bc,
                    name_tokens=tokens,
                    cached_matnr=None,
                )
                if isinstance(h_res, dict) and h_res.get("data"):
                    mk = h_res["data"].get("EP_S_MALZEME_KARTI") or {}
                    found_m = str(mk.get("MATNR") or "").strip()
                    if found_m:
                        padded = found_m.zfill(18)
                        dirty = False
                        if clean_bc and self._set_matnr_mapping(clean_bc, padded):
                            dirty = True
                        if target_uid and self._set_matnr_mapping(target_uid, padded):
                            dirty = True
                        if isinstance(h_res.get("discovered"), dict):
                            for bk, mv in h_res["discovered"].items():
                                if self._set_matnr_mapping(bk, mv):
                                    dirty = True
                        if dirty:
                            self._save_matnr_cache()
                        return padded
            except Exception:
                pass

        # 2. Yedek: Tarayıcı içi çözme
        if not self._page:
            return None
        try:
            matched_matnr = await self._page.evaluate("""async (args) => {
                try {
                    const rootEl = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = rootEl ? rootEl.__vue__ : null;
                    while (cur && cur.$parent) cur = cur.$parent;
                    const store = cur ? cur.$store : null;
                    const auth = (store && store.state && store.state.authentication) ? store.state.authentication : {};
                    const liveToken = auth.token || args.token || '';
                    const liveSln = String((auth.challenge && auth.challenge.solution && auth.challenge.solution.number) || args.sln || '1');

                    async function fetchWithTimeout(url, opts, timeoutMs = 4000) {
                        const ctrl = new AbortController();
                        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
                        try {
                            return await fetch(url, { ...opts, signal: ctrl.signal });
                        } finally {
                            clearTimeout(timer);
                        }
                    }

                    if (args.barcode) {
                        const bcQueries = [args.barcode];
                        if (args.strippedBc && args.strippedBc !== args.barcode) {
                            bcQueries.push(args.strippedBc);
                        }
                        for (const bcQ of bcQueries) {
                            const rBc = await fetchWithTimeout('/MainService/api/rfc/mat/sm?ST=' + encodeURIComponent(bcQ) + '&TYP=3', {
                                headers: { 'accept': 'application/json', 'token': liveToken, 'sln': liveSln }
                            }, 4000);
                            if (rBc.ok) {
                                const dBc = await rBc.json();
                                const bcItems = dBc.ET_MAKTX || [];
                                if (bcItems.length === 1 && bcItems[0].MATNR) {
                                    return bcItems[0].MATNR;
                                } else if (bcItems.length > 1) {
                                    for (const it of bcItems.slice(0, 6)) {
                                        const r2 = await fetchWithTimeout('/MainService/api/rfc/mat/ms?MATNR=' + it.MATNR, {
                                            method: 'POST',
                                            headers: { 'accept': 'application/json', 'content-type': 'application/json', 'token': liveToken, 'sln': liveSln },
                                            body: '{}'
                                        }, 4000);
                                        if (r2.ok) {
                                            const d2 = await r2.json();
                                            const mk = d2.EP_S_MALZEME_KARTI || {};
                                            const itemBc = String(mk.BARKOD || '').trim();
                                            if (itemBc === args.barcode || (args.strippedBc && itemBc.replace(/^0+/, '') === args.strippedBc)) {
                                                return it.MATNR;
                                            }
                                        }
                                    }
                                    return bcItems[0].MATNR;
                                }
                            }
                        }
                    }

                    const r1 = await fetchWithTimeout('/MainService/api/rfc/mat/sm?ST=' + encodeURIComponent(args.query) + '&TYP=3', {
                        headers: { 'accept': 'application/json', 'token': liveToken, 'sln': liveSln }
                    }, 4000);
                    const d1 = await r1.json();
                    let items = d1.ET_MAKTX || [];
                    if (items.length === 0) return null;

                    if (args.barcode) {
                        const tokens = args.tokens || [];
                        if (tokens.length > 1) {
                            items = items.slice().sort((a, b) => {
                                const ma = String(a.MAKTX || '').toUpperCase();
                                const mb = String(b.MAKTX || '').toUpperCase();
                                let sa = 0, sb = 0;
                                for (const t of tokens) {
                                    if (ma.includes(t)) sa++;
                                    if (mb.includes(t)) sb++;
                                }
                                return sb - sa;
                            });
                        }
                        const chunkSize = 6;
                        for (let i = 0; i < Math.min(items.length, 24); i += chunkSize) {
                            const chunk = items.slice(i, i + chunkSize);
                            const results = await Promise.all(chunk.map(async (it) => {
                                const r2 = await fetchWithTimeout('/MainService/api/rfc/mat/ms?MATNR=' + it.MATNR, {
                                    method: 'POST',
                                    headers: { 'accept': 'application/json', 'content-type': 'application/json', 'token': liveToken, 'sln': liveSln },
                                    body: '{}'
                                }, 4000);
                                if (!r2.ok) return null;
                                const d2 = await r2.json();
                                const mk = d2.EP_S_MALZEME_KARTI || {};
                                const itemBc = String(mk.BARKOD || '').trim();
                                return (itemBc === args.barcode || (args.strippedBc && itemBc.replace(/^0+/, '') === args.strippedBc)) ? it.MATNR : null;
                            }));
                            const hit = results.find(x => !!x);
                            if (hit) return hit;
                        }
                    }
                    return items[0].MATNR || null;
                } catch(e) {
                    return null;
                }
            }""", {
                "query": first_word,
                "barcode": valid_bc,
                "strippedBc": stripped_bc,
                "tokens": tokens,
                "token": self._token,
                "sln": self._sln
            })
            if matched_matnr:
                padded = str(matched_matnr).strip().zfill(18)
                dirty = False
                if clean_bc and self._set_matnr_mapping(clean_bc, padded):
                    dirty = True
                if target_uid and self._set_matnr_mapping(target_uid, padded):
                    dirty = True
                if dirty:
                    self._save_matnr_cache()
                return padded
        except Exception:
            pass

        return None

    async def _add_to_cart_unlocked(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        barkod = str(kwargs.get("barkod") or "").strip()
        if len(barkod) == 14 and barkod.startswith("0"):
            barkod = barkod[1:]
        product_name = str(kwargs.get("name") or kwargs.get("urun_adi") or "").strip()
        if not barkod and str(urun_id).isdigit() and len(str(urun_id).lstrip("0")) >= 9:
            barkod = str(urun_id).strip()
            if len(barkod) == 14 and barkod.startswith("0"):
                barkod = barkod[1:]

        if not product_name and barkod:
            try:
                from backend.catalog import catalog
                cp = catalog.get_by_barcode(barkod)
                if cp and cp.get("name"):
                    product_name = cp["name"]
            except Exception:
                pass

        # 0. Önbellekten stok kontrolü (Stokta yoksa 2ms'de dön!)
        stock_cache = getattr(self, "_stock_cache", {})
        uid_str = str(urun_id or "").strip()
        if (uid_str in stock_cache and stock_cache[uid_str] is False) or (barkod and barkod in stock_cache and stock_cache[barkod] is False):
            return {
                "success": False,
                "depo": "ISKOOP",
                "message": f"{product_name or barkod or uid_str} İSKOOP deposunda stokta mevcut değil."
            }

        # 1. Yanıt dinleyiciyi kur (mat/ms ürün yükleme + order/oc-ab sepet yanıtı)
        captured_order = {}
        order_error_msg = None
        order_has_error = False
        order_event = asyncio.Event()
        ms_data = {}
        ms_event = asyncio.Event()

        async def on_resp(res):
            nonlocal order_error_msg, order_has_error
            if "mat/ms" in res.url:
                try:
                    d_ms = await res.json()
                    if isinstance(d_ms, dict):
                        kart = d_ms.get("EP_S_MALZEME_KARTI") or {}
                        if kart.get("MAKTX") or kart.get("MATNR"):
                            ms_data["kart"] = kart
                            ms_data["vwerk"] = d_ms.get("EP_S_VWERK") or {}
                            ms_event.set()
                except Exception:
                    pass
            elif "order/oc" in res.url or "order/ab" in res.url:
                try:
                    data = await res.json()
                    captured_order[res.url] = data
                    if isinstance(data, dict):
                        ret = data.get("EP_S_RETURN") or {}
                        if ret.get("MESSAGE"):
                            if str(ret.get("TYPE") or "").upper() in ("E", "A"):
                                order_has_error = True
                            order_error_msg = ret.get("MESSAGE")
                        for r in (data.get("EP_T_RETURN") or []):
                            if r.get("MESSAGE"):
                                if str(r.get("TYPE") or "").upper() in ("E", "A"):
                                    order_has_error = True
                                order_error_msg = r.get("MESSAGE")
                    order_event.set()
                except Exception:
                    order_event.set()
        self._page.on("response", on_resp)

        try:
            # 2. Hedef MATNR'yi çözümle (Önbellekte varsa 0ms!)
            matnr = await self._resolve_matnr(urun_id=urun_id, barcode=barkod, product_name=product_name)
            target_matnr_short = matnr.lstrip("0") if matnr else ""

            # 3. Önce /dashboard rotasına geçerek eski MedicineDetail bileşenini Vue yaşam döngüsüyle temizle,
            #    ardından hedef ürüne yönlen ve mat/ms yanıtının gelmesini bekle!
            if matnr:
                ms_event.clear()
                ms_data.clear()
                await self._page.evaluate("""async (m) => {
                    document.querySelectorAll('.v-dialog--active button, .v-overlay--active').forEach(el => {
                        try { if (el.tagName === 'BUTTON') el.click(); } catch(e) {}
                    });
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = el ? el.__vue__ : null;
                    while (cur && cur.$parent) { cur = cur.$parent; }
                    const store = cur ? cur.$store : null;
                    const router = cur ? cur.$router : null;
                    if (store) {
                        try { store.dispatch('basket/clearAddingProduct'); } catch(e) {}
                        const nowMs = Date.now();
                        if (!window._frLastBasketSyncMs || (nowMs - window._frLastBasketSyncMs) > 5000) {
                            window._frLastBasketSyncMs = nowMs;
                            try {
                                await Promise.race([
                                    store.dispatch('basket/fetchBaskets', { basketOwnerType: 'T' }),
                                    new Promise(r => setTimeout(r, 1500))
                                ]);
                            } catch(e) {}
                        }
                    }
                    if (router) {
                        if (!router.currentRoute || router.currentRoute.path !== '/dashboard') {
                            try { await router.replace('/dashboard'); } catch(e) {}
                            await new Promise(r => setTimeout(r, 25));
                        }
                        try {
                            await router.push('/medicine-detail/' + m);
                        } catch(e) {}
                    }
                }""", matnr)

                try:
                    await asyncio.wait_for(ms_event.wait(), timeout=1.8)
                except asyncio.TimeoutError:
                    pass

                # Eğer ilaç sayfasında mat/ms yanıtı gelmediyse (ıtriyat / şeker stribi vb.), non-medicine-detail sayfasını dene
                if not ms_data.get("kart"):
                    ms_event.clear()
                    await self._page.evaluate("""async (m) => {
                        const el = document.querySelector('#app') || document.querySelector('.v-application') || document.body.firstElementChild;
                        let cur = el ? el.__vue__ : null;
                        while (cur && cur.$parent) { cur = cur.$parent; }
                        const router = cur ? cur.$router : null;
                        if (router) {
                            try { await router.replace('/dashboard'); } catch(e) {}
                            await new Promise(r => setTimeout(r, 25));
                            try { await router.push('/non-medicine-detail/' + m); } catch(e) {}
                        }
                    }""", matnr)
                    try:
                        await asyncio.wait_for(ms_event.wait(), timeout=1.8)
                    except asyncio.TimeoutError:
                        pass

                await asyncio.sleep(0.03)
            else:
                ms_event.clear()
                ms_data.clear()
                await self._page.evaluate("""async () => {
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = el ? el.__vue__ : null;
                    while (cur && cur.$parent) { cur = cur.$parent; }
                    const store = cur ? cur.$store : null;
                    const router = cur ? cur.$router : null;
                    if (store) {
                        try { store.dispatch('basket/clearAddingProduct'); } catch(e) {}
                        const nowMs = Date.now();
                        if (!window._frLastBasketSyncMs || (nowMs - window._frLastBasketSyncMs) > 5000) {
                            window._frLastBasketSyncMs = nowMs;
                            try {
                                await Promise.race([
                                    store.dispatch('basket/fetchBaskets', { basketOwnerType: 'T' }),
                                    new Promise(r => setTimeout(r, 1500))
                                ]);
                            } catch(e) {}
                        }
                    }
                    if (router && (!router.currentRoute || router.currentRoute.path !== '/dashboard')) {
                        try { await router.replace('/dashboard'); } catch(e) {}
                        await new Promise(r => setTimeout(r, 25));
                    }
                }""")
                search_q = product_name or barkod or urun_id
                try:
                    search_input = await self._page.wait_for_selector('input[placeholder*="Barkod"], #input-99', timeout=4000)
                    await search_input.click()
                    await self._page.keyboard.press("Control+A")
                    await self._page.keyboard.press("Backspace")
                    await search_input.fill(search_q)
                    await asyncio.sleep(0.10)
                    item_elem = await self._page.wait_for_selector('.v-list-item[class*="item-"]', timeout=1200)
                    if item_elem:
                        await item_elem.click()
                    else:
                        await search_input.press("Enter")
                    try:
                        await asyncio.wait_for(ms_event.wait(), timeout=1.8)
                    except asyncio.TimeoutError:
                        pass
                    await asyncio.sleep(0.05)
                except Exception:
                    pass

            if ms_data.get("kart"):
                kart_name = str(ms_data["kart"].get("MAKTX") or "").strip()
                kart_matnr = str(ms_data["kart"].get("MATNR") or "").strip().lstrip("0")
                if kart_name:
                    product_name = kart_name
                if kart_matnr and not target_matnr_short:
                    target_matnr_short = kart_matnr
            elif matnr:
                return {
                    "success": False,
                    "depo": "ISKOOP",
                    "message": f"Ürün ({product_name or barkod or urun_id}) İSKOOP'ta bulunamadı veya malzeme kartı yüklenemedi."
                }

            # 4. Hedef ürünün sepete ekleme butonunu yakala, miktarı yaz ve tıkla!
            captured_order.clear()
            order_event.clear()
            order_has_error = False
            order_error_msg = None

            prod_state = await self._page.evaluate("""async (params) => {
                const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                let lastState = { found: false };

                for (let i = 0; i < 70; i++) { // 70 * 25ms = 1.75 saniye hızlı yoklama
                    const btn = document.querySelector('.add-to-basket-btn');
                    if (btn) {
                        let comp = btn.__vue__;
                        let dm = null;
                        let store = null;
                        let router = null;
                        while (comp) {
                            if (!dm && comp.dataModel) dm = comp.dataModel;
                            if (!store && comp.$store) store = comp.$store;
                            if (!router && comp.$router) router = comp.$router;
                            comp = comp.$parent;
                        }
                        const activeBasket = store ? store.getters['basket/getActiveBasket'] : null;
                        const allBaskets = (store && store.getters['basket/getBaskets']) || [];
                        const checkBasket = activeBasket || allBaskets.find(b => b && b.products && b.products.length > 0);
                        let inActiveBasket = false;
                        if (params.targetMatnr && checkBasket && Array.isArray(checkBasket.products)) {
                            inActiveBasket = checkBasket.products.some(
                                prod => String(prod.id || '').replace(/^0+/, '') === params.targetMatnr
                            );
                        }
                        const routeId = (router && router.currentRoute && router.currentRoute.params && router.currentRoute.params.id) || '';
                        const curMatnr = String((dm && (dm.matnr || dm.MATNR || dm.id)) || routeId || '').replace(/^0+/, '');
                        const targetLoaded = !params.targetMatnr || !curMatnr || (params.targetMatnr === curMatnr);

                        lastState = {
                            found: true,
                            targetLoaded: targetLoaded,
                            btnDisabled: !!btn.disabled,
                            alreadyInBasket: inActiveBasket,
                            activeBasketId: checkBasket ? checkBasket.id : null,
                            name: (dm && (dm.name || dm.MAKTX)) || null,
                            matnr: curMatnr || params.targetMatnr || null,
                            clicked: false
                        };

                        if (targetLoaded) {
                            if (!btn.disabled) {
                                if (params.qty > 1 && dm) {
                                    dm.quantity = params.qty;
                                    await sleep(25);
                                }
                                btn.click();
                                lastState.clicked = true;
                                await sleep(50);
                                const dlgBtn = document.querySelector('.v-dialog--active button.primary, .v-dialog--active .v-btn.primary, .v-dialog--active .v-btn--contained');
                                if (dlgBtn) {
                                    try { dlgBtn.click(); } catch(e) {}
                                }
                            }
                            return lastState;
                        }
                    }
                    await sleep(25);
                }
                return lastState;
            }""", {
                "targetMatnr": target_matnr_short,
                "fullMatnr": matnr or "",
                "qty": int(miktar)
            })

            if not prod_state.get("found"):
                return {
                    "success": False,
                    "depo": "ISKOOP",
                    "message": f"Ürün ({product_name or barkod or urun_id}) İSKOOP'ta bulunamadı veya stokta mevcut değil."
                }

            if not prod_state.get("targetLoaded"):
                loaded_name = prod_state.get("name") or "Bilinmeyen Ürün"
                return {
                    "success": False,
                    "depo": "ISKOOP",
                    "message": f"İSKOOP sayfasında hedeflenen ürün ({product_name or barkod}) yüklenemedi ('{loaded_name}')."
                }

            if prod_state.get("name"):
                product_name = prod_state.get("name")

            if prod_state.get("btnDisabled"):
                return {
                    "success": False,
                    "depo": "ISKOOP",
                    "btn_disabled": True,
                    "message": f"{product_name} İSKOOP deposunda stokta yok veya sepete ekleme butonu pasif (Tevzi kota dolmuş olabilir)."
                }

            if prod_state.get("alreadyInBasket") and not prod_state.get("clicked"):
                doc_no = prod_state.get("activeBasketId") or ""
                msg = f"{product_name} zaten İSKOOP taslak sepetinizde kayıtlı."
                if doc_no:
                    msg += f" (Belge No: {doc_no})"
                self._merge_last_added_items([{
                    "barcode": barkod or "",
                    "urun_id": target_matnr_short or "",
                    "matnr": target_matnr_short or "",
                    "kod": target_matnr_short or "",
                    "name": product_name or "",
                    "ad": product_name or "",
                    "miktar": int(miktar)
                }])
                return {
                    "success": True,
                    "depo": "ISKOOP",
                    "message": msg,
                    "urun_adi": product_name,
                    "belge_no": doc_no,
                    "urun_id": target_matnr_short,
                    "matnr": target_matnr_short,
                    "already_in_cart": True,
                    "portal_url": "https://esube.iskoop.org/FrameWorkT1/#/baskets"
                }

            # 5. Sipariş yanıtını Event ile bekle (yanıt geldiği salisede devam eder!)
            if not captured_order:
                try:
                    await asyncio.wait_for(order_event.wait(), timeout=3.2)
                except asyncio.TimeoutError:
                    pass

            oc_data = None
            oc_url = ""
            for u, d in captured_order.items():
                if "order/oc" in u:
                    oc_data = d
                    oc_url = u
                    break
                elif "order/ab" in u and not oc_data:
                    oc_data = d
                    oc_url = u

            skip_cart_status = kwargs.get("skip_cart_status", False)
            in_cart = False
            cart_after = {}
            oc_has_items = False
            if isinstance(oc_data, dict):
                kalem_list = oc_data.get("EP_T_KALEM") if "EP_T_KALEM" in oc_data else oc_data.get("ET_KALEM")
                if isinstance(kalem_list, list):
                    oc_has_items = len(kalem_list) > 0
                elif oc_data.get("VBELN") or oc_data.get("EP_VBELN") or "order/ab" in oc_url:
                    oc_has_items = True

            if oc_data and not order_has_error and oc_has_items:
                in_cart = True
            elif not skip_cart_status:
                cart_after = await self._get_cart_status_unlocked()
                cart_items = cart_after.get("items", [])
                tr_m = str.maketrans("İIıŞşĞğÜüÖöÇç", "iiissgguuoocc")
                p_norm = re.sub(r"[^a-z0-9]+", " ", str(product_name or "").translate(tr_m).lower()).strip()
                p_words = [w for w in p_norm.split() if len(w) >= 2]
                p_nums = {w for w in p_norm.split() if w.isdigit()}
                for it in cart_items:
                    it_kod = str(it.get("kod") or "").strip().lstrip("0")
                    if target_matnr_short and it_kod and it_kod == str(target_matnr_short).strip().lstrip("0"):
                        in_cart = True
                        break
                    if barkod and (barkod.lstrip("0") == it_kod or barkod == str(it.get("barkod") or "").strip()):
                        in_cart = True
                        break
                    if p_norm and not target_matnr_short:
                        c_norm = re.sub(r"[^a-z0-9]+", " ", str(it.get("ad") or "").translate(tr_m).lower()).strip()
                        c_words = [w for w in c_norm.split() if len(w) >= 2]
                        c_nums = {w for w in c_norm.split() if w.isdigit()}
                        if c_norm == p_norm or (p_words and c_words and p_words[0] == c_words[0] and (not p_nums or not c_nums or p_nums.intersection(c_nums)) and len(set(p_words).intersection(set(c_words))) >= min(2, len(p_words), len(c_words))):
                            in_cart = True
                            break

            if in_cart:
                vbeln = str((oc_data.get("VBELN") or oc_data.get("EP_VBELN") or "") if oc_data else "").strip() or str(cart_after.get("basket_id") or "")
                toplam_tutar = (oc_data.get("TOPLAM_TUTAR") if oc_data else None) or cart_after.get("total_amount")
                self._merge_last_added_items([{
                    "barcode": barkod or "",
                    "urun_id": target_matnr_short or "",
                    "matnr": target_matnr_short or "",
                    "kod": target_matnr_short or "",
                    "name": product_name or "",
                    "ad": product_name or "",
                    "miktar": int(miktar)
                }])
                return {
                    "success": True,
                    "depo": "ISKOOP",
                    "message": f"{product_name} ({miktar} adet) İSKOOP taslak siparişine başarıyla eklendi" + (f" (Belge No: {vbeln})." if vbeln else "."),
                    "belge_no": vbeln,
                    "miktar": int(miktar),
                    "urun_adi": product_name,
                    "urun_id": target_matnr_short,
                    "matnr": target_matnr_short,
                    "cart_total": toplam_tutar
                }
            else:
                err_detail = order_error_msg or "Stok yetersiz, kota aşıldı veya İSKOOP sepeti onaylamadı."
                return {
                    "success": False,
                    "depo": "ISKOOP",
                    "message": f"{product_name} İSKOOP sepetine eklenemedi: {err_detail}"
                }
        finally:
            try:
                self._page.remove_listener("response", on_resp)
            except Exception:
                pass

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """İSKOOP taslak siparişine ürün ekler (MATNR önbellek ve Event hızlandırmalı)."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def bulk_add_to_cart(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        İSKOOP taslak siparişine toplu ürün ekler.
        items: [{"barcode": "...", "miktar": 1, "name": "...", "urun_id": "..."}]
        """
        if not items:
            return {
                "success": False,
                "message": "Eklenecek ürün listesi boş.",
                "total_items": 0,
                "success_count": 0,
                "failed_count": 0,
                "total_amount": 0.0,
                "items": []
            }

        self._cart_busy += 1
        try:
            async with self._lock:
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()
                await self._ensure_ready_page()
                await self._sync_http_state_from_context()

                # ÖN HAZIRLIK: Sepet listesini 1 kez senkronize et ve önbellekte olmayan MATNR'leri 6'lı paralel HTTPX ile çöz!
                try:
                    await self._page.evaluate("""async () => {
                        const el = document.querySelector('#app') || document.querySelector('.v-application') || document.body.firstElementChild;
                        let cur = el ? el.__vue__ : null;
                        while (cur && cur.$parent) cur = cur.$parent;
                        const store = cur ? cur.$store : null;
                        if (store) {
                            await Promise.race([
                                store.dispatch('basket/fetchBaskets', { basketOwnerType: 'T' }),
                                new Promise(r => setTimeout(r, 3000))
                            ]);
                        }
                    }""")
                except Exception:
                    pass

                prep_sem = asyncio.Semaphore(6)
                async def _pre_resolve(it_obj: Dict[str, Any]):
                    bc_p = str(it_obj.get("barcode") or it_obj.get("barkod") or "").strip()
                    nm_p = str(it_obj.get("name") or it_obj.get("urun_adi") or "").strip()
                    uid_p = str(it_obj.get("urun_id") or "").strip()
                    async with prep_sem:
                        try:
                            await self._resolve_matnr(urun_id=uid_p, barcode=bc_p, product_name=nm_p)
                        except Exception:
                            pass

                await asyncio.gather(*[_pre_resolve(it) for it in items])

                results = []
                for it in items:
                    bc = str(it.get("barcode") or it.get("barkod") or "").strip()
                    name = str(it.get("name") or it.get("urun_adi") or "").strip()
                    qty = max(1, int(it.get("miktar") or it.get("quantity") or 1))
                    u_id = str(it.get("urun_id") or "").strip()

                    item_res = {
                        "barcode": bc,
                        "name": name,
                        "miktar": qty,
                        "urun_id": u_id,
                        "matnr": "",
                        "btn_disabled": False,
                        "success": False,
                        "message": "",
                        "urun_adi": name,
                        "net_fiyat": 0.0,
                        "vade": 30,
                        "toplam_tutar": 0.0
                    }

                    try:
                        add_res = await self._add_to_cart_unlocked(urun_id=u_id or bc or name, miktar=qty, barkod=bc, name=name, skip_cart_status=True)
                        item_res["matnr"] = str(add_res.get("matnr") or "").strip()
                        item_res["btn_disabled"] = bool(add_res.get("btn_disabled"))
                        if add_res.get("success"):
                            item_res["success"] = True
                            item_res["urun_adi"] = add_res.get("urun_adi") or item_res["urun_adi"]
                            item_res["message"] = add_res.get("message") or f"{qty} Adet İSKOOP taslak siparişine eklendi."
                            if add_res.get("cart_total"):
                                item_res["toplam_tutar"] = float(add_res.get("cart_total") or 0.0)
                        else:
                            item_res["message"] = add_res.get("message") or "Sepete eklenemedi."
                    except Exception as e:
                        item_res["message"] = f"Hata: {str(e)}"

                    results.append(item_res)

                tr_map_isk = str.maketrans("İIıŞşĞğÜüÖöÇç", "iiissgguuoocc")

                def _norm_isk(s: str) -> str:
                    return re.sub(r"[^a-z0-9]+", " ", str(s or "").translate(tr_map_isk).lower()).strip()

                def _match_cart_item(r_item: Dict[str, Any], c_items: List[Dict[str, Any]], used_idx: set) -> Optional[Dict[str, Any]]:
                    r_matnr = str(r_item.get("matnr") or r_item.get("urun_id") or "").strip().lstrip("0")
                    if len(r_matnr) == 13 and r_matnr.startswith("86"):
                        r_matnr = ""
                    r_bc = str(r_item.get("barcode") or "").strip()
                    if not r_matnr and r_bc and r_bc in self._matnr_cache:
                        r_matnr = str(self._matnr_cache[r_bc]).strip().lstrip("0")

                    # 1. Önce kesin MATNR / Barkod eşleşmesi (her sepet satırı yalnızca 1 kez kullanılır!)
                    for idx_c, ci in enumerate(c_items):
                        if idx_c in used_idx:
                            continue
                        ci_kod = str(ci.get("kod") or ci.get("id") or "").strip().lstrip("0")
                        if r_matnr and ci_kod and r_matnr == ci_kod:
                            used_idx.add(idx_c)
                            return ci
                        if r_bc and ci_kod and r_bc.lstrip("0") == ci_kod:
                            used_idx.add(idx_c)
                            return ci

                    # Eğer r_matnr biliniyor ama sepette o MATNR yoksa ASLA ilk 6 harften başka bir varyantla (örn. PAROL PLUS <-> PAROL 500) eşleştirme!
                    if r_matnr:
                        return None

                    r_norm = _norm_isk(r_item.get("urun_adi") or r_item.get("name") or "")
                    if not r_norm:
                        return None
                    r_words = [w for w in r_norm.split() if len(w) >= 2]
                    r_nums = {w for w in r_norm.split() if w.isdigit()}
                    for idx_c, ci in enumerate(c_items):
                        if idx_c in used_idx:
                            continue
                        ci_norm = _norm_isk(ci.get("ad") or "")
                        if not ci_norm:
                            continue
                        if r_norm == ci_norm or (len(r_norm) >= 8 and (r_norm in ci_norm or ci_norm in r_norm)):
                            used_idx.add(idx_c)
                            return ci
                        ci_words = [w for w in ci_norm.split() if len(w) >= 2]
                        ci_nums = {w for w in ci_norm.split() if w.isdigit()}
                        if r_words and ci_words and r_words[0] == ci_words[0]:
                            if r_nums and ci_nums and not r_nums.intersection(ci_nums):
                                continue
                            if len(set(r_words).intersection(set(ci_words))) >= min(2, len(r_words), len(ci_words)):
                                used_idx.add(idx_c)
                                return ci
                    return None

                # Tek seferde güncel sepet durumunu çek ve eksik kalan kalem varsa 1 kez otomatik yeniden dene!
                total_amount = 0.0
                final_cart_items = []
                try:
                    final_cart = await self._get_cart_status_unlocked()
                    final_cart_items = final_cart.get("items", []) or []
                    retried_any = False
                    used_first_pass: set = set()
                    for r in results:
                        matched = _match_cart_item(r, final_cart_items, used_first_pass)
                        if not matched and not r.get("btn_disabled"):
                            try:
                                retry_res = await self._add_to_cart_unlocked(
                                    urun_id=r.get("matnr") or r.get("urun_id") or r.get("barcode") or r.get("name"),
                                    miktar=r.get("miktar", 1),
                                    barkod=r.get("barcode", ""),
                                    name=r.get("name", ""),
                                    skip_cart_status=True
                                )
                                if retry_res.get("matnr"):
                                    r["matnr"] = str(retry_res.get("matnr")).strip()
                                if retry_res.get("success"):
                                    r["success"] = True
                                    r["urun_adi"] = retry_res.get("urun_adi") or r["urun_adi"]
                                    r["message"] = retry_res.get("message") or f"{r['miktar']} Adet İSKOOP taslak siparişine eklendi."
                                else:
                                    r["message"] = retry_res.get("message") or r.get("message") or "Sepete eklenemedi."
                                retried_any = True
                            except Exception:
                                pass
                    if retried_any:
                        final_cart = await self._get_cart_status_unlocked()
                        final_cart_items = final_cart.get("items", []) or []

                    used_final_pass: set = set()
                    for r in results:
                        matched = _match_cart_item(r, final_cart_items, used_final_pass)
                        if matched:
                            r["success"] = True
                            if matched.get("kod"):
                                r["urun_id"] = str(matched.get("kod")).strip()
                                r["matnr"] = str(matched.get("kod")).strip()
                            r["urun_adi"] = matched.get("ad") or r.get("urun_adi") or r.get("name")
                            if matched.get("birim_fiyat"):
                                r["net_fiyat"] = float(matched.get("birim_fiyat") or 0.0)
                            if matched.get("tutar"):
                                r["toplam_tutar"] = float(matched.get("tutar") or 0.0)
                            if not r.get("message") or "eklenemedi" in r.get("message", "").lower():
                                r["message"] = f"{r['miktar']} Adet İSKOOP taslak siparişine eklendi."
                        elif r.get("success") and final_cart.get("success"):
                            r["success"] = False
                            r["toplam_tutar"] = 0.0
                            if not r.get("message") or "eklendi" in r.get("message", "").lower():
                                r["message"] = "İSKOOP sepet doğrulamasında ürün sepette görülmedi (Stok/Tevzi kısıtı olabilir)."

                    total_amount = float(final_cart.get("total_amount") or 0.0)
                except Exception:
                    pass

                success_items = [r for r in results if r.get("success")]
                failed_items = [r for r in results if not r.get("success")]
                if total_amount <= 0 and success_items:
                    total_amount = round(sum(r.get("toplam_tutar", 0) for r in success_items), 2)
                if success_items:
                    self._merge_last_added_items([
                        {
                            "barcode": r.get("barcode") or "",
                            "urun_id": r.get("urun_id") or r.get("matnr") or "",
                            "matnr": r.get("matnr") or r.get("urun_id") or "",
                            "kod": r.get("urun_id") or r.get("matnr") or "",
                            "name": r.get("urun_adi") or r.get("name") or "",
                            "ad": r.get("urun_adi") or r.get("name") or "",
                            "miktar": int(r.get("miktar") or 1)
                        }
                        for r in success_items
                    ])

                return {
                    "success": len(success_items) > 0,
                    "depo": "ISKOOP",
                    "message": f"İSKOOP taslak sepetine {len(success_items)}/{len(items)} kalem ürün eklendi.",
                    "total_items": len(items),
                    "success_count": len(success_items),
                    "failed_count": len(failed_items),
                    "total_amount": total_amount,
                    "items": results
                }
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    def get_portal_urls(self) -> dict:
        """İSKOOP sepet ve sipariş web arayüzü linklerini döndürür."""
        return {
            "cart_url": "https://esube.iskoop.org/FrameWorkT1/#/baskets",
            "checkout_url": "https://esube.iskoop.org/FrameWorkT1/#/baskets"
        }

    async def _get_cart_status_unlocked(self) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        res = await self._page.evaluate("""async () => {
            const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
            let current = el ? el.__vue__ : null;
            while (current && current.$parent) current = current.$parent;
            const store = current ? current.$store : null;
            if (!store) return { error: "İSKOOP Vuex store bulunamadı" };

            const dispatchWithTimeout = (action, payload, ms = 4500) => Promise.race([
                store.dispatch(action, payload),
                new Promise(r => setTimeout(r, ms))
            ]);

            try {
                await dispatchWithTimeout('basket/fetchBaskets', { basketOwnerType: 'T' }, 4500);
            } catch(e) {}

            let activeBasket = store.getters['basket/getActiveBasket'];
            let allBaskets = store.getters['basket/getBaskets'] || [];

            if (activeBasket && activeBasket.id) {
                try {
                    await dispatchWithTimeout('basket/fetchBasketProducts', { id: activeBasket.id, willForce: true }, 4500);
                } catch(e) {}
            }

            activeBasket = store.getters['basket/getActiveBasket'];
            allBaskets = store.getters['basket/getBaskets'] || [];

            let targetBasket = activeBasket;
            if (!targetBasket || !targetBasket.products || targetBasket.products.length === 0) {
                targetBasket = allBaskets.find(b => b.products && b.products.length > 0) || targetBasket;
            }

            const items = [];
            if (targetBasket && targetBasket.products) {
                for (const p of targetBasket.products) {
                    items.push({
                        id: String(p.id || ''),
                        kod: String(p.id || '').replace(/^0+/, ''),
                        ad: String(p.name || ''),
                        miktar: Number(p.quantity || 1),
                        mf: Number(p.bonusQuantity || 0),
                        birim_fiyat: Number(p.unitPrice || 0),
                        tutar: Number(p.amount || 0)
                    });
                }
            }

            const totalAmount = targetBasket ? Number(targetBasket.amount || targetBasket.totalPrice || items.reduce((a, b) => a + (b.tutar || 0), 0)) : 0;

            return {
                basketId: targetBasket ? targetBasket.id : null,
                itemCount: items.length,
                totalAmount: totalAmount,
                items: items
            };
        }""")

        items = res.get("items", [])
        total_amount = float(res.get("totalAmount") or 0.0)

        return {
            "success": True,
            "depo": "ISKOOP",
            "depo_adi": self.depo_adi,
            "supported": True,
            "item_count": len(items),
            "total_amount": round(total_amount, 2),
            "items": items,
            "cart_url": "https://esube.iskoop.org/FrameWorkT1/#/baskets",
            "checkout_url": "https://esube.iskoop.org/FrameWorkT1/#/baskets",
            "basket_id": res.get("basketId")
        }

    async def get_cart_status(self) -> Dict[str, Any]:
        """İSKOOP taslak sepetinin anlık içeriğini ve toplam tutarını sorgular."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._get_cart_status_unlocked()
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def clear_cart(self) -> Dict[str, Any]:
        """İSKOOP taslak sepetindeki tüm ürünleri tek adımda temizler."""
        self._cart_busy += 1
        try:
            async with self._lock:
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()
                await self._ensure_ready_page()

                res = await self._page.evaluate("""async () => {
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let current = el ? el.__vue__ : null;
                    while (current && current.$parent) current = current.$parent;
                    const store = current ? current.$store : null;
                    if (!store) return { success: false, message: "Vuex store bulunamadı", count: 0 };

                    const dispatchWithTimeout = (action, payload, ms = 4500) => Promise.race([
                        store.dispatch(action, payload),
                        new Promise(r => setTimeout(r, ms))
                    ]);

                    let activeBasket = store.getters['basket/getActiveBasket'];
                    let allBaskets = store.getters['basket/getBaskets'] || [];
                    let targetBasket = activeBasket || allBaskets.find(b => b && b.id);
                    if (!targetBasket || !targetBasket.id) {
                        try {
                            await dispatchWithTimeout('basket/fetchBaskets', { basketOwnerType: 'T' }, 4500);
                            activeBasket = store.getters['basket/getActiveBasket'];
                            allBaskets = store.getters['basket/getBaskets'] || [];
                            targetBasket = activeBasket || allBaskets.find(b => b && b.id);
                        } catch(e) {}
                    }
                    if (!targetBasket || !targetBasket.id) {
                        return { success: true, message: "İSKOOP sepeti zaten boş.", count: 0 };
                    }
                    const cnt = (targetBasket.products && targetBasket.products.length) || 1;
                    try {
                        await dispatchWithTimeout('basket/deleteOrder', targetBasket.id, 6500);
                        return { success: true, message: `İSKOOP sepeti başarıyla temizlendi (${cnt} kalem silindi).`, count: cnt };
                    } catch(e) {
                        return { success: false, message: "Sepet temizleme hatası: " + e.toString(), count: 0 };
                    }
                }""")
                if res.get("success"):
                    self._last_added_items = []
                    self._last_added_time = 0.0
                return {
                    "success": bool(res.get("success")),
                    "message": res.get("message") or "İSKOOP sepeti temizlendi.",
                    "cleared_count": int(res.get("count") or 0)
                }
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def finalize_order(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        """Tekli veya toplu siparişi İSKOOP sepetine ekler ve depoya iletir."""
        self._cart_busy += 1
        try:
            async with self._lock:
                if not self.is_logged_in:
                    if await self.is_session_valid():
                        self.is_logged_in = True
                    else:
                        await self._login_unlocked()
                await self._ensure_ready_page()

                cart_status = await self._get_cart_status_unlocked()
                existing_items = cart_status.get("items", [])

                if urun_id:
                    u_clean = str(urun_id).strip()
                    already_in_cart = any(it.get("kod") == u_clean or it.get("id") == u_clean for it in existing_items)
                    if not already_in_cart:
                        added_res = await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
                        if not added_res.get("success"):
                            return {
                                "success": False,
                                "message": f"Ürün sepete eklenemediği için sipariş sonlandırılamadı: {added_res.get('message')}"
                            }
                        cart_status = await self._get_cart_status_unlocked()
                        existing_items = cart_status.get("items", [])

                pre_count = len(existing_items)
                if not existing_items:
                    return {"success": False, "message": "İSKOOP sepetinde siparişe dönüştürülecek ürün bulunamadı."}

                if len(existing_items) > 1 and not force:
                    return {
                        "success": False,
                        "need_confirmation": True,
                        "item_count": len(existing_items),
                        "items": existing_items,
                        "total_amount": cart_status.get("total_amount", 0.0),
                        "message": f"İSKOOP sepetinizde önceden eklenmiş {len(existing_items)} farklı ürün bulunmaktadır (Toplam: {cart_status.get('total_amount', 0.0):,.2f} ₺). Tüm sepeti depoya göndermek için onay veriniz."
                    }

                res = await self._page.evaluate("""async () => {
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let current = el ? el.__vue__ : null;
                    while (current && current.$parent) current = current.$parent;
                    const store = current ? current.$store : null;
                    if (!store) return { success: false, message: "Vuex store bulunamadı" };

                    const dispatchWithTimeout = (action, payload, ms = 5000) => Promise.race([
                        store.dispatch(action, payload),
                        new Promise(r => setTimeout(r, ms))
                    ]);

                    try {
                        await dispatchWithTimeout('basket/fetchBaskets', { basketOwnerType: 'T' }, 4000);
                    } catch(e) {}

                    const activeBasket = store.getters['basket/getActiveBasket'];
                    const allBaskets = store.getters['basket/getBaskets'] || [];
                    let targetBasket = activeBasket;
                    if (!targetBasket || !targetBasket.products || targetBasket.products.length === 0) {
                        targetBasket = allBaskets.find(b => b.products && b.products.length > 0) || activeBasket || allBaskets[0];
                    }
                    if (!targetBasket) return { success: false, message: "İSKOOP aktif taslak sepeti bulunamadı" };

                    try {
                        await dispatchWithTimeout('basket/completeOrderOrCheckOnlinePayment', targetBasket, 9000);
                        await new Promise(r => setTimeout(r, 450));
                        const dlgBtn = document.querySelector('.v-dialog--active button.primary, .v-dialog--active .v-btn.primary, .v-dialog--active .v-btn--contained.success, .v-dialog--active button.success');
                        if (dlgBtn) dlgBtn.click();
                        await new Promise(r => setTimeout(r, 650));
                        try { await dispatchWithTimeout('basket/clearAddingProduct', undefined, 2000); } catch(e) {}
                        try { await dispatchWithTimeout('basket/fetchBaskets', { basketOwnerType: 'T' }, 3500); } catch(e) {}
                        if (current && current.$router) {
                            try { await current.$router.push('/dashboard'); } catch(e) {}
                        }
                        const snackEl = document.querySelector('.v-snack--active .v-snack__content, .v-dialog--active .v-card__text');
                        const uiNotice = snackEl ? (snackEl.innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 220) : '';
                        return { success: true, ui_notice: uiNotice, message: "İSKOOP siparişi başarıyla depoya iletildi." };
                    } catch(e) {
                        return { success: false, message: "Sipariş iletme hatası: " + e.toString() };
                    }
                }""")

                if pre_count > 0:
                    last_post_cart = None
                    for wait_s in (0.6, 1.1):
                        try:
                            await asyncio.sleep(wait_s)
                            post_cart = await self._get_cart_status_unlocked()
                            if post_cart.get("success"):
                                last_post_cart = post_cart
                                if post_cart.get("item_count", -1) == 0:
                                    if not res.get("success"):
                                        res = {
                                            "success": True,
                                            "depo": "ISKOOP",
                                            "message": "İSKOOP siparişiniz başarıyla depoya iletildi ve sepet onaylandı!"
                                        }
                                    break
                        except Exception:
                            pass

                    if last_post_cart and last_post_cart.get("item_count", 0) > 0:
                        rem_cnt = last_post_cart.get("item_count", 0)
                        notice = (res.get("ui_notice") or "").strip()
                        if not notice:
                            notice = "Minimum sepet tutarı veya depo onay kısıtını kontrol ediniz."
                        res = {
                            "success": False,
                            "depo": "ISKOOP",
                            "remaining_count": rem_cnt,
                            "message": f"İSKOOP siparişi depoya DÜŞMEDİ ({notice}) — Ürünler hala İSKOOP sepetinde bekliyor ({rem_cnt} kalem)!"
                        }

                if res.get("success"):
                    self._last_added_items = []
                    self._last_added_time = 0.0

                return res
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def close(self):
        if self._http_client and not self._http_client.is_closed:
            try:
                await self._http_client.aclose()
            except Exception:
                pass
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
