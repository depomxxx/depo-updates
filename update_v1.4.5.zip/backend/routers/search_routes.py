# -*- coding: utf-8 -*-
"""
backend/routers/search_routes.py
--------------------------------
İlaç/OTC katalog önerileri, çoklu barkod senkronizasyonu, tüm depolarda
canlı fiyat/MF karşılaştırması, EczaneTakas / Eczatrend ortak alım ve E-Ticaret piyasa kıyaslama uç noktaları.
"""

import os
import asyncio
import tempfile
from pathlib import Path
from fastapi import APIRouter, Query, UploadFile, File
from fastapi.responses import JSONResponse

import backend.app_state as app_state
from backend.models import DepoKarsilastirmaRaporu, DepoKodu
from backend.catalog import catalog
from backend.tria_client import tria_client
from backend.botanik_client import botanik_client
from backend.tebeos_client import tebeos_client
from backend.market.models import MarketPriceReport
from backend.order_tracker import order_tracker

router = APIRouter()


@router.get("/api/eczanetakas/offers")
async def get_eczanetakas_active_offers_endpoint(refresh: bool = False):
    """EczaneTakas portalındaki tüm aktif teklifleri (barkod ve fiyat bilgileriyle) döndürür."""
    motor = app_state.get_motor()
    et_adapter = motor.adapters.get(DepoKodu.ECZANETAKAS)
    if not et_adapter:
        return {
            "success": False,
            "message": "EczaneTakas aktif değil veya giriş bilgileri tanımlanmamış.",
            "count": 0,
            "offers": []
        }
    try:
        offers = await et_adapter.get_active_offers(force_refresh=bool(refresh))
        return {
            "success": True,
            "count": len(offers),
            "offers": offers
        }
    except Exception as e:
        return {
            "success": False,
            "message": str(e),
            "count": 0,
            "offers": []
        }


@router.get("/api/eczatrend/offers")
async def get_eczatrend_active_offers_endpoint(refresh: bool = False, q: str = ""):
    """Eczatrend ortak alım portalındaki aktif grup tekliflerini döndürür."""
    motor = app_state.get_motor()
    etr_adapter = motor.adapters.get(DepoKodu.ECZATREND)
    if not etr_adapter:
        return {
            "success": False,
            "message": "Eczatrend aktif değil veya giriş bilgileri tanımlanmamış.",
            "count": 0,
            "offers": []
        }
    try:
        offers = await etr_adapter.get_active_offers(force_refresh=bool(refresh), search_query=q)
        return {
            "success": True,
            "count": len(offers),
            "offers": offers
        }
    except Exception as e:
        return {
            "success": False,
            "message": str(e),
            "count": 0,
            "offers": []
        }


@router.get("/api/catalog/suggest")
async def suggest_endpoint(q: str = Query(..., min_length=2)):
    """Kullanıcı yazarken anlık ilaç ve OTC önerisi sunar."""
    suggestions = await asyncio.to_thread(catalog.search_suggestions, q, 15)
    return suggestions


@router.get("/api/catalog/stats")
async def catalog_stats_endpoint():
    """Katalogdaki toplam tekil ürün ve çoklu barkod sayılarını döndürür."""
    with catalog._get_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM products")
        total_p = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM product_barcodes")
        total_b = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM product_barcodes WHERE is_primary = 0")
        total_sec = cur.fetchone()[0]
    return {
        "total_products": total_p,
        "total_barcodes": total_b,
        "secondary_barcodes": total_sec
    }


@router.post("/api/catalog/sync-tria")
async def catalog_sync_tria_endpoint():
    """TRIA Oracle'dan çoklu barkod senkronizasyonunu tetikler."""
    try:
        catalog.sync_from_tria()
        return {"success": True, "message": "TRIA çoklu barkod senkronizasyonu tamamlandı."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})


@router.post("/api/catalog/sync-botanik")
async def catalog_sync_botanik_endpoint():
    """Botanik MS SQL'den çoklu barkod senkronizasyonunu tetikler."""
    try:
        catalog.sync_from_botanik()
        return {"success": True, "message": "Botanik çoklu barkod senkronizasyonu başarıyla tamamlandı."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})


@router.post("/api/catalog/upload-excel")
async def catalog_upload_excel_endpoint(file: UploadFile = File(...)):
    """Kullanıcının yüklediği Dermokozmetik / OTC Excel dosyasını kataloğa aktarır."""
    try:
        suffix = Path(file.filename).suffix
        if suffix.lower() not in [".xlsx", ".xls"]:
            return JSONResponse(status_code=400, content={"success": False, "error": "Lütfen geçerli bir Excel (.xlsx) dosyası yükleyin."})

        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = Path(tmp.name)

        res = catalog.import_custom_excel(tmp_path)
        try:
            tmp_path.unlink()
        except Exception:
            pass
        return res
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})


@router.get("/api/products/find")
async def find_products_endpoint(q: str = Query(..., min_length=2)):
    """
    Kullanıcı arama yaptığında:
    - Barkod ise doğrudan tekil barkod döndürür.
    - Kelime araması ise (örn: 'ocean', 'parol', 'solgar') eşleşen tüm ürünleri döndürür.
    """
    motor = app_state.get_motor()
    clean_q = q.strip()
    if clean_q.isdigit() and len(clean_q) >= 8:
        cat_item = catalog.get_by_barcode(clean_q)
        return {
            "is_barcode": True,
            "barcode": clean_q,
            "count": 1,
            "products": [cat_item] if cat_item else [{
                "barcode": clean_q,
                "name": f"Ürün Barkodu: {clean_q}",
                "manufacturer": "Genel",
                "price": 0.0
            }]
        }

    products = await motor.find_products(clean_q, limit=20)
    return {
        "is_barcode": False,
        "count": len(products),
        "products": products
    }


@router.get("/api/search", response_model=DepoKarsilastirmaRaporu)
async def search_endpoint(
    q: str = Query(..., description="Barkod veya Ürün Adı"),
    name: str = Query("", description="Ürün Adı (Yedek)"),
    urun_id: str = Query("", description="Otomasyon Ürün ID (Yedek)")
):
    from backend.config_manager import get_active_otomasyon
    motor = app_state.get_motor()
    clean_q = q.strip()
    clean_name = (name or "").strip()
    clean_uid = (urun_id or "").strip()
    if not clean_q and not clean_name:
        return JSONResponse(status_code=400, content={"error": "Arama ifadesi boş olamaz"})

    rapor = await motor.search_all(clean_q or clean_name)

    # Eğer barkodla aramada hiçbir depodan gerçek sonuç gelmediyse ve ürün adı biliniyorsa, isimden kanonik barkodu bulup tekrar dene
    has_depo_res = any(
        (getattr(r.stok_durumu, "value", str(r.stok_durumu)) == "VAR" or r.depocu_satis_fiyati > 0 or r.net_birim_maliyet > 0)
        for r in (rapor.sonuclar or [])
    )
    if not has_depo_res and clean_name:
        alt_bcs = catalog.find_canonical_barcodes_by_name(clean_name, exclude_barcode=clean_q)
        if not alt_bcs:
            found_prods = await motor.find_products(clean_name, limit=1)
            if found_prods and found_prods[0].get("barcode"):
                alt_bcs = [str(found_prods[0]["barcode"]).strip()]
        for alt_bc in alt_bcs[:1]:
            if alt_bc and alt_bc != clean_q and alt_bc != rapor.barkod:
                alt_rapor = await motor.search_all(alt_bc)
                if alt_rapor and alt_rapor.sonuclar:
                    rapor = alt_rapor
                    break

    cat_item = catalog.get_by_barcode(rapor.barkod)
    if cat_item and cat_item.get("name"):
        rapor.urun_adi = cat_item["name"]
    elif clean_name and (not rapor.urun_adi or rapor.urun_adi.startswith("Ürün (Barkod:")):
        rapor.urun_adi = clean_name

    active_oto = get_active_otomasyon()
    oto_res = None

    if active_oto == "TEBEOS":
        try:
            oto_res = await asyncio.to_thread(tebeos_client.get_product_analysis, clean_q, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and (clean_name or rapor.urun_adi):
                oto_res = await asyncio.to_thread(tebeos_client.get_product_analysis, clean_name or rapor.urun_adi, barcode=rapor.barkod)
            rapor.tria_bilgisi = oto_res
        except Exception as e:
            print(f"[Tebeos] Arama hatası: {e}")
            oto_res = {"found": False, "connected": False, "kaynak": "TEBEOS", "message": "TEBEOS otomasyonuna bağlanılamadı."}
    elif active_oto == "TRIA":
        try:
            oto_res = await asyncio.to_thread(tria_client.get_product_analysis, clean_q, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and (clean_name or rapor.urun_adi):
                oto_res = await asyncio.to_thread(tria_client.get_product_analysis, clean_name or rapor.urun_adi, barcode=rapor.barkod)
            rapor.tria_bilgisi = oto_res
        except Exception as e:
            print(f"[Tria] Arama hatası: {e}")
            oto_res = {"found": False, "connected": False, "kaynak": "TRIA", "message": "TRIA otomasyonuna bağlanılamadı."}
    else:  # BOTANIK
        try:
            oto_res = await asyncio.to_thread(botanik_client.get_product_analysis, clean_q, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and clean_uid and clean_uid.isdigit() and len(clean_uid) <= 9:
                oto_res = await asyncio.to_thread(botanik_client.get_product_analysis, clean_uid, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and (clean_name or rapor.urun_adi):
                fb_name = clean_name or rapor.urun_adi
                if fb_name and not fb_name.startswith("Ürün (Barkod:"):
                    oto_res = await asyncio.to_thread(botanik_client.get_product_analysis, fb_name, barcode=rapor.barkod)
            rapor.botanik_bilgisi = oto_res
        except Exception as e:
            print(f"[Botanik] Arama hatası: {e}")
            oto_res = {"found": False, "connected": False, "kaynak": "BOTANIK", "message": "Botanik otomasyonuna bağlanılamadı."}

    # Eğer TRIA seçili kalmış ama bağlanamamışsa ve Botanik aktifse otomatik Botanik'e düş
    if oto_res and not oto_res.get("connected", True) and active_oto != "BOTANIK":
        try:
            bot_try = await asyncio.to_thread(botanik_client.get_product_analysis, clean_q, barcode=rapor.barkod)
            if (not bot_try or not bot_try.get("found")) and (clean_name or rapor.urun_adi):
                bot_try = await asyncio.to_thread(botanik_client.get_product_analysis, clean_name or rapor.urun_adi, barcode=rapor.barkod)
            if bot_try and bot_try.get("connected"):
                oto_res = bot_try
                rapor.botanik_bilgisi = oto_res
        except Exception:
            pass

    if oto_res and oto_res.get("found") and oto_res.get("urun_adi"):
        if not rapor.urun_adi or rapor.urun_adi.startswith("Ürün (Barkod:"):
            rapor.urun_adi = oto_res["urun_adi"]

    rapor.otomasyon_bilgisi = oto_res
    rapor.tria_bilgisi = oto_res
    if oto_res and oto_res.get("kaynak") == "BOTANIK":
        rapor.botanik_bilgisi = oto_res
    elif oto_res and oto_res.get("kaynak") in ("TRIA", "TEBEOS"):
        rapor.tria_bilgisi = oto_res

    try:
        orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
        bc_key = str(rapor.barkod or "").strip()
        nm_key = str(rapor.urun_adi or "").strip().upper()
        ord_info = orders_map.get(bc_key) or (orders_map.get(bc_key[1:]) if len(bc_key) == 14 and bc_key.startswith("0") else None) or orders_map.get(nm_key)
        if ord_info:
            rapor.bugun_siparis = ord_info
    except Exception:
        pass

    return rapor


@router.get("/api/market/search", response_model=MarketPriceReport)
async def market_search_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    m_engine = app_state.get_market_engine()
    clean_q = q.strip()
    if not clean_q:
        return JSONResponse(status_code=400, content={"error": "Arama ifadesi boş olamaz"})

    report = await m_engine.generate_market_report(clean_q)
    return report
