import asyncio
import json
import re
from typing import List, Optional, Dict, Any
from pathlib import Path
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.core.cost_calculator import CostCalculator
from backend.core.session_store import SessionStore

class IskoopAdapter(BaseDepoAdapter):
    PORTAL_URL = "https://esube.iskoop.org/irj/portal"
    FRAMEWORK_URL = "https://esube.iskoop.org/FrameWorkT1/"

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ISKOOP, "İstanbul Eczacılar Kooperatifi (İSKOOP)")
        import os
        self.username = (username or os.environ.get("ISKOOP_USERNAME", "")).strip()
        self.password = (password or os.environ.get("ISKOOP_PASSWORD", "")).strip()
        self.headless = headless
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
        self._token: Optional[str] = None
        self._sln: str = "1"
        self._lock = asyncio.Lock()
        # Barkod / Ürün ID -> 18 haneli SAP MATNR önbelleği (Tekrar aramayı ve sepete eklemede MATNR çözmeyi 0ms'ye indirir)
        self._matnr_cache: Dict[str, str] = {}

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-setuid-sandbox"]
            )
            
            session_file = SessionStore.get_session_file("iskoop")
            if session_file.exists():
                try:
                    self._context = await self._browser.new_context(storage_state=str(session_file))
                except Exception:
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()
                
            self._page = await self._context.new_page()

            # Ağ isteklerinden güncel oturum token'ını dinamik yakala
            def on_req(r):
                t = r.headers.get("token")
                if t:
                    self._token = t
                    self._sln = r.headers.get("sln", "1")
            self._page.on("request", on_req)

    async def is_session_valid(self) -> bool:
        if not self._page:
            await self._init_browser()
            
        try:
            cur_url = self._page.url or ""
            # Hızlı kontrol: Zaten FrameWorkT1 sayfasındaysak yeniden goto yapmadan 1ms'de DOM kontrolü yap
            if "FrameWorkT1" in cur_url:
                ready = await self._page.evaluate("""() => {
                    return !!(document.querySelector('#input-99') || document.querySelector('.basket-chip') || document.querySelector("input[placeholder*='Barkod']"));
                }""")
                if ready:
                    return True

            await self._page.goto(self.FRAMEWORK_URL, wait_until="domcontentloaded", timeout=15000)
            await self._page.wait_for_selector("input[placeholder*='Barkod'], #input-99, .basket-chip", timeout=6000)
            return True
        except Exception:
            return False

    async def _login_unlocked(self) -> bool:
        """İSKOOP Portalına giriş yapar (kilit içerisinden çağrılır)."""
        await self._init_browser()
        
        if await self.is_session_valid():
            print("[İSKOOP] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            return True

        if not self.username or not self.password:
            raise ValueError("İSKOOP için Kullanıcı Adı ve Şifre zorunludur.")

        print("[İSKOOP] Giriş yapılıyor...")
        await self._page.goto(self.PORTAL_URL, wait_until="domcontentloaded", timeout=20000)

        await self._page.fill("#logonuidfield", str(self.username))
        await self._page.fill("#logonpassfield", str(self.password))
        await self._page.click('input[name="login"]')
        
        await self._page.wait_for_load_state("domcontentloaded")
        await asyncio.sleep(2.5)

        if "irj/portal" not in (self._page.url or "") and "FrameWorkT1" not in (self._page.url or ""):
            raise RuntimeError("İSKOOP Giriş Başarısız! Bilgileri kontrol edin.")

        try:
            await self._page.goto(self.FRAMEWORK_URL, wait_until="domcontentloaded", timeout=15000)
            await self._page.wait_for_selector("input[placeholder*='Barkod'], #input-99, .basket-chip", timeout=6000)
        except Exception:
            pass

        session_file = SessionStore.get_session_file("iskoop")
        await self._context.storage_state(path=str(session_file))
        print("[İSKOOP] Başarıyla giriş yapıldı ve oturum kaydedildi.")
        self.is_logged_in = True
        return True

    async def login(self) -> bool:
        """İSKOOP Portalına giriş yapar."""
        async with self._lock:
            return await self._login_unlocked()

    async def _ensure_ready_page(self):
        if not self._page:
            await self._init_browser()
        cur_url = self._page.url or ""
        if "FrameWorkT1" not in cur_url:
            await self._page.goto(self.FRAMEWORK_URL, wait_until="domcontentloaded", timeout=15000)
            try:
                await self._page.wait_for_selector("input[placeholder*='Barkod'], #input-99, .basket-chip", timeout=5000)
            except Exception:
                pass
        if not self._token:
            try:
                tok_info = await self._page.evaluate("""async () => {
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = el ? el.__vue__ : null;
                    while (cur && cur.$parent) cur = cur.$parent;
                    const store = cur ? cur.$store : null;
                    if (store && store.state && store.state.authentication && store.state.authentication.token) {
                        const auth = store.state.authentication;
                        const sln = (auth.challenge && auth.challenge.solution && String(auth.challenge.solution.number)) || '1';
                        return { token: auth.token, sln: sln };
                    }
                    if (store) {
                        try { await store.dispatch('basket/fetchBaskets', { basketOwnerType: 'T' }); } catch(e) {}
                    }
                    return null;
                }""")
                if tok_info and tok_info.get("token"):
                    self._token = tok_info["token"]
                    self._sln = tok_info.get("sln") or "1"
            except Exception:
                pass
            if not self._token:
                try:
                    await self._page.goto(self.FRAMEWORK_URL, wait_until="domcontentloaded", timeout=10000)
                    await self._page.wait_for_selector("input[placeholder*='Barkod'], #input-99, .basket-chip", timeout=4000)
                except Exception:
                    pass

    async def search_product(self, query: str, include_equivalents: bool = True, is_background: bool = False) -> List[DepoUrunSarti]:
        """İSKOOP'ta ürün ara ve şartları getir (Doğrudan barkod + MATNR önbellekli hızlı sorgu)."""
        if is_background and getattr(self, "_cart_busy", 0) > 0:
            return []
        async with self._lock:
            if is_background and getattr(self, "_cart_busy", 0) > 0:
                return []
            if not self.is_logged_in:
                if await self.is_session_valid():
                    self.is_logged_in = True
                else:
                    await self._login_unlocked()

            await self._ensure_ready_page()
            clean_q = str(query).strip()
            if len(clean_q) == 14 and clean_q.startswith("0"):
                clean_q = clean_q[1:]
            if not is_background:
                print(f"[İSKOOP] '{clean_q}' sorgulanıyor...")

            target_barcode = clean_q if (clean_q.isdigit() and len(clean_q) >= 8) else ""
            stripped_bc = target_barcode.lstrip("0") if target_barcode else ""
            fallback_word = ""
            name_tokens: List[str] = []

            if target_barcode:
                try:
                    from backend.catalog import catalog
                    cp = catalog.get_by_barcode(target_barcode)
                    if cp and cp.get("name"):
                        words = re.sub(r'[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]', ' ', cp["name"]).strip().split()
                        if words:
                            fallback_word = words[0].upper()
                            name_tokens = [w.upper() for w in words if len(w) >= 2]
                except Exception:
                    pass

            cached_matnr = (
                self._matnr_cache.get(clean_q)
                or (self._matnr_cache.get(target_barcode) if target_barcode else None)
                or (self._matnr_cache.get(stripped_bc) if stripped_bc else None)
            )

            search_queries = []
            if target_barcode:
                if stripped_bc and stripped_bc != target_barcode:
                    search_queries.append(stripped_bc)
                search_queries.append(target_barcode)
                if fallback_word and fallback_word not in search_queries:
                    search_queries.append(fallback_word)
            else:
                search_queries.append(clean_q)

            js_iskoop_search = '''async (info) => {
                const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                let cur = el ? el.__vue__ : null;
                while (cur && cur.$parent) cur = cur.$parent;
                const store = cur ? cur.$store : null;
                const auth = (store && store.state && store.state.authentication) || {};
                const activeToken = auth.token || info.token || '';
                const activeSln = (auth.challenge && auth.challenge.solution && String(auth.challenge.solution.number)) || info.sln || '1';
                if (!activeToken) return { _session_expired: true };

                const headersGet = {
                    'accept': 'application/json;charset=UTF-8',
                    'token': activeToken,
                    'sln': activeSln
                };
                const headersPost = {
                    'accept': 'application/json;charset=UTF-8',
                    'content-type': 'application/json',
                    'token': activeToken,
                    'sln': activeSln
                };
                const discovered = {};

                async function fetchDetail(matnr) {
                    const r2 = await fetch('/MainService/api/rfc/mat/ms?MATNR=' + encodeURIComponent(matnr), {
                        method: 'POST',
                        headers: headersPost,
                        body: '{}'
                    });
                    if (r2.status === 401 || r2.status === 403) return { _session_expired: true };
                    if (!r2.ok) return null;
                    const d2 = await r2.json();
                    const mk = d2.EP_S_MALZEME_KARTI || {};
                    if (!mk.MATNR && matnr) mk.MATNR = matnr;
                    if (mk.BARKOD && mk.MATNR) {
                        discovered[mk.BARKOD] = mk.MATNR;
                    }
                    return d2;
                }

                try {
                    // A) Önbellekte MATNR varsa doğrudan tek istekte çek (~80ms!)
                    if (info.cachedMatnr) {
                        const directData = await fetchDetail(info.cachedMatnr);
                        if (directData && directData._session_expired) return { _session_expired: true };
                        if (directData && directData.EP_S_MALZEME_KARTI && directData.EP_S_MALZEME_KARTI.MAKTX) {
                            return { data: directData, discovered, token: activeToken, sln: activeSln };
                        }
                    }

                    // B) Sırasıyla barkod (doğrudan tek sonuç!) ve gerekirse ilk kelime ile ara
                    for (const qStr of (info.queries || [])) {
                        const isBcQuery = /^\\d{8,14}$/.test(qStr);
                        const r1 = await fetch('/MainService/api/rfc/mat/sm?ST=' + encodeURIComponent(qStr) + '&TYP=3', {
                            headers: headersGet
                        });
                        if (r1.status === 401 || r1.status === 403) {
                            return { _session_expired: true };
                        }
                        if (!r1.ok) continue;
                        const d1 = await r1.json();
                        let matList = d1.ET_MAKTX || [];
                        if (matList.length === 0) continue;

                        // Doğrudan barkod sorgusunda tek sonuç döndüyse anında detayını çek!
                        if (isBcQuery && matList.length === 1 && matList[0].MATNR) {
                            const d2 = await fetchDetail(matList[0].MATNR);
                            if (d2 && d2._session_expired) return { _session_expired: true };
                            if (d2 && d2.EP_S_MALZEME_KARTI && d2.EP_S_MALZEME_KARTI.MAKTX) {
                                return { data: d2, discovered, token: activeToken, sln: activeSln };
                            }
                        }

                        if (info.barcode) {
                            const tokens = info.tokens || [];
                            if (tokens.length > 1) {
                                matList = matList.slice().sort((a, b) => {
                                    const ma = String(a.MAKTX || '').toUpperCase();
                                    const mb = String(b.MAKTX || '').toUpperCase();
                                    let sa = 0, sb = 0;
                                    for (const t of tokens) {
                                        if (ma.includes(t)) sa++;
                                        if (mb.includes(t)) sb++;
                                    }
                                    return sb - sa;
                                });
                            }

                            const maxCheck = Math.min(matList.length, 18);
                            const chunkSize = 6;
                            for (let i = 0; i < maxCheck; i += chunkSize) {
                                const chunk = matList.slice(i, i + chunkSize);
                                const chunkResults = await Promise.all(chunk.map(it => fetchDetail(it.MATNR)));
                                for (const d2 of chunkResults) {
                                    if (d2 && d2._session_expired) return { _session_expired: true };
                                    if (d2 && d2.EP_S_MALZEME_KARTI) {
                                        const foundBc = String(d2.EP_S_MALZEME_KARTI.BARKOD || '').trim();
                                        if (foundBc === info.barcode || foundBc.replace(/^0+/, '') === info.strippedBarcode) {
                                            return { data: d2, discovered, token: activeToken, sln: activeSln };
                                        }
                                    }
                                }
                            }
                        } else {
                            const matnr = matList[0].MATNR;
                            if (!matnr) continue;
                            const d2 = await fetchDetail(matnr);
                            if (d2 && d2._session_expired) return { _session_expired: true };
                            if (d2) return { data: d2, discovered, token: activeToken, sln: activeSln };
                        }
                    }
                    return { items: [], discovered, token: activeToken, sln: activeSln };
                } catch (e) {
                    return { error: e.toString(), discovered };
                }
            }'''

            # 1. Hızlı Doğrudan API Yolu (Doğrudan barkod ile tek adımda ~450-700 ms)
            try:
                payload = {
                    "queries": search_queries,
                    "barcode": target_barcode,
                    "strippedBarcode": stripped_bc,
                    "tokens": name_tokens,
                    "cachedMatnr": cached_matnr,
                    "token": self._token or "",
                    "sln": self._sln or "1"
                }
                res_api = await self._page.evaluate(js_iskoop_search, payload)

                if isinstance(res_api, dict) and res_api.get("_session_expired"):
                    print("[İSKOOP] Oturum veya token süresi dolmuş, otomatik yenileniyor...")
                    self._token = None
                    self.is_logged_in = False
                    SessionStore.clear("iskoop")
                    await self._login_unlocked()
                    await self._ensure_ready_page()
                    payload["token"] = self._token or ""
                    payload["sln"] = self._sln or "1"
                    res_api = await self._page.evaluate(js_iskoop_search, payload)

                if isinstance(res_api, dict):
                    if res_api.get("token"):
                        self._token = res_api["token"]
                        self._sln = res_api.get("sln") or "1"
                    if isinstance(res_api.get("discovered"), dict):
                        for bc_k, mat_v in res_api["discovered"].items():
                            if bc_k and mat_v:
                                self._matnr_cache[str(bc_k).strip()] = str(mat_v).strip()

                    if res_api.get("data"):
                        return self._parse_iskoop_detail(res_api["data"], clean_q)
                    elif "items" in res_api and len(res_api["items"]) == 0:
                        return []
            except Exception as e:
                print(f"[İSKOOP] Hızlı API arama uyarısı: {e}, UI aramasına geçiliyor...")

            # 2. UI Arama Fallback
            captured_ms = {}
            ms_event = asyncio.Event()
            async def on_response(res):
                if "mat/ms" in res.url:
                    try:
                        captured_ms["data"] = await res.json()
                        ms_event.set()
                    except Exception:
                        pass

            self._page.on("response", on_response)

            try:
                try:
                    await self._page.evaluate("() => document.querySelectorAll('.v-overlay--active').forEach(el => el.remove())")
                except Exception:
                    pass

                search_input = await self._page.wait_for_selector('input[placeholder*="Barkod"], #input-99', timeout=4000)
                await search_input.fill(clean_q)
                await search_input.press("Enter")

                try:
                    await asyncio.wait_for(ms_event.wait(), timeout=2.5)
                except asyncio.TimeoutError:
                    pass

                if "data" not in captured_ms:
                    return []

                detail = captured_ms["data"]
                return self._parse_iskoop_detail(detail, clean_q)
            except Exception as e:
                print(f"[İSKOOP] Arama hatası: {e}")
                return []
            finally:
                try:
                    self._page.remove_listener("response", on_response)
                except Exception:
                    pass

    def _parse_iskoop_detail(self, detail: Dict[str, Any], query: str) -> List[DepoUrunSarti]:
        mat_kart = detail.get("EP_S_MALZEME_KARTI") or {}
        vwerk = detail.get("EP_S_VWERK") or {}
        baremler = detail.get("EP_T_BAREM") or []
        klasm = detail.get("EP_T_KLASM") or []

        ad = mat_kart.get("MAKTX", "")
        if not ad:
            return []

        barkod = str(mat_kart.get("BARKOD") or query).strip()
        raw_matnr = str(mat_kart.get("MATNR", "")).strip()
        matnr = raw_matnr.lstrip("0")

        # Hızlı sepet ve arama önbelleğine kaydet
        if raw_matnr:
            padded_matnr = raw_matnr.zfill(18)
            if barkod:
                self._matnr_cache[barkod] = padded_matnr
            if matnr:
                self._matnr_cache[matnr] = padded_matnr
            if query:
                self._matnr_cache[str(query).strip()] = padded_matnr

        psf = float(mat_kart.get("PSF") or 0.0)
        dsf = float(mat_kart.get("DSF") or 0.0)
        if dsf == 0.0 and psf > 0:
            dsf = round(psf * 0.7102, 2)
        kdv_orani = float(mat_kart.get("KDV") or 10.0)
        kamu_iskontosu = float(str(mat_kart.get("KIST") or 0.0).replace(",", "."))
        eczaci_kari = float(str(mat_kart.get("ECKAR") or 0.0).replace(",", "."))
        esdeger_kodu = str(mat_kart.get("ZZSES") or "").strip() or None

        # Stok durumu
        stok_mevcut = vwerk.get("STOK_MEVCUT") or ""
        stok_durumu = StokDurumu.VAR if stok_mevcut in ["T", "X", "1", "Var"] else StokDurumu.YOK
        if not hasattr(self, "_stock_cache"):
            self._stock_cache = {}
        is_in_stock = (stok_durumu == StokDurumu.VAR)
        if barkod:
            self._stock_cache[barkod] = is_in_stock
        if matnr:
            self._stock_cache[matnr] = is_in_stock

        if not klasm:
            klasm = [{"KLASM": "030", "VADE_ADI": "30 Gün", "DSF": dsf, "NETFIYAT": dsf, "ZTC1": 0.0}]

        sonuclar: List[DepoUrunSarti] = []

        # Her bir ödeme seçeneğini (KLASM) ayrı bir şart olarak değerlendir (90 Gün Vade & Kredi Kartı)
        for k in klasm:
            k_klasm = str(k.get("KLASM", "")).strip()
            vade_adi = str(k.get("VADE_ADI", "")).strip()

            is_kk = ("Kredi Kartı" in vade_adi or "Peşin" in vade_adi or "Online" in vade_adi or k_klasm == "004")
            vade = 0 if is_kk else 30
            if not is_kk:
                v_match = re.search(r"\d+", vade_adi)
                if v_match:
                    vade = int(v_match.group(0))

            # İsimlendirme: Tek şart varsa "İSKOOP", çoklu şart varsa "İSKOOP (Kredi Kartı)" / "İSKOOP (90 Gün Vade)"
            if len(klasm) > 1:
                if is_kk:
                    depo_gorunen_ad = "İSKOOP (Kredi Kartı)"
                else:
                    depo_gorunen_ad = f"İSKOOP ({vade} Gün Vade)"
            else:
                depo_gorunen_ad = self.depo_adi

            # Bu KLASM'a ait baremleri filtrele
            matching_baremler = [b for b in baremler if str(b.get("KLASM", "")).strip() == k_klasm]
            if not matching_baremler and len(klasm) == 1:
                matching_baremler = baremler

            k_dsf = float(k.get("DSF") or dsf)
            if k_dsf == 0.0:
                k_dsf = dsf

            k_net = float(k.get("NETFIYAT") or k_dsf)
            en_iyi_net = k_net
            ticari_iskonto = 0.0

            # 1. k içinden iskonto (ZTC1, TEXT_ZTC)
            k_ztc1 = float(str(k.get("ZTC1") or 0).replace(",", "."))
            k_text_ztc = str(k.get("TEXT_ZTC") or "").replace(",", ".").strip()
            if k_ztc1 > 0:
                ticari_iskonto = max(ticari_iskonto, k_ztc1)
            elif k_text_ztc.replace(".", "", 1).isdigit() and float(k_text_ztc) > 0:
                ticari_iskonto = max(ticari_iskonto, float(k_text_ztc))

            # 2. k_net vs k_dsf
            if k_dsf > 0 and k_net > 0 and k_net < (k_dsf - 0.01):
                isk_from_knet = round((1.0 - (k_net / k_dsf)) * 100.0, 2)
                ticari_iskonto = max(ticari_iskonto, isk_from_knet)

            # 3. Baremleri tara
            mf_set = set()
            for b in matching_baremler:
                b_adi = str(b.get("BAREM_ADI", "")).strip()
                if "+" in b_adi:
                    mf_set.add(b_adi.replace(" ", ""))

                b_isk = float(str(b.get("ZTC8_ISK") or 0).replace(",", "."))
                if b_isk > 0:
                    ticari_iskonto = max(ticari_iskonto, b_isk)

                b_nf = float(b.get("NETFIYAT") or 0.0)
                if k_dsf > 0 and b_nf > 0 and b_nf < (k_dsf - 0.01):
                    isk_from_bnf = round((1.0 - (b_nf / k_dsf)) * 100.0, 2)
                    ticari_iskonto = max(ticari_iskonto, isk_from_bnf)

                bf = float(b.get("BIRIMFIYAT") or 0.0)
                fiyat_aday = bf if bf > 0 else b_nf
                if fiyat_aday > 0:
                    if en_iyi_net == 0 or fiyat_aday < en_iyi_net:
                        en_iyi_net = fiyat_aday

            mf_text = " / ".join(sorted(list(mf_set))) if mf_set else "YOK"

            # 4. MF ve ticari iskonto korelasyonu (MF varken de iskonto kontrolü)
            pairs = CostCalculator.parse_mf_pairs(mf_text)
            best_mf_carpan = min((a / (a + h)) for a, h in pairs) if pairs else 1.0
            expected_net_mf = k_dsf * best_mf_carpan

            if k_dsf > 0 and en_iyi_net > 0 and expected_net_mf > 0:
                if en_iyi_net < (expected_net_mf - 0.05):
                    derived_isk = round((1.0 - (en_iyi_net / expected_net_mf)) * 100.0, 2)
                    ticari_iskonto = max(ticari_iskonto, derived_isk)

            maliyet = CostCalculator.calculate(
                dsf=k_dsf if k_dsf > 0 else en_iyi_net,
                psf=psf,
                kdv_orani=kdv_orani,
                mf_str=mf_text,
                ticari_iskonto=ticari_iskonto,
                vade_gun=vade
            )

            final_net = min(en_iyi_net, maliyet.net_birim_maliyet) if (en_iyi_net > 0 and maliyet.net_birim_maliyet > 0) else maliyet.net_birim_maliyet
            final_net_kdvli = round(final_net * (1.0 + (kdv_orani / 100.0)), 2)

            notlar = [f"{vade} Gün Vade" if vade > 0 else "Peşin / Kredi Kartı"]
            if mf_text != "YOK":
                notlar.append(f"MF: {mf_text}")
            if ticari_iskonto > 0:
                notlar.append(f"İsk: %{ticari_iskonto}")

            sarti = DepoUrunSarti(
                depo=DepoKodu.ISKOOP,
                depo_adi=depo_gorunen_ad,
                barkod=barkod,
                urun_id=matnr,
                urun_adi=ad,
                esdeger_kodu=esdeger_kodu,
                stok_durumu=stok_durumu,
                stok_adedi=None,
                depocu_satis_fiyati=round(k_dsf, 2),
                perakende_satis_fiyati=round(psf, 2),
                kdv_orani=kdv_orani,
                mf_metni=mf_text,
                kademeler=maliyet.kademeler,
                ticari_iskonto=round(ticari_iskonto, 2),
                vade_gun=vade,
                net_birim_maliyet=round(final_net, 2),
                net_birim_maliyet_kdvli=final_net_kdvli,
                toplam_indirim_yuzdesi=maliyet.toplam_iskonto_orani,
                ozel_kampanya_notu=" • ".join(notlar),
                kamu_iskontosu=round(kamu_iskontosu, 2),
                eczaci_kari=round(eczaci_kari, 2)
            )
            sonuclar.append(sarti)

        return sonuclar

    async def _resolve_matnr(self, urun_id: str = "", barcode: str = "", product_name: str = "") -> Optional[str]:
        """İSKOOP SAP MATNR kodunu çözer (Önbellekte varsa 0ms'de döner)."""
        target_uid = str(urun_id or "").strip()
        clean_bc = str(barcode or "").strip()
        if len(clean_bc) == 14 and clean_bc.startswith("0"):
            clean_bc = clean_bc[1:]

        # 0. Önbellek kontrolü (0ms)
        if target_uid and target_uid in self._matnr_cache:
            return self._matnr_cache[target_uid]
        if clean_bc and clean_bc in self._matnr_cache:
            return self._matnr_cache[clean_bc]

        if target_uid.isdigit() and not target_uid.startswith("869") and not target_uid.startswith("0869") and len(target_uid) <= 18:
            padded = target_uid.zfill(18)
            self._matnr_cache[target_uid] = padded
            if clean_bc:
                self._matnr_cache[clean_bc] = padded
            return padded

        name = str(product_name or "").strip()
        if not name and clean_bc and clean_bc.isdigit() and len(clean_bc) >= 8:
            try:
                from backend.catalog import catalog
                cp = catalog.get_by_barcode(clean_bc)
                if cp and cp.get("name"):
                    name = cp["name"]
            except Exception:
                pass

        if not name and clean_bc:
            name = clean_bc

        if not name:
            return None

        words = re.sub(r'[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]', ' ', name).strip().split()
        first_word = words[0].upper() if words else name
        tokens = [w.upper() for w in words if len(w) >= 2]
        valid_bc = clean_bc if (clean_bc.isdigit() and len(clean_bc) >= 8) else ""
        stripped_bc = valid_bc.lstrip("0") if valid_bc else ""

        try:
            matched_matnr = await self._page.evaluate("""async (args) => {
                try {
                    const rootEl = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = rootEl ? rootEl.__vue__ : null;
                    while (cur && cur.$parent) cur = cur.$parent;
                    const store = cur ? cur.$store : null;
                    const auth = (store && store.state && store.state.authentication) ? store.state.authentication : {};
                    const liveToken = auth.token || args.token || '';
                    const liveSln = String(auth.sln || args.sln || '1');

                    // 1. ÖNCE DOĞRUDAN BARKOD İLE mat/sm SORGULA (Tek çağrı, ~500ms!)
                    if (args.barcode) {
                        const bcQueries = [];
                        if (args.strippedBc && args.strippedBc !== args.barcode) {
                            bcQueries.push(args.strippedBc);
                        }
                        bcQueries.push(args.barcode);
                        for (const bcQ of bcQueries) {
                            const rBc = await fetch('/MainService/api/rfc/mat/sm?ST=' + encodeURIComponent(bcQ) + '&TYP=3', {
                                headers: { 'accept': 'application/json', 'token': liveToken, 'sln': liveSln }
                            });
                            if (rBc.ok) {
                                const dBc = await rBc.json();
                                const bcItems = dBc.ET_MAKTX || [];
                                if (bcItems.length === 1 && bcItems[0].MATNR) {
                                    return bcItems[0].MATNR;
                                } else if (bcItems.length > 1) {
                                    for (const it of bcItems.slice(0, 6)) {
                                        const r2 = await fetch('/MainService/api/rfc/mat/ms?MATNR=' + it.MATNR, {
                                            method: 'POST',
                                            headers: { 'accept': 'application/json', 'content-type': 'application/json', 'token': liveToken, 'sln': liveSln },
                                            body: '{}'
                                        });
                                        if (r2.ok) {
                                            const d2 = await r2.json();
                                            const mk = d2.EP_S_MALZEME_KARTI || {};
                                            const itemBc = String(mk.BARKOD || '').trim();
                                            if (itemBc === args.barcode || (args.strippedBc && itemBc.replace(/^0+/, '') === args.strippedBc)) {
                                                return it.MATNR;
                                            }
                                        }
                                    }
                                    return bcItems[0].MATNR;
                                }
                            }
                        }
                    }

                    // 2. BARKODLA BULUNAMAZSA İLK KELİME İLE SORGULA
                    const r1 = await fetch('/MainService/api/rfc/mat/sm?ST=' + encodeURIComponent(args.query) + '&TYP=3', {
                        headers: { 'accept': 'application/json', 'token': liveToken, 'sln': liveSln }
                    });
                    const d1 = await r1.json();
                    let items = d1.ET_MAKTX || [];
                    if (items.length === 0) return null;

                    if (args.barcode) {
                        const tokens = args.tokens || [];
                        if (tokens.length > 1) {
                            items = items.slice().sort((a, b) => {
                                const ma = String(a.MAKTX || '').toUpperCase();
                                const mb = String(b.MAKTX || '').toUpperCase();
                                let sa = 0, sb = 0;
                                for (const t of tokens) {
                                    if (ma.includes(t)) sa++;
                                    if (mb.includes(t)) sb++;
                                }
                                return sb - sa;
                            });
                        }
                        const chunkSize = 4;
                        for (let i = 0; i < Math.min(items.length, 24); i += chunkSize) {
                            const chunk = items.slice(i, i + chunkSize);
                            const results = await Promise.all(chunk.map(async (it) => {
                                const r2 = await fetch('/MainService/api/rfc/mat/ms?MATNR=' + it.MATNR, {
                                    method: 'POST',
                                    headers: { 'accept': 'application/json', 'content-type': 'application/json', 'token': liveToken, 'sln': liveSln },
                                    body: '{}'
                                });
                                if (!r2.ok) return null;
                                const d2 = await r2.json();
                                const mk = d2.EP_S_MALZEME_KARTI || {};
                                const itemBc = String(mk.BARKOD || '').trim();
                                return (itemBc === args.barcode || (args.strippedBc && itemBc.replace(/^0+/, '') === args.strippedBc)) ? it.MATNR : null;
                            }));
                            const hit = results.find(x => !!x);
                            if (hit) return hit;
                        }
                    }
                    return items[0].MATNR || null;
                } catch(e) {
                    return null;
                }
            }""", {
                "query": first_word,
                "barcode": valid_bc,
                "strippedBc": stripped_bc,
                "tokens": tokens,
                "token": self._token,
                "sln": self._sln
            })
            if matched_matnr:
                padded = str(matched_matnr).strip().zfill(18)
                if clean_bc:
                    self._matnr_cache[clean_bc] = padded
                if target_uid:
                    self._matnr_cache[target_uid] = padded
                return padded
        except Exception:
            pass

        return None

    async def _add_to_cart_unlocked(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        barkod = str(kwargs.get("barkod") or "").strip()
        if len(barkod) == 14 and barkod.startswith("0"):
            barkod = barkod[1:]
        product_name = str(kwargs.get("name") or kwargs.get("urun_adi") or "").strip()
        if not barkod and str(urun_id).isdigit() and len(str(urun_id)) >= 8 and str(urun_id).startswith("869"):
            barkod = str(urun_id).strip()

        if not product_name and barkod:
            try:
                from backend.catalog import catalog
                cp = catalog.get_by_barcode(barkod)
                if cp and cp.get("name"):
                    product_name = cp["name"]
            except Exception:
                pass

        # 0. Önbellekten stok kontrolü (Stokta yoksa 2ms'de dön!)
        stock_cache = getattr(self, "_stock_cache", {})
        uid_str = str(urun_id or "").strip()
        if (uid_str in stock_cache and stock_cache[uid_str] is False) or (barkod and barkod in stock_cache and stock_cache[barkod] is False):
            return {
                "success": False,
                "depo": "ISKOOP",
                "message": f"{product_name or barkod or uid_str} İSKOOP deposunda stokta mevcut değil."
            }

        # 1. Yanıt dinleyiciyi kur (Event tabanlı anlık tetikleme)
        captured_order = {}
        order_error_msg = None
        order_event = asyncio.Event()
        async def on_resp(res):
            nonlocal order_error_msg
            if "order/oc" in res.url or "order/ab" in res.url:
                try:
                    data = await res.json()
                    captured_order[res.url] = data
                    if isinstance(data, dict):
                        ret = data.get("EP_S_RETURN") or {}
                        if ret.get("MESSAGE"):
                            order_error_msg = ret.get("MESSAGE")
                        for r in (data.get("EP_T_RETURN") or []):
                            if r.get("MESSAGE"):
                                order_error_msg = r.get("MESSAGE")
                    order_event.set()
                except Exception:
                    order_event.set()
        self._page.on("response", on_resp)

        try:
            # 2. Hedef MATNR'yi çözümle (Önbellekte varsa 0ms!)
            matnr = await self._resolve_matnr(urun_id=urun_id, barcode=barkod, product_name=product_name)

            # 3. Sayfadaki eski ürün butonunu sıfırla ve hedef ürüne tek JS adımında yönlen
            if matnr:
                await self._page.evaluate("""async (m) => {
                    document.querySelectorAll('.add-to-basket-btn').forEach(b => b.remove());
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = el ? el.__vue__ : null;
                    while (cur && cur.$parent) { cur = cur.$parent; }
                    const store = cur ? cur.$store : null;
                    const router = cur ? cur.$router : null;
                    if (store) {
                        try { store.dispatch('basket/clearAddingProduct'); } catch(e) {}
                    }
                    if (router) {
                        const targetPath = '/medicine-detail/' + m;
                        if (router.currentRoute && router.currentRoute.path === targetPath) {
                            try { await router.replace('/dashboard'); } catch(e) {}
                        }
                        try {
                            await router.push(targetPath);
                        } catch(e) {}
                    }
                }""", matnr)
            else:
                await self._page.evaluate("""() => {
                    document.querySelectorAll('.add-to-basket-btn').forEach(b => b.remove());
                    const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                    let cur = el ? el.__vue__ : null;
                    while (cur && cur.$parent) { cur = cur.$parent; }
                    const store = cur ? cur.$store : null;
                    if (store) {
                        try { store.dispatch('basket/clearAddingProduct'); } catch(e) {}
                    }
                }""")
                search_q = product_name or barkod or urun_id
                try:
                    search_input = await self._page.wait_for_selector('input[placeholder*="Barkod"], #input-99', timeout=4000)
                    await search_input.click()
                    await self._page.keyboard.press("Control+A")
                    await self._page.keyboard.press("Backspace")
                    await search_input.fill(search_q)
                    await asyncio.sleep(0.15)
                    item_elem = await self._page.wait_for_selector('.v-list-item[class*="item-"]', timeout=1200)
                    if item_elem:
                        await item_elem.click()
                    else:
                        await search_input.press("Enter")
                except Exception:
                    pass

            # 4. Hedef ürünün sayfada yüklendiğini DOĞRULA ve yüklendiği anda tek adımda miktarı yazıp tıkla!
            target_keywords = []
            if product_name:
                w = re.sub(r'[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]', ' ', product_name).strip().split()
                if w:
                    target_keywords.append(w[0].upper())
            target_matnr_short = matnr.lstrip("0") if matnr else ""

            prod_state = await self._page.evaluate("""async (params) => {
                const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                const normTr = (s) => String(s || '').toUpperCase()
                    .replace(/İ/g, 'I').replace(/İ/g, 'I')
                    .replace(/Ğ/g, 'G').replace(/Ü/g, 'U')
                    .replace(/Ş/g, 'S').replace(/Ö/g, 'O').replace(/Ç/g, 'C');
                let lastState = { found: false };
                let triedNonMedicine = false;

                for (let i = 0; i < 65; i++) { // 65 * 50ms = 3.25 saniye (yüklendiği ilk 50ms'de yakalar!)
                    const btn = document.querySelector('.add-to-basket-btn');
                    if (!btn && i === 25 && params.fullMatnr && !triedNonMedicine) {
                        triedNonMedicine = true;
                        const rootEl = document.querySelector('#app') || document.querySelector('.v-application') || document.body.firstElementChild;
                        let rCur = rootEl ? rootEl.__vue__ : null;
                        while (rCur && rCur.$parent) rCur = rCur.$parent;
                        if (rCur && rCur.$router) {
                            try { rCur.$router.push('/non-medicine-detail/' + params.fullMatnr); } catch(e) {}
                        }
                    }
                    if (btn) {
                        const p = btn.__vue__ ? btn.__vue__.$parent : null;
                        const store = p ? p.$store : null;
                        const router = p ? p.$router : null;
                        const activeBasket = store ? store.getters['basket/getActiveBasket'] : null;
                        const alreadyInBasket = store ? store.getters['basket/hasAnyBasketContainsAddingProduct'] : false;
                        const dm = p ? p.dataModel : null;
                        const curName = normTr((dm && dm.name) || '');
                        const routeId = (router && router.currentRoute && router.currentRoute.params && router.currentRoute.params.id) || '';
                        const curMatnr = String((dm && (dm.matnr || dm.id)) || routeId || '').replace(/^0+/, '');

                        let targetLoaded = false;
                        if (params.targetMatnr && curMatnr && params.targetMatnr === curMatnr) {
                            targetLoaded = true;
                        } else if (params.keywords && params.keywords.length > 0 && params.keywords.some(kw => curName.includes(normTr(kw)))) {
                            targetLoaded = true;
                        } else if (curName && (params.targetMatnr || (!params.keywords || params.keywords.length === 0))) {
                            targetLoaded = true;
                        }

                        lastState = {
                            found: true,
                            targetLoaded: targetLoaded,
                            btnDisabled: !!btn.disabled,
                            alreadyInBasket: !!alreadyInBasket,
                            activeBasketId: activeBasket ? activeBasket.id : null,
                            name: dm ? dm.name : null,
                            matnr: curMatnr || null,
                            clicked: false
                        };

                        if (targetLoaded) {
                            if (!btn.disabled && !alreadyInBasket) {
                                if (params.qty > 1 && dm) {
                                    dm.quantity = params.qty;
                                    await sleep(30);
                                }
                                btn.click();
                                lastState.clicked = true;
                            }
                            return lastState;
                        }
                    }
                    await sleep(50);
                }
                return lastState;
            }""", {
                "targetMatnr": target_matnr_short,
                "fullMatnr": matnr or "",
                "keywords": target_keywords,
                "qty": int(miktar)
            })

            if not prod_state.get("found"):
                return {
                    "success": False,
                    "depo": "ISKOOP",
                    "message": f"Ürün ({product_name or barkod or urun_id}) İSKOOP'ta bulunamadı veya stokta mevcut değil."
                }

            if not prod_state.get("targetLoaded"):
                loaded_name = prod_state.get("name") or "Bilinmeyen Ürün"
                return {
                    "success": False,
                    "depo": "ISKOOP",
                    "message": f"İSKOOP sayfasında hedeflenen ürün ({product_name or barkod}) yerine '{loaded_name}' yüklü kaldı. Yanlış ürün eklenmemesi için işlem durduruldu."
                }

            if prod_state.get("name"):
                product_name = prod_state.get("name")

            if prod_state.get("btnDisabled"):
                return {
                    "success": False,
                    "depo": "ISKOOP",
                    "message": f"{product_name} İSKOOP deposunda stokta yok veya sepete ekleme butonu pasif (Tevzi kota dolmuş olabilir)."
                }

            if prod_state.get("alreadyInBasket"):
                doc_no = prod_state.get("activeBasketId") or ""
                msg = f"{product_name} zaten İSKOOP taslak sepetinizde kayıtlı."
                if doc_no:
                    msg += f" (Belge No: {doc_no})"
                return {
                    "success": True,
                    "depo": "ISKOOP",
                    "message": msg,
                    "urun_adi": product_name,
                    "belge_no": doc_no,
                    "already_in_cart": True
                }

            # 5. Sipariş yanıtını Event ile bekle (200ms uyuma döngüsü olmadan yanıt geldiği salisede devam eder!)
            if not captured_order:
                try:
                    await asyncio.wait_for(order_event.wait(), timeout=2.5)
                except asyncio.TimeoutError:
                    pass

            oc_data = None
            for u, d in captured_order.items():
                if "order/oc" in u:
                    oc_data = d
                    break
                elif "order/ab" in u and not oc_data:
                    oc_data = d

            skip_cart_status = kwargs.get("skip_cart_status", False)
            in_cart = False
            cart_after = {}
            if oc_data:
                in_cart = True
            elif not skip_cart_status:
                cart_after = await self._get_cart_status_unlocked()
                cart_items = cart_after.get("items", [])
                in_cart = any(barkod in it.get("kod", "") or it.get("kod", "") in barkod or (product_name and product_name[:6].lower() in it.get("ad", "").lower()) for it in cart_items)

            if oc_data or in_cart:
                vbeln = (oc_data.get("VBELN", "") if oc_data else "") or cart_after.get("basket_id", "")
                toplam_tutar = (oc_data.get("TOPLAM_TUTAR") if oc_data else None) or cart_after.get("total_amount")
                return {
                    "success": True,
                    "depo": "ISKOOP",
                    "message": f"{product_name} ({miktar} adet) İSKOOP taslak siparişine başarıyla eklendi (Belge No: {vbeln}).",
                    "belge_no": vbeln,
                    "miktar": int(miktar),
                    "urun_adi": product_name,
                    "cart_total": toplam_tutar
                }
            else:
                err_detail = order_error_msg or "Stok yetersiz, kota aşıldı veya İSKOOP sepeti onaylamadı."
                return {
                    "success": False,
                    "depo": "ISKOOP",
                    "message": f"{product_name} İSKOOP sepetine eklenemedi: {err_detail}"
                }
        finally:
            try:
                self._page.remove_listener("response", on_resp)
            except Exception:
                pass

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """İSKOOP taslak siparişine ürün ekler (MATNR önbellek ve Event hızlandırmalı)."""
        async with self._lock:
            return await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)

    async def bulk_add_to_cart(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        İSKOOP taslak siparişine toplu ürün ekler.
        items: [{"barcode": "...", "miktar": 1, "name": "...", "urun_id": "..."}]
        """
        if not items:
            return {
                "success": False,
                "message": "Eklenecek ürün listesi boş.",
                "total_items": 0,
                "success_count": 0,
                "failed_count": 0,
                "total_amount": 0.0,
                "items": []
            }

        async with self._lock:
            if not self.is_logged_in:
                if await self.is_session_valid():
                    self.is_logged_in = True
                else:
                    await self._login_unlocked()
            await self._ensure_ready_page()

            results = []
            for it in items:
                bc = str(it.get("barcode") or it.get("barkod") or "").strip()
                name = str(it.get("name") or it.get("urun_adi") or "").strip()
                qty = max(1, int(it.get("miktar") or it.get("quantity") or 1))
                u_id = str(it.get("urun_id") or "").strip()

                item_res = {
                    "barcode": bc,
                    "name": name,
                    "miktar": qty,
                    "success": False,
                    "message": "",
                    "urun_adi": name,
                    "net_fiyat": 0.0,
                    "vade": 30,
                    "toplam_tutar": 0.0
                }

                try:
                    add_res = await self._add_to_cart_unlocked(urun_id=u_id or bc or name, miktar=qty, barkod=bc, name=name, skip_cart_status=True)
                    if add_res.get("success"):
                        item_res["success"] = True
                        item_res["urun_adi"] = add_res.get("urun_adi") or item_res["urun_adi"]
                        item_res["message"] = add_res.get("message") or f"{qty} Adet İSKOOP taslak siparişine eklendi."
                        if add_res.get("cart_total"):
                            item_res["toplam_tutar"] = float(add_res.get("cart_total") or 0.0)
                    else:
                        item_res["message"] = add_res.get("message") or "Sepete eklenemedi."
                except Exception as e:
                    item_res["message"] = f"Hata: {str(e)}"

                results.append(item_res)

            success_items = [r for r in results if r.get("success")]
            failed_items = [r for r in results if not r.get("success")]
            
            # Tek seferde güncel sepet tutarını al
            total_amount = 0.0
            try:
                final_cart = await self._get_cart_status_unlocked()
                total_amount = float(final_cart.get("total_amount") or 0.0)
            except Exception:
                total_amount = round(sum(r.get("toplam_tutar", 0) for r in success_items), 2)

            return {
                "success": len(success_items) > 0,
                "depo": "ISKOOP",
                "message": f"İSKOOP taslak sepetine {len(success_items)}/{len(items)} kalem ürün eklendi.",
                "total_items": len(items),
                "success_count": len(success_items),
                "failed_count": len(failed_items),
                "total_amount": total_amount,
                "items": results
            }

    def get_portal_urls(self) -> dict:
        """İSKOOP sepet ve sipariş web arayüzü linklerini döndürür."""
        return {
            "cart_url": "https://esube.iskoop.org/FrameWorkT1/#/baskets",
            "checkout_url": "https://esube.iskoop.org/FrameWorkT1/#/baskets"
        }

    async def _get_cart_status_unlocked(self) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        res = await self._page.evaluate("""async () => {
            const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
            let current = el ? el.__vue__ : null;
            while (current && current.$parent) current = current.$parent;
            const store = current ? current.$store : null;
            if (!store) return { error: "İSKOOP Vuex store bulunamadı" };

            try {
                await store.dispatch('basket/fetchBaskets', { basketOwnerType: 'T' });
            } catch(e) {}

            let activeBasket = store.getters['basket/getActiveBasket'];
            let allBaskets = store.getters['basket/getBaskets'] || [];

            if (activeBasket && activeBasket.id) {
                try {
                    await store.dispatch('basket/fetchBasketProducts', { id: activeBasket.id, willForce: true });
                } catch(e) {}
            }

            activeBasket = store.getters['basket/getActiveBasket'];
            allBaskets = store.getters['basket/getBaskets'] || [];

            let targetBasket = activeBasket;
            if (!targetBasket || !targetBasket.products || targetBasket.products.length === 0) {
                targetBasket = allBaskets.find(b => b.products && b.products.length > 0) || targetBasket;
            }

            const items = [];
            if (targetBasket && targetBasket.products) {
                for (const p of targetBasket.products) {
                    items.push({
                        id: String(p.id || ''),
                        kod: String(p.id || '').replace(/^0+/, ''),
                        ad: String(p.name || ''),
                        miktar: Number(p.quantity || 1),
                        mf: Number(p.bonusQuantity || 0),
                        birim_fiyat: Number(p.unitPrice || 0),
                        tutar: Number(p.amount || 0)
                    });
                }
            }

            const totalAmount = targetBasket ? Number(targetBasket.amount || targetBasket.totalPrice || items.reduce((a, b) => a + (b.tutar || 0), 0)) : 0;

            return {
                basketId: targetBasket ? targetBasket.id : null,
                itemCount: items.length,
                totalAmount: totalAmount,
                items: items
            };
        }""")

        items = res.get("items", [])
        total_amount = float(res.get("totalAmount") or 0.0)

        return {
            "success": True,
            "depo": "ISKOOP",
            "depo_adi": self.depo_adi,
            "supported": True,
            "item_count": len(items),
            "total_amount": round(total_amount, 2),
            "items": items,
            "cart_url": "https://esube.iskoop.org/FrameWorkT1/#/baskets",
            "checkout_url": "https://esube.iskoop.org/FrameWorkT1/#/baskets",
            "basket_id": res.get("basketId")
        }

    async def get_cart_status(self) -> Dict[str, Any]:
        """İSKOOP taslak sepetinin anlık içeriğini ve toplam tutarını sorgular."""
        async with self._lock:
            return await self._get_cart_status_unlocked()

    async def clear_cart(self) -> Dict[str, Any]:
        """İSKOOP taslak sepetindeki tüm ürünleri tek adımda temizler."""
        async with self._lock:
            if not self.is_logged_in:
                if await self.is_session_valid():
                    self.is_logged_in = True
                else:
                    await self._login_unlocked()
            await self._ensure_ready_page()

            res = await self._page.evaluate("""async () => {
                const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                let current = el ? el.__vue__ : null;
                while (current && current.$parent) current = current.$parent;
                const store = current ? current.$store : null;
                if (!store) return { success: false, message: "Vuex store bulunamadı", count: 0 };

                let activeBasket = store.getters['basket/getActiveBasket'];
                let allBaskets = store.getters['basket/getBaskets'] || [];
                let targetBasket = activeBasket || allBaskets.find(b => b && b.id);
                if (!targetBasket || !targetBasket.id) {
                    try {
                        await store.dispatch('basket/fetchBaskets', { basketOwnerType: 'T' });
                        activeBasket = store.getters['basket/getActiveBasket'];
                        allBaskets = store.getters['basket/getBaskets'] || [];
                        targetBasket = activeBasket || allBaskets.find(b => b && b.id);
                    } catch(e) {}
                }
                if (!targetBasket || !targetBasket.id) {
                    return { success: true, message: "İSKOOP sepeti zaten boş.", count: 0 };
                }
                const cnt = (targetBasket.products && targetBasket.products.length) || 1;
                try {
                    await store.dispatch('basket/deleteOrder', targetBasket.id);
                    return { success: true, message: `İSKOOP sepeti başarıyla temizlendi (${cnt} kalem silindi).`, count: cnt };
                } catch(e) {
                    return { success: false, message: "Sepet temizleme hatası: " + e.toString(), count: 0 };
                }
            }""")
            return {
                "success": bool(res.get("success")),
                "message": res.get("message") or "İSKOOP sepeti temizlendi.",
                "cleared_count": int(res.get("count") or 0)
            }

    async def finalize_order(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        """Tekli siparişi İSKOOP sepetine ekler ve depoya iletir."""
        async with self._lock:
            if not self.is_logged_in:
                if await self.is_session_valid():
                    self.is_logged_in = True
                else:
                    await self._login_unlocked()
            await self._ensure_ready_page()

            cart_status = await self._get_cart_status_unlocked()
            existing_items = cart_status.get("items", [])

            if urun_id:
                u_clean = str(urun_id).strip()
                already_in_cart = any(it.get("kod") == u_clean or it.get("id") == u_clean for it in existing_items)
                if not already_in_cart:
                    added_res = await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
                    if not added_res.get("success"):
                        return {
                            "success": False,
                            "message": f"Ürün sepete eklenemediği için sipariş sonlandırılamadı: {added_res.get('message')}"
                        }
                    cart_status = await self._get_cart_status_unlocked()
                    existing_items = cart_status.get("items", [])

            if not existing_items:
                return {"success": False, "message": "İSKOOP sepetinde siparişe dönüştürülecek ürün bulunamadı."}

            if len(existing_items) > 1 and not force:
                return {
                    "success": False,
                    "need_confirmation": True,
                    "item_count": len(existing_items),
                    "items": existing_items,
                    "total_amount": cart_status.get("total_amount", 0.0),
                    "message": f"İSKOOP sepetinizde önceden eklenmiş {len(existing_items)} farklı ürün bulunmaktadır (Toplam: {cart_status.get('total_amount', 0.0):,.2f} ₺). Tüm sepeti depoya göndermek için onay veriniz."
                }

            res = await self._page.evaluate("""async () => {
                const el = document.querySelector('#app') || document.querySelector('.v-application') || document.querySelector('.basket-chip') || document.body.firstElementChild;
                let current = el ? el.__vue__ : null;
                while (current && current.$parent) current = current.$parent;
                const store = current ? current.$store : null;
                if (!store) return { success: false, message: "Vuex store bulunamadı" };

                try {
                    await store.dispatch('basket/fetchBaskets', { basketOwnerType: 'T' });
                } catch(e) {}

                const activeBasket = store.getters['basket/getActiveBasket'];
                const allBaskets = store.getters['basket/getBaskets'] || [];
                let targetBasket = activeBasket;
                if (!targetBasket || !targetBasket.products || targetBasket.products.length === 0) {
                    targetBasket = allBaskets.find(b => b.products && b.products.length > 0) || activeBasket || allBaskets[0];
                }
                if (!targetBasket) return { success: false, message: "İSKOOP aktif taslak sepeti bulunamadı" };

                try {
                    await store.dispatch('basket/completeOrderOrCheckOnlinePayment', targetBasket);
                    await new Promise(r => setTimeout(r, 400));
                    const dlgBtn = document.querySelector('.v-dialog--active button.primary, .v-dialog--active .v-btn.primary, .v-dialog--active .v-btn--contained.success');
                    if (dlgBtn) dlgBtn.click();
                    return { success: true, message: "İSKOOP siparişi başarıyla depoya iletildi." };
                } catch(e) {
                    return { success: false, message: "Sipariş iletme hatası: " + e.toString() };
                }
            }""")

            return res

    async def close(self):
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
