import asyncio
import base64
import json
import re
from typing import List, Optional, Dict, Any
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu, MFKademeDetay
from backend.core.cost_calculator import CostCalculator
from backend.core.session_store import SessionStore

class AllianceAdapter(BaseDepoAdapter):
    BASE_URL = "https://esiparisv2.alliance-healthcare.com.tr/"
    MAIN_URL = "https://esiparisv2.alliance-healthcare.com.tr/Home/MainPage"

    def __init__(self, pharmacy_code: str = "", username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ALLIANCE, "Alliance Healthcare")
        self.pharmacy_code = pharmacy_code
        self.username = username
        self.password = password
        self.headless = headless
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
        self._lock = asyncio.Lock()
        self._cart_busy: int = 0
        self._search_busy: int = 0
        self._fast_cart_cache: Dict[str, Dict[str, Any]] = {}

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-setuid-sandbox"]
            )
            
            session_file = SessionStore.get_session_file("alliance")
            if session_file.exists():
                try:
                    self._context = await self._browser.new_context(storage_state=str(session_file))
                except Exception:
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()
                
            self._page = await self._context.new_page()

    async def is_session_valid(self) -> bool:
        if not self._page:
            await self._init_browser()
            
        try:
            cur_url = (self._page.url or "").lower()
            if "alliance-healthcare.com.tr" in cur_url and "login" not in cur_url:
                is_ready = await self._page.evaluate("() => typeof AjaxPostWithoutOverlay === 'function' && !document.querySelector('#pharmacyCode')")
                if is_ready:
                    return True

            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            await self._page.wait_for_selector("#searchArea, #searchedItems", timeout=4000)
            return True
        except Exception:
            return False

    async def _login_unlocked(self) -> bool:
        """Alliance eSiparis v2'ye giriş yapar ve oturum kaydeder."""
        if not self.pharmacy_code or not self.username or not self.password:
            raise ValueError("Alliance için Eczane Kodu, Kullanıcı Adı ve Şifre zorunludur.")

        await self._init_browser()
        
        if await self.is_session_valid():
            print("[Alliance] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            return True

        print("[Alliance] Giriş sayfası açılıyor...")
        await self._page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=15000)

        await self._page.wait_for_selector("#pharmacyCode", timeout=8000)
        await self._page.fill("#pharmacyCode", str(self.pharmacy_code))
        await self._page.click("#Customer_username")
        await self._page.fill("#Customer_username", str(self.username))
        await self._page.fill("#Customer_password", str(self.password))
        
        login_result = {}

        async def handle_response(response):
            if "/Home/Login" in response.url and response.request.method == "POST":
                try:
                    data = await response.json()
                    login_result.update(data)
                except Exception:
                    pass

        self._page.on("response", handle_response)
        try:
            print("[Alliance] Giriş yapılıyor...")
            await self._page.click(".Customer_login__button")
            
            for _ in range(25):
                await asyncio.sleep(0.25)
                if login_result:
                    break

            if login_result.get("Result") is False:
                error_msg = login_result.get("Message", "Giriş başarısız oldu!")
                raise RuntimeError(f"Alliance Giriş Hatası: {error_msg}")

            await self._page.wait_for_url("**/Home/MainPage**", timeout=12000)
            await self._page.wait_for_function("() => typeof AjaxPostWithoutOverlay === 'function'", timeout=10000)
            
            session_file = SessionStore.get_session_file("alliance")
            await self._context.storage_state(path=str(session_file))
            print("[Alliance] Oturum başarıyla açıldı ve kaydedildi.")
            self.is_logged_in = True
            return True
        finally:
            try:
                self._page.remove_listener("response", handle_response)
            except Exception:
                pass

    async def login(self) -> bool:
        async with self._lock:
            return await self._login_unlocked()

    async def _ensure_ready_page(self):
        """Arama fonksiyonunun hazır olduğundan emin olur."""
        if not self._page:
            await self._init_browser()
            
        is_ready = False
        try:
            is_ready = await self._page.evaluate("() => typeof AjaxPostWithoutOverlay === 'function' && !document.querySelector('#pharmacyCode')")
        except Exception:
            is_ready = False

        if not is_ready:
            print("[Alliance] Sayfa hazırlanıyor...")
            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            cur_url = (self._page.url or "").lower()
            if "login" in cur_url or await self._page.evaluate("() => !!document.querySelector('#pharmacyCode')"):
                self.is_logged_in = False
                await self._login_unlocked()
            else:
                await self._page.wait_for_function("() => typeof AjaxPostWithoutOverlay === 'function'", timeout=10000)

    async def search_product(self, query: str, include_equivalents: bool = True, is_background: bool = False) -> List[DepoUrunSarti]:
        """
        Barkod veya ürün adına göre depoda arama yapar (Tek seferlik birleşik AJAX motoru).
        """
        if is_background and (getattr(self, "_cart_busy", 0) > 0 or getattr(self, "_search_busy", 0) > 0):
            return []
        if not is_background:
            self._search_busy += 1
        try:
            async with self._lock:
                if is_background and (getattr(self, "_cart_busy", 0) > 0 or getattr(self, "_search_busy", 0) > 0):
                    return []
                if not self.is_logged_in:
                    await self._login_unlocked()

                await self._ensure_ready_page()
                clean_q = str(query or "").strip()
                if not is_background:
                    print(f"[Alliance] '{clean_q}' sorgulanıyor...")

                # SearchItems + ItemsBranchDetail tek evaluate çağrısında tarayıcı içinde birleşik çalışır (0 Python-HTML gecikmesi)
                branch_data = await self._page.evaluate("""async (q) => {
                    function postNoOverlay(url, data) {
                        return new Promise((resolve) => {
                            AjaxPostWithoutOverlay(url, data, function(res) {
                                resolve(res);
                            });
                        });
                    }

                    let searchHtml = await postNoOverlay('/Sales/SearchItems', {
                        SearchText: q,
                        OnlyStock: false,
                        SearchContains: false,
                        SelectedClass: '3',
                        Sorter: 0,
                        ManufacturerID: '0',
                        WithEQ: false,
                        RequestedPage: 1,
                        BeforeSearchRequest: ''
                    });

                    function extractIds(html) {
                        if (!html || typeof html !== 'string') return [];
                        const ids = [];
                        const re = /id=["']branchdetailstring_(\\d+)["']/g;
                        let m;
                        while ((m = re.exec(html)) !== null) {
                            if (ids.length < 10) ids.push(m[1]);
                        }
                        return ids;
                    }

                    let itemIds = extractIds(searchHtml);

                    // GTIN-14 fallback: 13 haneli barkod bulunamazsa başına '0' ekleyip aynı turda dene
                    if (itemIds.length === 0 && /^\\d{13}$/.test(q)) {
                        searchHtml = await postNoOverlay('/Sales/SearchItems', {
                            SearchText: '0' + q,
                            OnlyStock: false,
                            SearchContains: false,
                            SelectedClass: '3',
                            Sorter: 0,
                            ManufacturerID: '0',
                            WithEQ: false,
                            RequestedPage: 1,
                            BeforeSearchRequest: ''
                        });
                        itemIds = extractIds(searchHtml);
                    }

                    if (itemIds.length === 0) return [];

                    const bData = await postNoOverlay('/Sales/ItemsBranchDetail', {
                        ItemIDs: itemIds.join(','),
                        NonDrugInventoryItems: ''
                    });
                    return Array.isArray(bData) ? bData : [];
                }""", clean_q)

                sonuclar: List[DepoUrunSarti] = []

                if isinstance(branch_data, list):
                    for b_item in branch_data:
                        item_id = str(b_item.get("ItemID", ""))
                        b64_detail = b_item.get("BranchItemDetailString", "")
                        if not b64_detail:
                            continue
                        try:
                            detail = json.loads(base64.b64decode(b64_detail).decode("utf-8"))
                            eq_string = b_item.get("EQString", "") or ""
                            sarti = self._parse_branch_item(detail, eq_string, clean_q)
                            sonuclar.append(sarti)

                            # Hızlı sepet önbelleğine kaydet (Sepete Ekle tıklandığında SearchItems ve ItemsBranchDetail atlanır!)
                            offers = detail.get("Offers") or []
                            if offers:
                                chosen_offer = offers[0]
                                offer_b64 = base64.b64encode(json.dumps(chosen_offer).encode("utf-8")).decode("utf-8")
                                cache_entry = {
                                    "item_id": item_id,
                                    "b64_detail": b64_detail,
                                    "offer_b64": offer_b64,
                                    "name": detail.get("Name", sarti.urun_adi),
                                    "vade": int(chosen_offer.get("DaysDue") or 30),
                                    "net_fiyat": float(chosen_offer.get("NetPrice") or sarti.net_birim_maliyet or 0.0),
                                    "has_stock": bool(detail.get("HasStock", True))
                                }
                                if item_id:
                                    self._fast_cart_cache[item_id] = cache_entry
                                bc_val = str(detail.get("Barcode") or "").strip()
                                if bc_val:
                                    self._fast_cart_cache[bc_val] = cache_entry
                                    self._fast_cart_cache[bc_val.lstrip("0")] = cache_entry
                                if clean_q.isdigit():
                                    self._fast_cart_cache[clean_q] = cache_entry
                        except Exception as e:
                            print(f"[Alliance] Ürün ayrıştırma hatası ({item_id}): {e}")

                return sonuclar
        finally:
            if not is_background:
                self._search_busy = max(0, self._search_busy - 1)

    def _parse_branch_item(self, detail: Dict[str, Any], eq_string: str, query: str) -> DepoUrunSarti:
        item_id = str(detail.get("ID", ""))
        name = detail.get("Name", "")
        barcode = detail.get("Barcode") or query
        
        has_stock = bool(detail.get("HasStock", False))
        stock_qty = int(detail.get("QA", 0) or 0)
        stok_durumu = StokDurumu.VAR if has_stock else StokDurumu.YOK

        price_tag = detail.get("PriceTag") or {}
        psf = float(price_tag.get("ListPrice") or 0.0)
        dsf_taxed = float(price_tag.get("SalesPrice") or 0.0)
        dsf_notax = float(price_tag.get("SalesPriceOutOfTaxes") or 0.0)
        dsf = dsf_notax if dsf_notax > 0 else dsf_taxed
        kdv_orani = float(price_tag.get("TaxRate") or 10.0)
        eczaci_kari = float(price_tag.get("CustomerProfitRate") or 0.0)
        is_cold = bool(detail.get("MustShipCold", False))

        # İskontolar
        kurum_isk = float(detail.get("KurumOran") or 0.0)
        ticari_isk = float(detail.get("TicariOran") or 0.0)
        ticari2_isk = float(detail.get("Ticari2Oran") or 0.0)
        web_prim = float(detail.get("WebPrimOran") or 0.0)
        deal_rate = float(detail.get("DealRate") or 0.0)
        offer_rate = float(detail.get("OfferRate") or 0.0)

        # Teklifler (Offers)
        offers = detail.get("Offers") or []
        en_iyi_vade = 30
        en_iyi_net_fiyat = 0.0
        kampanya_notu = ""
        secilen_teklif = None

        min_offer_net = 999999.0
        base_offer_net = 0.0

        if offers:
            for off in offers:
                o_net = float(off.get("NetPrice") or 0.0)
                o_min_qty = int(off.get("MinQuantity") or 1)
                o_days = int(off.get("DaysDue") or 30)

                if o_min_qty <= 1 and base_offer_net == 0.0 and o_net > 0:
                    base_offer_net = o_net

                if o_net > 0 and o_net < min_offer_net:
                    min_offer_net = o_net
                    en_iyi_vade = o_days
                    secilen_teklif = off

            if not secilen_teklif:
                secilen_teklif = offers[0]
                en_iyi_vade = int(secilen_teklif.get("DaysDue") or 30)
                min_offer_net = float(secilen_teklif.get("NetPrice") or dsf)

            en_iyi_net_fiyat = min_offer_net
            min_q = secilen_teklif.get("MinQuantity", 1)
            kampanya_notu = f"{secilen_teklif.get('Name')} (Min: {min_q} Adet, {en_iyi_vade} Gün)"

        # Açık ticari iskontoların toplamı
        toplam_ticari = ticari_isk + ticari2_isk + web_prim + deal_rate + offer_rate
        if secilen_teklif:
            off_rate = float(secilen_teklif.get("Rate") or 0.0)
            off_extra = float(secilen_teklif.get("ExtraDiscountRate") or 0.0)
            off_cash = float(secilen_teklif.get("CashDiscountRate") or 0.0)
            toplam_ticari = max(toplam_ticari, off_rate + off_extra + off_cash)

        # Eczane İskonto Çarpanı:
        # Kurum/Kamu İskontosu ve Ticari İskonto birlikte DSF'den düşülür
        # Formül: Net = DSF * (1 - Kurum / 100) * (1 - Ticari / 100)
        birlesik_isk_carpan = (1.0 - (kurum_isk / 100.0)) * (1.0 - (toplam_ticari / 100.0))
        birlesik_iskonto_yuzdesi = round((1.0 - birlesik_isk_carpan) * 100.0, 2)

        # Eğer Alliance'ın doğrudan bildirdiği teklif net fiyatı daha avantajlıysa (örn. özel kampanya)
        if dsf > 0 and en_iyi_net_fiyat > 0 and en_iyi_net_fiyat < (dsf - 0.01):
            derived_disc = round((1.0 - (en_iyi_net_fiyat / dsf)) * 100.0, 2)
            if not eq_string or eq_string.strip().upper() in ["YOK", "-", ""]:
                birlesik_iskonto_yuzdesi = max(birlesik_iskonto_yuzdesi, derived_disc)

        # MF formatlama
        mf_text = eq_string.strip() if eq_string else "YOK"

        # Maliyet motoru (Tüm kademeleri hesaplar)
        maliyet = CostCalculator.calculate(
            dsf=dsf,
            psf=psf,
            kdv_orani=kdv_orani,
            mf_str=mf_text,
            ticari_iskonto=birlesik_iskonto_yuzdesi,
            vade_gun=en_iyi_vade
        )

        final_net = maliyet.net_birim_maliyet
        if en_iyi_net_fiyat > 0 and (final_net == 0 or en_iyi_net_fiyat < final_net):
            final_net = round(en_iyi_net_fiyat, 2)

        final_net_kdvli = round(final_net * (1.0 + (kdv_orani / 100.0)), 2)

        # Eğer MF yok ama tekliflerde farklı ve daha avantajlı alım kademeleri varsa kademelere ekle
        kademeler = list(maliyet.kademeler)
        if not kademeler and len(offers) > 1:
            for off in sorted(offers, key=lambda x: int(x.get("MinQuantity") or 1)):
                q = int(off.get("MinQuantity") or 1)
                np = float(off.get("NetPrice") or 0.0)
                if q > 1 and np > 0 and np < (final_net - 0.01):
                    np_kdvli = round(np * (1.0 + (kdv_orani / 100.0)), 2)
                    off_disc = round((1.0 - (np / dsf)) * 100.0, 2) if dsf > 0 else 0.0
                    kademeler.append(MFKademeDetay(
                        alinan=q,
                        hediye=0,
                        mf_text=f"{q} Kutu",
                        net_birim_maliyet=round(np, 2),
                        net_birim_maliyet_kdvli=np_kdvli,
                        toplam_iskonto_yuzdesi=off_disc
                    ))

        # Kampanya ve vade notunu zenginleştir
        notlar = [f"{en_iyi_vade} Gün Vade"]
        if mf_text != "YOK":
            notlar.append(f"MF: {mf_text}")
        if toplam_ticari > 0:
            notlar.append(f"İsk: %{round(toplam_ticari, 2)}")
        if kurum_isk > 0:
            notlar.append(f"Kamu İsk: %{round(kurum_isk, 2)}")
        if notlar:
            kampanya_notu = " • ".join(notlar)

        return DepoUrunSarti(
            depo=DepoKodu.ALLIANCE,
            depo_adi=self.depo_adi,
            barkod=barcode,
            urun_id=item_id,
            urun_adi=name,
            stok_durumu=stok_durumu,
            stok_adedi=stock_qty if has_stock else 0,
            depocu_satis_fiyati=round(dsf, 2),
            perakende_satis_fiyati=round(psf, 2),
            kdv_orani=kdv_orani,
            mf_metni=mf_text,
            kademeler=kademeler,
            ticari_iskonto=round(toplam_ticari, 2),
            vade_gun=en_iyi_vade,
            net_birim_maliyet=round(final_net, 2),
            net_birim_maliyet_kdvli=final_net_kdvli,
            toplam_indirim_yuzdesi=round((1.0 - (final_net / dsf)) * 100.0, 2) if dsf > 0 else 0.0,
            ozel_kampanya_notu=kampanya_notu,
            soguk_zincir=is_cold,
            kamu_iskontosu=round(kurum_isk, 2),
            eczaci_kari=round(eczaci_kari, 2)
        )

    async def _add_to_cart_unlocked(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        barkod = str(kwargs.get("barkod") or "").strip()
        if len(barkod) == 14 and barkod.startswith("0"):
            barkod = barkod[1:]
        actual_id = str(urun_id or "").strip()

        # 1. HIZLI YOL: Arama sırasında önbelleğe alınmış ürün ise (SearchItems + ItemsBranchDetail atlanır, tek adımda ~80ms!)
        cached = self._fast_cart_cache.get(actual_id) or (self._fast_cart_cache.get(barkod) if barkod else None)
        if cached and cached.get("b64_detail") and cached.get("offer_b64"):
            if not cached.get("has_stock", True):
                return {"success": False, "message": "Ürün Alliance deposunda stokta yok."}

            add_resp = await self._page.evaluate("""async (param) => {
                return new Promise((resolve) => {
                    const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                    postFn("/Sales/AddItemToBasket", {
                        ItemString: param.itemString,
                        OfferString: param.offerString,
                        Quantity: param.quantity,
                        SupplierControlParam: false
                    }, function(res) {
                        if (res && res.Result && typeof RebindQuickCart === 'function') {
                            try { RebindQuickCart(); } catch(e) {}
                        }
                        resolve(res);
                    });
                });
            }""", {
                "itemString": cached["b64_detail"],
                "offerString": cached["offer_b64"],
                "quantity": int(miktar)
            })

            if add_resp and add_resp.get("Result"):
                prod_name = cached.get("name", "Ürün")
                return {
                    "success": True,
                    "depo": "ALLIANCE",
                    "message": f"{prod_name} başarıyla Alliance sepetine eklendi.",
                    "urun_adi": prod_name,
                    "miktar": int(miktar),
                    "vade": cached.get("vade", 30),
                    "net_fiyat": cached.get("net_fiyat", 0.0)
                }

        # 2. YEDEK YOL: Önbellekte yoksa (veya hızlı yol başarısız olduysa) TEK JS çağrısında çöz ve ekle
        is_direct_id = actual_id.isdigit() and len(actual_id) <= 8 and not actual_id.startswith("869")
        search_target = barkod or actual_id

        single_res = await self._page.evaluate("""async (params) => {
            function postAsync(url, data) {
                return new Promise((resolve) => {
                    const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                    postFn(url, data, function(res) { resolve(res); });
                });
            }
            try {
                let targetId = params.isDirectId ? params.actualId : '';
                if (!targetId) {
                    const searchHtml = await postAsync('/Sales/SearchItems', {
                        SearchText: params.searchTarget,
                        OnlyStock: false,
                        SearchContains: false,
                        SelectedClass: '3',
                        Sorter: 0,
                        ManufacturerID: '0',
                        WithEQ: false,
                        RequestedPage: 1,
                        BeforeSearchRequest: ''
                    });
                    if (searchHtml && typeof searchHtml === 'string') {
                        const m = /id=["']branchdetailstring_(\\d+)["']/i.exec(searchHtml);
                        if (m && m[1]) targetId = m[1];
                    }
                }
                if (!targetId) {
                    return { success: false, message: 'Alliance deposunda ürün bulunamadı.' };
                }

                const branchData = await postAsync('/Sales/ItemsBranchDetail', {
                    ItemIDs: targetId,
                    NonDrugInventoryItems: ''
                });
                if (!branchData || !Array.isArray(branchData) || !branchData[0] || !branchData[0].BranchItemDetailString) {
                    return { success: false, message: 'Alliance ürün şube bilgisi alınamadı.' };
                }

                const b64Detail = branchData[0].BranchItemDetailString;
                const detail = JSON.parse(atob(b64Detail));
                const offers = detail.Offers || [];
                if (!offers.length) {
                    return { success: false, message: 'Ürün için geçerli kampanya veya satış şartı bulunamadı.' };
                }

                const chosenOffer = offers[0];
                const offerB64 = btoa(JSON.stringify(chosenOffer));
                const addResp = await postAsync('/Sales/AddItemToBasket', {
                    ItemString: b64Detail,
                    OfferString: offerB64,
                    Quantity: params.quantity,
                    SupplierControlParam: false
                });

                if (addResp && addResp.Result) {
                    if (typeof RebindQuickCart === 'function') {
                        try { RebindQuickCart(); } catch(e) {}
                    }
                    return {
                        success: true,
                        depo: 'ALLIANCE',
                        urun_adi: detail.Name || 'Ürün',
                        vade: chosenOffer.DaysDue || 30,
                        net_fiyat: chosenOffer.NetPrice || 0.0,
                        b64_detail: b64Detail,
                        offer_b64: offerB64,
                        item_id: targetId
                    };
                }
                return {
                    success: false,
                    message: (addResp && addResp.Message) || 'Alliance sepete ekleme reddedildi.'
                };
            } catch (e) {
                return { success: false, message: 'Alliance işlem hatası: ' + e.toString() };
            }
        }""", {
            "actualId": actual_id,
            "isDirectId": is_direct_id,
            "searchTarget": search_target,
            "quantity": int(miktar)
        })

        if single_res and single_res.get("success"):
            prod_name = single_res.get("urun_adi", "Ürün")
            if single_res.get("b64_detail") and single_res.get("offer_b64"):
                ce = {
                    "item_id": str(single_res.get("item_id") or actual_id),
                    "b64_detail": single_res["b64_detail"],
                    "offer_b64": single_res["offer_b64"],
                    "name": prod_name,
                    "vade": int(single_res.get("vade") or 30),
                    "net_fiyat": float(single_res.get("net_fiyat") or 0.0),
                    "has_stock": True
                }
                if ce["item_id"]:
                    self._fast_cart_cache[ce["item_id"]] = ce
                if barkod:
                    self._fast_cart_cache[barkod] = ce
            return {
                "success": True,
                "depo": "ALLIANCE",
                "message": f"{prod_name} başarıyla Alliance sepetine eklendi.",
                "urun_adi": prod_name,
                "miktar": int(miktar),
                "vade": single_res.get("vade", 30),
                "net_fiyat": float(single_res.get("net_fiyat") or 0.0)
            }

        return {
            "success": False,
            "message": (single_res.get("message") if single_res else "") or "Alliance sepete ekleme başarısız."
        }

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """Alliance Healthcare sepetine ürün ekler (ID veya barkod destekli, önbellek hızlandırmalı)."""
        async with self._lock:
            return await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)

    async def bulk_add_to_cart(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Alliance Healthcare sepetine toplu (batch/paralel) ürün ekler.
        items: [{"barcode": "...", "miktar": 1, "name": "...", "urun_id": "..."}]
        """
        if not items:
            return {
                "success": False,
                "message": "Eklenecek ürün listesi boş.",
                "total_items": 0,
                "success_count": 0,
                "failed_count": 0,
                "total_amount": 0.0,
                "items": []
            }

        async with self._lock:
            if not self.is_logged_in:
                if await self.is_session_valid():
                    self.is_logged_in = True
                else:
                    await self._login_unlocked()
            await self._ensure_ready_page()

            clean_items = []
            for it in items:
                bc = str(it.get("barcode") or it.get("barkod") or "").strip()
                if len(bc) == 14 and bc.startswith("0"):
                    bc = bc[1:]
                qty = int(it.get("miktar") or it.get("quantity") or 1)
                name = str(it.get("name") or it.get("urun_adi") or "").strip()
                u_id = str(it.get("urun_id") or "").strip()
                cached = self._fast_cart_cache.get(u_id) or (self._fast_cart_cache.get(bc) if bc else None)
                clean_items.append({
                    "barcode": bc,
                    "miktar": max(1, qty),
                    "name": name,
                    "urun_id": u_id,
                    "cached_b64": cached.get("b64_detail") if cached else None,
                    "cached_offer": cached.get("offer_b64") if cached else None,
                    "cached_name": cached.get("name") if cached else None,
                    "cached_vade": cached.get("vade") if cached else None,
                    "cached_price": cached.get("net_fiyat") if cached else None,
                    "cached_stock": cached.get("has_stock", True) if cached else True
                })

            results = await self._page.evaluate("""async (items) => {
                function postAsync(url, data) {
                    return new Promise((resolve) => {
                        const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                        postFn(url, data, function(res) {
                            resolve(res);
                        });
                    });
                }

                async function processSingleItem(item) {
                    const itemRes = { 
                        barcode: item.barcode, 
                        name: item.name, 
                        miktar: item.miktar, 
                        success: false, 
                        message: '', 
                        urun_adi: item.name,
                        net_fiyat: 0, 
                        vade: 30,
                        toplam_tutar: 0
                    };
                    try {
                        // 0. Önbellekte varsa doğrudan tek adımda sepete ekle
                        if (item.cached_b64 && item.cached_offer) {
                            if (item.cached_stock === false) {
                                itemRes.message = 'Ürün Stokta Yok (Depo mevcudu 0)';
                                return itemRes;
                            }
                            const addRespFast = await postAsync('/Sales/AddItemToBasket', {
                                ItemString: item.cached_b64,
                                OfferString: item.cached_offer,
                                Quantity: item.miktar,
                                SupplierControlParam: false
                            });
                            if (addRespFast && addRespFast.Result) {
                                itemRes.success = true;
                                itemRes.message = 'Alliance sepetine eklendi';
                                itemRes.urun_adi = item.cached_name || item.name;
                                itemRes.vade = item.cached_vade || 30;
                                itemRes.net_fiyat = Math.round((item.cached_price || 0) * 100) / 100;
                                itemRes.toplam_tutar = Math.round(itemRes.net_fiyat * item.miktar * 100) / 100;
                                return itemRes;
                            }
                        }

                        let rowId = '';
                        const searchTarget = (item.barcode && item.barcode.trim()) ? item.barcode.trim() : (item.name || '').trim();
                        
                        // 1. Barkod veya ürün adıyla Alliance sisteminde ara
                        if (searchTarget) {
                            let searchHtml = await postAsync('/Sales/SearchItems', {
                                SearchText: searchTarget,
                                OnlyStock: false,
                                SearchContains: false,
                                SelectedClass: '3',
                                Sorter: 0,
                                ManufacturerID: '0',
                                WithEQ: false,
                                RequestedPage: 1,
                                BeforeSearchRequest: ''
                            });
                            
                            let m = /id=["']branchdetailstring_(\\d+)["']/i.exec(searchHtml || '');
                            
                            // GTIN-14 varyasyonu: 13 hane bulunamazsa başına 0 koyup dene
                            if (!m && item.barcode && item.barcode.length === 13) {
                                searchHtml = await postAsync('/Sales/SearchItems', {
                                    SearchText: '0' + item.barcode,
                                    OnlyStock: false,
                                    SearchContains: false,
                                    SelectedClass: '3',
                                    Sorter: 0,
                                    ManufacturerID: '0',
                                    WithEQ: false,
                                    RequestedPage: 1,
                                    BeforeSearchRequest: ''
                                });
                                m = /id=["']branchdetailstring_(\\d+)["']/i.exec(searchHtml || '');
                            }

                            // Barkod ile çıkmazsa ürün adının ilk 2-3 kelimesi ile dene
                            if (!m && item.name) {
                                const cleanWords = item.name.replace(/[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]/g, ' ').trim().split(/\\s+/).slice(0, 3).join(' ');
                                if (cleanWords.length >= 3) {
                                    searchHtml = await postAsync('/Sales/SearchItems', {
                                        SearchText: cleanWords,
                                        OnlyStock: false,
                                        SearchContains: false,
                                        SelectedClass: '3',
                                        Sorter: 0,
                                        ManufacturerID: '0',
                                        WithEQ: false,
                                        RequestedPage: 1,
                                        BeforeSearchRequest: ''
                                    });
                                    m = /id=["']branchdetailstring_(\\d+)["']/i.exec(searchHtml || '');
                                }
                            }

                            if (!m || !m[1]) {
                                itemRes.message = 'Alliance deposunda bulunamadı (Stok yok veya kapalı)';
                                return itemRes;
                            }
                            
                            rowId = m[1];
                        } else if (item.urun_id) {
                            rowId = item.urun_id;
                        }

                        if (!rowId) {
                            itemRes.message = 'Ürün şube ID belirlenemedi';
                            return itemRes;
                        }
                        
                        // 2. Şube Detayı
                        const branchData = await postAsync('/Sales/ItemsBranchDetail', {
                            ItemIDs: rowId,
                            NonDrugInventoryItems: ''
                        });
                        
                        if (!branchData || !Array.isArray(branchData) || branchData.length === 0) {
                            itemRes.message = 'Şube detayı bulunamadı';
                            return itemRes;
                        }
                        
                        const b64Detail = branchData[0].BranchItemDetailString;
                        if (!b64Detail) {
                            itemRes.message = 'Şube verisi boş';
                            return itemRes;
                        }
                        
                        const detail = JSON.parse(atob(b64Detail));
                        
                        // Stok kontrolü
                        if (detail.HasStock === false) {
                            itemRes.message = 'Ürün Stokta Yok (Depo mevcudu 0)';
                            return itemRes;
                        }

                        const offers = detail.Offers || [];
                        if (!offers || offers.length === 0) {
                            itemRes.message = 'Satış şartı / kampanya teklifi bulunamadı';
                            return itemRes;
                        }
                        
                        // En iyi teklifi seç
                        const chosenOffer = offers[0];
                        const offerB64 = btoa(JSON.stringify(chosenOffer));
                        
                        // 3. Sepete Ekle
                        const addResp = await postAsync('/Sales/AddItemToBasket', {
                            ItemString: b64Detail,
                            OfferString: offerB64,
                            Quantity: item.miktar,
                            SupplierControlParam: false
                        });
                        
                        if (addResp && addResp.Result) {
                            itemRes.success = true;
                            itemRes.message = 'Alliance sepetine eklendi';
                            itemRes.urun_adi = detail.Name || item.name;
                            itemRes.vade = chosenOffer.DaysDue || 30;
                            const price = chosenOffer.NetPrice || (detail.PriceTag ? (detail.PriceTag.SalesPriceOutOfTaxes || detail.PriceTag.SalesPrice) : 0) || 0;
                            itemRes.net_fiyat = Math.round(price * 100) / 100;
                            itemRes.toplam_tutar = Math.round(itemRes.net_fiyat * item.miktar * 100) / 100;
                        } else {
                            itemRes.message = (addResp && addResp.Message) ? addResp.Message : 'Sepete ekleme reddedildi';
                        }
                    } catch(e) {
                        itemRes.message = 'İşlem hatası: ' + e.message;
                    }
                    return itemRes;
                }

                // Chunks of 6 items concurrently
                const results = [];
                const chunkSize = 6;
                for (let i = 0; i < items.length; i += chunkSize) {
                    const chunk = items.slice(i, i + chunkSize);
                    const chunkResults = await Promise.all(chunk.map(it => processSingleItem(it)));
                    results.push(...chunkResults);
                }
                
                // Rebind Quick Cart to refresh badge
                if (typeof RebindQuickCart === 'function') {
                    try { RebindQuickCart(); } catch(e) {}
                }
                
                return results;
            }""", clean_items)

            success_items = [r for r in results if r.get("success")]
            failed_items = [r for r in results if not r.get("success")]
            total_amount = round(sum(r.get("toplam_tutar", 0) for r in success_items), 2)

            return {
                "success": len(success_items) > 0,
                "depo": "ALLIANCE",
                "message": f"Alliance sepetine {len(success_items)}/{len(items)} kalem ürün taslak olarak eklendi (Toplam: {total_amount:,.2f} ₺).",
                "total_items": len(items),
                "success_count": len(success_items),
                "failed_count": len(failed_items),
                "total_amount": total_amount,
                "items": results
            }

    def get_portal_urls(self) -> dict:
        """Alliance Healthcare sepet ve sipariş web arayüzü linklerini döndürür."""
        return {
            "cart_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart",
            "checkout_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart"
        }

    async def _get_cart_status_unlocked(self) -> Dict[str, Any]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        parsed = await self._page.evaluate("""async () => {
            return new Promise((resolve) => {
                if (typeof AjaxAsyncPostWithoutOverlay !== 'function') {
                    resolve({ item_count: 0, total_amount: 0.0, items: [] });
                    return;
                }
                AjaxAsyncPostWithoutOverlay('/Home/QuickCart', {}, function(html) {
                    try {
                        const tempDiv = document.createElement('div');
                        tempDiv.innerHTML = html;
                        const rows = tempDiv.querySelectorAll('table.tbl-cart tr');
                        const items = [];
                        rows.forEach(tr => {
                            const chk = tr.querySelector('input[data-basketitem]');
                            if (!chk) return;
                            const basketId = chk.getAttribute('data-basketitem') || '';
                            const itemId = chk.getAttribute('data-itemid') || '';
                            const tds = tr.querySelectorAll('td');
                            if (tds.length < 10) return;
                            const name = (tds[1]?.innerText || '').trim();
                            const qty = parseInt((tds[5]?.innerText || '1').trim(), 10) || 1;
                            const mf = (tds[6]?.innerText || '0').trim();
                            const unitPrice = parseFloat((tds[10]?.innerText || tds[9]?.innerText || '0').replace(/\\./g, '').replace(',', '.').trim()) || 0.0;
                            const total = parseFloat((tds[11]?.innerText || '0').replace(/\\./g, '').replace(',', '.').trim()) || (qty * unitPrice);
                            items.push({
                                id: basketId,
                                kod: itemId,
                                ad: name,
                                miktar: qty,
                                mf: mf,
                                birim_fiyat: unitPrice,
                                tutar: total
                            });
                        });
                        
                        let topTutar = 0;
                        const topText = tempDiv.innerText;
                        const match = topText.match(/Toplam\\s*([\\d.,]+)\\s*TL/i);
                        if (match) {
                            topTutar = parseFloat(match[1].replace(/\\./g, '').replace(',', '.').trim()) || 0.0;
                        } else {
                            topTutar = items.reduce((acc, it) => acc + (it.tutar || 0), 0);
                        }
                        
                        resolve({
                            item_count: items.length,
                            total_amount: topTutar,
                            items: items
                        });
                    } catch(e) {
                        resolve({ item_count: 0, total_amount: 0.0, items: [], error: e.toString() });
                    }
                });
            });
        }""")

        items = parsed.get("items", [])
        total_amount = float(parsed.get("total_amount") or 0.0)

        return {
            "success": True,
            "depo": "ALLIANCE",
            "depo_adi": self.depo_adi,
            "supported": True,
            "item_count": len(items),
            "total_amount": round(total_amount, 2),
            "items": items,
            "cart_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart",
            "checkout_url": "https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart"
        }

    async def get_cart_status(self) -> Dict[str, Any]:
        """Alliance Healthcare sepetinin anlık içeriğini ve toplam tutarını sorgular."""
        async with self._lock:
            return await self._get_cart_status_unlocked()

    async def clear_cart(self) -> Dict[str, Any]:
        """Alliance Healthcare sepetindeki tüm ürünleri temizler."""
        async with self._lock:
            if not self.is_logged_in:
                if await self.is_session_valid():
                    self.is_logged_in = True
                else:
                    await self._login_unlocked()
            await self._ensure_ready_page()

            res = await self._page.evaluate("""async () => {
                return new Promise((resolve) => {
                    const postFn = (typeof AjaxPostWithoutOverlay === 'function') ? AjaxPostWithoutOverlay : AjaxPost;
                    if (typeof postFn !== 'function') {
                        resolve({ success: false, message: "Alliance AjaxPost fonksiyonu bulunamadı" });
                        return;
                    }
                    postFn("/Sales/RemoveBasketItems", { Clear: true, BasketItemStrings: [] }, function(resp) {
                        if (resp && resp.Result) {
                            if (typeof RebindQuickCart === 'function') {
                                try { RebindQuickCart(); } catch(e) {}
                            }
                            resolve({ success: true, message: "Alliance sepeti başarıyla temizlendi." });
                        } else {
                            resolve({ success: false, message: (resp && resp.Message) || "Sepet temizlenemedi." });
                        }
                    });
                });
            }""")
            return res

    async def finalize_order(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        """Tekli siparişi Alliance sepetine ekler ve depoya iletir."""
        async with self._lock:
            if not self.is_logged_in:
                if await self.is_session_valid():
                    self.is_logged_in = True
                else:
                    await self._login_unlocked()
            await self._ensure_ready_page()

            cart_status = await self._get_cart_status_unlocked()
            existing_items = cart_status.get("items", [])

            if urun_id:
                u_clean = str(urun_id).strip()
                already_in_cart = any(it.get("kod") == u_clean or it.get("id") == u_clean for it in existing_items)
                if not already_in_cart:
                    added_res = await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
                    if not added_res.get("success"):
                        return {
                            "success": False,
                            "message": f"Ürün sepete eklenemediği için sipariş sonlandırılamadı: {added_res.get('message')}"
                        }
                    cart_status = await self._get_cart_status_unlocked()
                    existing_items = cart_status.get("items", [])

            if not existing_items:
                return {"success": False, "message": "Alliance sepetinde siparişe dönüştürülecek ürün bulunamadı."}

            if len(existing_items) > 1 and not force:
                return {
                    "success": False,
                    "need_confirmation": True,
                    "item_count": len(existing_items),
                    "items": existing_items,
                    "total_amount": cart_status.get("total_amount", 0.0),
                    "message": f"Alliance Healthcare sepetinizde önceden eklenmiş {len(existing_items)} farklı ürün bulunmaktadır (Toplam: {cart_status.get('total_amount', 0.0):,.2f} ₺). Tüm sepeti depoya göndermek için onay veriniz."
                }

            # Alliance sepet sayfasına git (SubmitBasketRequest ve sipariş gönderme bu sayfada tanımlıdır)
            if "sales/cart" not in (self._page.url or "").lower():
                try:
                    await self._page.goto("https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart", wait_until="domcontentloaded", timeout=10000)
                except Exception:
                    pass

            # Alliance siparişini onayla
            res = {"success": False, "message": "Sipariş onaylanamadı."}
            try:
                res = await self._page.evaluate("""async () => {
                    return new Promise((resolve) => {
                        const timer = setTimeout(() => {
                            resolve({ success: false, timeout: true, message: "Zaman aşımı" });
                        }, 10000);
                        if (typeof SubmitBasketRequest === 'function') {
                            SubmitBasketRequest('', '', false, false, function(resp) {
                                clearTimeout(timer);
                                try {
                                    if (typeof resp === 'string') {
                                        const match = resp.match(/<b>(\\d+)<\\/b>\\s*numaral[ıi]\\s*sipari[şs]/i) 
                                                   || resp.match(/(\\d+)\\s*numaral[ıi]\\s*sipari[şs]/i)
                                                   || resp.match(/sipari[şs]\\s*detay/i);
                                        const orderNo = (match && match[1]) ? match[1] : '';
                                        if (orderNo || resp.includes('sipariş detay') || resp.includes('order-detail') || resp.includes('numaralı sipariş')) {
                                            resolve({
                                                success: true,
                                                order_no: orderNo,
                                                message: `Alliance siparişi başarıyla depoya iletildi.${orderNo ? ' (Sipariş No: ' + orderNo + ')' : ''}`
                                            });
                                            return;
                                        }
                                        const errMatch = resp.match(/alert-danger[^>]*>([^<]+)</i) || resp.match(/error[^>]*>([^<]+)</i);
                                        if (errMatch) {
                                            resolve({ success: false, message: errMatch[1].trim() });
                                            return;
                                        }
                                        resolve({ success: true, message: "Alliance siparişi başarıyla depoya iletildi." });
                                    } else if (resp && (resp.Result === true || resp.Success === true || resp.IsSuccess === true)) {
                                        resolve({ success: true, message: resp.Message || "Alliance siparişi başarıyla depoya iletildi." });
                                    } else {
                                        resolve({ success: false, message: (resp && resp.Message) || "Sipariş onaylanamadı." });
                                    }
                                } catch(e) {
                                    resolve({ success: false, message: "Sipariş yanıtı işlenirken hata oluştu: " + e.toString() });
                                }
                            });
                        } else if (typeof SumbitBasket === 'function') {
                            clearTimeout(timer);
                            try {
                                SumbitBasket();
                                resolve({ success: true, message: "Alliance siparişi işleme konuldu." });
                            } catch(e) {
                                resolve({ success: false, message: "Sipariş gönderme hatası: " + e.toString() });
                            }
                        } else {
                            clearTimeout(timer);
                            const btn = document.querySelector('#btnSubmitBasket, .btn-submit-basket, button[onclick*="SubmitBasket"]');
                            if (btn) {
                                btn.click();
                                resolve({ success: true, message: "Alliance siparişi onaylandı." });
                            } else {
                                resolve({ success: false, message: "SubmitBasketRequest fonksiyonu bulunamadı." });
                            }
                        }
                    });
                }""")
            except Exception as nav_err:
                print(f"[Alliance] Finalize evaluate/navigation: {nav_err}")

            if not res.get("success"):
                try:
                    await asyncio.sleep(0.8)
                    post_cart = await self._get_cart_status_unlocked()
                    if post_cart.get("success") and post_cart.get("item_count", 0) == 0:
                        return {
                            "success": True,
                            "depo": "ALLIANCE",
                            "message": "Alliance Healthcare siparişiniz başarıyla depoya iletildi ve sepet onaylandı!"
                        }
                except Exception:
                    pass

            return res




    async def close(self):
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
