# -*- coding: utf-8 -*-
"""
backend/tria_client.py
-----------------------
Tria Eczane Otomasyon Sistemi (Oracle 11g/12c/19c) Veri Erişim & Analiz Modülü.
Eczane raf stoğu, aylık nakit fişli ve SGK reçeteli satış hareketlerini (ÇIKIŞ),
depolardan gelen alış faturalarını (GİRİŞ) ve günün kritik/azalan stok çıkışlarını sorgular.
"""

import os
import re
import sys
import time
import datetime
from typing import Dict, Any, List, Optional, Tuple

try:
    import oracledb
except ImportError:
    oracledb = None

LATIN1_TR_TRANS = str.maketrans({
    '\xdd': 'İ', '\xfd': 'ı', '\xde': 'Ş', '\xfe': 'ş', '\xd0': 'Ğ', '\xf0': 'ğ',
    'Ý': 'İ', 'ý': 'ı', 'Þ': 'Ş', 'þ': 'ş', 'Ð': 'Ğ', 'ð': 'ğ'
})

EXCLUDE_MAL_KODLARI = {
    '0020934', '0026445', '0042923', '0042925', '0042926', '0111629', '0272017', '0272050'
}

def fix_tria_str(val: Any) -> str:
    """TRIA Oracle veritabanından gelen Türkçe karakterleri standartlaştırır."""
    if val is None:
        return ""
    if isinstance(val, (bytes, bytearray)):
        for enc in ('utf-8', 'iso-8859-9', 'windows-1254', 'cp857'):
            try:
                decoded = val.decode(enc)
                if decoded and all(c.isprintable() or c.isspace() for c in decoded):
                    val = decoded
                    break
            except Exception:
                continue
        if isinstance(val, (bytes, bytearray)):
            val = val.decode('iso-8859-9', errors='replace')
    s = str(val).strip()
    return s.translate(LATIN1_TR_TRANS).rstrip('*').strip()


def to_short_path(path: str) -> str:
    """Windows'ta Türkçe/özel karakter içeren yolları 8.3 kısa dosya adına dönüştürür (Oracle ODPI-C UTF-8 fix)."""
    if not path or not os.path.exists(path):
        return path
    if os.name == 'nt':
        try:
            import ctypes
            buf = ctypes.create_unicode_buffer(1024)
            res = ctypes.windll.kernel32.GetShortPathNameW(path, buf, 1024)
            if res > 0 and buf.value:
                return buf.value
        except Exception:
            pass
    return path

class TriaOracleClient:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.oracle_client_initialized = False
        self._bad_auth_cache: Dict[Tuple[str, str, str], float] = {}
        self._takas_schema_cache: Optional[Dict[str, Dict[str, str]]] = None
        self._init_oracle_client()

    def _get_takas_schema(self, cur) -> Dict[str, Dict[str, str]]:
        """TRIA Oracle takas ve belge tablolarının sütun tiplerini bir kez okuyup önbelleğe alır (100% SELECT)."""
        if self._takas_schema_cache is not None:
            return self._takas_schema_cache
        schema: Dict[str, Dict[str, str]] = {}
        try:
            cur.execute("""
                SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
                FROM USER_TAB_COLS
                WHERE TABLE_NAME IN (
                    'TBL_TAKAS', 'TBL_TAKAS_DETAY',
                    'TBL_BELGE', 'TBL_BELGE_DETAY',
                    'TBL_CARI_TANIM', 'TBL_ECZANE_TANIM', 'TBL_TAKAS_ECZANE',
                    'TBL_MAL_HAREKET'
                )
            """)
            for tbl, col, dtype in cur.fetchall():
                t_key = str(tbl or "").strip().upper()
                c_key = str(col or "").strip().upper()
                d_val = str(dtype or "").strip().upper()
                if t_key and c_key:
                    schema.setdefault(t_key, {})[c_key] = d_val
            if schema:
                self._takas_schema_cache = schema
        except Exception as e:
            print(f"[TriaClient] Takas şema keşfi uyarısı: {e}")
        return schema

    def _fetch_tria_takas_movements(self, cur, mal_kodu: str, mal_id: Any) -> Tuple[List[Dict[str, Any]], int, int]:
        """
        TRIA'daki hem özel Takas Modülü (TBL_TAKAS + TBL_TAKAS_DETAY) hem de
        Faturalı Eczane Takaslarını (TBL_BELGE TIP_NO: TGF / TÇF / TCF) eksiksiz birleştirir.
        """
        schema = self._get_takas_schema(cur)
        collected: List[Dict[str, Any]] = []
        pcode_str = str(mal_kodu or "").strip()

        def _is_str_col(cols_map: Dict[str, str], cname: str) -> bool:
            dt = cols_map.get(cname, "")
            return dt in ("VARCHAR2", "CHAR", "NVARCHAR2", "NCHAR")

        def _is_num_col(cols_map: Dict[str, str], cname: str) -> bool:
            dt = cols_map.get(cname, "")
            return dt in ("NUMBER", "FLOAT", "BINARY_DOUBLE", "BINARY_FLOAT", "INTEGER")

        def _is_date_col(cols_map: Dict[str, str], cname: str) -> bool:
            dt = cols_map.get(cname, "")
            return dt == "DATE" or dt.startswith("TIMESTAMP")

        # ------------------------------------------------------------------
        # KAYNAK 1: TBL_TAKAS + TBL_TAKAS_DETAY (TRIA Özel Takas Modülü)
        # T.TAKAS_DURUM = 1 -> GİDEN (-TD.MIKTAR), T.TAKAS_DURUM = 0 -> GELEN (+TD.MIKTAR)
        # ------------------------------------------------------------------
        takas_mod_found = False
        t_cols = schema.get("TBL_TAKAS", {})
        td_cols = schema.get("TBL_TAKAS_DETAY", {})
        if t_cols and td_cols and "ID" in t_cols and "MIKTAR" in td_cols:
            try:
                fk_belge = "BELGE_ID" if "BELGE_ID" in td_cols else ("TAKAS_ID" if "TAKAS_ID" in td_cols else None)
                if fk_belge:
                    date_candidates = [
                        c for c in ("BELGE_TARIHI", "TAKAS_TARIHI", "ISLEM_TARIHI", "TARIH", "INSERT_DATE")
                        if _is_date_col(t_cols, c)
                    ]
                    if len(date_candidates) > 1:
                        date_raw_expr = f"COALESCE({', '.join('T.' + c for c in date_candidates)})"
                    elif len(date_candidates) == 1:
                        date_raw_expr = f"T.{date_candidates[0]}"
                    else:
                        date_raw_expr = "SYSDATE"

                    joins_sql = []
                    name_exprs = []
                    for sc in ("KARSI_ECZANE_ADI", "ECZANE_ADI", "CARI_ADI", "KARSI_CARI_ADI", "FIRMA_ADI", "UNVAN", "ACIKLAMA"):
                        if _is_str_col(t_cols, sc):
                            name_exprs.append(f"SUBSTR(NULLIF(TRIM(T.{sc}), ''), 1, 200)")

                    c_cols = schema.get("TBL_CARI_TANIM", {})
                    if c_cols and "ID" in c_cols:
                        cari_fk = next((c for c in ("CARI_TANIM_ID", "CARI_ID", "KARSI_CARI_ID", "KARSI_ECZANE_ID") if c in t_cols), None)
                        if cari_fk:
                            joins_sql.append(f"LEFT JOIN TBL_CARI_TANIM C ON C.ID = T.{cari_fk}")
                            for cc in ("CARI_ADI", "UNVAN", "ADI"):
                                if _is_str_col(c_cols, cc):
                                    name_exprs.append(f"SUBSTR(NULLIF(TRIM(C.{cc}), ''), 1, 200)")

                    for e_tbl in ("TBL_TAKAS_ECZANE", "TBL_ECZANE_TANIM"):
                        e_cols = schema.get(e_tbl, {})
                        if e_cols and "ID" in e_cols:
                            e_fk = next((c for c in ("TAKAS_ECZANE_ID", "ECZANE_TANIM_ID", "ECZANE_ID") if c in t_cols), None)
                            if e_fk:
                                joins_sql.append(f"LEFT JOIN {e_tbl} E ON E.ID = T.{e_fk}")
                                for ec in ("ECZANE_ADI", "CARI_ADI", "ADI", "UNVAN"):
                                    if _is_str_col(e_cols, ec):
                                        name_exprs.append(f"SUBSTR(NULLIF(TRIM(E.{ec}), ''), 1, 200)")
                                break

                    if name_exprs:
                        ecz_raw_expr = f"UTL_RAW.CAST_TO_RAW(COALESCE({', '.join(name_exprs)}, 'TAKAS ECZANESI'))"
                    else:
                        ecz_raw_expr = "UTL_RAW.CAST_TO_RAW('TAKAS ECZANESI')"

                    if "TAKAS_DURUM" in t_cols:
                        durum_expr = "NVL(T.TAKAS_DURUM, 0)"
                    elif "GIRIS_CIKIS_DURUMU" in t_cols:
                        durum_expr = "CASE WHEN NVL(T.GIRIS_CIKIS_DURUMU, 1) = 1 THEN 0 ELSE 1 END"
                    else:
                        durum_expr = "0"

                    uprice_cols = [
                        f"NULLIF(TD.{c}, 0)" for c in (
                            "NET_FIYAT", "BIRIM_FIYAT", "TAKAS_FIYATI", "FIYAT",
                            "MALIYET", "ALIS_FIYATI", "DEPOCU_FIYATI", "ECZACI_FIYATI", "PSF", "ETIKET_FIYATI"
                        ) if _is_num_col(td_cols, c)
                    ]
                    uprice_expr = f"COALESCE({', '.join(uprice_cols)}, 0)" if uprice_cols else "0"

                    tot_cols = [
                        f"NULLIF(TD.{c}, 0)" for c in ("NET_TUTAR", "TUTAR", "TOPLAM_TUTAR", "GENEL_TOPLAM")
                        if _is_num_col(td_cols, c)
                    ]
                    tot_expr = f"COALESCE({', '.join(tot_cols)}, 0)" if tot_cols else "0"

                    where_parts = []
                    bind_params: Dict[str, Any] = {"pcode": pcode_str}
                    if "MAL_KODU" in td_cols and "MAL_ID" in td_cols and mal_id is not None:
                        where_parts.append("(TD.MAL_KODU = :pcode OR LTRIM(TD.MAL_KODU, '0') = LTRIM(:pcode, '0') OR TD.MAL_ID = :mid)")
                        bind_params["mid"] = mal_id
                    elif "MAL_KODU" in td_cols:
                        where_parts.append("(TD.MAL_KODU = :pcode OR LTRIM(TD.MAL_KODU, '0') = LTRIM(:pcode, '0'))")
                    elif "MAL_ID" in td_cols and mal_id is not None:
                        where_parts.append("TD.MAL_ID = :mid")
                        bind_params = {"mid": mal_id}

                    for cancel_col in ("IPTAL", "IPTAL_DURUMU", "SILINDI"):
                        if _is_num_col(t_cols, cancel_col):
                            where_parts.append(f"NVL(T.{cancel_col}, 0) = 0")

                    if where_parts:
                        sql_takas_mod = f"""
                            SELECT
                                TO_CHAR({date_raw_expr}, 'YYYY-MM-DD') AS TARIH,
                                {ecz_raw_expr} AS ECZANE_RAW,
                                {durum_expr} AS TAKAS_DURUM,
                                NVL(TD.MIKTAR, 0) AS MIKTAR,
                                {uprice_expr} AS BIRIM_FIYAT,
                                {tot_expr} AS SATIR_TUTAR,
                                NVL(T.ID, 0) AS SORT_ID
                            FROM TBL_TAKAS_DETAY TD
                            JOIN TBL_TAKAS T ON T.ID = TD.{fk_belge}
                            {' '.join(joins_sql)}
                            WHERE {' AND '.join(where_parts)}
                            ORDER BY {date_raw_expr} DESC NULLS LAST, T.ID DESC
                        """
                        cur.execute(sql_takas_mod, bind_params)
                        for tr in cur.fetchmany(20):
                            raw_qty = float(tr[3] or 0)
                            t_adet = int(round(abs(raw_qty)))
                            if t_adet <= 0:
                                continue
                            takas_mod_found = True
                            t_durum = int(tr[2] or 0)
                            yon = "GIDEN" if (t_durum == 1 or raw_qty < 0) else "GELEN"
                            u_val = float(tr[4] or 0.0)
                            s_val = float(tr[5] or 0.0)
                            if u_val > 0:
                                b_tutar = round(u_val, 2)
                                top_tutar = round(s_val if s_val > 0 else (b_tutar * t_adet), 2)
                            elif s_val > 0:
                                b_tutar = round(s_val / max(1, t_adet), 2)
                                top_tutar = round(s_val, 2)
                            else:
                                b_tutar = 0.0
                                top_tutar = 0.0
                            ecz_str = fix_tria_str(tr[1]) or "TAKAS ECZANESİ"
                            if ecz_str.upper() == "TAKAS ECZANESI":
                                ecz_str = "TAKAS ECZANESİ"
                            collected.append({
                                "tarih": str(tr[0] or ""),
                                "eczane": ecz_str,
                                "yon": yon,
                                "adet": t_adet,
                                "birim_tutar": b_tutar,
                                "maliyet": b_tutar,
                                "toplam_tutar": top_tutar,
                                "hesap_tipi": "Takas",
                                "_sort_id": int(tr[6] or 0),
                            })
            except Exception as e_tk:
                print(f"[TriaClient] TBL_TAKAS sorgu uyarısı: {e_tk}")

        # ------------------------------------------------------------------
        # KAYNAK 2: TBL_BELGE + TBL_BELGE_DETAY (Faturalı Takas: TGF / TÇF / TCF / TF)
        # WE8ISO8859P9 'Ç' karakter kodlamasından etkilenmemek için SUBSTR T_F kontrolü kullanılır.
        # ------------------------------------------------------------------
        b_cols = schema.get("TBL_BELGE", {})
        bd_cols = schema.get("TBL_BELGE_DETAY", {})
        if not b_cols or ("TIP_NO" in b_cols and "BELGE_TARIHI" in b_cols):
            try:
                c_cols = schema.get("TBL_CARI_TANIM", {})
                has_cari_join = bool(c_cols and "ID" in c_cols and (not b_cols or "CARI_TANIM_ID" in b_cols) and _is_str_col(c_cols, "CARI_ADI"))
                cari_join_sql = "LEFT JOIN TBL_CARI_TANIM c ON c.ID = b.CARI_TANIM_ID" if has_cari_join else ""
                cari_raw_sql = (
                    "UTL_RAW.CAST_TO_RAW(SUBSTR(COALESCE(NULLIF(TRIM(b.CARI_ADI), ''), NULLIF(TRIM(c.CARI_ADI), ''), 'DIGER ECZANE'), 1, 200))"
                    if has_cari_join else
                    "NVL(UTL_RAW.CAST_TO_RAW(SUBSTR(b.CARI_ADI, 1, 200)), UTL_RAW.CAST_TO_RAW('DIGER ECZANE'))"
                )
                alis_satis_sql = "NVL(b.ALIS_SATIS_DURUMU, -1)" if (not b_cols or "ALIS_SATIS_DURUMU" in b_cols) else "-1"

                bd_uprice_parts = []
                for col_nm in ("NET_FIYAT", "BIRIM_FIYAT"):
                    if not bd_cols or _is_num_col(bd_cols, col_nm):
                        bd_uprice_parts.append(f"NULLIF(d.{col_nm}, 0)")
                bd_uprice_sql = f"COALESCE({', '.join(bd_uprice_parts)}, 0)" if bd_uprice_parts else "0"
                bd_tutar_sql = "NVL(d.TUTAR, 0)" if (not bd_cols or _is_num_col(bd_cols, "TUTAR")) else "0"

                cur.execute(f"""
                    SELECT
                        TO_CHAR(b.BELGE_TARIHI, 'YYYY-MM-DD') AS TARIH,
                        {cari_raw_sql} AS ECZANE_RAW,
                        UTL_RAW.CAST_TO_RAW(NVL(b.TIP_NO, '')) AS TIP_RAW,
                        {alis_satis_sql} AS ALIS_SATIS,
                        NVL(d.MIKTAR, 0) AS ADET,
                        {bd_uprice_sql} AS BIRIM_FIYAT,
                        {bd_tutar_sql} AS SATIR_TUTAR,
                        NVL(b.ID, 0) AS SORT_ID
                    FROM TBL_BELGE_DETAY d
                    JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                    {cari_join_sql}
                    WHERE (d.MAL_KODU = :pcode OR LTRIM(d.MAL_KODU, '0') = LTRIM(:pcode, '0'))
                      AND (
                          UPPER(TRIM(NVL(b.TIP_NO, ''))) IN ('TGF', 'TCF', 'TF', 'TAK')
                          OR (
                              LENGTH(TRIM(NVL(b.TIP_NO, ''))) = 3
                              AND SUBSTR(UPPER(TRIM(b.TIP_NO)), 1, 1) = 'T'
                              AND SUBSTR(UPPER(TRIM(b.TIP_NO)), 3, 1) = 'F'
                          )
                      )
                    ORDER BY b.BELGE_TARIHI DESC NULLS LAST, b.ID DESC
                """, {"pcode": pcode_str})
                for br in cur.fetchmany(20):
                    raw_qty = float(br[4] or 0)
                    t_adet = int(round(abs(raw_qty)))
                    if t_adet <= 0:
                        continue
                    tip_dec = (fix_tria_str(br[2]) or "").strip().upper()
                    alis_satis = int(br[3] if br[3] is not None else -1)
                    if tip_dec == "TGF" or ("G" in tip_dec and alis_satis != 1):
                        yon = "GELEN"
                        htip_lbl = "Takas Faturası"
                    else:
                        yon = "GIDEN"
                        htip_lbl = "Takas Faturası"
                    u_val = float(br[5] or 0.0)
                    s_val = float(br[6] or 0.0)
                    if u_val > 0:
                        b_tutar = round(u_val, 2)
                        top_tutar = round(s_val if s_val > 0 else (b_tutar * t_adet), 2)
                    elif s_val > 0:
                        b_tutar = round(s_val / max(1, t_adet), 2)
                        top_tutar = round(s_val, 2)
                    else:
                        b_tutar = 0.0
                        top_tutar = 0.0
                    ecz_str = fix_tria_str(br[1]) or "DİĞER ECZANE"
                    if ecz_str.upper() == "DIGER ECZANE":
                        ecz_str = "DİĞER ECZANE"
                    collected.append({
                        "tarih": str(br[0] or ""),
                        "eczane": ecz_str,
                        "yon": yon,
                        "adet": t_adet,
                        "birim_tutar": b_tutar,
                        "maliyet": b_tutar,
                        "toplam_tutar": top_tutar,
                        "hesap_tipi": htip_lbl,
                        "_sort_id": int(br[7] or 0),
                    })
            except Exception as e_bf:
                print(f"[TriaClient] TBL_BELGE takas sorgu uyarısı: {e_bf}")

        # ------------------------------------------------------------------
        # KAYNAK 3: TBL_MAL_HAREKET (Fişli Eczane Takas Hareketleri: BELGE_TURU = 'TAKAS')
        # Not: TRIA'da GIRIS_CIKIS_DURUMU = 0 (veya URUN_BELGE_TIPI = 17) GELEN Takas,
        #      GIRIS_CIKIS_DURUMU = 1 (veya URUN_BELGE_TIPI = 18) GİDEN Takas demektir.
        #      Karşı eczane adı ACIKLAMA sütununda ('... NL TAKAS-LİVA ECZANESİ:888...') yer alır.
        # ------------------------------------------------------------------
        mh_cols = schema.get("TBL_MAL_HAREKET", {})
        if not takas_mod_found and (not mh_cols or ("BELGE_TURU" in mh_cols and "MIKTAR" in mh_cols)):
            try:
                c_cols = schema.get("TBL_CARI_TANIM", {})
                has_mh_cari = bool(
                    c_cols and "ID" in c_cols
                    and (not mh_cols or "CARI_TANIM_ID" in mh_cols)
                    and _is_str_col(c_cols, "CARI_ADI")
                )
                mh_cari_join = "LEFT JOIN TBL_CARI_TANIM c ON c.ID = mh.CARI_TANIM_ID" if has_mh_cari else ""
                mh_cari_expr = (
                    "UTL_RAW.CAST_TO_RAW(SUBSTR(NVL(c.CARI_ADI, ''), 1, 200))"
                    if has_mh_cari else
                    "UTL_RAW.CAST_TO_RAW('')"
                )
                gc_sql = "NVL(mh.GIRIS_CIKIS_DURUMU, -1)" if (not mh_cols or "GIRIS_CIKIS_DURUMU" in mh_cols) else "-1"
                iade_sql = "NVL(mh.NORMAL_IADE_DURUMU, 0)" if (not mh_cols or "NORMAL_IADE_DURUMU" in mh_cols) else "0"
                ubt_sql = "NVL(mh.URUN_BELGE_TIPI, 0)" if (not mh_cols or "URUN_BELGE_TIPI" in mh_cols) else "0"
                mh_price_sql = "NVL(mh.BIRIM_FIYAT, 0)" if (not mh_cols or _is_num_col(mh_cols, "BIRIM_FIYAT")) else "0"
                mh_tot_sql = "NVL(mh.TUTAR, 0)" if (not mh_cols or _is_num_col(mh_cols, "TUTAR")) else "0"
                mh_acik_sql = (
                    "UTL_RAW.CAST_TO_RAW(SUBSTR(NVL(mh.ACIKLAMA, ''), 1, 220))"
                    if (not mh_cols or _is_str_col(mh_cols, "ACIKLAMA")) else
                    "UTL_RAW.CAST_TO_RAW('')"
                )
                mh_id_sql = "NVL(mh.ID, 0)" if (not mh_cols or _is_num_col(mh_cols, "ID")) else "0"

                cur.execute(f"""
                    SELECT
                        TO_CHAR(mh.BELGE_TARIHI, 'YYYY-MM-DD') AS TARIH,
                        {gc_sql} AS GC_DURUM,
                        NVL(mh.MIKTAR, 0) AS MIKTAR,
                        {mh_price_sql} AS BIRIM_FIYAT,
                        {mh_tot_sql} AS SATIR_TUTAR,
                        {iade_sql} AS IADE_DURUM,
                        {ubt_sql} AS UBT,
                        {mh_acik_sql} AS ACIK_RAW,
                        {mh_cari_expr} AS CARI_RAW,
                        {mh_id_sql} AS SORT_ID
                    FROM TBL_MAL_HAREKET mh
                    {mh_cari_join}
                    WHERE (mh.MAL_KODU = :pcode OR LTRIM(mh.MAL_KODU, '0') = LTRIM(:pcode, '0'))
                      AND UPPER(TRIM(NVL(mh.BELGE_TURU, ''))) = 'TAKAS'
                    ORDER BY mh.BELGE_TARIHI DESC NULLS LAST, {mh_id_sql} DESC
                """, {"pcode": pcode_str})
                for mr in cur.fetchmany(20):
                    raw_qty = float(mr[2] or 0)
                    t_adet = int(round(abs(raw_qty)))
                    if t_adet <= 0:
                        continue
                    gc_val = int(mr[1] if mr[1] is not None else -1)
                    iade_val = int(mr[5] or 0)
                    ubt_val = int(mr[6] or 0)

                    if raw_qty < 0:
                        yon = "GIDEN"
                    elif gc_val == 1 or ubt_val == 18:
                        yon = "GELEN" if iade_val == 1 else "GIDEN"
                    elif gc_val == 0 or ubt_val == 17:
                        yon = "GIDEN" if iade_val == 1 else "GELEN"
                    else:
                        yon = "GIDEN" if gc_val == 2 else "GELEN"

                    acik_txt = fix_tria_str(mr[7]).strip()
                    cari_txt = fix_tria_str(mr[8]).strip()
                    ecz_name = cari_txt
                    if not ecz_name and acik_txt:
                        m_ecz = re.search(r"TAKAS\s*[-:]\s*([^:]+)", acik_txt, flags=re.IGNORECASE)
                        if m_ecz:
                            ecz_name = m_ecz.group(1).strip(" -:")
                        elif "-" in acik_txt:
                            tail = acik_txt.split("-", 1)[1].split(":", 1)[0].strip()
                            if len(tail) >= 3:
                                ecz_name = tail
                    if not ecz_name:
                        ecz_name = "TAKAS ECZANESİ"

                    u_val = float(mr[3] or 0.0)
                    s_val = float(mr[4] or 0.0)
                    b_tutar = round(u_val if u_val > 0 else (s_val / max(1, t_adet) if s_val > 0 else 0.0), 2)
                    collected.append({
                        "tarih": str(mr[0] or ""),
                        "eczane": ecz_name,
                        "yon": yon,
                        "adet": t_adet,
                        "birim_tutar": b_tutar,
                        "maliyet": b_tutar,
                        "toplam_tutar": round(s_val if s_val > 0 else (b_tutar * t_adet), 2),
                        "hesap_tipi": "Takas",
                        "_sort_id": int(mr[9] or 0),
                    })
            except Exception as e_mh_tk:
                print(f"[TriaClient] TBL_MAL_HAREKET takas sorgu uyarısı: {e_mh_tk}")

        collected.sort(key=lambda x: (x.get("tarih") or "", int(x.get("_sort_id") or 0)), reverse=True)
        son_takaslar = []
        takas_gelen_kutu = 0
        takas_giden_kutu = 0
        for item in collected[:15]:
            item.pop("_sort_id", None)
            if item["yon"] == "GELEN":
                takas_gelen_kutu += int(item["adet"])
            else:
                takas_giden_kutu += int(item["adet"])
            son_takaslar.append(item)

        return son_takaslar, takas_gelen_kutu, takas_giden_kutu

    def _init_oracle_client(self):
        """Oracle Client (Thick Mode) ve network_admin ayarlarını hazırlar."""
        if oracledb is None or self.oracle_client_initialized:
            return

        client_dir = os.path.join(self.base_dir, "oracle_client", "instantclient_19_23")
        net_admin = os.path.join(self.base_dir, "oracle_client", "network_admin")
        
        # Eğer paket içindeki oracle_client bulunamazsa tipik konumlardan dene
        if not os.path.exists(client_dir):
            user_profile = os.environ.get("USERPROFILE", "")
            candidate_dirs = [
                os.path.join(user_profile, "OneDrive", "Masaüstü", "betaprim", "EdaPrim", "instantclient_19_23"),
                os.path.join(user_profile, "Desktop", "betaprim", "EdaPrim", "instantclient_19_23"),
                r"C:\instantclient_19_23",
                r"C:\oracle\instantclient_19_23"
            ]
            for c_dir in candidate_dirs:
                if os.path.exists(c_dir):
                    client_dir = c_dir
                    break

        try:
            os.makedirs(net_admin, exist_ok=True)
            sqlnet_path = os.path.join(net_admin, "sqlnet.ora")
            if not os.path.exists(sqlnet_path):
                with open(sqlnet_path, "w", encoding="utf-8") as f:
                    f.write("SQLNET.AUTHENTICATION_SERVICES = (NONE)\n")
        except Exception as e:
            print(f"[TriaClient] sqlnet.ora oluşturma uyarısı: {e}")

        try:
            if os.path.exists(client_dir):
                os.environ["PATH"] = client_dir + os.pathsep + os.environ.get("PATH", "")
                if hasattr(os, "add_dll_directory"):
                    try:
                        os.add_dll_directory(client_dir)
                    except Exception:
                        pass
            short_lib = to_short_path(client_dir) if os.path.exists(client_dir) else None
            short_cfg = to_short_path(net_admin) if os.path.exists(net_admin) else None

            # Eğer Windows 10/11'de 8.3 kısa yol kapalıysa ve yolda Türkçe karakter (Masaüstü vb.) varsa
            # geçici olarak client_dir dizinine geçip '.' ile başlatarak DPI-1047 hatasını tamamen önle:
            orig_cwd = os.getcwd()
            try:
                if short_lib and any(ord(c) > 127 for c in short_lib):
                    os.chdir(client_dir)
                    oracledb.init_oracle_client(lib_dir=".")
                else:
                    kwargs = {}
                    if short_lib:
                        kwargs["lib_dir"] = short_lib
                    if short_cfg and not any(ord(c) > 127 for c in short_cfg):
                        kwargs["config_dir"] = short_cfg
                    oracledb.init_oracle_client(**kwargs)
            finally:
                try:
                    os.chdir(orig_cwd)
                except Exception:
                    pass

            self.oracle_client_initialized = True
            print(f"[TriaClient] Oracle Instant Client Thick Mode aktif: {client_dir}")
        except Exception as e:
            if "already been initialized" in str(e):
                self.oracle_client_initialized = True
            else:
                print(f"[TriaClient] Oracle Client başlatma hatası: {e}")

    def _persist_env_settings(self, host: str, port: str, sid: str, user: str, password: str):
        """Başarılı Tria bağlantı bilgilerini .env dosyasına ve ortam değişkenlerine kalıcı olarak yazar."""
        clean_host = (host or "").strip()
        os.environ["TRIA_DB_HOST"] = clean_host
        os.environ["TRIA_DB_PORT"] = str(port).strip()
        os.environ["TRIA_DB_SID"] = (sid or "ORCL").strip()
        if user:
            os.environ["TRIA_DB_USER"] = user.strip()
        if password:
            os.environ["TRIA_DB_PASSWORD"] = password.strip()
        if clean_host.lower() in ("127.0.0.1", "localhost", "::1") or str(port).strip() == "1522" or (sid or "").strip().upper() == "XEPDB1":
            return
        try:
            env_path = os.path.join(self.base_dir, ".env")
            if os.path.exists(env_path):
                with open(env_path, "r", encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()
                updates = {
                    "TRIA_DB_HOST": clean_host,
                    "TRIA_DB_PORT": str(port).strip(),
                    "TRIA_DB_SID": (sid or "ORCL").strip(),
                }
                if user:
                    updates["TRIA_DB_USER"] = user.strip()
                if password:
                    updates["TRIA_DB_PASSWORD"] = password.strip()
                seen = set()
                new_lines = []
                for line in lines:
                    s = line.strip()
                    if s and not s.startswith("#") and "=" in s:
                        k = s.split("=", 1)[0].strip()
                        if k in updates:
                            new_lines.append(f"{k}={updates[k]}\n")
                            seen.add(k)
                            continue
                    new_lines.append(line)
                for k, v in updates.items():
                    if k not in seen:
                        new_lines.append(f"{k}={v}\n")
                with open(env_path, "w", encoding="utf-8") as f:
                    f.writelines(new_lines)
        except Exception:
            pass

    def get_config(self) -> Dict[str, str]:
        """Güncel bağlantı ayarlarını döndürür."""
        return {
            "user": os.environ.get("TRIA_DB_USER", "").strip(),
            "password": os.environ.get("TRIA_DB_PASSWORD", "").strip(),
            "host": os.environ.get("TRIA_DB_HOST", "").strip() or "127.0.0.1",
            "port": os.environ.get("TRIA_DB_PORT", "1521").strip() or "1521",
            "sid": os.environ.get("TRIA_DB_SID", "ORCL").strip() or "ORCL",
        }

    def _try_auto_unlock_account(self, host: str, port: str, sid: str, target_user: str) -> bool:
        """ORA-28000 (hesap kilitli) durumunda SYSDBA üzerinden hesabı otomatik açar ve şifre kilidi limitini UNLIMITED yapar."""
        if oracledb is None or not target_user:
            return False
        safe_user = "".join(c for c in target_user.strip().upper() if c.isalnum() or c == "_")
        if not safe_user:
            return False
        try:
            dsn = oracledb.makedsn(host, int(port), sid=sid)
        except Exception:
            dsn = f"{host}:{port}/{sid}"

        sys_pwds = ["tria", "TRIA", "manager", "MANAGER", "oracle", "ORACLE", "orcl", "ORCL"]
        for sys_pwd in sys_pwds:
            wrong_sys_pwd = False
            for _ in range(8):
                conn = None
                try:
                    conn = oracledb.connect(
                        user="SYS",
                        password=sys_pwd,
                        dsn=dsn,
                        mode=oracledb.AUTH_MODE_SYSDBA,
                        tcp_connect_timeout=2.0,
                    )
                    cur = conn.cursor()
                    cur.execute(f"ALTER USER {safe_user} ACCOUNT UNLOCK")
                    try:
                        cur.execute("ALTER PROFILE DEFAULT LIMIT FAILED_LOGIN_ATTEMPTS UNLIMITED PASSWORD_LIFE_TIME UNLIMITED")
                    except Exception:
                        pass
                    cur.close()
                    conn.close()
                    print(f"[TriaClient] '{safe_user}' Oracle hesabı (ORA-28000) otomatik olarak açıldı ve UNLIMITED yapıldı.")
                    return True
                except Exception as e:
                    if conn is not None:
                        try:
                            conn.close()
                        except Exception:
                            pass
                    es = str(e)
                    if "ORA-01017" in es or "ORA-01031" in es:
                        wrong_sys_pwd = True
                        break
                    if any(k in es for k in ("DPY-4011", "ORA-00028", "ORA-03113", "ORA-01012", "DPI-1080")):
                        time.sleep(0.08)
                        continue
                    break
            if wrong_sys_pwd:
                continue
        return False

    def _open_and_verify_conn(self, host: str, port: str, sid: str, user: str, password: str, timeout: float = 3.0):
        """Oracle bağlantısını açar, Tria servisi uyumluluk bilgilerini ayarlar ve canlı sorgu ile doğrular."""
        dsn = f"{host}:{port}/{sid}"
        auth_key = (host.strip(), user.strip().upper(), password.strip())
        bad_ts = self._bad_auth_cache.get(auth_key)
        if bad_ts and (time.time() - bad_ts) < 60.0:
            raise RuntimeError(f"ORA-01017: '{user}' şeması için girilen şifre hatalı (hesap kilitlenmesini önlemek için deneme durduruldu).")

        last_err = None
        unlocked_once = False
        for attempt in range(6):
            conn = None
            try:
                conn = oracledb.connect(user=user, password=password, dsn=dsn, tcp_connect_timeout=timeout)
                try:
                    conn.module = "Tria.exe"
                    conn.action = "Tria"
                except Exception:
                    pass
                cur = conn.cursor()
                cur.execute("SELECT 1 FROM TBL_MAL_TANIM WHERE ROWNUM = 1")
                cur.fetchone()
                cur.close()
                self._bad_auth_cache.pop(auth_key, None)
                return conn
            except Exception as err:
                last_err = err
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass
                err_str = str(err)
                # ORA-28000 (the account is locked) -> Otomatik SYSDBA kilit açıcıyı çalıştır ve tekrar dene
                if "ORA-28000" in err_str and not unlocked_once:
                    unlocked_once = True
                    if self._try_auto_unlock_account(host, port, sid, user):
                        time.sleep(0.1)
                        continue
                    break
                # ORA-01017 (hatalı şifre) -> Hesabı kilitlememek için ASLA tekrar deneme!
                if "ORA-01017" in err_str:
                    self._bad_auth_cache[auth_key] = time.time()
                    break
                # DPY-4011 / ORA-00028 / ORA-03113 / ORA-01012 (ProcessDB anlık oturum kesmesi) -> hızlı tekrar dene
                if attempt < 5 and any(k in err_str for k in ("DPY-4011", "ORA-00028", "ORA-03113", "ORA-03135", "ORA-01012", "DPI-1080")):
                    time.sleep(0.08)
                    continue
                break
        raise last_err

    def get_connection(self, host: Optional[str] = None, port: Optional[str] = None,
                       sid: Optional[str] = None, user: Optional[str] = None,
                       password: Optional[str] = None):
        """Oracle bağlantısını açar (otomatik port, SID, şema ve ağ sunucusu düzeltme destekli - ORA-28000 & DPY-4011 korumalı)."""
        if oracledb is None:
            raise RuntimeError("oracledb kütüphanesi yüklü değil. 'pip install oracledb' gereklidir.")

        import socket
        self._init_oracle_client()
        cfg = self.get_config()
        active_host = (host or cfg.get("host") or "127.0.0.1").strip()
        active_port = str(port or cfg.get("port") or "1521").strip()
        active_sid = (sid or cfg.get("sid") or "ORCL").strip()
        active_user = (user or cfg.get("user") or "").strip()
        active_pwd = (password or cfg.get("password") or active_user).strip()

        def _is_tcp_open(h: str, p: str, t: float = 0.45) -> bool:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(t)
                    return s.connect_ex((h, int(p))) == 0
            except Exception:
                return False

        last_error = None
        auth_error_stopped = False
        if active_host and active_user and _is_tcp_open(active_host, active_port, 0.45):
            for s_try in list(dict.fromkeys([active_sid, "ORCL", "XEPDB1", "XE"])):
                try:
                    conn = self._open_and_verify_conn(active_host, active_port, s_try, active_user, active_pwd, timeout=3.0)
                    if s_try != active_sid:
                        self._persist_env_settings(active_host, active_port, s_try, active_user, active_pwd)
                    return conn
                except Exception as e:
                    last_error = e
                    es = str(e)
                    # Şifre hatalıysa (ORA-01017) veya hesap kilitliyse (ORA-28000) diğer SID'leri deneyip hesabı kilitleme!
                    if "ORA-01017" in es or "ORA-28000" in es:
                        auth_error_stopped = True
                        break

        # Sadece ağ/sunucu erişim hatası varsa yerel ağda keşif yap; şifre/kilit hatasında keşif yapıp hesabı kilitleme
        if not auth_error_stopped:
            disc = self.discover_tria_host()
            if disc.get("found") and disc.get("host"):
                dh = disc["host"]
                dp = str(disc.get("port", "1521"))
                ds = disc.get("sid", "ORCL")
                du = disc.get("user") or active_user
                dpw = disc.get("password") or active_pwd or du
                if du:
                    try:
                        conn = self._open_and_verify_conn(dh, dp, ds, du, dpw, timeout=3.0)
                        self._persist_env_settings(dh, dp, ds, du, dpw)
                        return conn
                    except Exception as e:
                        last_error = e

        if last_error:
            raise last_error
        raise RuntimeError(f"Tria Oracle sunucusuna ({active_host}:{active_port}/{active_sid}) bağlanılamadı. Lütfen Ayarlar > TRIA sekmesinden sunucu IP ve şema adını kontrol edin.")

    def ping(self, host: Optional[str] = None, port: Optional[str] = None,
             sid: Optional[str] = None, user: Optional[str] = None,
             password: Optional[str] = None) -> Dict[str, Any]:
        """Tria Oracle veritabanına ping atar ve bağlantı durumunu test eder."""
        cfg = self.get_config()
        active_host = (host or cfg.get("host") or "127.0.0.1").strip()
        active_port = str(port or cfg.get("port") or "1521").strip()
        active_sid = (sid or cfg.get("sid") or "ORCL").strip()
        active_user = (user or cfg.get("user") or "").strip()
        active_pwd = (password or cfg.get("password") or active_user).strip()
        t0 = time.time()
        try:
            with self.get_connection(host=active_host, port=active_port, sid=active_sid, user=active_user, password=active_pwd) as conn:
                cfg_now = self.get_config()
                active_host = cfg_now.get("host", active_host)
                active_port = cfg_now.get("port", active_port)
                active_sid = cfg_now.get("sid", active_sid)
                active_user = cfg_now.get("user", active_user)
                latency_ms = round((time.time() - t0) * 1000, 2)
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM TBL_RECETE")
                recete_count = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM TBL_MAL_TANIM")
                mal_count = cur.fetchone()[0]

                # Bugün kesilen reçete sayısı
                cur.execute("SELECT COUNT(*) FROM TBL_RECETE WHERE RECETE_TARIHI >= TRUNC(SYSDATE)")
                today_recete = cur.fetchone()[0]

                # Toplam alış faturası sayısı
                cur.execute("SELECT COUNT(*) FROM TBL_BELGE WHERE TIP_NO IN ('AAF', 'KAF', 'TGF')")
                fatura_count = cur.fetchone()[0]

                return {
                    "success": True,
                    "connected": True,
                    "message": f"Tria Oracle bağlantısı başarılı ({latency_ms} ms)",
                    "latency_ms": latency_ms,
                    "version": conn.version,
                    "host": active_host,
                    "port": active_port,
                    "sid": active_sid,
                    "user": active_user,
                    "stats": {
                        "recete_sayisi": recete_count,
                        "kayitli_urun_sayisi": mal_count,
                        "bugun_recete_sayisi": today_recete,
                        "fatura_sayisi": fatura_count
                    }
                }
        except Exception as e:
            latency_ms = round((time.time() - t0) * 1000, 2)
            err_msg = str(e)
            user_friendly = err_msg
            if "12541" in err_msg:
                user_friendly = f"Oracle Dinleyici Bulunamadı (ORA-12541). '{active_host}' makinesinde {active_port} portunda Oracle listener çalışmıyor veya farklı bir ağdasınız."
            elif "12514" in err_msg:
                user_friendly = f"Veritabanı Servisi Bulunamadı (ORA-12514). '{active_sid}' SID/Servis adı geçersiz."
            elif "01017" in err_msg:
                user_friendly = f"Kullanıcı adı veya şifre hatalı (ORA-01017). '{active_user}' şeması için şifreyi kontrol ediniz."
            return {
                "success": False,
                "connected": False,
                "message": user_friendly,
                "latency_ms": latency_ms,
                "host": active_host,
                "port": active_port,
                "sid": active_sid,
                "user": active_user,
                "error": err_msg
            }

    def get_product_analysis(self, query: str, barcode: str = "") -> Dict[str, Any]:
        """
        Belirtilen barkod veya ilaç adı için Tria veritabanından:
        1. Anlık raf/mevcut stok (Golden Formula: İade/Emanet düzeltmeli)
        2. Son 6 takvim ayı Nakit ve Reçeteli çıkış adetleri (ÇIKIŞ)
        3. Son depolardan gelen alış faturaları (GİRİŞ)
        4. Aylık ortalama çıkış hızı ve kalan gün tahmini
        5. Akıllı sipariş önerisi
        döndürür.
        """
        clean_q = (barcode or query or "").strip()
        if not clean_q:
            return {"found": False, "message": "Barkod veya ürün belirtilmedi."}

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                # 1. Ürünü bul (Öncelik: Barkod, sonra Mal Adı / Kodu)
                product_row = None
                
                # A) Eğer doğrudan barkod verilmişse veya clean_q barkod ise
                target_barcodes = set()
                if barcode and barcode.strip().isdigit() and len(barcode.strip()) >= 8:
                    target_barcodes.add(barcode.strip())
                if clean_q and clean_q.isdigit() and len(clean_q) >= 8:
                    target_barcodes.add(clean_q)

                if target_barcodes:
                    # Kanonik EAN ve alternatif barkodları ekle
                    try:
                        from backend.catalog import catalog
                        for b in list(target_barcodes):
                            can = catalog.resolve_canonical_barcode(b)
                            if can:
                                target_barcodes.add(can)
                            cat_p = catalog.get_by_barcode(b)
                            if cat_p:
                                for ab in cat_p.get("all_barcodes", []):
                                    if str(ab).strip():
                                        target_barcodes.add(str(ab).strip())
                    except Exception:
                        pass

                    bc_list = list(target_barcodes)
                    for bc in bc_list:
                        cur.execute("""
                            SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(b.BARKOD, :b) as BARKOD
                            FROM TBL_MAL_TANIM t
                            LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                            WHERE (b.BARKOD = :b OR t.MAL_KODU = :b)
                              AND (t.PASIF IS NULL OR t.PASIF = 0)
                              AND ROWNUM <= 1
                        """, {"b": bc})
                        product_row = cur.fetchone()
                        if product_row:
                            break

                # B) Sayısal Kod araması
                if not product_row and clean_q.isdigit():
                    cur.execute("""
                        SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(b.BARKOD, '') as BARKOD
                        FROM TBL_MAL_TANIM t
                        LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                        WHERE (t.MAL_KODU = :raw_q OR TO_CHAR(t.ID) = :raw_q)
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                          AND ROWNUM <= 1
                    """, {"raw_q": clean_q})
                    product_row = cur.fetchone()

                # C) İsim araması
                if not product_row:
                    tr_query = clean_q.upper().replace("I", "İ").replace("ı", "I")
                    cur.execute("""
                        SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), NVL(b.BARKOD, '') as BARKOD
                        FROM TBL_MAL_TANIM t
                        LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                        WHERE (UPPER(t.MAL_ADI) LIKE :q OR UPPER(t.MAL_ADI) LIKE :raw_q)
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                          AND ROWNUM <= 1
                    """, {"q": f"%{tr_query}%", "raw_q": f"%{clean_q.upper()}%"})
                    product_row = cur.fetchone()

                if not product_row:
                    return {
                        "found": False,
                        "connected": True,
                        "kaynak": "TRIA",
                        "message": f"'{clean_q}' Tria kayıtlarında bulunamadı."
                    }

                mal_id, mal_kodu, mal_adi, found_barkod = product_row
                final_barcode = barcode or found_barkod or clean_q
                try:
                    from backend.catalog import catalog
                    can_final = catalog.resolve_canonical_barcode(final_barcode)
                    if can_final:
                        final_barcode = can_final
                except Exception:
                    pass

                # 2. Anlık Altın Stok (Golden Formula)
                cur.execute("""
                    SELECT NVL(
                        SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) - 
                        SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END), 
                        0
                    ) 
                    FROM TBL_MAL_MIKTARLAR m 
                    WHERE m.MAL_ID = :mid
                """, {"mid": mal_id})
                stok_val = cur.fetchone()[0] or 0.0
                stok = int(round(stok_val)) if stok_val == int(stok_val) else round(stok_val, 1)

                # 3. Son 6 Aylık Satış / Çıkış Trendi (Nakit vs Reçeteli)
                cur.execute("""
                    SELECT 
                        TO_CHAR(BELGE_TARIHI, 'YYYY-MM') as AY,
                        SUM(CASE WHEN UPPER(TRIM(BELGE_TURU)) = 'FIS' AND BELGE_TIP_NO IN ('01', '06') THEN MIKTAR ELSE 0 END) as NAKIT,
                        SUM(CASE WHEN UPPER(TRIM(BELGE_TURU)) = 'RECETE' THEN MIKTAR ELSE 0 END) as RECETELI,
                        SUM(CASE 
                            WHEN UPPER(TRIM(BELGE_TURU)) = 'FIS' AND BELGE_TIP_NO IN ('01', '06') THEN MIKTAR 
                            WHEN UPPER(TRIM(BELGE_TURU)) = 'RECETE' THEN MIKTAR 
                            ELSE 0 
                        END) as TOPLAM
                    FROM TBL_MAL_HAREKET
                    WHERE MAL_KODU = :pcode
                      AND BELGE_TARIHI >= ADD_MONTHS(TRUNC(SYSDATE, 'MM'), -6)
                      AND BELGE_TARIHI <= SYSDATE + 1
                    GROUP BY TO_CHAR(BELGE_TARIHI, 'YYYY-MM')
                    ORDER BY AY ASC
                """, {"pcode": mal_kodu})
                
                rows = cur.fetchall()

                ay_isimleri = {
                    "01": "Ocak", "02": "Şubat", "03": "Mart", "04": "Nisan",
                    "05": "Mayıs", "06": "Haziran", "07": "Temmuz", "08": "Ağustos",
                    "09": "Eylül", "10": "Ekim", "11": "Kasım", "12": "Aralık"
                }

                activity_by_month = {}
                for r in rows:
                    ay_str = str(r[0])
                    activity_by_month[ay_str] = {
                        "nakit": int(r[1] or 0),
                        "receteli": int(r[2] or 0),
                        "toplam": int(r[3] or 0)
                    }

                # Kesintisiz son 6 takvim ayını oluştur
                today = datetime.date.today()
                aylik_cikislar = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    m_str = f"{m_calc:02d}"
                    ym_key = f"{y_calc}-{m_str}"
                    is_current_month = (i == 0)
                    suffix = " (Bu Ay)" if is_current_month else ""
                    ay_label = f"{ay_isimleri.get(m_str, m_str)} '{str(y_calc)[-2:]}{suffix}"
                    
                    act = activity_by_month.get(ym_key, {"nakit": 0, "receteli": 0, "toplam": 0})
                    aylik_cikislar.append({
                        "ay": ym_key,
                        "label": ay_label,
                        "is_current": is_current_month,
                        "nakit": act["nakit"],
                        "receteli": act["receteli"],
                        "toplam": act["toplam"]
                    })

                # Ortalama aylık ve günlük çıkış hesabı
                gecmis_aylar = aylik_cikislar[:-1] if len(aylik_cikislar) > 1 else aylik_cikislar
                gecmis_sum = sum(x["toplam"] for x in gecmis_aylar)
                if gecmis_sum > 0:
                    ort_aylik = round(gecmis_sum / max(1, len(gecmis_aylar)), 1)
                else:
                    ort_aylik = round(sum(x["toplam"] for x in aylik_cikislar) / max(1, len(aylik_cikislar)), 1)
                
                ort_gunluk = round(ort_aylik / 30.0, 2)

                # Kalan gün ve stok durumu
                if ort_gunluk > 0:
                    kalan_gun = int(round(stok / ort_gunluk))
                else:
                    kalan_gun = 999 if stok > 0 else 0

                toplam_6_aylik_cikis = sum(x["toplam"] for x in aylik_cikislar)
                is_hareketsiz = (stok <= 0 and toplam_6_aylik_cikis == 0)

                if is_hareketsiz:
                    stok_status = "HAREKET YOK"
                    stok_status_color = "slate"
                    onerilen_siparis = 1
                elif stok <= 0:
                    stok_status = "TÜKENDİ"
                    stok_status_color = "red"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(1, hedef_stok - stok)
                elif kalan_gun < 10:
                    stok_status = "KRİTİK AZ"
                    stok_status_color = "amber"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                elif kalan_gun <= 30:
                    stok_status = "YETERLİ"
                    stok_status_color = "emerald"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)
                else:
                    stok_status = "YÜKSEK STOK"
                    stok_status_color = "sky"
                    hedef_stok = int(round(ort_aylik))
                    onerilen_siparis = max(0, hedef_stok - stok)

                # 4. Son Alış Faturaları / Depo Girişleri (GİRİŞ)
                cur.execute("""
                    SELECT 
                        TO_CHAR(b.BELGE_TARIHI, 'YYYY-MM-DD') as TARIH,
                        NVL(UTL_RAW.CAST_TO_RAW(b.CARI_ADI), UTL_RAW.CAST_TO_RAW('DIGER DEPO')) as DEPO,
                        NVL(d.MIKTAR, 0) as ADET,
                        NVL(d.MF_MIKTAR, 0) as MF,
                        ROUND(NVL(d.BIRIM_FIYAT, 0), 2) as BIRIM_FIYAT,
                        ROUND(NVL(d.NET_FIYAT, 0), 2) as MALIYET,
                        NVL(b.BELGE_NO, NVL(b.D_FATURA_NO, '')) as FATURA_NO
                    FROM TBL_BELGE_DETAY d
                    JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                    WHERE (d.MAL_KODU = :pcode OR LTRIM(d.MAL_KODU, '0') = LTRIM(:pcode, '0'))
                      AND UPPER(TRIM(NVL(b.TIP_NO, ''))) IN ('AAF', 'KAF', 'ASIF')
                    ORDER BY b.BELGE_TARIHI DESC, b.ID DESC
                """, {"pcode": mal_kodu})
                giris_rows = cur.fetchmany(6)

                son_girisler = []
                toplam_giren_kutu = 0
                for gr in giris_rows:
                    g_adet = int(gr[2] or 0)
                    g_mf = int(gr[3] or 0)
                    g_maliyet = round(float(gr[5] or 0.0), 2)
                    g_birim = round(float(gr[4] or 0.0), 2)
                    top_satir = g_adet + g_mf
                    toplam_giren_kutu += top_satir
                    son_girisler.append({
                        "tarih": str(gr[0]),
                        "depo": fix_tria_str(gr[1]),
                        "adet": g_adet,
                        "mf": g_mf,
                        "toplam_adet": top_satir,
                        "birim_fiyat": g_birim,
                        "maliyet": g_maliyet,
                        "fatura_no": str(gr[6])
                    })

                # 5. Takas Hareketleri (TBL_TAKAS + TBL_TAKAS_DETAY ve TBL_BELGE TGF/TÇF/TCF Birleşik)
                son_takaslar, takas_gelen_kutu, takas_giden_kutu = self._fetch_tria_takas_movements(cur, str(mal_kodu), mal_id)

                return {
                    "found": True,
                    "connected": True,
                    "kaynak": "TRIA",
                    "otomasyon_adi": "Tria Eczane",
                    "urun_id": mal_id,
                    "mal_id": mal_id,
                    "mal_kodu": str(mal_kodu),
                    "mal_adi": fix_tria_str(mal_adi),
                    "barkod": final_barcode,
                    "stok": stok,
                    "stok_depo": 0,
                    "stok_raf": stok,
                    "stok_acik": 0,
                    "kalan_gun": kalan_gun,
                    "stok_status": stok_status,
                    "stok_status_color": stok_status_color,
                    "ort_aylik_cikis": ort_aylik,
                    "ort_gunluk_cikis": ort_gunluk,
                    "onerilen_siparis": onerilen_siparis,
                    "aylik_cikislar": aylik_cikislar,
                    "son_girisler": son_girisler,
                    "toplam_giren_kutu": toplam_giren_kutu,
                    "son_takaslar": son_takaslar,
                    "takas_gelen_kutu": takas_gelen_kutu,
                    "takas_giden_kutu": takas_giden_kutu,
                    "hareketsiz_kart": is_hareketsiz,
                    "hareketsiz_aciklama": "Eczanenizde bu ürün için son 6 aydır çıkış hareketi bulunmuyor. Depo ve piyasa koşulları doğrudan üretici EAN barkodu üzerinden sunulmaktadır."
                }

        except Exception as e:
            return {
                "found": False,
                "connected": False,
                "kaynak": "TRIA",
                "error": str(e),
                "message": f"Tria stok ve hareket sorgusu hatası: {str(e)}"
            }

    def _fetch_today_open_emanet_map(self, cur) -> Dict[str, int]:
        """
        Bugün TRIA üzerinde hastaya verilmiş ve henüz reçeteye/nakit fişe kapatılmamış
        (iade de alınmamış) AÇIK EMANET çıkışlarını MAL_KODU bazında döndürür (%100 SELECT).
        """
        out: Dict[str, int] = {}
        try:
            cur.execute("""
                SELECT e.MAL_KODU,
                       SUM(
                           GREATEST(
                               0,
                               ABS(NVL(e.MIKTAR, 0)) - NVL((
                                   SELECT SUM(ABS(NVL(k.MIKTAR, 0)))
                                   FROM TBL_MAL_HAREKET k
                                   WHERE k.HAREKET_ID = e.ID
                                     AND (
                                         UPPER(TRIM(k.BELGE_TURU)) = 'EMANET_KAPATMA'
                                         OR NVL(k.NORMAL_IADE_DURUMU, 0) = 1
                                     )
                               ), 0)
                           )
                       ) AS EMANET_ADET
                FROM TBL_MAL_HAREKET e
                WHERE e.BELGE_TARIHI >= TRUNC(SYSDATE)
                  AND UPPER(TRIM(e.BELGE_TURU)) = 'EMANET'
                  AND NVL(e.GIRIS_CIKIS_DURUMU, 1) = 1
                  AND NVL(e.NORMAL_IADE_DURUMU, 0) = 0
                GROUP BY e.MAL_KODU
                HAVING SUM(
                    GREATEST(
                        0,
                        ABS(NVL(e.MIKTAR, 0)) - NVL((
                            SELECT SUM(ABS(NVL(k.MIKTAR, 0)))
                            FROM TBL_MAL_HAREKET k
                            WHERE k.HAREKET_ID = e.ID
                              AND (
                                  UPPER(TRIM(k.BELGE_TURU)) = 'EMANET_KAPATMA'
                                  OR NVL(k.NORMAL_IADE_DURUMU, 0) = 1
                              )
                        ), 0)
                    )
                ) > 0
            """)
            for r_code, r_qty in cur.fetchall():
                if r_code:
                    c_clean = str(r_code).strip()
                    q_int = int(round(float(r_qty or 0)))
                    if c_clean and c_clean not in EXCLUDE_MAL_KODLARI and q_int > 0:
                        out[c_clean] = q_int
        except Exception as e_em:
            print(f"[Tria] Bugün açık emanet sorgu uyarısı: {e_em}")
        return out

    def get_critical_stock_sales(self, limit: int = 0, max_stock_threshold: int = 5, max_stock_days: int = 21) -> List[Dict[str, Any]]:
        """
        Bugün eczaneden çıkışı olan (reçeteli veya nakit) veya bugün hastaya açık emanet verildiği için
        stoğu ≤ 21 gün altına düşen ürünleri listeler.
        """
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                
                # 1. Adım: Bugün çıkışı olan ürünleri (Reçete + Nakit Fiş) ve bugün verilen Açık Emanetleri ayrı ayrı çek (~10-15 ms)
                cur.execute("""
                    SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as BUGUN_ADET
                    FROM TBL_MAL_HAREKET mh
                    WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE)
                      AND (
                          UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE' 
                          OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                      )
                    GROUP BY mh.MAL_KODU
                    HAVING SUM(ABS(mh.MIKTAR)) > 0
                """)
                today_rows = cur.fetchall()
                today_map = {
                    str(r[0]).strip(): int(r[1] or 0) for r in today_rows 
                    if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI
                }
                today_emanet_map = self._fetch_today_open_emanet_map(cur)
                prod_codes = list(dict.fromkeys(list(today_map.keys()) + list(today_emanet_map.keys())))
                if not prod_codes:
                    return []

                # 2. Adım: Sadece bugün satılan ürünler için son 30 günün çıkışlarını çek (900'lük chunk)
                month_map = {}
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i+900]
                    params = {f'k{idx}': c for idx, c in enumerate(chunk)}
                    binds = ','.join(f':{k}' for k in params.keys())
                    cur.execute(f"""
                        SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as AY_ADET
                        FROM TBL_MAL_HAREKET mh
                        WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 30
                          AND (
                              UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE' 
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                          )
                          AND mh.MAL_KODU IN ({binds})
                        GROUP BY mh.MAL_KODU
                    """, params)
                    for r in cur.fetchall():
                        if r[0]:
                            month_map[str(r[0]).strip()] = int(r[1] or 0)

                # 3. Adım: Geçmişte MF'li Alım Kontrolü (TBL_BELGE_DETAY)
                mf_history_map = {}
                try:
                    for i in range(0, len(prod_codes), 900):
                        chunk = prod_codes[i:i+900]
                        params = {f'k{idx}': c for idx, c in enumerate(chunk)}
                        binds = ','.join(f':{k}' for k in params.keys())
                        cur.execute(f"""
                            SELECT MAL_KODU, MIKTAR, MF_MIKTAR, TO_CHAR(BELGE_TARIHI, 'YYYY-MM-DD'), ALIM_COUNT
                            FROM (
                                SELECT 
                                    d.MAL_KODU,
                                    d.MIKTAR,
                                    d.MF_MIKTAR,
                                    b.BELGE_TARIHI,
                                    COUNT(*) OVER (PARTITION BY d.MAL_KODU) as ALIM_COUNT,
                                    ROW_NUMBER() OVER (PARTITION BY d.MAL_KODU ORDER BY b.BELGE_TARIHI DESC, b.ID DESC) as RN
                                FROM TBL_BELGE_DETAY d
                                JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                                WHERE d.MAL_KODU IN ({binds})
                                  AND b.TIP_NO IN ('AAF', 'KAF', 'TGF')
                                  AND NVL(d.MF_MIKTAR, 0) > 0
                            ) WHERE RN = 1
                        """, params)
                        for r in cur.fetchall():
                            m_k = str(r[0])
                            m_adet = int(r[1] or 0)
                            m_mf = int(r[2] or 0)
                            raw_date = str(r[3] or '')
                            if raw_date and '-' in raw_date:
                                parts = raw_date.split('-')
                                fmt_date = f"{parts[2]}.{parts[1]}.{parts[0]}" if len(parts) == 3 else raw_date
                            else:
                                fmt_date = raw_date
                            alim_count = int(r[4] or 1)

                            mf_kisa = f"Son: {m_adet}+{m_mf} MF" if m_adet > 0 else f"Son: +{m_mf} MF"
                            mf_bilgi = f"Geçmişte {alim_count} kez MF ile alındı (Son Alım: {m_adet}+{m_mf} MF, {fmt_date})"

                            mf_history_map[m_k] = {
                                "var": True,
                                "sayisi": alim_count,
                                "son_adet": m_adet,
                                "son_mf": m_mf,
                                "son_tarih": fmt_date,
                                "kisa": mf_kisa,
                                "bilgi": mf_bilgi
                            }
                except Exception as e_mf:
                    print(f"[Tria] Geçmiş MF sorgu uyarısı: {e_mf}")

                # 4. Adım: İlgili ürünlerin temel tanım, fiyat, gerçek altın stok ve barkodlarını çek
                candidate_items = []
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i+900]
                    params = {f'k{idx}': c for idx, c in enumerate(chunk)}
                    binds = ','.join(f':{k}' for k in params.keys())
                    cur.execute(f"""
                        SELECT 
                            t.ID, 
                            t.MAL_KODU, 
                            UTL_RAW.CAST_TO_RAW(t.MAL_ADI), 
                            NVL(t.SATIS_FIYATI_1, 0) as PSF,
                            NVL((
                                SELECT SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) - 
                                       SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END)
                                FROM TBL_MAL_MIKTARLAR m WHERE m.MAL_ID = t.ID
                            ), 0) as STOK,
                            NVL((
                                SELECT MAX(b.BARKOD) FROM TBL_MAL_BARKOD_TANIM b 
                                WHERE b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                            ), '') as BARKOD
                        FROM TBL_MAL_TANIM t
                        WHERE t.MAL_KODU IN ({binds})
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                    """, params)
                    for r in cur.fetchall():
                        m_id, m_kodu_raw, m_adi, psf, stok_val, barkod = r
                        m_kodu = str(m_kodu_raw or "").strip()
                        stok = int(round(float(stok_val or 0)))
                        bugun = int(today_map.get(m_kodu, 0))
                        emanet_val = int(today_emanet_map.get(m_kodu, 0))
                        aylik = int(month_map.get(m_kodu, 0))
                        psf_val = round(float(psf or 0.0), 2)
                        barkod_val = str(barkod or m_kodu).strip()

                        # Kanonik EAN çözümleme
                        try:
                            from backend.catalog import catalog
                            canonical_bc = catalog.resolve_canonical_barcode(barkod_val)
                            if canonical_bc:
                                barkod_val = canonical_bc
                        except Exception:
                            pass

                        # Kalan stok gün hesabı ve 21 gün kuralı (aylık hız yalnızca gerçek satıştan baz alınır; hiç satış yoksa en az 1 kabul edilir)
                        effective_aylik = max(int(aylik or 0), int(bugun + emanet_val or 1))
                        gunluk_ort = max(0.1, round(effective_aylik / 30.0, 2))
                        stok_gun = round((stok * 30.0) / effective_aylik, 1) if stok > 0 else 0.0

                        # Sadece emanet çıkışı olan ürünlerde kesinlikle ≤ 21 gün (veya stok ≤ 0) şartı aranır
                        if emanet_val > 0 and bugun == 0 and stok > 0 and stok_gun > 21:
                            continue

                        # 21 Günden fazla stok varsa mantıken sipariş listesine dahil etme
                        if max_stock_days > 0 and stok > 0 and stok_gun > max_stock_days:
                            continue

                        # Günlük ortalama ve ihtiyaç tahmini
                        toplam_bugun_hareket = bugun + emanet_val
                        onerilen = max(toplam_bugun_hareket, int(gunluk_ort * 7) - max(0, stok))
                        if onerilen <= 0:
                            onerilen = max(1, toplam_bugun_hareket)

                        mf_hist = mf_history_map.get(m_kodu, {})
                        has_past_mf = bool(mf_hist.get("var", False))

                        item_payload = {
                            "urun_id": m_id,
                            "mal_kodu": m_kodu,
                            "urun_adi": fix_tria_str(m_adi),
                            "barkod": barkod_val,
                            "stok": stok,
                            "stok_gun": stok_gun,
                            "bugun_cikis": bugun,
                            "aylik_cikis": aylik,
                            "psf": psf_val,
                            "onerilen_siparis": max(1, onerilen),
                            "gecmis_mf_var": has_past_mf,
                            "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                            "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                            "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                            "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                            "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                            "gecmis_mf_bilgi": mf_hist.get("bilgi", "")
                        }
                        if emanet_val > 0:
                            item_payload["bugun_emanet"] = emanet_val
                            item_payload["emanet_cikis_var"] = True
                            item_payload["sadece_emanet"] = bool(bugun == 0)

                        candidate_items.append(item_payload)

                # Akıllı Sıralama: Önce normal satışlar (eksi -> tükenen -> kalan gün), ardından sadece emanetle düşenler kendi bloğunda
                candidate_items.sort(key=lambda x: (
                    1 if x.get("sadece_emanet") else 0,
                    0 if x["stok"] < 0 else (1 if x["stok"] == 0 else 2),
                    x["stok"] if x["stok"] < 0 else x["stok_gun"],
                    -(x["bugun_cikis"] + int(x.get("bugun_emanet") or 0))
                ))

                if limit and limit > 0:
                    return candidate_items[:limit]
                return candidate_items
        except Exception as e:
            print(f"[Tria] get_critical_stock_sales hatası: {e}")
            return []

    def get_six_month_smart_order_list(
        self,
        scope: str = "today",
        search_query: str = "",
        target_days: int = 15,
        limit: int = 250
    ) -> Dict[str, Any]:
        """
        TRIA Oracle veritabanından toplu sipariş ve 6 aylık çıkış analizi için:
        - Son 6 takvim ayının ay-ay çıkış sayılarını (Reçeteli + Elden),
        - Günlük ve aylık ortalama çıkış hızını,
        - Trend ve istikrar analizini (STABİL ÇIKAN, ÇIKIŞI AZALAN, ÇIKIŞI ARTAN, ARALIKLI),
        - Hedef gün sayısına göre (örn. 7, 15, 30 gün) akıllı sipariş miktarı önerisini,
        - Geçmiş fatura MF bilgilerini ve anlık raf stoğunu (Golden Formula)
        tek seferde yüksek hızla döndürür.
        """
        import math
        t0 = time.time()
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()

                ay_kisa = {
                    1: "Oca", 2: "Şub", 3: "Mar", 4: "Nis",
                    5: "May", 6: "Haz", 7: "Tem", 8: "Ağu",
                    9: "Eyl", 10: "Eki", 11: "Kas", 12: "Ara"
                }
                today = datetime.date.today()
                months_meta = []
                for i in range(5, -1, -1):
                    m_calc = today.month - i
                    y_calc = today.year
                    while m_calc <= 0:
                        m_calc += 12
                        y_calc -= 1
                    ym_int = y_calc * 100 + m_calc
                    ym_str = f"{y_calc}-{m_calc:02d}"
                    short_lbl = ay_kisa.get(m_calc, str(m_calc))
                    lbl = f"{short_lbl} '{str(y_calc)[-2:]}"
                    months_meta.append({
                        "ym_int": ym_int,
                        "ym": ym_str,
                        "short": short_lbl,
                        "label": lbl,
                        "is_current": (i == 0)
                    })

                start_ym = months_meta[0]["ym_int"]
                start_date_str = f"{start_ym // 100}-{start_ym % 100:02d}-01"
                lim = max(10, int(limit or 250))

                # 1. Bugünkü Çıkışları Belirle
                cur.execute("""
                    SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as BUGUN_ADET
                    FROM TBL_MAL_HAREKET mh
                    WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE)
                      AND (
                          UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                          OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                      )
                    GROUP BY mh.MAL_KODU
                    HAVING SUM(ABS(mh.MIKTAR)) > 0
                """)
                today_map = {
                    str(r[0]).strip(): int(r[1] or 0)
                    for r in cur.fetchall()
                    if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI
                }
                today_emanet_map = self._fetch_today_open_emanet_map(cur)

                clean_q = (search_query or "").strip()
                scope_norm = (scope or "today").strip().lower()
                prod_codes: List[str] = []

                if clean_q:
                    tr_q = clean_q.replace("i", "İ").replace("ı", "I").upper()
                    raw_u = clean_q.upper()
                    cur.execute(f"""
                        SELECT MAL_KODU FROM (
                            SELECT DISTINCT t.MAL_KODU, t.ID
                            FROM TBL_MAL_TANIM t
                            LEFT JOIN TBL_MAL_BARKOD_TANIM b ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                            WHERE (t.PASIF IS NULL OR t.PASIF = 0)
                              AND (
                                  UPPER(t.MAL_ADI) LIKE :q1
                                  OR UPPER(t.MAL_ADI) LIKE :q2
                                  OR b.BARKOD LIKE :q3
                                  OR t.MAL_KODU LIKE :q3
                              )
                            ORDER BY t.ID DESC
                        ) WHERE ROWNUM <= {lim}
                    """, {"q1": f"%{tr_q}%", "q2": f"%{raw_u}%", "q3": f"%{clean_q}%"})
                    prod_codes = [str(r[0]).strip() for r in cur.fetchall() if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI]
                elif scope_norm in ("week", "days_7"):
                    cur.execute(f"""
                        SELECT MAL_KODU FROM (
                            SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as TOP_ADET
                            FROM TBL_MAL_HAREKET mh
                            WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 7
                              AND (
                                  UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                                  OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                              )
                            GROUP BY mh.MAL_KODU
                            HAVING SUM(ABS(mh.MIKTAR)) > 0
                            ORDER BY SUM(ABS(mh.MIKTAR)) DESC
                        ) WHERE ROWNUM <= {lim}
                    """)
                    prod_codes = [str(r[0]).strip() for r in cur.fetchall() if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI]
                elif scope_norm in ("top6m", "top_6m"):
                    cur.execute(f"""
                        SELECT MAL_KODU FROM (
                            SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as TOP_ADET
                            FROM TBL_MAL_HAREKET mh
                            WHERE mh.BELGE_TARIHI >= TO_DATE(:sdate, 'YYYY-MM-DD')
                              AND (
                                  UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                                  OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                              )
                            GROUP BY mh.MAL_KODU
                            HAVING SUM(ABS(mh.MIKTAR)) > 0
                            ORDER BY SUM(ABS(mh.MIKTAR)) DESC
                        ) WHERE ROWNUM <= {lim}
                    """, {"sdate": start_date_str})
                    prod_codes = [str(r[0]).strip() for r in cur.fetchall() if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI]
                else:
                    prod_codes = list(dict.fromkeys(list(today_map.keys()) + list(today_emanet_map.keys())))
                    if not prod_codes:
                        cur.execute(f"""
                            SELECT MAL_KODU FROM (
                                SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as TOP_ADET
                                FROM TBL_MAL_HAREKET mh
                                WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 3
                                  AND (
                                      UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                                      OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                                  )
                                GROUP BY mh.MAL_KODU
                                HAVING SUM(ABS(mh.MIKTAR)) > 0
                                ORDER BY SUM(ABS(mh.MIKTAR)) DESC
                            ) WHERE ROWNUM <= {lim}
                        """)
                        prod_codes = [str(r[0]).strip() for r in cur.fetchall() if r[0] and str(r[0]).strip() not in EXCLUDE_MAL_KODLARI]

                if not prod_codes:
                    return {
                        "success": True,
                        "source": "TRIA",
                        "scope": scope,
                        "months": months_meta,
                        "items": [],
                        "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
                    }

                if len(prod_codes) > lim:
                    prod_codes = prod_codes[:lim]

                # 2. Son 6 Ayın Ay-Ay Reçeteli ve Nakit Çıkış Dağılımını Çek
                per_item_months: Dict[str, Dict[int, Dict[str, int]]] = {}
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i+900]
                    params = {f"k{idx}": c for idx, c in enumerate(chunk)}
                    binds = ",".join(f":{k}" for k in params.keys())
                    params["sdate"] = start_date_str
                    cur.execute(f"""
                        SELECT
                            mh.MAL_KODU,
                            TO_NUMBER(TO_CHAR(mh.BELGE_TARIHI, 'YYYYMM')) as YM,
                            SUM(CASE
                                WHEN UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE' THEN ABS(mh.MIKTAR)
                                WHEN UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06') THEN ABS(mh.MIKTAR)
                                ELSE 0
                            END) as TOP_ADET,
                            SUM(CASE WHEN UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE' THEN ABS(mh.MIKTAR) ELSE 0 END) as REC_ADET,
                            SUM(CASE WHEN UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06') THEN ABS(mh.MIKTAR) ELSE 0 END) as NAK_ADET
                        FROM TBL_MAL_HAREKET mh
                        WHERE mh.BELGE_TARIHI >= TO_DATE(:sdate, 'YYYY-MM-DD')
                          AND mh.MAL_KODU IN ({binds})
                          AND (
                              UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                          )
                        GROUP BY mh.MAL_KODU, TO_NUMBER(TO_CHAR(mh.BELGE_TARIHI, 'YYYYMM'))
                    """, params)
                    for r_code, r_ym, r_top, r_rec, r_nak in cur.fetchall():
                        if not r_code or not r_ym:
                            continue
                        per_item_months.setdefault(str(r_code).strip(), {})[int(r_ym)] = {
                            "toplam": int(r_top or 0),
                            "receteli": int(r_rec or 0),
                            "nakit": int(r_nak or 0)
                        }

                # 3. Son 30 Günün Çıkışlarını Çek
                last30_map: Dict[str, int] = {}
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i+900]
                    params = {f"k{idx}": c for idx, c in enumerate(chunk)}
                    binds = ",".join(f":{k}" for k in params.keys())
                    cur.execute(f"""
                        SELECT mh.MAL_KODU, SUM(ABS(mh.MIKTAR)) as AY_ADET
                        FROM TBL_MAL_HAREKET mh
                        WHERE mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 30
                          AND (
                              UPPER(TRIM(mh.BELGE_TURU)) = 'RECETE'
                              OR (UPPER(TRIM(mh.BELGE_TURU)) = 'FIS' AND mh.BELGE_TIP_NO IN ('01', '06'))
                          )
                          AND mh.MAL_KODU IN ({binds})
                        GROUP BY mh.MAL_KODU
                    """, params)
                    for r in cur.fetchall():
                        if r[0]:
                            last30_map[str(r[0]).strip()] = int(r[1] or 0)

                # 4. Geçmiş Fatura MF Bilgisi (TBL_BELGE_DETAY)
                mf_history_map: Dict[str, Dict[str, Any]] = {}
                try:
                    for i in range(0, len(prod_codes), 900):
                        chunk = prod_codes[i:i+900]
                        params = {f"k{idx}": c for idx, c in enumerate(chunk)}
                        binds = ",".join(f":{k}" for k in params.keys())
                        cur.execute(f"""
                            SELECT MAL_KODU, MIKTAR, MF_MIKTAR, TO_CHAR(BELGE_TARIHI, 'YYYY-MM-DD'), ALIM_COUNT, DEPO_RAW
                            FROM (
                                SELECT
                                    d.MAL_KODU,
                                    d.MIKTAR,
                                    d.MF_MIKTAR,
                                    b.BELGE_TARIHI,
                                    COUNT(*) OVER (PARTITION BY d.MAL_KODU) as ALIM_COUNT,
                                    NVL(UTL_RAW.CAST_TO_RAW(b.CARI_ADI), UTL_RAW.CAST_TO_RAW('')) as DEPO_RAW,
                                    ROW_NUMBER() OVER (PARTITION BY d.MAL_KODU ORDER BY b.BELGE_TARIHI DESC, b.ID DESC) as RN
                                FROM TBL_BELGE_DETAY d
                                JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                                WHERE d.MAL_KODU IN ({binds})
                                  AND b.TIP_NO IN ('AAF', 'KAF', 'TGF')
                                  AND NVL(d.MF_MIKTAR, 0) > 0
                            ) WHERE RN = 1
                        """, params)
                        for r in cur.fetchall():
                            m_k = str(r[0]).strip()
                            m_adet = int(r[1] or 0)
                            m_mf = int(r[2] or 0)
                            raw_dt = str(r[3] or "")
                            if raw_dt and "-" in raw_dt:
                                pts = raw_dt.split("-")
                                fmt_dt = f"{pts[2]}.{pts[1]}.{pts[0]}" if len(pts) == 3 else raw_dt
                            else:
                                fmt_dt = raw_dt
                            cnt = int(r[4] or 1)
                            depo_adi = fix_tria_str(r[5]).strip() if r[5] else ""
                            mf_kisa = f"{m_adet}+{m_mf}" if m_adet > 0 else f"+{m_mf}"
                            mf_history_map[m_k] = {
                                "var": True,
                                "sayisi": cnt,
                                "son_adet": m_adet,
                                "son_mf": m_mf,
                                "son_tarih": fmt_dt,
                                "son_depo": depo_adi,
                                "kisa": mf_kisa,
                                "bilgi": f"Geçmişte {cnt} kez MF'li alındı (Son: {mf_kisa} MF, {fmt_dt})"
                            }
                except Exception as e_mf:
                    print(f"[Tria] 6 aylık geçmiş MF sorgu uyarısı: {e_mf}")

                # 5. Ürün Tanım, PSF, Altın Stok ve Barkodları Çek
                urun_rows = []
                for i in range(0, len(prod_codes), 900):
                    chunk = prod_codes[i:i+900]
                    params = {f"k{idx}": c for idx, c in enumerate(chunk)}
                    binds = ",".join(f":{k}" for k in params.keys())
                    cur.execute(f"""
                        SELECT
                            t.ID,
                            t.MAL_KODU,
                            UTL_RAW.CAST_TO_RAW(t.MAL_ADI),
                            NVL(t.SATIS_FIYATI_1, 0) as PSF,
                            NVL((
                                SELECT SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                                       SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END)
                                FROM TBL_MAL_MIKTARLAR m WHERE m.MAL_ID = t.ID
                            ), 0) as STOK,
                            NVL((
                                SELECT MAX(b.BARKOD) FROM TBL_MAL_BARKOD_TANIM b
                                WHERE b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                            ), '') as BARKOD
                        FROM TBL_MAL_TANIM t
                        WHERE t.MAL_KODU IN ({binds})
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                    """, params)
                    urun_rows.extend(cur.fetchall())

                items = []
                stabil_count = 0
                azalan_count = 0
                artan_count = 0
                tukenen_count = 0
                target_days_clean = max(1, int(target_days or 15))

                for m_id, m_kodu_raw, m_adi_raw, psf_raw, stok_raw, barkod_raw in urun_rows:
                    m_kodu = str(m_kodu_raw).strip()
                    u_id = int(m_id or 0)
                    u_adi = fix_tria_str(m_adi_raw)
                    stok_val = int(round(float(stok_raw or 0)))
                    psf_val = round(float(psf_raw or 0.0), 2)
                    bugun_val = int(today_map.get(m_kodu, 0))
                    emanet_val = int(today_emanet_map.get(m_kodu, 0))
                    son30_val = int(last30_map.get(m_kodu, 0))
                    bc_val = str(barkod_raw or m_kodu).strip()
                    try:
                        from backend.catalog import catalog
                        can_bc = catalog.resolve_canonical_barcode(bc_val)
                        if can_bc:
                            bc_val = can_bc
                    except Exception:
                        pass

                    m_dict = per_item_months.get(m_kodu, {})
                    aylik_detay = []
                    toplam_6ay = 0
                    toplam_6ay_recete = 0
                    toplam_6ay_nakit = 0
                    aktif_ay_sayisi = 0

                    for m_meta in months_meta:
                        ym_i = m_meta["ym_int"]
                        cell = m_dict.get(ym_i, {"toplam": 0, "receteli": 0, "nakit": 0})
                        c_top = cell["toplam"]
                        c_rec = cell["receteli"]
                        c_nak = cell["nakit"]
                        toplam_6ay += c_top
                        toplam_6ay_recete += c_rec
                        toplam_6ay_nakit += c_nak
                        if c_top > 0:
                            aktif_ay_sayisi += 1
                        aylik_detay.append({
                            "ym": m_meta["ym"],
                            "short": m_meta["short"],
                            "label": m_meta["label"],
                            "is_current": m_meta["is_current"],
                            "toplam": c_top,
                            "receteli": c_rec,
                            "recete": c_rec,
                            "nakit": c_nak
                        })

                    m_vals = [x["toplam"] for x in aylik_detay]
                    gecmis_5_toplam = sum(m_vals[:5])
                    ort_aylik_6m = round(gecmis_5_toplam / 5.0, 1) if gecmis_5_toplam > 0 else round(toplam_6ay / 6.0, 1)

                    onceki_4_ort = sum(m_vals[:4]) / 4.0
                    gecen_ay_val = m_vals[4] if len(m_vals) >= 5 else 0
                    son_donem_hiz = round((gecen_ay_val + son30_val) / 2.0, 1) if gecen_ay_val > 0 else float(son30_val)

                    degisim_yuzde = 0
                    if onceki_4_ort >= 1.5:
                        degisim_yuzde = int(round(((son_donem_hiz - onceki_4_ort) / onceki_4_ort) * 100))

                    if onceki_4_ort >= 2.0 and son_donem_hiz < onceki_4_ort * 0.65:
                        trend_kodu = "AZALAN"
                        trend_etiket = f"📉 Çıkışı Azalan (%{abs(degisim_yuzde)}↓)"
                        trend_renk = "amber"
                        trend_uyari = f"Son dönemde çıkış hızı {onceki_4_ort:.1f}/ay'dan {son_donem_hiz:.1f}/ay'a geriledi. Yüksek stok bağlamayın."
                        azalan_count += 1
                    elif onceki_4_ort >= 1.5 and son_donem_hiz > onceki_4_ort * 1.35 and son_donem_hiz >= 3.0:
                        trend_kodu = "ARTAN"
                        trend_etiket = f"📈 Çıkışı Artan (+%{abs(degisim_yuzde)}↑)"
                        trend_renk = "sky"
                        trend_uyari = f"Son dönemde talep hızlandı ({onceki_4_ort:.1f} → {son_donem_hiz:.1f}/ay). Güvenli stok tutun."
                        artan_count += 1
                    elif aktif_ay_sayisi >= 4 and toplam_6ay >= 5:
                        trend_kodu = "STABIL"
                        trend_etiket = f"🟢 Stabil Çıkan ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "emerald"
                        trend_uyari = f"Her ay düzenli satıyor (Ort. {ort_aylik_6m:.1f} kt/ay). MF baremli alıma uygun."
                        stabil_count += 1
                    else:
                        trend_kodu = "DUZENSIZ"
                        trend_etiket = f"⚡ Aralıklı ({aktif_ay_sayisi}/6 Ay)"
                        trend_renk = "slate"
                        trend_uyari = f"Son 6 ayın {aktif_ay_sayisi} ayında çıkış yaptı (Toplam {toplam_6ay} kt). İhtiyaç kadar alın."

                    if stok_val <= 0:
                        tukenen_count += 1

                    if trend_kodu == "AZALAN":
                        etkin_aylik_hiz = max(0.5, min(ort_aylik_6m, max(1.0, son_donem_hiz)))
                    elif trend_kodu == "ARTAN":
                        etkin_aylik_hiz = max(ort_aylik_6m, son_donem_hiz, float(bugun_val))
                    else:
                        etkin_aylik_hiz = max(ort_aylik_6m, float(son30_val), float(bugun_val))

                    gunluk_hiz = round(max(0.05, etkin_aylik_hiz / 30.0), 2)
                    stok_gun = round(stok_val / gunluk_hiz, 1) if stok_val > 0 else 0.0

                    # Sadece emanet çıkışı olan ürünlerde stok 21 günün üzerindeyse Toplu Sipariş (Bugün) listesini de meşgul etmesin
                    if scope_norm == "today" and not clean_q and emanet_val > 0 and bugun_val == 0 and stok_val > 0 and stok_gun > 21:
                        continue

                    hedef_kutu = math.ceil(gunluk_hiz * target_days_clean)
                    if trend_kodu == "AZALAN":
                        kisitli_hedef = math.ceil(gunluk_hiz * min(target_days_clean, 10))
                        onerilen = max(0, kisitli_hedef - max(0, stok_val))
                        if stok_val <= 0:
                            onerilen = max(1, min(bugun_val or 1, 2))
                    else:
                        onerilen = max(0, hedef_kutu - max(0, stok_val))
                        if stok_val <= 0 and onerilen <= 0:
                            onerilen = max(1, bugun_val or 1)

                    mf_hist = mf_history_map.get(m_kodu, {})

                    if trend_kodu == "AZALAN":
                        oneri_metni = f"⚠️ Çıkışı azaldığı için {target_days_clean} gün yerine kısa vadeli ({max(1, onerilen)} kt) önerildi."
                    elif trend_kodu == "STABIL" and mf_hist.get("var"):
                        oneri_metni = f"💡 Düzenli çıkıyor ({ort_aylik_6m:.1f}/ay). Geçmişte {mf_hist.get('kisa')} MF ile alındı; MF baremi avantajlı!"
                    elif trend_kodu == "STABIL":
                        oneri_metni = f"✅ Stabil ürün ({ort_aylik_6m:.1f}/ay). {target_days_clean} günlük stok hedefi için {max(1, onerilen)} kt uygun."
                    elif trend_kodu == "ARTAN":
                        oneri_metni = f"🚀 Çıkış hızı artıyor ({son_donem_hiz:.1f}/ay). Stoksuz kalmamak için {max(1, onerilen)} kt önerilir."
                    else:
                        oneri_metni = f"📦 Aralıklı çıkış ({toplam_6ay} kt / 6 ay). Minimum stok ({max(1, onerilen)} kt) tutun."

                    items.append({
                        "urun_id": u_id,
                        "mal_kodu": m_kodu,
                        "urun_kodu": m_kodu,
                        "urun_adi": u_adi,
                        "barkod": bc_val,
                        "stok": stok_val,
                        "stok_gun": stok_gun,
                        "psf": psf_val,
                        "bugun_cikis": bugun_val,
                        "aylik_cikis": son30_val,
                        "toplam_6ay": toplam_6ay,
                        "toplam_6ay_recete": toplam_6ay_recete,
                        "toplam_6ay_nakit": toplam_6ay_nakit,
                        "ort_aylik_6m": ort_aylik_6m,
                        "onceki_4_ort": round(onceki_4_ort, 1),
                        "ilk4_ort": round(onceki_4_ort, 1),
                        "son_donem_hiz": round(son_donem_hiz, 1),
                        "son2_ort": round(son_donem_hiz, 1),
                        "gunluk_hiz": gunluk_hiz,
                        "aktif_ay_sayisi": aktif_ay_sayisi,
                        "aylik_detay": aylik_detay,
                        "trend_kodu": trend_kodu,
                        "trend_etiket": trend_etiket,
                        "trend_renk": trend_renk,
                        "trend_uyari": trend_uyari,
                        "degisim_yuzde": degisim_yuzde,
                        "onerilen_siparis": max(1, onerilen) if (stok_val <= 0 or bugun_val > 0 or emanet_val > 0 or onerilen > 0) else 0,
                        "ham_ihtiyac": max(0, hedef_kutu - max(0, stok_val)),
                        "oneri_metni": oneri_metni,
                        **({
                            "bugun_emanet": emanet_val,
                            "emanet_cikis_var": True,
                            "sadece_emanet": bool(bugun_val == 0)
                        } if emanet_val > 0 else {}),
                        "gecmis_mf_var": bool(mf_hist.get("var", False)),
                        "gecmis_mf_sayisi": mf_hist.get("sayisi", 0),
                        "gecmis_mf_son_adet": mf_hist.get("son_adet", 0),
                        "gecmis_mf_min_alim": mf_hist.get("son_adet", 0),
                        "gecmis_mf_son_mf": mf_hist.get("son_mf", 0),
                        "gecmis_mf_bedelsiz": mf_hist.get("son_mf", 0),
                        "gecmis_mf_son_tarih": mf_hist.get("son_tarih", ""),
                        "gecmis_mf_son_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_depo": mf_hist.get("son_depo", ""),
                        "gecmis_mf_kisa": mf_hist.get("kisa", ""),
                        "gecmis_mf_bilgi": mf_hist.get("bilgi", "")
                    })

                items.sort(key=lambda x: (
                    0 if (x["stok"] <= 0 and x["bugun_cikis"] > 0) else (1 if x["bugun_cikis"] > 0 else 2),
                    x["stok_gun"],
                    -x["toplam_6ay"]
                ))

                return {
                    "success": True,
                    "source": "TRIA",
                    "scope": scope,
                    "target_days": target_days_clean,
                    "elapsed_ms": round((time.time() - t0) * 1000, 1),
                    "months": months_meta,
                    "items": items,
                    "stats": {
                        "total_items": len(items),
                        "stabil_count": stabil_count,
                        "azalan_count": azalan_count,
                        "artan_count": artan_count,
                        "tukenen_count": tukenen_count
                    }
                }
        except Exception as e:
            print(f"[Tria] get_six_month_smart_order_list hatası: {e}")
            return {
                "success": False,
                "source": "TRIA",
                "scope": scope,
                "error": str(e),
                "months": [],
                "items": [],
                "stats": {"total_items": 0, "stabil_count": 0, "azalan_count": 0, "artan_count": 0, "tukenen_count": 0}
            }

    def get_product_vat(self, barcode_or_code: str) -> Optional[float]:
        """Ürünün Tria veritabanındaki resmi KDV oranını döner (örn: 1.0, 10.0, 20.0)."""
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                cur.execute("""
                    SELECT k.KDV
                    FROM TBL_MAL_TANIM t
                    LEFT JOIN TBL_MAL_BARKOD_TANIM b ON t.ID = b.MAL_TANIM_ID
                    LEFT JOIN TBL_KDV_TANIM k ON t.SATIS_KDV_ID = k.ID
                    WHERE (b.BARKOD = :q OR t.MAL_KODU = :q) AND (t.PASIF IS NULL OR t.PASIF = 0)
                      AND ROWNUM = 1
                """, {"q": str(barcode_or_code).strip()})
                row = cur.fetchone()
                if row and row[0] is not None:
                    return float(row[0])
        except Exception as e:
            print(f"[Tria] get_product_vat hatası: {e}")
        return None

    def get_product_equivalents(self, barcode_or_code: str) -> Dict[str, Any]:
        """
        Belirtilen barkod veya mal koduna ait SGK Eşdeğer Grubunu (ESDEGER_GRUP_KODU) tespit eder.
        Gruptaki tüm muadilleri anlık raf stoğu, son 30 gün çıkışları ve geçmiş MF alımlarıyla döndürür.
        """
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                q = str(barcode_or_code).strip()
                cur.execute("""
                    SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), t.ESDEGER_GRUP_KODU
                    FROM TBL_MAL_TANIM t
                    LEFT JOIN TBL_MAL_BARKOD_TANIM b ON t.ID = b.MAL_TANIM_ID
                    WHERE (b.BARKOD = :q OR t.MAL_KODU = :q) AND (t.PASIF IS NULL OR t.PASIF = 0)
                      AND ROWNUM = 1
                """, {"q": q})
                r = cur.fetchone()

                # Barkod veya mal kodu ile bulunamadıysa (örn: ilaç adı girildiyse) katalogdan barkodunu bul
                if not r or not r[3]:
                    can_bc = None
                    try:
                        from backend.catalog import catalog
                        if not (q.isdigit() and len(q) >= 8):
                            suggs = catalog.search_suggestions(q, limit=1)
                            if suggs and suggs[0].get("barcode"):
                                can_bc = suggs[0]["barcode"]
                        else:
                            can_bc = catalog.resolve_canonical_barcode(q)
                    except Exception:
                        pass

                    if can_bc and can_bc.isdigit() and len(can_bc) >= 8:
                        cur.execute("""
                            SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), t.ESDEGER_GRUP_KODU
                            FROM TBL_MAL_TANIM t
                            LEFT JOIN TBL_MAL_BARKOD_TANIM b ON t.ID = b.MAL_TANIM_ID
                            WHERE (b.BARKOD = :b OR t.MAL_KODU = :b) AND (t.PASIF IS NULL OR t.PASIF = 0)
                              AND ROWNUM = 1
                        """, {"b": can_bc})
                        r = cur.fetchone()

                # Hala bulunamadıysa TBL_MAL_TANIM içinde ilaç adıyla eşleştir
                if not r or not r[3]:
                    try:
                        clean_w = [w for w in re.findall(r'[a-zA-Z0-9]+', q) if len(w) >= 3]
                        if clean_w:
                            kw = clean_w[0].upper()
                            cur.execute("""
                                SELECT t.ID, t.MAL_KODU, UTL_RAW.CAST_TO_RAW(t.MAL_ADI), t.ESDEGER_GRUP_KODU
                                FROM TBL_MAL_TANIM t
                                WHERE UPPER(t.MAL_ADI) LIKE :kw || '%'
                                  AND (t.PASIF IS NULL OR t.PASIF = 0)
                                  AND t.ESDEGER_GRUP_KODU IS NOT NULL
                                  AND ROWNUM = 1
                            """, {"kw": kw})
                            r = cur.fetchone()
                    except Exception:
                        pass

                if not r or not r[3]:
                    return {"found": False, "esdeger_kodu": None, "muadiller": [], "message": "SGK eşdeğer grubu bulunamadı."}

                m_id, m_kodu, m_adi, grup_kodu = r
                grup_str = str(grup_kodu).strip()

                cur.execute("""
                    SELECT 
                        t.MAL_KODU,
                        UTL_RAW.CAST_TO_RAW(t.MAL_ADI),
                        NVL(
                            (SELECT MAX(b.BARKOD) FROM TBL_MAL_BARKOD_TANIM b WHERE b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0) AND LENGTH(b.BARKOD) = 13),
                            NVL((SELECT MAX(b.BARKOD) FROM TBL_MAL_BARKOD_TANIM b WHERE b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)), t.MAL_KODU)
                        ) as BARKOD,
                        NVL(t.SATIS_FIYATI_1, 0) as PSF,
                        NVL((
                            SELECT SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) - 
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END)
                            FROM TBL_MAL_MIKTARLAR m WHERE m.MAL_ID = t.ID
                        ), 0) as STOK,
                        NVL((
                            SELECT SUM(ABS(mh.MIKTAR)) FROM TBL_MAL_HAREKET mh 
                            WHERE (mh.MAL_KODU = t.MAL_KODU OR LTRIM(mh.MAL_KODU, '0') = LTRIM(t.MAL_KODU, '0')) 
                              AND mh.BELGE_TARIHI >= TRUNC(SYSDATE) - 30
                              AND (
                                  UPPER(TRIM(mh.BELGE_TURU)) LIKE 'RECET%' 
                                  OR UPPER(TRIM(mh.BELGE_TURU)) LIKE 'REÇET%'
                                  OR UPPER(TRIM(mh.BELGE_TURU)) IN ('FIS', 'FİŞ', 'FATURA', 'PS', 'SF')
                                  OR mh.BELGE_TIP_NO IN ('01', '06', '02', '03')
                              )
                        ), 0) as CIKIS_30GUN,
                        (
                            SELECT TO_CHAR(d.MIKTAR) || '+' || TO_CHAR(d.MF_MIKTAR) || ' MF (' || TO_CHAR(b.BELGE_TARIHI, 'DD.MM.YYYY') || ')'
                            FROM TBL_BELGE_DETAY d
                            JOIN TBL_BELGE b ON d.BELGE_ID = b.ID
                            WHERE (d.MAL_KODU = t.MAL_KODU OR LTRIM(d.MAL_KODU, '0') = LTRIM(t.MAL_KODU, '0')) AND b.TIP_NO IN ('AAF', 'KAF', 'TGF') AND NVL(d.MF_MIKTAR, 0) > 0
                              AND ROWNUM = 1
                        ) as SON_MF_BILGI,
                        NVL(t.KAMU_ISKONTO_ORANI, 0) as KAMU_ISK,
                        NVL(t.DEPOCU_SATIS_FIYATI, 0) as DSF,
                        NVL(t.ALIS_FIYATI_1, 0) as ALIS_1,
                        NVL((SELECT MAX(k.KDV) FROM TBL_KDV_TANIM k WHERE k.ID = t.SATIS_KDV_ID), 10) as KDV_ORAN
                    FROM TBL_MAL_TANIM t
                    WHERE t.ESDEGER_GRUP_KODU = :grp AND (t.PASIF IS NULL OR t.PASIF = 0)
                    ORDER BY STOK DESC, CIKIS_30GUN DESC
                """, {"grp": grup_str})

                items = []
                current_kamu_kari = 0.0
                for row in cur.fetchall():
                    kodu = str(row[0])
                    adi = fix_tria_str(row[1])
                    barkod = str(row[2])
                    psf = round(float(row[3] or 0), 2)
                    stok = int(round(float(row[4] or 0)))
                    cikis30 = int(round(float(row[5] or 0)))
                    mf_bilgi = str(row[6] or "").strip() if row[6] else ""
                    kamu_isk = round(float(row[7] or 0.0), 2)
                    dsf_val = round(float(row[8] or 0.0), 2)
                    alis1_val = round(float(row[9] or 0.0), 2)
                    kdv_oran = float(row[10] or 10.0)
                    kdv_div = 1.0 + (kdv_oran / 100.0) if kdv_oran > 0 else 1.10

                    # Eğer Tria'da kamu iskontosu 0 görünüyorsa ancak DSF veya Alış fiyatından kamu iskontosu anlaşılıyorsa çıkar
                    dsf_brut = (psf / kdv_div) * 0.78125 if psf > 0 else 0.0
                    if kamu_isk <= 0.0 and dsf_brut > 0 and alis1_val > 0 and alis1_val < (dsf_brut * 0.985):
                        derived_isk = round((1.0 - (alis1_val / dsf_brut)) * 100.0, 1)
                        if 1.5 <= derived_isk <= 75.0:
                            kamu_isk = derived_isk

                    ksf = round(psf * (1.0 - (kamu_isk / 100.0)), 2) if (psf > 0 and kamu_isk > 0) else round(psf, 2)

                    if alis1_val > 0:
                        net_kdvsiz = alis1_val
                    elif dsf_val > 0:
                        net_kdvsiz = round(dsf_val * (1.0 - (kamu_isk / 100.0)), 2) if dsf_val >= (dsf_brut * 0.95) else dsf_val
                    elif dsf_brut > 0:
                        net_kdvsiz = round(dsf_brut * (1.0 - (kamu_isk / 100.0)), 2)
                    else:
                        net_kdvsiz = 0.0

                    net_kdvli = round(net_kdvsiz * kdv_div, 2)
                    kamu_kari = round(ksf - net_kdvli, 2) if (ksf > 0 and net_kdvli > 0) else 0.0
                    perakende_kari = round(psf - net_kdvli, 2) if (psf > 0 and net_kdvli > 0) else 0.0
                    is_curr = (kodu == str(m_kodu))
                    if is_curr:
                        current_kamu_kari = kamu_kari

                    items.append({
                        "kod": kodu,
                        "mal_kodu": kodu,
                        "ad": adi,
                        "urun_adi": adi,
                        "barkod": barkod,
                        "etiket_fiyati": psf,
                        "psf": psf,
                        "kamu_fiyati": ksf,
                        "ksf": ksf,
                        "kamu_iskontosu": kamu_isk,
                        "birim_maliyet": net_kdvsiz,
                        "net_birim_maliyet": net_kdvsiz,
                        "birim_maliyet_kdvli": net_kdvli,
                        "net_birim_maliyet_kdvli": net_kdvli,
                        "kamu_kari": kamu_kari,
                        "perakende_kari": perakende_kari,
                        "stok": stok,
                        "cikis_30gun": cikis30,
                        "gecmis_mf_var": bool(mf_bilgi),
                        "gecmis_mf_bilgi": mf_bilgi,
                        "is_current": is_curr
                    })

                for it in items:
                    kf = round(it["kamu_kari"] - current_kamu_kari, 2)
                    it["kar_farki"] = kf
                    it["is_more_profitable"] = (kf > 0)
                    it["kar_artis_yuzdesi"] = round((kf / current_kamu_kari * 100.0), 1) if (current_kamu_kari > 0 and kf > 0) else 0.0

                items.sort(key=lambda x: (x.get("kamu_kari") or 0.0, x.get("stok") or 0), reverse=True)

                en_karli = None
                muadil_kar_avantaji = 0.0
                for it in items:
                    if it.get("kar_farki", 0.0) > 0 and not it.get("is_current"):
                        it["is_best_deal"] = True
                        en_karli = it
                        muadil_kar_avantaji = it["kar_farki"]
                        break

                return {
                    "found": True,
                    "esdeger_kodu": grup_str,
                    "count": len(items),
                    "en_karli_muadil": en_karli,
                    "muadil_kar_avantaji": muadil_kar_avantaji,
                    "current_kamu_kari": current_kamu_kari,
                    "muadiller": items
                }
        except Exception as e:
            print(f"[Tria] get_product_equivalents hatası: {e}")
            return {"found": False, "error": str(e), "esdeger_kodu": None, "muadiller": []}

    def list_available_schemas(self) -> Dict[str, Any]:
        """Oracle veritabanındaki kayıtlı eczane şemalarını listeler (EdaPrim list_available_schemas)."""
        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                cur.execute("""
                    SELECT USERNAME FROM ALL_USERS 
                    WHERE USERNAME NOT IN (
                        'SYS', 'SYSTEM', 'ANONYMOUS', 'APEX_PUBLIC_USER', 'APPQOSSYS',
                        'CTXSYS', 'DBSNMP', 'DIP', 'EXFSYS', 'FLOWS_FILES', 'MDDATA',
                        'MDSYS', 'MGMT_VIEW', 'OLAPSYS', 'ORACLE_OCM', 'ORDDATA',
                        'ORDPLUGINS', 'ORDSYS', 'OUTLN', 'OWBSYS', 'OWBSYS_AUDIT',
                        'SCOTT', 'SI_INFORMTN_SCHEMA', 'SPATIAL_CSW_ADMIN_USR',
                        'SPATIAL_WFS_ADMIN_USR', 'SYSMAN', 'WMSYS', 'XDB', 'XS$NULL'
                    )
                    AND USERNAME NOT LIKE 'APEX_%'
                    ORDER BY USERNAME
                """)
                schemas = [r[0] for r in cur.fetchall() if r and r[0] != 'XS$NULL']
                return {"success": True, "schemas": schemas}
        except Exception as e:
            return {"success": False, "error": str(e), "schemas": []}

    def discover_oracle_host(self) -> Dict[str, Any]:
        return self.discover_tria_host()

    def discover_tria_host(self) -> Dict[str, Any]:
        """Ağda veya yerel makinede TRIA Oracle sunucusunu tüm alt ağda paralel tarayarak otomatik keşfeder."""
        import socket
        import concurrent.futures
        import re

        local_ip = "127.0.0.1"
        prefix = "192.168.1"
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            prefix = ".".join(local_ip.split(".")[:3])
        except Exception:
            pass

        cfg_user = os.environ.get("TRIA_DB_USER", "").strip()
        cfg_pwd = os.environ.get("TRIA_DB_PASSWORD", "").strip() or cfg_user
        cfg_host = os.environ.get("TRIA_DB_HOST", "").strip()

        # Varsa yerel Tria / Oracle tnsnames.ora veya ini dosyalarından IP/SID ipucu oku
        hint_ips = []
        if cfg_host and cfg_host not in ("127.0.0.1", "localhost"):
            hint_ips.append(cfg_host)
        for tns_cand in [
            r"C:\Tria\tnsnames.ora",
            r"D:\Tria\tnsnames.ora",
            os.path.join(self.base_dir, "oracle_client", "network_admin", "tnsnames.ora"),
        ]:
            if os.path.exists(tns_cand):
                try:
                    with open(tns_cand, "r", encoding="utf-8", errors="ignore") as f:
                        txt = f.read()
                    for m in re.findall(r"HOST\s*=\s*([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)", txt, re.I):
                        if m not in hint_ips:
                            hint_ips.append(m)
                except Exception:
                    pass

        all_ips = list(dict.fromkeys(
            hint_ips + [f"{prefix}.{i}" for i in range(1, 255) if f"{prefix}.{i}" != local_ip]
        ))

        def _probe_port(ip_port):
            ip, p = ip_port
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.25)
            try:
                if sock.connect_ex((ip, p)) == 0:
                    return (ip, str(p))
            except Exception:
                pass
            finally:
                sock.close()
            return None

        targets = [(ip, p) for p in (1521, 1522) for ip in all_ips]
        open_endpoints = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=96) as ex:
            for res in ex.map(_probe_port, targets):
                if res:
                    open_endpoints.append(res)

        for p in (1521, 1522):
            res = _probe_port(("127.0.0.1", p))
            if res:
                open_endpoints.append(res)

        candidates_found = []
        if oracledb is not None and cfg_user:
            self._init_oracle_client()
            for cand_ip, cand_port in open_endpoints:
                for cand_sid in ("ORCL", "XEPDB1", "XE"):
                    try:
                        conn = self._open_and_verify_conn(
                            cand_ip, cand_port, cand_sid, cfg_user, cfg_pwd, timeout=1.5
                        )
                        cur = conn.cursor()
                        cur.execute("SELECT MAX(RECETE_TARIHI) FROM TBL_RECETE")
                        max_dt = cur.fetchone()[0]
                        conn.close()
                        max_dt_str = str(max_dt or "")
                        match_info = {
                            "success": True,
                            "found": True,
                            "host": cand_ip,
                            "port": cand_port,
                            "sid": cand_sid,
                            "user": cfg_user,
                            "password": cfg_pwd,
                            "max_date": max_dt_str,
                            "_score": (
                                1 if cand_ip != "127.0.0.1" else 0,
                                1 if str(cand_port) == "1521" else 0,
                                max_dt_str,
                            ),
                            "message": f"Ağda canlı TRIA Oracle sunucusu bulundu: {cand_ip}:{cand_port}/{cand_sid} ({cfg_user})"
                        }
                        candidates_found.append(match_info)
                        break
                    except Exception as e:
                        es = str(e)
                        if "ORA-01017" in es or "ORA-28000" in es:
                            break
                        continue

        if candidates_found:
            candidates_found.sort(key=lambda x: x["_score"], reverse=True)
            best_match = dict(candidates_found[0])
            best_match.pop("_score", None)
            if best_match["host"] != "127.0.0.1":
                self._persist_env_settings(
                    best_match["host"],
                    best_match["port"],
                    best_match["sid"],
                    best_match["user"],
                    best_match["password"],
                )
            return best_match

        if open_endpoints:
            found_ip, found_port = open_endpoints[0]
            return {
                "success": True,
                "found": True,
                "host": found_ip,
                "port": found_port,
                "sid": "ORCL",
                "user": cfg_user,
                "message": f"Ağda TRIA Oracle sunucusu bulundu: {found_ip}:{found_port} (Lütfen TRIA şema/kullanıcı adınızı giriniz)"
            }
        return {
            "success": False,
            "found": False,
            "host": "",
            "port": "1521",
            "sid": "ORCL",
            "user": cfg_user,
            "message": "Ağda açık Oracle (1521) sunucusu tespit edilemedi. Lütfen sunucu IP adresini elle giriniz."
        }

    def get_bulk_stock_and_sales_map(self, barcodes: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Verilen barkod listesi için TRIA Oracle veritabanından tek seferde (toplu/bulk)
        anlık altın stok (Golden Formula), son 1 aylık (30 gün) çıkış ve son 3 aylık (90 gün) çıkış
        sayılarını döndürür.
        """
        result: Dict[str, Dict[str, Any]] = {}
        clean_inputs = [str(b or "").strip() for b in (barcodes or []) if str(b or "").strip()]
        if not clean_inputs:
            return result

        variant_to_originals: Dict[str, set] = {}
        for orig_bc in clean_inputs:
            result[orig_bc] = {"stok": 0, "cikis_1ay": 0, "cikis_3ay": 0, "found": False}
            variants = {orig_bc}
            if orig_bc.isdigit():
                if len(orig_bc) == 13:
                    variants.add("0" + orig_bc)
                elif len(orig_bc) == 14 and orig_bc.startswith("0"):
                    variants.add(orig_bc[1:])
            try:
                from backend.catalog import catalog
                c_item = catalog.get_by_barcode(orig_bc)
                if c_item:
                    if c_item.get("barcode"):
                        variants.add(str(c_item["barcode"]).strip())
                    for ab in (c_item.get("all_barcodes") or []):
                        if str(ab).strip():
                            variants.add(str(ab).strip())
            except Exception:
                pass
            for v in variants:
                if v:
                    variant_to_originals.setdefault(v, set()).add(orig_bc)

        all_variants = list(variant_to_originals.keys())
        if not all_variants:
            return result

        try:
            with self.get_connection() as conn:
                cur = conn.cursor()
                mal_id_to_originals: Dict[int, set] = {}
                mal_kodu_to_originals: Dict[str, set] = {}

                chunk_size = 400
                for i in range(0, len(all_variants), chunk_size):
                    chunk = all_variants[i:i + chunk_size]
                    bind_names = [f":b{ idx }" for idx in range(len(chunk))]
                    bind_map = {f"b{ idx }": val for idx, val in enumerate(chunk)}
                    in_clause = ",".join(bind_names)

                    cur.execute(f"""
                        SELECT t.ID, t.MAL_KODU, b.BARKOD
                        FROM TBL_MAL_TANIM t
                        LEFT JOIN TBL_MAL_BARKOD_TANIM b
                               ON b.MAL_TANIM_ID = t.ID AND (b.PASIF IS NULL OR b.PASIF = 0)
                        WHERE (b.BARKOD IN ({in_clause}) OR t.MAL_KODU IN ({in_clause}))
                          AND (t.PASIF IS NULL OR t.PASIF = 0)
                    """, bind_map)
                    for row in cur.fetchall():
                        m_id = int(row[0] or 0)
                        m_kodu = str(row[1] or "").strip()
                        b_str = str(row[2] or "").strip()
                        matched_origs = set()
                        if b_str in variant_to_originals:
                            matched_origs.update(variant_to_originals[b_str])
                        if m_kodu in variant_to_originals:
                            matched_origs.update(variant_to_originals[m_kodu])
                        if matched_origs:
                            if m_id > 0:
                                mal_id_to_originals.setdefault(m_id, set()).update(matched_origs)
                            if m_kodu:
                                mal_kodu_to_originals.setdefault(m_kodu, set()).update(matched_origs)

                all_mal_ids = list(mal_id_to_originals.keys())
                all_mal_kodlari = list(mal_kodu_to_originals.keys())
                if not all_mal_ids and not all_mal_kodlari:
                    return result

                mid_stock: Dict[int, int] = {}
                for i in range(0, len(all_mal_ids), chunk_size):
                    m_chunk = all_mal_ids[i:i + chunk_size]
                    bind_names = [f":m{ idx }" for idx in range(len(m_chunk))]
                    bind_map = {f"m{ idx }": val for idx, val in enumerate(m_chunk)}
                    in_clause = ",".join(bind_names)

                    cur.execute(f"""
                        SELECT m.MAL_ID,
                               NVL(
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.GIREN_MIKTAR ELSE m.GIREN_MIKTAR END) -
                                   SUM(CASE WHEN m.NORMAL_IADE_DURUMU = 1 THEN -m.CIKAN_MIKTAR ELSE m.CIKAN_MIKTAR END),
                                   0
                               ) AS STOK
                        FROM TBL_MAL_MIKTARLAR m
                        WHERE m.MAL_ID IN ({in_clause})
                        GROUP BY m.MAL_ID
                    """, bind_map)
                    for row in cur.fetchall():
                        m_id = int(row[0] or 0)
                        mid_stock[m_id] = int(round(float(row[1] or 0.0)))

                mkod_c30: Dict[str, int] = {}
                mkod_c90: Dict[str, int] = {}
                for i in range(0, len(all_mal_kodlari), chunk_size):
                    k_chunk = all_mal_kodlari[i:i + chunk_size]
                    bind_names = [f":k{ idx }" for idx in range(len(k_chunk))]
                    bind_map = {f"k{ idx }": val for idx, val in enumerate(k_chunk)}
                    in_clause = ",".join(bind_names)

                    cur.execute(f"""
                        SELECT h.MAL_KODU,
                               NVL(SUM(CASE WHEN h.BELGE_TARIHI >= SYSDATE - 30 AND (
                                   (UPPER(TRIM(h.BELGE_TURU)) = 'FIS' AND h.BELGE_TIP_NO IN ('01', '06')) OR
                                   UPPER(TRIM(h.BELGE_TURU)) = 'RECETE'
                               ) THEN h.MIKTAR ELSE 0 END), 0) AS C30,
                               NVL(SUM(CASE WHEN h.BELGE_TARIHI >= SYSDATE - 90 AND (
                                   (UPPER(TRIM(h.BELGE_TURU)) = 'FIS' AND h.BELGE_TIP_NO IN ('01', '06')) OR
                                   UPPER(TRIM(h.BELGE_TURU)) = 'RECETE'
                               ) THEN h.MIKTAR ELSE 0 END), 0) AS C90
                        FROM TBL_MAL_HAREKET h
                        WHERE h.MAL_KODU IN ({in_clause})
                          AND h.BELGE_TARIHI >= SYSDATE - 90
                          AND h.BELGE_TARIHI <= SYSDATE + 1
                        GROUP BY h.MAL_KODU
                    """, bind_map)
                    for row in cur.fetchall():
                        mk = str(row[0] or "").strip()
                        mkod_c30[mk] = int(round(float(row[1] or 0.0)))
                        mkod_c90[mk] = int(round(float(row[2] or 0.0)))

                orig_mids: Dict[str, set] = {}
                for m_id, origs in mal_id_to_originals.items():
                    for obc in origs:
                        orig_mids.setdefault(obc, set()).add(m_id)

                orig_mkods: Dict[str, set] = {}
                for mk, origs in mal_kodu_to_originals.items():
                    for obc in origs:
                        orig_mkods.setdefault(obc, set()).add(mk)

                all_matched_origs = set(orig_mids.keys()) | set(orig_mkods.keys())
                for obc in all_matched_origs:
                    tot_stok = sum(mid_stock.get(m, 0) for m in orig_mids.get(obc, set()))
                    tot_c30 = sum(mkod_c30.get(k, 0) for k in orig_mkods.get(obc, set()))
                    tot_c90 = sum(mkod_c90.get(k, 0) for k in orig_mkods.get(obc, set()))
                    result[obc] = {
                        "stok": int(tot_stok),
                        "cikis_1ay": int(tot_c30),
                        "cikis_3ay": int(tot_c90),
                        "found": True,
                    }

        except Exception as e:
            print(f"[TRIA] get_bulk_stock_and_sales_map hatası: {e}")

        return result


# Singleton instance
tria_client = TriaOracleClient()
