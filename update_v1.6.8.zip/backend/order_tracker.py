# -*- coding: utf-8 -*-
"""
backend/order_tracker.py
------------------------
Eczane İçi Tüm Bilgisayarlar Arası Ortak Günlük Sipariş & Sepet Takip Modülü.

Mimari:
- Eczanedeki tüm bilgisayarlar aynı Tria Oracle (veya Botanik MS SQL) veritabanına bağlandığı için,
  sipariş/sepet durumlarını doğrudan merkezi veritabanındaki yardımcı tabloda (`TBL_EDA_GUNLUK_SIPARIS` / `EdaGunlukSiparis`)
  ve eşzamanlı olarak yerel SQLite yedeğinde tutar.
- Böylece Masa 1'de bir ürün toplu veya tekil olarak sipariş verilip sonlandırıldığında (veya sepete eklendiğinde),
  Masa 2 ve Masa 3'teki ekranlarda da anında "SİPARİŞ VERİLDİ" / "SEPETTE" olarak görünür ve mükerrer sipariş önlenir.
"""

import os
import re
import time
import socket
import sqlite3
import datetime
import threading
from pathlib import Path
from typing import Dict, Any, List, Optional


class SharedOrderTracker:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = Path(base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.data_dir = self.base_dir / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.sqlite_path = self.data_dir / "shared_orders_local.db"
        self.hostname = socket.gethostname()
        self.pc_name = self.hostname
        self._lock = threading.Lock()
        self._tria_table_ready = False
        self._botanik_table_ready = False
        self._tebeos_table_ready = False
        self._eczanem_table_ready = False
        self._last_cart_add_ts: Dict[str, float] = {}
        self._recent_takas_cache: Dict[str, Any] = {"ts": 0.0, "data": {}}
        self.last_central_read_ok: bool = False
        self._init_local_sqlite()

    def get_last_cart_add_time(self, depo: str) -> float:
        return self._last_cart_add_ts.get(str(depo or "").strip().upper(), 0.0)

    def _today_str(self) -> str:
        return datetime.date.today().strftime("%Y-%m-%d")

    def _now_time_str(self) -> str:
        return datetime.datetime.now().strftime("%H:%M")

    def _init_local_sqlite(self):
        try:
            with sqlite3.connect(self.sqlite_path, timeout=5) as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS daily_orders (
                        tarih TEXT NOT NULL,
                        barkod TEXT NOT NULL,
                        urun_adi TEXT,
                        durum TEXT NOT NULL,
                        depo TEXT,
                        miktar INTEGER DEFAULT 1,
                        masa_adi TEXT,
                        saat TEXT,
                        updated_at REAL,
                        PRIMARY KEY (tarih, barkod)
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS daily_joined_offers (
                        tarih TEXT NOT NULL,
                        offer_key TEXT NOT NULL,
                        depo TEXT NOT NULL,
                        offer_id TEXT NOT NULL,
                        barkod TEXT,
                        urun_adi TEXT,
                        miktar INTEGER DEFAULT 1,
                        fiyat_kdvli REAL DEFAULT 0,
                        fiyat_kdvsiz REAL DEFAULT 0,
                        depo_fiyati REAL DEFAULT 0,
                        mf TEXT,
                        satici TEXT,
                        group_name TEXT,
                        miad TEXT,
                        katil_url TEXT,
                        not_metni TEXT,
                        masa_adi TEXT,
                        saat TEXT,
                        updated_at REAL,
                        PRIMARY KEY (tarih, offer_key)
                    )
                """)
                conn.commit()
        except Exception as e:
            print(f"[OrderTracker] Yerel SQLite başlatma uyarısı: {e}")

    def _ensure_tria_table(self, conn) -> bool:
        if self._tria_table_ready:
            return True
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT COUNT(*) FROM USER_TABLES WHERE TABLE_NAME = 'TBL_EDA_GUNLUK_SIPARIS'
            """)
            exists = cur.fetchone()[0] > 0
            if not exists:
                cur.execute("""
                    CREATE TABLE TBL_EDA_GUNLUK_SIPARIS (
                        TARIH VARCHAR2(16) NOT NULL,
                        BARKOD VARCHAR2(32) NOT NULL,
                        URUN_ADI VARCHAR2(255),
                        DURUM VARCHAR2(32) NOT NULL,
                        DEPO VARCHAR2(64),
                        MIKTAR NUMBER(10) DEFAULT 1,
                        MASA_ADI VARCHAR2(128),
                        SAAT VARCHAR2(16),
                        GUNCELLEME_ZAMANI DATE DEFAULT SYSDATE,
                        CONSTRAINT PK_EDA_GUNLUK_SIP PRIMARY KEY (TARIH, BARKOD)
                    )
                """)
                conn.commit()
            self._tria_table_ready = True
            return True
        except Exception as e:
            if "ORA-00955" in str(e):
                self._tria_table_ready = True
                return True
            print(f"[OrderTracker] Tria tablo hazırlama uyarısı: {e}")
            return False

    def _ensure_botanik_table(self, conn) -> bool:
        if self._botanik_table_ready:
            return True
        try:
            cur = conn.cursor()
            cur.execute("""
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EdaGunlukSiparis' AND xtype='U')
                CREATE TABLE EdaGunlukSiparis (
                    Tarih VARCHAR(16) NOT NULL,
                    Barkod VARCHAR(32) NOT NULL,
                    UrunAdi NVARCHAR(255),
                    Durum VARCHAR(32) NOT NULL,
                    Depo VARCHAR(64),
                    Miktar INT DEFAULT 1,
                    MasaAdi NVARCHAR(128),
                    Saat VARCHAR(16),
                    GuncellemeZamani DATETIME DEFAULT GETDATE(),
                    CONSTRAINT PK_EdaGunlukSiparis PRIMARY KEY (Tarih, Barkod)
                )
            """)
            conn.commit()
            self._botanik_table_ready = True
            return True
        except Exception as e:
            print(f"[OrderTracker] Botanik tablo hazırlama uyarısı: {e}")
            return False

    def _ensure_tebeos_table(self, conn) -> bool:
        if self._tebeos_table_ready:
            return True
        try:
            conn.query("""
                CREATE TABLE IF NOT EXISTS public.eda_gunluk_siparis (
                    tarih VARCHAR(16) NOT NULL,
                    barkod VARCHAR(32) NOT NULL,
                    urun_adi VARCHAR(255),
                    durum VARCHAR(32) NOT NULL,
                    depo VARCHAR(64),
                    miktar INTEGER DEFAULT 1,
                    masa_adi VARCHAR(128),
                    saat VARCHAR(16),
                    guncelleme_zamani TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (tarih, barkod)
                )
            """)
            self._tebeos_table_ready = True
            return True
        except Exception as e:
            print(f"[OrderTracker] TEBEOS tablo hazırlama uyarısı: {e}")
            return False

    def _ensure_eczanem_table(self, conn) -> bool:
        if self._eczanem_table_ready:
            return True
        try:
            cur = conn.cursor()
            cur.execute("""
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EdaGunlukSiparis' AND xtype='U')
                CREATE TABLE EdaGunlukSiparis (
                    Tarih VARCHAR(16) NOT NULL,
                    Barkod VARCHAR(32) NOT NULL,
                    UrunAdi NVARCHAR(255),
                    Durum VARCHAR(32) NOT NULL,
                    Depo VARCHAR(64),
                    Miktar INT DEFAULT 1,
                    MasaAdi NVARCHAR(128),
                    Saat VARCHAR(16),
                    GuncellemeZamani DATETIME DEFAULT GETDATE(),
                    CONSTRAINT PK_EdaGunlukSiparis PRIMARY KEY (Tarih, Barkod)
                )
            """)
            conn.commit()
            self._eczanem_table_ready = True
            return True
        except Exception as e:
            print(f"[OrderTracker] Eczanem tablo hazırlama uyarısı: {e}")
            return False

    def _normalize_barcode(self, barcode: str, urun_adi: str = "") -> str:
        bc = str(barcode or "").strip()
        if len(bc) == 14 and bc.startswith("0"):
            bc = bc[1:]
        if bc:
            try:
                from backend.catalog import catalog
                can = catalog.resolve_canonical_barcode(bc)
                if can:
                    return can
            except Exception:
                pass
            return bc
        if urun_adi:
            try:
                from backend.catalog import catalog
                suggs = catalog.search_suggestions(urun_adi, limit=1)
                if suggs and suggs[0].get("barcode"):
                    return str(suggs[0]["barcode"]).strip()
            except Exception:
                pass
        return bc

    def mark_ordered(
        self,
        items: List[Dict[str, Any]],
        default_depo: str = "",
        masa_adi: Optional[str] = None
    ) -> int:
        return self.mark_items(items=items, durum="SIPARIS_VERILDI", default_depo=default_depo, masa_adi=masa_adi)

    def mark_items(
        self,
        items: List[Dict[str, Any]],
        durum: str = "SIPARIS_VERILDI",
        default_depo: str = "",
        masa_adi: Optional[str] = None
    ) -> int:
        """
        Verilen ürün listesini ('SIPARIS_VERILDI' veya 'SEPETTE') olarak hem merkezi veritabanına
        (Tria Oracle / Botanik MS SQL / TEBEOS / Eczanem) hem de yerel önbelleğe kaydeder.
        Eğer ürün zaten 'SIPARIS_VERILDI' ise ve yeni gelen durum 'SEPETTE' ise,
        'SIPARIS_VERILDI' statüsünü korur (düşürmez).
        """
        if not items:
            return 0

        tarih = self._today_str()
        saat = self._now_time_str()
        masa = (masa_adi or self.hostname or "Eczane-PC").strip()

        normalized_records = []
        for it in items:
            raw_bc = str(it.get("barkod") or it.get("barcode") or it.get("urun_id") or it.get("kod") or "").strip()
            if raw_bc.startswith("CART:"):
                parts = raw_bc.split(":", 2)
                raw_bc = parts[2] if len(parts) == 3 else ""
            raw_name = str(it.get("urun_adi") or it.get("name") or it.get("ad") or "").strip()
            offer_key = str(it.get("offer_key") or "").strip()[:32]
            bc = self._normalize_barcode(raw_bc, raw_name)
            if not bc and not raw_name and not offer_key:
                continue
            key_bc = bc or offer_key or raw_name[:30].upper()
            depo = str(it.get("depo") or it.get("assigned_depo") or default_depo or "DEPO").strip().upper()
            try:
                miktar = max(1, int(it.get("miktar") or it.get("adet") or 1))
            except Exception:
                miktar = 1

            if durum == "SEPETTE" and depo:
                self._last_cart_add_ts[depo] = time.time()

            clean_depo_code = re.sub(r"[^A-Z0-9_]", "", depo)[:10] or "DEPO"
            base_cart_token = bc or offer_key or re.sub(r"[^A-Z0-9]", "", raw_name.upper())[:16]
            cart_key = f"CART:{clean_depo_code}:{base_cart_token}"[:32] if (base_cart_token and depo not in ("YOK_LISTESI", "VERILMEYECEK")) else ""

            normalized_records.append({
                "tarih": tarih,
                "barkod": key_bc[:32],
                "raw_barkod": raw_bc[:32] if raw_bc else key_bc[:32],
                "offer_key": offer_key,
                "name_key": f"NAME:{raw_name.upper()[:26]}" if raw_name else "",
                "cart_key": cart_key,
                "urun_adi": (raw_name or key_bc)[:250],
                "durum": durum,
                "depo": depo[:60],
                "miktar": miktar,
                "masa_adi": masa[:120],
                "saat": saat
            })

        if not normalized_records:
            return 0

        def _record_keys(rec: Dict[str, Any]):
            keys = {rec.get("barkod", ""), rec.get("raw_barkod", ""), rec.get("name_key", ""), rec.get("offer_key", "")}
            for k_c in list(keys):
                if len(k_c) == 14 and k_c.startswith("0"):
                    keys.add(k_c[1:])
                elif len(k_c) == 13 and k_c.isdigit():
                    keys.add("0" + k_c)
            if rec.get("cart_key") and rec.get("durum") in ("SEPETTE", "SIPARIS_VERILDI"):
                keys.add(rec["cart_key"])
            return [k[:32] for k in keys if k]

        # 1. Yerel SQLite'a kaydet
        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    for rec in normalized_records:
                        for b_key in _record_keys(rec):
                            is_cart_key = b_key.startswith("CART:")
                            if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and not is_cart_key:
                                s_cur.execute(
                                    "DELETE FROM daily_orders WHERE UPPER(depo) = 'YOK_LISTESI' AND barkod = ?",
                                    (b_key,)
                                )
                            s_cur.execute(
                                "SELECT durum, miktar, depo FROM daily_orders WHERE tarih = ? AND barkod = ?",
                                (tarih, b_key)
                            )
                            existing = s_cur.fetchone()
                            if existing and not is_cart_key:
                                ex_durum = str(existing[0] or "").upper()
                                ex_depo = str(existing[2] or "").strip().upper()
                                # Farklı bir deponun aktif SEPETTE kaydını çıplak anahtarda ezme veya başka deponun SIPARIS_VERILDI işleminin diğer deponun SEPETTE anahtarını ezmesini önle
                                if rec["durum"] == "SIPARIS_VERILDI" and ex_durum == "SEPETTE" and ex_depo and ex_depo != rec["depo"]:
                                    continue
                            s_cur.execute("""
                                INSERT OR REPLACE INTO daily_orders
                                (tarih, barkod, urun_adi, durum, depo, miktar, masa_adi, saat, updated_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, strftime('%s','now'))
                            """, (
                                tarih, b_key, rec["urun_adi"], rec["durum"],
                                rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"]
                            ))
                        if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and rec["urun_adi"]:
                            s_cur.execute(
                                "DELETE FROM daily_orders WHERE UPPER(depo) = 'YOK_LISTESI' AND UPPER(urun_adi) = ?",
                                (rec["urun_adi"].strip().upper(),)
                            )
                        if rec["durum"] == "SIPARIS_VERILDI" and rec["urun_adi"]:
                            s_cur.execute("""
                                UPDATE daily_orders
                                SET durum = ?, depo = ?, miktar = ?, masa_adi = ?, saat = ?, updated_at = strftime('%s','now')
                                WHERE tarih = ? AND UPPER(urun_adi) = ? AND UPPER(depo) = ? AND durum = 'SEPETTE'
                            """, (
                                rec["durum"], rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"],
                                tarih, rec["urun_adi"].strip().upper(), rec["depo"].strip().upper()
                            ))
                        elif rec["durum"] == "SIPARIS_VERILMEYECEK" and rec["urun_adi"]:
                            s_cur.execute("""
                                UPDATE daily_orders
                                SET durum = ?, depo = ?, miktar = ?, masa_adi = ?, saat = ?, updated_at = strftime('%s','now')
                                WHERE tarih = ? AND UPPER(urun_adi) = ? AND durum = 'SEPETTE'
                            """, (
                                rec["durum"], rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"],
                                tarih, rec["urun_adi"].strip().upper()
                            ))
                    s_conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Yerel SQLite yazma uyarısı: {e}")

        # 2. Merkezi Veritabanına (Tria Oracle, Botanik MS SQL veya TEBEOS PostgreSQL) kaydet
        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            if not self._write_to_tria(normalized_records):
                self._write_to_botanik(normalized_records)
        elif active_oto == "BOTANIK":
            self._write_to_botanik(normalized_records)
        elif active_oto == "TEBEOS":
            self._write_to_tebeos(normalized_records)
        elif active_oto == "ECZANEM":
            self._write_to_eczanem(normalized_records)

        self._recent_takas_cache = {"ts": 0.0, "data": {}}
        return len(normalized_records)

    def _write_to_tria(self, records: List[Dict[str, Any]]) -> bool:
        try:
            from backend.tria_client import tria_client
            with tria_client.get_connection() as conn:
                if not self._ensure_tria_table(conn):
                    return False
                cur = conn.cursor()
                for rec in records:
                    keys = {rec["barkod"], rec["raw_barkod"], rec.get("name_key", ""), rec.get("offer_key", "")}
                    bc_val = rec.get("barkod", "")
                    if len(bc_val) == 14 and bc_val.startswith("0"):
                        keys.add(bc_val[1:])
                    elif len(bc_val) == 13 and bc_val.isdigit():
                        keys.add("0" + bc_val)
                    if rec.get("cart_key") and rec.get("durum") in ("SEPETTE", "SIPARIS_VERILDI"):
                        keys.add(rec["cart_key"])
                    if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and rec.get("urun_adi"):
                        cur.execute(
                            "DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE UPPER(DEPO) = 'YOK_LISTESI' AND UPPER(URUN_ADI) = :u",
                            {"u": rec["urun_adi"].strip().upper()}
                        )
                    for b_key in [k[:32] for k in keys if k]:
                        is_cart_key = b_key.startswith("CART:")
                        if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and not is_cart_key:
                            cur.execute(
                                "DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE UPPER(DEPO) = 'YOK_LISTESI' AND BARKOD = :b",
                                {"b": b_key}
                            )
                        cur.execute("""
                            SELECT DURUM, DEPO FROM TBL_EDA_GUNLUK_SIPARIS
                            WHERE TARIH = :t AND BARKOD = :b
                        """, {"t": rec["tarih"], "b": b_key})
                        row = cur.fetchone()
                        if row:
                            if not is_cart_key and rec["durum"] == "SIPARIS_VERILDI":
                                ex_durum = str(row[0] or "").upper()
                                ex_depo = str(row[1] or "").strip().upper()
                                if ex_durum == "SEPETTE" and ex_depo and ex_depo != rec["depo"]:
                                    continue
                            cur.execute("""
                                UPDATE TBL_EDA_GUNLUK_SIPARIS
                                SET URUN_ADI = :u, DURUM = :d, DEPO = :dp, MIKTAR = :m,
                                    MASA_ADI = :ms, SAAT = :s, GUNCELLEME_ZAMANI = SYSDATE
                                WHERE TARIH = :t AND BARKOD = :b
                            """, {
                                "u": rec["urun_adi"], "d": rec["durum"], "dp": rec["depo"],
                                "m": rec["miktar"], "ms": rec["masa_adi"], "s": rec["saat"],
                                "t": rec["tarih"], "b": b_key
                            })
                        else:
                            cur.execute("""
                                INSERT INTO TBL_EDA_GUNLUK_SIPARIS
                                (TARIH, BARKOD, URUN_ADI, DURUM, DEPO, MIKTAR, MASA_ADI, SAAT, GUNCELLEME_ZAMANI)
                                VALUES (:t, :b, :u, :d, :dp, :m, :ms, :s, SYSDATE)
                            """, {
                                "t": rec["tarih"], "b": b_key, "u": rec["urun_adi"],
                                "d": rec["durum"], "dp": rec["depo"], "m": rec["miktar"],
                                "ms": rec["masa_adi"], "s": rec["saat"]
                            })
                conn.commit()
                return True
        except Exception as e:
            print(f"[OrderTracker] Tria merkezi sipariş kayıt uyarısı: {e}")
            return False

    def _write_to_botanik(self, records: List[Dict[str, Any]]) -> bool:
        try:
            from backend.botanik_client import botanik_client
            with botanik_client.get_connection() as conn:
                if not self._ensure_botanik_table(conn):
                    return False
                cur = conn.cursor()
                for rec in records:
                    keys = {rec["barkod"], rec["raw_barkod"], rec.get("name_key", ""), rec.get("offer_key", "")}
                    bc_val = rec.get("barkod", "")
                    if len(bc_val) == 14 and bc_val.startswith("0"):
                        keys.add(bc_val[1:])
                    elif len(bc_val) == 13 and bc_val.isdigit():
                        keys.add("0" + bc_val)
                    if rec.get("cart_key") and rec.get("durum") in ("SEPETTE", "SIPARIS_VERILDI"):
                        keys.add(rec["cart_key"])
                    if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and rec.get("urun_adi"):
                        cur.execute(
                            "DELETE FROM EdaGunlukSiparis WHERE UPPER(Depo) = 'YOK_LISTESI' AND UPPER(UrunAdi) = ?",
                            (rec["urun_adi"].strip().upper(),)
                        )
                    for b_key in [k[:32] for k in keys if k]:
                        is_cart_key = b_key.startswith("CART:")
                        if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and not is_cart_key:
                            cur.execute(
                                "DELETE FROM EdaGunlukSiparis WHERE UPPER(Depo) = 'YOK_LISTESI' AND Barkod = ?",
                                (b_key,)
                            )
                        cur.execute("""
                            SELECT Durum, Depo FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?
                        """, (rec["tarih"], b_key))
                        row = cur.fetchone()
                        if row:
                            if not is_cart_key and rec["durum"] == "SIPARIS_VERILDI":
                                ex_durum = str(row[0] or "").upper()
                                ex_depo = str(row[1] or "").strip().upper()
                                if ex_durum == "SEPETTE" and ex_depo and ex_depo != rec["depo"]:
                                    continue
                            cur.execute("""
                                UPDATE EdaGunlukSiparis
                                SET UrunAdi = ?, Durum = ?, Depo = ?, Miktar = ?,
                                    MasaAdi = ?, Saat = ?, GuncellemeZamani = GETDATE()
                                WHERE Tarih = ? AND Barkod = ?
                            """, (
                                rec["urun_adi"], rec["durum"], rec["depo"], rec["miktar"],
                                rec["masa_adi"], rec["saat"], rec["tarih"], b_key
                            ))
                        else:
                            cur.execute("""
                                INSERT INTO EdaGunlukSiparis
                                (Tarih, Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat, GuncellemeZamani)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, GETDATE())
                            """, (
                                rec["tarih"], b_key, rec["urun_adi"], rec["durum"],
                                rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"]
                            ))
                conn.commit()
                return True
        except Exception as e:
            print(f"[OrderTracker] Botanik merkezi sipariş kayıt uyarısı: {e}")
            return False

    def _write_to_tebeos(self, records: List[Dict[str, Any]]) -> bool:
        try:
            from backend.tebeos_client import tebeos_client, _sql_lit
            with tebeos_client.get_connection() as conn:
                if not self._ensure_tebeos_table(conn):
                    return False
                for rec in records:
                    keys = {rec["barkod"], rec["raw_barkod"], rec.get("name_key", ""), rec.get("offer_key", "")}
                    bc_val = rec.get("barkod", "")
                    if len(bc_val) == 14 and bc_val.startswith("0"):
                        keys.add(bc_val[1:])
                    elif len(bc_val) == 13 and bc_val.isdigit():
                        keys.add("0" + bc_val)
                    if rec.get("cart_key") and rec.get("durum") in ("SEPETTE", "SIPARIS_VERILDI"):
                        keys.add(rec["cart_key"])
                    if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and rec.get("urun_adi"):
                        conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE UPPER(depo) = 'YOK_LISTESI' AND UPPER(urun_adi) = {_sql_lit(rec['urun_adi'].strip().upper())}")
                    for b_key in [k[:32] for k in keys if k]:
                        is_cart_key = b_key.startswith("CART:")
                        t_lit = _sql_lit(rec["tarih"])
                        b_lit = _sql_lit(b_key)
                        u_lit = _sql_lit(rec["urun_adi"])
                        d_lit = _sql_lit(rec["durum"])
                        dp_lit = _sql_lit(rec["depo"])
                        m_lit = int(rec["miktar"] or 1)
                        ms_lit = _sql_lit(rec["masa_adi"])
                        s_lit = _sql_lit(rec["saat"])
                        if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and not is_cart_key:
                            conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE UPPER(depo) = 'YOK_LISTESI' AND barkod = {b_lit}")
                        _, rows = conn.query(f"SELECT durum, depo FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND barkod = {b_lit}")
                        if rows:
                            if not is_cart_key and rec["durum"] == "SIPARIS_VERILDI":
                                ex_durum = str(rows[0][0] or "").upper()
                                ex_depo = str(rows[0][1] or "").strip().upper()
                                if ex_durum == "SEPETTE" and ex_depo and ex_depo != rec["depo"]:
                                    continue
                            conn.query(f"""
                                UPDATE public.eda_gunluk_siparis
                                SET urun_adi = {u_lit}, durum = {d_lit}, depo = {dp_lit}, miktar = {m_lit},
                                    masa_adi = {ms_lit}, saat = {s_lit}, guncelleme_zamani = CURRENT_TIMESTAMP
                                WHERE tarih = {t_lit} AND barkod = {b_lit}
                            """)
                        else:
                            conn.query(f"""
                                INSERT INTO public.eda_gunluk_siparis
                                (tarih, barkod, urun_adi, durum, depo, miktar, masa_adi, saat, guncelleme_zamani)
                                VALUES ({t_lit}, {b_lit}, {u_lit}, {d_lit}, {dp_lit}, {m_lit}, {ms_lit}, {s_lit}, CURRENT_TIMESTAMP)
                            """)
                return True
        except Exception as e:
            print(f"[OrderTracker] TEBEOS merkezi sipariş kayıt uyarısı: {e}")
            return False

    def _write_to_eczanem(self, records: List[Dict[str, Any]]) -> bool:
        try:
            from backend.eczanem_client import eczanem_client
            with eczanem_client.get_connection() as conn:
                if not self._ensure_eczanem_table(conn):
                    return False
                cur = conn.cursor()
                for rec in records:
                    keys = {rec["barkod"], rec["raw_barkod"], rec.get("name_key", ""), rec.get("offer_key", "")}
                    bc_val = rec.get("barkod", "")
                    if len(bc_val) == 14 and bc_val.startswith("0"):
                        keys.add(bc_val[1:])
                    elif len(bc_val) == 13 and bc_val.isdigit():
                        keys.add("0" + bc_val)
                    if rec.get("cart_key") and rec.get("durum") in ("SEPETTE", "SIPARIS_VERILDI"):
                        keys.add(rec["cart_key"])
                    if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and rec.get("urun_adi"):
                        cur.execute(
                            "DELETE FROM EdaGunlukSiparis WHERE UPPER(Depo) = 'YOK_LISTESI' AND UPPER(UrunAdi) = ?",
                            (rec["urun_adi"].strip().upper(),)
                        )
                    for b_key in [k[:32] for k in keys if k]:
                        is_cart_key = b_key.startswith("CART:")
                        if rec["durum"] in ("SIPARIS_VERILDI", "SEPETTE") and not is_cart_key:
                            cur.execute(
                                "DELETE FROM EdaGunlukSiparis WHERE UPPER(Depo) = 'YOK_LISTESI' AND Barkod = ?",
                                (b_key,)
                            )
                        cur.execute("""
                            SELECT Durum, Depo FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?
                        """, (rec["tarih"], b_key))
                        row = cur.fetchone()
                        if row:
                            if not is_cart_key and rec["durum"] == "SIPARIS_VERILDI":
                                ex_durum = str(row[0] or "").upper()
                                ex_depo = str(row[1] or "").strip().upper()
                                if ex_durum == "SEPETTE" and ex_depo and ex_depo != rec["depo"]:
                                    continue
                            cur.execute("""
                                UPDATE EdaGunlukSiparis
                                SET UrunAdi = ?, Durum = ?, Depo = ?, Miktar = ?,
                                    MasaAdi = ?, Saat = ?, GuncellemeZamani = GETDATE()
                                WHERE Tarih = ? AND Barkod = ?
                            """, (
                                rec["urun_adi"], rec["durum"], rec["depo"], rec["miktar"],
                                rec["masa_adi"], rec["saat"], rec["tarih"], b_key
                            ))
                        else:
                            cur.execute("""
                                INSERT INTO EdaGunlukSiparis
                                (Tarih, Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat, GuncellemeZamani)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, GETDATE())
                            """, (
                                rec["tarih"], b_key, rec["urun_adi"], rec["durum"],
                                rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"]
                            ))
                conn.commit()
                return True
        except Exception as e:
            print(f"[OrderTracker] Eczanem merkezi sipariş kayıt uyarısı: {e}")
            return False

    def record_joined_offer(
        self,
        depo: str,
        offer_id: str,
        barkod: str,
        urun_adi: str,
        miktar: int = 1,
        offer_meta: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        EczaneTakas veya Eczatrend üzerinden katılınan ortak alım / takas teklifini
        hem günlük ortak sipariş takibine (daily_orders + merkezi SQL) hem de
        daily_joined_offers tablosuna kalıcı olarak kaydeder.
        """
        tarih = self._today_str()
        saat = self._now_time_str()
        masa = (self.hostname or "Eczane-PC").strip()[:120]
        clean_depo = str(depo or "ECZANETAKAS").strip().upper()
        clean_oid = str(offer_id or "").strip()
        prefix = "ET_" if clean_depo == "ECZANETAKAS" else "ETR_"
        offer_key = f"{prefix}{clean_oid[:24]}"
        norm_bc = self._normalize_barcode(barkod, urun_adi)
        clean_name = str(urun_adi or "").strip() or f"{clean_depo} #{clean_oid[:8]}"
        qty = max(1, int(miktar or 1))
        meta = offer_meta or {}

        total_qty = qty
        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    s_cur.execute(
                        "SELECT miktar FROM daily_joined_offers WHERE tarih = ? AND offer_key = ?",
                        (tarih, offer_key)
                    )
                    row = s_cur.fetchone()
                    if row and row[0]:
                        total_qty = int(row[0]) + qty

                    s_cur.execute("""
                        INSERT OR REPLACE INTO daily_joined_offers (
                            tarih, offer_key, depo, offer_id, barkod, urun_adi, miktar,
                            fiyat_kdvli, fiyat_kdvsiz, depo_fiyati, mf, satici, group_name,
                            miad, katil_url, not_metni, masa_adi, saat, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, strftime('%s','now'))
                    """, (
                        tarih,
                        offer_key,
                        clean_depo,
                        clean_oid,
                        norm_bc,
                        clean_name[:250],
                        total_qty,
                        float(meta.get("fiyat_kdvli") or meta.get("satis_fiyati") or meta.get("fiyat") or 0.0),
                        float(meta.get("fiyat_kdvsiz") or 0.0),
                        float(meta.get("depo_fiyati") or meta.get("depocu_fiyat") or 0.0),
                        str(meta.get("mf") or "YOK")[:64],
                        str(meta.get("satici") or meta.get("ekleyen") or "")[:120],
                        str(meta.get("groupName") or meta.get("group_name") or "")[:120],
                        str(meta.get("miad") or meta.get("kalan_sure") or "")[:64],
                        str(meta.get("katil_url") or "")[:255],
                        str(meta.get("not") or meta.get("not_metni") or "")[:255],
                        masa,
                        saat
                    ))
                    s_conn.commit()
            except Exception as e:
                print(f"[OrderTracker] daily_joined_offers yazma uyarısı: {e}")

        self.mark_items(
            items=[{
                "barkod": norm_bc or offer_key,
                "offer_key": offer_key,
                "urun_adi": clean_name,
                "miktar": total_qty,
                "depo": clean_depo
            }],
            durum="SIPARIS_VERILDI",
            default_depo=clean_depo,
            masa_adi=masa
        )

        return {
            "offer_key": offer_key,
            "offer_id": clean_oid,
            "barkod": norm_bc,
            "urun_adi": clean_name,
            "depo": clean_depo,
            "durum": "SIPARIS_VERILDI",
            "miktar": total_qty,
            "masa_adi": masa,
            "saat": saat
        }

    def get_today_joined_offers(self, depo: str = "") -> Dict[str, Dict[str, Any]]:
        """
        Bugün EczaneTakas veya Eczatrend üzerinden katılınan teklifleri
        {offer_key: {...}} sözlüğü olarak döndürür.
        """
        tarih = self._today_str()
        clean_depo = str(depo or "").strip().upper()
        result: Dict[str, Dict[str, Any]] = {}
        try:
            with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                s_cur = s_conn.cursor()
                if clean_depo:
                    s_cur.execute("""
                        SELECT offer_key, depo, offer_id, barkod, urun_adi, miktar,
                               fiyat_kdvli, fiyat_kdvsiz, depo_fiyati, mf, satici, group_name,
                               miad, katil_url, not_metni, masa_adi, saat
                        FROM daily_joined_offers
                        WHERE tarih = ? AND UPPER(depo) = ?
                        ORDER BY updated_at DESC
                    """, (tarih, clean_depo))
                else:
                    s_cur.execute("""
                        SELECT offer_key, depo, offer_id, barkod, urun_adi, miktar,
                               fiyat_kdvli, fiyat_kdvsiz, depo_fiyati, mf, satici, group_name,
                               miad, katil_url, not_metni, masa_adi, saat
                        FROM daily_joined_offers
                        WHERE tarih = ?
                        ORDER BY updated_at DESC
                    """, (tarih,))
                for r in s_cur.fetchall():
                    okey = str(r[0] or "").strip()
                    if not okey:
                        continue
                    result[okey] = {
                        "offer_key": okey,
                        "depo": str(r[1] or ""),
                        "offer_id": str(r[2] or ""),
                        "barkod": str(r[3] or ""),
                        "urun_adi": str(r[4] or ""),
                        "miktar": int(r[5] or 1),
                        "fiyat_kdvli": float(r[6] or 0.0),
                        "fiyat_kdvsiz": float(r[7] or 0.0),
                        "depo_fiyati": float(r[8] or 0.0),
                        "mf": str(r[9] or "YOK"),
                        "satici": str(r[10] or ""),
                        "group_name": str(r[11] or ""),
                        "miad": str(r[12] or ""),
                        "katil_url": str(r[13] or ""),
                        "not_metni": str(r[14] or ""),
                        "masa_adi": str(r[15] or ""),
                        "saat": str(r[16] or ""),
                        "durum": "SIPARIS_VERILDI"
                    }
        except Exception as e:
            print(f"[OrderTracker] daily_joined_offers okuma uyarısı: {e}")
        return result

    def unmark_item(self, barcode: str, urun_adi: str = "", clear_takas_7d: bool = False, depo: str = "") -> bool:
        """Ürünün 'Sipariş Verildi / Sepette / Verilmeyecek' işaretini tüm bilgisayarlar için kaldırır."""
        tarih = self._today_str()
        cutoff_7d = (datetime.date.today() - datetime.timedelta(days=8)).strftime("%Y-%m-%d")
        bc = self._normalize_barcode(barcode, urun_adi)
        clean_name = str(urun_adi or "").strip().upper()
        raw_depo = str(depo or "").strip().upper()
        clean_depo = re.sub(r"[^A-Z0-9_]", "", raw_depo)[:10]
        keys = {str(barcode or "").strip(), bc}
        if bc:
            try:
                from backend.catalog import catalog
                for rel_b in catalog.get_all_related_barcodes(bc):
                    if rel_b and len(rel_b) <= 32:
                        keys.add(rel_b)
            except Exception:
                pass
        if clean_name:
            keys.add(clean_name[:30])
            keys.add(f"NAME:{clean_name[:26]}")
        for k_cand in list(keys):
            if len(k_cand) == 14 and k_cand.startswith("0"):
                keys.add(k_cand[1:])
            elif len(k_cand) == 13 and k_cand.isdigit():
                keys.add("0" + k_cand)
        base_keys = {k for k in keys if k}
        if clean_name:
            nm_tok = re.sub(r"[^A-Z0-9]", "", clean_name)[:16]
            if nm_tok:
                base_keys.add(nm_tok)
        if clean_depo:
            for bk in list(base_keys):
                if not bk.startswith("CART:"):
                    keys.add(f"CART:{clean_depo}:{bk}"[:32])
        else:
            for d_code in ("ALLIANCE", "SELCUK", "ISKOOP", "NEVZAT", "BEK", "DNA", "MANUEL", "TOPLU"):
                for bk in list(base_keys):
                    if not bk.startswith("CART:"):
                        keys.add(f"CART:{d_code}:{bk}"[:32])
        keys = {k for k in keys if k}
        if not keys and not clean_name:
            return False

        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    date_op = ">=" if clear_takas_7d else "="
                    date_val = cutoff_7d if clear_takas_7d else tarih
                    if raw_depo:
                        for k in keys:
                            s_cur.execute("DELETE FROM daily_orders WHERE tarih = ? AND barkod = ? AND UPPER(depo) = ?", (tarih, k, raw_depo))
                        if clean_name:
                            s_cur.execute("DELETE FROM daily_orders WHERE tarih = ? AND UPPER(urun_adi) = ? AND UPPER(depo) = ?", (tarih, clean_name, raw_depo))
                    else:
                        # Ayrıca bu ürüne ait joined_offers anahtarlarını da bulup keys setine ekle
                        for k in list(keys):
                            s_cur.execute(f"SELECT offer_key FROM daily_joined_offers WHERE tarih {date_op} ? AND (barkod = ? OR offer_key = ? OR offer_id = ?)", (date_val, k, k, k))
                            for r_ok in s_cur.fetchall():
                                if r_ok and r_ok[0]:
                                    keys.add(str(r_ok[0]))
                        if clean_name:
                            s_cur.execute(f"SELECT offer_key FROM daily_joined_offers WHERE tarih {date_op} ? AND UPPER(urun_adi) = ?", (date_val, clean_name))
                            for r_ok in s_cur.fetchall():
                                if r_ok and r_ok[0]:
                                    keys.add(str(r_ok[0]))
                        for k in keys:
                            s_cur.execute("DELETE FROM daily_orders WHERE tarih = ? AND barkod = ?", (tarih, k))
                            s_cur.execute("DELETE FROM daily_orders WHERE UPPER(depo) = 'YOK_LISTESI' AND barkod = ?", (k,))
                            if clear_takas_7d:
                                s_cur.execute("DELETE FROM daily_orders WHERE tarih >= ? AND barkod = ? AND UPPER(depo) IN ('ECZANETAKAS', 'ECZATREND')", (cutoff_7d, k))
                            s_cur.execute(f"DELETE FROM daily_joined_offers WHERE tarih {date_op} ? AND (barkod = ? OR offer_key = ? OR offer_id = ?)", (date_val, k, k, k))
                        if clean_name:
                            s_cur.execute("DELETE FROM daily_orders WHERE tarih = ? AND UPPER(urun_adi) = ?", (tarih, clean_name))
                            s_cur.execute("DELETE FROM daily_orders WHERE UPPER(depo) = 'YOK_LISTESI' AND UPPER(urun_adi) = ?", (clean_name,))
                            if clear_takas_7d:
                                s_cur.execute("DELETE FROM daily_orders WHERE tarih >= ? AND UPPER(urun_adi) = ? AND UPPER(depo) IN ('ECZANETAKAS', 'ECZATREND')", (cutoff_7d, clean_name))
                            s_cur.execute(f"DELETE FROM daily_joined_offers WHERE tarih {date_op} ? AND UPPER(urun_adi) = ?", (date_val, clean_name))
                    s_conn.commit()
            except Exception:
                pass

        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        if raw_depo:
                            for k in keys:
                                cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND BARKOD = :b AND UPPER(DEPO) = :d", {"t": tarih, "b": k, "d": raw_depo})
                            if clean_name:
                                cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND UPPER(URUN_ADI) = :u AND UPPER(DEPO) = :d", {"t": tarih, "u": clean_name, "d": raw_depo})
                        else:
                            for k in keys:
                                cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND BARKOD = :b", {"t": tarih, "b": k})
                                cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE UPPER(DEPO) = 'YOK_LISTESI' AND BARKOD = :b", {"b": k})
                                if clear_takas_7d:
                                    cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH >= :c AND BARKOD = :b AND UPPER(DEPO) IN ('ECZANETAKAS', 'ECZATREND')", {"c": cutoff_7d, "b": k})
                            if clean_name:
                                cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND UPPER(URUN_ADI) = :u", {"t": tarih, "u": clean_name})
                                cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE UPPER(DEPO) = 'YOK_LISTESI' AND UPPER(URUN_ADI) = :u", {"u": clean_name})
                                if clear_takas_7d:
                                    cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH >= :c AND UPPER(URUN_ADI) = :u AND UPPER(DEPO) IN ('ECZANETAKAS', 'ECZATREND')", {"c": cutoff_7d, "u": clean_name})
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Tria silme uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        if raw_depo:
                            for k in keys:
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ? AND UPPER(Depo) = ?", (tarih, k, raw_depo))
                            if clean_name:
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(UrunAdi) = ? AND UPPER(Depo) = ?", (tarih, clean_name, raw_depo))
                        else:
                            for k in keys:
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?", (tarih, k))
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE UPPER(Depo) = 'YOK_LISTESI' AND Barkod = ?", (k,))
                                if clear_takas_7d:
                                    cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih >= ? AND Barkod = ? AND UPPER(Depo) IN ('ECZANETAKAS', 'ECZATREND')", (cutoff_7d, k))
                            if clean_name:
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(UrunAdi) = ?", (tarih, clean_name))
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE UPPER(Depo) = 'YOK_LISTESI' AND UPPER(UrunAdi) = ?", (clean_name,))
                                if clear_takas_7d:
                                    cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih >= ? AND UPPER(UrunAdi) = ? AND UPPER(Depo) IN ('ECZANETAKAS', 'ECZATREND')", (cutoff_7d, clean_name))
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Botanik silme uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        t_lit = _sql_lit(tarih)
                        c_lit = _sql_lit(cutoff_7d)
                        if raw_depo:
                            d_lit = _sql_lit(raw_depo)
                            for k in keys:
                                conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND barkod = {_sql_lit(k)} AND UPPER(depo) = {d_lit}")
                            if clean_name:
                                conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND UPPER(urun_adi) = {_sql_lit(clean_name)} AND UPPER(depo) = {d_lit}")
                        else:
                            for k in keys:
                                conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND barkod = {_sql_lit(k)}")
                                conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE UPPER(depo) = 'YOK_LISTESI' AND barkod = {_sql_lit(k)}")
                                if clear_takas_7d:
                                    conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih >= {c_lit} AND barkod = {_sql_lit(k)} AND UPPER(depo) IN ('ECZANETAKAS', 'ECZATREND')")
                            if clean_name:
                                conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND UPPER(urun_adi) = {_sql_lit(clean_name)}")
                                conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE UPPER(depo) = 'YOK_LISTESI' AND UPPER(urun_adi) = {_sql_lit(clean_name)}")
                                if clear_takas_7d:
                                    conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih >= {c_lit} AND UPPER(urun_adi) = {_sql_lit(clean_name)} AND UPPER(depo) IN ('ECZANETAKAS', 'ECZATREND')")
            except Exception as e:
                print(f"[OrderTracker] TEBEOS silme uyarısı: {e}")
        elif active_oto == "ECZANEM":
            try:
                from backend.eczanem_client import eczanem_client
                with eczanem_client.get_connection() as conn:
                    if self._ensure_eczanem_table(conn):
                        cur = conn.cursor()
                        if raw_depo:
                            for k in keys:
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ? AND UPPER(Depo) = ?", (tarih, k, raw_depo))
                            if clean_name:
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(UrunAdi) = ? AND UPPER(Depo) = ?", (tarih, clean_name, raw_depo))
                        else:
                            for k in keys:
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?", (tarih, k))
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE UPPER(Depo) = 'YOK_LISTESI' AND Barkod = ?", (k,))
                                if clear_takas_7d:
                                    cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih >= ? AND Barkod = ? AND UPPER(Depo) IN ('ECZANETAKAS', 'ECZATREND')", (cutoff_7d, k))
                            if clean_name:
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(UrunAdi) = ?", (tarih, clean_name))
                                cur.execute("DELETE FROM EdaGunlukSiparis WHERE UPPER(Depo) = 'YOK_LISTESI' AND UPPER(UrunAdi) = ?", (clean_name,))
                                if clear_takas_7d:
                                    cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih >= ? AND UPPER(UrunAdi) = ? AND UPPER(Depo) IN ('ECZANETAKAS', 'ECZATREND')", (cutoff_7d, clean_name))
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Eczanem silme uyarısı: {e}")
        self._recent_takas_cache = {"ts": 0.0, "data": {}}
        return True

    def clear_cart_items_for_depo(self, depo: str) -> bool:
        """İlgili deponun sepeti boşaltıldığında ('SEPETTE' durumundaki) kayıtları tüm bilgisayarlar için temizler."""
        tarih = self._today_str()
        clean_depo = str(depo or "").strip().upper()
        if not clean_depo:
            return False

        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    s_cur.execute(
                        "DELETE FROM daily_orders WHERE tarih = ? AND UPPER(depo) = ? AND durum = 'SEPETTE'",
                        (tarih, clean_depo)
                    )
                    s_conn.commit()
            except Exception:
                pass

        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND UPPER(DEPO) = :d AND DURUM = 'SEPETTE'",
                            {"t": tarih, "d": clean_depo}
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Tria sepet temizleme uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(Depo) = ? AND Durum = 'SEPETTE'",
                            (tarih, clean_depo)
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Botanik sepet temizleme uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        t_lit = _sql_lit(tarih)
                        d_lit = _sql_lit(clean_depo)
                        conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND UPPER(depo) = {d_lit} AND durum = 'SEPETTE'")
            except Exception as e:
                print(f"[OrderTracker] TEBEOS sepet temizleme uyarısı: {e}")
        elif active_oto == "ECZANEM":
            try:
                from backend.eczanem_client import eczanem_client
                with eczanem_client.get_connection() as conn:
                    if self._ensure_eczanem_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(Depo) = ? AND Durum = 'SEPETTE'",
                            (tarih, clean_depo)
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Eczanem sepet temizleme uyarısı: {e}")
        return True

    def promote_cart_items_to_ordered_for_depo(self, depo: str) -> int:
        """
        İlgili deponun sepetindeki ('SEPETTE' durumundaki) tüm kayıtları yerinde 'SIPARIS_VERILDI' olarak günceller.
        Böylece barkod veya ürün kodu farklılığı olsa dahi o depoya ait hiçbir ürün 'SEPETTE' olarak asılı kalmaz.
        """
        tarih = self._today_str()
        saat = self._now_time_str()
        clean_depo = str(depo or "").strip().upper()
        if not clean_depo:
            return 0

        updated_count = 0
        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    s_cur.execute(
                        "UPDATE daily_orders SET durum = 'SIPARIS_VERILDI', saat = ?, updated_at = strftime('%s','now') WHERE tarih = ? AND UPPER(depo) = ? AND durum = 'SEPETTE'",
                        (saat, tarih, clean_depo)
                    )
                    updated_count = s_cur.rowcount or 0
                    s_conn.commit()
            except Exception as e:
                print(f"[OrderTracker] SQLite sepet->sipariş terfi uyarısı: {e}")

        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "UPDATE TBL_EDA_GUNLUK_SIPARIS SET DURUM = 'SIPARIS_VERILDI', SAAT = :s, GUNCELLEME_ZAMANI = SYSDATE WHERE TARIH = :t AND UPPER(DEPO) = :d AND DURUM = 'SEPETTE'",
                            {"s": saat, "t": tarih, "d": clean_depo}
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Tria sepet->sipariş terfi uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "UPDATE EdaGunlukSiparis SET Durum = 'SIPARIS_VERILDI', Saat = ?, GuncellemeZamani = GETDATE() WHERE Tarih = ? AND UPPER(Depo) = ? AND Durum = 'SEPETTE'",
                            (saat, tarih, clean_depo)
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Botanik sepet->sipariş terfi uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        t_lit = _sql_lit(tarih)
                        d_lit = _sql_lit(clean_depo)
                        s_lit = _sql_lit(saat)
                        conn.query(
                            f"UPDATE public.eda_gunluk_siparis SET durum = 'SIPARIS_VERILDI', saat = {s_lit}, guncelleme_zamani = CURRENT_TIMESTAMP WHERE tarih = {t_lit} AND UPPER(depo) = {d_lit} AND durum = 'SEPETTE'"
                        )
            except Exception as e:
                print(f"[OrderTracker] TEBEOS sepet->sipariş terfi uyarısı: {e}")
        elif active_oto == "ECZANEM":
            try:
                from backend.eczanem_client import eczanem_client
                with eczanem_client.get_connection() as conn:
                    if self._ensure_eczanem_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "UPDATE EdaGunlukSiparis SET Durum = 'SIPARIS_VERILDI', Saat = ?, GuncellemeZamani = GETDATE() WHERE Tarih = ? AND UPPER(Depo) = ? AND Durum = 'SEPETTE'",
                            (saat, tarih, clean_depo)
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Eczanem sepet->sipariş terfi uyarısı: {e}")

        return updated_count

    def get_today_orders_map(self) -> Dict[str, Dict[str, Any]]:
        """
        Bugün sipariş verilen veya sepete eklenen tüm ürünleri {barkod: {...}} sözlüğü olarak döner.
        Merkezi veritabanından (Tria / Botanik / TEBEOS) okur, böylece tüm bilgisayarlar aynı ekranı görür.
        """
        tarih = self._today_str()
        result: Dict[str, Dict[str, Any]] = {}
        status_priority = {
            "SIPARIS_VERILDI": 3,
            "SIPARIS_VERILMEYECEK": 2,
            "SEPETTE": 1
        }

        def _set_with_priority(k: str, entry: Dict[str, Any]):
            if not k:
                return
            existing = result.get(k)
            if not existing:
                result[k] = dict(entry)
                return
            new_durum = str(entry.get("durum") or "")
            old_durum = str(existing.get("durum") or "")
            if new_durum == "SEPETTE" and old_durum == "SEPETTE" and not k.startswith("CART:"):
                old_depo = str(existing.get("depo") or "").strip().upper()
                new_depo = str(entry.get("depo") or "").strip().upper()
                old_parts = [p.strip() for p in old_depo.split("+") if p.strip()]
                if new_depo and new_depo not in old_parts:
                    merged = dict(existing)
                    merged["depo"] = " + ".join(old_parts + [new_depo]) if old_parts else new_depo
                    merged["miktar"] = int(existing.get("miktar") or 0) + int(entry.get("miktar") or 0)
                    if str(entry.get("saat") or "") >= str(existing.get("saat") or ""):
                        merged["saat"] = entry.get("saat") or existing.get("saat")
                        merged["masa_adi"] = entry.get("masa_adi") or existing.get("masa_adi")
                    result[k] = merged
                    return
            if new_durum == "SEPETTE" and old_durum == "SIPARIS_VERILDI":
                if str(entry.get("saat") or "") >= str(existing.get("saat") or ""):
                    result[k] = dict(entry)
                return
            if new_durum == "SIPARIS_VERILDI" and old_durum == "SEPETTE":
                if str(existing.get("saat") or "") > str(entry.get("saat") or ""):
                    return
                result[k] = dict(entry)
                return
            new_prio = status_priority.get(new_durum, 0)
            old_prio = status_priority.get(old_durum, 0)
            if new_prio >= old_prio:
                result[k] = dict(entry)

        def _put_entry(bc_key: str, u_name: str, entry: Dict[str, Any]):
            clean_nm = u_name.strip().upper() if u_name else ""
            is_cart_key = bc_key.startswith("CART:")
            real_bc_key = bc_key
            cart_depo = ""
            if is_cart_key:
                parts = bc_key.split(":", 2)
                if len(parts) == 3:
                    cart_depo = parts[1].strip().upper()
                    real_bc_key = parts[2].strip()
                else:
                    real_bc_key = ""
            raw_b = str(entry.get("barkod") or real_bc_key or "").strip()
            if raw_b.startswith("CART:"):
                c_parts = raw_b.split(":", 2)
                raw_b = c_parts[2].strip() if len(c_parts) == 3 else ""
            if raw_b.startswith(("NAME:", "ET_", "ETR_")) or (raw_b and not raw_b.isdigit()):
                canon_b = ""
            elif len(raw_b) == 14 and raw_b.startswith("0"):
                canon_b = raw_b[1:]
            else:
                canon_b = raw_b
            if canon_b and canon_b.isdigit():
                try:
                    from backend.catalog import catalog
                    resolved_b = catalog.resolve_canonical_barcode(canon_b)
                    if resolved_b and resolved_b.isdigit():
                        canon_b = resolved_b
                except Exception:
                    pass
            if clean_nm and clean_nm in result:
                prev_b = str(result[clean_nm].get("barkod") or "").strip()
                if len(prev_b) == 14 and prev_b.startswith("0"):
                    prev_b = prev_b[1:]
                if prev_b and prev_b.isdigit():
                    canon_b = prev_b
            entry = dict(entry)
            if canon_b and canon_b.isdigit():
                entry["barkod"] = canon_b
            elif is_cart_key:
                entry["barkod"] = real_bc_key if real_bc_key.isdigit() else ""
            if cart_depo and not entry.get("depo"):
                entry["depo"] = cart_depo

            if is_cart_key:
                result[bc_key] = dict(entry)
                if canon_b and canon_b.isdigit():
                    norm_cart_key = f"CART:{str(entry.get('depo') or cart_depo).strip().upper()[:10]}:{canon_b}"[:32]
                    result[norm_cart_key] = dict(entry)

            if real_bc_key and not real_bc_key.startswith("CART:"):
                if real_bc_key.isdigit() or real_bc_key.startswith(("NAME:", "ET_", "ETR_")):
                    _set_with_priority(real_bc_key, entry)
                if len(real_bc_key) == 14 and real_bc_key.startswith("0"):
                    _set_with_priority(real_bc_key[1:], entry)
                elif len(real_bc_key) == 13 and real_bc_key.isdigit():
                    _set_with_priority("0" + real_bc_key, entry)
                if real_bc_key.isdigit():
                    try:
                        from backend.catalog import catalog
                        for rel_b in catalog.get_all_related_barcodes(real_bc_key):
                            if rel_b:
                                _set_with_priority(rel_b, entry)
                    except Exception:
                        pass
            if canon_b and canon_b.isdigit():
                _set_with_priority(canon_b, entry)
                if len(canon_b) == 13:
                    _set_with_priority("0" + canon_b, entry)
            if clean_nm:
                _set_with_priority(clean_nm, entry)
                _set_with_priority(f"NAME:{clean_nm[:26]}", entry)

        cutoff_yok = (datetime.date.today() - datetime.timedelta(days=45)).strftime("%Y-%m-%d")

        # 1. Önce merkezi veritabanından (Tria Oracle / Botanik MS SQL / TEBEOS PostgreSQL / Eczanem) oku
        # Böylece ağdaki diğer bilgisayarlarda eklenen veya silinen kayıtlar tüm bilgisayarlarda birebir aynı görünür.
        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        central_read_ok = False
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT BARKOD, URUN_ADI, DURUM, DEPO, MIKTAR, MASA_ADI, SAAT
                            FROM TBL_EDA_GUNLUK_SIPARIS
                            WHERE TARIH = :t OR (TARIH >= :cy AND UPPER(DEPO) = 'YOK_LISTESI')
                            ORDER BY TARIH ASC
                        """, {"t": tarih, "cy": cutoff_yok})
                        for r in cur.fetchall():
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            unm = str(r[1] or "")
                            entry = {
                                "barkod": bc,
                                "urun_adi": unm,
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
                            _put_entry(bc, unm, entry)
                        central_read_ok = True
            except Exception as e:
                print(f"[OrderTracker] Tria okuma uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat
                            FROM EdaGunlukSiparis
                            WHERE Tarih = ? OR (Tarih >= ? AND UPPER(Depo) = 'YOK_LISTESI')
                            ORDER BY Tarih ASC
                        """, (tarih, cutoff_yok))
                        for r in cur.fetchall():
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            unm = str(r[1] or "")
                            entry = {
                                "barkod": bc,
                                "urun_adi": unm,
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
                            _put_entry(bc, unm, entry)
                        central_read_ok = True
            except Exception as e:
                print(f"[OrderTracker] Botanik okuma uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        _, rows = conn.query(f"""
                            SELECT barkod, urun_adi, durum, depo, miktar, masa_adi, saat
                            FROM public.eda_gunluk_siparis
                            WHERE tarih = {_sql_lit(tarih)} OR (tarih >= {_sql_lit(cutoff_yok)} AND UPPER(depo) = 'YOK_LISTESI')
                            ORDER BY tarih ASC
                        """)
                        for r in rows:
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            unm = str(r[1] or "")
                            entry = {
                                "barkod": bc,
                                "urun_adi": unm,
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
                            _put_entry(bc, unm, entry)
                        central_read_ok = True
            except Exception as e:
                print(f"[OrderTracker] TEBEOS okuma uyarısı: {e}")
        elif active_oto == "ECZANEM":
            try:
                from backend.eczanem_client import eczanem_client
                with eczanem_client.get_connection() as conn:
                    if self._ensure_eczanem_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat
                            FROM EdaGunlukSiparis WITH (NOLOCK)
                            WHERE Tarih = ? OR (Tarih >= ? AND UPPER(Depo) = 'YOK_LISTESI')
                            ORDER BY Tarih ASC
                        """, (tarih, cutoff_yok))
                        for r in cur.fetchall():
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            unm = str(r[1] or "")
                            entry = {
                                "barkod": bc,
                                "urun_adi": unm,
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
                            _put_entry(bc, unm, entry)
                        central_read_ok = True
            except Exception as e:
                print(f"[OrderTracker] Eczanem okuma uyarısı: {e}")

        self.last_central_read_ok = central_read_ok

        # 2. Merkezi veritabanı kapalıysa veya ulaşılamadıysa yerel SQLite yedeğinden oku
        if not central_read_ok:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    s_cur.execute("""
                        SELECT barkod, urun_adi, durum, depo, miktar, masa_adi, saat
                        FROM daily_orders
                        WHERE tarih = ? OR (tarih >= ? AND UPPER(depo) = 'YOK_LISTESI')
                        ORDER BY tarih ASC
                    """, (tarih, cutoff_yok))
                    for r in s_cur.fetchall():
                        bc = str(r[0] or "").strip()
                        unm = str(r[1] or "")
                        entry = {
                            "barkod": bc,
                            "urun_adi": unm,
                            "durum": str(r[2] or "SIPARIS_VERILDI"),
                            "depo": str(r[3] or "DEPO"),
                            "miktar": int(r[4] or 1),
                            "masa_adi": str(r[5] or ""),
                            "saat": str(r[6] or "")
                        }
                        _put_entry(bc, unm, entry)
            except Exception:
                pass

        return result

    def get_recent_takas_orders_map(self, days: int = 7) -> Dict[str, Dict[str, Any]]:
        """
        Son N gün (varsayılan 7 gün) içinde ECZATREND veya ECZANETAKAS üzerinden
        katılınan/sipariş verilen ve henüz kargo/takas sürecinde olabilecek ürünleri
        {barkod_veya_isim: {...}} sözlüğü olarak döndürür.
        """
        now_ts = time.time()
        if (now_ts - float(self._recent_takas_cache.get("ts") or 0.0)) < 4.0 and self._recent_takas_cache.get("data"):
            return self._recent_takas_cache["data"]

        today_dt = datetime.date.today()
        cutoff_dt = today_dt - datetime.timedelta(days=max(1, int(days or 7)))
        cutoff_str = cutoff_dt.strftime("%Y-%m-%d")
        result: Dict[str, Dict[str, Any]] = {}

        def _parse_days_ago(t_str: str) -> int:
            try:
                dt = datetime.date.fromisoformat(str(t_str or "").strip()[:10])
                return max(0, (today_dt - dt).days)
            except Exception:
                return 0

        def _put_takas_entry(r_tarih: str, r_depo: str, r_bc: str, r_name: str, r_qty: int, r_masa: str, r_saat: str):
            depo_up = str(r_depo or "").strip().upper()
            if depo_up not in ("ECZANETAKAS", "ECZATREND"):
                return
            kac_gun = _parse_days_ago(r_tarih)
            if kac_gun > days:
                return
            kalan_gun = max(1, days - kac_gun)
            if kac_gun == 0:
                gun_etiketi = "Bugün katıldı"
            elif kac_gun == 1:
                gun_etiketi = "Dün katıldı (1 gün önce)"
            else:
                gun_etiketi = f"{kac_gun} gün önce katıldı"

            depo_etiket = "Eczatrend" if depo_up == "ECZATREND" else "EczaneTakas"
            clean_nm = str(r_name or "").strip().upper()
            raw_b = str(r_bc or "").strip()
            if raw_b.startswith(("NAME:", "ET_", "ETR_")):
                canon_b = ""
            elif len(raw_b) == 14 and raw_b.startswith("0"):
                canon_b = raw_b[1:]
            else:
                canon_b = raw_b

            if canon_b and canon_b.isdigit():
                try:
                    from backend.catalog import catalog
                    resolved_b = catalog.resolve_canonical_barcode(canon_b)
                    if resolved_b and resolved_b.isdigit():
                        canon_b = resolved_b
                except Exception:
                    pass

            entry = {
                "depo": depo_up,
                "depo_etiket": depo_etiket,
                "barkod": canon_b or raw_b,
                "urun_adi": str(r_name or "").strip(),
                "miktar": max(1, int(r_qty or 1)),
                "tarih": str(r_tarih or ""),
                "saat": str(r_saat or ""),
                "masa_adi": str(r_masa or ""),
                "kac_gun_once": kac_gun,
                "kalan_gun": kalan_gun,
                "gun_etiketi": gun_etiketi,
            }

            keys_to_set = set()
            if raw_b and not raw_b.startswith(("ET_", "ETR_")):
                keys_to_set.add(raw_b)
                if len(raw_b) == 14 and raw_b.startswith("0"):
                    keys_to_set.add(raw_b[1:])
                elif len(raw_b) == 13 and raw_b.isdigit():
                    keys_to_set.add("0" + raw_b)
                try:
                    from backend.catalog import catalog
                    for rel_b in catalog.get_all_related_barcodes(raw_b):
                        if rel_b:
                            keys_to_set.add(rel_b)
                except Exception:
                    pass
            if canon_b and canon_b.isdigit():
                keys_to_set.add(canon_b)
                if len(canon_b) == 13:
                    keys_to_set.add("0" + canon_b)
            if clean_nm:
                keys_to_set.add(clean_nm)
                keys_to_set.add(f"NAME:{clean_nm[:26]}")

            for k in keys_to_set:
                if not k:
                    continue
                existing = result.get(k)
                # Daha güncel (kac_gun_once daha küçük) olan kaydı tercih et
                if not existing or entry["kac_gun_once"] <= existing.get("kac_gun_once", 99):
                    result[k] = entry

        # 1. Yerel SQLite (daily_joined_offers ve daily_orders)
        try:
            with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                s_cur = s_conn.cursor()
                s_cur.execute("""
                    SELECT tarih, depo, barkod, urun_adi, miktar, masa_adi, saat
                    FROM daily_joined_offers
                    WHERE tarih >= ? AND UPPER(depo) IN ('ECZANETAKAS', 'ECZATREND')
                    ORDER BY tarih ASC, updated_at ASC
                """, (cutoff_str,))
                for r in s_cur.fetchall():
                    _put_takas_entry(r[0], r[1], r[2], r[3], r[4], r[5], r[6])

                s_cur.execute("""
                    SELECT tarih, depo, barkod, urun_adi, miktar, masa_adi, saat
                    FROM daily_orders
                    WHERE tarih >= ? AND UPPER(depo) IN ('ECZANETAKAS', 'ECZATREND') AND durum = 'SIPARIS_VERILDI'
                    ORDER BY tarih ASC, updated_at ASC
                """, (cutoff_str,))
                for r in s_cur.fetchall():
                    _put_takas_entry(r[0], r[1], r[2], r[3], r[4], r[5], r[6])
        except Exception:
            pass

        # 2. Merkezi SQL (Tria / Botanik / Tebeos / Eczanem)
        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT TARIH, DEPO, BARKOD, URUN_ADI, MIKTAR, MASA_ADI, SAAT
                            FROM TBL_EDA_GUNLUK_SIPARIS
                            WHERE TARIH >= :c AND UPPER(DEPO) IN ('ECZANETAKAS', 'ECZATREND') AND DURUM = 'SIPARIS_VERILDI'
                        """, {"c": cutoff_str})
                        for r in cur.fetchall():
                            _put_takas_entry(r[0], r[1], r[2], r[3], r[4], r[5], r[6])
            except Exception:
                pass
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT Tarih, Depo, Barkod, UrunAdi, Miktar, MasaAdi, Saat
                            FROM EdaGunlukSiparis
                            WHERE Tarih >= ? AND UPPER(Depo) IN ('ECZANETAKAS', 'ECZATREND') AND Durum = 'SIPARIS_VERILDI'
                        """, (cutoff_str,))
                        for r in cur.fetchall():
                            _put_takas_entry(r[0], r[1], r[2], r[3], r[4], r[5], r[6])
            except Exception:
                pass
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        _, rows = conn.query(f"""
                            SELECT tarih, depo, barkod, urun_adi, miktar, masa_adi, saat
                            FROM public.eda_gunluk_siparis
                            WHERE tarih >= {_sql_lit(cutoff_str)} AND UPPER(depo) IN ('ECZANETAKAS', 'ECZATREND') AND durum = 'SIPARIS_VERILDI'
                        """)
                        for r in rows:
                            _put_takas_entry(r[0], r[1], r[2], r[3], r[4], r[5], r[6])
            except Exception:
                pass
        elif active_oto == "ECZANEM":
            try:
                from backend.eczanem_client import eczanem_client
                with eczanem_client.get_connection() as conn:
                    if self._ensure_eczanem_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT Tarih, Depo, Barkod, UrunAdi, Miktar, MasaAdi, Saat
                            FROM EdaGunlukSiparis WITH (NOLOCK)
                            WHERE Tarih >= ? AND UPPER(Depo) IN ('ECZANETAKAS', 'ECZATREND') AND Durum = 'SIPARIS_VERILDI'
                        """, (cutoff_str,))
                        for r in cur.fetchall():
                            _put_takas_entry(r[0], r[1], r[2], r[3], r[4], r[5], r[6])
            except Exception:
                pass

        self._recent_takas_cache = {"ts": now_ts, "data": result}
        return result


order_tracker = SharedOrderTracker()
