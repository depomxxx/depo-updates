import asyncio
import json
import os
import time
from pathlib import Path
from typing import List, Dict, Optional, Any

from backend.models import DepoKodu

class MFDistributedResolver:
    """
    Kritik stok ve günün çıkışları listesindeki ürünlerin MF (Mal Fazlası) şartlarını
    depolar (Alliance, Selçuk, İSKOOP, Nevzat) arasında bölüştürerek,
    asenkron, paralel ve önbellekli (cache) olarak hızlıca çözen motor.
    """

    def __init__(self, cache_file_path: Optional[str] = None):
        if cache_file_path:
            self.cache_file = Path(cache_file_path)
        else:
            self.cache_file = Path(__file__).resolve().parent.parent / "data" / "mf_cache.json"
        
        self.cache_file.parent.mkdir(parents=True, exist_ok=True)
        self._cache: Dict[str, Dict[str, Any]] = {} # barcode -> {"mf": "10+1", "depo": "Alliance", "time": 1720000000}
        self._ttl_seconds = 43200 # 12 saat önbellek (MF şartları gün içinde nadiren değişir)
        self._lock = asyncio.Lock()
        self._load_cache()

    def _load_cache(self):
        try:
            if self.cache_file.exists():
                with open(self.cache_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    now = time.time()
                    # 12 saatten eski olmayanları sakla
                    self._cache = {
                        k: v for k, v in data.items() 
                        if isinstance(v, dict) and (now - v.get("time", 0)) < self._ttl_seconds
                    }
        except Exception as e:
            print(f"[MFResolver] Önbellek yükleme uyarısı: {e}")
            self._cache = {}

    def _save_cache(self):
        try:
            with open(self.cache_file, "w", encoding="utf-8") as f:
                json.dump(self._cache, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[MFResolver] Önbellek kaydetme uyarısı: {e}")

    @staticmethod
    def is_valid_mf(mf_str: Optional[str]) -> bool:
        if not mf_str:
            return False
        s = str(mf_str).strip().upper()
        if s in ("", "YOK", "-", "0", "NONE", "NULL", "PAZARYERİ", "PAZARYERI"):
            return False
        if "+" in s:
            return True
        return False

    def get_cached_mf(self, barcode: str) -> Optional[Dict[str, Any]]:
        """Önbellekte varsa ve süresi dolmadıysa döndürür. Yoksa None döner."""
        bc = str(barcode).strip()
        if not bc:
            return None
        item = self._cache.get(bc)
        if not item:
            return None
        now = time.time()
        if (now - item.get("time", 0)) < self._ttl_seconds:
            return item
        return None

    def set_cached_mf(self, barcode: str, mf_text: Optional[str], depo_name: Optional[str], fiyat: float = 0.0):
        bc = str(barcode).strip()
        if not bc:
            return
        if self.is_valid_mf(mf_text):
            self._cache[bc] = {
                "mf": str(mf_text).strip(),
                "depo": str(depo_name).strip(),
                "fiyat": round(float(fiyat or 0.0), 2),
                "time": time.time()
            }
        else:
            # MF yok olarak önbelleğe al, böylece gün içinde tekrar tekrar depoya gidip vakit kaybetmeyiz
            self._cache[bc] = {
                "mf": None,
                "depo": None,
                "fiyat": 0.0,
                "time": time.time()
            }

    async def _query_single_depo(self, adapter, barcode: str) -> Optional[Dict[str, Any]]:
        """Tek bir depodan ürünün MF şartını ve birim fiyatını döner."""
        if getattr(adapter, "_cart_busy", 0) > 0 or getattr(adapter, "_search_busy", 0) > 0:
            return None
        try:
            try:
                res_list = await adapter.search_product(barcode, include_equivalents=False, is_background=True)
            except TypeError:
                res_list = await adapter.search_product(barcode)
            if res_list:
                for r in res_list:
                    if self.is_valid_mf(r.mf_metni):
                        unit_p = float(getattr(r, "psf", 0) or getattr(r, "depocu_fiyat", 0) or getattr(r, "net_birim_maliyet_kdvli", 0) or 0.0)
                        return {"mf": r.mf_metni.strip(), "fiyat": round(unit_p, 2)}
        except Exception:
            pass
        return None

    async def resolve_barcode(self, motor, barcode: str, preferred_depo: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Tek bir barkodu önce tercih edilen depoda arar.
        Aktif kullanıcı araması veya sepet işlemi olan depoyu asla meşgul etmez.
        """
        cached = self.get_cached_mf(barcode)
        if cached is not None:
            if cached.get("mf"):
                return {
                    "mf": cached["mf"],
                    "depo": cached.get("depo", "Depo"),
                    "fiyat": float(cached.get("fiyat") or 0.0)
                }
            return None

        if not motor or not motor.adapters:
            return None

        if getattr(motor, "_active_user_searches", 0) > 0:
            return None

        candidate_depos = []
        if preferred_depo:
            p_upper = preferred_depo.upper()
            candidate_depos.append(p_upper)

        for d in ["ISKOOP", "NEVZAT", "ALLIANCE", "SELCUK"]:
            if d not in candidate_depos and any(k.value == d for k in motor.adapters.keys()):
                candidate_depos.append(d)

        found_mf = None
        found_depo = None
        found_fiyat = 0.0
        any_queried = False

        for d_name in candidate_depos[:1]:
            if getattr(motor, "_active_user_searches", 0) > 0:
                return None
            adapter = next((a for k, a in motor.adapters.items() if k.value == d_name), None)
            if not adapter:
                continue
            if getattr(adapter, "_cart_busy", 0) > 0 or getattr(adapter, "_search_busy", 0) > 0:
                continue

            any_queried = True
            mf_res = await self._query_single_depo(adapter, barcode)
            if mf_res and mf_res.get("mf"):
                found_mf = mf_res["mf"]
                found_fiyat = float(mf_res.get("fiyat") or 0.0)
                found_depo = "Alliance" if d_name == "ALLIANCE" else ("Selçuk" if d_name == "SELCUK" else ("İSKOOP" if d_name == "ISKOOP" else "Nevzat"))
                break

        if any_queried and getattr(motor, "_active_user_searches", 0) == 0:
            async with self._lock:
                self.set_cached_mf(barcode, found_mf, found_depo, found_fiyat)
                self._save_cache()

        if found_mf:
            return {"mf": found_mf, "depo": found_depo, "fiyat": found_fiyat}
        return None

    async def resolve_batch(self, motor, barcodes: List[str], max_concurrency: int = 2) -> Dict[str, Optional[Dict[str, str]]]:
        """
        Gelen barkod listesini aktif depolar arasında paylaştırarak kullanıcı aramalarını engellemeden çözer.
        """
        results: Dict[str, Optional[Dict[str, str]]] = {}
        uncached: List[str] = []

        # 1. Önce önbellekte olanları anında al
        for bc in barcodes:
            clean_bc = str(bc).strip()
            if not clean_bc:
                continue
            cached = self.get_cached_mf(clean_bc)
            if cached is not None:
                if cached.get("mf"):
                    results[clean_bc] = {
                        "mf": cached["mf"],
                        "depo": cached.get("depo", "Depo"),
                        "fiyat": float(cached.get("fiyat") or 0.0)
                    }
                else:
                    results[clean_bc] = None
            else:
                uncached.append(clean_bc)

        if not uncached or not motor or not motor.adapters:
            return results

        # 2. Aktif toptancı depoları listele (Tek bir tarayıcıya yüklenmemek için tüm aktif depolar arasında dağıt)
        active_depos = [k.value for k in motor.adapters.keys() if k.value in ("ISKOOP", "NEVZAT", "ALLIANCE", "SELCUK")]
        if not active_depos:
            for b in uncached:
                results[b] = None
            return results

        # 3. Barkodları depolara yuvarlak masa (round-robin) ile paylaştır, eşzamanlılığı sınırla
        effective_concurrency = max(1, min(int(max_concurrency or 2), 2))
        sem = asyncio.Semaphore(effective_concurrency)

        async def _worker(idx: int, bc: str):
            async with sem:
                if getattr(motor, "_active_user_searches", 0) > 0:
                    await asyncio.sleep(0.4)
                pref = active_depos[idx % len(active_depos)]
                res = await self.resolve_barcode(motor, bc, preferred_depo=pref)
                results[bc] = res
                await asyncio.sleep(0.05)

        tasks = [_worker(i, bc) for i, bc in enumerate(uncached)]
        await asyncio.gather(*tasks, return_exceptions=True)

        return results

mf_resolver = MFDistributedResolver()
