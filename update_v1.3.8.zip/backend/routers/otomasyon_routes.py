# -*- coding: utf-8 -*-
"""
backend/routers/otomasyon_routes.py
-----------------------------------
Botanik MS SQL, TRIA Oracle ve TEBEOS PostgreSQL entegrasyon uç noktaları:
- Bağlantı testleri (ping), otomatik sunucu bulma (discover)
- Günün çıkışları & azalan kritik stok listesi
- 6 aylık çıkış & akıllı toplu sipariş planlama listesi
- Paralel MF çözümleyici ve SGK eşdeğer (muadil) kârlılık analizi
"""

import os
import re
import time
import asyncio
from typing import Optional
from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse

import backend.app_state as app_state
from backend.models import DepoKodu
from backend.catalog import catalog
from backend.tria_client import tria_client
from backend.botanik_client import botanik_client
from backend.tebeos_client import tebeos_client
from backend.dermo_sync import audit_botanik_dermo_barcodes, apply_botanik_dermo_barcodes
from backend.mf_resolver import mf_resolver
from backend.order_tracker import order_tracker

router = APIRouter()


@router.get("/api/botanik/ping")
async def botanik_ping_endpoint(
    server: Optional[str] = None,
    database: Optional[str] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    trusted: Optional[bool] = None
):
    """Botanik MS SQL veritabanı bağlantı testi ve ping metrikleri."""
    return await asyncio.to_thread(
        botanik_client.ping,
        server=server,
        database=database,
        user=user,
        password=password,
        trusted=trusted
    )


@router.get("/api/botanik/product")
async def botanik_product_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    """Tekil olarak ilacın Botanik stok, giriş ve aylık hareket analizini döner."""
    return botanik_client.get_product_analysis(q)


@router.get("/api/botanik/read-config")
async def botanik_read_config_endpoint():
    """Botanik config dosyasından (BotanikEczane.exe.config) otomatik bağlantı bilgilerini okur."""
    return botanik_client.read_botanik_config_file()


async def enrich_critical_items_with_orders(items_list: list) -> list:
    """Günün çıkışları listesini tüm bilgisayarlardaki ortak sipariş durumuyla zenginleştirir ve sipariş verilenleri/verilmeyecekleri alta alır."""
    try:
        orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
    except Exception:
        orders_map = {}

    enriched = []
    for raw_it in items_list:
        it = dict(raw_it)
        bc = str(it.get("barkod") or "").strip()
        nm = str(it.get("urun_adi") or "").strip().upper()
        c_mf = mf_resolver.get_cached_mf(bc)
        if c_mf and c_mf.get("mf"):
            it["mf_metni"] = c_mf["mf"]
            it["mf_depo"] = c_mf.get("depo", "Depo")
        else:
            it["mf_metni"] = None
            it["mf_depo"] = None

        ord_info = orders_map.get(bc) or (orders_map.get(bc[1:]) if len(bc) == 14 and bc.startswith("0") else None) or orders_map.get(nm)
        if ord_info:
            it["siparis_durumu"] = ord_info.get("durum")
            it["siparis_depo"] = ord_info.get("depo")
            it["siparis_miktar"] = ord_info.get("miktar")
            it["siparis_masa"] = ord_info.get("masa_adi")
            it["siparis_saat"] = ord_info.get("saat")
        else:
            it["siparis_durumu"] = None
            it["siparis_depo"] = None
            it["siparis_miktar"] = None
            it["siparis_masa"] = None
            it["siparis_saat"] = None
        enriched.append(it)

    # Sipariş verilenler ve bugün sipariş verilmeyecekler listenin altına kaysın, bekleyenler üstte kalsın
    enriched.sort(key=lambda x: (1 if x.get("siparis_durumu") in ("SIPARIS_VERILDI", "SIPARIS_VERILMEYECEK") else 0))
    return enriched


@router.get("/api/otomasyon/smart-order-list")
@router.get("/api/botanik/smart-order-list")
async def botanik_smart_order_list_endpoint(
    scope: str = Query("today", description="today | week | top6m | search"),
    q: str = Query("", description="Arama kelimesi veya barkod"),
    target_days: int = Query(15, description="Hedef stok gün sayısı (örn: 1, 7, 15, 30)"),
    limit: int = Query(250, description="Maksimum ürün sayısı"),
    force: bool = Query(False, description="Önbelleği yoksay ve canlı sorgula")
):
    """
    Aktif Eczane Otomasyonuna (TRIA / BOTANIK / TEBEOS) Göre
    6 Aylık Çıkış & Akıllı Toplu Sipariş Planlama Listesi.
    """
    now = time.time()
    active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
    cache_key = f"{active_oto}_{scope.strip().lower()}_{(q or '').strip().lower()}_{int(target_days)}_{int(limit)}"

    res_data = None
    source_used = active_oto if active_oto in ("TRIA", "BOTANIK", "TEBEOS") else "TRIA"

    if not force and cache_key in app_state.smart_order_list_cache:
        cached_entry = app_state.smart_order_list_cache[cache_key]
        if (now - cached_entry.get("time", 0)) < 90:
            res_data = dict(cached_entry["data"])
            source_used = res_data.get("source") or source_used

    if not res_data:
        if active_oto == "TEBEOS":
            cli_obj = tebeos_client
            source_used = "TEBEOS"
        elif active_oto == "BOTANIK":
            cli_obj = botanik_client
            source_used = "BOTANIK"
        else:
            cli_obj = tria_client
            source_used = "TRIA"

        try:
            cand_res = await asyncio.to_thread(
                cli_obj.get_six_month_smart_order_list,
                scope=scope,
                search_query=q,
                target_days=target_days,
                limit=limit
            )
            if cand_res:
                cand_res["source"] = source_used
                res_data = cand_res
        except Exception as e_cli:
            print(f"[SmartOrder] {source_used} 6 aylık sorgu hatası: {e_cli}")
            res_data = {"success": False, "source": source_used, "items": [], "error": str(e_cli)}

        if res_data and res_data.get("success") and res_data.get("items"):
            app_state.smart_order_list_cache[cache_key] = {"time": now, "data": dict(res_data)}

    raw_items = res_data.get("items", []) if res_data else []
    enriched_items = await enrich_critical_items_with_orders(raw_items)

    stabil_count = sum(1 for it in enriched_items if it.get("trend_kodu") == "STABIL")
    azalan_count = sum(1 for it in enriched_items if it.get("trend_kodu") == "AZALAN")
    artan_count = sum(1 for it in enriched_items if it.get("trend_kodu") == "ARTAN")
    mf_count = sum(1 for it in enriched_items if (it.get("mf_metni") and it.get("mf_metni") != "YOK") or it.get("gecmis_mf_var"))
    ordered_count = sum(1 for it in enriched_items if it.get("siparis_durumu"))

    return {
        "success": bool(res_data and res_data.get("success")),
        "source": source_used,
        "active_otomasyon": active_oto,
        "scope": scope,
        "target_days": target_days,
        "count": len(enriched_items),
        "months": res_data.get("months", []) if res_data else [],
        "stats": {
            "total": len(enriched_items),
            "stabil": stabil_count,
            "azalan": azalan_count,
            "artan": artan_count,
            "mf_olan": mf_count,
            "siparis_verilen": ordered_count,
        },
        "pc_name": order_tracker.pc_name,
        "error": res_data.get("error") if res_data else None,
        "items": enriched_items,
    }


@router.get("/api/otomasyon/critical-stock")
async def otomasyon_critical_stock_endpoint(force: bool = False, limit: int = 0, max_days: int = 21):
    """Bugün eczaneden çıkışı olan ve stoğu kritik/azalan ürünleri döner (limit=0 tüm ürünleri getirir). 21 gün üzeri stokları filtreler."""
    now = time.time()
    active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
    cache = app_state.critical_stock_cache
    if not force and cache.get("data") and cache.get("source") == active_oto and (now - cache.get("time", 0.0) < 120):
        cached_items = cache["data"]
        if max_days > 0:
            filtered_items = [it for it in cached_items if it.get("stok", 0) <= 0 or it.get("stok_gun", 0) <= max_days]
        else:
            filtered_items = cached_items

        res_items = filtered_items[:limit] if (limit and limit > 0) else filtered_items
        res_items = await enrich_critical_items_with_orders(res_items)

        return {
            "success": True,
            "source": cache.get("source", active_oto),
            "cached": True,
            "count": len(res_items),
            "total_count": len(filtered_items),
            "max_days": max_days,
            "pc_name": order_tracker.pc_name,
            "items": res_items
        }

    items = []
    source_used = active_oto
    try:
        if active_oto == "TEBEOS":
            items = await asyncio.to_thread(tebeos_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)
        elif active_oto == "BOTANIK":
            items = await asyncio.to_thread(botanik_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)
        else:
            items = await asyncio.to_thread(tria_client.get_critical_stock_sales, limit=0, max_stock_days=max_days)

        app_state.critical_stock_cache = {"time": now, "data": items, "source": source_used}
    except Exception as e:
        print(f"[Otomasyon] Critical stock endpoint hatası ({active_oto}): {e}")

    if max_days > 0:
        filtered_items = [it for it in items if it.get("stok", 0) <= 0 or it.get("stok_gun", 0) <= max_days]
    else:
        filtered_items = items

    res_items = filtered_items[:limit] if (limit and limit > 0) else filtered_items
    res_items = await enrich_critical_items_with_orders(res_items)

    return {
        "success": True,
        "source": source_used,
        "cached": False,
        "count": len(res_items),
        "total_count": len(filtered_items),
        "max_days": max_days,
        "pc_name": order_tracker.pc_name,
        "items": res_items
    }


@router.post("/api/otomasyon/resolve-mf")
async def resolve_mf_endpoint(request: Request):
    """Günün azalan ürünlerinin MF şartlarını depolar arasında bölüştürerek paralel çözer."""
    motor = app_state.get_motor()
    try:
        data = await request.json()
        barcodes = data.get("barcodes", [])
        if not barcodes:
            return {"success": True, "results": {}}
        results = await mf_resolver.resolve_batch(motor, barcodes[:40], max_concurrency=4)
        return {"success": True, "results": results}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.get("/api/tria/ping")
async def tria_ping_endpoint(
    host: Optional[str] = Query(None),
    port: Optional[str] = Query(None),
    sid: Optional[str] = Query(None),
    user: Optional[str] = Query(None),
    password: Optional[str] = Query(None)
):
    """Tria Oracle veritabanı bağlantı testi ve ping metrikleri."""
    return tria_client.ping(host=host, port=port, sid=sid, user=user, password=password)


@router.get("/api/tria/product")
async def tria_product_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    """Tekil olarak ilacın Tria stok ve aylık hareket analizini döner."""
    return tria_client.get_product_analysis(q)


@router.get("/api/tria/schemas")
async def tria_schemas_endpoint():
    """Oracle veritabanındaki kayıtlı eczane şemalarını listeler (EdaPrim stili)."""
    return tria_client.list_available_schemas()


@router.get("/api/tria/discover")
async def tria_discover_endpoint():
    """Ağda veya yerel ortamda TRIA Oracle sunucusunu otomatik tespit eder (EdaPrim stili)."""
    return tria_client.discover_tria_host()


@router.get("/api/tebeos/ping")
async def tebeos_ping_endpoint(
    host: Optional[str] = Query(None),
    port: Optional[str] = Query(None),
    database: Optional[str] = Query(None),
    user: Optional[str] = Query(None),
    password: Optional[str] = Query(None)
):
    """TEBEOS PostgreSQL veritabanı bağlantı testi ve ping metrikleri."""
    return await asyncio.to_thread(
        tebeos_client.ping,
        host=host,
        port=port,
        database=database,
        user=user,
        password=password
    )


@router.get("/api/tebeos/product")
async def tebeos_product_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    """Tekil olarak ilacın TEBEOS stok, giriş ve aylık hareket analizini döner."""
    return await asyncio.to_thread(tebeos_client.get_product_analysis, q)


@router.get("/api/tebeos/discover")
async def tebeos_discover_endpoint():
    """Ağda veya yerel ortamda TEBEOS PostgreSQL sunucusunu (Port 5454) otomatik tespit eder."""
    return await asyncio.to_thread(tebeos_client.discover_tebeos_host)


@router.get("/api/products/equivalents")
@router.get("/api/otomasyon/equivalents")
async def get_equivalents_endpoint(
    kod: Optional[str] = Query(None),
    esdeger: Optional[str] = Query(None),
    jenerik: Optional[str] = Query(""),
    barcode: Optional[str] = Query(None),
    q: Optional[str] = Query(None)
):
    """
    Aranan ilacın SGK eşdeğer grubundaki tüm muadilleri;
    anlık canlı depo MF şartları, net birim maliyetleri, SGK kamu ve perakende kârlılıkları
    ve eczane raf stoğu ile birlikte kârlılık sırasına göre döner.
    """
    target = barcode or q or kod or ""
    active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()

    oto_data = None
    oto_map = {}
    esdeger_kodu = esdeger or None

    if target:
        if active_oto == "TEBEOS":
            try:
                res = await asyncio.to_thread(tebeos_client.get_product_equivalents, target)
                if res.get("found"):
                    oto_data = res
                    esdeger_kodu = esdeger_kodu or res.get("esdeger_kodu")
            except Exception as e:
                print(f"[Tebeos] get_product_equivalents hatası: {e}")
        elif active_oto == "TRIA":
            try:
                res = await asyncio.to_thread(tria_client.get_product_equivalents, target)
                if res.get("found"):
                    oto_data = res
                    esdeger_kodu = esdeger_kodu or res.get("esdeger_kodu")
            except Exception as e:
                print(f"[Tria] get_product_equivalents hatası: {e}")
        elif active_oto == "BOTANIK":
            try:
                res = await asyncio.to_thread(botanik_client.get_product_equivalents, target)
                if res.get("found"):
                    oto_data = res
                    esdeger_kodu = esdeger_kodu or res.get("esdeger_kodu")
            except Exception as e:
                print(f"[Botanik] get_product_equivalents hatası: {e}")

    def clean_brand_name(text: str) -> str:
        if not text:
            return ""
        tr_map = {'İ': 'i', 'I': 'i', 'ı': 'i', 'Ş': 's', 'ş': 's', 'Ğ': 'g', 'ğ': 'g', 'Ü': 'u', 'ü': 'u', 'Ö': 'o', 'ö': 'o', 'Ç': 'c', 'ç': 'c'}
        n = text
        for k, v in tr_map.items():
            n = n.replace(k, v)
        words = re.findall(r'[a-z0-9]+', n.lower())
        return words[0] if words else ""

    oto_brand_map = {}
    if oto_data and oto_data.get("muadiller"):
        for item in oto_data["muadiller"]:
            m_kod = str(item.get("mal_kodu", "")).strip()
            m_bc = str(item.get("barkod", "")).strip()
            m_name = str(item.get("urun_adi", "")).strip()
            if m_kod:
                oto_map[m_kod] = item
            if m_bc:
                oto_map[m_bc] = item
            b = clean_brand_name(m_name)
            if b and (b not in oto_brand_map or item.get("stok", 0) > oto_brand_map[b].get("stok", 0)):
                oto_brand_map[b] = item

    raw_eqs = []
    motor = app_state.get_motor()
    try:
        selcuk_ad = motor.adapters.get(DepoKodu.SELCUK) if motor else None
        search_code = barcode or q or target or kod or ""
        if selcuk_ad and (search_code or esdeger_kodu):
            raw_eqs = await selcuk_ad.get_equivalents(search_code, esdeger_kodu or "", jenerik or "")
    except Exception as e:
        print(f"[Equivalents] Selçuk get_equivalents hatası: {e}")

    if not oto_data and raw_eqs:
        try:
            curr_ref = next((x for x in raw_eqs if x.get("is_current")), raw_eqs[0])
            ref_name = curr_ref.get("ad") or curr_ref.get("urun_adi") or ""
            if ref_name:
                sec_res = None
                if active_oto == "TEBEOS":
                    sec_res = await asyncio.to_thread(tebeos_client.get_product_equivalents, ref_name)
                elif active_oto == "TRIA":
                    sec_res = await asyncio.to_thread(tria_client.get_product_equivalents, ref_name)
                elif active_oto == "BOTANIK":
                    sec_res = await asyncio.to_thread(botanik_client.get_product_equivalents, ref_name)

                if sec_res and sec_res.get("found"):
                    oto_data = sec_res
                    esdeger_kodu = esdeger_kodu or sec_res.get("esdeger_kodu")
                    for item in sec_res.get("muadiller", []):
                        m_kod = str(item.get("mal_kodu", "")).strip()
                        m_bc = str(item.get("barkod", "")).strip()
                        m_name = str(item.get("urun_adi", "")).strip()
                        if m_kod:
                            oto_map[m_kod] = item
                        if m_bc:
                            oto_map[m_bc] = item
                        b = clean_brand_name(m_name)
                        if b and (b not in oto_brand_map or item.get("stok", 0) > oto_brand_map[b].get("stok", 0)):
                            oto_brand_map[b] = item
        except Exception as e:
            print(f"[Equivalents] Otomasyon ikincil çözümleme hatası: {e}")

    def extract_drug_tokens(name: str):
        if not name:
            return "", set()
        n = name.upper().replace("-", " ").replace(".", " ")
        n = re.sub(r"\b1\s*(GR|G)\b", "1000 MG", n)
        n = re.sub(r"\b2\s*(GR|G)\b", "2000 MG", n)
        nums = set(re.findall(r"\d+", n))
        tr_map = {'İ': 'i', 'I': 'i', 'ı': 'i', 'Ş': 's', 'ş': 's', 'Ğ': 'g', 'ğ': 'g', 'Ü': 'u', 'ü': 'u', 'Ö': 'o', 'ö': 'o', 'Ç': 'c', 'ç': 'c'}
        for k, v in tr_map.items():
            n = n.replace(k, v.upper())
        skip = {'MG', 'ML', 'GR', 'G', 'TB', 'FTB', 'TAB', 'TABLET', 'FILM', 'SUS', 'SUSP', 'SURUP', 'KAP', 'KAPSUL', 'ADET', 'KUTU', 'FLK', 'AMP'}
        words = [w for w in re.findall(r"[A-Z0-9]+", n) if w not in skip and not w.isdigit()]
        brand = words[0].lower() if words else ""
        return brand, nums

    if raw_eqs:
        for eq in raw_eqs:
            c_kod = str(eq.get("kod", "")).strip()
            c_ad = str(eq.get("ad") or eq.get("urun_adi") or "").strip()
            c_brand, c_nums = extract_drug_tokens(c_ad)

            oto_info = oto_map.get(c_kod) or {}

            if not oto_info and oto_data and oto_data.get("muadiller"):
                best_match = None
                best_score = 0
                for m_item in oto_data["muadiller"]:
                    m_name = m_item.get("urun_adi", "")
                    m_brand, m_nums = extract_drug_tokens(m_name)
                    if c_brand and m_brand and c_brand == m_brand:
                        common = c_nums.intersection(m_nums)
                        score = len(common) + 1
                        if score > best_score:
                            best_score = score
                            best_match = m_item
                if best_match:
                    oto_info = best_match

            final_bc = oto_info.get("barkod") if oto_info else None
            cat_inst_isk = 0.0
            if not final_bc or len(str(final_bc)) < 8 or not str(final_bc).isdigit():
                try:
                    with catalog._get_connection() as c_conn:
                        c_cur = c_conn.cursor()
                        if c_brand and c_nums:
                            like_terms = [f"%{c_brand}%"] + [f"%{n}%" for n in sorted(c_nums, key=lambda x: -len(x))[:2]]
                            where_clause = " AND ".join(["name_normalized LIKE ?" for _ in like_terms])
                            c_cur.execute(f"SELECT primary_barcode, institution_discount FROM products WHERE {where_clause} LIMIT 1", [t.lower() for t in like_terms])
                            c_row = c_cur.fetchone()
                            if c_row and c_row[0]:
                                final_bc = c_row[0]
                                cat_inst_isk = float(c_row[1] or 0.0)
                        if not final_bc:
                            suggs = catalog.search_suggestions(c_ad, limit=1)
                            if suggs and suggs[0].get("barcode"):
                                final_bc = suggs[0]["barcode"]
                                cat_inst_isk = float(suggs[0].get("institution_discount") or 0.0)
                except Exception:
                    pass

            if final_bc and not oto_info:
                oto_info = oto_map.get(str(final_bc)) or oto_map.get(str(final_bc).lstrip("0")) or {}

            eq["stok"] = oto_info.get("stok", 0) if oto_info else 0
            eq["cikis_30gun"] = oto_info.get("cikis_30gun", 0) if oto_info else 0
            eq["barkod"] = final_bc or c_kod
            eq["gecmis_mf_var"] = oto_info.get("gecmis_mf_var", False) if oto_info else False
            eq["gecmis_mf_bilgi"] = oto_info.get("gecmis_mf_bilgi", "") if oto_info else ""
            eq["gecmis_mf_kisa"] = oto_info.get("gecmis_mf_kisa", "") if oto_info else ""

            kamu_isk_val = float(eq.get("kamu_iskontosu") or 0.0)
            if kamu_isk_val <= 0.0 and oto_info and float(oto_info.get("kamu_iskontosu") or 0.0) > 0.0:
                kamu_isk_val = float(oto_info["kamu_iskontosu"])
            if kamu_isk_val <= 0.0 and cat_inst_isk > 0.0:
                kamu_isk_val = cat_inst_isk
            if kamu_isk_val <= 0.0 and final_bc:
                try:
                    cat_p = catalog.get_by_barcode(str(final_bc))
                    if cat_p and float(cat_p.get("institution_discount") or 0.0) > 0.0:
                        kamu_isk_val = float(cat_p["institution_discount"])
                except Exception:
                    pass

            psf_v = float(eq.get("psf") or eq.get("etiket_fiyati") or (oto_info.get("psf") if oto_info else 0.0) or 0.0)
            existing_ksf_v = float(eq.get("ksf") or eq.get("kamu_fiyati") or (oto_info.get("ksf") if oto_info else 0.0) or 0.0)
            if existing_ksf_v > 0 and (psf_v <= 0 or existing_ksf_v < psf_v):
                ksf_v = round(existing_ksf_v, 2)
                if kamu_isk_val <= 0.0 and psf_v > ksf_v > 0:
                    kamu_isk_val = round((1.0 - (ksf_v / psf_v)) * 100.0, 2)
            else:
                ksf_v = round(psf_v * (1.0 - (kamu_isk_val / 100.0)), 2) if (psf_v > 0 and kamu_isk_val > 0) else round(psf_v, 2)

            eq["psf"] = round(psf_v, 2)
            eq["kamu_iskontosu"] = round(kamu_isk_val, 2)
            eq["ksf"] = ksf_v
            eq["kamu_fiyati"] = ksf_v

        if motor:
            await motor.enrich_equivalents_with_live_mf(raw_eqs, search_target=target)

        curr_item = next((x for x in raw_eqs if x.get("is_current")), None)
        curr_kamu_kari = float(curr_item.get("kamu_kari") or 0.0) if curr_item else 0.0

        en_karli = None
        muadil_kar_avantaji = 0.0
        for item in raw_eqs:
            if item.get("is_best_deal") or (float(item.get("kar_farki") or 0.0) > 0 and not item.get("is_current")):
                item["is_best_deal"] = True
                en_karli = item
                muadil_kar_avantaji = float(item.get("kar_farki") or 0.0)
                break

        return {
            "found": True,
            "esdeger_kodu": esdeger_kodu or "SGK_ESDEGER",
            "count": len(raw_eqs),
            "en_karli_muadil": en_karli,
            "muadil_kar_avantaji": muadil_kar_avantaji,
            "current_kamu_kari": curr_kamu_kari,
            "muadiller": raw_eqs
        }

    if oto_data and oto_data.get("found"):
        muadiller = oto_data.get("muadiller", [])
        base_kari = float(oto_data.get("current_kamu_kari") or 0.0)
        if motor and muadiller:
            await motor.enrich_equivalents_with_live_mf(
                esdegerler=muadiller,
                search_target=target,
                base_kamu_kari=base_kari
            )

        curr_item = next((x for x in muadiller if x.get("is_current")), None)
        curr_kamu_kari = float(curr_item.get("kamu_kari") or base_kari) if curr_item else base_kari
        en_karli = next((x for x in muadiller if x.get("is_best_deal")), oto_data.get("en_karli_muadil"))
        muadil_kar_avantaji = float(en_karli.get("kar_farki") or 0.0) if en_karli else float(oto_data.get("muadil_kar_avantaji") or 0.0)

        return {
            "found": True,
            "esdeger_kodu": oto_data.get("esdeger_kodu"),
            "count": len(muadiller),
            "en_karli_muadil": en_karli,
            "muadil_kar_avantaji": muadil_kar_avantaji,
            "current_kamu_kari": curr_kamu_kari,
            "muadiller": muadiller
        }

    return {
        "found": False,
        "esdeger_kodu": None,
        "count": 0,
        "en_karli_muadil": None,
        "muadil_kar_avantaji": 0.0,
        "current_kamu_kari": 0.0,
        "muadiller": []
    }


@router.get("/api/botanik/dermo-audit")
async def botanik_dermo_audit_endpoint(brand: str = Query("", description="Marka filtresi"), limit: int = Query(50, ge=1, le=200)):
    """Botanik'teki dermo ürünlerini tarayıp eşleşen gerçek üretici EAN barkodlarını döndürür."""
    return await asyncio.to_thread(audit_botanik_dermo_barcodes, brand_filter=brand, limit=limit)


@router.post("/api/botanik/dermo-sync")
async def botanik_dermo_sync_endpoint(request: Request):
    """Kullanıcının onayladığı gerçek EAN barkodlarını Botanik'in Barkod tablosuna ekler."""
    try:
        data = await request.json()
        items = data.get("items", [])
        return await asyncio.to_thread(apply_botanik_dermo_barcodes, items)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Senkronizasyon hatası: {str(e)}"}, status_code=500)
