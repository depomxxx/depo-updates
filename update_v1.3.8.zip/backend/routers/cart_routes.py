# -*- coding: utf-8 -*-
"""
backend/routers/cart_routes.py
------------------------------
Depo sepet işlemleri (tekil ekleme, toplu ekleme, şelale ekleme, sepet durumu,
hızlı/toplu sipariş sonlandırma ve çoklu bilgisayar ortak sipariş/verilmeyecek takibi) uç noktaları.
"""

import re
import asyncio
from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse

import backend.app_state as app_state
from backend.order_tracker import order_tracker

router = APIRouter()


@router.post("/api/cart/add")
async def add_to_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        barkod = str(data.get("barkod", "")).strip()
        satis_sekli = str(data.get("satis_sekli", "")).strip()
        name = str(data.get("name") or data.get("urun_adi") or "").strip()

        if not depo:
            return JSONResponse({"success": False, "message": "Depo belirtilmedi."}, status_code=400)

        res = await motor.add_to_cart(
            depo=depo,
            urun_id=urun_id or barkod,
            miktar=miktar,
            barkod=barkod,
            satis_sekli=satis_sekli,
            name=name,
            urun_adi=name
        )
        if res.get("success"):
            try:
                await asyncio.to_thread(
                    order_tracker.mark_items,
                    [{"barkod": barkod or urun_id, "urun_adi": name, "depo": depo, "miktar": miktar}],
                    "SEPETTE",
                    depo
                )
            except Exception as e:
                print(f"[OrderTracker] add_to_cart kayıt uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepete ekleme hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/bulk-add")
async def bulk_add_to_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "ALLIANCE")).strip()
        items = data.get("items", [])
        cascade = bool(data.get("cascade", False))

        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek ürün listesi boş."}, status_code=400)

        if cascade:
            res = await motor.cascade_bulk_add_to_cart(start_depo=depo, items=items)
        else:
            res = await motor.bulk_add_to_cart(depo=depo, items=items)

        try:
            succ_items = [
                {
                    "barkod": r.get("barcode") or r.get("barkod"),
                    "urun_adi": r.get("name") or r.get("urun_adi"),
                    "depo": r.get("assigned_depo") or depo,
                    "miktar": r.get("miktar", 1)
                }
                for r in res.get("items", []) if r.get("success")
            ]
            if succ_items:
                await asyncio.to_thread(order_tracker.mark_items, succ_items, "SEPETTE", depo)
        except Exception as e:
            print(f"[OrderTracker] bulk_add kayıt uyarısı: {e}")

        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Toplu sepete ekleme hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/cascade-bulk-add")
async def cascade_bulk_add_to_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "ALLIANCE")).strip()
        items = data.get("items", [])
        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek ürün listesi boş."}, status_code=400)
        res = await motor.cascade_bulk_add_to_cart(start_depo=depo, items=items)
        try:
            succ_items = [
                {
                    "barkod": r.get("barcode") or r.get("barkod"),
                    "urun_adi": r.get("name") or r.get("urun_adi"),
                    "depo": r.get("assigned_depo") or depo,
                    "miktar": r.get("miktar", 1)
                }
                for r in res.get("items", []) if r.get("success")
            ]
            if succ_items:
                await asyncio.to_thread(order_tracker.mark_items, succ_items, "SEPETTE", depo)
        except Exception as e:
            print(f"[OrderTracker] cascade_bulk_add kayıt uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Şelale sepete ekleme hatası: {str(e)}"}, status_code=500)


@router.get("/api/cart/status")
async def cart_status_endpoint(depo: str = Query("SELCUK")):
    motor = app_state.get_motor()
    try:
        res = await motor.get_cart_status(depo=depo)
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepet sorgulama hatası: {str(e)}"}, status_code=500)


def _normalize_tr_cart_text(text: str) -> str:
    if not text:
        return ""
    tr_map = {
        'İ': 'i', 'I': 'i', 'ı': 'i',
        'Ş': 's', 'ş': 's',
        'Ğ': 'g', 'ğ': 'g',
        'Ü': 'u', 'ü': 'u',
        'Ö': 'o', 'ö': 'o',
        'Ç': 'c', 'ç': 'c'
    }
    res = str(text)
    for k, v in tr_map.items():
        res = res.replace(k, v)
    return res.lower().strip()


def _extract_cart_tokens(name: str):
    norm = _normalize_tr_cart_text(name)
    if not norm:
        return "", [], set()
    norm = re.sub(r"\b1\s*(gr|g)\b", "1000 mg", norm)
    norm = re.sub(r"\b2\s*(gr|g)\b", "2000 mg", norm)
    nums = set(re.findall(r"\d+", norm))
    skip = {
        'mg', 'ml', 'gr', 'g', 'tb', 'ftb', 'tab', 'tablet', 'film', 'kapli',
        'sus', 'susp', 'surup', 'kap', 'kapsul', 'adet', 'kutu', 'flk', 'amp',
        'krem', 'merhem', 'jel', 'losyon', 'sprey', 'damla', 'saşe', 'sase', 'ef', 'efervesan'
    }
    words = [w for w in re.findall(r"[a-z0-9]+", norm) if w not in skip and not w.isdigit() and len(w) >= 2]
    brand = words[0] if words else ""
    return brand, words, nums


def _is_same_cart_product(cart_it: dict, exp_it: dict) -> bool:
    """Depo sepetindeki bir satırın, beklenen/az önce eklenen ürünle aynı olup olmadığını akıllıca tespit eder."""
    c_kod = str(cart_it.get("kod") or cart_it.get("id") or "").strip()
    c_bc = str(cart_it.get("barkod") or "").strip()
    c_ad = str(cart_it.get("ad") or cart_it.get("urun_adi") or "").strip()

    e_id = str(exp_it.get("urun_id") or exp_it.get("kod") or exp_it.get("id") or "").strip()
    e_bc = str(exp_it.get("barcode") or exp_it.get("barkod") or "").strip()
    e_ad = str(exp_it.get("name") or exp_it.get("urun_adi") or exp_it.get("ad") or "").strip()

    c_codes = {x for x in (c_kod, c_bc, c_bc.lstrip("0") if len(c_bc) == 14 else "") if x}
    e_codes = {x for x in (e_id, e_bc, e_bc.lstrip("0") if len(e_bc) == 14 else "") if x}
    if c_codes and e_codes and c_codes.intersection(e_codes):
        return True

    c_norm = _normalize_tr_cart_text(c_ad)
    e_norm = _normalize_tr_cart_text(e_ad)
    if not c_norm or not e_norm:
        return False
    if c_norm in e_norm or e_norm in c_norm:
        return True

    c_brand, c_words, c_nums = _extract_cart_tokens(c_ad)
    e_brand, e_words, e_nums = _extract_cart_tokens(e_ad)
    if not c_brand or not e_brand:
        return False

    if c_brand == e_brand or (len(c_brand) >= 4 and len(e_brand) >= 4 and (c_brand.startswith(e_brand[:4]) or e_brand.startswith(c_brand[:4]))):
        if c_nums and e_nums:
            if c_nums.intersection(e_nums):
                return True
        else:
            common_words = set(c_words).intersection(set(e_words))
            if len(common_words) >= min(2, len(c_words), len(e_words)):
                return True
    return False


@router.post("/api/cart/quick-finalize-check")
async def quick_finalize_check_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        barkod = str(data.get("barkod", "")).strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        urun_adi = str(data.get("urun_adi", "")).strip()

        cart_status = await motor.get_cart_status(depo=depo)
        items = cart_status.get("items", [])

        today_session_items = []
        try:
            cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
            for val in cur_orders.values():
                if isinstance(val, dict) and str(val.get("depo") or "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                    today_session_items.append({
                        "barcode": str(val.get("barkod") or "").strip(),
                        "name": str(val.get("urun_adi") or "").strip(),
                        "miktar": int(val.get("miktar") or 1)
                    })
        except Exception:
            pass

        target_exp = {"urun_id": urun_id, "barkod": barkod, "urun_adi": urun_adi}
        already_in_cart = False
        session_items = []
        foreign_items = []
        annotated_items = []

        for it in items:
            it_copy = dict(it)
            if _is_same_cart_product(it_copy, target_exp):
                it_copy["item_origin"] = "CURRENT_TARGET"
                already_in_cart = True
                session_items.append(it_copy)
            elif any(_is_same_cart_product(it_copy, s_it) for s_it in today_session_items):
                it_copy["item_origin"] = "ADDED_THIS_SESSION"
                session_items.append(it_copy)
            else:
                it_copy["item_origin"] = "FOREIGN_OTHER"
                foreign_items.append(it_copy)
            annotated_items.append(it_copy)

        item_count = len(annotated_items)
        has_other_items = len(foreign_items) > 0
        foreign_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in foreign_items)
        session_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in session_items)

        return JSONResponse({
            "success": True,
            "depo": depo,
            "can_finalize_directly": not has_other_items,
            "has_other_items": has_other_items,
            "already_in_cart": already_in_cart,
            "item_count": item_count,
            "items": annotated_items,
            "session_items": session_items,
            "session_count": len(session_items),
            "session_total": round(session_total, 2),
            "foreign_items": foreign_items,
            "foreign_count": len(foreign_items),
            "foreign_total": round(foreign_total, 2),
            "total_amount": cart_status.get("total_amount", 0.0),
            "cart_url": cart_status.get("cart_url", ""),
            "checkout_url": cart_status.get("checkout_url", ""),
            "supported": cart_status.get("supported", False)
        })
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Hızlı sipariş kontrol hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/finalize")
async def finalize_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        barkod = str(data.get("barkod", "")).strip()
        urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        force = bool(data.get("force", False))
        already_in_cart = bool(data.get("already_in_cart", False))
        satis_sekli = str(data.get("satis_sekli", "")).strip()
        bulk_items = data.get("items", [])

        effective_urun_id = "" if already_in_cart else (urun_id or barkod)
        effective_barkod = "" if already_in_cart else barkod
        effective_force = True if already_in_cart else force

        res = await motor.finalize_order(
            depo=depo,
            urun_id=effective_urun_id,
            miktar=miktar,
            force=effective_force,
            barkod=effective_barkod,
            satis_sekli=satis_sekli,
            name=urun_adi,
            urun_adi=urun_adi,
            items=bulk_items
        )
        if res.get("success"):
            try:
                to_mark = []
                if barkod or urun_id or urun_adi:
                    to_mark.append({
                        "barkod": barkod or urun_id,
                        "urun_adi": urun_adi,
                        "depo": depo,
                        "miktar": miktar
                    })
                if bulk_items and isinstance(bulk_items, list):
                    for bi in bulk_items:
                        to_mark.append({
                            "barkod": bi.get("barcode") or bi.get("barkod") or bi.get("urun_id") or "",
                            "urun_adi": bi.get("name") or bi.get("urun_adi") or "",
                            "depo": depo,
                            "miktar": bi.get("miktar", 1)
                        })
                cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
                seen_bcs = set()
                for val in cur_orders.values():
                    if isinstance(val, dict) and val.get("depo", "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                        v_bc = val.get("barkod") or ""
                        if v_bc and v_bc not in seen_bcs:
                            seen_bcs.add(v_bc)
                            to_mark.append({
                                "barkod": v_bc,
                                "urun_adi": val.get("urun_adi") or "",
                                "depo": depo,
                                "miktar": val.get("miktar", 1)
                            })
                if to_mark:
                    await asyncio.to_thread(order_tracker.mark_items, to_mark, "SIPARIS_VERILDI", depo)
            except Exception as e:
                print(f"[OrderTracker] finalize_order kayıt uyarısı: {e}")

        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sipariş sonlandırma hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/clear")
async def clear_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        res = await motor.clear_cart(depo=depo)
        if res.get("success"):
            try:
                await asyncio.to_thread(order_tracker.clear_cart_items_for_depo, depo)
            except Exception as e:
                print(f"[OrderTracker] clear_cart kayıt silme uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepet temizleme hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/bulk-finalize-check")
async def bulk_finalize_check_endpoint(request: Request):
    """
    Günlük toplu sipariş sonlandırma öncesi sepeti kontrol eder.
    Sepetteki ürünleri, bugün sipariş edilmek istenen beklenen ürünlerle karşılaştırır.
    Farklı/önceden sepette olan ürünleri ayıklar.
    """
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        raw_expected = data.get("items", []) or []

        expected_items = list(raw_expected)
        seen_bcs = {str(it.get("barcode") or it.get("barkod") or "").strip() for it in expected_items if str(it.get("barcode") or it.get("barkod") or "").strip()}
        try:
            cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
            for val in cur_orders.values():
                if isinstance(val, dict) and str(val.get("depo") or "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                    v_bc = str(val.get("barkod") or "").strip()
                    v_nm = str(val.get("urun_adi") or "").strip()
                    key = v_bc or v_nm
                    if key and key not in seen_bcs:
                        seen_bcs.add(key)
                        expected_items.append({
                            "barcode": v_bc,
                            "name": v_nm,
                            "miktar": int(val.get("miktar") or 1)
                        })
        except Exception:
            pass

        cart_status = await motor.get_cart_status(depo=depo)
        cart_items = cart_status.get("items", [])

        if len(cart_items) == 0 and len(expected_items) > 0:
            try:
                print(f"[{depo}] bulk-finalize-check: Sepet boş döndü, {len(expected_items)} beklenen ürün otomatik yeniden sepete ekleniyor...")
                await motor.bulk_add_to_cart(depo=depo, items=expected_items)
                cart_status = await motor.get_cart_status(depo=depo)
                cart_items = cart_status.get("items", [])
            except Exception as re_err:
                print(f"[{depo}] Otomatik sepet geri yükleme uyarısı: {re_err}")

        total_amount = cart_status.get("total_amount", 0.0)

        matched_items = []
        extra_items = []

        for c_it in cart_items:
            c_copy = dict(c_it)
            is_matched = any(_is_same_cart_product(c_copy, exp_it) for exp_it in expected_items)
            if is_matched:
                c_copy["item_origin"] = "ADDED_THIS_SESSION"
                matched_items.append(c_copy)
            else:
                c_copy["item_origin"] = "FOREIGN_OTHER"
                extra_items.append(c_copy)

        has_extra_items = len(extra_items) > 0
        can_finalize_directly = (not has_extra_items) and (len(cart_items) > 0)

        extra_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in extra_items)

        return JSONResponse({
            "success": True,
            "depo": depo,
            "can_finalize_directly": can_finalize_directly,
            "has_extra_items": has_extra_items,
            "cart_count": len(cart_items),
            "matched_count": len(matched_items),
            "extra_count": len(extra_items),
            "extra_total": round(extra_total, 2),
            "total_amount": total_amount,
            "matched_items": matched_items,
            "extra_items": extra_items,
            "all_items": matched_items + extra_items,
            "cart_url": cart_status.get("cart_url", ""),
            "checkout_url": cart_status.get("checkout_url", ""),
            "supported": cart_status.get("supported", False)
        })
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Günlük sipariş sepet kontrol hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/bulk-finalize-clean-submit")
async def bulk_finalize_clean_submit_endpoint(request: Request):
    """
    Sepetteki farklı ürünleri temizler:
    1. Sepeti tamamen boşaltır (/api/cart/clear)
    2. Sadece bugün gönderilmek istenen günlük sipariş ürünlerini yeniden sepete ekler
    3. Siparişi depoya onaylayıp sonlandırır (/api/cart/finalize force=True)
    """
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        items = data.get("items", []) or []

        if not items:
            try:
                cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
                seen_bcs = set()
                for val in cur_orders.values():
                    if isinstance(val, dict) and val.get("depo", "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                        v_bc = str(val.get("barkod") or "").strip()
                        if v_bc and v_bc not in seen_bcs:
                            seen_bcs.add(v_bc)
                            items.append({
                                "barcode": v_bc,
                                "name": val.get("urun_adi") or "",
                                "miktar": int(val.get("miktar") or 1)
                            })
            except Exception:
                pass

        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek günlük sipariş kalemi bulunamadı."}, status_code=400)

        await motor.clear_cart(depo=depo)

        added_count = 0
        adapter = motor._get_adapter_by_depo(depo)
        if not adapter:
            return JSONResponse({"success": False, "message": f"'{depo}' için adaptör bulunamadı."}, status_code=400)

        for it in items:
            bc = str(it.get("barcode") or it.get("barkod") or "").strip()
            u_id = str(it.get("urun_id") or "").strip()
            mik = int(it.get("miktar") or 1)
            try:
                target_id = u_id if u_id else bc
                add_res = await adapter.add_to_cart(urun_id=target_id, miktar=mik, barkod=bc)
                if add_res.get("success"):
                    added_count += 1
            except Exception as e:
                print(f"[Bulk Finalize Clean] Ürün ekleme hatası ({bc}): {e}")

        if added_count == 0:
            return JSONResponse({"success": False, "message": "Günlük sipariş ürünleri sepete yeniden eklenemedi."}, status_code=500)

        fin_res = await motor.finalize_order(depo=depo, urun_id="", force=True)
        if fin_res.get("success"):
            try:
                await asyncio.to_thread(order_tracker.clear_cart_items_for_depo, depo)
                await asyncio.to_thread(order_tracker.mark_items, items, "SIPARIS_VERILDI", depo)
            except Exception as e:
                print(f"[OrderTracker] bulk_finalize_clean_submit kayıt uyarısı: {e}")
        return JSONResponse(fin_res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Temizleyip sonlandırma hatası: {str(e)}"}, status_code=500)


# --- Çoklu Bilgisayar (Multi-PC) Günlük Sipariş & Verilmeyecek Senkronizasyon Endpoints ---
@router.get("/api/orders/today")
async def get_today_orders_endpoint():
    """Tüm eczane bilgisayarlarında bugün verilen / sepete eklenen / verilmeyecek işaretlenen siparişlerin anlık haritasını döner."""
    try:
        orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
        return {"success": True, "orders": orders, "pc_name": order_tracker.pc_name}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/mark")
async def mark_orders_endpoint(request: Request):
    """Bir veya birden fazla ürünü tüm bilgisayarlarda 'SIPARIS_VERILDI', 'SEPETTE' veya 'SIPARIS_VERILMEYECEK' olarak işaretler."""
    try:
        data = await request.json()
        items = data.get("items", [])
        durum = str(data.get("durum", "SIPARIS_VERILDI")).strip()
        depo = str(data.get("depo", "MANUEL")).strip()
        count = await asyncio.to_thread(order_tracker.mark_items, items, durum, depo)
        return JSONResponse({"success": True, "count": count, "pc_name": order_tracker.pc_name})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/unmark")
async def unmark_order_endpoint(request: Request):
    """Sipariş verildi veya sipariş verilmeyecek işaretini geri alır (tüm bilgisayarlarda tekrar aktif listeye sokar)."""
    try:
        data = await request.json()
        barkod = str(data.get("barkod") or data.get("barcode") or "").strip()
        urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
        ok = await asyncio.to_thread(order_tracker.unmark_item, barkod, urun_adi)
        return JSONResponse({"success": bool(ok), "pc_name": order_tracker.pc_name})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)
