# -*- coding: utf-8 -*-
"""Modüler Web Arayüzü (UI) Paket Birleştirici."""

from backend.ui.layout_html import LAYOUT_HTML
from backend.ui.core_cart_js import CORE_CART_JS
from backend.ui.settings_market_js import SETTINGS_MARKET_JS
from backend.ui.critical_bulk_js import CRITICAL_BULK_JS

def get_main_ui_html() -> str:
    return LAYOUT_HTML + CORE_CART_JS + SETTINGS_MARKET_JS + CRITICAL_BULK_JS
