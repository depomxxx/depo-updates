# -*- coding: utf-8 -*-
"""
server.py
---------
Farma Radar — Eczane Depo Şart & Net Maliyet Karşılaştırma Sistemi
Ana Sunucu Giriş Noktası (Modüler Mimari v2.1)

Tüm alt modüller `backend/` dizini altında düzenli parçalara ayrılmıştır:
- `backend/config_manager.py`         : .env ve depo/otomasyon şifre yönetimi
- `backend/app_state.py`              : Paylaşılan motor ve önbellek durumu
- `backend/routers/system_routes.py`  : Durum, ayarlar, lisans ve canlı güncelleme API'leri
- `backend/routers/search_routes.py`  : Katalog, ilaç arama ve piyasa kıyaslama API'leri
- `backend/routers/otomasyon_routes.py`: Botanik/Tria/Tebeos, günün çıkışları, 6 aylık analiz ve muadil API'leri
- `backend/routers/cart_routes.py`    : Sepet, sipariş sonlandırma ve ortak sipariş/verilmeyecek takibi API'leri
- `backend/ui/`                       : Modüler HTML Arayüzü ve JavaScript bileşenleri
"""

import asyncio
import os
import sys
import time
from pathlib import Path
from typing import Optional

# Ensure script directory is in sys.path
_script_dir = str(Path(__file__).resolve().parent)
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

# Ensure process runs as Tria.exe on Windows so TriaWinService.exe never kills Oracle sessions (ORA-00028 / DPY-4011)
if __name__ == "__main__" and sys.platform == "win32" and os.environ.get("TRIA_EXE_REEXEC") != "1":
    _exe_name = os.path.basename(sys.executable).lower()
    if _exe_name in ("python.exe", "pythonw.exe"):
        import shutil
        import subprocess
        _exe_dir = Path(sys.executable).resolve().parent
        _target_name = "TriaPcPOS.exe" if _exe_name == "pythonw.exe" else "Tria.exe"
        _tria_exe = _exe_dir / _target_name
        if not _tria_exe.exists():
            try:
                shutil.copy2(sys.executable, _tria_exe)
            except Exception:
                pass
        if not _tria_exe.exists():
            _rt_tria = Path(__file__).resolve().parent / "runtime" / "Tria.exe"
            if _rt_tria.exists():
                _tria_exe = _rt_tria
        if _tria_exe.exists():
            _env = os.environ.copy()
            _env["TRIA_EXE_REEXEC"] = "1"
            _cflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
            subprocess.Popen(
                [str(_tria_exe), *sys.argv],
                cwd=str(Path(__file__).resolve().parent),
                env=_env,
                creationflags=_cflags,
                close_fds=True
            )
            os._exit(0)

# Ensure UTF-8 and valid stdout/stderr handles on Windows (including pythonw / detached mode)
if sys.platform == "win32":
    _log_path = Path(__file__).resolve().parent / "server.log"
    try:
        if sys.stdout is None or not hasattr(sys.stdout, "write"):
            sys.stdout = open(_log_path, "a", encoding="utf-8", buffering=1)
        else:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            sys.stdout.write("")
    except Exception:
        sys.stdout = open(_log_path, "a", encoding="utf-8", buffering=1)
    try:
        if sys.stderr is None or not hasattr(sys.stderr, "write"):
            sys.stderr = sys.stdout
        else:
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
            sys.stderr.write("")
    except Exception:
        sys.stderr = sys.stdout

from backend.config_manager import load_env, get_current_credentials, save_credentials_to_env
load_env()

# Auto-configure PLAYWRIGHT_BROWSERS_PATH if bundled in runtime/playwright-browsers
_base_dir = Path(__file__).resolve().parent
_bundled_browsers = _base_dir / "runtime" / "playwright-browsers"
if _bundled_browsers.exists():
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(_bundled_browsers)

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware

import backend.app_state as app_state
from backend.query_engine import DepoSorguMotoru
from backend.models import DepoKodu
from backend.tria_client import tria_client
from backend.botanik_client import botanik_client
from backend.tebeos_client import tebeos_client
from backend.mf_resolver import mf_resolver
from backend.updater import updater
from backend.routers import system_router, search_router, otomasyon_router, cart_router
from backend.routers.system_routes import trigger_delayed_server_restart
from backend.ui import get_main_ui_html

app = FastAPI(title="Eczane Depo Şart & Maliyet Karşılaştırma", version="2.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modüler API Router'larını kaydet
app.include_router(system_router)
app.include_router(search_router)
app.include_router(otomasyon_router)
app.include_router(cart_router)


@app.on_event("startup")
async def startup_event():
    app_state.motor = DepoSorguMotoru(headless=True)
    print(">> Depo Sorgu Motoru başlatıldı. Aktif depolar:", list(app_state.motor.adapters.keys()))

    _prewarm_done_event = asyncio.Event()

    async def _prewarm_single_depot(depo_kodu: DepoKodu, label: str):
        try:
            if app_state.motor and depo_kodu in app_state.motor.adapters:
                adp = app_state.motor.adapters[depo_kodu]
                await adp.login()
                await adp._ensure_ready_page()
                print(f">> [{label}] Arka plan hızlı sipariş oturumu hazırlandı.")
        except Exception as e:
            print(f">> [{label}] Oturum ön-ısıtma uyarısı: {e}")

    async def _prewarm_all_depot_sessions():
        try:
            await asyncio.sleep(0.2)
            await asyncio.gather(
                _prewarm_single_depot(DepoKodu.SELCUK, "Selçuk"),
                _prewarm_single_depot(DepoKodu.NEVZAT, "Nevzat"),
                _prewarm_single_depot(DepoKodu.ALLIANCE, "Alliance"),
                _prewarm_single_depot(DepoKodu.ISKOOP, "İSKOOP"),
                return_exceptions=True
            )
        finally:
            _prewarm_done_event.set()

    asyncio.create_task(_prewarm_all_depot_sessions())

    async def _prewarm_cache():
        try:
            await asyncio.sleep(0.5)
            active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
            items = []
            source_used = active_oto
            if active_oto == "TRIA":
                print(">> [Tria] Arka planda kritik stok ve günün çıkışları taranıyor...")
                try:
                    items = await asyncio.to_thread(tria_client.get_critical_stock_sales)
                except Exception as e:
                    print(f">> [Tria] Önbellek çekme uyarısı: {e}")
            elif active_oto == "TEBEOS":
                print(">> [TEBEOS] Arka planda kritik stok ve günün çıkışları taranıyor...")
                try:
                    items = await asyncio.to_thread(tebeos_client.get_critical_stock_sales)
                    source_used = "TEBEOS"
                except Exception as e:
                    print(f">> [TEBEOS] Bağlantı uyarısı: {e}")
                    items = []
            else:
                print(">> [Botanik] Arka planda kritik stok önbelleği ısıtılıyor...")
                try:
                    items = await asyncio.to_thread(botanik_client.get_critical_stock_sales)
                    source_used = "BOTANIK"
                except Exception as e:
                    print(f">> [Botanik] Bağlantı uyarısı: {e}")
                    items = []

            app_state.critical_stock_cache = {"time": time.time(), "data": items, "source": source_used}
            print(f">> [{source_used}] Kritik stok önbelleği hazır: {len(items)} kalem ürün yüklendi.")

            async def _prewarm_mf_worker():
                try:
                    try:
                        await asyncio.wait_for(_prewarm_done_event.wait(), timeout=20.0)
                    except asyncio.TimeoutError:
                        pass
                    await asyncio.sleep(1.5)
                    top_barcodes = [str(x.get("barkod") or "").strip() for x in items[:35] if str(x.get("barkod") or "").strip()]
                    if top_barcodes and app_state.motor:
                        print(f">> [MF Motoru] İlk {len(top_barcodes)} azalan ürün için MF şartları arka planda taranıyor...")
                        await mf_resolver.resolve_batch(app_state.motor, top_barcodes, max_concurrency=4)
                        print(">> [MF Motoru] İlk parti MF şartları başarıyla önbelleğe alındı.")
                except Exception as e:
                    print(f">> [MF Motoru] Arka plan MF tarama uyarısı: {e}")

            asyncio.create_task(_prewarm_mf_worker())
        except Exception as e:
            print(f">> [Otomasyon] Önbellek ısıtma hatası: {e}")

    asyncio.create_task(_prewarm_cache())

    async def _auto_sync_active_dermo_worker():
        try:
            active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
            if active_oto != "BOTANIK":
                return
            await asyncio.sleep(2.0)
            from backend.dermo_sync import auto_sync_active_dermo_in_background
            print(">> [Taban Motoru] Botanik dermo ve OTC ürünleri arka planda taranıyor...")
            res = await asyncio.to_thread(auto_sync_active_dermo_in_background, 80)
            print(f">> [Taban Motoru] {res.get('message')}")
        except Exception as e:
            print(f">> [Taban Motoru] Arka plan eşleme notu: {e}")

    async def _live_auto_update_worker():
        """Arka planda GitHub Canlı Portalını ve LAN dağıtım sunucusunu periyodik denetler; yeni sürüm varsa canlı kurar."""
        await asyncio.sleep(12.0)
        while True:
            try:
                chk = await asyncio.to_thread(updater.check_for_updates, 3.0)
                if chk.get("update_available") and chk.get("download_url"):
                    if chk.get("auto_update", True) or chk.get("mandatory", False):
                        print(f">> [Canlı Güncelleme] Yeni sürüm tespit edildi: v{chk.get('latest_version')}. Otomatik kuruluyor...")
                        apply_res = await asyncio.to_thread(
                            updater.apply_update,
                            chk["download_url"],
                            chk.get("sha256", ""),
                            chk.get("latest_version", "")
                        )
                        if apply_res.get("success"):
                            print(f">> [Canlı Güncelleme] v{chk.get('latest_version')} başarıyla kuruldu, sunucu yeniden başlatılıyor...")
                            trigger_delayed_server_restart(1.5)
                            return
            except Exception as e:
                print(f">> [Canlı Güncelleme] Kontrol notu: {e}")
            await asyncio.sleep(300.0)

    asyncio.create_task(_auto_sync_active_dermo_worker())
    asyncio.create_task(_live_auto_update_worker())


@app.on_event("shutdown")
async def shutdown_event():
    if app_state.motor:
        await app_state.motor.close_all()
        print(">> Depo oturumları kapatıldı.")


def _start_background_auto_update_watcher():
    """Arka planda periyodik olarak hem yerel ağı (LAN) hem de GitHub portalını kontrol eder; yeni sürüm varsa otomatik günceller."""
    import threading
    def _watcher_loop():
        time.sleep(25)
        while True:
            try:
                vinfo = updater.get_local_version_info()
                if vinfo.get("auto_update", True):
                    chk = updater.check_for_updates(timeout=3.5)
                    if chk.get("update_available") and chk.get("download_url"):
                        dl_url = chk["download_url"]
                        sha = chk.get("sha256", "")
                        lat_ver = chk.get("latest_version", "")
                        print(f"[AUTO-UPDATE] Yeni sürüm tespit edildi: v{lat_ver} ({dl_url}) -> Otomatik kuruluyor...")
                        res = updater.apply_update(dl_url, sha, lat_ver)
                        if res.get("success"):
                            print(f"[AUTO-UPDATE] v{lat_ver} başarıyla kuruldu, sunucu yeniden başlatılıyor...")
                            trigger_delayed_server_restart(2.0)
                            return
            except Exception as e:
                print(f"[AUTO-UPDATE] Kontrol hatası: {e}")
            time.sleep(180)

    t = threading.Thread(target=_watcher_loop, daemon=True, name="AutoUpdateWatcher")
    t.start()


_start_background_auto_update_watcher()


@app.get("/", response_class=HTMLResponse)
async def get_ui():
    return HTMLResponse(content=get_main_ui_html())


if __name__ == "__main__":
    import uvicorn
    import socket
    import threading
    import webbrowser
    import subprocess

    host = os.environ.get("SERVER_HOST", "0.0.0.0")
    port = int(os.environ.get("SERVER_PORT", "8080"))

    local_ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass

    print("\n" + "=" * 65)
    print("  🚀 FARMA RADAR — AKILLI DEPO & MF SİSTEMİ ÇALIŞIYOR")
    print(f"  📍 Bu Bilgisayardan Erişim : http://localhost:{port}")
    print(f"  🌐 Eczane Ağından Erişim   : http://{local_ip}:{port}")
    print("=" * 65 + "\n")

    def _auto_open_browser():
        time.sleep(1.0)
        url = f"http://localhost:{port}"
        chrome_candidates = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
        ]
        opened = False
        for c_exe in chrome_candidates:
            if os.path.exists(c_exe):
                try:
                    subprocess.Popen([c_exe, f"--app={url}", "--window-size=1440,920"])
                    opened = True
                    break
                except Exception:
                    pass
        if not opened:
            try:
                webbrowser.open(url)
            except Exception:
                pass

    def _is_port_busy(p):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            return s.connect_ex(('127.0.0.1', p)) == 0

    is_restarting = (os.environ.get("SERVER_RESTARTING") == "1") or ("--restarting" in sys.argv)
    no_browser = is_restarting or (os.environ.get("NO_AUTO_BROWSER") == "1") or ("--no-browser" in sys.argv)

    if is_restarting:
        for _ in range(30):
            if not _is_port_busy(port):
                break
            time.sleep(0.3)
    elif _is_port_busy(port):
        print(f"\n[BILGI] Sistem zaten {port} portunda calisiyor!")
        if not no_browser:
            print(f"Tarayici aciliyor: http://localhost:{port}\n")
            _auto_open_browser()
            time.sleep(1.5)
        sys.exit(0)

    if not no_browser:
        threading.Thread(target=_auto_open_browser, daemon=True).start()

    uvicorn.run(app, host=host, port=port, reload=False)
