import asyncio
import json
import re
from typing import List, Optional, Dict, Any
from pathlib import Path
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.core.cost_calculator import CostCalculator
from backend.core.session_store import SessionStore
try:
    from backend.catalog import catalog
except Exception:
    catalog = None

def clean_float(val: Any) -> float:
    if val is None or val == "":
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).replace("₺", "").replace("TL", "").strip()
    if not s:
        return 0.0
    if "." in s and "," in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except Exception:
        return 0.0

def _parse_cart_adet(val: Any) -> Dict[str, Any]:
    """SepetDoldur'dan dönen 'adet' değerini ('1', '10+1', '8 + 2' vb.) güvenli şekilde ayrıştırır."""
    raw = str(val if val is not None else "1").strip()
    if not raw:
        raw = "1"
    if "+" in raw:
        parts = [p.strip() for p in raw.split("+") if p.strip()]
        try:
            alinan = int(float(parts[0].replace(",", "."))) if parts else 1
        except Exception:
            alinan = 1
        try:
            hediye = int(float(parts[1].replace(",", "."))) if len(parts) > 1 else 0
        except Exception:
            hediye = 0
        alinan = max(1, alinan)
        hediye = max(0, hediye)
        return {
            "miktar": alinan,
            "mf_hediye": hediye,
            "toplam_adet": alinan + hediye,
            "adet_label": f"{alinan}+{hediye}" if hediye > 0 else str(alinan)
        }
    try:
        m = max(1, int(float(raw.replace(",", "."))))
    except Exception:
        m = 1
    return {
        "miktar": m,
        "mf_hediye": 0,
        "toplam_adet": m,
        "adet_label": str(m)
    }

def parse_selcuk_mf_html(
    html_str: str,
    psf: float = 0.0,
    kdv_orani: float = 10.0,
    kamu_iskontosu: float = 0.0,
    mf1_fiyat: float = 0.0,
    top_isk: float = 0.0
) -> Dict[str, Any]:
    """Selçuk WebDepo'dan gelen MF HTML veya buton metinlerini çözümler, birim maliyet, KSF, SGK reçete kârı ve elden satış kârını hesaplar."""
    kdv_div = 1.0 + (kdv_orani / 100.0) if kdv_orani > 0 else 1.10
    dsf_brut = (psf / kdv_div) * 0.78125 if psf > 0 else 0.0
    ticari_carpan = (1.0 - (top_isk / 100.0)) if (0.0 < top_isk < 100.0) else 1.0

    def _resolve_kamu_isk(base_isk: float, tekli_net_kdvsiz: float) -> float:
        if base_isk > 0.0:
            return round(base_isk, 2)
        if dsf_brut > 0 and tekli_net_kdvsiz > 0:
            dsf_after_kamu = tekli_net_kdvsiz / ticari_carpan if ticari_carpan > 0 else tekli_net_kdvsiz
            if 0 < dsf_after_kamu < (dsf_brut * 0.985):
                derived = round((1.0 - (dsf_after_kamu / dsf_brut)) * 100.0, 1)
                if 1.5 <= derived <= 75.0:
                    return derived
        return round(max(0.0, base_isk), 2)

    if not html_str or "<button" not in html_str:
        clean_str = re.sub(r'<[^>]+>', '', html_str or '').strip()
        raw_pairs = re.findall(r'(\d+)\s*\+\s*(\d+)', clean_str)
        pairs = [(int(x), int(y)) for x, y in raw_pairs if int(x) > 0 and int(y) > 0]
        if pairs and psf > 0:
            a, h = pairs[0][0], pairs[0][1]
            if mf1_fiyat > 0:
                unit_cost_net = round(mf1_fiyat, 2)
                tekli_net = mf1_fiyat * ((a + h) / a)
            else:
                eff_isk = kamu_iskontosu if kamu_iskontosu > 0 else 0.0
                tekli_net = dsf_brut * (1.0 - (eff_isk / 100.0)) * ticari_carpan
                unit_cost_net = round(tekli_net * (a / (a + h)), 2)
            eff_kamu_isk = _resolve_kamu_isk(kamu_iskontosu, tekli_net)
            unit_cost_kdvli = round(unit_cost_net * kdv_div, 2)
            ksf = round(psf * (1.0 - (eff_kamu_isk / 100.0)), 2) if (psf > 0 and eff_kamu_isk > 0) else round(psf, 2)
            kamu_kari = round(ksf - unit_cost_kdvli, 2) if (ksf > 0 and unit_cost_kdvli > 0) else 0.0
            perakende_kari = round(psf - unit_cost_kdvli, 2) if (psf > 0 and unit_cost_kdvli > 0) else 0.0
            valid_mf_str = " / ".join(f"{x}+{y}" for x, y in pairs)
            return {
                "mf_metni": valid_mf_str,
                "en_iyi_mf": f"{a}+{h}",
                "kademeler": [{"alinan": a, "hediye": h, "mf_text": f"{a}+{h}", "birim_maliyet_kdvli": unit_cost_kdvli, "birim_maliyet": unit_cost_net}],
                "birim_maliyet_kdvli": unit_cost_kdvli,
                "birim_maliyet": unit_cost_net,
                "kamu_iskontosu": eff_kamu_isk,
                "ksf": ksf,
                "kamu_kari": kamu_kari,
                "perakende_kari": perakende_kari
            }

        if mf1_fiyat > 0:
            dsf_net = round(mf1_fiyat, 2)
            eff_kamu_isk = _resolve_kamu_isk(kamu_iskontosu, dsf_net)
            dsf_est = round(dsf_net * kdv_div, 2)
        else:
            eff_kamu_isk = round(max(0.0, kamu_iskontosu), 2)
            dsf_net = round(dsf_brut * (1.0 - (eff_kamu_isk / 100.0)) * ticari_carpan, 2) if dsf_brut > 0 else 0.0
            dsf_est = round(dsf_net * kdv_div, 2)

        ksf = round(psf * (1.0 - (eff_kamu_isk / 100.0)), 2) if (psf > 0 and eff_kamu_isk > 0) else round(psf, 2)
        kamu_kari = round(ksf - dsf_est, 2) if (ksf > 0 and dsf_est > 0) else 0.0
        perakende_kari = round(psf - dsf_est, 2) if (psf > 0 and dsf_est > 0) else 0.0
        return {
            "mf_metni": "YOK",
            "en_iyi_mf": "YOK",
            "kademeler": [],
            "birim_maliyet_kdvli": dsf_est,
            "birim_maliyet": dsf_net,
            "kamu_iskontosu": eff_kamu_isk,
            "ksf": ksf,
            "kamu_kari": kamu_kari,
            "perakende_kari": perakende_kari
        }

    btn_blocks = re.findall(r'<button[^>]*>.*?</button>', html_str, re.DOTALL | re.IGNORECASE)
    kademeler = []
    
    for btn in btn_blocks:
        m_pair = re.search(r'SetMiktarMf\([^,]*,\s*(\d+),\s*(\d+)\)', btn)
        if not m_pair:
            m_text = re.search(r'>\s*(\d+\s*\+\s*\d+)\s*<', btn)
            if m_text:
                parts = m_text.group(1).replace(" ", "").split("+")
                a, h = int(parts[0]), int(parts[1])
            else:
                continue
        else:
            a, h = int(m_pair.group(1)), int(m_pair.group(2))
        if a <= 0 or h <= 0:
            continue

        m_cost = re.search(r'Birim\s*Fiyat[^\d]*([\d\.,]+)', btn, re.IGNORECASE)
        unit_cost_kdvli = 0.0
        if m_cost:
            raw_c = m_cost.group(1).replace('.', '').replace(',', '.').strip()
            try:
                unit_cost_kdvli = float(raw_c)
            except ValueError:
                unit_cost_kdvli = 0.0

        if unit_cost_kdvli == 0.0 and psf > 0:
            base_single_kdvli = round(dsf_brut * kdv_div * (1.0 - (kamu_iskontosu / 100.0)) * ticari_carpan, 2)
            unit_cost_kdvli = round(base_single_kdvli * (a / (a + h)), 2)

        unit_cost_net = round(unit_cost_kdvli / kdv_div, 2)
        mf_text = f"{a}+{h}"
        isk_yuzde = round((h / (a + h)) * 100.0, 1)

        kademeler.append({
            "alinan": a,
            "hediye": h,
            "mf_text": mf_text,
            "birim_maliyet_kdvli": unit_cost_kdvli,
            "birim_maliyet": unit_cost_net,
            "iskonto_yuzdesi": isk_yuzde
        })

    kademeler.sort(key=lambda x: (x["birim_maliyet_kdvli"] if x["birim_maliyet_kdvli"] > 0 else 99999))
    
    en_iyi = kademeler[0] if kademeler else None
    en_iyi_mf = en_iyi["mf_text"] if en_iyi else "YOK"
    birim_kdvli = en_iyi["birim_maliyet_kdvli"] if en_iyi else 0.0
    birim_net = en_iyi["birim_maliyet"] if en_iyi else 0.0

    # Tekli kutu net maliyetinden (MF öncesi) ilacın gerçek SGK kamu iskontosunu tespit et
    tekli_net_est = 0.0
    if en_iyi and en_iyi["alinan"] > 0:
        ref_net = mf1_fiyat if (mf1_fiyat > 0 and abs(mf1_fiyat - birim_net) < 1.0) else birim_net
        tekli_net_est = ref_net * ((en_iyi["alinan"] + en_iyi["hediye"]) / en_iyi["alinan"])
    elif mf1_fiyat > 0:
        tekli_net_est = mf1_fiyat

    eff_kamu_isk = _resolve_kamu_isk(kamu_iskontosu, tekli_net_est)
    ksf = round(psf * (1.0 - (eff_kamu_isk / 100.0)), 2) if (psf > 0 and eff_kamu_isk > 0) else round(psf, 2)
    kamu_kari = round(ksf - birim_kdvli, 2) if (ksf > 0 and birim_kdvli > 0) else 0.0
    perakende_kari = round(psf - birim_kdvli, 2) if (psf > 0 and birim_kdvli > 0) else 0.0

    mf_all_text = " / ".join([k["mf_text"] for k in kademeler]) if kademeler else "YOK"

    return {
        "mf_metni": mf_all_text,
        "en_iyi_mf": en_iyi_mf,
        "kademeler": kademeler,
        "birim_maliyet_kdvli": birim_kdvli,
        "birim_maliyet": birim_net,
        "kamu_iskontosu": eff_kamu_isk,
        "ksf": ksf,
        "kamu_kari": kamu_kari,
        "perakende_kari": perakende_kari
    }

class SelcukAdapter(BaseDepoAdapter):
    BASE_URL = "https://webdepo.selcukecza.com.tr/Login.aspx"
    MAIN_URL = "https://webdepo.selcukecza.com.tr/Siparis/hizlisiparis.aspx"

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.SELCUK, "Selçuk Ecza Deposu")
        self.username = username
        self.password = password
        self.headless = headless
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
        self._lock = asyncio.Lock()
        self._cart_busy: int = 0
        self._last_added_items: List[Dict[str, Any]] = []
        self._last_added_time: float = 0.0

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-setuid-sandbox"]
            )
            
            session_file = SessionStore.get_session_file("selcuk")
            if session_file.exists():
                try:
                    self._context = await self._browser.new_context(storage_state=str(session_file))
                except Exception:
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()
                
            self._page = await self._context.new_page()

    async def is_session_valid(self) -> bool:
        if not self._page:
            await self._init_browser()
            
        try:
            cur_path = (self._page.url or "").split("?")[0].lower()
            if "hizlisiparis" in cur_path and "login.aspx" not in cur_path:
                has_jq = await self._page.evaluate("() => typeof window.jQuery !== 'undefined' && !document.querySelector('#txtKullaniciAdi')")
                if has_jq:
                    return True

            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            cur_path = (self._page.url or "").split("?")[0].lower()
            if "login.aspx" in cur_path:
                return False
            has_login_input = await self._page.evaluate("() => !!document.querySelector('#txtKullaniciAdi')")
            return not has_login_input
        except Exception:
            return False

    async def _login_unlocked(self) -> bool:
        """Selçuk WebDepo'ya giriş yapar (kilit içinde çağrılır)."""
        if not self.username or not self.password:
            raise ValueError("Selçuk için Kullanıcı Adı ve Şifre zorunludur.")

        await self._init_browser()
        
        if await self.is_session_valid():
            print("[Selçuk] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            return True

        print("[Selçuk] Giriş yapılıyor...")
        await self._page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=15000)
        cur_path = (self._page.url or "").split("?")[0].lower()
        if "login.aspx" in cur_path:
            await self._page.wait_for_selector("#txtKullaniciAdi", timeout=8000)
            await self._page.fill("#txtKullaniciAdi", str(self.username))
            await self._page.fill("#txtSifre", str(self.password))
            await self._page.click("#btnGiris")
            await self._page.wait_for_load_state("domcontentloaded")
            await asyncio.sleep(1.2)

        cur_path = (self._page.url or "").split("?")[0].lower()
        if "login.aspx" in cur_path:
            raise RuntimeError("Selçuk Giriş Başarısız! Kullanıcı adı veya şifre hatalı.")

        session_file = SessionStore.get_session_file("selcuk")
        await self._context.storage_state(path=str(session_file))
        print("[Selçuk] Başarıyla giriş yapıldı ve oturum kaydedildi.")
        self.is_logged_in = True
        return True

    async def login(self) -> bool:
        async with self._lock:
            return await self._login_unlocked()

    async def _ensure_ready_page(self, allow_sepet_page: bool = False):
        if not self._page:
            await self._init_browser()
        cur_path = (self._page.url or "").split("?")[0].lower()
        if not cur_path or cur_path == "about:blank" or "login.aspx" in cur_path:
            self.is_logged_in = False
            await self._login_unlocked()
            cur_path = (self._page.url or "").split("?")[0].lower()

        is_ok_page = ("hizlisiparis" in cur_path) or (allow_sepet_page and ("sepet.aspx" in cur_path or "siparisonay.aspx" in cur_path))
        if not is_ok_page:
            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            cur_path = (self._page.url or "").split("?")[0].lower()
            if "login.aspx" in cur_path:
                self.is_logged_in = False
                await self._login_unlocked()
                await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)

        # jQuery ($) yüklenene kadar kısa bekle
        for _ in range(10):
            try:
                has_jq = await self._page.evaluate("() => typeof window.jQuery !== 'undefined'")
                if has_jq:
                    break
            except Exception:
                pass
            await asyncio.sleep(0.1)

    async def search_product(self, query: str, include_equivalents: bool = True, is_background: bool = False) -> List[DepoUrunSarti]:
        """Ürün ara ve şartları getir. Sepet işlemi aktifken arka plan (MF) sorguları bekletilmez/iptal edilir."""
        if is_background and self._cart_busy > 0:
            return []
        async with self._lock:
            if is_background and self._cart_busy > 0:
                return []
            return await self._search_product_unlocked(query, include_equivalents=include_equivalents, is_background=is_background)

    async def _search_product_unlocked(self, query: str, include_equivalents: bool = True, is_background: bool = False) -> List[DepoUrunSarti]:
        if not self.is_logged_in:
            await self._login_unlocked()

        if is_background and self._cart_busy > 0:
            return []

        await self._ensure_ready_page()
        if not is_background:
            print(f"[Selçuk] '{query}' sorgulanıyor...")

        # 1. Hızlı sipariş ürün ara
        res = await self._page.evaluate("""async (q) => {
            return new Promise((resolve) => {
                $.ajax({
                    type: "POST",
                    url: "/Siparis/hizlisiparis-ajax.aspx",
                    timeout: 7000,
                    data: {
                        action: "GetUrunler",
                        searchText: q,
                        isInculude: true,
                        isStoktakiler: false,
                        siralama: "ilacASC",
                        marka: "",
                        baslangicSayfasi: 0,
                        topRowNum: 0,
                        sayfaMaxRowAdet: 5,
                        s: "s"
                    },
                    success: function(data) {
                        try {
                            resolve(typeof data === 'string' ? JSON.parse(data) : data);
                        } catch(e) {
                            resolve(null);
                        }
                    },
                    error: function() { resolve(null); }
                });
            });
        }""", query)

        if not res or not res.get("obj") or not res["obj"].get("urunler"):
            return []

        urunler = res["obj"]["urunler"]
        sonuclar: List[DepoUrunSarti] = []
        max_items = 1 if is_background else 5

        for u in urunler[:max_items]:
            if is_background and self._cart_busy > 0:
                break
            kod = u.get("kodu")
            ilac_tipi = u.get("ILACTIP", "B")
            
            # Detay ve Kampanyaları çek
            detay = await self._page.evaluate("""async (param) => {
                return new Promise((resolve) => {
                    $.ajax({
                        type: "POST",
                        url: "/Ilac/IlacGetir-ajax.aspx",
                        timeout: 7000,
                        data: {
                            action: "GetIlacDetay",
                            kod: param.kod,
                            isEsdeger: false,
                            esdeger: "",
                            isJenerik: false,
                            jenerikId: "",
                            tip: null,
                            ILACTIP: param.tip,
                            kampKodu: ""
                        },
                        success: function(data) {
                            try {
                                resolve(typeof data === 'string' ? JSON.parse(data) : data);
                            } catch(e) {
                                resolve(null);
                            }
                        },
                        error: function() { resolve(null); }
                    });
                });
            }""", {"kod": kod, "tip": ilac_tipi})

            if detay and detay.get("obj"):
                sarti = self._parse_selcuk_detay(u, detay["obj"], query)
                
                # Sadece kullanıcı aramasında (is_background=False) ilk ürün için muadil listesini çek
                if include_equivalents and not is_background:
                    esdeger_kodu = str(detay["obj"].get("esdegerKodu") or "").strip()
                    jenerik_obj = detay["obj"].get("jenerik") or {}
                    jenerik_id = str(jenerik_obj.get("value") or "")
                    if esdeger_kodu and len(sonuclar) == 0:
                        try:
                            esdegerler = await self._get_equivalents_unlocked(kod, esdeger_kodu, jenerik_id, ilac_tipi)
                            sarti.esdegerler = esdegerler
                        except Exception as e:
                            print(f"[Selçuk] Eşdeğer çekme hatası: {e}")

                sonuclar.append(sarti)

        return sonuclar

    async def get_equivalents(self, kod: str, esdeger_kodu: str = "", jenerik_id: str = "", ilac_tipi: str = "B") -> List[Dict[str, Any]]:
        """SGK Eşdeğer grubundaki muadil ilaçları Selçuk üzerinden çeker."""
        async with self._lock:
            return await self._get_equivalents_unlocked(kod, esdeger_kodu, jenerik_id, ilac_tipi)

    async def _get_equivalents_unlocked(self, kod: str, esdeger_kodu: str = "", jenerik_id: str = "", ilac_tipi: str = "B") -> List[Dict[str, Any]]:
        if not self.is_logged_in:
            if await self.is_session_valid():
                self.is_logged_in = True
            else:
                await self._login_unlocked()
        await self._ensure_ready_page()

        kod_str = str(kod or "").strip()
        esdeger_str = str(esdeger_kodu or "").strip()

        try:
            target_kod = kod_str
            target_esdeger = esdeger_str
            target_jenerik = jenerik_id
            target_tip = ilac_tipi

            # Eğer kod barkod ise (uzunluğu >= 8), başta '0' olan Tria kodu ise veya esdeger_kodu boşsa, önce Selçuk kodunu ve detayını bul
            if len(target_kod) >= 6 or target_kod.startswith("0") or not target_kod.isdigit() or not target_esdeger:
                search_res = await self._page.evaluate("""async (q) => {
                    return new Promise((resolve) => {
                        $.ajax({
                            type: "POST",
                            url: "/Siparis/hizlisiparis-ajax.aspx",
                            data: {
                                action: "GetUrunler",
                                searchText: q,
                                isInculude: true,
                                isStoktakiler: false,
                                siralama: "ilacASC",
                                marka: "",
                                baslangicSayfasi: 0,
                                topRowNum: 0,
                                sayfaMaxRowAdet: 5,
                                s: "s"
                            },
                            success: function(data) {
                                try {
                                    resolve(typeof data === 'string' ? JSON.parse(data) : data);
                                } catch(e) { resolve(null); }
                            },
                            error: function() { resolve(null); }
                        });
                    });
                }""", target_kod)

                if search_res and search_res.get("obj") and search_res["obj"].get("urunler"):
                    u = search_res["obj"]["urunler"][0]
                    target_kod = str(u.get("kodu") or target_kod)
                    target_tip = u.get("ILACTIP") or target_tip

                # Detaydan esdegerKodu çek
                if not target_esdeger:
                    detay_res = await self._page.evaluate("""async (param) => {
                        return new Promise((resolve) => {
                            $.ajax({
                                type: "POST",
                                url: "/Ilac/IlacGetir-ajax.aspx",
                                data: {
                                    action: "GetIlacDetay",
                                    kod: param.kod,
                                    isEsdeger: false,
                                    esdeger: "",
                                    isJenerik: false,
                                    jenerikId: "",
                                    tip: null,
                                    ILACTIP: param.tip,
                                    kampKodu: ""
                                },
                                success: function(data) {
                                    try {
                                        resolve(typeof data === 'string' ? JSON.parse(data) : data);
                                    } catch(e) { resolve(null); }
                                },
                                error: function() { resolve(null); }
                            });
                        });
                    }""", {"kod": target_kod, "tip": target_tip})

                    if detay_res and detay_res.get("obj"):
                        target_esdeger = str(detay_res["obj"].get("esdegerKodu") or "").strip()
                        j_obj = detay_res["obj"].get("jenerik") or {}
                        target_jenerik = str(j_obj.get("value") or target_jenerik)

            if not target_esdeger:
                return []

            detay_esdeger = await self._page.evaluate("""async (param) => {
                return new Promise((resolve) => {
                    $.ajax({
                        type: "POST",
                        url: "/Ilac/IlacGetir-ajax.aspx",
                        data: {
                            action: "GetIlacDetay",
                            kod: param.kod,
                            isEsdeger: true,
                            esdeger: param.esdegerKodu,
                            isJenerik: false,
                            jenerikId: param.jenerikId,
                            tip: null,
                            ILACTIP: param.tip,
                            kampKodu: ""
                        },
                        success: function(data) {
                            try {
                                resolve(typeof data === 'string' ? JSON.parse(data) : data);
                            } catch(e) {
                                resolve(null);
                            }
                        },
                        error: function() { resolve(null); }
                    });
                });
            }""", {"kod": target_kod, "esdegerKodu": target_esdeger, "jenerikId": target_jenerik, "tip": target_tip})

            if not detay_esdeger or not detay_esdeger.get("obj"):
                return []

            grd = detay_esdeger["obj"].get("grdKampanyalar") or []
            kdv_dict_es = detay_esdeger["obj"].get("kdv") or {}
            kdv_es_val = float(kdv_dict_es.get("val1") or 10.0)
            muadiller: List[Dict[str, Any]] = []
            seen_codes = set()
            curr_kod_str = str(target_kod).strip()

            for g in grd:
                i_kod = str(g.get("ilacKodu") or "").strip()
                if not i_kod or i_kod in seen_codes:
                    continue
                seen_codes.add(i_kod)

                i_ad = str(g.get("ilacAdi") or "").strip()
                raw_fiyat = str(g.get("etiketFiyati") or "0").replace("₺", "").replace(".", "").replace(",", ".").strip()
                psf_val = float(raw_fiyat) if raw_fiyat.replace(".", "", 1).isdigit() else 0.0
                
                raw_top_isk = str(g.get("topIsk") or "0").replace(",", ".").strip()
                if "+" in raw_top_isk:
                    top_isk_val = sum(float(p.strip()) for p in raw_top_isk.split("+") if p.strip().replace(".", "", 1).isdigit())
                else:
                    top_isk_val = float(raw_top_isk) if raw_top_isk.replace(".", "", 1).isdigit() else 0.0

                mf1_val = 0.0
                try:
                    if g.get("mf1Fiyat") is not None:
                        mf1_val = float(str(g.get("mf1Fiyat")).replace(",", "."))
                except Exception:
                    mf1_val = 0.0

                mf_raw = str(g.get("mf") or "YOK").strip()
                parsed_mf = parse_selcuk_mf_html(
                    mf_raw,
                    psf=psf_val,
                    kdv_orani=kdv_es_val,
                    kamu_iskontosu=0.0,
                    mf1_fiyat=mf1_val,
                    top_isk=top_isk_val
                )
                vade_val = f"{g.get('gün') or 30} Gün"
                is_same = (i_kod == curr_kod_str or i_kod == kod_str)

                muadiller.append({
                    "kod": i_kod,
                    "mal_kodu": i_kod,
                    "ad": i_ad,
                    "urun_adi": i_ad,
                    "etiket_fiyati": psf_val,
                    "psf": psf_val,
                    "mf": parsed_mf["mf_metni"],
                    "en_iyi_mf": parsed_mf["en_iyi_mf"],
                    "birim_maliyet_kdvli": parsed_mf["birim_maliyet_kdvli"],
                    "net_birim_maliyet_kdvli": parsed_mf["birim_maliyet_kdvli"],
                    "birim_maliyet": parsed_mf["birim_maliyet"],
                    "net_birim_maliyet": parsed_mf["birim_maliyet"],
                    "kamu_iskontosu": parsed_mf["kamu_iskontosu"],
                    "kamu_fiyati": parsed_mf["ksf"],
                    "ksf": parsed_mf["ksf"],
                    "kamu_kari": parsed_mf["kamu_kari"],
                    "perakende_kari": parsed_mf["perakende_kari"],
                    "kademeler": parsed_mf["kademeler"],
                    "depo": "SELCUK",
                    "vade": vade_val,
                    "iskonto": top_isk_val,
                    "is_current": is_same
                })

            return muadiller
        except Exception as e:
            print(f"[Selçuk] get_equivalents hatası: {e}")
            return []

    def _parse_selcuk_detay(self, basic_info: Dict[str, Any], detail: Dict[str, Any], query: str) -> DepoUrunSarti:
        kod = str(basic_info.get("kodu", ""))
        ad = detail.get("ad") or basic_info.get("ad", "")
        barkod = detail.get("barkod") or query
        
        stok_durumu_val = basic_info.get("stokDurumu", 0)
        stok_durumu = StokDurumu.VAR if stok_durumu_val == 1 else StokDurumu.YOK

        dsf = float(detail.get("depocuFiyati") or 0.0)
        psf = float(detail.get("SonFiyat") or detail.get("etiketFiyati") or 0.0)
        kdv_dict = detail.get("kdv") or {}
        kdv_orani = float(kdv_dict.get("val1") or 10.0)

        # Soğuk Zincir Tespiti
        saklama = str(detail.get("saklama") or "")
        saklamastr = str(detail.get("saklamastr") or "").lower()
        is_soguk = (saklama == "S" or "soğuk" in saklamastr or "soguk" in saklamastr or "2-8" in saklamastr or "+2" in saklamastr)

        # SGK Kamu İskontosu ve Eczacı Kârı
        raw_kurum_isk = str(detail.get("kurumIskontosu") or "0").replace(",", ".").strip()
        kamu_iskontosu = float(raw_kurum_isk) if raw_kurum_isk.replace(".", "", 1).isdigit() else 0.0
        eczaci_kari = float(detail.get("kar") or 0.0)
        esdeger_kodu = str(detail.get("esdegerKodu") or "").strip() or None

        # Kampanyalar, MF ve İskonto bilgisi
        kampanyalar = detail.get("kampanyalar") or []
        grd_kampanyalar = detail.get("grdKampanyalar") or []
        mf_text = "YOK"
        vade = 30
        en_iyi_net = dsf
        ticari_iskonto = 0.0
        kampanya_notu = ""

        # 1. grdKampanyalar üzerinden iskonto ve vadeleri çek
        if grd_kampanyalar:
            g_kamp = grd_kampanyalar[0]
            vade = int(g_kamp.get("gün") or 30)
            top_isk = str(g_kamp.get("topIsk", "0")).replace(",", ".").strip()
            if "+" in top_isk:
                parts = top_isk.split("+")
                ticari_iskonto = sum(float(p.strip()) for p in parts if p.strip().replace(".", "", 1).isdigit())
            elif top_isk.replace(".", "", 1).isdigit():
                ticari_iskonto = float(top_isk)
            if g_kamp.get("mf1Fiyat"):
                en_iyi_net = float(g_kamp.get("mf1Fiyat"))

            # grdKampanyalar içindeki canlı MF butonlarını/metnini ayrıştır
            mf_raw_grd = str(g_kamp.get("mf") or "").strip()
            if mf_raw_grd and mf_raw_grd != "YOK":
                parsed_g = parse_selcuk_mf_html(mf_raw_grd, psf=psf, kdv_orani=kdv_orani, kamu_iskontosu=kamu_iskontosu)
                if parsed_g.get("mf_metni") and parsed_g["mf_metni"] != "YOK":
                    mf_text = parsed_g["mf_metni"]
                    if parsed_g.get("birim_maliyet") and parsed_g["birim_maliyet"] > 0:
                        en_iyi_net = min(en_iyi_net, parsed_g["birim_maliyet"]) if en_iyi_net > 0 else parsed_g["birim_maliyet"]

        # 2. kampanyalar listesi üzerinden MF ve ek iskontoları çek
        if kampanyalar:
            kamp = kampanyalar[0]
            vade = int(kamp.get("vadeGun") or vade)
            miktarlar = [m for m in kamp.get("miktar", []) if m > 0]
            mfler = [f for f in kamp.get("mf", []) if f > 0]
            net_fiyatlar = [nf for nf in kamp.get("netFiyati", []) if nf > 0]

            isk1 = float(str(kamp.get("iskonto1_Oran") or 0).replace(",", "."))
            isk2 = float(str(kamp.get("iskonto2_Oran") or 0).replace(",", "."))
            pesin_isk = float(str(kamp.get("pesinIskonto") or 0).replace(",", "."))
            kamp_isk_list = [float(str(x or 0).replace(",", ".")) for x in kamp.get("kampIskonto_Oranlari", []) if float(str(x or 0).replace(",", ".")) > 0]
            
            if kamp_isk_list:
                ticari_iskonto = max(ticari_iskonto, max(kamp_isk_list))
            if (isk1 + isk2) > 0:
                ticari_iskonto = max(ticari_iskonto, isk1 + isk2)
            if pesin_isk > 0:
                ticari_iskonto = max(ticari_iskonto, pesin_isk)

            if miktarlar and mfler:
                mf_kademeleri = [f"{m}+{f}" for m, f in zip(miktarlar, mfler)]
                mf_text = " / ".join(mf_kademeleri)
                if net_fiyatlar:
                    en_iyi_net = min(net_fiyatlar)
            elif net_fiyatlar:
                en_iyi_net = min(net_fiyatlar)

        # 3. MF ve ticari iskonto korelasyonu (MF varken de iskonto kontrolü)
        pairs = CostCalculator.parse_mf_pairs(mf_text)
        best_mf_carpan = min((a / (a + h)) for a, h in pairs) if pairs else 1.0
        expected_net_mf = dsf * best_mf_carpan

        if dsf > 0 and en_iyi_net > 0 and expected_net_mf > 0:
            if en_iyi_net < (expected_net_mf - 0.05):
                derived_isk = round((1.0 - (en_iyi_net / expected_net_mf)) * 100.0, 2)
                ticari_iskonto = max(ticari_iskonto, derived_isk)

        # Kampanya notunu oluştur
        notlar = [f"{vade} Gün Vade"]
        if mf_text != "YOK":
            notlar.append(f"MF: {mf_text}")
        if ticari_iskonto > 0:
            notlar.append(f"İsk: %{ticari_iskonto}")
        kampanya_notu = " • ".join(notlar)

        # Maliyet hesapla (Ticari iskonto dahil)
        maliyet = CostCalculator.calculate(
            dsf=dsf if dsf > 0 else en_iyi_net,
            psf=psf,
            kdv_orani=kdv_orani,
            mf_str=mf_text,
            ticari_iskonto=ticari_iskonto,
            vade_gun=vade
        )

        final_net = min(en_iyi_net, maliyet.net_birim_maliyet) if (en_iyi_net > 0 and maliyet.net_birim_maliyet > 0) else maliyet.net_birim_maliyet
        final_net_kdvli = round(final_net * (1.0 + (kdv_orani / 100.0)), 2)

        return DepoUrunSarti(
            depo=DepoKodu.SELCUK,
            depo_adi=self.depo_adi,
            barkod=barkod,
            urun_id=kod,
            urun_adi=ad,
            stok_durumu=stok_durumu,
            stok_adedi=None,
            depocu_satis_fiyati=round(dsf, 2),
            perakende_satis_fiyati=round(psf, 2),
            kdv_orani=kdv_orani,
            mf_metni=mf_text,
            kademeler=maliyet.kademeler,
            ticari_iskonto=round(ticari_iskonto, 2),
            vade_gun=vade,
            net_birim_maliyet=round(final_net, 2),
            net_birim_maliyet_kdvli=final_net_kdvli,
            toplam_indirim_yuzdesi=maliyet.toplam_iskonto_orani,
            ozel_kampanya_notu=kampanya_notu,
            soguk_zincir=is_soguk,
            kamu_iskontosu=kamu_iskontosu,
            eczaci_kari=eczaci_kari,
            esdeger_kodu=esdeger_kodu
        )

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """Selçuk Ecza sepetine ürün ekler (Barkod ve Selçuk Ürün Kodu destekli)."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def _add_to_cart_unlocked(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        if not self.is_logged_in:
            await self._login_unlocked()
        await self._ensure_ready_page()

        target_kod = str(urun_id or "").strip()
        barkod = str(kwargs.get("barkod") or kwargs.get("barcode") or "").strip()
        if len(barkod) == 14 and barkod.startswith("0"):
            barkod = barkod[1:]
        product_name = str(kwargs.get("name") or kwargs.get("urun_adi") or "").strip()

        if not product_name and catalog:
            lookup_bc = barkod or (target_kod if (target_kod.isdigit() and len(target_kod) >= 8) else "")
            if lookup_bc:
                prod = catalog.get_by_barcode(lookup_bc)
                if not prod and len(lookup_bc) == 14 and lookup_bc.startswith("0"):
                    prod = catalog.get_by_barcode(lookup_bc[1:])
                if prod and prod.get("name"):
                    product_name = prod["name"]

        res = await self._page.evaluate("""async (param) => {
            function postAsync(url, data, isJson = true) {
                return new Promise((resolve) => {
                    $.ajax({
                        type: 'POST',
                        url: url,
                        timeout: 7000,
                        data: data,
                        dataType: isJson ? 'json' : undefined,
                        success: function(resp) {
                            try {
                                resolve(typeof resp === 'string' && isJson ? JSON.parse(resp) : resp);
                            } catch(e) { resolve(resp); }
                        },
                        error: function(err) {
                            resolve({ error: true, statusText: err.statusText });
                        }
                    });
                });
            }

            async function getSepet() {
                const s = await postAsync('/Ilac/IlacGetir-ajax.aspx', 'action=SepetDoldur', true);
                return (s && s.obj) ? s.obj : { Siparisler: [], topTutar: 0 };
            }

            async function removeExistingIfNeeded(kod, desiredMiktar, forceRemove = false) {
                const sObj = await getSepet();
                const list = sObj.Siparisler || [];
                const found = list.find(x => String(x.ilacKodu || x.kod) === String(kod));
                if (!found) return { existed: false, matched: false, item: null, sObj };
                const baseQty = parseInt(String(found.adet || '1').split('+')[0].trim(), 10) || 1;
                if (!forceRemove && baseQty === desiredMiktar) {
                    return { existed: true, matched: true, item: found, sObj };
                }
                if (found.id) {
                    await postAsync('/Ilac/IlacGetir-ajax.aspx', 'action=SeciliOlanlariSil&kodlar=' + found.id + ';', true);
                }
                return { existed: true, matched: false, item: null, sObj };
            }

            let targetKod = param.kod || '';
            let ilacTipi = param.ilacTipi || 'B';
            let targetBarcode = param.barkod || '';
            let productName = param.productName || '';

            // 1. Eğer kod 7 karakterden uzunsa (barkod ise) veya barkod verildiyse önce Selçuk ilaç kodunu sorgula
            if (!targetKod || targetKod.length > 7 || isNaN(targetKod)) {
                const searchTarget = targetBarcode || targetKod;
                let candidates = [];
                if (searchTarget) {
                    let searchRes = await postAsync("/Siparis/hizlisiparis-ajax.aspx", {
                        action: "GetUrunler",
                        searchText: searchTarget,
                        isInculude: true,
                        isStoktakiler: false,
                        siralama: "ilacASC",
                        marka: "",
                        baslangicSayfasi: 0,
                        topRowNum: 0,
                        sayfaMaxRowAdet: 5,
                        s: "s"
                    });
                    if (searchRes && searchRes.obj && searchRes.obj.urunler) {
                        candidates = searchRes.obj.urunler;
                    }
                    // GTIN-14 varyasyonu
                    if (candidates.length === 0 && searchTarget.length === 13) {
                        searchRes = await postAsync("/Siparis/hizlisiparis-ajax.aspx", {
                            action: "GetUrunler",
                            searchText: "0" + searchTarget,
                            isInculude: true,
                            isStoktakiler: false,
                            siralama: "ilacASC",
                            marka: "",
                            baslangicSayfasi: 0,
                            topRowNum: 0,
                            sayfaMaxRowAdet: 5,
                            s: "s"
                        });
                        if (searchRes && searchRes.obj && searchRes.obj.urunler) {
                            candidates = searchRes.obj.urunler;
                        }
                    }
                }
                if (candidates.length === 0 && productName) {
                    const cleanWords = productName.replace(/[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]/g, ' ').trim().split(/\\s+/).slice(0, 2).join(' ');
                    if (cleanWords.length >= 2) {
                        let searchRes = await postAsync("/Siparis/hizlisiparis-ajax.aspx", {
                            action: "GetUrunler",
                            searchText: cleanWords,
                            isInculude: true,
                            isStoktakiler: false,
                            siralama: "ilacASC",
                            marka: "",
                            baslangicSayfasi: 0,
                            topRowNum: 0,
                            sayfaMaxRowAdet: 5,
                            s: "s"
                        });
                        if (searchRes && searchRes.obj && searchRes.obj.urunler) {
                            candidates = searchRes.obj.urunler;
                        }
                    }
                }
                if (candidates.length > 0) {
                    targetKod = candidates[0].kodu;
                    ilacTipi = candidates[0].ILACTIP || ilacTipi;
                }
            }

            if (!targetKod || targetKod.length > 7) {
                return { success: false, message: 'Selçuk deposunda ürün kodu tespit edilemedi.' };
            }

            const preCheck = await removeExistingIfNeeded(targetKod, param.miktar, false);
            if (preCheck.matched && preCheck.item) {
                const list = preCheck.sObj.Siparisler || [];
                return {
                    success: true,
                    depo: 'SELCUK',
                    message: (preCheck.item.ilacAdi || 'Ürün') + ' (' + preCheck.item.adet + ' adet) Selçuk Ecza sepetinde hazır.',
                    urun_adi: preCheck.item.ilacAdi || '',
                    urun_kodu: targetKod,
                    miktar: preCheck.item.adet || param.miktar,
                    cart_count: list.length,
                    cart_total: preCheck.sObj.topTutar || null
                };
            }

            // 2. GetIlacDetay
            const detayVeri = await postAsync('/Ilac/IlacGetir-ajax.aspx', {
                action: 'GetIlacDetay',
                kod: targetKod,
                isEsdeger: false,
                esdeger: '',
                isJenerik: false,
                jenerikId: '',
                tip: null,
                ILACTIP: ilacTipi,
                kampKodu: ''
            });

            if (!detayVeri || !detayVeri.obj) {
                return { success: false, message: 'Ürün detayı alınamadı.' };
            }
            const obj = detayVeri.obj;
            if (!obj.satilabilir) {
                return { success: false, message: (obj.ad || 'Bu ürün') + ' şu an Selçuk deposunda satılabilir durumda değil.' };
            }
            const kamp = (obj.kampanyalar && obj.kampanyalar.length > 0) ? obj.kampanyalar[0] : {};
            const grd = (obj.grdKampanyalar && obj.grdKampanyalar.length > 0) ? obj.grdKampanyalar[0] : {};

            let satisSekli = '';
            if (param.satisSekli && param.satisSekli !== 'A6') {
                satisSekli = param.satisSekli;
            } else if (kamp.satisSekli) {
                satisSekli = kamp.satisSekli;
            } else if (grd.satisSekli) {
                satisSekli = grd.satisSekli;
            } else if (obj.satisSekli) {
                satisSekli = obj.satisSekli;
            } else {
                satisSekli = param.satisSekli || 'A6';
            }

            const etiketRaw = grd.etiketFiyati || obj.SonFiyat || obj.etiketFiyati || 0;
            const etiketStr = String(etiketRaw).replace('.', ',');

            async function tryAdd(targetSatisSekli) {
                let cepSube = (kamp && kamp.cepSube) || (grd && grd.cepSube) || obj.cepSube || '05';
                let subeMiktar = param.miktar;

                const subelerData = 'action=GetSubeler&kod=' + targetKod +
                    '&miktar=' + param.miktar +
                    '&satisSekli=' + targetSatisSekli +
                    '&etiketFiyati=' + encodeURIComponent(etiketStr) +
                    '&miad=&onerilenFiyat=' + encodeURIComponent(etiketStr) +
                    '&tip=&ILACTIP=' + ilacTipi +
                    '&ekstraMf=&ekstraIskonto=&siparisNotu=';
                let subeler = await postAsync('/Ilac/IlacGetir-ajax.aspx', subelerData, true);

                if (subeler && (subeler.hataId === 9 || (subeler.hataStr && subeler.hataStr.includes('mevcuttur')))) {
                    await removeExistingIfNeeded(targetKod, param.miktar, true);
                    subeler = await postAsync('/Ilac/IlacGetir-ajax.aspx', subelerData, true);
                }

                if (subeler && subeler.hataId === 0) {
                    if (!subeler.obj || (Array.isArray(subeler.obj) && subeler.obj.length === 0)) {
                        const checkS = await getSepet();
                        const inCart = (checkS.Siparisler || []).find(x => String(x.ilacKodu || x.kod) === String(targetKod));
                        if (inCart) {
                            return { success: true, item: inCart, sObj: checkS };
                        }
                    } else if (Array.isArray(subeler.obj) && subeler.obj.length > 0) {
                        const validBranches = subeler.obj.filter(b => {
                            const kVal = parseInt(String(b.karsilanacak || '0').split('+')[0].trim(), 10) || 0;
                            return kVal > 0;
                        });
                        const branch = validBranches.find(b => b.chk) || validBranches.find(b => b.kendiCep === '1') || validBranches[0] || subeler.obj[0];
                        if (branch && branch.cepSube) cepSube = branch.cepSube;
                        if (branch && branch.karsilanacak !== undefined && branch.karsilanacak !== null) {
                            let k = String(branch.karsilanacak);
                            if (k.includes('+')) k = k.split('+')[0];
                            const parsedK = parseInt(k.trim(), 10);
                            if (!isNaN(parsedK) && parsedK > 0) {
                                subeMiktar = parsedK;
                            } else if (parsedK === 0) {
                                return { success: false, hataStr: (obj.ad || 'Ürün') + ' için şubede karşılanabilecek stok bulunamadı.' };
                            }
                        }
                    }
                } else if (subeler && subeler.hataStr) {
                    return { success: false, hataStr: subeler.hataStr };
                }

                const dataStr = 'action=SiparisEkle&kod=' + targetKod +
                    '&miktar=' + subeMiktar +
                    '&satisSekli=' + targetSatisSekli +
                    '&etiketFiyati=' + encodeURIComponent(etiketStr) +
                    '&ILACTIP=' + ilacTipi +
                    '&depoId=' + cepSube +
                    '&tip=&miad=&onerilenFiyat=' + encodeURIComponent(etiketStr) +
                    '&ekstraMf=&ekstraIskonto=&siparisNotu=';

                const ekleVeri = await postAsync('/Ilac/IlacGetir-ajax.aspx', dataStr, true);
                if (!ekleVeri || ekleVeri.hataId !== 0) {
                    return { success: false, hataStr: (ekleVeri && ekleVeri.hataStr) || 'Sipariş eklenirken hata oluştu.' };
                }

                const finalS = await getSepet();
                const finalItem = (finalS.Siparisler || []).find(x => String(x.ilacKodu || x.kod) === String(targetKod));
                if (!finalItem) {
                    return { success: false, hataStr: (obj.ad || 'Ürün') + ' istenen miktarda (' + param.miktar + ') şube stoğu tarafından karşılanamadı.' };
                }
                return { success: true, item: finalItem, sObj: finalS };
            }

            let addRes = await tryAdd(satisSekli);
            if (!addRes.success) {
                const fallbacks = [kamp.satisSekli, grd.satisSekli, obj.satisSekli, 'M2', 'A6', '01', 'E3'].filter(s => s && s !== satisSekli);
                for (const fb of fallbacks) {
                    const retryRes = await tryAdd(fb);
                    if (retryRes.success) {
                        addRes = retryRes;
                        satisSekli = fb;
                        break;
                    }
                }
            }

            if (!addRes.success) {
                return { success: false, message: addRes.hataStr || 'Selçuk sepetine eklenemedi.' };
            }

            const sObj = addRes.sObj || await getSepet();
            const siparisler = sObj.Siparisler || [];
            const found = addRes.item || siparisler.find(s => String(s.ilacKodu || s.kod) === String(targetKod));
            const addedItemName = (found && found.ilacAdi) || obj.ad || '';
            const addedMiktar = (found && found.adet) || param.miktar;

            return {
                success: true,
                depo: 'SELCUK',
                message: addedItemName + ' (' + addedMiktar + ' adet) başarıyla Selçuk Ecza sepetine eklendi.',
                urun_adi: addedItemName,
                urun_kodu: targetKod,
                miktar: addedMiktar,
                cart_count: siparisler.length,
                cart_total: sObj.topTutar || null
            };
        }""", {
            "kod": target_kod,
            "barkod": barkod,
            "productName": product_name,
            "miktar": int(miktar),
            "satisSekli": kwargs.get("satis_sekli", ""),
            "ilacTipi": kwargs.get("ilac_tipi", "B")
        })

        if isinstance(res, dict) and res.get("success"):
            import time as _t
            parsed_m = _parse_cart_adet(res.get("miktar") or miktar)
            self._last_added_items.append({
                "barcode": barkod,
                "miktar": parsed_m["miktar"],
                "name": str(res.get("urun_adi") or ""),
                "urun_id": str(res.get("urun_kodu") or urun_id or "")
            })
            self._last_added_time = _t.time()

        return res

    async def bulk_add_to_cart(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Selçuk Ecza Deposu sepetine toplu (batch) ürün ekler.
        items: [{"barcode": "...", "miktar": 1, "name": "...", "urun_id": "..."}]
        """
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._bulk_add_to_cart_unlocked(items, update_cache=True)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def _bulk_add_to_cart_unlocked(self, items: List[Dict[str, Any]], update_cache: bool = True) -> Dict[str, Any]:
        if not items:
            return {
                "success": False,
                "message": "Eklenecek ürün listesi boş.",
                "total_items": 0,
                "success_count": 0,
                "failed_count": 0,
                "total_amount": 0.0,
                "items": []
            }

        if not self.is_logged_in:
            await self._login_unlocked()
        await self._ensure_ready_page()

        clean_items = []
        for it in items:
            bc = str(it.get("barcode") or it.get("barkod") or "").strip()
            if len(bc) == 14 and bc.startswith("0"):
                bc = bc[1:]
            qty_info = _parse_cart_adet(it.get("miktar") or it.get("quantity") or 1)
            qty = qty_info["miktar"]
            name = str(it.get("name") or it.get("urun_adi") or "").strip()
            u_id = str(it.get("urun_id") or it.get("kod") or "").strip()
            clean_items.append({
                "barcode": bc,
                "miktar": max(1, qty),
                "name": name,
                "urun_id": u_id
            })

        results = await self._page.evaluate("""async (items) => {
            function postAsync(url, data, isJson = true) {
                return new Promise((resolve) => {
                    $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        timeout: 7000,
                        dataType: isJson ? 'json' : undefined,
                        success: function(resp) {
                            try {
                                resolve(typeof resp === 'string' && isJson ? JSON.parse(resp) : resp);
                            } catch(e) { resolve(resp); }
                        },
                        error: function(err) {
                            resolve({ error: true, statusText: err.statusText });
                        }
                    });
                });
            }

            async function getSepet() {
                const s = await postAsync('/Ilac/IlacGetir-ajax.aspx', 'action=SepetDoldur', true);
                return (s && s.obj) ? s.obj : { Siparisler: [], topTutar: 0 };
            }

            async function processSingleItem(item) {
                const itemRes = {
                    barcode: item.barcode,
                    name: item.name,
                    miktar: item.miktar,
                    success: false,
                    message: '',
                    urun_adi: item.name,
                    urun_id: item.urun_id || '',
                    net_fiyat: 0,
                    vade: 30,
                    toplam_tutar: 0
                };

                try {
                    let targetKod = item.urun_id || '';
                    let ilacTipi = 'B';

                    // 1. Eğer urun_id geçerli bir Selçuk ilaç kodu değilse barkod ile ara
                    if (!targetKod || targetKod.length > 7 || !/^\\d+$/.test(targetKod)) {
                        let searchTarget = item.barcode || '';
                        let searchRes = null;
                        if (searchTarget) {
                            searchRes = await postAsync('/Siparis/hizlisiparis-ajax.aspx', {
                                action: "GetUrunler",
                                searchText: searchTarget,
                                isInculude: true,
                                isStoktakiler: false,
                                siralama: "ilacASC",
                                marka: "",
                                baslangicSayfasi: 0,
                                topRowNum: 0,
                                sayfaMaxRowAdet: 5,
                                s: "s"
                            });
                        }

                        // GTIN-14 varyasyonu: Eğer 13 haneli barkod bulunamazsa başına 0 ekle
                        if ((!searchRes || !searchRes.obj || !searchRes.obj.urunler || searchRes.obj.urunler.length === 0) && searchTarget.length === 13) {
                            searchRes = await postAsync('/Siparis/hizlisiparis-ajax.aspx', {
                                action: "GetUrunler",
                                searchText: "0" + searchTarget,
                                isInculude: true,
                                isStoktakiler: false,
                                siralama: "ilacASC",
                                marka: "",
                                baslangicSayfasi: 0,
                                topRowNum: 0,
                                sayfaMaxRowAdet: 5,
                                s: "s"
                            });
                        }

                        // Barkod ile çıkmazsa ürün adının ilk 2 kelimesi ile dene
                        if ((!searchRes || !searchRes.obj || !searchRes.obj.urunler || searchRes.obj.urunler.length === 0) && item.name) {
                            const cleanWords = item.name.replace(/[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]/g, ' ').trim().split(/\\s+/).slice(0, 2).join(' ');
                            if (cleanWords.length >= 3) {
                                searchRes = await postAsync('/Siparis/hizlisiparis-ajax.aspx', {
                                    action: "GetUrunler",
                                    searchText: cleanWords,
                                    isInculude: true,
                                    isStoktakiler: false,
                                    siralama: "ilacASC",
                                    marka: "",
                                    baslangicSayfasi: 0,
                                    topRowNum: 0,
                                    sayfaMaxRowAdet: 5,
                                    s: "s"
                                });
                            }
                        }

                        if (!searchRes || !searchRes.obj || !searchRes.obj.urunler || searchRes.obj.urunler.length === 0) {
                            itemRes.message = 'Selçuk deposunda ürün bulunamadı.';
                            return itemRes;
                        }

                        targetKod = searchRes.obj.urunler[0].kodu;
                        ilacTipi = searchRes.obj.urunler[0].ILACTIP || ilacTipi;
                        if (searchRes.obj.urunler[0].adi) {
                            itemRes.urun_adi = searchRes.obj.urunler[0].adi;
                        }
                    }

                    itemRes.urun_id = targetKod;

                    // 2. GetIlacDetay
                    const detayVeri = await postAsync('/Ilac/IlacGetir-ajax.aspx', {
                        action: 'GetIlacDetay',
                        kod: targetKod,
                        isEsdeger: false,
                        esdeger: '',
                        isJenerik: false,
                        jenerikId: '',
                        tip: null,
                        ILACTIP: ilacTipi,
                        kampKodu: ''
                    });

                    if (!detayVeri || !detayVeri.obj) {
                        itemRes.message = 'Ürün detayına ulaşılamadı.';
                        return itemRes;
                    }

                    const obj = detayVeri.obj;
                    itemRes.urun_adi = obj.ad || itemRes.urun_adi;

                    if (!obj.satilabilir) {
                        itemRes.message = 'Selçuk deposunda şu an satılabilir durumda değil (Stok Yok/Pasif).';
                        return itemRes;
                    }

                    const kamp = (obj.kampanyalar && obj.kampanyalar.length > 0) ? obj.kampanyalar[0] : {};
                    const grd = (obj.grdKampanyalar && obj.grdKampanyalar.length > 0) ? obj.grdKampanyalar[0] : {};

                    let satisSekli = kamp.satisSekli || grd.satisSekli || obj.satisSekli || 'M2';
                    const etiketRaw = grd.etiketFiyati || obj.SonFiyat || obj.etiketFiyati || 0;
                    const etiketStr = String(etiketRaw).replace('.', ',');

                    async function tryAddBulk(targetSatisSekli) {
                        let cepSube = (kamp && kamp.cepSube) || (grd && grd.cepSube) || obj.cepSube || '05';
                        let subeMiktar = item.miktar;

                        const subelerData = 'action=GetSubeler&kod=' + targetKod +
                            '&miktar=' + item.miktar +
                            '&satisSekli=' + targetSatisSekli +
                            '&etiketFiyati=' + encodeURIComponent(etiketStr) +
                            '&miad=&onerilenFiyat=' + encodeURIComponent(etiketStr) +
                            '&tip=&ILACTIP=' + ilacTipi +
                            '&ekstraMf=&ekstraIskonto=&siparisNotu=';
                        let subeler = await postAsync('/Ilac/IlacGetir-ajax.aspx', subelerData, true);

                        if (subeler && (subeler.hataId === 9 || (subeler.hataStr && subeler.hataStr.includes('mevcuttur')))) {
                            const curS = await getSepet();
                            const ex = (curS.Siparisler || []).find(x => String(x.ilacKodu || x.kod) === String(targetKod));
                            if (ex) {
                                const exBase = parseInt(String(ex.adet || '1').split('+')[0].trim(), 10) || 1;
                                if (exBase === item.miktar) {
                                    return { success: true, actualQty: exBase };
                                }
                                if (ex.id) {
                                    await postAsync('/Ilac/IlacGetir-ajax.aspx', 'action=SeciliOlanlariSil&kodlar=' + ex.id + ';', true);
                                    subeler = await postAsync('/Ilac/IlacGetir-ajax.aspx', subelerData, true);
                                }
                            }
                        }

                        if (subeler && subeler.hataId === 0) {
                            if (!subeler.obj || (Array.isArray(subeler.obj) && subeler.obj.length === 0)) {
                                return { success: true, actualQty: item.miktar };
                            } else if (Array.isArray(subeler.obj) && subeler.obj.length > 0) {
                                const validBranches = subeler.obj.filter(b => {
                                    const kVal = parseInt(String(b.karsilanacak || '0').split('+')[0].trim(), 10) || 0;
                                    return kVal > 0;
                                });
                                const branch = validBranches.find(b => b.chk) || validBranches.find(b => b.kendiCep === '1') || validBranches[0] || subeler.obj[0];
                                if (branch && branch.cepSube) cepSube = branch.cepSube;
                                if (branch && branch.karsilanacak !== undefined && branch.karsilanacak !== null) {
                                    let k = String(branch.karsilanacak);
                                    if (k.includes('+')) k = k.split('+')[0];
                                    const parsedK = parseInt(k.trim(), 10);
                                    if (!isNaN(parsedK) && parsedK > 0) {
                                        subeMiktar = parsedK;
                                    } else if (parsedK === 0) {
                                        return { success: false, hataStr: 'Şubede karşılanabilecek stok bulunamadı.' };
                                    }
                                }
                            }
                        } else if (subeler && subeler.hataStr) {
                            return { success: false, hataStr: subeler.hataStr };
                        }

                        const dataStr = 'action=SiparisEkle&kod=' + targetKod +
                            '&miktar=' + subeMiktar +
                            '&satisSekli=' + targetSatisSekli +
                            '&etiketFiyati=' + encodeURIComponent(etiketStr) +
                            '&ILACTIP=' + ilacTipi +
                            '&depoId=' + cepSube +
                            '&tip=&miad=&onerilenFiyat=' + encodeURIComponent(etiketStr) +
                            '&ekstraMf=&ekstraIskonto=&siparisNotu=';
                        const ekleVeri = await postAsync('/Ilac/IlacGetir-ajax.aspx', dataStr, true);
                        if (ekleVeri && ekleVeri.hataId === 0) {
                            return { success: true, actualQty: subeMiktar };
                        }
                        return { success: false, hataStr: (ekleVeri && ekleVeri.hataStr) || 'Sepete ekleme reddedildi.' };
                    }

                    let addRes = await tryAddBulk(satisSekli);

                    if (!addRes.success) {
                        const fallbacks = [kamp.satisSekli, grd.satisSekli, obj.satisSekli, 'M2', 'A6', '01', 'E3'].filter(s => s && s !== satisSekli);
                        for (const fb of fallbacks) {
                            const retryRes = await tryAddBulk(fb);
                            if (retryRes.success) {
                                addRes = retryRes;
                                satisSekli = fb;
                                break;
                            }
                        }
                    }

                    if (addRes.success) {
                        const rawFiyat = parseFloat(String(etiketRaw).replace(',', '.')) || (kamp.fiyat || 0);
                        const effQty = addRes.actualQty || item.miktar;
                        itemRes.success = true;
                        itemRes.miktar = effQty;
                        itemRes.net_fiyat = rawFiyat;
                        itemRes.toplam_tutar = round2(itemRes.net_fiyat * effQty);
                        itemRes.message = `${effQty} Adet Selçuk sepetine eklendi (${satisSekli})`;
                    } else {
                        itemRes.message = addRes.hataStr || 'Sepete ekleme reddedildi.';
                    }

                    return itemRes;
                } catch(err) {
                    itemRes.message = 'Hata: ' + err.toString();
                    return itemRes;
                }
            }

            function round2(v) { return Math.round(v * 100) / 100; }

            const results = [];
            for (let i = 0; i < items.length; i++) {
                const res = await processSingleItem(items[i]);
                results.push(res);
                await new Promise(r => setTimeout(r, 20));
            }

            // Sepeti yenile
            try {
                await postAsync('/Ilac/IlacGetir-ajax.aspx', 'action=SepetDoldur', true);
            } catch(e) {}

            return results;
        }""", clean_items)

        success_items = [r for r in results if r.get("success")]
        failed_items = [r for r in results if not r.get("success")]
        total_amount = round(sum(r.get("toplam_tutar", 0) for r in success_items), 2)

        if update_cache and success_items:
            import time as _t
            self._last_added_items = [
                {
                    "barcode": r.get("barcode") or "",
                    "miktar": _parse_cart_adet(r.get("miktar") or 1)["miktar"],
                    "name": r.get("urun_adi") or r.get("name") or "",
                    "urun_id": r.get("urun_id") or ""
                }
                for r in success_items
            ]
            self._last_added_time = _t.time()

        return {
            "success": len(success_items) > 0,
            "depo": "SELCUK",
            "message": f"Selçuk Ecza sepetine {len(success_items)}/{len(items)} kalem ürün taslak olarak eklendi (Toplam: {total_amount:,.2f} ₺).",
            "total_items": len(items),
            "success_count": len(success_items),
            "failed_count": len(failed_items),
            "total_amount": total_amount,
            "items": results
        }

    def get_portal_urls(self) -> dict:
        """Selçuk WebDepo sepet ve sipariş onaylama web arayüzü linklerini döndürür."""
        return {
            "cart_url": "https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx",
            "checkout_url": "https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx"
        }

    async def get_cart_status(self) -> Dict[str, Any]:
        """Selçuk Ecza sepetinin anlık içeriğini ve toplam tutarını sorgular."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=True)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def _get_cart_status_unlocked(self, allow_sepet_page: bool = True, auto_restore: bool = False) -> Dict[str, Any]:
        if not self.is_logged_in:
            await self._login_unlocked()
        await self._ensure_ready_page(allow_sepet_page=allow_sepet_page)

        async def _fetch_sepet_ajax():
            return await self._page.evaluate("""async () => {
                return new Promise((resolve) => {
                    if (typeof window.jQuery === 'undefined') {
                        return resolve({ error: 'no_jquery' });
                    }
                    $.ajax({
                        type: 'POST',
                        dataType: 'json',
                        timeout: 6000,
                        data: 'action=SepetDoldur',
                        url: '/Ilac/IlacGetir-ajax.aspx',
                        success: function(veri) {
                            try {
                                resolve(typeof veri === 'string' ? JSON.parse(veri) : veri);
                            } catch(e) { resolve(veri); }
                        },
                        error: function(err) { resolve({ error: err.statusText || 'Ağ hatası' }); }
                    });
                });
            }""")

        res = await _fetch_sepet_ajax()

        # Eğer jQuery veya sayfa geçişi nedeniyle hata döndüyse 1 kez sayfayı yenileyip tekrar dene
        if not isinstance(res, dict) or res.get("error") or "obj" not in res:
            await self._ensure_ready_page(allow_sepet_page=False)
            res = await _fetch_sepet_ajax()

        def _build_cart_items(siparis_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            parsed_list = []
            for s in siparis_list:
                adet_info = _parse_cart_adet(s.get("adet"))
                tutar_val = clean_float(s.get("tutar"))
                bf_val = clean_float(s.get("birimFiyat") or s.get("fiyat"))
                if bf_val <= 0 and tutar_val > 0 and adet_info["miktar"] > 0:
                    bf_val = round(tutar_val / adet_info["miktar"], 2)
                parsed_list.append({
                    "id": str(s.get("id") or ""),
                    "kod": str(s.get("ilacKodu") or s.get("kod") or ""),
                    "ad": str(s.get("ilacAdi") or s.get("ad") or ""),
                    "miktar": adet_info["miktar"],
                    "mf_hediye": adet_info["mf_hediye"],
                    "toplam_adet": adet_info["toplam_adet"],
                    "adet_label": adet_info["adet_label"],
                    "birim_fiyat": bf_val,
                    "tutar": tutar_val,
                    "satis_sekli": str(s.get("satisSekli") or "")
                })
            return parsed_list

        obj = (res.get("obj") or {}) if isinstance(res, dict) else {}
        siparisler = obj.get("Siparisler") or []
        items = _build_cart_items(siparisler)

        # Eğer sepet boş görünüyorsa ama son 20 dakika içinde sepete ürün eklendiyse (oturum sıfırlanması vb.), otomatik geri yükle
        import time as _t
        if auto_restore and not items and self._last_added_items and (_t.time() - self._last_added_time < 1200):
            print(f"[Selçuk] Sepet boş döndü fakat son eklenen {len(self._last_added_items)} ürün önbellekte mevcut, otomatik yeniden ekleniyor...")
            await self._bulk_add_to_cart_unlocked(self._last_added_items, update_cache=False)
            res2 = await _fetch_sepet_ajax()
            obj = (res2.get("obj") or {}) if isinstance(res2, dict) else {}
            siparisler = obj.get("Siparisler") or []
            items = _build_cart_items(siparisler)

        top_tutar = clean_float(obj.get("topTutar")) or sum(it["tutar"] for it in items)

        return {
            "success": True,
            "depo": "SELCUK",
            "depo_adi": self.depo_adi,
            "supported": True,
            "item_count": len(items),
            "total_amount": round(top_tutar, 2),
            "items": items,
            "cart_url": "https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx",
            "checkout_url": "https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx"
        }

    async def clear_cart(self) -> Dict[str, Any]:
        """Selçuk Ecza sepetindeki tüm ürünleri temizler."""
        self._cart_busy += 1
        try:
            async with self._lock:
                self._last_added_items = []
                self._last_added_time = 0.0
                status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                items = status.get("items", [])
                if not items:
                    return {"success": True, "message": "Selçuk sepeti zaten boş.", "cleared_count": 0}

                ids_str = ";".join([it["id"] for it in items if it.get("id")]) + ";"
                await self._page.evaluate("""async (param) => {
                    return new Promise((resolve) => {
                        $.ajax({
                            type: 'POST',
                            dataType: 'json',
                            timeout: 6000,
                            data: 'action=SeciliOlanlariSil&kodlar=' + param.kodlar,
                            url: '/Ilac/IlacGetir-ajax.aspx',
                            success: function(veri) { resolve(veri); },
                            error: function(err) { resolve({ error: err.statusText }); }
                        });
                    });
                }""", {"kodlar": ids_str})

                new_status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                return {
                    "success": new_status.get("item_count", 0) == 0,
                    "message": f"Selçuk sepeti başarıyla temizlendi ({len(items)} kalem silindi).",
                    "cleared_count": len(items)
                }
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def finalize_order(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        """
        Siparişi Selçuk Ecza sepetine ekler (gerekirse), sepet üzerinden SiparisOnay ekranına geçiş yapar
        ve depoya onaylayarak kesin sipariş oluşturur.
        """
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._finalize_order_unlocked(urun_id=urun_id, miktar=miktar, force=force, **kwargs)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def _finalize_order_unlocked(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        if True:
            if not self.is_logged_in:
                await self._login_unlocked()
            await self._ensure_ready_page(allow_sepet_page=True)

            # 1. Mevcut sepet durumunu al (auto_restore=True ile son eklenenler düşmüşse geri yükler)
            cart_status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=True)
            existing_items = cart_status.get("items", [])

            # 1b. Eğer hala boşsa ve kwargs içinde beklenen items listesi gönderildiyse onları ekle
            fallback_items = kwargs.get("items") or []
            if not existing_items and fallback_items and isinstance(fallback_items, list):
                print(f"[Selçuk] Finalize sırasında sepet boş, gönderilen {len(fallback_items)} kalem yeniden ekleniyor...")
                await self._bulk_add_to_cart_unlocked(fallback_items, update_cache=True)
                cart_status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                existing_items = cart_status.get("items", [])

            # 2. Eğer tekil ürün belirtildiyse ve henüz sepette yoksa (veya miktarı değiştiyse) sepete ekle/güncelle
            if urun_id:
                u_clean = str(urun_id).strip()
                req_miktar = _parse_cart_adet(miktar)["miktar"]
                resolved_kod = u_clean
                for la in reversed(self._last_added_items):
                    if u_clean in (str(la.get("barcode") or ""), str(la.get("urun_id") or "")):
                        if la.get("urun_id"):
                            resolved_kod = str(la["urun_id"])
                        break

                matched_cart_item = None
                for it in existing_items:
                    it_kod = str(it.get("kod") or "").strip()
                    it_id = str(it.get("id") or "").strip()
                    if it_kod in (u_clean, resolved_kod) or it_id == u_clean:
                        matched_cart_item = it
                        break

                if not matched_cart_item or int(matched_cart_item.get("miktar") or 1) != req_miktar:
                    added_res = await self._add_to_cart_unlocked(urun_id=urun_id, miktar=req_miktar, **kwargs)
                    if not added_res.get("success") and not existing_items:
                        return {
                            "success": False,
                            "message": f"Ürün sepete eklenemediği için sipariş sonlandırılamadı: {added_res.get('message')}"
                        }
                    cart_status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                    existing_items = cart_status.get("items", [])

            # 3. Sepet kontrolü: Eğer sepette hiçbir ürün yoksa
            if not existing_items:
                return {
                    "success": False,
                    "message": "Selçuk sepetinde siparişe dönüştürülecek ürün bulunamadı."
                }

            # 4. Güvenlik Kontrolü: Sepette birden fazla kalem varsa ve 'force' onay verilmemişse kullanıcıya bildir
            if len(existing_items) > 1 and not force:
                return {
                    "success": False,
                    "need_confirmation": True,
                    "item_count": len(existing_items),
                    "items": existing_items,
                    "total_amount": cart_status.get("total_amount", 0.0),
                    "message": f"Selçuk Ecza sepetinizde önceden eklenmiş {len(existing_items)} farklı ürün bulunmaktadır (Toplam: {cart_status.get('total_amount', 0.0):,.2f} ₺). Tüm sepeti depoya göndermek için onay veriniz."
                }

            # 5. Şimdi sepet.aspx sayfasına git (get_cart_status sonrasında gidiyoruz ki hizlisiparis'e geri dönmesin!)
            try:
                await self._page.goto("https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx", wait_until="domcontentloaded", timeout=15000)
                await asyncio.sleep(0.5)
            except Exception:
                pass

            # Sepet sayfasındaki olası hata/uyarı modalını kontrol et
            pre_alert = await self._page.evaluate('''() => {
                const m = document.querySelector('.modal.show, #mesajModal.show, .alert-danger, .bootbox.show');
                return m ? m.innerText.trim() : null;
            }''')
            if pre_alert and any(w in pre_alert.lower() for w in ["karşılanamadı", "karsilanamadi", "iptal", "stok"]):
                return {
                    "success": False,
                    "message": f"Selçuk Ecza Deposu Uyarısı: {pre_alert}",
                    "cart_url": "https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx"
                }

            # 6. Sepetten SiparisOnay.aspx sayfasına geçiş yap
            try:
                if not getattr(self, "_dialog_hooked", False):
                    self._page.on("dialog", lambda dialog: asyncio.create_task(dialog.accept()))
                    self._dialog_hooked = True
            except Exception:
                pass

            try:
                onayla_link = await self._page.wait_for_selector("#ContentPlaceHolder1_btnSiparisiOnayla", timeout=6000)
                if onayla_link:
                    try:
                        async with self._page.expect_navigation(timeout=10000):
                            await onayla_link.click()
                    except Exception:
                        try:
                            async with self._page.expect_navigation(timeout=8000):
                                await self._page.evaluate("__doPostBack('ctl00$ContentPlaceHolder1$btnSiparisiOnayla','')")
                        except Exception:
                            pass
            except Exception:
                pass

            # Eğer açılan bir onay popup'ı (modal) varsa "Evet/Tamam" tıkla
            try:
                await self._page.evaluate('''() => {
                    const btn = document.querySelector('#btnModalEvet, #btnModalTamam, .bootbox-accept, .modal.show .btn-primary, .modal.show .btn-success');
                    if (btn) btn.click();
                }''')
                await asyncio.sleep(1)
            except Exception:
                pass

            # Eğer link tıklaması ile geçmediyse doğrudan gitmeyi dene
            if "siparisonay" not in self._page.url.lower():
                try:
                    await self._page.goto("https://webdepo.selcukecza.com.tr/Siparis/SiparisOnay.aspx", wait_until="domcontentloaded", timeout=12000)
                    await asyncio.sleep(0.5)
                except Exception:
                    pass

            # Geçiş kontrolü: Hala sepet sayfasında mıyız?
            if "siparisonay" not in self._page.url.lower():
                modal_msg = await self._page.evaluate('''() => {
                    const m = document.querySelector('.modal.show, #mesajModal, .alert, .bootbox');
                    return m ? m.innerText.trim() : null;
                }''')
                err_text = modal_msg or "Siparişiniz Selçuk Ecza tarafından karşılanamadı veya şube stoku yetersiz."
                return {
                    "success": False,
                    "message": f"Selçuk Ecza Uyarısı: {err_text}",
                    "cart_url": "https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx"
                }

            # 7. SiparisOnay sayfasında kesin onay butonunu (#ContentPlaceHolder1_btnSiparisOnay) çalıştır
            try:
                onay_btn = await self._page.wait_for_selector("#ContentPlaceHolder1_btnSiparisOnay", timeout=8000)
                if not onay_btn:
                    return {
                        "success": False,
                        "message": "Sipariş onay butonu bulunamadı. Lütfen WebDepo arayüzünden sepetinizi kontrol edin.",
                        "cart_url": "https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx"
                    }

                # Butona tıkla veya __doPostBack ile formu gönder
                try:
                    async with self._page.expect_navigation(timeout=15000):
                        await self._page.evaluate("__doPostBack('ctl00$ContentPlaceHolder1$btnSiparisOnay','')")
                except Exception:
                    try:
                        await self._page.click("#ContentPlaceHolder1_btnSiparisOnay", timeout=5000)
                    except Exception:
                        pass

                # Olası ek modal onayı
                try:
                    await self._page.evaluate('''() => {
                        const btn = document.querySelector('#btnModalEvet, #btnModalTamam, .bootbox-accept, .modal.show .btn-primary');
                        if (btn) btn.click();
                    }''')
                except Exception:
                    pass

                await asyncio.sleep(2)
                current_url = self._page.url
                page_text = await self._page.evaluate("() => document.body.innerText")

                order_info = ""
                for line in page_text.splitlines():
                    l_lower = line.lower()
                    if any(w in l_lower for w in ["sipariş no", "siparis no", "siparişiniz alınmıştır", "başarıyla iletil", "kaydedilmiştir", "proforma numarası"]):
                        order_info = line.strip()
                        break

                if "sno=" in current_url.lower():
                    import re
                    sno_m = re.search(r"sno=(\d+)", current_url, re.IGNORECASE)
                    if sno_m:
                        order_info = f"Sipariş No: {sno_m.group(1)}"

                # Sipariş kesinleşti mi doğrula (Web Siparişlerim listesi kontrolü)
                has_confirmed_order = bool(order_info)
                if not has_confirmed_order:
                    try:
                        await self._page.goto("https://webdepo.selcukecza.com.tr/Siparis/List.aspx", wait_until="domcontentloaded", timeout=10000)
                        list_text = await self._page.evaluate("() => document.body.innerText")
                        import datetime
                        today_str = datetime.date.today().strftime("%d.%m.%Y")
                        if today_str in list_text:
                            has_confirmed_order = True
                            order_info = "Sipariş WebDepo'ya Başarıyla Kaydedildi"
                    except Exception:
                        pass

                if has_confirmed_order:
                    self._last_added_items = []
                    self._last_added_time = 0.0
                    return {
                        "success": True,
                        "depo": "SELCUK",
                        "depo_adi": self.depo_adi,
                        "message": f"Siparişiniz Selçuk Ecza Deposu'na başarıyla iletildi ve kesinleşti! {f'({order_info})' if order_info else ''}".strip(),
                        "current_url": current_url,
                        "order_info": order_info or "Sipariş Onaylandı",
                        "total_amount": cart_status.get("total_amount", 0.0),
                        "items": existing_items,
                        "portal_url": "https://webdepo.selcukecza.com.tr/Siparis/List.aspx"
                    }
                else:
                    post_cart = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                    if post_cart.get("item_count", 0) == 0:
                        # Sepet boşaldıysa sipariş depoya düşmüştür
                        self._last_added_items = []
                        self._last_added_time = 0.0
                        return {
                            "success": True,
                            "depo": "SELCUK",
                            "depo_adi": self.depo_adi,
                            "message": "Siparişiniz Selçuk Ecza Deposu'na başarıyla iletildi ve sepet onaylandı!",
                            "current_url": current_url,
                            "order_info": "Sipariş Onaylandı",
                            "total_amount": cart_status.get("total_amount", 0.0),
                            "items": existing_items,
                            "portal_url": "https://webdepo.selcukecza.com.tr/Siparis/List.aspx"
                        }
                    else:
                        return {
                            "success": False,
                            "message": "Sipariş Selçuk WebDepo tarafından onaylanamadı. Ürünleriniz sepetinizde duruyor, lütfen WebDepo üzerinden sepetinizi kontrol ediniz.",
                            "cart_url": "https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx"
                        }

            except Exception as e:
                return {
                    "success": False,
                    "message": f"Sipariş onaylanırken hata oluştu: {str(e)}. Lütfen WebDepo sepetinizi kontrol ediniz.",
                    "cart_url": "https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx"
                }


    async def close(self):
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
