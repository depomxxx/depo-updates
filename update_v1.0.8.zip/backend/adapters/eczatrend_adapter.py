import asyncio
import json
import logging
from typing import List, Optional, Dict, Any
import httpx

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.core.session_store import SessionStore

logger = logging.getLogger("eczatrend_adapter")

class EczatrendAdapter(BaseDepoAdapter):
    """
    Eczatrend (eczatrend.com) Eczaneler Arası Ortak Alım Grubu & Barem Takas Adaptörü.
    'Grubumun Teklifleri' (menualloffer) sayfasındaki kampanyaları, baremleri,
    hedeflenen adetleri, kalan adetleri ve KDV'li/KDV'siz net birim fiyatları çeker.
    """
    LOGIN_URL = "https://eczatrend.com/gtsp/ajax/login"
    MAIN_URL = "https://eczatrend.com/eczanet/panelNew/main"
    PANEL_URL = "https://eczatrend.com/eczanet/panelNew/main"

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ECZATREND, "Eczatrend Alım Grubu")
        self.username = username.strip()
        self.password = password.strip()
        self.headless = headless
        self.session_data: Optional[Dict[str, Any]] = None
        self._client: Optional[httpx.AsyncClient] = None

    def _get_headers(self) -> Dict[str, str]:
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Origin": "https://eczatrend.com",
            "Referer": "https://eczatrend.com/eczanet/panelNew/main",
            "Content-Type": "application/x-www-form-urlencoded",
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "application/json, text/javascript, */*; q=0.01"
        }

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers=self._get_headers(),
                follow_redirects=True,
                timeout=25.0,
                verify=False
            )
            # Kayıtlı oturumu yükle
            cached = SessionStore.load_state("eczatrend")
            if cached and isinstance(cached, dict) and "cookies" in cached:
                for k, v in cached["cookies"].items():
                    self._client.cookies.set(k, v, domain="eczatrend.com")
                self.session_data = cached
        return self._client

    async def is_session_valid(self) -> bool:
        """Kayıtlı oturum çerezinin geçerli olup olmadığını kontrol eder."""
        client = await self._get_client()
        if "eria_session" not in client.cookies:
            return False

        try:
            payload = {
                "action": "purchaseGrid",
                "page": "0",
                "selectedMenu": "menualloffer",
                "taxFilter": "0"
            }
            resp = await client.post(self.MAIN_URL, data=payload)
            if resp.status_code == 200 and not resp.text.startswith("<"):
                data = resp.json()
                if "data" in data or "firstmes" in data:
                    self.is_logged_in = True
                    return True
        except Exception:
            pass
        return False

    async def login(self) -> bool:
        """Eczatrend B2B ortak alım portalına giriş yapar."""
        if not self.username or not self.password:
            raise ValueError("Eczatrend için Kullanıcı Adı ve Şifre zorunludur.")

        client = await self._get_client()

        # 1. Mevcut çerez hala geçerli mi?
        if await self.is_session_valid():
            logger.info("[Eczatrend] Mevcut oturum aktif, doğrudan devam ediliyor.")
            return True

        logger.info("[Eczatrend] Oturum açılıyor (%s)...", self.username)
        login_payload = {
            "username": self.username,
            "password": self.password,
            "remember": "true"
        }

        try:
            login_headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Origin": "https://eczatrend.com",
                "Referer": "https://eczatrend.com/eczanet/site/sitelogin",
                "X-Requested-With": "XMLHttpRequest"
            }
            resp = await client.post(self.LOGIN_URL, data=login_payload, headers=login_headers)
            if resp.status_code != 200:
                raise RuntimeError(f"Giriş isteği başarısız: HTTP {resp.status_code}")

            res_json = resp.json()
            if not res_json.get("success"):
                err_msg = res_json.get("message") or "Kullanıcı adı veya şifre hatalı."
                raise RuntimeError(f"Eczatrend Giriş Başarısız: {err_msg}")

            # Oturumu kaydet
            cookie_dict = dict(client.cookies)
            state_data = {
                "cookies": cookie_dict,
                "pharmacyName": res_json.get("pharmacyName", ""),
                "userName": res_json.get("userName", ""),
                "userRealName": res_json.get("userRealName", "")
            }
            SessionStore.save_state("eczatrend", state_data)
            self.session_data = state_data
            self.is_logged_in = True
            logger.info("[Eczatrend] Giriş başarılı! Eczane: %s", res_json.get("pharmacyName"))
            return True

        except Exception as e:
            logger.error("[Eczatrend] Giriş hatası: %s", e)
            self.is_logged_in = False
            raise

    async def search_product(self, query: str) -> List[DepoUrunSarti]:
        """
        'Grubumun Teklifleri' (menualloffer) listesinde ürün veya barkod sorgular.
        Teklifin baremini, hedefini, kalan miktarını ve birim fiyatını çeker.
        """
        clean_q = query.strip()
        if not clean_q:
            return []

        client = await self._get_client()

        # Oturum kontrolü
        if not self.is_logged_in:
            await self.login()

        payload = {
            "action": "purchaseGrid",
            "searchMiadSwitch": "true",
            "searchTargetSwitch": "true",
            "searchPharmacyOfferSwitch": "true",
            "page": "0",
            "priority": "2",
            "productName": clean_q,
            "pharmacy": "",
            "selectedMenu": "menualloffer",
            "directSalesCategory": "",
            "taxFilter": "0"
        }

        try:
            resp = await client.post(self.MAIN_URL, data=payload)

            # Eğer oturum düşmüşse yeniden giriş yap ve tekrar dene
            if resp.status_code != 200 or resp.text.startswith("<") or "sitelogin" in resp.text:
                logger.warning("[Eczatrend] Oturum süresi dolmuş, yeniden giriş yapılıyor...")
                self.is_logged_in = False
                await self.login()
                resp = await client.post(self.MAIN_URL, data=payload)

            if resp.status_code != 200:
                logger.error("[Eczatrend] Arama başarısız: HTTP %s", resp.status_code)
                return []

            data = resp.json()
            raw_items = data.get("data", [])
            if not raw_items:
                return []

            return self._parse_offer_items(raw_items, clean_q)

        except Exception as e:
            logger.error("[Eczatrend] Arama sırasında hata: %s", e)
            return []

    def _parse_offer_items(self, items: List[Dict[str, Any]], query: str) -> List[DepoUrunSarti]:
        """Eczatrend API'sinden gelen teklif listesini DepoUrunSarti formatına dönüştürür."""
        is_barcode_query = query.isdigit() and len(query) >= 8
        query_lower = query.lower()

        matched_offers = []
        for it in items:
            p_bc = str(it.get("productBarcode") or "").strip()
            p_name = str(it.get("productName") or "").strip()

            # Barkod veya isim eşleşmesi
            if is_barcode_query:
                if p_bc != query and query not in p_bc:
                    continue
            else:
                if query_lower not in p_name.lower() and query_lower not in p_bc:
                    continue

            matched_offers.append(it)

        if not matched_offers:
            return []

        # Her teklif detayını hazırla
        pazaryeri_teklifleri = []
        for it in matched_offers:
            try:
                left_target = int(float(str(it.get("leftTarget") or "0").strip()))
            except Exception:
                left_target = 0

            try:
                target_amount = int(float(str(it.get("offertarget") or "0").strip()))
            except Exception:
                target_amount = 0

            try:
                total_purchase = int(float(str(it.get("totalPurchase") or "0").strip()))
            except Exception:
                total_purchase = 0

            try:
                net_price_kdvli = float(str(it.get("netprice") or "0").replace(",", ".").strip())
            except Exception:
                net_price_kdvli = 0.0

            try:
                net_price_kdvsiz = float(str(it.get("vatExcludedNetPrice") or "0").replace(",", ".").strip())
            except Exception:
                net_price_kdvsiz = 0.0

            try:
                market_price = float(str(it.get("marketPrice") or "0").replace(",", ".").strip())
            except Exception:
                market_price = 0.0

            try:
                product_price = float(str(it.get("productPrice") or "0").replace(",", ".").strip())
            except Exception:
                product_price = 0.0

            try:
                product_vat = float(str(it.get("productVat") or "10").replace(",", ".").strip())
            except Exception:
                product_vat = 10.0

            offer_mf = str(it.get("offerMF") or "").strip()
            pharmacy_name = str(it.get("pharmacy") or "Grup Eczanesi").strip()
            group_name = str(it.get("groupName") or "Ortak Alım").strip()
            expire_dt = str(it.get("expireDT") or "").strip()
            offer_pk = str(it.get("offerPK") or "").strip()
            offer_load = str(it.get("offerload") or "0").strip()

            pazaryeri_teklifleri.append({
                "offer_id": offer_pk,
                "satici": pharmacy_name,
                "pharmacy": pharmacy_name,
                "groupName": group_name,
                "fiyat": net_price_kdvli,
                "fiyat_kdvsiz": net_price_kdvsiz,
                "depocu_fiyat": market_price,
                "psf": product_price,
                "kdv": product_vat,
                "mf": offer_mf,
                "hedef": target_amount,
                "kalan": left_target,
                "alinan": total_purchase,
                "doluluk": f"%{offer_load}",
                "kalan_sure": expire_dt,
                "tur": str(it.get("offerSpecialTypeFK") or "Grup Teklifi"),
                "durum": "Alıma Açık" if left_target > 0 else "Hedefe Ulaştı (Kapalı)"
            })

        # Teklifleri sırala: Önce kalanı olanlar (açık teklifler), sonra en düşük net birim maliyet
        pazaryeri_teklifleri.sort(key=lambda x: (0 if x["kalan"] > 0 else 1, x["fiyat"] if x["fiyat"] > 0 else 999999))

        best = pazaryeri_teklifleri[0]
        first_raw = matched_offers[0]

        primary_barcode = str(first_raw.get("productBarcode") or query).strip()
        primary_name = str(first_raw.get("productName") or f"Ürün ({primary_barcode})").strip()

        stok_durumu = StokDurumu.VAR if best["kalan"] > 0 else StokDurumu.YOK
        kalan_adet = best["kalan"]
        hedef_adet = best["hedef"]
        mf_text = best["mf"] or "BAREM"

        kampanya_notu = (
            f"🎯 Barem: {mf_text} | Kalan: {kalan_adet} Adet (Hedef: {hedef_adet}, Doluluk: {best['doluluk']}) | "
            f"Eczane: {best['satici']} ({best['groupName']})"
        )

        depocu_fiyat = best["depocu_fiyat"]
        net_maliyet = best["fiyat_kdvsiz"]
        net_kdvli = best["fiyat"]

        # İndirim yüzdesi
        indirim = 0.0
        if depocu_fiyat > 0 and net_maliyet > 0:
            indirim = round((1 - (net_maliyet / depocu_fiyat)) * 100, 2)

        sart = DepoUrunSarti(
            depo=DepoKodu.ECZATREND,
            depo_adi="Eczatrend (Alım Grubu)",
            barkod=primary_barcode,
            urun_id=best["offer_id"],
            urun_adi=primary_name,
            stok_durumu=stok_durumu,
            stok_adedi=kalan_adet,
            depocu_satis_fiyati=depocu_fiyat,
            perakende_satis_fiyati=best["psf"],
            kdv_orani=best["kdv"],
            mf_metni=mf_text,
            ticari_iskonto=0.0,
            vade_gun=30,
            net_birim_maliyet=net_maliyet,
            net_birim_maliyet_kdvli=net_kdvli,
            toplam_indirim_yuzdesi=indirim,
            miad=best["kalan_sure"],
            ozel_kampanya_notu=kampanya_notu,
            pazaryeri_teklifleri=pazaryeri_teklifleri
        )

        return [sart]

    async def close(self):
        """HTTP bağlantısını kapatır."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
