# -*- coding: utf-8 -*-
"""
backend/routers/cart_routes.py
------------------------------
Depo sepet işlemleri (tekil ekleme, toplu ekleme, şelale ekleme, sepet durumu,
hızlı/toplu sipariş sonlandırma ve çoklu bilgisayar ortak sipariş/verilmeyecek takibi) uç noktaları.
"""

import re
import asyncio
from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse

import backend.app_state as app_state
from backend.order_tracker import order_tracker

router = APIRouter()


@router.post("/api/cart/add")
async def add_to_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        barkod = str(data.get("barkod", "")).strip()
        satis_sekli = str(data.get("satis_sekli", "")).strip()
        name = str(data.get("name") or data.get("urun_adi") or "").strip()

        if not depo:
            return JSONResponse({"success": False, "message": "Depo belirtilmedi."}, status_code=400)

        res = await motor.add_to_cart(
            depo=depo,
            urun_id=urun_id or barkod,
            miktar=miktar,
            barkod=barkod,
            satis_sekli=satis_sekli,
            name=name,
            urun_adi=name
        )
        if res.get("success"):
            try:
                await asyncio.to_thread(
                    order_tracker.mark_items,
                    [{"barkod": barkod or urun_id, "urun_adi": name, "depo": depo, "miktar": miktar}],
                    "SEPETTE",
                    depo
                )
            except Exception as e:
                print(f"[OrderTracker] add_to_cart kayıt uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepete ekleme hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/bulk-add")
async def bulk_add_to_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "ALLIANCE")).strip()
        items = data.get("items", [])
        cascade = bool(data.get("cascade", False))

        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek ürün listesi boş."}, status_code=400)

        if cascade:
            res = await motor.cascade_bulk_add_to_cart(start_depo=depo, items=items)
        else:
            res = await motor.bulk_add_to_cart(depo=depo, items=items)

        try:
            succ_items = [
                {
                    "barkod": r.get("barcode") or r.get("barkod"),
                    "urun_adi": r.get("name") or r.get("urun_adi"),
                    "depo": r.get("assigned_depo") or depo,
                    "miktar": r.get("miktar", 1)
                }
                for r in res.get("items", []) if r.get("success")
            ]
            if succ_items:
                await asyncio.to_thread(order_tracker.mark_items, succ_items, "SEPETTE", depo)
        except Exception as e:
            print(f"[OrderTracker] bulk_add kayıt uyarısı: {e}")

        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Toplu sepete ekleme hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/cascade-bulk-add")
async def cascade_bulk_add_to_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "ALLIANCE")).strip()
        items = data.get("items", [])
        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek ürün listesi boş."}, status_code=400)
        res = await motor.cascade_bulk_add_to_cart(start_depo=depo, items=items)
        try:
            succ_items = [
                {
                    "barkod": r.get("barcode") or r.get("barkod"),
                    "urun_adi": r.get("name") or r.get("urun_adi"),
                    "depo": r.get("assigned_depo") or depo,
                    "miktar": r.get("miktar", 1)
                }
                for r in res.get("items", []) if r.get("success")
            ]
            if succ_items:
                await asyncio.to_thread(order_tracker.mark_items, succ_items, "SEPETTE", depo)
        except Exception as e:
            print(f"[OrderTracker] cascade_bulk_add kayıt uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Şelale sepete ekleme hatası: {str(e)}"}, status_code=500)


@router.get("/api/cart/status")
async def cart_status_endpoint(depo: str = Query("SELCUK")):
    motor = app_state.get_motor()
    try:
        res = await motor.get_cart_status(depo=depo)
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepet sorgulama hatası: {str(e)}"}, status_code=500)


def _normalize_tr_cart_text(text: str) -> str:
    if not text:
        return ""
    tr_map = {
        'İ': 'i', 'I': 'i', 'ı': 'i',
        'Ş': 's', 'ş': 's',
        'Ğ': 'g', 'ğ': 'g',
        'Ü': 'u', 'ü': 'u',
        'Ö': 'o', 'ö': 'o',
        'Ç': 'c', 'ç': 'c'
    }
    res = str(text)
    for k, v in tr_map.items():
        res = res.replace(k, v)
    return res.lower().strip()


def _extract_cart_tokens(name: str):
    norm = _normalize_tr_cart_text(name)
    if not norm:
        return "", [], set()
    norm = re.sub(r"\b1\s*(gr|g)\b", "1000 mg", norm)
    norm = re.sub(r"\b2\s*(gr|g)\b", "2000 mg", norm)
    nums = set(re.findall(r"\d+", norm))
    skip = {
        'mg', 'ml', 'gr', 'g', 'tb', 'ftb', 'tab', 'tablet', 'film', 'kapli',
        'sus', 'susp', 'surup', 'kap', 'kapsul', 'adet', 'kutu', 'flk', 'amp',
        'krem', 'merhem', 'jel', 'losyon', 'sprey', 'damla', 'saşe', 'sase', 'ef', 'efervesan'
    }
    words = [w for w in re.findall(r"[a-z0-9]+", norm) if w not in skip and not w.isdigit() and len(w) >= 2]
    brand = words[0] if words else ""
    return brand, words, nums


def _is_same_cart_product(cart_it: dict, exp_it: dict) -> bool:
    """Depo sepetindeki bir satırın, beklenen/az önce eklenen ürünle aynı olup olmadığını akıllıca tespit eder."""
    c_kod = str(cart_it.get("kod") or cart_it.get("id") or "").strip()
    c_bc = str(cart_it.get("barkod") or "").strip()
    c_ad = str(cart_it.get("ad") or cart_it.get("urun_adi") or "").strip()

    e_id = str(exp_it.get("urun_id") or exp_it.get("kod") or exp_it.get("id") or "").strip()
    e_bc = str(exp_it.get("barcode") or exp_it.get("barkod") or "").strip()
    e_ad = str(exp_it.get("name") or exp_it.get("urun_adi") or exp_it.get("ad") or "").strip()

    c_codes = {x for x in (c_kod, c_bc, c_bc.lstrip("0") if len(c_bc) == 14 else "") if x}
    e_codes = {x for x in (e_id, e_bc, e_bc.lstrip("0") if len(e_bc) == 14 else "") if x}
    if c_codes and e_codes and c_codes.intersection(e_codes):
        return True

    c_norm = _normalize_tr_cart_text(c_ad)
    e_norm = _normalize_tr_cart_text(e_ad)
    if not c_norm or not e_norm:
        return False
    if c_norm in e_norm or e_norm in c_norm:
        return True

    c_brand, c_words, c_nums = _extract_cart_tokens(c_ad)
    e_brand, e_words, e_nums = _extract_cart_tokens(e_ad)
    if not c_brand or not e_brand:
        return False

    if c_brand == e_brand or (len(c_brand) >= 4 and len(e_brand) >= 4 and (c_brand.startswith(e_brand[:4]) or e_brand.startswith(c_brand[:4]))):
        if c_nums and e_nums:
            if c_nums.intersection(e_nums):
                return True
        else:
            common_words = set(c_words).intersection(set(e_words))
            if len(common_words) >= min(2, len(c_words), len(e_words)):
                return True
    return False


@router.post("/api/cart/quick-finalize-check")
async def quick_finalize_check_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        barkod = str(data.get("barkod", "")).strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        urun_adi = str(data.get("urun_adi", "")).strip()

        cart_status = await motor.get_cart_status(depo=depo)
        items = cart_status.get("items", [])

        today_session_items = []
        try:
            cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
            for val in cur_orders.values():
                if isinstance(val, dict) and str(val.get("depo") or "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                    today_session_items.append({
                        "barcode": str(val.get("barkod") or "").strip(),
                        "name": str(val.get("urun_adi") or "").strip(),
                        "miktar": int(val.get("miktar") or 1)
                    })
        except Exception:
            pass

        target_exp = {"urun_id": urun_id, "barkod": barkod, "urun_adi": urun_adi}
        already_in_cart = False
        session_items = []
        foreign_items = []
        annotated_items = []

        for it in items:
            it_copy = dict(it)
            if _is_same_cart_product(it_copy, target_exp):
                it_copy["item_origin"] = "CURRENT_TARGET"
                already_in_cart = True
                session_items.append(it_copy)
            elif any(_is_same_cart_product(it_copy, s_it) for s_it in today_session_items):
                it_copy["item_origin"] = "ADDED_THIS_SESSION"
                session_items.append(it_copy)
            else:
                it_copy["item_origin"] = "FOREIGN_OTHER"
                foreign_items.append(it_copy)
            annotated_items.append(it_copy)

        item_count = len(annotated_items)
        has_other_items = len(foreign_items) > 0
        foreign_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in foreign_items)
        session_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in session_items)

        return JSONResponse({
            "success": True,
            "depo": depo,
            "can_finalize_directly": not has_other_items,
            "has_other_items": has_other_items,
            "already_in_cart": already_in_cart,
            "item_count": item_count,
            "items": annotated_items,
            "session_items": session_items,
            "session_count": len(session_items),
            "session_total": round(session_total, 2),
            "foreign_items": foreign_items,
            "foreign_count": len(foreign_items),
            "foreign_total": round(foreign_total, 2),
            "total_amount": cart_status.get("total_amount", 0.0),
            "cart_url": cart_status.get("cart_url", ""),
            "checkout_url": cart_status.get("checkout_url", ""),
            "supported": cart_status.get("supported", False)
        })
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Hızlı sipariş kontrol hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/finalize")
async def finalize_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        urun_id = str(data.get("urun_id", "")).strip()
        barkod = str(data.get("barkod", "")).strip()
        urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
        raw_miktar = str(data.get("miktar", 1) or "1").split("+")[0].strip()
        miktar = max(1, int(float(raw_miktar.replace(",", ".")))) if raw_miktar else 1
        force = bool(data.get("force", False))
        already_in_cart = bool(data.get("already_in_cart", False))
        satis_sekli = str(data.get("satis_sekli", "")).strip()
        bulk_items = data.get("items", [])

        effective_urun_id = "" if already_in_cart else (urun_id or barkod)
        effective_barkod = "" if already_in_cart else barkod
        effective_force = True if already_in_cart else force

        res = await motor.finalize_order(
            depo=depo,
            urun_id=effective_urun_id,
            miktar=miktar,
            force=effective_force,
            barkod=effective_barkod,
            satis_sekli=satis_sekli,
            name=urun_adi,
            urun_adi=urun_adi,
            items=bulk_items
        )
        if res.get("success"):
            try:
                to_mark = []
                if barkod or urun_id or urun_adi:
                    to_mark.append({
                        "barkod": barkod or urun_id,
                        "urun_adi": urun_adi,
                        "depo": depo,
                        "miktar": miktar
                    })
                if bulk_items and isinstance(bulk_items, list):
                    for bi in bulk_items:
                        to_mark.append({
                            "barkod": bi.get("barcode") or bi.get("barkod") or bi.get("urun_id") or "",
                            "urun_adi": bi.get("name") or bi.get("urun_adi") or "",
                            "depo": depo,
                            "miktar": bi.get("miktar", 1)
                        })
                cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
                seen_bcs = set()
                for val in cur_orders.values():
                    if isinstance(val, dict) and val.get("depo", "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                        v_bc = val.get("barkod") or ""
                        if v_bc and v_bc not in seen_bcs:
                            seen_bcs.add(v_bc)
                            to_mark.append({
                                "barkod": v_bc,
                                "urun_adi": val.get("urun_adi") or "",
                                "depo": depo,
                                "miktar": val.get("miktar", 1)
                            })
                if to_mark:
                    await asyncio.to_thread(order_tracker.mark_items, to_mark, "SIPARIS_VERILDI", depo)
            except Exception as e:
                print(f"[OrderTracker] finalize_order kayıt uyarısı: {e}")

        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sipariş sonlandırma hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/clear")
async def clear_cart_endpoint(request: Request):
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        res = await motor.clear_cart(depo=depo)
        if res.get("success"):
            try:
                await asyncio.to_thread(order_tracker.clear_cart_items_for_depo, depo)
            except Exception as e:
                print(f"[OrderTracker] clear_cart kayıt silme uyarısı: {e}")
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Sepet temizleme hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/bulk-finalize-check")
async def bulk_finalize_check_endpoint(request: Request):
    """
    Günlük toplu sipariş sonlandırma öncesi sepeti kontrol eder.
    Sepetteki ürünleri, bugün sipariş edilmek istenen beklenen ürünlerle karşılaştırır.
    Farklı/önceden sepette olan ürünleri ayıklar.
    """
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        raw_expected = data.get("items", []) or []

        expected_items = list(raw_expected)
        seen_bcs = {str(it.get("barcode") or it.get("barkod") or "").strip() for it in expected_items if str(it.get("barcode") or it.get("barkod") or "").strip()}
        try:
            cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
            for val in cur_orders.values():
                if isinstance(val, dict) and str(val.get("depo") or "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                    v_bc = str(val.get("barkod") or "").strip()
                    v_nm = str(val.get("urun_adi") or "").strip()
                    key = v_bc or v_nm
                    if key and key not in seen_bcs:
                        seen_bcs.add(key)
                        expected_items.append({
                            "barcode": v_bc,
                            "name": v_nm,
                            "miktar": int(val.get("miktar") or 1)
                        })
        except Exception:
            pass

        cart_status = await motor.get_cart_status(depo=depo)
        cart_items = cart_status.get("items", [])

        if len(cart_items) == 0 and len(expected_items) > 0:
            try:
                print(f"[{depo}] bulk-finalize-check: Sepet boş döndü, {len(expected_items)} beklenen ürün otomatik yeniden sepete ekleniyor...")
                await motor.bulk_add_to_cart(depo=depo, items=expected_items)
                cart_status = await motor.get_cart_status(depo=depo)
                cart_items = cart_status.get("items", [])
            except Exception as re_err:
                print(f"[{depo}] Otomatik sepet geri yükleme uyarısı: {re_err}")

        total_amount = cart_status.get("total_amount", 0.0)

        matched_items = []
        extra_items = []

        for c_it in cart_items:
            c_copy = dict(c_it)
            is_matched = any(_is_same_cart_product(c_copy, exp_it) for exp_it in expected_items)
            if is_matched:
                c_copy["item_origin"] = "ADDED_THIS_SESSION"
                matched_items.append(c_copy)
            else:
                c_copy["item_origin"] = "FOREIGN_OTHER"
                extra_items.append(c_copy)

        has_extra_items = len(extra_items) > 0
        can_finalize_directly = (not has_extra_items) and (len(cart_items) > 0)

        extra_total = sum(float(x.get("tutar") or (float(x.get("fiyat") or 0.0) * int(x.get("miktar") or 1))) for x in extra_items)

        return JSONResponse({
            "success": True,
            "depo": depo,
            "can_finalize_directly": can_finalize_directly,
            "has_extra_items": has_extra_items,
            "cart_count": len(cart_items),
            "matched_count": len(matched_items),
            "extra_count": len(extra_items),
            "extra_total": round(extra_total, 2),
            "total_amount": total_amount,
            "matched_items": matched_items,
            "extra_items": extra_items,
            "all_items": matched_items + extra_items,
            "cart_url": cart_status.get("cart_url", ""),
            "checkout_url": cart_status.get("checkout_url", ""),
            "supported": cart_status.get("supported", False)
        })
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Günlük sipariş sepet kontrol hatası: {str(e)}"}, status_code=500)


@router.post("/api/cart/bulk-finalize-clean-submit")
async def bulk_finalize_clean_submit_endpoint(request: Request):
    """
    Sepetteki farklı ürünleri temizler:
    1. Sepeti tamamen boşaltır (/api/cart/clear)
    2. Sadece bugün gönderilmek istenen günlük sipariş ürünlerini yeniden sepete ekler
    3. Siparişi depoya onaylayıp sonlandırır (/api/cart/finalize force=True)
    """
    motor = app_state.get_motor()
    try:
        data = await request.json()
        depo = str(data.get("depo", "SELCUK")).strip()
        items = data.get("items", []) or []

        if not items:
            try:
                cur_orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
                seen_bcs = set()
                for val in cur_orders.values():
                    if isinstance(val, dict) and val.get("depo", "").upper() == depo.upper() and val.get("durum") == "SEPETTE":
                        v_bc = str(val.get("barkod") or "").strip()
                        if v_bc and v_bc not in seen_bcs:
                            seen_bcs.add(v_bc)
                            items.append({
                                "barcode": v_bc,
                                "name": val.get("urun_adi") or "",
                                "miktar": int(val.get("miktar") or 1)
                            })
            except Exception:
                pass

        if not items:
            return JSONResponse({"success": False, "message": "Gönderilecek günlük sipariş kalemi bulunamadı."}, status_code=400)

        await motor.clear_cart(depo=depo)

        added_count = 0
        adapter = motor._get_adapter_by_depo(depo)
        if not adapter:
            return JSONResponse({"success": False, "message": f"'{depo}' için adaptör bulunamadı."}, status_code=400)

        for it in items:
            bc = str(it.get("barcode") or it.get("barkod") or "").strip()
            u_id = str(it.get("urun_id") or "").strip()
            mik = int(it.get("miktar") or 1)
            try:
                target_id = u_id if u_id else bc
                add_res = await adapter.add_to_cart(urun_id=target_id, miktar=mik, barkod=bc)
                if add_res.get("success"):
                    added_count += 1
            except Exception as e:
                print(f"[Bulk Finalize Clean] Ürün ekleme hatası ({bc}): {e}")

        if added_count == 0:
            return JSONResponse({"success": False, "message": "Günlük sipariş ürünleri sepete yeniden eklenemedi."}, status_code=500)

        fin_res = await motor.finalize_order(depo=depo, urun_id="", force=True)
        if fin_res.get("success"):
            try:
                await asyncio.to_thread(order_tracker.clear_cart_items_for_depo, depo)
                await asyncio.to_thread(order_tracker.mark_items, items, "SIPARIS_VERILDI", depo)
            except Exception as e:
                print(f"[OrderTracker] bulk_finalize_clean_submit kayıt uyarısı: {e}")
        return JSONResponse(fin_res)
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Temizleyip sonlandırma hatası: {str(e)}"}, status_code=500)


# --- Çoklu Bilgisayar (Multi-PC) Günlük Sipariş & Verilmeyecek Senkronizasyon Endpoints ---
@router.get("/api/orders/today")
async def get_today_orders_endpoint():
    """Tüm eczane bilgisayarlarında bugün verilen / sepete eklenen / verilmeyecek işaretlenen siparişlerin anlık haritasını döner."""
    try:
        orders = await asyncio.to_thread(order_tracker.get_today_orders_map)
        return {"success": True, "orders": orders, "pc_name": order_tracker.pc_name}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/mark")
@router.post("/api/orders/today/mark")
async def mark_orders_endpoint(request: Request):
    """Bir veya birden fazla ürünü tüm bilgisayarlarda 'SIPARIS_VERILDI', 'SEPETTE' veya 'SIPARIS_VERILMEYECEK' olarak işaretler."""
    try:
        data = await request.json()
        items = data.get("items", [])
        durum = str(data.get("durum", "SIPARIS_VERILDI")).strip()
        depo = str(data.get("depo", "MANUEL")).strip()
        count = await asyncio.to_thread(order_tracker.mark_items, items, durum, depo)
        return JSONResponse({"success": True, "count": count, "pc_name": order_tracker.pc_name})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/unmark")
@router.post("/api/orders/today/unmark")
async def unmark_order_endpoint(request: Request):
    """Sipariş verildi veya sipariş verilmeyecek işaretini geri alır (tüm bilgisayarlarda tekrar aktif listeye sokar)."""
    try:
        data = await request.json()
        barkod = str(data.get("barkod") or data.get("barcode") or "").strip()
        urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
        ok = await asyncio.to_thread(order_tracker.unmark_item, barkod, urun_adi)
        return JSONResponse({"success": bool(ok), "pc_name": order_tracker.pc_name})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


# --- GÜN SONU DEPO SİPARİŞ ÖZETİ & SİPARİŞ VERİLMEYECEKLERDEN YOK LİSTESİ OLUŞTURMA (v1.4.1) ---
def _get_yok_scan_file_path():
    from pathlib import Path
    p = Path(__file__).resolve().parent.parent.parent / "data"
    p.mkdir(parents=True, exist_ok=True)
    return p / "today_yok_scan.json"


def _load_today_yok_scan(today_str: str) -> dict:
    import json
    fp = _get_yok_scan_file_path()
    if fp.exists():
        try:
            data = json.loads(fp.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("date") == today_str:
                return data
        except Exception:
            pass
    return {"date": today_str, "last_scan_time": None, "yok_items": [], "var_items": []}


def _save_today_yok_scan(scan_data: dict):
    import json
    fp = _get_yok_scan_file_path()
    try:
        fp.write_text(json.dumps(scan_data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"[YokScan] Kayıt uyarısı: {e}")


def _deduplicate_today_orders(orders_map: dict) -> list:
    """
    orders_map içerisindeki 13/14 haneli barkod, NAME:... ve ürün adı kopyalarını tekilleştirir.
    """
    unique_by_key = {}
    for k, val in (orders_map or {}).items():
        if not isinstance(val, dict):
            continue
        raw_bc = str(val.get("barkod") or "").strip()
        if raw_bc.startswith("NAME:"):
            raw_bc = ""
        elif raw_bc and not raw_bc.isdigit() and len(raw_bc) > 15:
            raw_bc = ""
        canon_bc = raw_bc[1:] if (len(raw_bc) == 14 and raw_bc.startswith("0")) else raw_bc
        unm = str(val.get("urun_adi") or "").strip()
        unm_upper = unm.upper()
        dedup_key = canon_bc if (canon_bc and canon_bc.isdigit()) else (unm_upper or k)
        if not dedup_key:
            continue
        existing = unique_by_key.get(dedup_key)
        if not existing or (not existing.get("barkod") and canon_bc):
            unique_by_key[dedup_key] = {
                "barkod": canon_bc if (canon_bc and canon_bc.isdigit()) else "",
                "urun_adi": unm or canon_bc,
                "durum": str(val.get("durum") or "SIPARIS_VERILDI"),
                "depo": str(val.get("depo") or "DEPO").upper(),
                "miktar": int(val.get("miktar") or 1),
                "masa_adi": str(val.get("masa_adi") or "Eczane PC"),
                "saat": str(val.get("saat") or "")
            }
    return list(unique_by_key.values())


@router.get("/api/orders/today/summary")
async def get_today_end_of_day_summary_endpoint():
    """
    Gün Sonu Depo Sipariş Özeti:
    - Depo bazlı sipariş verilen (SIPARIS_VERILDI) ve sepette bekleyen (SEPETTE) kalem/kutu dökümü
    - Bugün 'Sipariş Verilmeyecek' (SIPARIS_VERILMEYECEK) işaretlenen ürünler listesi
    - Depolarda sorgulanıp 'Yok Listesi'ne alınan ürünlerin güncel durumu
    """
    try:
        import datetime
        today_str = datetime.date.today().strftime("%Y-%m-%d")
        orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
        unique_items = _deduplicate_today_orders(orders_map)

        ordered_items = []
        cart_items = []
        skipped_items = []
        depots_summary = {}

        for it in unique_items:
            durum = it.get("durum")
            depo = it.get("depo") or "MANUEL"
            miktar = int(it.get("miktar") or 1)
            if durum == "SIPARIS_VERILMEYECEK":
                skipped_items.append(it)
            elif durum == "SEPETTE":
                cart_items.append(it)
                d_entry = depots_summary.setdefault(depo, {
                    "depo": depo,
                    "ordered_count": 0,
                    "ordered_boxes": 0,
                    "cart_count": 0,
                    "cart_boxes": 0,
                    "items": []
                })
                d_entry["cart_count"] += 1
                d_entry["cart_boxes"] += miktar
                d_entry["items"].append(it)
            else:
                ordered_items.append(it)
                d_entry = depots_summary.setdefault(depo, {
                    "depo": depo,
                    "ordered_count": 0,
                    "ordered_boxes": 0,
                    "cart_count": 0,
                    "cart_boxes": 0,
                    "items": []
                })
                d_entry["ordered_count"] += 1
                d_entry["ordered_boxes"] += miktar
                d_entry["items"].append(it)

        yok_scan = await asyncio.to_thread(_load_today_yok_scan, today_str)

        return {
            "success": True,
            "date": today_str,
            "pc_name": order_tracker.pc_name,
            "totals": {
                "ordered_count": len(ordered_items),
                "ordered_boxes": sum(int(x.get("miktar") or 1) for x in ordered_items),
                "cart_count": len(cart_items),
                "cart_boxes": sum(int(x.get("miktar") or 1) for x in cart_items),
                "skipped_count": len(skipped_items),
                "yok_count": len(yok_scan.get("yok_items") or [])
            },
            "depots": list(depots_summary.values()),
            "ordered_items": ordered_items,
            "cart_items": cart_items,
            "skipped_items": skipped_items,
            "yok_scan": yok_scan
        }
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/today/check-yok-list")
async def check_skipped_items_for_yok_list_endpoint(request: Request):
    """
    Bugün 'Sipariş Verilmeyecek' olarak işaretlenen (veya gönderilen listedeki) ürünleri
    aktif ecza depolarında (Alliance, Selçuk, İSKOOP, Nevzat, BEK, DNA) paralel sorgular.
    Hiçbir depoda stoğu olmayan ürünleri otomatik olarak 'YOK LİSTESİ'ne ekler;
    stoğu bulunanlar için ise hangi depoda hangi şartla bulunduğunu raporlar.
    """
    import datetime
    from backend.models import DepoKodu, StokDurumu
    motor = app_state.get_motor()
    try:
        body = {}
        try:
            body = await request.json()
        except Exception:
            pass

        today_str = datetime.date.today().strftime("%Y-%m-%d")
        mode = str(body.get("mode") or "skipped").strip().lower()
        existing_scan = await asyncio.to_thread(_load_today_yok_scan, today_str)
        input_items = body.get("items")
        if not input_items:
            if mode == "yok_only":
                input_items = list(existing_scan.get("yok_items") or [])
            else:
                orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
                unique_all = _deduplicate_today_orders(orders_map)
                skipped_pool = [it for it in unique_all if it.get("durum") == "SIPARIS_VERILMEYECEK"]
                if mode == "all":
                    seen_keys = set()
                    combined = []
                    for it in (skipped_pool + list(existing_scan.get("yok_items") or [])):
                        k = str(it.get("barkod") or it.get("urun_adi") or "").strip().upper()
                        if k and k not in seen_keys:
                            seen_keys.add(k)
                            combined.append(it)
                    input_items = combined
                else:
                    input_items = skipped_pool

        if not input_items:
            return {
                "success": True,
                "message": "Sorgulanacak Yok Listesi ürünü bulunamadı." if mode == "yok_only" else "Sorgulanacak 'Sipariş Verilmeyecek' işaretli ürün bulunamadı.",
                "checked_count": 0,
                "yok_items": existing_scan.get("yok_items") or [],
                "var_items": existing_scan.get("var_items") or []
            }

        b2b_depo_codes = [
            DepoKodu.ALLIANCE,
            DepoKodu.SELCUK,
            DepoKodu.ISKOOP,
            DepoKodu.NEVZAT,
            DepoKodu.BEK,
            DepoKodu.DNA
        ]
        active_adapters = [
            (code.value, motor.adapters[code])
            for code in b2b_depo_codes
            if code in motor.adapters
        ]

        sem = asyncio.Semaphore(4)

        async def _probe_single_item(item_obj: dict) -> dict:
            bc = str(item_obj.get("barkod") or item_obj.get("barcode") or "").strip()
            nm = str(item_obj.get("urun_adi") or item_obj.get("name") or "").strip()
            query_term = bc if (bc and bc.isdigit() and len(bc) >= 8) else nm
            if not query_term:
                return {
                    "barkod": bc,
                    "urun_adi": nm,
                    "stokta_var": False,
                    "bulunan_depolar": [],
                    "yok_depolar": [c for c, _ in active_adapters],
                    "en_uygun_depo": None,
                    "en_uygun_fiyat": None,
                    "en_uygun_mf": None
                }

            async with sem:
                async def _ask_depo(depo_code: str, adapter):
                    try:
                        try:
                            res_list = await asyncio.wait_for(
                                adapter.search_product(query_term, include_equivalents=False, is_background=True),
                                timeout=8.5
                            )
                        except TypeError:
                            res_list = await asyncio.wait_for(
                                adapter.search_product(query_term),
                                timeout=8.5
                            )
                        if res_list:
                            for r in res_list:
                                if getattr(r, "stok_durumu", None) == StokDurumu.VAR:
                                    return {
                                        "depo": depo_code,
                                        "depo_adi": getattr(r, "depo_adi", depo_code),
                                        "var": True,
                                        "net_maliyet": float(getattr(r, "net_birim_maliyet_kdvli", 0) or getattr(r, "net_birim_maliyet", 0) or getattr(r, "depocu_fiyat", 0) or 0),
                                        "mf": str(getattr(r, "mf_metni", "") or "YOK"),
                                        "barkod": str(getattr(r, "barkod", "") or bc),
                                        "urun_adi": str(getattr(r, "urun_adi", "") or nm)
                                    }
                    except Exception:
                        pass
                    return {"depo": depo_code, "depo_adi": depo_code, "var": False}

                depo_results = await asyncio.gather(*[_ask_depo(c, ad) for c, ad in active_adapters])
                bulunan = [dr for dr in depo_results if dr.get("var")]
                yok_olan = [dr["depo"] for dr in depo_results if not dr.get("var")]
                bulunan.sort(key=lambda x: (x.get("net_maliyet") or 999999.0))
                best = bulunan[0] if bulunan else None
                resolved_bc = (best.get("barkod") if best else "") or bc
                resolved_nm = nm or (best.get("urun_adi") if best else "") or query_term

                return {
                    "barkod": resolved_bc,
                    "urun_adi": resolved_nm,
                    "masa_adi": item_obj.get("masa_adi") or "Eczane PC",
                    "saat": item_obj.get("saat") or datetime.datetime.now().strftime("%H:%M"),
                    "stokta_var": len(bulunan) > 0,
                    "bulunan_depolar": bulunan,
                    "yok_depolar": yok_olan,
                    "en_uygun_depo": best["depo"] if best else None,
                    "en_uygun_depo_adi": best["depo_adi"] if best else None,
                    "en_uygun_fiyat": round(best["net_maliyet"], 2) if (best and best.get("net_maliyet")) else None,
                    "en_uygun_mf": best["mf"] if best else None
                }

        probed_list = await asyncio.gather(*[_probe_single_item(it) for it in input_items[:50]])
        yok_items = [p for p in probed_list if not p.get("stokta_var")]
        var_items = [p for p in probed_list if p.get("stokta_var")]

        # Mevcut yok listesi ile birleştir (daha önce eklenen yoklar kaybolmasın)
        merged_yok_map = {}
        for old_y in (existing_scan.get("yok_items") or []):
            k = str(old_y.get("barkod") or old_y.get("urun_adi") or "").strip().upper()
            if k:
                merged_yok_map[k] = old_y
        # Yeni taramada stokta bulunanları yok listesinden çıkar, bulunmayanları ekle
        for v_it in var_items:
            k_bc = str(v_it.get("barkod") or "").strip().upper()
            k_nm = str(v_it.get("urun_adi") or "").strip().upper()
            if k_bc:
                merged_yok_map.pop(k_bc, None)
            if k_nm:
                merged_yok_map.pop(k_nm, None)
        for y_it in yok_items:
            k = str(y_it.get("barkod") or y_it.get("urun_adi") or "").strip().upper()
            if k:
                merged_yok_map[k] = y_it

        merged_var_map = {}
        for old_v in (existing_scan.get("var_items") or []):
            k = str(old_v.get("barkod") or old_v.get("urun_adi") or "").strip().upper()
            if k:
                merged_var_map[k] = old_v
        for v_it in var_items:
            k = str(v_it.get("barkod") or v_it.get("urun_adi") or "").strip().upper()
            if k:
                merged_var_map[k] = v_it

        now_time = datetime.datetime.now().strftime("%H:%M:%S")
        scan_payload = {
            "date": today_str,
            "last_scan_time": now_time,
            "active_depots": [c for c, _ in active_adapters],
            "yok_items": list(merged_yok_map.values()),
            "var_items": list(merged_var_map.values())
        }
        await asyncio.to_thread(_save_today_yok_scan, scan_payload)

        return {
            "success": True,
            "date": today_str,
            "last_scan_time": now_time,
            "checked_count": len(probed_list),
            "active_depots": [c for c, _ in active_adapters],
            "yok_count": len(scan_payload["yok_items"]),
            "var_count": len(var_items),
            "yok_items": scan_payload["yok_items"],
            "var_items": scan_payload["var_items"]
        }
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/today/yok-list/add")
async def add_to_today_yok_list_endpoint(request: Request):
    """Bir veya birden fazla ürünü doğrudan bugünkü Yok Listesine manuel ekler ve tüm PC'lerde işaretler."""
    import datetime
    try:
        body = await request.json()
        raw_items = body.get("items")
        if not raw_items:
            bc_single = str(body.get("barkod") or body.get("barcode") or "").strip()
            nm_single = str(body.get("urun_adi") or body.get("name") or "").strip()
            if bc_single or nm_single:
                raw_items = [{"barkod": bc_single, "urun_adi": nm_single}]
            else:
                raw_items = []

        if not raw_items:
            return JSONResponse({"success": False, "error": "Eklenecek ürün adı veya barkod girilmedi."}, status_code=400)

        today_str = datetime.date.today().strftime("%Y-%m-%d")
        now_hm = datetime.datetime.now().strftime("%H:%M")
        scan = await asyncio.to_thread(_load_today_yok_scan, today_str)
        yok_map = {}
        for it in (scan.get("yok_items") or []):
            k = str(it.get("barkod") or it.get("urun_adi") or "").strip().upper()
            if k:
                yok_map[k] = it

        tracker_payload = []
        added_count = 0
        for r in raw_items:
            bc = str(r.get("barkod") or r.get("barcode") or "").strip()
            nm = str(r.get("urun_adi") or r.get("name") or "").strip()
            if not bc and nm and nm.isdigit() and len(nm) >= 8:
                bc = nm
            if not nm and bc:
                nm = bc
            key = (bc or nm).strip().upper()
            if not key:
                continue
            yok_map[key] = {
                "barkod": bc,
                "urun_adi": nm,
                "masa_adi": order_tracker.pc_name,
                "saat": now_hm,
                "stokta_var": False,
                "bulunan_depolar": [],
                "yok_depolar": ["Manuel Eklendi"],
                "manuel_eklendi": True
            }
            tracker_payload.append({"barcode": bc, "name": nm, "miktar": 1})
            added_count += 1

        scan["yok_items"] = list(yok_map.values())
        await asyncio.to_thread(_save_today_yok_scan, scan)

        if tracker_payload and body.get("mark_skipped", True):
            try:
                await asyncio.to_thread(order_tracker.mark_items, tracker_payload, "SIPARIS_VERILMEYECEK", "YOK_LISTESI")
            except Exception:
                pass

        return {"success": True, "added_count": added_count, "yok_items": scan["yok_items"]}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/api/orders/today/yok-list/remove")
async def remove_from_today_yok_list_endpoint(request: Request):
    """Belirtilen ürünü bugünkü Yok Listesinden çıkarır."""
    import datetime
    try:
        body = await request.json()
        bc = str(body.get("barkod") or "").strip().upper()
        nm = str(body.get("urun_adi") or "").strip().upper()
        today_str = datetime.date.today().strftime("%Y-%m-%d")
        scan = await asyncio.to_thread(_load_today_yok_scan, today_str)
        old_list = scan.get("yok_items") or []
        new_list = [
            it for it in old_list
            if not (
                (bc and str(it.get("barkod") or "").strip().upper() == bc)
                or (nm and str(it.get("urun_adi") or "").strip().upper() == nm)
            )
        ]
        scan["yok_items"] = new_list
        await asyncio.to_thread(_save_today_yok_scan, scan)
        if body.get("unmark_order", True):
            try:
                await asyncio.to_thread(order_tracker.unmark_item, bc, nm)
            except Exception:
                pass
        return {"success": True, "yok_items": new_list}
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


