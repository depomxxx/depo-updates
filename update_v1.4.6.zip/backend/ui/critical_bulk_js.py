# -*- coding: utf-8 -*-
CRITICAL_BULK_JS = """        // ================= Günlük Çıkış & Azalan / Kritik Stok Paneli =================
        let criticalStockItems = [];
        let criticalFilterMode = 'days_21';
        window.criticalCheckedMap = window.criticalCheckedMap || {};
        window.criticalCustomQtyMap = window.criticalCustomQtyMap || {};
        window.criticalInitialSelectionDone = false;

        function getCriticalItemKey(item) {
            if (!item) return '';
            return String(item.barkod || item.urun_kodu || item.urun_adi || '').trim();
        }

        function syncCriticalDomStateToMaps() {
            window.criticalCheckedMap = window.criticalCheckedMap || {};
            window.criticalCustomQtyMap = window.criticalCustomQtyMap || {};
            const curList = window.currentFilteredCriticalItems || [];
            if (curList.length === 0) return;
            const checks = document.querySelectorAll('.bulkItemCheck');
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = curList[idx];
                const key = getCriticalItemKey(it);
                if (key) {
                    window.criticalCheckedMap[key] = !!c.checked;
                }
                const inp = document.getElementById(`bulkQtyInput_${idx}`);
                if (inp && key) {
                    const v = parseInt(inp.value);
                    if (!isNaN(v) && v >= 1) {
                        window.criticalCustomQtyMap[key] = v;
                    }
                }
            });
        }

        async function loadCriticalStockList(force = false) {
            syncCriticalDomStateToMaps();
            const container = document.getElementById('criticalStockListContainer');
            const countBadge = document.getElementById('sideCriticalCountBadge');
            const topBadge = document.getElementById('topBarCriticalCount');
            const refreshIcon = document.getElementById('criticalRefreshIcon');
            const statusPill = document.getElementById('botanikDataStatusPill');
            const statusIcon = document.getElementById('dataStatusIcon');
            const statusText = document.getElementById('dataStatusText');

            if (refreshIcon) refreshIcon.classList.add('fa-spin');
            if (container && force) {
                container.innerHTML = `
                    <div class="p-6 text-center text-slate-400 text-xs">
                        <i class="fa-solid fa-spinner fa-spin text-xl text-indigo-500 mb-2 block"></i>
                        Güncel stok ve çıkışlar taranıyor...
                    </div>
                `;
            }

            try {
                const res = await fetch(`/api/otomasyon/critical-stock?force=${force}`);
                if (!res.ok) throw new Error('API yanıt vermedi');
                const data = await res.json();
                criticalStockItems = data.items || [];

                // Başlangıçta hiçbir ürün seçili gelmesin; kullanıcı isterse Tümünü Seç veya tek tek seçsin
                criticalStockItems.forEach(it => {
                    const key = getCriticalItemKey(it);
                    if (!key) return;
                    if (it.siparis_durumu) {
                        window.criticalCheckedMap[key] = false;
                    } else if (window.criticalCheckedMap[key] === undefined) {
                        window.criticalCheckedMap[key] = false;
                    }
                });
                window.criticalInitialSelectionDone = true;

                const countStr = `${criticalStockItems.length}`;
                if (countBadge) countBadge.innerText = countStr;
                if (topBadge) topBadge.innerText = countStr;
                const miniBadge = document.getElementById('miniSideCriticalCount');
                if (miniBadge) miniBadge.innerText = countStr;

                renderCriticalList();
            } catch (err) {
                console.error("Critical stock fetch error:", err);
                if (container) {
                    container.innerHTML = `
                        <div class="p-4 text-center text-rose-500 text-xs bg-rose-50 rounded-xl border border-rose-200">
                            <i class="fa-solid fa-circle-exclamation text-base mb-1 block"></i>
                            Kritik stok bilgisi alınamadı: ${err.message}
                        </div>
                    `;
                }
            } finally {
                if (refreshIcon) refreshIcon.classList.remove('fa-spin');
            }
        }

        let showMfBadges = localStorage.getItem('showMfBadges') !== 'false';
        let hideOrderedItems = localStorage.getItem('hideOrderedItems') === 'true';
        let isMfResolutionRunning = false;

        function updateHideOrderedButtonUI() {
            const btn = document.getElementById('btnToggleHideOrdered');
            const txt = document.getElementById('btnToggleHideOrderedText');
            const icn = document.getElementById('btnToggleHideOrderedIcon');
            if (!btn) return;
            if (hideOrderedItems) {
                btn.className = 'px-1.5 py-1 rounded-md font-bold text-[10px] transition cursor-pointer flex items-center space-x-1 bg-emerald-600 text-white shrink-0';
                if (txt) txt.innerText = 'Gizli';
                if (icn) icn.className = 'fa-solid fa-eye text-[9px]';
            } else {
                btn.className = 'px-1.5 py-1 rounded-md font-bold text-[10px] transition cursor-pointer flex items-center space-x-1 bg-slate-100 text-slate-600 hover:bg-slate-200 shrink-0';
                if (txt) txt.innerText = 'Gizle';
                if (icn) icn.className = 'fa-solid fa-eye-slash text-[9px]';
            }
        }

        function toggleHideOrderedItems() {
            hideOrderedItems = !hideOrderedItems;
            localStorage.setItem('hideOrderedItems', hideOrderedItems ? 'true' : 'false');
            updateHideOrderedButtonUI();
            renderCriticalList();
        }

        async function syncTodayOrdersAcrossPCs() {
            try {
                const res = await fetch('/api/orders/today');
                if (!res.ok) return;
                const data = await res.json();
                if (!data.success || !data.orders) return;
                const ordersMap = data.orders || {};
                window.todayOrdersMap = ordersMap;

                let changed = false;
                let orderedTotal = 0;

                if (criticalStockItems && criticalStockItems.length > 0) {
                    criticalStockItems.forEach(it => {
                        const bc = (it.barkod || '').toString().trim();
                        const bcNoZero = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;
                        const nm = (it.urun_adi || '').toString().trim().toLowerCase();
                        const nmUpper = (it.urun_adi || '').toString().trim().toUpperCase();
                        const match = (bc && ordersMap[bc]) || (bcNoZero && ordersMap[bcNoZero]) || (nmUpper && ordersMap[nmUpper]) || (nm && ordersMap[`NAME:${nm}`]);

                        const newStatus = match ? match.durum : null;
                        const newDepo = match ? match.depo : null;
                        const newMiktar = match ? match.miktar : null;
                        const newMasa = match ? (match.masa_adi || match.masa) : null;
                        const newSaat = match ? match.saat : null;

                        if (newStatus) orderedTotal++;

                        if (it.siparis_durumu !== newStatus || it.siparis_depo !== newDepo || it.siparis_miktar !== newMiktar) {
                            it.siparis_durumu = newStatus;
                            it.siparis_depo = newDepo;
                            it.siparis_miktar = newMiktar;
                            it.siparis_masa = newMasa;
                            it.siparis_saat = newSaat;
                            if (newStatus && window.criticalCheckedMap) {
                                const cKey = getCriticalItemKey(it);
                                if (cKey) window.criticalCheckedMap[cKey] = false;
                            }
                            changed = true;
                        }
                    });
                }

                // 6 Aylık Çıkış & Toplu Sipariş listesini de senkronize et
                let smartChanged = false;
                if (window.smartOrderItems && window.smartOrderItems.length > 0) {
                    window.smartOrderItems.forEach(it => {
                        const bc = (it.barkod || '').toString().trim();
                        const bcNoZero = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;
                        const nm = (it.urun_adi || '').toString().trim().toLowerCase();
                        const nmUpper = (it.urun_adi || '').toString().trim().toUpperCase();
                        const match = (bc && ordersMap[bc]) || (bcNoZero && ordersMap[bcNoZero]) || (nmUpper && ordersMap[nmUpper]) || (nm && ordersMap[`NAME:${nm}`]);

                        const newStatus = match ? match.durum : null;
                        const newDepo = match ? match.depo : null;
                        const newMiktar = match ? match.miktar : null;
                        const newMasa = match ? (match.masa_adi || match.masa) : null;
                        const newSaat = match ? match.saat : null;

                        if (it.siparis_durumu !== newStatus || it.siparis_depo !== newDepo || it.siparis_miktar !== newMiktar) {
                            it.siparis_durumu = newStatus;
                            it.siparis_depo = newDepo;
                            it.siparis_miktar = newMiktar;
                            it.siparis_masa = newMasa;
                            it.siparis_saat = newSaat;
                            if ((newStatus === 'SIPARIS_VERILDI' || newStatus === 'SIPARIS_VERILMEYECEK') && window.smartRowCheckedMap) {
                                const key = it.barkod || it.urun_kodu || it.urun_adi;
                                window.smartRowCheckedMap[key] = false;
                            }
                            smartChanged = true;
                        }
                    });
                }

                const ordBadge = document.getElementById('orderedTodayCountBadge');
                if (ordBadge) {
                    ordBadge.innerText = `${orderedTotal} İşlem`;
                }
                const eodHdrBadge = document.getElementById('eodHeaderSummaryBadge');
                if (eodHdrBadge) {
                    eodHdrBadge.innerText = String(orderedTotal);
                }

                if (changed) {
                    // Sipariş verilenleri ve sipariş verilmeyecekleri listenin en altına taşı, bekleyenleri üstte tut
                    criticalStockItems.sort((a, b) => {
                        const aOrd = (a.siparis_durumu === 'SIPARIS_VERILDI' || a.siparis_durumu === 'SIPARIS_VERILMEYECEK') ? 1 : 0;
                        const bOrd = (b.siparis_durumu === 'SIPARIS_VERILDI' || b.siparis_durumu === 'SIPARIS_VERILMEYECEK') ? 1 : 0;
                        if (aOrd !== bOrd) return aOrd - bOrd;
                        return (b.bugun_cikis || 0) - (a.bugun_cikis || 0);
                    });
                    renderCriticalList();
                }

                if (smartChanged && typeof renderSmartOrderTable === 'function') {
                    window.smartOrderItems.sort((a, b) => {
                        const aOrd = (a.siparis_durumu === 'SIPARIS_VERILDI' || a.siparis_durumu === 'SIPARIS_VERILMEYECEK') ? 1 : 0;
                        const bOrd = (b.siparis_durumu === 'SIPARIS_VERILDI' || b.siparis_durumu === 'SIPARIS_VERILMEYECEK') ? 1 : 0;
                        if (aOrd !== bOrd) return aOrd - bOrd;
                        return 0;
                    });
                    renderSmartOrderTable();
                }

                if (typeof updateMultiDepotCartUI === 'function') {
                    updateMultiDepotCartUI();
                }
            } catch (e) {
                // Sessizce geç
            }
        }

        // Her 10 saniyede bir eczanedeki diğer bilgisayarlarla sipariş durumunu senkronize et
        setInterval(syncTodayOrdersAcrossPCs, 10000);
        setTimeout(() => { updateHideOrderedButtonUI(); syncTodayOrdersAcrossPCs(); }, 1500);

        async function markItemOrderedManually(idx, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            syncCriticalDomStateToMaps();
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;
            const cKey = getCriticalItemKey(item);
            if (cKey && window.criticalCheckedMap) {
                window.criticalCheckedMap[cKey] = false;
            }
            const depo = (window.cardSelectedDepos && window.cardSelectedDepos[idx]) || window.defaultQuickDepo || 'SELCUK';
            const input = document.getElementById(`bulkQtyInput_${idx}`);
            const qty = input ? (parseInt(input.value) || 1) : (item.onerilen_siparis || 1);
            await markItemOrderedDirect(item.barkod || '', item.urun_adi || '', depo, qty);
        }

        function applyOptimisticOrderStatus(itemsList, durum, depo) {
            try {
                const nowStr = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                const pcLabel = window.currentPcName || 'Bu PC';
                window.todayOrdersMap = window.todayOrdersMap || {};
                itemsList.forEach(target => {
                    const bc = String(target.barkod || '').trim();
                    const nm = String(target.urun_adi || '').trim().toUpperCase();
                    if (durum) {
                        const entry = {
                            barkod: bc,
                            urun_adi: target.urun_adi || '',
                            durum: durum,
                            depo: depo || target.depo || 'MANUEL',
                            miktar: target.miktar || 1,
                            masa_adi: pcLabel,
                            saat: nowStr
                        };
                        if (bc) window.todayOrdersMap[bc] = entry;
                        if (nm) window.todayOrdersMap[nm] = entry;
                    } else {
                        if (bc) delete window.todayOrdersMap[bc];
                        if (nm) delete window.todayOrdersMap[nm];
                    }
                    if (Array.isArray(criticalStockItems)) {
                        criticalStockItems.forEach(it => {
                            const itBc = String(it.barkod || '').trim();
                            const itNm = String(it.urun_adi || '').trim().toUpperCase();
                            if ((bc && itBc === bc) || (nm && itNm === nm)) {
                                it.siparis_durumu = durum || null;
                                it.siparis_depo = durum ? (depo || target.depo || 'MANUEL') : null;
                                it.siparis_miktar = durum ? (target.miktar || 1) : null;
                                it.siparis_masa = durum ? pcLabel : null;
                                it.siparis_saat = durum ? nowStr : null;
                            }
                        });
                    }
                    if (Array.isArray(window.smartOrderItems)) {
                        window.smartOrderItems.forEach(it => {
                            const itBc = String(it.barkod || '').trim();
                            const itNm = String(it.urun_adi || '').trim().toUpperCase();
                            if ((bc && itBc === bc) || (nm && itNm === nm)) {
                                it.siparis_durumu = durum || null;
                                it.siparis_depo = durum ? (depo || target.depo || 'MANUEL') : null;
                                it.siparis_miktar = durum ? (target.miktar || 1) : null;
                                it.siparis_masa = durum ? pcLabel : null;
                                it.siparis_saat = durum ? nowStr : null;
                            }
                        });
                    }
                    const activeRep = (typeof currentReport !== 'undefined' && currentReport) ? currentReport : null;
                    if (activeRep) {
                        const curBc = String(activeRep.barkod || '').trim();
                        const curNm = String(activeRep.urun_adi || '').trim().toUpperCase();
                        if ((bc && curBc === bc) || (nm && curNm === nm)) {
                            if (durum) {
                                activeRep.bugun_siparis = {
                                    barkod: bc,
                                    urun_adi: target.urun_adi || '',
                                    durum: durum,
                                    depo: depo || target.depo || 'MANUEL',
                                    miktar: target.miktar || 1,
                                    masa_adi: pcLabel,
                                    saat: nowStr
                                };
                            } else {
                                delete activeRep.bugun_siparis;
                            }
                            if (typeof renderResults === 'function') renderResults(activeRep);
                        }
                    }
                });
                if (Array.isArray(criticalStockItems) && criticalStockItems.length > 0) {
                    criticalStockItems.sort((a, b) => {
                        const aDone = (a.siparis_durumu === 'SIPARIS_VERILDI' || a.siparis_durumu === 'SIPARIS_VERILMEYECEK') ? 1 : 0;
                        const bDone = (b.siparis_durumu === 'SIPARIS_VERILDI' || b.siparis_durumu === 'SIPARIS_VERILMEYECEK') ? 1 : 0;
                        return aDone - bDone;
                    });
                    renderCriticalList();
                }
                if (Array.isArray(window.smartOrderItems) && window.smartOrderItems.length > 0 && typeof renderSmartOrderTable === 'function') {
                    renderSmartOrderTable();
                }
            } catch (optErr) {
                console.warn('Optimistic UI update warning:', optErr);
            }
        }

        async function markItemOrderedDirect(barkod, urunAdi, depo, miktar) {
            try {
                syncCriticalDomStateToMaps();
                const cKey = getCriticalItemKey({ barkod: barkod, urun_adi: urunAdi });
                if (cKey && window.criticalCheckedMap) {
                    window.criticalCheckedMap[cKey] = false;
                }
                applyOptimisticOrderStatus([{ barkod: barkod, urun_adi: urunAdi, depo: depo || 'MANUEL', miktar: miktar || 1 }], 'SIPARIS_VERILDI', depo || 'MANUEL');
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        durum: 'SIPARIS_VERILDI',
                        depo: depo || 'MANUEL',
                        items: [{ barkod: barkod, urun_adi: urunAdi, depo: depo || 'MANUEL', miktar: miktar || 1 }]
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Sipariş Verildi İşaretlendi', `${urunAdi || barkod} tüm bilgisayarlarda 'Sipariş Verildi' olarak işaretlendi.`, 'success');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markItemSkippedManually(idx, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            syncCriticalDomStateToMaps();
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;
            const cKey = getCriticalItemKey(item);
            if (cKey && window.criticalCheckedMap) {
                window.criticalCheckedMap[cKey] = false;
            }
            await markItemSkippedDirect(item.barkod || '', item.urun_adi || '');
        }

        async function markItemSkippedDirect(barkod, urunAdi) {
            try {
                syncCriticalDomStateToMaps();
                const cKey = getCriticalItemKey({ barkod: barkod, urun_adi: urunAdi });
                if (cKey && window.criticalCheckedMap) {
                    window.criticalCheckedMap[cKey] = false;
                }
                applyOptimisticOrderStatus([{ barkod: barkod, urun_adi: urunAdi, depo: 'VERILMEYECEK', miktar: 1 }], 'SIPARIS_VERILMEYECEK', 'VERILMEYECEK');
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        durum: 'SIPARIS_VERILMEYECEK',
                        depo: 'VERILMEYECEK',
                        items: [{ barkod: barkod, urun_adi: urunAdi, depo: 'VERILMEYECEK', miktar: 1 }]
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Sipariş Verilmeyecek İşaretlendi', `${urunAdi || barkod} bugün sipariş verilmeyecek olarak işaretlendi ve listenin altına alındı.`, 'info');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markSelectedCriticalItemsSkipped() {
            syncCriticalDomStateToMaps();
            const checks = document.querySelectorAll('.bulkItemCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', 'Lütfen bugün sipariş verilmeyecek olarak işaretlemek istediğiniz ilaçları seçiniz.', 'info');
                return;
            }
            const itemsToSkip = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
                if (it) {
                    const cKey = getCriticalItemKey(it);
                    if (cKey && window.criticalCheckedMap) {
                        window.criticalCheckedMap[cKey] = false;
                    }
                    itemsToSkip.push({
                        barkod: it.barkod || '',
                        urun_adi: it.urun_adi || '',
                        depo: 'VERILMEYECEK',
                        miktar: 1
                    });
                }
            });
            if (itemsToSkip.length === 0) return;
            try {
                applyOptimisticOrderStatus(itemsToSkip, 'SIPARIS_VERILMEYECEK', 'VERILMEYECEK');
                const res = await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        durum: 'SIPARIS_VERILMEYECEK',
                        depo: 'VERILMEYECEK',
                        items: itemsToSkip
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Toplu Verilmeyecek İşaretlendi', `${itemsToSkip.length} kalem ürün bugün sipariş verilmeyecek olarak işaretlendi.`, 'info');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markItemYokManually(idx, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            syncCriticalDomStateToMaps();
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;
            const cKey = getCriticalItemKey(item);
            if (cKey && window.criticalCheckedMap) {
                window.criticalCheckedMap[cKey] = false;
            }
            await markItemYokDirect(item.barkod || '', item.urun_adi || '');
        }

        async function markItemYokDirect(barkod, urunAdi) {
            try {
                syncCriticalDomStateToMaps();
                const cKey = getCriticalItemKey({ barkod: barkod, urun_adi: urunAdi });
                if (cKey && window.criticalCheckedMap) {
                    window.criticalCheckedMap[cKey] = false;
                }
                applyOptimisticOrderStatus([{ barkod: barkod, urun_adi: urunAdi, depo: 'YOK_LISTESI', miktar: 1 }], 'SIPARIS_VERILMEYECEK', 'YOK_LISTESI');
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        items: [{ barkod: barkod || '', urun_adi: urunAdi || '', kaynak: 'Günün Çıkışları' }]
                    })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('🚨 Yok Listesine Eklendi', `${urunAdi || barkod} doğrudan Yok Listesine eklendi ve işaretlendi.`, 'info');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markSelectedCriticalItemsYok() {
            syncCriticalDomStateToMaps();
            const checks = document.querySelectorAll('.bulkItemCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', 'Lütfen Yok Listesine eklemek istediğiniz ilaçları seçiniz.', 'info');
                return;
            }
            const itemsToYok = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
                if (it) {
                    const cKey = getCriticalItemKey(it);
                    if (cKey && window.criticalCheckedMap) {
                        window.criticalCheckedMap[cKey] = false;
                    }
                    itemsToYok.push({
                        barkod: it.barkod || '',
                        urun_adi: it.urun_adi || '',
                        depo: 'YOK_LISTESI',
                        miktar: 1,
                        kaynak: 'Günün Çıkışları (Toplu)'
                    });
                }
            });
            if (itemsToYok.length === 0) return;
            try {
                applyOptimisticOrderStatus(itemsToYok, 'SIPARIS_VERILMEYECEK', 'YOK_LISTESI');
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ items: itemsToYok })
                });
                const data = await res.json();
                if (data.success) {
                    showToast('🚨 Toplu Yok Listesine Eklendi', `${itemsToYok.length} kalem ürün Yok Listesine eklendi.`, 'info');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function unmarkItemOrderStatus(barkod, urunAdi, ev) {
            if (ev) { ev.stopPropagation(); ev.preventDefault(); }
            try {
                syncCriticalDomStateToMaps();
                applyOptimisticOrderStatus([{ barkod: barkod, urun_adi: urunAdi }], null, null);
                const res = await fetch('/api/orders/unmark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barkod: barkod, urun_adi: urunAdi })
                });
                try {
                    await fetch('/api/orders/today/yok-list/remove', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ barkod: barkod || '', urun_adi: urunAdi || '' })
                    });
                } catch (_) {}
                const data = await res.json();
                if (data.success) {
                    showToast('Sipariş İşareti Kaldırıldı', `${urunAdi || barkod} tekrar sipariş listesine alındı.`, 'info');
                    await syncTodayOrdersAcrossPCs();
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        function toggleCriticalZeroOrNegFilter(targetMode) {
            if (criticalFilterMode === targetMode) {
                setCriticalFilterMode('days_21');
            } else {
                setCriticalFilterMode(targetMode);
            }
        }

        function setCriticalFilterMode(mode) {
            criticalFilterMode = mode;
            const btn21 = document.getElementById('btnCritFilter21');
            const btnAll = document.getElementById('btnCritFilterAll');
            const btnZero = document.getElementById('btnCritFilterZero');
            const btnNegative = document.getElementById('btnCritFilterNegative');
            const btnMf = document.getElementById('btnCritFilterMf');

            const activeClass = 'px-2 py-1 rounded-md font-bold bg-indigo-600 text-white transition text-[10px] cursor-pointer shrink-0';
            const passiveClass = 'px-2 py-1 rounded-md font-semibold bg-slate-100 hover:bg-slate-200 text-slate-600 transition text-[10px] cursor-pointer shrink-0';

            if (btn21) btn21.className = mode === 'days_21' ? activeClass : passiveClass;
            if (btnAll) btnAll.className = mode === 'all' ? activeClass : passiveClass;
            if (btnZero) {
                btnZero.className = mode === 'zero'
                    ? 'px-2 py-1 rounded-md font-bold bg-rose-600 text-white transition text-[10px] cursor-pointer shrink-0 flex items-center space-x-1'
                    : 'px-2 py-1 rounded-md font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition text-[10px] cursor-pointer shrink-0 flex items-center space-x-1';
            }
            if (btnNegative) {
                btnNegative.className = mode === 'negative'
                    ? 'px-2 py-1 rounded-md font-bold bg-rose-700 text-white transition text-[10px] cursor-pointer shrink-0 flex items-center space-x-1'
                    : 'px-2 py-1 rounded-md font-bold bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 transition text-[10px] cursor-pointer shrink-0 flex items-center space-x-1';
            }
            if (btnMf) {
                btnMf.className = mode === 'mf_only' 
                    ? 'px-2 py-1 rounded-md font-bold bg-amber-500 text-white transition text-[10px] cursor-pointer flex items-center space-x-1 shrink-0'
                    : 'px-2 py-1 rounded-md font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 transition text-[10px] cursor-pointer flex items-center space-x-1 shrink-0';
            }

            renderCriticalList();
        }

        function filterCriticalList() {
            renderCriticalList();
        }

        function toggleMfBadgesView() {
            showMfBadges = !showMfBadges;
            localStorage.setItem('showMfBadges', showMfBadges ? 'true' : 'false');
            const btn = document.getElementById('btnToggleMfBadges');
            const txt = document.getElementById('btnToggleMfBadgesText');
            if (showMfBadges) {
                if (btn) btn.className = 'px-1.5 py-1 rounded-md font-bold text-[10px] transition cursor-pointer flex items-center space-x-1 bg-amber-500 text-white hover:bg-amber-600 shrink-0';
                if (txt) txt.innerText = 'MF';
                updateMfBadgesInDom();
                triggerBackgroundMfResolution();
            } else {
                if (btn) btn.className = 'px-1.5 py-1 rounded-md font-bold text-[10px] transition cursor-pointer flex items-center space-x-1 bg-slate-200 text-slate-600 hover:bg-slate-300 shrink-0';
                if (txt) txt.innerText = 'MF';
                updateMfBadgesInDom();
            }
        }

        function updateMfBadgesInDom() {
            if (!window.currentFilteredCriticalItems) return;
            window.currentFilteredCriticalItems.forEach((item, index) => {
                const badgeSlot = document.getElementById(`criticalMfBadge_${index}`);
                if (!badgeSlot) return;
                const hasMf = showMfBadges && item.mf_metni && item.mf_metni !== 'YOK';
                if (hasMf) {
                    badgeSlot.className = 'inline-flex';
                    badgeSlot.innerHTML = `
                        <span class="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded text-[9px] font-black bg-amber-500 text-white" title="${item.mf_depo || 'Depo'}: ${item.mf_metni} MF">
                            <i class="fa-solid fa-gift text-[8px]"></i>
                            <span>${item.mf_metni}</span>
                            <span class="opacity-85 text-[8px]">(${item.mf_depo ? String(item.mf_depo).substring(0, 6) : 'Depo'})</span>
                        </span>
                    `;
                } else {
                    badgeSlot.className = 'hidden';
                    badgeSlot.innerHTML = '';
                }
            });
        }

        async function triggerBackgroundMfResolution() {
            if (!showMfBadges || isMfResolutionRunning) return;
            if (!criticalStockItems || criticalStockItems.length === 0) return;

            const uncachedBarcodes = [];
            criticalStockItems.forEach(it => {
                const bc = (it.barkod || '').toString().trim();
                if (bc && it.mf_metni === undefined && uncachedBarcodes.length < 35) {
                    uncachedBarcodes.push(bc);
                }
            });

            if (uncachedBarcodes.length === 0) return;

            isMfResolutionRunning = true;
            try {
                const res = await fetch('/api/otomasyon/resolve-mf', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barcodes: uncachedBarcodes })
                });
                if (res.ok) {
                    const data = await res.json();
                    const results = data.results || {};
                    criticalStockItems.forEach(it => {
                        const bc = (it.barkod || '').toString().trim();
                        if (bc in results) {
                            const mfObj = results[bc];
                            if (mfObj && mfObj.mf) {
                                it.mf_metni = mfObj.mf;
                                it.mf_depo = mfObj.depo || 'Depo';
                            } else {
                                it.mf_metni = null;
                                it.mf_depo = null;
                            }
                        }
                    });
                    updateMfBadgesInDom();
                }
            } catch(e) {
                console.error('MF resolution error:', e);
            } finally {
                isMfResolutionRunning = false;
            }
        }

        function renderCriticalList() {
            const container = document.getElementById('criticalStockListContainer');
            if (!container) return;

            syncCriticalDomStateToMaps();
            window.criticalCheckedMap = window.criticalCheckedMap || {};
            window.criticalCustomQtyMap = window.criticalCustomQtyMap || {};

            const searchInput = document.getElementById('criticalFilterInput');
            const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

            // Sipariş sayacını güncelle
            const totalOrderedCount = (criticalStockItems || []).filter(x => !!x.siparis_durumu).length;
            const ordBadge = document.getElementById('orderedTodayCountBadge');
            if (ordBadge) ordBadge.innerText = `${totalOrderedCount} İşlem`;

            // Tükenen (==0) ve Eksiye Düşen (<0) sayaçlarını güncelle
            const baseForCounts = (criticalStockItems || []).filter(item => {
                if (hideOrderedItems && (item.siparis_durumu === 'SIPARIS_VERILDI' || item.siparis_durumu === 'SIPARIS_VERILMEYECEK')) return false;
                if (q) {
                    const name = (item.urun_adi || '').toLowerCase();
                    const barcode = (item.barkod || '').toLowerCase();
                    if (!name.includes(q) && !barcode.includes(q)) return false;
                }
                return true;
            });
            const zeroCount = baseForCounts.filter(x => Number(x.stok || 0) === 0).length;
            const negativeList = baseForCounts.filter(x => Number(x.stok || 0) < 0);
            const negativeCount = negativeList.length;

            const zeroBadgeEl = document.getElementById('critZeroCountBadge');
            const negBadgeEl = document.getElementById('critNegativeCountBadge');
            if (zeroBadgeEl) zeroBadgeEl.innerText = `${zeroCount}`;
            if (negBadgeEl) negBadgeEl.innerText = `${negativeCount}`;

            let filtered = criticalStockItems.filter(item => {
                if (hideOrderedItems && (item.siparis_durumu === 'SIPARIS_VERILDI' || item.siparis_durumu === 'SIPARIS_VERILMEYECEK')) return false;
                const stokVal = Number(item.stok || 0);
                const effectiveAylik = Math.max(item.aylik_cikis || 0, item.bugun_cikis || 1);
                const stokGun = item.stok_gun !== undefined ? item.stok_gun : (stokVal <= 0 ? 0 : Math.round((stokVal * 300.0) / effectiveAylik) / 10);
                if (criticalFilterMode === 'days_21' && stokVal > 0 && stokGun > 21) return false;
                if (criticalFilterMode === 'zero' && stokVal !== 0) return false;
                if (criticalFilterMode === 'negative' && stokVal >= 0) return false;
                const hasAnyMf = (item.mf_metni && item.mf_metni !== 'YOK') || !!item.gecmis_mf_var;
                if (criticalFilterMode === 'mf_only' && !hasAnyMf) return false;
                if (q) {
                    const name = (item.urun_adi || '').toLowerCase();
                    const barcode = (item.barkod || '').toLowerCase();
                    return name.includes(q) || barcode.includes(q);
                }
                return true;
            });

            if (filtered.length === 0) {
                window.currentFilteredCriticalItems = [];
                let emptyMsg = 'Kriterlere uyan kritik ürün bulunamadı.';
                if (criticalFilterMode === 'negative') emptyMsg = "Bugün çıkışı olup stoğu eksiye (<0) düşen ürün bulunmuyor.";
                else if (criticalFilterMode === 'zero') emptyMsg = "Bugün çıkışı olup stoğu tam 0'a inen ürün bulunmuyor.";
                container.innerHTML = `
                    <div class="p-6 text-center text-slate-400 text-xs bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
                        <i class="fa-solid fa-box-open text-xl text-slate-300 mb-1.5 block"></i>
                        ${emptyMsg}
                    </div>
                `;
                updateBulkSelectionCount();
                return;
            }

            window.currentFilteredCriticalItems = filtered;
            container.innerHTML = filtered.map((item, index) => {
                const stokVal = Number(item.stok || 0);
                const effectiveAylik = Math.max(item.aylik_cikis || 0, item.bugun_cikis || 1);
                const stokGun = item.stok_gun !== undefined ? item.stok_gun : (stokVal <= 0 ? 0 : Math.round((stokVal * 300.0) / effectiveAylik) / 10);
                
                // 3 Renk Kuralına Uygun Stok Rozeti (Kırmızı / Kehribar / Yeşil)
                let stockBadgeClass = 'bg-slate-100 text-slate-700 border-slate-200';
                let stockText = `${stokVal} Kt`;

                if (stokVal < 0) {
                    stockBadgeClass = 'bg-rose-600 text-white border-rose-700 font-black';
                    stockText = `EKSİ (${stokVal} Kt)`;
                } else if (stokVal === 0) {
                    stockBadgeClass = 'bg-rose-100 text-rose-700 border-rose-200 font-extrabold';
                    stockText = '0 Kt (Tükendi)';
                } else if (stokGun <= 7) {
                    stockBadgeClass = 'bg-rose-50 text-rose-700 border-rose-200 font-bold';
                    stockText = `${stokVal} Kt (${stokGun}G)`;
                } else if (stokGun <= 14) {
                    stockBadgeClass = 'bg-amber-50 text-amber-800 border-amber-200 font-bold';
                    stockText = `${stokVal} Kt (${stokGun}G)`;
                } else {
                    stockBadgeClass = 'bg-emerald-50 text-emerald-700 border-emerald-200 font-semibold';
                    stockText = `${stokVal} Kt (${stokGun}G)`;
                }

                const safeName = (item.urun_adi || '').replace(/'/g, "\\\\'");
                const safeBc = (item.barkod || '').replace(/'/g, "\\\\'");
                const itemKey = getCriticalItemKey(item);
                const isAlreadyOrderedOrInCart = !!item.siparis_durumu;

                // Varsayılan olarak hiçbir ürün seçili gelmez; sadece kullanıcının işaretledikleri seçili kalır
                let isInitialSelected = false;
                if (itemKey && window.criticalCheckedMap && typeof window.criticalCheckedMap[itemKey] === 'boolean') {
                    isInitialSelected = isAlreadyOrderedOrInCart ? false : window.criticalCheckedMap[itemKey];
                } else if (itemKey && window.criticalCheckedMap) {
                    window.criticalCheckedMap[itemKey] = false;
                }

                const savedQty = (itemKey && window.criticalCustomQtyMap && window.criticalCustomQtyMap[itemKey])
                    ? window.criticalCustomQtyMap[itemKey]
                    : (item.onerilen_siparis || item.bugun_cikis || 1);
                const hasMf = showMfBadges && item.mf_metni && item.mf_metni !== 'YOK';

                // Kompakt Sipariş Durumu Şeridi
                let orderStatusHtml = '';
                let cardWrapperClass = stokVal < 0
                    ? 'bg-rose-50/30 hover:bg-rose-50/60 border border-rose-200 border-l-4 border-l-rose-600'
                    : 'bg-white hover:bg-slate-50/80 border border-slate-200/90 hover:border-indigo-300';
                if (item.siparis_durumu === 'SIPARIS_VERILDI') {
                    cardWrapperClass = 'bg-emerald-50/40 border border-emerald-300 opacity-80';
                    orderStatusHtml = `
                        <div class="flex items-center justify-between px-2 py-0.5 mb-1 rounded bg-emerald-600 text-white text-[9px] font-bold" onclick="event.stopPropagation()">
                            <span class="truncate"><i class="fa-solid fa-check mr-1"></i>SİPARİŞ VERİLDİ • ${item.siparis_depo || 'DEPO'} (${item.siparis_miktar || 1} Kt)</span>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event)" class="ml-1 px-1 rounded bg-white/20 hover:bg-white/30 text-white text-[8px] cursor-pointer shrink-0">İptal ×</button>
                        </div>
                    `;
                } else if (item.siparis_durumu === 'SIPARIS_VERILMEYECEK') {
                    const isYokList = String(item.siparis_depo || '').toUpperCase() === 'YOK_LISTESI';
                    cardWrapperClass = isYokList
                        ? 'bg-rose-50/40 border border-rose-300 opacity-85'
                        : 'bg-slate-100/70 border border-slate-200 opacity-75';
                    orderStatusHtml = `
                        <div class="flex items-center justify-between px-2 py-0.5 mb-1 rounded ${isYokList ? 'bg-rose-600' : 'bg-slate-600'} text-white text-[9px] font-bold" onclick="event.stopPropagation()">
                            <span class="truncate"><i class="fa-solid ${isYokList ? 'fa-triangle-exclamation' : 'fa-ban'} mr-1"></i>${isYokList ? '🚨 YOK LİSTESİNDE (DEPOLARDA YOK)' : 'SİPARİŞ VERİLMEYECEK'}</span>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event)" class="ml-1 px-1 rounded bg-white/20 hover:bg-white/30 text-white text-[8px] cursor-pointer shrink-0">İptal ×</button>
                        </div>
                    `;
                } else if (item.siparis_durumu === 'SEPETTE') {
                    cardWrapperClass = 'bg-amber-50/40 border border-amber-300';
                    orderStatusHtml = `
                        <div class="flex items-center justify-between px-2 py-0.5 mb-1 rounded bg-amber-100 border border-amber-300 text-amber-950 text-[9px] font-bold" onclick="event.stopPropagation()">
                            <span class="truncate"><i class="fa-solid fa-cart-shopping text-amber-600 mr-1"></i>SEPETTE • ${item.siparis_depo || 'DEPO'} (${item.siparis_miktar || 1} Kt)</span>
                            <div class="flex items-center space-x-1 shrink-0 ml-1">
                                <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeName}', '${item.siparis_depo || 'SELCUK'}', ${item.siparis_miktar || 1})" class="px-1.5 py-0.2 rounded bg-emerald-600 text-white text-[8px] font-bold cursor-pointer">✓ Onayla</button>
                                <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeName}', event)" class="px-1 py-0.2 rounded bg-white text-slate-600 border border-amber-300 text-[8px] font-bold cursor-pointer">×</button>
                            </div>
                        </div>
                    `;
                }

                // Depo seçimi
                window.cardSelectedDepos = window.cardSelectedDepos || {};
                const activeDeposList = (typeof getActiveBulkDepos === 'function') ? getActiveBulkDepos() : ['ALLIANCE', 'SELCUK', 'ISKOOP', 'NEVZAT'];
                const defaultActiveDepo = activeDeposList[0] || window.defaultQuickDepo || 'ALLIANCE';
                let cardDepo = window.cardSelectedDepos[index];
                if (!cardDepo && item.mf_depo) {
                    const dUpper = String(item.mf_depo).toUpperCase();
                    if (dUpper.includes('ALLIANCE')) cardDepo = 'ALLIANCE';
                    else if (dUpper.includes('SELCUK') || dUpper.includes('SELÇUK')) cardDepo = 'SELCUK';
                    else if (dUpper.includes('ISKOOP') || dUpper.includes('İSKOOP')) cardDepo = 'ISKOOP';
                    else if (dUpper.includes('NEVZAT')) cardDepo = 'NEVZAT';
                }
                if (!cardDepo || !activeDeposList.includes(cardDepo)) {
                    cardDepo = defaultActiveDepo;
                }
                window.cardSelectedDepos[index] = cardDepo;

                const curDepoCfg = (typeof QUICK_DEPO_CONFIGS !== 'undefined' && QUICK_DEPO_CONFIGS[cardDepo]) 
                    ? QUICK_DEPO_CONFIGS[cardDepo] 
                    : { name: 'Alliance Healthcare', shortName: 'Alliance', actionText: "Alliance'a At", bgClass: 'bg-sky-600 hover:bg-sky-700', chevronClass: 'bg-sky-700 hover:bg-sky-800', icon: 'fa-solid fa-truck-fast' };

                // 2-KATMANLI KOMPAKT SATIR — Üstte %100 Tam İlaç İsmi (Kısaltmasız), Altta Rozetler ve Aksiyonlar
                return `
                    <div class="${cardWrapperClass} rounded-xl px-3 py-2 transition group">
                        ${orderStatusHtml}
                        <!-- 1. KATMAN: Checkbox + Tam İlaç İsmi (Kısaltmasız %100 Genişlik) -->
                        <div class="flex items-start space-x-2">
                            <input 
                                type="checkbox" 
                                style="accent-color: #4f46e5;"
                                class="bulkItemCheck rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 mt-0.5 cursor-pointer shrink-0" 
                                data-idx="${index}" 
                                data-ordered="${isAlreadyOrderedOrInCart ? '1' : '0'}"
                                onchange="updateBulkSelectionCount()" 
                                ${isInitialSelected ? 'checked' : ''} 
                            />
                            <div class="cursor-pointer flex-1 min-w-0" onclick="searchFromCriticalByIndex(${index})">
                                <h4 class="font-extrabold text-[12.5px] leading-snug ${item.siparis_durumu === 'SIPARIS_VERILDI' || item.siparis_durumu === 'SIPARIS_VERILMEYECEK' ? 'line-through text-slate-400' : 'text-slate-900 group-hover:text-indigo-700'} break-words" title="Barkod: ${item.barkod || '-'} • Tıklayıp tüm depolarda karşılaştırın">
                                    ${item.urun_adi}
                                </h4>
                            </div>
                        </div>

                        <!-- 2. KATMAN: Sol: Stok/Çıkış/MF Rozetleri — Sağ: - [Adet] + & Hızlı Aksiyonlar -->
                        <div class="flex items-center justify-between gap-2 mt-1.5 pl-6">
                            <!-- Sol: Kritik Stok, Çıkış ve MF Rozetleri -->
                            <div class="flex flex-wrap items-center gap-1 min-w-0 cursor-pointer" onclick="searchFromCriticalByIndex(${index})">
                                <!-- Stok Rozeti -->
                                <span class="px-1.5 py-0.5 rounded text-[9.5px] leading-none border ${stockBadgeClass}" title="Mevcut Stok: ${item.stok} Kutu • Kalan Süre: ${stokGun} Gün">
                                    ${stockText}
                                </span>
                                <!-- Bugün & Aylık Çıkış Rozeti -->
                                <span class="px-1.5 py-0.5 rounded text-[9.5px] leading-none bg-slate-100 text-slate-700 font-semibold border border-slate-200/70" title="Bugün Çıkış: ${item.bugun_cikis} Kt • Son 30 Gün: ${item.aylik_cikis} Kt">
                                    Bugün:<strong class="text-slate-900 ml-0.5">${item.bugun_cikis}</strong> • Ay:<strong class="text-slate-900 ml-0.5">${item.aylik_cikis}</strong>
                                </span>
                                <!-- Canlı MF Rozeti -->
                                <span id="criticalMfBadge_${index}" class="${hasMf ? 'inline-flex' : 'hidden'}">
                                    ${hasMf ? `
                                        <span class="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[9.5px] leading-none font-black bg-amber-500 text-white" title="${item.mf_depo || 'Depo'}: ${item.mf_metni} MF">
                                            <i class="fa-solid fa-gift text-[8px]"></i>
                                            <span>${item.mf_metni}</span>
                                            <span class="opacity-85 text-[8px]">(${item.mf_depo ? String(item.mf_depo).substring(0, 6) : 'Depo'})</span>
                                        </span>
                                    ` : ''}
                                </span>
                                <!-- Geçmiş MF İkonu -->
                                ${item.gecmis_mf_var ? `
                                    <span class="inline-flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9.5px] leading-none font-bold bg-amber-50 text-amber-800 border border-amber-200 cursor-help" title="${item.gecmis_mf_bilgi || 'Geçmişte MF ile alım yapılmış.'}">
                                        <i class="fa-solid fa-star text-amber-500 text-[8px]"></i>
                                        <span>${item.gecmis_mf_kisa || 'MF'}</span>
                                    </span>
                                ` : ''}
                            </div>

                            <!-- Sağ: - [Adet] + Stepper & Tek Tık Aksiyon Butonları -->
                            <div class="flex items-center space-x-1 shrink-0" onclick="event.stopPropagation()">
                                <!-- - [Adet] + -->
                                <div class="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200" title="Sipariş Adedi">
                                    <button type="button" onclick="changeBulkItemQty(${index}, -1)" class="w-5 h-5 rounded bg-white hover:bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-[10px] cursor-pointer">-</button>
                                    <input 
                                        type="number" 
                                        id="bulkQtyInput_${index}" 
                                        value="${savedQty}" 
                                        min="1" 
                                        max="999" 
                                        oninput="updateBulkSelectionCount()" 
                                        class="w-7 text-center text-[11px] font-black font-mono py-0 border-0 bg-transparent focus:ring-0 text-slate-900" 
                                    />
                                    <button type="button" onclick="changeBulkItemQty(${index}, 1)" class="w-5 h-5 rounded bg-white hover:bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-[10px] cursor-pointer">+</button>
                                </div>

                                <!-- Karşılaştır İkon Butonu -->
                                <button 
                                    type="button" 
                                    onclick="searchFromCriticalByIndex(${index})" 
                                    class="w-6 h-6 bg-slate-100 hover:bg-indigo-600 hover:text-white text-slate-600 rounded-lg transition flex items-center justify-center cursor-pointer"
                                    title="Tüm depolarda canlı fiyat ve şartları karşılaştır"
                                >
                                    <i class="fa-solid fa-code-compare text-[10px]"></i>
                                </button>

                                <!-- Seçimli Depoya At Split Butonu -->
                                <div class="relative flex items-stretch rounded-lg" id="quickAddWrapper_${index}">
                                    <button 
                                        type="button" 
                                        onclick="sendSingleCriticalToDepo(${index})" 
                                        id="btnQuickAdd_${index}" 
                                        class="h-6 px-2 ${curDepoCfg.bgClass} text-white font-bold text-[10px] rounded-l-lg transition flex items-center space-x-1 cursor-pointer"
                                        title="Bu ilacı ${curDepoCfg.name} sepetine ekle"
                                    >
                                        <i class="${curDepoCfg.icon} text-[9px]" id="btnQuickAddIcon_${index}"></i>
                                        <span id="btnQuickAddText_${index}">${curDepoCfg.shortName}</span>
                                    </button>
                                    <button 
                                        type="button" 
                                        onclick="toggleCardDepoMenu(${index}, event)" 
                                        id="btnQuickAddChevron_${index}" 
                                        class="w-4 h-6 ${curDepoCfg.chevronClass} text-white/90 hover:text-white border-l border-white/20 rounded-r-lg transition flex items-center justify-center cursor-pointer"
                                        title="Hedef depoyu değiştir"
                                    >
                                        <i class="fa-solid fa-caret-down text-[8px]"></i>
                                    </button>

                                    <!-- Açılır Depo Menüsü -->
                                    <div id="cardDepoMenu_${index}" class="hidden absolute right-0 bottom-full mb-1 z-50 w-40 bg-white border border-slate-200 rounded-xl shadow-xl py-1 text-xs divide-y divide-slate-100">
                                        <div class="py-0.5">
                                            ${activeDeposList.includes('ALLIANCE') ? `
                                            <button type="button" onclick="setCardDepo(${index}, 'ALLIANCE', false, event)" class="w-full text-left px-2.5 py-1 flex items-center space-x-2 hover:bg-sky-50 text-slate-700 font-semibold cursor-pointer">
                                                <span class="w-2 h-2 rounded-full bg-sky-500 shrink-0"></span>
                                                <span class="flex-1 text-[11px]">Alliance</span>
                                                ${cardDepo === 'ALLIANCE' ? '<i class="fa-solid fa-check text-[10px] text-sky-600"></i>' : ''}
                                            </button>` : ''}
                                            ${activeDeposList.includes('SELCUK') ? `
                                            <button type="button" onclick="setCardDepo(${index}, 'SELCUK', false, event)" class="w-full text-left px-2.5 py-1 flex items-center space-x-2 hover:bg-rose-50 text-slate-700 font-semibold cursor-pointer">
                                                <span class="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
                                                <span class="flex-1 text-[11px]">Selçuk</span>
                                                ${cardDepo === 'SELCUK' ? '<i class="fa-solid fa-check text-[10px] text-rose-600"></i>' : ''}
                                            </button>` : ''}
                                            ${activeDeposList.includes('ISKOOP') ? `
                                            <button type="button" onclick="setCardDepo(${index}, 'ISKOOP', false, event)" class="w-full text-left px-2.5 py-1 flex items-center space-x-2 hover:bg-emerald-50 text-slate-700 font-semibold cursor-pointer">
                                                <span class="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                                                <span class="flex-1 text-[11px]">İSKOOP</span>
                                                ${cardDepo === 'ISKOOP' ? '<i class="fa-solid fa-check text-[10px] text-emerald-600"></i>' : ''}
                                            </button>` : ''}
                                            ${activeDeposList.includes('NEVZAT') ? `
                                            <button type="button" onclick="setCardDepo(${index}, 'NEVZAT', false, event)" class="w-full text-left px-2.5 py-1 flex items-center space-x-2 hover:bg-amber-50 text-slate-700 font-semibold cursor-pointer">
                                                <span class="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                                                <span class="flex-1 text-[11px]">Nevzat</span>
                                                ${cardDepo === 'NEVZAT' ? '<i class="fa-solid fa-check text-[10px] text-amber-600"></i>' : ''}
                                            </button>` : ''}
                                        </div>
                                        <div class="py-0.5">
                                            <button type="button" onclick="setCardDepo(${index}, '${cardDepo}', true, event)" class="w-full text-left px-2.5 py-1 text-[10px] text-slate-600 hover:bg-slate-100 cursor-pointer flex items-center space-x-1 font-bold">
                                                <i class="fa-solid fa-check-double text-[9px] text-indigo-600"></i>
                                                <span>Tümünü buna ayarla</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tek Tık Durum İkonları (Sipariş Verildi / Verilmeyecek / Yok Listesi) -->
                                ${!item.siparis_durumu ? `
                                    <button type="button" onclick="markItemOrderedManually(${index}, event)" class="w-6 h-6 rounded-lg bg-slate-50 hover:bg-emerald-50 text-slate-400 hover:text-emerald-600 border border-slate-200/80 transition flex items-center justify-center cursor-pointer" title="Başka yerden sipariş verildi olarak işaretle">
                                        <i class="fa-solid fa-check text-[10px]"></i>
                                    </button>
                                    <button type="button" onclick="markItemSkippedManually(${index}, event)" class="w-6 h-6 rounded-lg bg-slate-50 hover:bg-slate-200 text-slate-400 hover:text-slate-700 border border-slate-200/80 transition flex items-center justify-center cursor-pointer" title="Bugün sipariş verilmeyecek olarak işaretle">
                                        <i class="fa-solid fa-ban text-[10px]"></i>
                                    </button>
                                    <button type="button" onclick="markItemYokManually(${index}, event)" class="w-6 h-6 rounded-lg bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white border border-rose-200 transition flex items-center justify-center cursor-pointer" title="Doğrudan Yok Listesine ekle (Yok olarak işaretle)">
                                        <i class="fa-solid fa-triangle-exclamation text-[10px]"></i>
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                    </div>
                `;
            }).join('');

            window.criticalInitialSelectionDone = true;
            updateBulkSelectionCount();
            triggerBackgroundMfResolution();
        }

        function searchFromCriticalByIndex(idx) {
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;

            // 1. Depo sekmesine geç
            if (typeof switchMainView === 'function') {
                switchMainView('depo');
            }

            // 2. Sağ çekmeceyi hemen kapat
            if (typeof toggleSideWidget === 'function') {
                toggleSideWidget(false);
            }

            // 3. Arama inputuna ürün adını veya barkodu yaz
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.value = item.urun_adi || item.barkod;
            }

            // 4. Öneri ve ara seçim kutularını kapat
            const suggestBox = document.getElementById('suggestBox');
            if (suggestBox) suggestBox.classList.add('hidden');
            const productSelection = document.getElementById('productSelection');
            if (productSelection) productSelection.classList.add('hidden');

            // 5. Sayfanın en üstüne yumuşakça kaydır
            window.scrollTo({ top: 0, behavior: 'smooth' });

            // 6. ANINDA CANLI DEPO SORGULAMASINI BAŞLAT
            const barcode = (item.barkod || '').toString().trim();
            const uid = (item.urun_id || item.mal_kodu || '').toString().trim();
            if (barcode && /^\\d{8,14}$/.test(barcode)) {
                performBarcodeSearch(barcode, item.urun_adi || '', uid);
            } else {
                handleSearchSubmit(item.urun_adi || barcode);
            }
        }

        function searchFromCritical(barcodeOrName, title) {
            if (typeof switchMainView === 'function') {
                switchMainView('depo');
            }
            if (typeof toggleSideWidget === 'function') {
                toggleSideWidget(false);
            }
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.value = title || barcodeOrName;
            }
            const suggestBox = document.getElementById('suggestBox');
            if (suggestBox) suggestBox.classList.add('hidden');
            const productSelection = document.getElementById('productSelection');
            if (productSelection) productSelection.classList.add('hidden');
            window.scrollTo({ top: 0, behavior: 'smooth' });

            const q = (barcodeOrName || '').toString().trim();
            if (q && /^\\d{8,14}$/.test(q)) {
                performBarcodeSearch(q, title || '');
            } else {
                handleSearchSubmit(title || q);
            }
        }

        // Global switchTab fonksiyonu (tam uyumluluk)
        function switchTab(t) {
            if (typeof switchMainView === 'function') switchMainView(t);
        }

        function toggleSideWidget(open) {
            const widget = document.getElementById('criticalSideWidget');
            const miniBtn = document.getElementById('criticalMiniBadgeBtn');
            if (!widget || !miniBtn) return;
            if (open) {
                widget.classList.remove('hidden');
                miniBtn.classList.add('hidden');
            } else {
                widget.classList.add('hidden');
                miniBtn.classList.remove('hidden');
            }
        }

        // ================= Toplu Sipariş Gönderici & Akıllı Şelale Dağıtıcısı =================
        function syncMasterCheckboxVisual(isChecked) {
            const masterCheck = document.getElementById('bulkSelectAllCheck');
            const box = document.getElementById('bulkSelectAllVisualBox');
            const icon = document.getElementById('bulkSelectAllVisualIcon');
            if (masterCheck) {
                masterCheck.checked = !!isChecked;
                masterCheck.indeterminate = false;
            }
            if (box) {
                box.className = isChecked
                    ? 'w-4 h-4 rounded border-2 border-sky-600 bg-sky-600 text-white flex items-center justify-center transition-all shadow-2xs group-hover:ring-2 group-hover:ring-sky-300'
                    : 'w-4 h-4 rounded border-2 border-slate-400 bg-white text-transparent flex items-center justify-center transition-all shadow-2xs group-hover:border-sky-500';
            }
            if (icon) {
                icon.className = isChecked
                    ? 'fa-solid fa-check text-[10px] leading-none text-white opacity-100'
                    : 'fa-solid fa-check text-[10px] leading-none text-transparent opacity-0';
            }
        }

        function handleMasterSelectClick(ev) {
            if (ev) {
                ev.preventDefault();
                ev.stopPropagation();
            }
            const masterCheck = document.getElementById('bulkSelectAllCheck');
            const allChecks = Array.from(document.querySelectorAll('.bulkItemCheck'));
            if (allChecks.length === 0) {
                syncMasterCheckboxVisual(false);
                return;
            }
            const currentlyChecked = masterCheck ? !!masterCheck.checked : false;
            const nextState = !currentlyChecked;
            if (masterCheck) masterCheck.checked = nextState;
            toggleBulkSelectAll(masterCheck || { checked: nextState });
        }

        function updateBulkSelectionCount(preserveMaster = false) {
            syncCriticalDomStateToMaps();
            const allChecks = Array.from(document.querySelectorAll('.bulkItemCheck'));
            const checkedChecks = allChecks.filter(c => c.checked);
            const count = checkedChecks.length;
            const badge = document.getElementById('bulkSelectedBadge');
            const masterCheck = document.getElementById('bulkSelectAllCheck');

            if (badge) badge.innerText = `${count} Seçili`;
            if (masterCheck) {
                if (!preserveMaster) {
                    const unorderedChecks = allChecks.filter(c => c.dataset.ordered !== '1');
                    const targetPool = unorderedChecks.length > 0 ? unorderedChecks : allChecks;
                    const isAllSelected = targetPool.length > 0 && targetPool.every(c => c.checked);
                    syncMasterCheckboxVisual(isAllSelected);
                } else {
                    syncMasterCheckboxVisual(!!masterCheck.checked);
                }
            }
        }

        function toggleBulkSelectAll(master) {
            const allChecks = Array.from(document.querySelectorAll('.bulkItemCheck'));
            const shouldSelect = !!(master && master.checked);
            if (shouldSelect) {
                const unorderedChecks = allChecks.filter(c => c.dataset.ordered !== '1');
                if (unorderedChecks.length > 0) {
                    allChecks.forEach(c => {
                        c.checked = (c.dataset.ordered !== '1');
                    });
                } else {
                    allChecks.forEach(c => {
                        c.checked = true;
                    });
                }
                syncMasterCheckboxVisual(true);
            } else {
                allChecks.forEach(c => {
                    c.checked = false;
                });
                syncMasterCheckboxVisual(false);
            }
            syncCriticalDomStateToMaps();
            updateBulkSelectionCount(true);
        }

        function selectTopNItems(n = 40) {
            const checks = document.querySelectorAll('.bulkItemCheck');
            let selectedSoFar = 0;
            checks.forEach((c) => {
                if (c.dataset.ordered !== '1' && selectedSoFar < n) {
                    c.checked = true;
                    selectedSoFar++;
                } else {
                    c.checked = false;
                }
            });
            syncCriticalDomStateToMaps();
            updateBulkSelectionCount(false);
        }

        function clearBulkSelection() {
            const checks = document.querySelectorAll('.bulkItemCheck');
            checks.forEach(c => c.checked = false);
            if (window.criticalCheckedMap) {
                Object.keys(window.criticalCheckedMap).forEach(k => {
                    window.criticalCheckedMap[k] = false;
                });
            }
            syncCriticalDomStateToMaps();
            syncMasterCheckboxVisual(false);
            updateBulkSelectionCount(true);
        }

        function changeBulkItemQty(idx, delta) {
            const input = document.getElementById(`bulkQtyInput_${idx}`);
            if (!input) return;
            let val = parseInt(input.value) || 1;
            val = Math.max(1, val + delta);
            input.value = val;
            syncCriticalDomStateToMaps();
            updateBulkSelectionCount();
        }

        const DEPO_CART_META = {
            'ALLIANCE': {
                code: 'ALLIANCE',
                name: 'Alliance Healthcare',
                shortName: 'Alliance',
                portalUrl: 'https://esiparisv2.alliance-healthcare.com.tr/Sales/OrderBasket',
                pillClass: 'bg-sky-500/25 hover:bg-sky-500/40 text-sky-200 border-sky-400/40',
                headerPillClass: 'bg-sky-100 text-sky-800 border-sky-300',
                cardHeaderClass: 'from-sky-900 via-sky-800 to-slate-900',
                badgeClass: 'bg-sky-600 text-white'
            },
            'SELCUK': {
                code: 'SELCUK',
                name: 'Selçuk Ecza Deposu',
                shortName: 'Selçuk',
                portalUrl: 'https://webdepo.selcukecza.com.tr/Siparis/Sepet.aspx',
                pillClass: 'bg-rose-500/25 hover:bg-rose-500/40 text-rose-200 border-rose-400/40',
                headerPillClass: 'bg-rose-100 text-rose-800 border-rose-300',
                cardHeaderClass: 'from-rose-900 via-rose-800 to-slate-900',
                badgeClass: 'bg-rose-600 text-white'
            },
            'ISKOOP': {
                code: 'ISKOOP',
                name: 'İstanbul Ecza Koop (İSKOOP)',
                shortName: 'İSKOOP',
                portalUrl: 'https://esube.iskoop.org/irj/portal',
                pillClass: 'bg-emerald-500/25 hover:bg-emerald-500/40 text-emerald-200 border-emerald-400/40',
                headerPillClass: 'bg-emerald-100 text-emerald-800 border-emerald-300',
                cardHeaderClass: 'from-emerald-900 via-teal-800 to-slate-900',
                badgeClass: 'bg-emerald-600 text-white'
            },
            'NEVZAT': {
                code: 'NEVZAT',
                name: 'Nevzat Ecza Deposu',
                shortName: 'Nevzat',
                portalUrl: 'https://eticaret.nevzatecza.com.tr/',
                pillClass: 'bg-amber-500/25 hover:bg-amber-500/40 text-amber-200 border-amber-400/40',
                headerPillClass: 'bg-amber-100 text-amber-900 border-amber-300',
                cardHeaderClass: 'from-amber-900 via-orange-800 to-slate-900',
                badgeClass: 'bg-amber-600 text-white'
            },
            'BEK': {
                code: 'BEK',
                name: 'Bursa Ecza Koop (BEK)',
                shortName: 'BEK',
                portalUrl: 'https://eticaret.bek.org.tr/',
                pillClass: 'bg-indigo-500/25 hover:bg-indigo-500/40 text-indigo-200 border-indigo-400/40',
                headerPillClass: 'bg-indigo-100 text-indigo-800 border-indigo-300',
                cardHeaderClass: 'from-indigo-900 via-indigo-800 to-slate-900',
                badgeClass: 'bg-indigo-600 text-white'
            },
            'DNA': {
                code: 'DNA',
                name: 'DNA Ecza Deposu',
                shortName: 'DNA',
                portalUrl: '#',
                pillClass: 'bg-purple-500/25 hover:bg-purple-500/40 text-purple-200 border-purple-400/40',
                headerPillClass: 'bg-purple-100 text-purple-800 border-purple-300',
                cardHeaderClass: 'from-purple-900 via-purple-800 to-slate-900',
                badgeClass: 'bg-purple-600 text-white'
            }
        };

        window.singleAddDepoMeta = window.singleAddDepoMeta || {};
        window.activeMultiDepotCartTab = window.activeMultiDepotCartTab || 'ALL';

        function recordDepotSessionFromSingleAdd(depo, sepetTutari, sepetNo, portalUrl) {
            const dKey = (depo || 'SELCUK').toUpperCase();
            window.singleAddDepoMeta = window.singleAddDepoMeta || {};
            const prev = window.singleAddDepoMeta[dKey] || {};
            window.singleAddDepoMeta[dKey] = {
                sepetTutari: sepetTutari || prev.sepetTutari || '',
                sepetNo: sepetNo || prev.sepetNo || '',
                portalUrl: portalUrl || prev.portalUrl || (DEPO_CART_META[dKey] && DEPO_CART_META[dKey].portalUrl) || ''
            };
        }

        function getActiveCartGroupsByDepo() {
            const ordersMap = window.todayOrdersMap || {};
            const groups = {};
            const seenPerDepo = {};

            function ensureDepoGroup(depoCode) {
                const dKey = (depoCode || 'SELCUK').toUpperCase();
                if (!groups[dKey]) {
                    const meta = DEPO_CART_META[dKey] || {
                        code: dKey,
                        name: dKey,
                        shortName: dKey,
                        portalUrl: '#',
                        pillClass: 'bg-indigo-500/25 hover:bg-indigo-500/40 text-indigo-200 border-indigo-400/40',
                        headerPillClass: 'bg-indigo-100 text-indigo-800 border-indigo-300',
                        cardHeaderClass: 'from-indigo-900 via-slate-800 to-slate-900',
                        badgeClass: 'bg-indigo-600 text-white'
                    };
                    const bulkSess = (window.currentBulkState && window.currentBulkState.depoSessions && window.currentBulkState.depoSessions[dKey]) || {};
                    const singleMeta = (window.singleAddDepoMeta && window.singleAddDepoMeta[dKey]) || {};
                    groups[dKey] = {
                        ...meta,
                        portalUrl: bulkSess.portal_url || singleMeta.portalUrl || meta.portalUrl,
                        sepetTutari: singleMeta.sepetTutari || (bulkSess.amount ? bulkSess.amount.toFixed(2) : ''),
                        sepetNo: singleMeta.sepetNo || '',
                        items: [],
                        totalBoxes: 0
                    };
                    seenPerDepo[dKey] = new Set();
                }
                return groups[dKey];
            }

            // 1. /api/orders/today üzerindeki SEPETTE kayıtları (Hem tekli aramadan hem günlük/6 aylık siparişten eklenenler)
            for (const [rawKey, entry] of Object.entries(ordersMap)) {
                if (!entry || entry.durum !== 'SEPETTE') continue;
                // NAME:... anahtarlarını atla (barkod veya ürün adı anahtarı zaten mevcut)
                if (rawKey.startsWith('NAME:')) continue;
                const dKey = (entry.depo || 'SELCUK').toUpperCase();
                const grp = ensureDepoGroup(dKey);
                const bc = (entry.barkod || (!rawKey.includes(' ') && /^\\d+$/.test(rawKey) ? rawKey : '') || '').toString().trim();
                const nm = (entry.urun_adi || '').toString().trim();
                const normName = nm.toUpperCase();
                const normBc = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;

                // Aynı ürünün hem kanonik barkodu hem alt barkodu varsa tek satırda birleştir
                const dedupKey = normName || normBc || rawKey;
                if (seenPerDepo[dKey].has(dedupKey) || (normBc && seenPerDepo[dKey].has(`BC:${normBc}`))) {
                    continue;
                }
                seenPerDepo[dKey].add(dedupKey);
                if (normBc) seenPerDepo[dKey].add(`BC:${normBc}`);

                const qty = parseInt(entry.miktar) || 1;
                grp.items.push({
                    barkod: bc,
                    urun_adi: nm || bc || rawKey,
                    miktar: qty,
                    saat: entry.saat || '--:--',
                    masa_adi: entry.masa_adi || entry.masa || 'Eczane PC'
                });
                grp.totalBoxes += qty;
            }

            // 2. Henüz senkronize olmamış anlık toplu sipariş hafızası varsa onu da dahil et
            const state = window.currentBulkState || {};
            const sessions = state.depoSessions || {};
            if (Array.isArray(state.allResults)) {
                state.allResults.forEach(r => {
                    if (r.status !== 'ADDED') return;
                    const dKey = (r.assigned_depo || state.depo || 'SELCUK').toUpperCase();
                    const sess = sessions[dKey];
                    if (sess && (sess.finalized || sess.cleared)) return;
                    const grp = ensureDepoGroup(dKey);
                    const bc = (r.barcode || '').toString().trim();
                    const nm = (r.name || '').toString().trim();
                    const normName = nm.toUpperCase();
                    const normBc = (bc.length === 14 && bc.startsWith('0')) ? bc.substring(1) : bc;
                    const dedupKey = normName || normBc;
                    if (!dedupKey) return;
                    if (seenPerDepo[dKey].has(dedupKey) || (normBc && seenPerDepo[dKey].has(`BC:${normBc}`))) return;
                    seenPerDepo[dKey].add(dedupKey);
                    if (normBc) seenPerDepo[dKey].add(`BC:${normBc}`);
                    const qty = parseInt(r.miktar) || 1;
                    grp.items.push({
                        barkod: bc,
                        urun_adi: nm || bc,
                        miktar: qty,
                        saat: 'Az Önce',
                        masa_adi: 'Toplu Sipariş'
                    });
                    grp.totalBoxes += qty;
                });
            }

            // Boş grupları temizle
            Object.keys(groups).forEach(k => {
                if (!groups[k].items || groups[k].items.length === 0) {
                    delete groups[k];
                }
            });

            return groups;
        }

        function updateMultiDepotCartUI() {
            const floatEl = document.getElementById('floatingMiniBulkCart');
            const drawerBar = document.getElementById('drawerMiniBulkResumeBar');
            const multiModal = document.getElementById('multiDepotCartModal');
            const isMultiModalOpen = multiModal && !multiModal.classList.contains('hidden') && multiModal.style.display !== 'none';

            // Sol alt yüzen sepet barı ve çekmece içi alt barı kalıcı olarak gizli tut
            if (floatEl) floatEl.classList.add('hidden');
            if (drawerBar) drawerBar.classList.add('hidden');

            const groups = getActiveCartGroupsByDepo();
            const depoKeys = Object.keys(groups);
            let totalCartItems = 0;
            let totalCartBoxes = 0;
            depoKeys.forEach(k => {
                totalCartItems += groups[k].items.length;
                totalCartBoxes += groups[k].totalBoxes;
            });

            // Tek ve Şık Üst Bar Sepet Butonu (#headerCartBtn) Güncellemesi
            const hdrBadge = document.getElementById('headerCartCountBadge');
            const hdrPills = document.getElementById('headerCartDepotPills');
            const hdrBtn = document.getElementById('headerCartBtn');
            if (hdrBadge) {
                hdrBadge.innerText = totalCartItems;
                hdrBadge.className = totalCartItems > 0
                    ? 'px-1.5 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black leading-none'
                    : 'px-1.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-black leading-none';
            }
            if (hdrBtn) {
                hdrBtn.className = totalCartItems > 0
                    ? 'inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl font-bold bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-400 transition cursor-pointer whitespace-nowrap shrink-0'
                    : 'inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 transition cursor-pointer whitespace-nowrap shrink-0';
            }
            if (hdrPills) {
                if (depoKeys.length > 0) {
                    hdrPills.classList.remove('hidden');
                    hdrPills.innerHTML = depoKeys.map(k => {
                        const g = groups[k];
                        return `<span onclick="event.stopPropagation(); openMultiDepotCartModal('${k}');" class="px-1.5 py-0.5 rounded-md border text-[9px] font-black ${g.headerPillClass} hover:opacity-80 cursor-pointer" title="${g.name} sepetinde ${g.items.length} kalem (${g.totalBoxes} kutu) ürün var">${g.shortName}:${g.items.length}</span>`;
                    }).join('');
                } else {
                    hdrPills.innerHTML = '';
                    hdrPills.classList.add('hidden');
                }
            }

            if (isMultiModalOpen) {
                renderMultiDepotCartModal();
            }
        }

        const updateMiniBulkCartUI = updateMultiDepotCartUI;

        function openMultiDepotCartModal(focusDepo = null) {
            const modal = document.getElementById('multiDepotCartModal');
            if (!modal) return;
            const groups = getActiveCartGroupsByDepo();
            const depoKeys = Object.keys(groups);
            if (focusDepo && groups[focusDepo.toUpperCase()]) {
                window.activeMultiDepotCartTab = focusDepo.toUpperCase();
            } else if (window.activeMultiDepotCartTab !== 'ALL' && !groups[window.activeMultiDepotCartTab]) {
                window.activeMultiDepotCartTab = 'ALL';
            } else if (!focusDepo) {
                window.activeMultiDepotCartTab = 'ALL';
            }
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
            renderMultiDepotCartModal();
            const floatEl = document.getElementById('floatingMiniBulkCart');
            if (floatEl) floatEl.classList.add('hidden');
        }

        function closeMultiDepotCartModal() {
            const modal = document.getElementById('multiDepotCartModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
            updateMultiDepotCartUI();
        }

        function switchMultiDepotCartTab(tabKey) {
            window.activeMultiDepotCartTab = tabKey || 'ALL';
            renderMultiDepotCartModal();
        }

        function renderMultiDepotCartModal() {
            const tabsEl = document.getElementById('multiDepotCartTabs');
            const bodyEl = document.getElementById('multiDepotCartBody');
            const summaryBadge = document.getElementById('multiCartTotalSummaryBadge');
            const missingBtn = document.getElementById('multiCartMissingBulkBtn');
            if (!tabsEl || !bodyEl) return;

            const groups = getActiveCartGroupsByDepo();
            const depoKeys = Object.keys(groups);
            let totalItems = 0;
            let totalBoxes = 0;
            depoKeys.forEach(k => {
                totalItems += groups[k].items.length;
                totalBoxes += groups[k].totalBoxes;
            });

            if (summaryBadge) {
                summaryBadge.innerText = `${depoKeys.length} Depo • ${totalItems} Kalem (${totalBoxes} Kutu)`;
            }

            const missingList = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];
            if (missingBtn) {
                if (missingList.length > 0) {
                    missingBtn.classList.remove('hidden');
                    missingBtn.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1"></i>${missingList.length} Eksik Ürün Raporu`;
                } else {
                    missingBtn.classList.add('hidden');
                }
            }

            if (depoKeys.length === 0) {
                tabsEl.innerHTML = `<span class="text-xs font-bold text-slate-500">Şu anda hiçbir deponun sepetinde bekleyen ürün bulunmuyor.</span>`;
                bodyEl.innerHTML = `
                    <div class="text-center py-14 bg-white rounded-3xl border border-slate-200 shadow-2xs">
                        <div class="w-16 h-16 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto text-2xl mb-3">
                            <i class="fa-solid fa-cart-shopping"></i>
                        </div>
                        <h4 class="text-base font-black text-slate-800">Depo Sepetleriniz Şu An Boş</h4>
                        <p class="text-xs text-slate-500 mt-1 max-w-md mx-auto">Tekli ürün aramasından, Günün Çıkışlarından veya 6 Aylık Çıkış listesinden herhangi bir depoya ürün eklediğinizde burada depolara göre ayrı ayrı listelenir.</p>
                    </div>
                `;
                return;
            }

            const activeTab = (window.activeMultiDepotCartTab !== 'ALL' && groups[window.activeMultiDepotCartTab])
                ? window.activeMultiDepotCartTab
                : 'ALL';

            // Sekmeleri oluştur
            let tabsHtml = `
                <button type="button" onclick="switchMultiDepotCartTab('ALL')" class="px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${activeTab === 'ALL' ? 'bg-slate-900 text-white shadow-sm' : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-300'}">
                    <i class="fa-solid fa-layer-group"></i>
                    <span>Tüm Depo Sepetleri</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] ${activeTab === 'ALL' ? 'bg-amber-400 text-slate-950' : 'bg-slate-200 text-slate-700'}">${totalItems} Kalem</span>
                </button>
            `;
            depoKeys.forEach(k => {
                const g = groups[k];
                const isAct = activeTab === k;
                tabsHtml += `
                    <button type="button" onclick="switchMultiDepotCartTab('${k}')" class="px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${isAct ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-300'}">
                        <i class="fa-solid fa-cart-shopping"></i>
                        <span>${g.name}</span>
                        <span class="px-2 py-0.5 rounded-full text-[10px] ${isAct ? 'bg-white text-indigo-900' : 'bg-indigo-50 text-indigo-700'}">${g.items.length} Kalem (${g.totalBoxes} Kutu)</span>
                    </button>
                `;
            });
            tabsEl.innerHTML = tabsHtml;

            // Gösterilecek depolar
            const displayKeys = activeTab === 'ALL' ? depoKeys : [activeTab];
            bodyEl.innerHTML = displayKeys.map(k => {
                const g = groups[k];
                const rowsHtml = g.items.map((it, idx) => {
                    const safeBc = (it.barkod || '').replace(/'/g, "\\'");
                    const safeNm = (it.urun_adi || '').replace(/'/g, "\\'");
                    return `
                        <tr class="hover:bg-slate-50 transition border-b border-slate-100 last:border-0">
                            <td class="py-2.5 px-4 text-xs font-bold text-slate-400 w-10">${idx + 1}</td>
                            <td class="py-2.5 px-4">
                                <div class="text-xs font-black text-slate-800">${it.urun_adi}</div>
                                <div class="text-[10px] text-slate-400 font-mono mt-0.5">${it.barkod ? `Barkod: ${it.barkod}` : 'İsimle Eşleşti'}</div>
                            </td>
                            <td class="py-2.5 px-4 text-center">
                                <span class="inline-flex items-center px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 font-black text-xs border border-amber-300">
                                    ${it.miktar} Kutu
                                </span>
                            </td>
                            <td class="py-2.5 px-4 text-center text-[11px] text-slate-500 font-semibold">
                                <div><i class="fa-regular fa-clock mr-1 text-slate-400"></i>${it.saat}</div>
                                <div class="text-[10px] text-slate-400">${it.masa_adi}</div>
                            </td>
                            <td class="py-2.5 px-4 text-right">
                                <div class="inline-flex items-center justify-end gap-1.5">
                                    ${it.barkod ? `
                                        <button type="button" onclick="closeMultiDepotCartModal(); searchProductByBarcode('${safeBc}');" class="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 text-[11px] font-bold border border-slate-200 transition cursor-pointer" title="Bu ürünü Farma Radar'da tekrar sorgula">
                                            <i class="fa-solid fa-magnifying-glass mr-1"></i>Fiyat Gör
                                        </button>
                                    ` : ''}
                                    <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeNm}', '${g.code}', ${it.miktar})" class="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-[11px] font-extrabold border border-emerald-200 transition cursor-pointer" title="Bu ürünü sipariş verildi olarak işaretle ve sepet listesinden düş">
                                        <i class="fa-solid fa-check mr-1"></i>Verildi İşaretle
                                    </button>
                                    <button type="button" onclick="removeCartItemFromModal('${safeBc}', '${safeNm}')" class="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-[11px] font-bold border border-rose-200 transition cursor-pointer" title="Sepet işaretini kaldır">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `;
                }).join('');

                return `
                    <div class="bg-white rounded-2xl border-2 border-slate-200 shadow-sm overflow-hidden">
                        <!-- Depo Kart Başlığı -->
                        <div class="px-5 py-3.5 bg-gradient-to-r ${g.cardHeaderClass} text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-xl bg-white/15 border border-white/25 flex items-center justify-center text-base font-black shrink-0">
                                    <i class="fa-solid fa-truck-medical"></i>
                                </div>
                                <div>
                                    <div class="flex flex-wrap items-center gap-2">
                                        <h4 class="text-sm font-black text-white">${g.name} Sepeti</h4>
                                        <span class="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[11px] font-black">${g.items.length} Kalem • ${g.totalBoxes} Kutu</span>
                                        ${g.sepetTutari ? `<span class="px-2.5 py-0.5 rounded-full bg-white/15 text-white text-[11px] font-mono font-bold">Sepet Tutarı: ${g.sepetTutari} ₺</span>` : ''}
                                    </div>
                                    <p class="text-[11px] text-white/75 mt-0.5">Bu depoya eklediğiniz ürünler aşağıda listelenmektedir. İnceledikten sonra depo sepetine gidebilir veya siparişi sonlandırabilirsiniz.</p>
                                </div>
                            </div>
                            <div class="flex flex-wrap items-center gap-2 shrink-0">
                                ${g.portalUrl && g.portalUrl !== '#' ? `
                                    <a href="${g.portalUrl}" target="_blank" class="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-sm transition flex items-center gap-1.5">
                                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                        <span>${g.shortName} Sepetine Git (Portal ↗)</span>
                                    </a>
                                ` : ''}
                                <button type="button" onclick="openBulkFinalizeFlow('${g.code}')" class="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs shadow-sm transition flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-paper-plane"></i>
                                    <span>${g.shortName} Siparişini Sonlandır & Gönder</span>
                                </button>
                            </div>
                        </div>

                        <!-- Ürün Tablosu -->
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="bg-slate-100/80 border-b border-slate-200 text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">
                                        <th class="py-2 px-4">#</th>
                                        <th class="py-2 px-4">Sepetteki Ürün Adı & Barkod</th>
                                        <th class="py-2 px-4 text-center">Miktar</th>
                                        <th class="py-2 px-4 text-center">Eklenme</th>
                                        <th class="py-2 px-4 text-right">Kontrol & İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${rowsHtml}
                                </tbody>
                            </table>
                        </div>

                        <!-- Depo Kart Alt Aksiyon Çubuğu -->
                        <div class="px-5 py-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
                            <div class="flex flex-wrap items-center gap-2">
                                <button type="button" onclick="clearDepotCartFromModal('${g.code}')" class="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-extrabold transition flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-trash-can"></i>
                                    <span>${g.shortName} Sepetini Boşalt</span>
                                </button>
                                <button type="button" onclick="markDepotCartItemsOrdered('${g.code}')" class="px-3 py-1.5 rounded-xl bg-white hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer" title="Portaldan kendiniz onayladıysanız tümünü sipariş verildi olarak işaretler">
                                    <i class="fa-solid fa-check-double"></i>
                                    <span>Portaldan Gönderdim (Tümünü Verildi İşaretle)</span>
                                </button>
                            </div>
                            <div class="flex flex-wrap items-center gap-2">
                                ${g.portalUrl && g.portalUrl !== '#' ? `
                                    <a href="${g.portalUrl}" target="_blank" class="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs transition flex items-center gap-1.5 shadow-2xs">
                                        <i class="fa-solid fa-cart-shopping"></i>
                                        <span>${g.name} Sepetine Git ↗</span>
                                    </a>
                                ` : ''}
                                <button type="button" onclick="openBulkFinalizeFlow('${g.code}')" class="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs transition flex items-center gap-1.5 shadow-2xs cursor-pointer">
                                    <i class="fa-solid fa-paper-plane"></i>
                                    <span>Canlı Sepeti Doğrula & Siparişi Bitir</span>
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }

        async function removeCartItemFromModal(barkod, urunAdi) {
            try {
                await fetch('/api/orders/today/unmark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barkod: barkod || '', urun_adi: urunAdi || '' })
                });
                // Toplu sipariş hafızasında varsa oradan da düş
                if (window.currentBulkState && Array.isArray(window.currentBulkState.allResults)) {
                    window.currentBulkState.allResults.forEach(r => {
                        if ((barkod && r.barcode === barkod) || (urunAdi && r.name === urunAdi)) {
                            r.status = 'CLEARED';
                        }
                    });
                }
                await syncTodayOrdersAcrossPCs();
                showToast('Sepet Listesinden Çıkarıldı', `${urunAdi || barkod} sepet takip listesinden kaldırıldı.`, 'info');
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function markDepotCartItemsOrdered(depoCode) {
            const groups = getActiveCartGroupsByDepo();
            const grp = groups[(depoCode || '').toUpperCase()];
            if (!grp || !grp.items || grp.items.length === 0) return;
            try {
                const payloadItems = grp.items.map(it => ({
                    barkod: it.barkod || '',
                    urun_adi: it.urun_adi || '',
                    miktar: it.miktar || 1
                }));
                await fetch('/api/orders/today/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: grp.code,
                        durum: 'SIPARIS_VERILDI',
                        items: payloadItems
                    })
                });
                if (typeof markBulkSessionFinalizedInUI === 'function') {
                    markBulkSessionFinalizedInUI(grp.code);
                }
                await syncTodayOrdersAcrossPCs();
                showToast('Sipariş Verildi İşaretlendi', `${grp.name} sepetindeki ${grp.items.length} kalem ürün sipariş verildi olarak işaretlendi.`, 'success');
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function clearDepotCartFromModal(depoCode) {
            const dKey = (depoCode || 'SELCUK').toUpperCase();
            const meta = DEPO_CART_META[dKey] || { name: dKey };
            if (!confirm(`${meta.name} sepetindeki tüm ürünleri hem canlı depo sepetinden hem de bugünkü sepet listenizden temizlemek istediğinize emin misiniz?`)) {
                return;
            }
            try {
                const res = await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: dKey })
                });
                const data = await res.json();
                if (typeof markBulkSessionClearedInUI === 'function') {
                    markBulkSessionClearedInUI(dKey);
                }
                await syncTodayOrdersAcrossPCs();
                if (data.success) {
                    showToast('Depo Sepeti Boşaltıldı', data.message || `${meta.name} sepeti temizlendi.`, 'info');
                } else {
                    showToast('Bilgi', data.message || `${meta.name} sepeti temizlenirken uyarı oluştu.`, 'info');
                }
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        function reopenBulkOrderModal() {
            const modal = document.getElementById('bulkOrderModal');
            if (!modal) return;
            // Eğer sepette sonlandırılmamış ürün kalmadıysa ve sadece sipariş verilmeyen eksik ürünler varsa doğrudan Eksikler sekmesini aç
            const unfin = getUnfinalizedBulkDepos();
            const missing = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];
            if (unfin.length === 0 && missing.length > 0 && typeof switchBulkResultTab === 'function') {
                switchBulkResultTab('YOK');
            }
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
            updateMultiDepotCartUI();
        }

        function closeBulkOrderModal() {
            const modal = document.getElementById('bulkOrderModal');
            if (modal) {
                modal.style.display = 'none';
                modal.classList.add('hidden');
            }
            updateMultiDepotCartUI();
        }

        // ================= Kart Bazlı Seçimli Depo Hızlı Ekleme =================
        const QUICK_DEPO_CONFIGS = {
            'ALLIANCE': {
                code: 'ALLIANCE',
                name: 'Alliance Healthcare',
                shortName: 'Alliance',
                actionText: "Alliance'a At",
                bgClass: 'bg-sky-600 hover:bg-sky-700',
                chevronClass: 'bg-sky-700 hover:bg-sky-800',
                dotColor: 'bg-sky-500',
                icon: 'fa-solid fa-truck-fast'
            },
            'SELCUK': {
                code: 'SELCUK',
                name: 'Selçuk Ecza',
                shortName: 'Selçuk',
                actionText: "Selçuk'a At",
                bgClass: 'bg-rose-600 hover:bg-rose-700',
                chevronClass: 'bg-rose-700 hover:bg-rose-800',
                dotColor: 'bg-rose-500',
                icon: 'fa-solid fa-paper-plane'
            },
            'ISKOOP': {
                code: 'ISKOOP',
                name: 'İSKOOP E-Şube',
                shortName: 'İSKOOP',
                actionText: "İSKOOP'a At",
                bgClass: 'bg-emerald-600 hover:bg-emerald-700',
                chevronClass: 'bg-emerald-700 hover:bg-emerald-800',
                dotColor: 'bg-emerald-500',
                icon: 'fa-solid fa-cart-plus'
            },
            'NEVZAT': {
                code: 'NEVZAT',
                name: 'Nevzat Ecza',
                shortName: 'Nevzat',
                actionText: "Nevzat'a At",
                bgClass: 'bg-amber-600 hover:bg-amber-700',
                chevronClass: 'bg-amber-700 hover:bg-amber-800',
                dotColor: 'bg-amber-500',
                icon: 'fa-solid fa-boxes-packing'
            }
        };

        window.cardSelectedDepos = window.cardSelectedDepos || {};
        window.defaultQuickDepo = 'ALLIANCE';

        function toggleCardDepoMenu(idx, ev) {
            if (ev) {
                ev.stopPropagation();
                ev.preventDefault();
            }
            const menu = document.getElementById(`cardDepoMenu_${idx}`);
            if (!menu) return;
            const isHidden = menu.classList.contains('hidden');
            document.querySelectorAll('[id^="cardDepoMenu_"]').forEach(el => el.classList.add('hidden'));
            if (isHidden) {
                menu.classList.remove('hidden');
            }
        }

        function setCardDepo(idx, depoCode, applyToAll = false, ev = null) {
            if (ev) {
                ev.stopPropagation();
                ev.preventDefault();
            }
            window.cardSelectedDepos = window.cardSelectedDepos || {};
            const cfg = QUICK_DEPO_CONFIGS[depoCode] || QUICK_DEPO_CONFIGS['ALLIANCE'];

            if (applyToAll) {
                window.defaultQuickDepo = depoCode;
                const total = (window.currentFilteredCriticalItems || []).length;
                for (let i = 0; i < total; i++) {
                    window.cardSelectedDepos[i] = depoCode;
                    updateSingleCardDepoUI(i, depoCode);
                }
                showToast('Tüm Kartlar Güncellendi', `Tüm ilaçlar için hedef depo ${cfg.shortName} olarak belirlendi.`, 'success');
            } else {
                window.cardSelectedDepos[idx] = depoCode;
                updateSingleCardDepoUI(idx, depoCode);
                showToast('Depo Seçildi', `Bu ilaç için ${cfg.shortName} seçildi.`, 'success');
            }

            const menu = document.getElementById(`cardDepoMenu_${idx}`);
            if (menu) menu.classList.add('hidden');
        }

        function refreshCardDepoMenuContent(idx, currentDepo) {
            const menu = document.getElementById(`cardDepoMenu_${idx}`);
            if (!menu) return;
            menu.innerHTML = `
                <div class="px-2.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Hedef Depo Seç
                </div>
                <div class="py-0.5">
                    <button type="button" onclick="setCardDepo(${idx}, 'ALLIANCE', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-sky-50 text-slate-700 hover:text-sky-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-sky-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">Alliance</span>
                        ${currentDepo === 'ALLIANCE' ? '<i class="fa-solid fa-check text-[10px] text-sky-600"></i>' : ''}
                    </button>
                    <button type="button" onclick="setCardDepo(${idx}, 'SELCUK', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-rose-50 text-slate-700 hover:text-rose-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">Selçuk</span>
                        ${currentDepo === 'SELCUK' ? '<i class="fa-solid fa-check text-[10px] text-rose-600"></i>' : ''}
                    </button>
                    <button type="button" onclick="setCardDepo(${idx}, 'ISKOOP', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">İSKOOP</span>
                        ${currentDepo === 'ISKOOP' ? '<i class="fa-solid fa-check text-[10px] text-emerald-600"></i>' : ''}
                    </button>
                    <button type="button" onclick="setCardDepo(${idx}, 'NEVZAT', false, event)" class="w-full text-left px-2.5 py-1.5 flex items-center space-x-2 hover:bg-amber-50 text-slate-700 hover:text-amber-900 font-semibold cursor-pointer">
                        <span class="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                        <span class="flex-1 text-[11px]">Nevzat</span>
                        ${currentDepo === 'NEVZAT' ? '<i class="fa-solid fa-check text-[10px] text-amber-600"></i>' : ''}
                    </button>
                </div>
                <div class="py-0.5 border-t border-slate-100">
                    <button type="button" onclick="setCardDepo(${idx}, '${currentDepo}', true, event)" class="w-full text-left px-2.5 py-1.5 text-[10px] text-slate-600 hover:bg-slate-100 hover:text-slate-900 cursor-pointer flex items-center space-x-1.5 font-bold">
                        <i class="fa-solid fa-check-double text-[9px] text-sky-600"></i>
                        <span>Tüm kartları buna ayarla</span>
                    </button>
                </div>
            `;
        }

        function updateSingleCardDepoUI(idx, depoCode) {
            const cfg = QUICK_DEPO_CONFIGS[depoCode] || QUICK_DEPO_CONFIGS['ALLIANCE'];
            const btn = document.getElementById(`btnQuickAdd_${idx}`);
            const chevron = document.getElementById(`btnQuickAddChevron_${idx}`);
            const icon = document.getElementById(`btnQuickAddIcon_${idx}`);
            const text = document.getElementById(`btnQuickAddText_${idx}`);

            if (btn) {
                btn.className = `h-7 px-2 ${cfg.bgClass} text-white font-bold text-[10px] rounded-l-lg transition flex items-center space-x-1 cursor-pointer`;
                btn.title = `Bu ilacı ${cfg.name} sepetine ekle`;
            }
            if (chevron) {
                chevron.className = `w-4 h-7 ${cfg.chevronClass} text-white/90 hover:text-white border-l border-white/20 rounded-r-lg transition flex items-center justify-center cursor-pointer`;
            }
            if (icon) {
                icon.className = `${cfg.icon} text-[9px]`;
            }
            if (text) {
                text.innerText = cfg.shortName;
            }
            refreshCardDepoMenuContent(idx, depoCode);
        }

        // Dışarı tıklanınca tüm depo menülerini kapat
        document.addEventListener('click', function(e) {
            if (!e.target.closest('[id^="quickAddWrapper_"]')) {
                document.querySelectorAll('[id^="cardDepoMenu_"]').forEach(el => el.classList.add('hidden'));
            }
        });

        async function sendSingleCriticalToDepo(idx) {
            syncCriticalDomStateToMaps();
            const item = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
            if (!item) return;

            window.cardSelectedDepos = window.cardSelectedDepos || {};
            const depoCode = window.cardSelectedDepos[idx] || window.defaultQuickDepo || 'ALLIANCE';
            const cfg = QUICK_DEPO_CONFIGS[depoCode] || QUICK_DEPO_CONFIGS['ALLIANCE'];

            const btn = document.getElementById(`btnQuickAdd_${idx}`);
            const chevron = document.getElementById(`btnQuickAddChevron_${idx}`);
            
            if (btn) {
                btn.disabled = true;
                if (chevron) chevron.disabled = true;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin text-[9px]"></i>`;
            }

            const input = document.getElementById(`bulkQtyInput_${idx}`);
            const qty = input ? (parseInt(input.value) || 1) : 1;

            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depoCode,
                        barkod: item.barkod,
                        urun_id: item.barkod,
                        miktar: qty,
                        name: item.urun_adi || ''
                    })
                });
                const data = await res.json();
                if (data.success) {
                    const cKey = getCriticalItemKey(item);
                    if (cKey && window.criticalCheckedMap) {
                        window.criticalCheckedMap[cKey] = false;
                    }
                    let extra = '';
                    if (data.sepet_no) extra += ` (Belge No: ${data.sepet_no})`;
                    if (data.sepet_tutari) extra += ` (Tutar: ${data.sepet_tutari} ₺)`;
                    if (typeof recordDepotSessionFromSingleAdd === 'function') {
                        recordDepotSessionFromSingleAdd(depoCode, data.sepet_tutari, data.sepet_no, data.portal_url);
                    }
                    showToast(`${cfg.shortName} Sepetine Eklendi`, `${item.urun_adi} x${qty} kutu ${cfg.name} sepetinize aktarıldı.${extra}`, 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') await syncTodayOrdersAcrossPCs();
                    if (btn) {
                        btn.className = 'h-7 px-2 bg-emerald-600 text-white font-bold text-[10px] rounded-l-lg flex items-center space-x-1';
                        btn.innerHTML = `<i class="fa-solid fa-check text-[9px]"></i><span>OK</span>`;
                        setTimeout(() => {
                            btn.innerHTML = `<i class="${cfg.icon} text-[9px]" id="btnQuickAddIcon_${idx}"></i><span id="btnQuickAddText_${idx}">${cfg.shortName}</span>`;
                            updateSingleCardDepoUI(idx, depoCode);
                            btn.disabled = false;
                            if (chevron) chevron.disabled = false;
                        }, 2000);
                    }
                } else {
                    showToast(`${cfg.shortName} Hatası`, data.message || 'Ürün sepete eklenemedi.', 'error');
                    if (btn) {
                        btn.innerHTML = `<i class="${cfg.icon} text-[9px]" id="btnQuickAddIcon_${idx}"></i><span id="btnQuickAddText_${idx}">${cfg.shortName}</span>`;
                        updateSingleCardDepoUI(idx, depoCode);
                        btn.disabled = false;
                        if (chevron) chevron.disabled = false;
                    }
                }
            } catch(e) {
                showToast('Bağlantı Hatası', e.message, 'error');
                if (btn) {
                    btn.innerHTML = `<i class="${cfg.icon} text-[9px]" id="btnQuickAddIcon_${idx}"></i><span id="btnQuickAddText_${idx}">${cfg.shortName}</span>`;
                    updateSingleCardDepoUI(idx, depoCode);
                    btn.disabled = false;
                    if (chevron) chevron.disabled = false;
                }
            }
        }

        // Geriye dönük uyumluluk
        window.sendSingleCriticalToAlliance = sendSingleCriticalToDepo;

        const DEPO_BULK_CONFIGS = {
            'ALLIANCE': {
                name: 'Alliance Healthcare',
                title: '🚀 Alliance Healthcare Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar otomatik taranarak Alliance Healthcare sepetinize aktarılır.',
                cartUrl: 'https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart',
                cartBtnText: 'Alliance eSipariş Sepetini Aç ↗',
                icon: 'fa-solid fa-truck-fast',
                color: 'sky'
            },
            'SELCUK': {
                name: 'Selçuk Ecza',
                title: '🚀 Selçuk Ecza Deposu Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar Selçuk WebDepo sepetinize aktarılır.',
                cartUrl: 'https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx',
                cartBtnText: 'Selçuk WebDepo Sepetini Aç ↗',
                icon: 'fa-solid fa-paper-plane',
                color: 'rose'
            },
            'ISKOOP': {
                name: 'İSKOOP E-Şube',
                title: '🚀 İSKOOP E-Şube Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar İSKOOP E-Şube taslak siparişinize aktarılır.',
                cartUrl: 'https://esube.iskoop.org/FrameWorkT1/#/baskets',
                cartBtnText: 'İSKOOP E-Şube Sepetini Aç ↗',
                icon: 'fa-solid fa-cart-plus',
                color: 'emerald'
            },
            'NEVZAT': {
                name: 'Nevzat Ecza',
                title: '🚀 Nevzat Ecza Deposu Toplu Sipariş Gönderici',
                desc: 'Günün çıkışlarından seçilen ilaçlar Nevzat WebDepo sepetinize aktarılır.',
                cartUrl: 'http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx',
                cartBtnText: 'Nevzat WebDepo Sepetini Aç ↗',
                icon: 'fa-solid fa-boxes-packing',
                color: 'amber'
            }
        };

        // ================= Toplu Sipariş Gönderici (Tek Depo Ultra Hızlı + Eksikleri Topla & Aktar) =================
        window.currentBulkState = {
            initialDepo: null,
            requestedItems: [],
            depoSessions: {}, // { 'ALLIANCE': { count: X, amount: Y, name: '...', cartUrl: '...' } }
            missingItems: [], // items still missing across tried depots
            allResults: []    // trace array for table rendering
        };
        window.activeBulkResultTab = 'ALL';

        function switchBulkResultTab(tab = 'ALL') {
            window.activeBulkResultTab = tab;
            const btnAll = document.getElementById('bulkTabBtnAll');
            const btnYok = document.getElementById('bulkTabBtnYok');

            if (tab === 'ALL') {
                if (btnAll) btnAll.className = 'px-2.5 py-1 rounded-lg text-xs font-black bg-white text-slate-900 shadow-2xs border border-slate-200 cursor-pointer';
                if (btnYok) btnYok.className = 'px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 hover:bg-rose-50 border border-transparent cursor-pointer flex items-center space-x-1';
            } else {
                if (btnAll) btnAll.className = 'px-2.5 py-1 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-100 border border-transparent cursor-pointer';
                if (btnYok) btnYok.className = 'px-2.5 py-1 rounded-lg text-xs font-black bg-rose-600 text-white shadow-2xs border border-rose-700 cursor-pointer flex items-center space-x-1';
            }

            renderBulkItemsTable();
        }

        function renderBulkItemsTable() {
            const listEl = document.getElementById('bulkOrderItemsList');
            if (!listEl) return;

            const state = window.currentBulkState;
            if (!state) return;

            const itemsToShow = (window.activeBulkResultTab === 'YOK') 
                ? (state.missingItems || []) 
                : (state.allResults || []);

            if (itemsToShow.length === 0) {
                listEl.innerHTML = window.activeBulkResultTab === 'YOK'
                    ? `<div class="p-8 text-center text-emerald-600 font-bold"><i class="fa-solid fa-circle-check text-2xl block mb-2 text-emerald-500"></i>Harika! Tüm ürünler sepete eklendi, eksik ürün bulunmuyor.</div>`
                    : `<div class="p-8 text-center text-slate-400">Listelenecek ürün bulunamadı.</div>`;
                return;
            }

            const depoColors = {
                'ALLIANCE': { badge: 'bg-sky-100 text-sky-800 border-sky-200', text: 'Alliance' },
                'SELCUK': { badge: 'bg-rose-100 text-rose-800 border-rose-200', text: 'Selçuk' },
                'ISKOOP': { badge: 'bg-emerald-100 text-emerald-800 border-emerald-200', text: 'İSKOOP' },
                'NEVZAT': { badge: 'bg-amber-100 text-amber-800 border-amber-200', text: 'Nevzat' }
            };

            listEl.innerHTML = itemsToShow.map((it, i) => {
                const isYok = it.status === 'YOK' || (!it.assigned_depo && it.status !== 'SKIPPED');
                const dCfg = depoColors[it.assigned_depo] || { badge: 'bg-slate-100 text-slate-800', text: it.assigned_depo || 'Depo' };
                const netFiyatStr = it.net_fiyat > 0 ? `${it.net_fiyat.toFixed(2)} ₺` : '';
                const vadeStr = it.vade ? `${it.vade} Gün` : '';
                const subDetail = [netFiyatStr, vadeStr].filter(Boolean).join(' • ');
                const safeBc = (it.barcode || '').replace(/'/g, "\\\\'");
                const safeNm = (it.name || '').replace(/'/g, "\\\\'");

                let badgeHtml = '';
                if (it.status === 'ORDERED') {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-600 text-white border border-emerald-700 shadow-2xs">
                            <i class="fa-solid fa-circle-check text-[9px] mr-1"></i>
                            <span>✓ ${dCfg.text} Siparişi Verildi</span>
                            ${subDetail ? `<span class="opacity-90 font-mono">(${subDetail})</span>` : ''}
                        </span>
                    `;
                } else if (it.status === 'SKIPPED') {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-slate-700 text-white border border-slate-800 shadow-2xs">
                            <i class="fa-solid fa-ban text-rose-300 text-[9px] mr-1"></i>
                            <span>🚫 Sipariş Verilmeyecek</span>
                        </span>
                    `;
                } else if (it.status === 'CLEARED') {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-700 border border-slate-300">
                            <i class="fa-solid fa-trash-can text-[9px] mr-1"></i>
                            <span>${dCfg.text} Sepetinden Silindi</span>
                        </span>
                    `;
                } else if (!isYok) {
                    badgeHtml = `
                        <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${dCfg.badge}">
                            <i class="fa-solid fa-cart-shopping text-[9px] mr-1"></i>
                            <span>${dCfg.text} Sepetinde</span>
                            ${subDetail ? `<span class="opacity-80 font-mono">(${subDetail})</span>` : ''}
                        </span>
                    `;
                } else {
                    const failMsg = it.message || 'Depoda Yok / Teklif Yok';
                    badgeHtml = `
                        <div class="inline-flex items-center space-x-1.5">
                            <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                                <i class="fa-solid fa-circle-exclamation text-[9px] mr-1"></i>
                                <span>${failMsg}</span>
                            </span>
                            <button type="button" onclick="skipBulkModalItem('${safeBc}', '${safeNm}')" class="px-2 py-0.5 rounded-lg bg-slate-700 hover:bg-slate-800 text-white text-[10px] font-extrabold transition cursor-pointer flex items-center space-x-1 shadow-2xs" title="Bu ürünü bugün sipariş verilmeyecek olarak işaretle ve eksik listesinden çıkar">
                                <i class="fa-solid fa-ban text-rose-300 text-[9px]"></i>
                                <span>Verilmeyecek</span>
                            </button>
                        </div>
                    `;
                }

                return `
                    <div class="px-4 py-2.5 flex items-center justify-between transition hover:bg-slate-50 ${it.status === 'SKIPPED' ? 'bg-slate-100/60 opacity-75' : (isYok ? 'bg-rose-50/20' : 'bg-white')}" id="bulkRow_${i}">
                        <div class="flex items-center space-x-2.5 min-w-0">
                            <span class="w-5 h-5 rounded-full ${isYok ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-500'} font-mono text-[10px] font-bold flex items-center justify-center shrink-0">${i + 1}</span>
                            <div class="min-w-0">
                                <div class="font-bold ${it.status === 'SKIPPED' ? 'line-through text-slate-500' : 'text-slate-800'} truncate">${it.name}</div>
                                <div class="text-[10px] text-slate-400 font-mono">${it.barcode} • Sipariş: <strong class="text-sky-700 font-bold">${it.miktar} Kutu</strong></div>
                            </div>
                        </div>
                        <div class="shrink-0 text-right">
                            ${badgeHtml}
                        </div>
                    </div>
                `;
            }).join('');
        }

        async function skipBulkModalItem(barcode, name) {
            await markItemSkippedDirect(barcode, name);
            const state = window.currentBulkState;
            if (!state) return;
            if (Array.isArray(state.missingItems)) {
                state.missingItems = state.missingItems.filter(m => !(m.barcode === barcode || (name && m.name === name)));
            }
            if (Array.isArray(state.allResults)) {
                state.allResults.forEach(r => {
                    if (r.barcode === barcode || (name && r.name === name)) {
                        r.status = 'SKIPPED';
                        r.assigned_depo = null;
                        r.message = 'Bugün Sipariş Verilmeyecek';
                    }
                });
            }
            const statFailed = document.getElementById('bulkStatFailed');
            if (statFailed) statFailed.innerText = (state.missingItems || []).length;
            const tabYok = document.getElementById('bulkTabCountYok');
            if (tabYok) tabYok.innerText = (state.missingItems || []).length;
            const copyBtn = document.getElementById('btnCopyYokList');
            if (copyBtn && (!state.missingItems || state.missingItems.length === 0)) {
                copyBtn.classList.add('hidden');
            }
            renderBulkItemsTable();
            renderTransferMissingBar(state.depo || 'ALLIANCE');
            if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
        }

        function copyMissingItemsToClipboard() {
            const missing = window.currentBulkState ? window.currentBulkState.missingItems : [];
            if (!missing || missing.length === 0) {
                showToast('Eksik Yok', 'Tüm ürünler sepete başarıyla eklendi, eksik ürün bulunmuyor.', 'info');
                return;
            }
            const now = new Date();
            const dateStr = now.toLocaleDateString('tr-TR') + ' ' + now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
            
            let text = `📋 ECZANE DEPO EKSİK / YOK LİSTESİ (${dateStr})\\n`;
            text += `Aşağıdaki ${missing.length} kalem ürün depolarda bulunamamıştır:\\n`;
            text += `--------------------------------------------------\\n`;
            missing.forEach((it, idx) => {
                text += `${idx + 1}. ${it.name} (${it.barcode}) - ${it.miktar} Kutu\\n`;
            });
            text += `--------------------------------------------------\\n`;
            text += `Toplam: ${missing.length} Kalem • Eksik / Yok\\n`;

            const finishCopy = () => {
                showToast('Eksik Listesi Kopyalandı!', `${missing.length} kalemlik eksik listesi panoya kopyalandı. WhatsApp veya notlara yapıştırabilirsiniz.`, 'success');
            };

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(finishCopy).catch(() => {
                    fallbackCopyText(text);
                    finishCopy();
                });
            } else {
                fallbackCopyText(text);
                finishCopy();
            }
        }

        function fallbackCopyText(text) {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
        }

        function renderTransferMissingBar(currentDepo) {
            const bar = document.getElementById('bulkTransferMissingBar');
            const countEl = document.getElementById('bulkMissingCount');
            const btnsContainer = document.getElementById('bulkTransferButtonsContainer');
            if (!bar || !countEl || !btnsContainer) return;

            const missing = window.currentBulkState ? window.currentBulkState.missingItems : [];
            if (!missing || missing.length === 0) {
                bar.classList.add('hidden');
                return;
            }

            bar.classList.remove('hidden');
            countEl.innerText = missing.length;

            const allDepos = [
                { key: 'ALLIANCE', name: 'Alliance', color: 'bg-sky-600 hover:bg-sky-700', icon: 'fa-solid fa-truck-fast' },
                { key: 'SELCUK', name: 'Selçuk', color: 'bg-rose-600 hover:bg-rose-700', icon: 'fa-solid fa-paper-plane' },
                { key: 'ISKOOP', name: 'İSKOOP', color: 'bg-emerald-600 hover:bg-emerald-700', icon: 'fa-solid fa-cart-plus' },
                { key: 'NEVZAT', name: 'Nevzat', color: 'bg-amber-600 hover:bg-amber-700', icon: 'fa-solid fa-boxes-packing' }
            ];
            const depos = allDepos.filter(d => typeof isBulkDepoActive !== 'function' || isBulkDepoActive(d.key));

            // Denenmiş depoları hariç tutarak sıradaki aktif depoları göster (tümü denendiyse mevcut depo hariç aktifleri göster)
            const triedDepos = (window.currentBulkState && Array.isArray(window.currentBulkState.triedDepos)) ? window.currentBulkState.triedDepos : [currentDepo];
            let availableDepos = depos.filter(d => !triedDepos.includes(d.key));
            if (availableDepos.length === 0) {
                availableDepos = depos.filter(d => d.key !== currentDepo);
            }

            btnsContainer.innerHTML = availableDepos.map(d => `
                <button 
                    type="button" 
                    onclick="transferMissingItemsTo('${d.key}')" 
                    class="px-3 py-1.5 ${d.color} text-white rounded-xl text-xs font-extrabold transition flex items-center space-x-1.5 cursor-pointer shadow-xs active:scale-98"
                    title="Bu ${missing.length} eksik ilacı ${d.name} deposunda sorgulayıp sepete ekle"
                >
                    <i class="${d.icon} text-[10px]"></i>
                    <span>${d.name}'a Gönder (${missing.length})</span>
                </button>
            `).join('') + `
                <button 
                    type="button" 
                    onclick="copyMissingItemsToClipboard()" 
                    class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer active:scale-98" 
                    title="Eksik ürünleri panoya kopyala"
                >
                    <i class="fa-solid fa-copy text-[10px]"></i>
                    <span>Kopyala</span>
                </button>
            `;
        }

        function renderDepoBreakdownPills() {
            if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
            const breakdownEl = document.getElementById('bulkModalDepoBreakdown');
            if (!breakdownEl) return;

            const sessions = window.currentBulkState ? window.currentBulkState.depoSessions : {};
            const keys = Object.keys(sessions);
            if (keys.length === 0) {
                breakdownEl.classList.add('hidden');
                return;
            }

            breakdownEl.classList.remove('hidden');
            const colors = {
                'ALLIANCE': 'bg-sky-50 border-sky-300 text-sky-900',
                'SELCUK': 'bg-rose-50 border-rose-300 text-rose-900',
                'ISKOOP': 'bg-emerald-50 border-emerald-300 text-emerald-900',
                'NEVZAT': 'bg-amber-50 border-amber-300 text-amber-900'
            };

            breakdownEl.innerHTML = keys.map(k => {
                const s = sessions[k];
                const cStyle = colors[k] || 'bg-slate-50 border-slate-300 text-slate-900';
                let btnHtml = '';
                if (s.finalized) {
                    btnHtml = `<div class="mt-2 w-full py-1.5 px-2 rounded-lg bg-emerald-100 border border-emerald-300 text-emerald-900 font-black text-[10px] flex items-center justify-center space-x-1">
                           <i class="fa-solid fa-circle-check text-emerald-600 text-[10px]"></i>
                           <span>✓ ${s.name} Siparişi İletildi</span>
                       </div>`;
                } else if (s.cleared) {
                    btnHtml = `<div class="mt-2 w-full py-1.5 px-2 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 font-bold text-[10px] flex items-center justify-center space-x-1">
                           <i class="fa-solid fa-trash-can text-rose-500 text-[10px]"></i>
                           <span>Sepet Boşaltıldı</span>
                       </div>`;
                } else if ((s.count || 0) <= 0) {
                    btnHtml = `<div class="mt-2 w-full py-1.5 px-2 rounded-lg bg-slate-100 border border-slate-200 text-slate-500 font-bold text-[10px] text-center">
                           Bu Depoda Yok (0 Kalem)
                       </div>`;
                } else {
                    btnHtml = `<button type="button" onclick="openBulkFinalizeFlow('${k}')" class="mt-2 w-full py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[10px] transition flex items-center justify-center space-x-1 cursor-pointer shadow-xs">
                           <i class="fa-solid fa-paper-plane text-[9px]"></i>
                           <span>${s.name} Siparişini Sonlandır</span>
                       </button>`;
                }
                return `
                    <div class="p-2.5 rounded-xl border ${cStyle} flex flex-col justify-between shadow-2xs">
                        <div class="flex items-center justify-between text-[11px] font-bold">
                            <span>${s.name}</span>
                            <a href="${s.cartUrl}" target="_blank" rel="noopener noreferrer" class="text-[10px] underline font-extrabold hover:opacity-80">Sepeti Aç ↗</a>
                        </div>
                        <div class="mt-1 flex items-baseline justify-between">
                            <span class="text-xs font-black">${s.finalized ? `${s.count} Kalem Sipariş Verildi` : `${s.count} Kalem Eklendi`}</span>
                            <span class="text-[10px] font-mono font-bold">${(s.amount || 0).toFixed(2)} ₺</span>
                        </div>
                        ${btnHtml}
                    </div>
                `;
            }).join('');
        }

        async function triggerBulkOrder(depoKodu = 'ALLIANCE') {
            const depo = (depoKodu || 'ALLIANCE').toUpperCase();
            const cfg = DEPO_BULK_CONFIGS[depo] || DEPO_BULK_CONFIGS['ALLIANCE'];

            const checks = document.querySelectorAll('.bulkItemCheck:checked');
            if (checks.length === 0) {
                showToast('Seçim Yapılmadı', `Lütfen sepete aktarmak için en az bir ilaç seçiniz.`, 'info');
                return;
            }

            const itemsToOrder = [];
            checks.forEach(c => {
                const idx = parseInt(c.dataset.idx);
                const it = window.currentFilteredCriticalItems ? window.currentFilteredCriticalItems[idx] : null;
                if (it) {
                    const input = document.getElementById(`bulkQtyInput_${idx}`);
                    const qty = input ? (parseInt(input.value) || 1) : 1;
                    itemsToOrder.push({
                        barcode: it.barkod,
                        name: it.urun_adi,
                        miktar: qty
                    });
                }
            });

            // State sıfırla
            window.currentBulkState = {
                depo: depo,
                initialDepo: depo,
                triedDepos: [depo],
                requestedItems: itemsToOrder,
                depoSessions: {},
                missingItems: [],
                allResults: itemsToOrder.map(it => ({
                    barcode: it.barcode,
                    name: it.name,
                    miktar: it.miktar,
                    status: 'PENDING',
                    assigned_depo: null,
                    net_fiyat: 0,
                    vade: 30,
                    message: 'İşleniyor...'
                }))
            };
            window.activeBulkResultTab = 'ALL';

            // Modalı aç
            const modal = document.getElementById('bulkOrderModal');
            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
            }

            const finBtn = document.getElementById('btnBulkFinalize');
            if (finBtn) {
                finBtn.disabled = false;
                finBtn.className = 'px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl font-black text-xs transition flex items-center space-x-2 shadow-md shadow-emerald-600/20 cursor-pointer active:scale-95';
                finBtn.innerHTML = `<i class="fa-solid fa-paper-plane"></i><span>Siparişi Sonlandır & Depoya Gönder</span>`;
            }

            const modalTitle = document.getElementById('bulkModalTitle');
            const modalDesc = document.getElementById('bulkModalDesc');
            const modalIcon = document.getElementById('bulkModalIcon');
            const modalTargetDepo = document.getElementById('bulkModalTargetDepo');
            const modalCartLink = document.getElementById('bulkModalCartLink');
            const modalCartText = document.getElementById('bulkModalCartBtnText');

            if (modalTitle) modalTitle.innerText = cfg.title;
            if (modalDesc) modalDesc.innerText = cfg.desc;
            if (modalTargetDepo) modalTargetDepo.innerText = `${cfg.name} B2B`;
            if (modalIcon) modalIcon.className = cfg.icon;
            if (modalCartLink) {
                modalCartLink.href = cfg.cartUrl;
                modalCartLink.onclick = function(e) {
                    e.preventDefault();
                    window.open(cfg.cartUrl, '_blank', 'noopener,noreferrer');
                    return false;
                };
            }
            if (modalCartText) modalCartText.innerText = cfg.cartBtnText;

            // Gizle
            const missingBar = document.getElementById('bulkTransferMissingBar');
            if (missingBar) missingBar.classList.add('hidden');
            const breakdownEl = document.getElementById('bulkModalDepoBreakdown');
            if (breakdownEl) breakdownEl.classList.add('hidden');

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');
            const statTotal = document.getElementById('bulkStatTotal');
            const statSuccess = document.getElementById('bulkStatSuccess');
            const statFailed = document.getElementById('bulkStatFailed');
            const statAmount = document.getElementById('bulkStatAmount');

            if (statTotal) statTotal.innerText = itemsToOrder.length;
            if (statSuccess) statSuccess.innerText = '0';
            if (statFailed) statFailed.innerText = '0';
            if (statAmount) statAmount.innerText = '0.00 ₺';
            if (pBar) pBar.style.width = '20%';
            if (pPercent) pPercent.innerText = '%20';
            if (pText) pText.innerText = `${cfg.name} sepetine ${itemsToOrder.length} kalem aktarılıyor (Hızlı Gönderim)...`;
            if (pSpinner) pSpinner.className = 'fa-solid fa-spinner fa-spin text-sky-600';

            renderBulkItemsTable();

            let progress = 20;
            const progressInterval = setInterval(() => {
                if (progress < 90) {
                    progress += 10;
                    if (pBar) pBar.style.width = `${progress}%`;
                    if (pPercent) pPercent.innerText = `%${progress}`;
                }
            }, 300);

            try {
                const res = await fetch('/api/cart/bulk-add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        items: itemsToOrder,
                        cascade: false // TEK DEPO ULTRA HIZLI
                    })
                });
                clearInterval(progressInterval);

                const data = await res.json();
                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '%100';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-check text-emerald-600';

                if (data.success || data.success_count > 0 || data.items) {
                    const successCount = data.success_count || 0;
                    const totalAmount = data.total_amount || 0;

                    // Depo sepet oturumunu kaydet
                    window.currentBulkState.depoSessions[depo] = {
                        count: successCount,
                        amount: totalAmount,
                        name: cfg.name,
                        cartUrl: cfg.cartUrl
                    };

                    // Eksik ürünleri topla
                    const missing = [];
                    const results = data.items || [];
                    results.forEach(r => {
                        const target = window.currentBulkState.allResults.find(it => it.barcode === r.barcode);
                        if (r.success) {
                            if (target) {
                                target.status = 'ADDED';
                                target.assigned_depo = depo;
                                target.urun_id = r.urun_id || target.urun_id || '';
                                target.net_fiyat = r.net_fiyat || 0;
                                target.vade = r.vade || 30;
                                target.message = r.message || 'Eklendi';
                            }
                        } else {
                            if (target) {
                                target.status = 'YOK';
                                target.message = r.message || `${cfg.shortName}'ta Stok Yok`;
                            }
                            missing.push({
                                barcode: r.barcode,
                                name: r.name || (target ? target.name : r.barcode),
                                miktar: r.miktar || (target ? target.miktar : 1),
                                message: r.message || `${cfg.shortName}'ta Yok`
                            });
                        }
                    });

                    window.currentBulkState.missingItems = missing;

                    // UI Güncelle
                    if (statSuccess) statSuccess.innerText = `${successCount} Kalem`;
                    if (statFailed) statFailed.innerText = `${missing.length} Kalem`;
                    if (statAmount) statAmount.innerText = `${totalAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;
                    
                    const tabAllCount = document.getElementById('bulkTabCountAll');
                    const tabYokCount = document.getElementById('bulkTabCountYok');
                    if (tabAllCount) tabAllCount.innerText = itemsToOrder.length;
                    if (tabYokCount) tabYokCount.innerText = missing.length;

                    if (pText) {
                        pText.innerHTML = `<strong>Tamamlandı:</strong> ${successCount} Kalem ${cfg.name} sepetine eklendi! ${missing.length > 0 ? `<span class="text-rose-600 font-bold ml-1">(${missing.length} kalem bu depoda bulunamadı)</span>` : ''}`;
                    }

                    renderDepoBreakdownPills();
                    updateBulkMainFinalizeButtonUI();
                    renderTransferMissingBar(depo);
                    renderBulkItemsTable();

                    showToast(`${cfg.name} Sepetine Eklendi`, `${successCount} kalem sepete yüklendi. ${missing.length > 0 ? `${missing.length} eksik kalem toplandı.` : ''}`, 'success');
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    if (pText) pText.innerText = `Aktarım uyarısı: ${data.message || 'Ürünler sepete eklenemedi'}`;
                    if (pSpinner) pSpinner.className = 'fa-solid fa-triangle-exclamation text-rose-600';
                    showToast('Aktarım Uyarısı', data.message || 'İşlem tamamlanamadı.', 'error');
                }
            } catch(e) {
                clearInterval(progressInterval);
                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '!';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-xmark text-rose-600';
                if (pText) pText.innerText = `Bağlantı hatası: ${e.message}`;
                showToast('Hata', e.message, 'error');
            }
        }

        async function transferMissingItemsTo(targetDepo) {
            const targetDepoClean = (targetDepo || '').toUpperCase();
            const cfg = DEPO_BULK_CONFIGS[targetDepoClean];
            if (!cfg) return;

            const missing = window.currentBulkState ? window.currentBulkState.missingItems : [];
            if (!missing || missing.length === 0) {
                showToast('Eksik Yok', 'Tüm ürünler depolara eklendi!', 'info');
                return;
            }

            const pBar = document.getElementById('bulkProgressBar');
            const pText = document.getElementById('bulkProgressText');
            const pPercent = document.getElementById('bulkProgressPercent');
            const pSpinner = document.getElementById('bulkProgressSpinner');

            if (pBar) pBar.style.width = '20%';
            if (pPercent) pPercent.innerText = '%20';
            if (pText) pText.innerText = `${cfg.name} sepetine eksik ${missing.length} kalem aktarılıyor...`;
            if (pSpinner) pSpinner.className = 'fa-solid fa-spinner fa-spin text-sky-600';

            const toSend = [...missing];

            let progress = 20;
            const progressInterval = setInterval(() => {
                if (progress < 90) {
                    progress += 10;
                    if (pBar) pBar.style.width = `${progress}%`;
                    if (pPercent) pPercent.innerText = `%${progress}`;
                }
            }, 300);

            try {
                const res = await fetch('/api/cart/bulk-add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: targetDepoClean,
                        items: toSend,
                        cascade: false
                    })
                });
                clearInterval(progressInterval);

                const data = await res.json();
                if (pBar) pBar.style.width = '100%';
                if (pPercent) pPercent.innerText = '%100';
                if (pSpinner) pSpinner.className = 'fa-solid fa-circle-check text-emerald-600';

                if (data.success || data.success_count > 0 || data.items) {
                    const newSuccess = data.success_count || 0;
                    const newAmount = data.total_amount || 0;

                    // Hedef depo istatistiğini kaydet / güncelle
                    if (!Array.isArray(window.currentBulkState.triedDepos)) {
                        window.currentBulkState.triedDepos = [window.currentBulkState.initialDepo || targetDepoClean];
                    }
                    if (!window.currentBulkState.triedDepos.includes(targetDepoClean)) {
                        window.currentBulkState.triedDepos.push(targetDepoClean);
                    }
                    if (!window.currentBulkState.depoSessions[targetDepoClean]) {
                        window.currentBulkState.depoSessions[targetDepoClean] = {
                            count: newSuccess,
                            amount: newAmount,
                            name: cfg.name,
                            cartUrl: cfg.cartUrl,
                            finalized: false
                        };
                    } else {
                        window.currentBulkState.depoSessions[targetDepoClean].count += newSuccess;
                        window.currentBulkState.depoSessions[targetDepoClean].amount += newAmount;
                        if (newSuccess > 0) window.currentBulkState.depoSessions[targetDepoClean].finalized = false;
                    }

                    // Kalan eksikleri hesapla
                    const stillMissing = [];
                    const results = data.items || [];
                    results.forEach(r => {
                        const target = window.currentBulkState.allResults.find(it => it.barcode === r.barcode);
                        if (r.success) {
                            if (target) {
                                target.status = 'ADDED';
                                target.assigned_depo = targetDepoClean;
                                target.net_fiyat = r.net_fiyat || 0;
                                target.vade = r.vade || 30;
                                target.message = r.message || 'Eklendi';
                            }
                        } else {
                            if (target && target.status !== 'ADDED') {
                                target.message = r.message || `${cfg.shortName}'ta da Yok`;
                            }
                            stillMissing.push({
                                barcode: r.barcode,
                                name: r.name || (target ? target.name : r.barcode),
                                miktar: r.miktar || (target ? target.miktar : 1),
                                message: r.message || `${cfg.shortName}'ta da Yok`
                            });
                        }
                    });

                    window.currentBulkState.missingItems = stillMissing;

                    // Toplam başarı ve tutar hesapla
                    let totalAdded = 0;
                    let totalAmount = 0;
                    Object.values(window.currentBulkState.depoSessions).forEach(s => {
                        totalAdded += s.count;
                        totalAmount += s.amount;
                    });

                    const statSuccess = document.getElementById('bulkStatSuccess');
                    const statFailed = document.getElementById('bulkStatFailed');
                    const statAmount = document.getElementById('bulkStatAmount');
                    const tabYokCount = document.getElementById('bulkTabCountYok');

                    if (statSuccess) statSuccess.innerText = `${totalAdded} Kalem`;
                    if (statFailed) statFailed.innerText = `${stillMissing.length} Kalem`;
                    if (statAmount) statAmount.innerText = `${totalAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺`;
                    if (tabYokCount) tabYokCount.innerText = stillMissing.length;

                    if (pText) {
                        pText.innerHTML = `<strong>${cfg.name} Tamamlandı:</strong> ${newSuccess} Kalem sepete eklendi! ${stillMissing.length > 0 ? `<span class="text-rose-600 font-bold">(${stillMissing.length} kalem halen bulunamadı)</span>` : '<span class="text-emerald-600 font-bold">(Tüm eksikler tamamlandı!)</span>'}`;
                    }

                    renderDepoBreakdownPills();
                    updateBulkMainFinalizeButtonUI();
                    renderTransferMissingBar(targetDepoClean);
                    renderBulkItemsTable();

                    showToast(`${cfg.name} Aktarımı Yapıldı`, `${newSuccess} kalem ${cfg.name} sepetine eklendi. ${stillMissing.length > 0 ? `${stillMissing.length} kalem kaldı.` : 'Tüm ürünler tamamlandı!'}`, 'success');
                } else {
                    if (pText) pText.innerText = `Aktarım uyarısı: ${data.message || 'Ürünler sepete eklenemedi'}`;
                    showToast('Aktarım Uyarısı', data.message || 'İşlem tamamlanamadı.', 'error');
                }
            } catch(e) {
                clearInterval(progressInterval);
                if (pText) pText.innerText = `Bağlantı hatası: ${e.message}`;
                showToast('Hata', e.message, 'error');
            }
        }

        // Geriye dönük uyumluluk için alias
        const triggerBulkAllianceOrder = () => triggerBulkOrder('ALLIANCE');

        // ================= EczaneTakas Canlı Açık Teklifler Modalı =================
        window.etActiveOffersCache = [];

        function ensureEczaneTakasModalDom() {
            if (document.getElementById('eczanetakasOffersModal')) return;
            const modalHtml = `
                <div id="eczanetakasOffersModal" class="hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
                    <div class="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-5xl max-h-[88vh] flex flex-col overflow-hidden">
                        <div class="px-6 py-4 bg-gradient-to-r from-sky-700 to-cyan-600 text-white flex items-center justify-between">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center">
                                    <i class="fa-solid fa-arrow-right-arrow-left text-lg"></i>
                                </div>
                                <div>
                                    <h3 class="text-base font-black leading-tight flex items-center space-x-2">
                                        <span>EczaneTakas — Canlı Açık Teklifler</span>
                                        <span id="etModalCountBadge" class="px-2 py-0.5 rounded-full text-xs font-extrabold bg-white/20">0 Teklif</span>
                                    </h3>
                                    <p class="text-xs text-sky-100">Portaldaki aktif eczane tekliflerini arayın, tek tıkla tüm depolarla karşılaştırın veya teklife katılın</p>
                                </div>
                            </div>
                            <div class="flex items-center space-x-2">
                                <button type="button" onclick="openEczaneTakasOffersModal(true)" class="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer">
                                    <i class="fa-solid fa-rotate text-[11px]"></i>
                                    <span>Yenile</span>
                                </button>
                                <a href="https://eczanetakas.com/teklifler/1" target="_blank" class="px-3 py-1.5 rounded-xl bg-white text-sky-800 hover:bg-sky-50 text-xs font-extrabold transition flex items-center space-x-1.5">
                                    <span>Portalı Aç ↗</span>
                                </a>
                                <button type="button" onclick="closeEczaneTakasOffersModal()" class="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                        </div>
                        <div class="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3">
                            <div class="relative flex-1">
                                <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-2.5 text-slate-400 text-xs"></i>
                                <input type="text" id="etModalSearchInput" oninput="renderEczaneTakasOffersModal()" placeholder="İlaç adı, barkod veya teklif veren eczane ara..." class="w-full pl-9 pr-4 py-2 text-xs font-semibold rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white" />
                            </div>
                            <span class="text-[11px] text-slate-500 font-medium hidden sm:inline">💡 "Karşılaştır" butonuna tıklayarak ilacı diğer depolarla kıyaslayabilirsiniz</span>
                        </div>
                        <div id="etModalBody" class="flex-1 overflow-y-auto p-4">
                            <div class="p-8 text-center text-slate-400 text-sm">Yükleniyor...</div>
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHtml);
        }

        async function openEczaneTakasOffersModal(forceRefresh = false) {
            ensureEczaneTakasModalDom();
            const modal = document.getElementById('eczanetakasOffersModal');
            const body = document.getElementById('etModalBody');
            if (modal) modal.classList.remove('hidden');
            if (body && (forceRefresh || !window.etActiveOffersCache || window.etActiveOffersCache.length === 0)) {
                body.innerHTML = `<div class="p-10 text-center text-sky-700 font-bold text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl mb-2 block"></i>EczaneTakas aktif teklifleri çekiliyor...</div>`;
                try {
                    const res = await fetch('/api/eczanetakas/offers' + (forceRefresh ? '?refresh=true' : ''));
                    const data = await res.json();
                    if (data.success) {
                        window.etActiveOffersCache = data.offers || [];
                        const topBadge = document.getElementById('etTopOffersCountBadge');
                        if (topBadge) topBadge.innerText = `${window.etActiveOffersCache.length} Teklif`;
                    } else {
                        body.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-sm">${data.message || 'Teklifler alınamadı.'}</div>`;
                        return;
                    }
                } catch (e) {
                    body.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-sm">Bağlantı hatası: ${e.message}</div>`;
                    return;
                }
            }
            renderEczaneTakasOffersModal();
        }

        function closeEczaneTakasOffersModal() {
            const modal = document.getElementById('eczanetakasOffersModal');
            if (modal) modal.classList.add('hidden');
        }

        function compareFromEczaneTakasOffer(barcode, name) {
            closeEczaneTakasOffersModal();
            if (typeof switchMainView === 'function') switchMainView('depo');
            const q = (barcode && barcode.length >= 8) ? barcode : name;
            const searchInput = document.getElementById('searchInput');
            if (searchInput) searchInput.value = name || q;
            if (barcode && /^\\d{8,14}$/.test(barcode) && typeof performBarcodeSearch === 'function') {
                performBarcodeSearch(barcode);
            } else if (typeof handleSearchSubmit === 'function') {
                handleSearchSubmit(q);
            }
        }

        function renderEczaneTakasOffersModal() {
            const body = document.getElementById('etModalBody');
            const badge = document.getElementById('etModalCountBadge');
            const inp = document.getElementById('etModalSearchInput');
            if (!body) return;
            const q = inp ? inp.value.trim().toLowerCase() : '';
            const all = window.etActiveOffersCache || [];
            const filtered = all.filter(o => {
                if (!q) return true;
                return (o.urun_adi || '').toLowerCase().includes(q)
                    || (o.barcode || '').toLowerCase().includes(q)
                    || (o.ekleyen || '').toLowerCase().includes(q);
            });
            if (badge) badge.innerText = `${filtered.length} Teklif`;
            if (filtered.length === 0) {
                body.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs font-bold">Aramanıza uygun açık teklif bulunamadı.</div>`;
                return;
            }
            body.innerHTML = `
                <div class="overflow-x-auto rounded-2xl border border-slate-200">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-slate-100 text-slate-600 font-extrabold uppercase text-[10px] border-b border-slate-200">
                            <tr>
                                <th class="py-2.5 px-3">Ürün Adı & Barkod</th>
                                <th class="py-2.5 px-3">Teklif Veren Eczane</th>
                                <th class="py-2.5 px-3 text-center">Kalan Stok</th>
                                <th class="py-2.5 px-3 text-center">Barem / MF</th>
                                <th class="py-2.5 px-3 text-right">Depo Fiyatı</th>
                                <th class="py-2.5 px-3 text-right">Net Satış (KDV'li)</th>
                                <th class="py-2.5 px-3 text-center">Miad</th>
                                <th class="py-2.5 px-3 text-right">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            ${filtered.map(o => {
                                const safeName = (o.urun_adi || '').replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
                                const safeBc = (o.barcode || '').replace(/'/g, "\\\\'");
                                return `
                                    <tr class="hover:bg-sky-50/40 transition">
                                        <td class="py-2.5 px-3">
                                            <div class="font-extrabold text-slate-900">${o.urun_adi}</div>
                                            <div class="text-[10px] font-mono text-slate-400">${o.barcode || 'Barkod Eşleşti'} • #${o.teklif_no}</div>
                                        </td>
                                        <td class="py-2.5 px-3 font-bold text-slate-700">
                                            <i class="fa-solid fa-hospital text-sky-600 mr-1 text-[10px]"></i>${o.ekleyen || '-'}
                                            ${o.not ? `<div class="text-[10px] text-amber-700 font-normal italic">${o.not}</div>` : ''}
                                        </td>
                                        <td class="py-2.5 px-3 text-center">
                                            <span class="px-2 py-0.5 rounded-lg font-black bg-sky-100 text-sky-900 border border-sky-200">${o.kalan_stok} Kt</span>
                                        </td>
                                        <td class="py-2.5 px-3 text-center">
                                            <span class="px-2 py-0.5 rounded font-black bg-indigo-50 text-indigo-900 border border-indigo-200 font-mono">${o.mf || 'YOK'}</span>
                                        </td>
                                        <td class="py-2.5 px-3 text-right font-mono text-slate-500">${Number(o.depo_fiyati || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-3 text-right font-mono font-extrabold text-emerald-700">${Number(o.satis_fiyati || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-3 text-center font-mono text-[11px] text-slate-700">${o.miad || '-'}</td>
                                        <td class="py-2.5 px-3 text-right">
                                            <div class="flex items-center justify-end space-x-1.5">
                                                <button type="button" onclick="compareFromEczaneTakasOffer('${safeBc}', '${safeName}')" class="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] cursor-pointer transition">
                                                    Karşılaştır
                                                </button>
                                                <a href="${o.katil_url || ('https://eczanetakas.com/katil/' + o.teklif_no)}" target="_blank" class="px-2.5 py-1 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-[11px] transition">
                                                    Katıl ↗
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        }

        // ============================================================
        // ECZATREND CANLI ORTAK ALIM TEKLİFLERİ MODALI
        // ============================================================
        window.eczatrendActiveOffersCache = [];
        function ensureEczatrendModalDom() {
            if (document.getElementById('eczatrendOffersModal')) return;
            const modalHtml = `
                <div id="eczatrendOffersModal" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
                    <div class="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-6xl max-h-[88vh] flex flex-col overflow-hidden">
                        <div class="bg-gradient-to-r from-purple-700 to-fuchsia-700 px-6 py-4 flex items-center justify-between text-white">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center font-black text-lg">
                                    <i class="fa-solid fa-users-rectangle"></i>
                                </div>
                                <div>
                                    <h3 class="text-base font-extrabold tracking-tight flex items-center gap-2">
                                        Eczatrend — Canlı Ortak Alım Teklifleri
                                        <span id="etrModalCountBadge" class="text-[11px] bg-white/20 px-2.5 py-0.5 rounded-full font-bold">0 Teklif</span>
                                    </h3>
                                    <p class="text-xs text-purple-100">Grubunuzdaki açık barem/ortak alım kampanyaları. Herhangi bir ürüne tıklayarak tüm depolarla karşılaştırabilirsiniz.</p>
                                </div>
                            </div>
                            <div class="flex items-center space-x-2">
                                <button type="button" onclick="openEczatrendOffersModal(true)" class="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-xs font-bold transition cursor-pointer flex items-center space-x-1.5">
                                    <i class="fa-solid fa-rotate"></i>
                                    <span>Yenile</span>
                                </button>
                                <a href="https://eczatrend.com/eczanet/panelNew/main" target="_blank" class="px-3 py-1.5 rounded-xl bg-white text-purple-800 hover:bg-purple-50 text-xs font-extrabold transition flex items-center space-x-1.5">
                                    <span>Siteyi Aç</span>
                                    <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                                </a>
                                <button type="button" onclick="closeEczatrendOffersModal()" class="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                        </div>
                        <div class="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3">
                            <div class="relative flex-1 flex items-center gap-2">
                                <div class="relative flex-1">
                                    <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-2.5 text-slate-400 text-xs"></i>
                                    <input type="text" id="etrModalSearchInput" oninput="renderEczatrendOffersModal()" onkeydown="if(event.key==='Enter') searchEczatrendModalServer()" placeholder="İlaç adı, barkod, grup veya eczane ara... (Tüm sitede aramak için Enter'a basın)" class="w-full pl-9 pr-4 py-2 text-xs font-semibold rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white" />
                                </div>
                                <button type="button" onclick="searchEczatrendModalServer()" class="px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition cursor-pointer whitespace-nowrap">
                                    Portalda Ara
                                </button>
                            </div>
                            <span class="text-[11px] text-slate-500 font-medium hidden md:inline">💡 "Karşılaştır" butonuna tıklayarak ilacı diğer depolarla kıyaslayabilirsiniz</span>
                        </div>
                        <div id="etrModalBody" class="flex-1 overflow-y-auto p-4">
                            <div class="p-8 text-center text-slate-400 text-sm">Yükleniyor...</div>
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHtml);
        }

        async function openEczatrendOffersModal(forceRefresh = false, serverQuery = '') {
            ensureEczatrendModalDom();
            const modal = document.getElementById('eczatrendOffersModal');
            const body = document.getElementById('etrModalBody');
            if (modal) modal.classList.remove('hidden');
            if (body && (forceRefresh || serverQuery || !window.eczatrendActiveOffersCache || window.eczatrendActiveOffersCache.length === 0)) {
                body.innerHTML = `<div class="p-10 text-center text-purple-700 font-bold text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl mb-2 block"></i>Eczatrend ortak alım teklifleri çekiliyor...</div>`;
                try {
                    const params = new URLSearchParams();
                    if (forceRefresh) params.set('refresh', 'true');
                    if (serverQuery) params.set('q', serverQuery);
                    const qs = params.toString() ? ('?' + params.toString()) : '';
                    const res = await fetch('/api/eczatrend/offers' + qs);
                    const data = await res.json();
                    if (data.success) {
                        window.eczatrendActiveOffersCache = data.offers || [];
                    } else {
                        body.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-sm">${data.message || 'Teklifler alınamadı.'}</div>`;
                        return;
                    }
                } catch (e) {
                    body.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold text-sm">Bağlantı hatası: ${e.message}</div>`;
                    return;
                }
            }
            renderEczatrendOffersModal();
        }

        function searchEczatrendModalServer() {
            const inp = document.getElementById('etrModalSearchInput');
            const q = inp ? inp.value.trim() : '';
            openEczatrendOffersModal(true, q);
        }

        function closeEczatrendOffersModal() {
            const modal = document.getElementById('eczatrendOffersModal');
            if (modal) modal.classList.add('hidden');
        }

        function compareFromEczatrendOffer(barcode, name) {
            closeEczatrendOffersModal();
            compareFromEczaneTakasOffer(barcode, name);
        }

        function renderEczatrendOffersModal() {
            const body = document.getElementById('etrModalBody');
            const badge = document.getElementById('etrModalCountBadge');
            const inp = document.getElementById('etrModalSearchInput');
            if (!body) return;
            const q = inp ? inp.value.trim().toLowerCase() : '';
            const all = window.eczatrendActiveOffersCache || [];
            const filtered = all.filter(o => {
                if (!q) return true;
                return (o.urun_adi || '').toLowerCase().includes(q)
                    || (o.barcode || '').toLowerCase().includes(q)
                    || (o.satici || '').toLowerCase().includes(q)
                    || (o.groupName || '').toLowerCase().includes(q);
            });
            if (badge) badge.innerText = `${filtered.length} Teklif`;
            if (filtered.length === 0) {
                body.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs font-bold">Aramanıza uygun açık ortak alım teklifi bulunamadı. Dilerseniz "Portalda Ara" butonuna basarak tüm Eczatrend sayfalarında arayabilirsiniz.</div>`;
                return;
            }
            body.innerHTML = `
                <div class="overflow-x-auto rounded-2xl border border-slate-200">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-slate-100 text-slate-600 font-extrabold uppercase text-[10px] border-b border-slate-200">
                            <tr>
                                <th class="py-2.5 px-3">Ürün Adı & Barkod</th>
                                <th class="py-2.5 px-3">Grup & Teklif Veren Eczane</th>
                                <th class="py-2.5 px-3 text-center">Barem / MF</th>
                                <th class="py-2.5 px-3 text-center">Hedef / Kalan</th>
                                <th class="py-2.5 px-3 text-right">Depo Fiyatı</th>
                                <th class="py-2.5 px-3 text-right">Net (KDV Hariç)</th>
                                <th class="py-2.5 px-3 text-right">Net (KDV Dahil)</th>
                                <th class="py-2.5 px-3 text-center">Bitiş</th>
                                <th class="py-2.5 px-3 text-right">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            ${filtered.map(o => {
                                const safeName = (o.urun_adi || '').replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
                                const safeBc = (o.barcode || '').replace(/'/g, "\\\\'");
                                return `
                                    <tr class="hover:bg-purple-50/40 transition">
                                        <td class="py-2.5 px-3">
                                            <div class="font-extrabold text-slate-900">${o.urun_adi}</div>
                                            <div class="text-[10px] font-mono text-slate-400">${o.barcode || '-'} • #${o.offer_id}</div>
                                        </td>
                                        <td class="py-2.5 px-3 font-bold text-slate-700">
                                            <div><i class="fa-solid fa-hospital text-purple-600 mr-1 text-[10px]"></i>${o.satici || '-'}</div>
                                            <div class="text-[10px] text-purple-700 font-semibold">${o.groupName || ''}</div>
                                        </td>
                                        <td class="py-2.5 px-3 text-center">
                                            <span class="px-2 py-0.5 rounded font-black bg-purple-50 text-purple-900 border border-purple-200 font-mono">${o.mf || 'BAREM'}</span>
                                        </td>
                                        <td class="py-2.5 px-3 text-center">
                                            <span class="px-2 py-0.5 rounded-lg font-black bg-amber-100 text-amber-900 border border-amber-200">Kalan: ${o.kalan}</span>
                                            <div class="text-[10px] text-slate-500 mt-0.5">Hedef: ${o.hedef} (${o.doluluk})</div>
                                        </td>
                                        <td class="py-2.5 px-3 text-right font-mono text-slate-500">${Number(o.depo_fiyati || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-3 text-right font-mono font-bold text-slate-700">${Number(o.fiyat_kdvsiz || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-3 text-right font-mono font-extrabold text-emerald-700">${Number(o.fiyat_kdvli || 0).toFixed(2)} ₺</td>
                                        <td class="py-2.5 px-3 text-center font-mono text-[11px] text-slate-600">${o.kalan_sure || '-'}</td>
                                        <td class="py-2.5 px-3 text-right">
                                            <div class="flex items-center justify-end space-x-1.5">
                                                <button type="button" onclick="compareFromEczatrendOffer('${safeBc}', '${safeName}')" class="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] cursor-pointer transition">
                                                    Karşılaştır
                                                </button>
                                                <a href="${o.katil_url || 'https://eczatrend.com/eczanet/panelNew/main'}" target="_blank" class="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-[11px] transition">
                                                    Katıl ↗
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        }

        // =========================================================================
        // GÜN SONU DEPO SİPARİŞ ÖZETİ & VERİLMEYECEKLERDEN YOK LİSTESİ SİSTEMİ (v1.4.1)
        // =========================================================================
        window.currentEndOfDayData = null;
        window.activeEndOfDayTab = 'summary';

        async function openEndOfDaySummaryModal(initialTab = 'summary') {
            const modal = document.getElementById('endOfDaySummaryModal');
            if (!modal) return;
            modal.classList.remove('hidden');
            switchEndOfDayTab(initialTab || 'summary');
            await loadEndOfDaySummary();
        }

        function closeEndOfDaySummaryModal() {
            const modal = document.getElementById('endOfDaySummaryModal');
            if (modal) modal.classList.add('hidden');
        }

        function switchEndOfDayTab(tab) {
            window.activeEndOfDayTab = tab || 'summary';
            const tabs = ['summary', 'skipped', 'yok'];
                    tabs.forEach(t => {
                const btn = document.getElementById('eodTabBtn' + t.charAt(0).toUpperCase() + t.slice(1));
                const content = document.getElementById('eodTabContent' + t.charAt(0).toUpperCase() + t.slice(1));
                if (btn) {
                    if (t === window.activeEndOfDayTab) {
                        btn.className = 'py-2 px-3 border-b-2 border-emerald-600 text-emerald-800 font-extrabold text-[11px] flex items-center space-x-1.5 cursor-pointer';
                    } else {
                        btn.className = 'py-2 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 font-bold text-[11px] flex items-center space-x-1.5 cursor-pointer';
                    }
                }
                if (content) {
                    if (t === window.activeEndOfDayTab) content.classList.remove('hidden');
                    else content.classList.add('hidden');
                }
            });
        }

        async function loadEndOfDaySummary() {
            try {
                const res = await fetch('/api/orders/today/summary');
                if (!res.ok) return;
                const data = await res.json();
                if (!data.success) return;
                window.currentEndOfDayData = data;
                renderEndOfDaySummaryUI(data);
            } catch (e) {
                console.warn('Gün sonu özeti yüklenemedi:', e);
            }
        }

        function renderEndOfDaySummaryUI(data) {
            if (!data) return;
            const totals = data.totals || {};
            const dateBadge = document.getElementById('eodModalDateBadge');
            if (dateBadge) dateBadge.innerText = `${data.date || ''} • ${data.pc_name || 'Eczane PC'}`;

            const elOrdCnt = document.getElementById('eodKpiOrderedCount');
            const elOrdBox = document.getElementById('eodKpiOrderedBoxes');
            const elCartCnt = document.getElementById('eodKpiCartCount');
            const elCartBox = document.getElementById('eodKpiCartBoxes');
            const elSkipCnt = document.getElementById('eodKpiSkippedCount');
            const elYokCnt = document.getElementById('eodKpiYokCount');
            const elYokTime = document.getElementById('eodKpiYokScanTime');

            if (elOrdCnt) elOrdCnt.innerText = totals.ordered_count || 0;
            if (elOrdBox) elOrdBox.innerText = totals.ordered_boxes || 0;
            if (elCartCnt) elCartCnt.innerText = totals.cart_count || 0;
            if (elCartBox) elCartBox.innerText = totals.cart_boxes || 0;
            if (elSkipCnt) elSkipCnt.innerText = totals.skipped_count || 0;

            const yokScan = data.yok_scan || {};
            const yokList = Array.isArray(yokScan.yok_items) ? yokScan.yok_items : [];
            const varList = Array.isArray(yokScan.var_items) ? yokScan.var_items : [];
            if (elYokCnt) elYokCnt.innerText = yokList.length;
            if (elYokTime) {
                elYokTime.innerText = yokScan.last_scan_time
                    ? `Sorgu: ${yokScan.last_scan_time}`
                    : 'Depolarda Yok';
            }

            // 1. SEKME: DEPO BAZLI GÜN SONU SİPARİŞ ÖZETİ
            const sumContainer = document.getElementById('eodTabContentSummary');
            if (sumContainer) {
                const depots = Array.isArray(data.depots) ? data.depots : [];
                if (depots.length === 0) {
                    sumContainer.innerHTML = `
                        <div class="p-6 text-center bg-white rounded-xl border border-slate-200 text-slate-500 text-xs space-y-1.5">
                            <i class="fa-solid fa-box-open text-2xl text-slate-300 block"></i>
                            <div class="font-extrabold text-xs text-slate-700">Bugün Henüz Depo Siparişi veya Sepet Kaydı Yok</div>
                            <p class="text-[11px]">Gün içinde arama ekranından, günün çıkışlarından veya 6 aylık listeden verdiğiniz siparişler burada depo bazında özetlenir.</p>
                        </div>
                    `;
                } else {
                    sumContainer.innerHTML = depots.map(d => {
                        const rows = (d.items || []).map((it, idx) => {
                            const isOrd = it.durum === 'SIPARIS_VERILDI';
                            const sBc = (it.barkod || '').replace(/'/g, "\\\\'");
                            const sNm = (it.urun_adi || '').replace(/'/g, "\\\\'");
                            return `
                                <tr class="border-b border-slate-100 hover:bg-slate-50/80 text-[11px]">
                                    <td class="py-1.5 px-2.5 font-mono text-slate-400">${idx + 1}</td>
                                    <td class="py-1.5 px-2.5">
                                        <span class="font-extrabold text-slate-900">${it.urun_adi || '-'}</span>
                                        <span class="text-[10px] font-mono text-slate-400 ml-1.5">${it.barkod || ''}</span>
                                    </td>
                                    <td class="py-1.5 px-2.5 text-center">
                                        <span class="px-2 py-0.5 rounded-full font-black ${isOrd ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'} text-[10px]">
                                            ${isOrd ? '✓ VERİLDİ' : '🛒 SEPETTE'}
                                        </span>
                                    </td>
                                    <td class="py-1.5 px-2.5 text-center font-black text-slate-800">${it.miktar || 1} Kt</td>
                                    <td class="py-1.5 px-2.5 text-center text-[10px] text-slate-500">${it.masa_adi || '-'} • ${it.saat || '--:--'}</td>
                                    <td class="py-1.5 px-2.5 text-right">
                                        <button type="button" onclick="unmarkItemOrderStatus('${sBc}', '${sNm}', event); setTimeout(loadEndOfDaySummary, 350);" class="px-2 py-0.5 rounded bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 text-[10px] font-bold cursor-pointer" title="Kaydı geri al">
                                            İptal ×
                                        </button>
                                    </td>
                                </tr>
                            `;
                        }).join('');

                        return `
                            <div class="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
                                <div class="px-3.5 py-2 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-2">
                                    <div class="flex items-center space-x-2">
                                        <i class="fa-solid fa-truck-medical text-emerald-400 text-xs"></i>
                                        <span class="font-black text-xs">${d.depo} DEPOSU ÖZETİ</span>
                                    </div>
                                    <div class="flex items-center gap-1.5 text-[11px]">
                                        <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 font-extrabold">
                                            ✓ Verilen: ${d.ordered_count} Kalem (${d.ordered_boxes} Kt)
                                        </span>
                                        ${d.cart_count > 0 ? `
                                            <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 font-extrabold">
                                                🛒 Sepette: ${d.cart_count} Kalem (${d.cart_boxes} Kt)
                                            </span>
                                        ` : ''}
                                    </div>
                                </div>
                                <table class="w-full text-left border-collapse">
                                    <thead>
                                        <tr class="bg-slate-50 border-b border-slate-200 text-[10px] font-extrabold text-slate-500 uppercase">
                                            <th class="py-1.5 px-2.5 w-8">#</th>
                                            <th class="py-1.5 px-2.5">Ürün Adı & Barkod</th>
                                            <th class="py-1.5 px-2.5 text-center w-24">Durum</th>
                                            <th class="py-1.5 px-2.5 text-center w-16">Adet</th>
                                            <th class="py-1.5 px-2.5 text-center w-32">PC & Saat</th>
                                            <th class="py-1.5 px-2.5 text-right w-20">İşlem</th>
                                        </tr>
                                    </thead>
                                    <tbody>${rows}</tbody>
                                </table>
                            </div>
                        `;
                    }).join('');
                }
            }

            // 2. SEKME: SİPARİŞ VERİLMEYECEKLER & DEPO YOK SORGULAMA
            const skipContainer = document.getElementById('eodTabContentSkipped');
            if (skipContainer) {
                const skipped = Array.isArray(data.skipped_items) ? data.skipped_items : [];
                const scanLookup = {};
                yokList.forEach(y => { scanLookup[(y.barkod || y.urun_adi || '').toUpperCase()] = { type: 'YOK', info: y }; });
                varList.forEach(v => { scanLookup[(v.barkod || v.urun_adi || '').toUpperCase()] = { type: 'VAR', info: v }; });

                if (skipped.length === 0) {
                    skipContainer.innerHTML = `
                        <div class="p-6 text-center bg-white rounded-xl border border-slate-200 text-slate-500 text-xs space-y-1.5">
                            <i class="fa-solid fa-ban text-2xl text-slate-300 block"></i>
                            <div class="font-extrabold text-xs text-slate-700">Bugün "Sipariş Verilmeyecek" Olarak İşaretlenen Ürün Yok</div>
                            <p class="text-[11px]">Günün çıkışlarında veya 6 aylık listede "🚫 Verilmeyecek" olarak işaretlediğiniz ilaçlar burada toplanır ve tek tıkla tüm depolarda stok kontrolü yapılarak olmayanlardan Yok Listesi oluşturulur.</p>
                        </div>
                    `;
                } else {
                    const skipRows = skipped.map((it, idx) => {
                        const sBc = (it.barkod || '').replace(/'/g, "\\\\'");
                        const sNm = (it.urun_adi || '').replace(/'/g, "\\\\'");
                        const lookupKey = (it.barkod || it.urun_adi || '').toUpperCase();
                        const scanRes = scanLookup[lookupKey] || scanLookup[(it.urun_adi || '').toUpperCase()];

                        let statusCellHtml = `<span class="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-bold">Sorgulanmadı</span>`;
                        if (scanRes && scanRes.type === 'YOK') {
                            statusCellHtml = `
                                <span class="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black shadow-2xs">
                                    🚨 HİÇBİR DEPODA YOK
                                </span>
                            `;
                        } else if (scanRes && scanRes.type === 'VAR') {
                            const v = scanRes.info;
                            const depBadges = (v.bulunan_depolar || []).map(bd =>
                                `<span class="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-300 text-[10px] font-extrabold">${bd.depo}: ${bd.net_maliyet ? bd.net_maliyet.toFixed(2) + '₺' : 'VAR'} ${bd.mf && bd.mf !== 'YOK' ? '(' + bd.mf + ')' : ''}</span>`
                            ).join(' ');
                            statusCellHtml = `
                                <div class="flex flex-wrap items-center justify-center gap-1">
                                    <span class="px-1.5 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-black">✅ VAR</span>
                                    ${depBadges}
                                </div>
                            `;
                        }

                        return `
                            <tr class="border-b border-slate-100 hover:bg-slate-50 text-[11px]">
                                <td class="py-1.5 px-2.5 font-mono text-slate-400">${idx + 1}</td>
                                <td class="py-1.5 px-2.5">
                                    <div class="font-extrabold text-slate-900">${it.urun_adi || '-'}</div>
                                    <div class="text-[10px] font-mono text-slate-400">${it.barkod || 'Barkodsuz'} • ${it.masa_adi || ''} (${it.saat || ''})</div>
                                </td>
                                <td class="py-1.5 px-2.5 text-center">${statusCellHtml}</td>
                                <td class="py-1.5 px-2.5 text-right">
                                    <div class="inline-flex items-center gap-1">
                                        ${(scanRes && scanRes.type === 'VAR' && scanRes.info.en_uygun_depo) ? `
                                            <button type="button" onclick="quickOrderFromYokScan('${scanRes.info.en_uygun_depo}', '${sBc}', '${sNm}')" class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold cursor-pointer">
                                                🛒 ${scanRes.info.en_uygun_depo}'a At
                                            </button>
                                        ` : ''}
                                        <button type="button" onclick="closeEndOfDaySummaryModal(); searchFromCritical('${sBc}', '${sNm}');" class="px-2 py-0.5 rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-[10px] font-bold cursor-pointer">
                                            🔍 Kıyasla
                                        </button>
                                        <button type="button" onclick="unmarkItemOrderStatus('${sBc}', '${sNm}', event); setTimeout(loadEndOfDaySummary, 350);" class="px-2 py-0.5 rounded bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 text-[10px] font-bold cursor-pointer" title="Sipariş verilmeyecek işaretini kaldır">
                                            Kaldır ×
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('');

                    skipContainer.innerHTML = `
                        <div class="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-950 via-slate-900 to-rose-950 text-white flex flex-wrap items-center justify-between gap-2">
                            <div class="text-[11px] text-slate-200">
                                <strong class="text-amber-300">🔍 Depo Yok Kontrolü:</strong> İşaretlenen <b>${skipped.length} kalem</b> ürünü depolarda sorgulayıp olmayanları <b>Yok Listesi</b>'ne aktarın.
                            </div>
                            <button type="button" onclick="scanSkippedItemsForYokList()" class="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-[11px] shadow-xs transition shrink-0 cursor-pointer">
                                <i class="fa-solid fa-radar mr-1"></i>Depolarda Sorgula & Yok Listesi Oluştur
                            </button>
                        </div>
                        <div class="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="bg-slate-100 border-b border-slate-200 text-[10px] font-extrabold text-slate-500 uppercase">
                                        <th class="py-1.5 px-2.5 w-8">#</th>
                                        <th class="py-1.5 px-2.5">Ürün Adı & Barkod</th>
                                        <th class="py-1.5 px-2.5 text-center">Canlı Depo Stok Durumu</th>
                                        <th class="py-1.5 px-2.5 text-right">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>${skipRows}</tbody>
                            </table>
                        </div>
                    `;
                }
            }

            // 3. SEKME: YOK LİSTESİ (HİÇBİR DEPODA BULUNAMAYAN ÜRÜNLER)
            const yokContainer = document.getElementById('eodTabContentYok');
            if (yokContainer) {
                const manualAddBarHtml = `
                    <div class="bg-white rounded-xl border border-rose-200 p-3 shadow-2xs flex flex-wrap items-center gap-2">
                        <div class="flex items-center space-x-1.5 text-rose-700 font-extrabold text-[11px] shrink-0">
                            <i class="fa-solid fa-plus-circle"></i>
                            <span>Manuel Yok Ekle:</span>
                        </div>
                        <input type="text" id="manualYokNameInput" onkeydown="if(event.key==='Enter') addManualItemToYokList()" placeholder="İlaç adı veya barkod yazın (Örn: PAROL 500 MG 20 TB veya 8699...)" class="flex-1 min-w-[220px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-rose-500 focus:outline-none" />
                        <input type="text" id="manualYokBarcodeInput" onkeydown="if(event.key==='Enter') addManualItemToYokList()" placeholder="Barkod (Opsiyonel)" class="w-36 px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-mono text-slate-700 focus:ring-2 focus:ring-rose-500 focus:outline-none" />
                        <button type="button" onclick="addManualItemToYokList()" class="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-[11px] shadow-2xs transition cursor-pointer shrink-0">
                            <i class="fa-solid fa-plus mr-1"></i>Yok Listesine Ekle
                        </button>
                    </div>
                `;

                const foundInStockHtml = varList.length > 0 ? `
                    <div class="bg-emerald-50/70 rounded-xl border border-emerald-300 overflow-hidden shadow-2xs">
                        <div class="px-3.5 py-2 bg-emerald-600 text-white flex items-center justify-between">
                            <span class="text-[11px] font-black"><i class="fa-solid fa-circle-check mr-1.5"></i>Sorgulamada Depoda Stoğu Bulunan Ürünler (${varList.length} Kalem)</span>
                            <span class="text-[10px] text-emerald-100 font-semibold">Tek tıkla en uygun depoya atabilirsiniz</span>
                        </div>
                        <div class="divide-y divide-emerald-200/70">
                            ${varList.map(v => {
                                const sBc = (v.barkod || '').replace(/'/g, "\\\\'");
                                const sNm = (v.urun_adi || '').replace(/'/g, "\\\\'");
                                const depBadges = (v.bulunan_depolar || []).map(bd =>
                                    `<span class="px-1.5 py-0.5 rounded bg-white text-emerald-800 border border-emerald-300 text-[10px] font-extrabold">${bd.depo}: ${bd.net_maliyet ? bd.net_maliyet.toFixed(2) + '₺' : 'VAR'} ${bd.mf && bd.mf !== 'YOK' ? '(' + bd.mf + ')' : ''}</span>`
                                ).join(' ');
                                return `
                                    <div class="px-3.5 py-2 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                                        <div>
                                            <span class="font-extrabold text-slate-900">${v.urun_adi || '-'}</span>
                                            <span class="text-[10px] font-mono text-slate-500 ml-1.5">${v.barkod || ''}</span>
                                        </div>
                                        <div class="flex flex-wrap items-center gap-1.5">
                                            ${depBadges}
                                            ${v.en_uygun_depo ? `
                                                <button type="button" onclick="quickOrderFromYokScan('${v.en_uygun_depo}', '${sBc}', '${sNm}')" class="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold cursor-pointer">
                                                    🛒 ${v.en_uygun_depo}'a At
                                                </button>
                                            ` : ''}
                                            <button type="button" onclick="closeEndOfDaySummaryModal(); searchFromCritical('${sBc}', '${sNm}');" class="px-2 py-1 rounded-lg bg-white hover:bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold cursor-pointer">
                                                🔍 Kıyasla
                                            </button>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                ` : '';

                if (yokList.length === 0) {
                    yokContainer.innerHTML = `
                        ${manualAddBarHtml}
                        ${foundInStockHtml}
                        <div class="p-6 text-center bg-white rounded-xl border border-slate-200 text-slate-500 text-xs space-y-2">
                            <i class="fa-solid fa-clipboard-check text-2xl text-emerald-400 block"></i>
                            <div class="font-extrabold text-xs text-slate-700">Yok Listesi Şu Anda Boş</div>
                            <p class="text-[11px]">Yukarıdaki kutudan manuel ilaç ekleyebilir, Günün Çıkışlarında <b>🚨 Yok</b> butonuna tıklayabilir veya "🚫 Verilmeyecekler" sekmesindeki ürünleri <b>"🔍 Depolarda Sorgula"</b> butonuyla taratabilirsiniz.</p>
                            <button type="button" onclick="scanSkippedItemsForYokList()" class="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-[11px] transition cursor-pointer">
                                <i class="fa-solid fa-radar mr-1"></i>Verilmeyecekleri Şimdi Sorgula
                            </button>
                        </div>
                    `;
                } else {
                    const yokRows = yokList.map((it, idx) => {
                        const sBc = (it.barkod || '').replace(/'/g, "\\\\'");
                        const sNm = (it.urun_adi || '').replace(/'/g, "\\\\'");
                        const checkedDepos = Array.isArray(it.yok_depolar) && it.yok_depolar.length > 0
                            ? it.yok_depolar.join(', ')
                            : 'Tüm Aktif Depolar';
                        return `
                            <tr class="border-b border-rose-100 bg-rose-50/20 hover:bg-rose-50/50 text-[11px]">
                                <td class="py-1.5 px-2.5 font-mono font-bold text-rose-700">${idx + 1}</td>
                                <td class="py-1.5 px-2.5">
                                    <span class="font-black text-slate-900">${it.urun_adi || '-'}</span>
                                    <span class="text-[10px] font-mono text-slate-500 ml-1.5">${it.barkod || ''}</span>
                                </td>
                                <td class="py-1.5 px-2.5 text-center">
                                    <span class="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black">
                                        🛑 YOK (${checkedDepos})
                                    </span>
                                </td>
                                <td class="py-1.5 px-2.5 text-right">
                                    <div class="inline-flex items-center gap-1">
                                        <button type="button" onclick="closeEndOfDaySummaryModal(); searchFromCritical('${sBc}', '${sNm}');" class="px-2 py-0.5 rounded bg-white hover:bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold cursor-pointer" title="Tüm depolarda, pazaryerlerinde veya muadillerinde ara">
                                            🔍 Depo / Muadil Ara
                                        </button>
                                        <button type="button" onclick="removeFromTodayYokList('${sBc}', '${sNm}')" class="px-2 py-0.5 rounded bg-white hover:bg-rose-100 text-rose-700 border border-rose-200 text-[10px] font-bold cursor-pointer" title="Yok listesinden çıkar">
                                            Çıkar ×
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('');

                    yokContainer.innerHTML = `
                        ${manualAddBarHtml}
                        ${foundInStockHtml}
                        <div class="px-3.5 py-2.5 rounded-xl bg-rose-50 border border-rose-300 text-rose-950 flex flex-wrap items-center justify-between gap-2">
                            <div class="text-[11px] font-bold text-rose-800">
                                🚨 <b>Yok Listesi (${yokList.length} Kalem):</b> Depolarda bulunamayan veya manuel eklenen yok ürünleri.
                            </div>
                            <div class="flex items-center gap-1.5 shrink-0">
                                <button type="button" onclick="scanYokListItemsInDepots()" class="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[11px] shadow-xs transition cursor-pointer flex items-center space-x-1" title="Yok listesindeki ilaçları tüm aktif depolarda tekrar sorgula; stoğa giren varsa yeşil listede göster">
                                    <i class="fa-solid fa-magnifying-glass-chart"></i>
                                    <span>Yokları Depoda Sorgula</span>
                                </button>
                                <button type="button" onclick="copyCompiledYokList()" class="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-black text-[11px] shadow-xs transition cursor-pointer flex items-center space-x-1">
                                    <i class="fa-solid fa-copy"></i>
                                    <span>Yok Listesini Kopyala</span>
                                </button>
                            </div>
                        </div>
                        <div class="bg-white rounded-xl border border-rose-200 overflow-hidden shadow-2xs">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="bg-rose-100/70 border-b border-rose-200 text-[10px] font-extrabold text-rose-900 uppercase">
                                        <th class="py-1.5 px-2.5 w-8">#</th>
                                        <th class="py-1.5 px-2.5">Bulunamayan Ürün Adı & Barkod</th>
                                        <th class="py-1.5 px-2.5 text-center">Durum / Sorgulanan Depolar</th>
                                        <th class="py-1.5 px-2.5 text-right">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>${yokRows}</tbody>
                            </table>
                        </div>
                    `;
                }
            }
        }

        async function addManualItemToYokList() {
            const nameInput = document.getElementById('manualYokNameInput');
            const bcInput = document.getElementById('manualYokBarcodeInput');
            let rawName = nameInput ? nameInput.value.trim() : '';
            let rawBc = bcInput ? bcInput.value.trim() : '';

            if (!rawName && !rawBc) {
                showToast('Eksik Bilgi', 'Lütfen Yok Listesine eklemek istediğiniz ilacın adını veya barkodunu yazın.', 'info');
                if (nameInput) nameInput.focus();
                return;
            }

            // Eğer ilk kutuya sadece 8-14 haneli barkod yazıldıysa barkod olarak da ata
            if (!rawBc && /^\\d{8,14}$/.test(rawName)) {
                rawBc = rawName;
            }

            try {
                const res = await fetch('/api/orders/today/yok-list/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        items: [{
                            barkod: rawBc,
                            urun_adi: rawName || rawBc,
                            kaynak: 'Manuel Ekleme'
                        }]
                    })
                });
                const data = await res.json();
                if (!data.success) {
                    showToast('Uyarı', data.error || 'Yok listesine eklenemedi.', 'error');
                    return;
                }
                if (nameInput) nameInput.value = '';
                if (bcInput) bcInput.value = '';
                showToast('🚨 Yok Listesine Eklendi', `${rawName || rawBc} Yok Listesine eklendi.`, 'success');
                await loadEndOfDaySummary();
                await syncTodayOrdersAcrossPCs();
            } catch (e) {
                showToast('Hata', e.message || 'Yok listesine ekleme hatası', 'error');
            }
        }

        async function scanYokListItemsInDepots() {
            const btn = document.getElementById('btnScanYokInDepots');
            const origHtml = btn ? btn.innerHTML : '';
            try {
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Yoklar Sorgulanıyor...</span>`;
                }
                showToast('Yok Listesi Depolarda Sorgulanıyor', 'Yok listesindeki ürünler tüm aktif depolarda canlı olarak kontrol ediliyor...', 'info');
                const res = await fetch('/api/orders/today/check-yok-list', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: 'yok_only' })
                });
                const data = await res.json();
                if (!data.success) {
                    showToast('Uyarı', data.error || data.message || 'Sorgulama yapılamadı.', 'error');
                    return;
                }
                if (data.checked_count === 0) {
                    showToast('Yok Listesi Boş', 'Sorgulanacak Yok Listesi ürünü bulunmuyor.', 'info');
                    return;
                }
                await loadEndOfDaySummary();
                switchEndOfDayTab('yok');
                if ((data.var_count || 0) > 0) {
                    showToast('🎉 Stoğa Giren Ürün Bulundu!', `Sorgulanan ${data.checked_count} üründen ${data.var_count} tanesi depolarda stokta bulundu! Yeşil listeden hemen sipariş verebilirsiniz.`, 'success');
                } else {
                    showToast('Sorgulama Tamamlandı', `Yok listesindeki ${data.checked_count} ürünün tamamı aktif depolarda tekrar sorgulandı; henüz stoğa giren ürün yok.`, 'info');
                }
            } catch (e) {
                showToast('Hata', e.message || 'Yok listesi sorgulama hatası', 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = origHtml;
                }
            }
        }

        async function scanSkippedItemsForYokList() {
            const btn = document.getElementById('btnScanSkippedForYok');
            const origHtml = btn ? btn.innerHTML : '';
            try {
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Sorgulanıyor...</span>`;
                }
                showToast('Depolar Sorgulanıyor', 'Sipariş verilmeyecek olarak işaretlenen ürünler aktif depolarda taranıyor, lütfen bekleyin...', 'info');
                const res = await fetch('/api/orders/today/check-yok-list', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: 'skipped' })
                });
                const data = await res.json();
                if (!data.success) {
                    showToast('Uyarı', data.error || data.message || 'Sorgulama yapılamadı.', 'error');
                    return;
                }
                if (data.checked_count === 0) {
                    showToast('Bilgi', 'Bugün "Sipariş Verilmeyecek" olarak işaretlenmiş ürün bulunamadı.', 'info');
                    return;
                }
                await loadEndOfDaySummary();
                if ((data.yok_count || 0) > 0) {
                    switchEndOfDayTab('yok');
                    showToast('Yok Listesi Oluşturuldu', `${data.checked_count} ürün tarandı: ${data.yok_count} ürün hiçbir depoda bulunamadı ve Yok Listesine eklendi, ${data.var_count} ürün depolarda mevcut.`, 'success');
                } else {
                    switchEndOfDayTab('skipped');
                    showToast('Tüm Ürünler Depolarda Mevcut!', `Taranan ${data.checked_count} ürünün tamamı en az bir depoda stokta bulundu.`, 'success');
                }
            } catch (e) {
                showToast('Hata', e.message || 'Depo sorgulama hatası', 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = origHtml;
                }
            }
        }

        async function removeFromTodayYokList(barkod, urunAdi) {
            try {
                await fetch('/api/orders/today/yok-list/remove', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ barkod: barkod || '', urun_adi: urunAdi || '' })
                });
                await loadEndOfDaySummary();
                await syncTodayOrdersAcrossPCs();
                showToast('Yok Listesinden Çıkarıldı', `${urunAdi || barkod} yok listesinden kaldırıldı.`, 'info');
            } catch (e) {
                showToast('Hata', e.message, 'error');
            }
        }

        async function quickOrderFromYokScan(depo, barkod, urunAdi) {
            if (!depo) return;
            await executeBulkOrderWithItems(depo, [{ barcode: barkod, name: urunAdi, miktar: 1 }]);
            setTimeout(loadEndOfDaySummary, 800);
        }

        function copyEndOfDaySummaryReport() {
            const data = window.currentEndOfDayData;
            if (!data) return;
            const lines = [];
            lines.push(`📋 FARMA RADAR — GÜN SONU DEPO SİPARİŞ ÖZETİ (${data.date || ''})`);
            lines.push(`==========================================================`);
            const depots = data.depots || [];
            if (depots.length === 0) {
                lines.push(`Bugün sipariş verilen ürün bulunmamaktadır.`);
            } else {
                depots.forEach(d => {
                    lines.push(`\\n🏢 ${d.depo} DEPOSU (Verilen: ${d.ordered_count} Kalem / ${d.ordered_boxes} Kutu | Sepette: ${d.cart_count} Kalem / ${d.cart_boxes} Kutu)`);
                    (d.items || []).forEach((it, idx) => {
                        const st = it.durum === 'SIPARIS_VERILDI' ? 'SİPARİŞ VERİLDİ' : 'SEPETTE';
                        lines.push(`  ${idx + 1}. ${it.urun_adi} [${it.barkod || '-'}] — ${it.miktar || 1} Kutu (${st} • ${it.masa_adi || ''} ${it.saat || ''})`);
                    });
                });
            }
            const yokItems = (data.yok_scan && data.yok_scan.yok_items) ? data.yok_scan.yok_items : [];
            if (yokItems.length > 0) {
                lines.push(`\\n🚨 DEPOLARDA BULUNAMAYANLAR (YOK LİSTESİ — ${yokItems.length} Kalem):`);
                yokItems.forEach((y, i) => {
                    lines.push(`  ${i + 1}. ${y.urun_adi} (${y.barkod || '-'})`);
                });
            }
            navigator.clipboard.writeText(lines.join('\\n'));
            showToast('Gün Sonu Özeti Kopyalandı', 'Depo sipariş özeti ve yok listesi panoya kopyalandı.', 'success');
        }

        function copyCompiledYokList() {
            const data = window.currentEndOfDayData;
            const yokItems = (data && data.yok_scan && Array.isArray(data.yok_scan.yok_items)) ? data.yok_scan.yok_items : [];
            if (yokItems.length === 0) {
                showToast('Yok Listesi Boş', 'Kopyalanacak yok listesi ürünü bulunmuyor.', 'info');
                return;
            }
            const lines = [`🚨 ECZANE DEPO YOK LİSTESİ (${data.date || ''}) — Toplam ${yokItems.length} Kalem:`];
            yokItems.forEach((it, i) => {
                lines.push(`${i + 1}. ${it.urun_adi} ${it.barkod ? '[' + it.barkod + ']' : ''}`);
            });
            navigator.clipboard.writeText(lines.join('\\n'));
            showToast('Yok Listesi Kopyalandı', `${yokItems.length} kalemlik Yok Listesi panoya kopyalandı.`, 'success');
        }

        // Sayfa yüklendiğinde aktif otomasyonu çek ve SADECE aktif otomasyonun bağlantısını test et
        document.addEventListener('DOMContentLoaded', async () => {
            try {
                const res = await fetch('/api/settings/credentials');
                if (res.ok) {
                    const c = await res.json();
                    if (c.active_otomasyon) {
                        window.activeOtomasyon = c.active_otomasyon.toUpperCase();
                    }
                }
            } catch(e) {}
            selectActiveOtomasyon(window.activeOtomasyon || 'BOTANIK', false);
            refreshHeaderActiveOtomasyon();
            refreshDepoStatusBadge();
            const activeOto = (window.activeOtomasyon || 'BOTANIK').toUpperCase();
            if (activeOto === 'BOTANIK') {
                checkBotanikStatusOnLoad();
            } else if (activeOto === 'TEBEOS') {
                checkTebeosStatusOnLoad();
            } else {
                checkTriaStatusOnLoad();
            }
            initMarketSuggest();
            loadCriticalStockList(false);
            setTimeout(() => checkAppUpdate(false), 2000);
            setInterval(() => checkAppUpdate(false), 180000);
        });
    </script>
</body>
</html>
"""
