import asyncio
import os
import sys
import re
import time
from typing import List, Dict, Optional, Any
from pathlib import Path

from backend.models import (
    DepoKodu,
    DepoUrunSarti,
    DepoKarsilastirmaRaporu,
    StokDurumu
)
from backend.adapters.base_adapter import BaseDepoAdapter
from backend.adapters.alliance_adapter import AllianceAdapter
from backend.adapters.selcuk_adapter import SelcukAdapter
from backend.adapters.nevzat_adapter import NevzatAdapter
from backend.adapters.iskoop_adapter import IskoopAdapter
from backend.adapters.bek_adapter import BekAdapter
from backend.adapters.ecza1_adapter import Ecza1Adapter
from backend.adapters.farmazon_adapter import FarmazonAdapter
from backend.adapters.dna_adapter import DNAEczaAdapter
from backend.adapters.eczatrend_adapter import EczatrendAdapter
from backend.adapters.eczanetakas_adapter import EczaneTakasAdapter

from backend.catalog import catalog

class DepoSorguMotoru:
    def __init__(self, headless: bool = True):
        self.headless = headless
        self.adapters: Dict[DepoKodu, BaseDepoAdapter] = {}
        self._active_user_searches: int = 0
        self._search_cache: Dict[str, Any] = {}
        self._eq_live_cache: Dict[str, Any] = {}
        self._init_adapters()

    def _is_depo_active(self, depo_name: str, *required_credentials) -> bool:
        """
        Deponun aktif olup olmadığını doğrular:
        1. Kullanıcı adı ve şifre gibi zorunlu alanlar DOLU olmalıdır (şifre hiç yoksa kesinlikle PASİF).
        2. {DEPO}_ACTIVE ayarı '0' veya 'false' ise kullanıcı tarafından pasife alınmıştır.
        """
        for cred in required_credentials:
            if not cred or not str(cred).strip():
                return False
        
        active_env = os.environ.get(f"{depo_name.upper()}_ACTIVE", "1").strip().lower()
        if active_env in ("0", "false", "hayir", "no", "pasif"):
            return False
        return True

    def _init_adapters(self):
        # 1. Alliance
        p_code = os.environ.get("ALLIANCE_PHARMACY_CODE", "").strip()
        u_name = os.environ.get("ALLIANCE_USERNAME", "").strip()
        pwd = os.environ.get("ALLIANCE_PASSWORD", "").strip()
        if self._is_depo_active("ALLIANCE", p_code, u_name, pwd):
            self.adapters[DepoKodu.ALLIANCE] = AllianceAdapter(
                pharmacy_code=p_code, username=u_name, password=pwd, headless=self.headless
            )

        # 2. Selçuk
        s_user = os.environ.get("SELCUK_USERNAME", "").strip()
        s_pwd = os.environ.get("SELCUK_PASSWORD", "").strip()
        if self._is_depo_active("SELCUK", s_user, s_pwd):
            self.adapters[DepoKodu.SELCUK] = SelcukAdapter(
                username=s_user, password=s_pwd, headless=self.headless
            )

        # 3. Nevzat
        n_acc = os.environ.get("NEVZAT_ACCOUNT_CODE", "").strip()
        n_user = os.environ.get("NEVZAT_USERNAME", "").strip()
        n_pwd = os.environ.get("NEVZAT_PASSWORD", "").strip()
        if self._is_depo_active("NEVZAT", n_acc, n_user, n_pwd):
            self.adapters[DepoKodu.NEVZAT] = NevzatAdapter(
                account_code=n_acc, username=n_user, password=n_pwd, headless=self.headless
            )

        # 4. İSKOOP
        i_user = os.environ.get("ISKOOP_USERNAME", "").strip()
        i_pwd = os.environ.get("ISKOOP_PASSWORD", "").strip()
        if self._is_depo_active("ISKOOP", i_user, i_pwd):
            self.adapters[DepoKodu.ISKOOP] = IskoopAdapter(
                username=i_user, password=i_pwd, headless=self.headless
            )

        # 5. BEK
        b_user = os.environ.get("BEK_USERNAME", "").strip()
        b_pwd = os.environ.get("BEK_PASSWORD", "").strip()
        if self._is_depo_active("BEK", b_user, b_pwd):
            self.adapters[DepoKodu.BEK] = BekAdapter(
                username=b_user, password=b_pwd, headless=self.headless
            )

        # 6. Ecza1
        e_user = os.environ.get("ECZA1_USERNAME", "").strip()
        e_pwd = os.environ.get("ECZA1_PASSWORD", "").strip()
        if self._is_depo_active("ECZA1", e_user, e_pwd):
            self.adapters[DepoKodu.ECZA1] = Ecza1Adapter(
                username=e_user, password=e_pwd, headless=self.headless
            )

        # 7. Farmazon
        f_user = os.environ.get("FARMAZON_USERNAME", "").strip()
        f_pwd = os.environ.get("FARMAZON_PASSWORD", "").strip()
        if self._is_depo_active("FARMAZON", f_user, f_pwd):
            self.adapters[DepoKodu.FARMAZON] = FarmazonAdapter(
                username=f_user, password=f_pwd, headless=self.headless
            )

        # 8. DNA Ecza Deposu
        dna_user = os.environ.get("DNA_USERNAME", "").strip()
        dna_pwd = os.environ.get("DNA_PASSWORD", "").strip()
        if self._is_depo_active("DNA", dna_user, dna_pwd):
            self.adapters[DepoKodu.DNA] = DNAEczaAdapter(
                username=dna_user, password=dna_pwd, headless=self.headless
            )

        # 9. Eczatrend Alım Grubu
        eczatrend_user = os.environ.get("ECZATREND_USERNAME", "").strip()
        eczatrend_pwd = os.environ.get("ECZATREND_PASSWORD", "").strip()
        if self._is_depo_active("ECZATREND", eczatrend_user, eczatrend_pwd):
            self.adapters[DepoKodu.ECZATREND] = EczatrendAdapter(
                username=eczatrend_user, password=eczatrend_pwd, headless=self.headless
            )

        # 10. EczaneTakas Alım & Takas Pazaryeri
        et_user = os.environ.get("ECZANETAKAS_USERNAME", "").strip()
        et_pwd = os.environ.get("ECZANETAKAS_PASSWORD", "").strip()
        if self._is_depo_active("ECZANETAKAS", et_user, et_pwd):
            self.adapters[DepoKodu.ECZANETAKAS] = EczaneTakasAdapter(
                username=et_user, password=et_pwd, headless=self.headless
            )

    async def find_products(self, query: str, limit: int = 25) -> List[Dict[str, Any]]:
        """
        Kullanıcı bir kelime (örn: 'ocean', 'parol', 'solgar') aradığında:
        1. Önce SQLite kataloğunda arar.
        2. Eğer katalogda yoksa veya sonuç azsa (örn: OTC ürünler), depolardan (Selçuk/Alliance)
           hızlıca ürün isim ve barkodlarını keşfeder, kataloğa kaydeder ve döndürür.
        Böylece farklı ürünler asla tek bir tabloda birbirine karışmaz!
        """
        clean_q = query.strip()
        if not clean_q:
            return []

        # Eğer zaten 8-14 haneli bir barkod ise doğrudan döndür
        if clean_q.isdigit() and len(clean_q) >= 8:
            cat_item = catalog.get_by_barcode(clean_q)
            if cat_item:
                return [cat_item]
            return [{
                "barcode": clean_q,
                "name": f"Ürün ({clean_q})",
                "manufacturer": "Genel",
                "price": 0.0
            }]

        # 1. Katalogda ara (Botanik, TRIA ve Selçuk'tan aktarılan 165.000+ ürün)
        results = catalog.search_suggestions(clean_q, limit=limit)
        if results:
            return results

        # 2. Eğer katalogda bulunamadıysa veya az ise, önce hızlı dermokozmetik motorunu dene
        discovered_items = []
        try:
            dermo_items = catalog.fetch_online_dermokozmetik(clean_q, limit=10)
            if dermo_items:
                discovered_items.extend(dermo_items)
        except Exception as e:
            print(f"[Keşif] Dermokozmetik motoru hatası: {e}")

        # 3. Selçuk Ecza üzerinden keşif yap
        try:
            selcuk_adapter = self.adapters.get(DepoKodu.SELCUK)
            if selcuk_adapter:
                raw_selcuk = await asyncio.wait_for(selcuk_adapter.search_product(clean_q), timeout=6.0)
                for r in raw_selcuk:
                    if r.barkod and r.barkod.isdigit() and len(r.barkod) >= 8:
                        discovered_items.append({
                            "barcode": r.barkod,
                            "name": r.urun_adi,
                            "manufacturer": "Selçuk Ecza",
                            "price": r.depocu_satis_fiyati,
                            "vat": r.kdv_orani
                        })
        except Exception as e:
            print(f"[Keşif] Selçuk arama hatası: {e}")

        # Alliance keşfi
        if len(discovered_items) < 5:
            try:
                alliance_adapter = self.adapters.get(DepoKodu.ALLIANCE)
                if alliance_adapter:
                    raw_alliance = await asyncio.wait_for(alliance_adapter.search_product(clean_q), timeout=6.0)
                    for r in raw_alliance:
                        if r.barkod and r.barkod.isdigit() and len(r.barkod) >= 8:
                            if not any(d["barcode"] == r.barkod for d in discovered_items):
                                discovered_items.append({
                                    "barcode": r.barkod,
                                    "name": r.urun_adi,
                                    "manufacturer": "Alliance Healthcare",
                                    "price": r.depocu_satis_fiyati,
                                    "vat": r.kdv_orani
                                })
            except Exception as e:
                print(f"[Keşif] Alliance arama hatası: {e}")

        if discovered_items:
            catalog.upsert_products(discovered_items)
            existing_barcodes = {r["barcode"] for r in results}
            for d in discovered_items:
                if d["barcode"] not in existing_barcodes:
                    results.append(d)
                    existing_barcodes.add(d["barcode"])

        return results[:limit]

    async def search_all(self, query: str, include_equivalents: bool = False) -> DepoKarsilastirmaRaporu:
        """
        Tanımlı tüm depolarda paralel (eşzamanlı) arama yapar ve karşılaştırma raporu üretir.
        Her zaman tek bir ürünü (barkodu) hedefler; farklı ürünleri asla karıştırmaz.
        Varsayılan olarak (include_equivalents=False) ana ürün sonuçlarını anında döndürür;
        muadil analizi arka planda (/api/products/equivalents) asenkron yüklenir.
        """
        self._active_user_searches += 1
        try:
            return await self._search_all_impl(query, include_equivalents=include_equivalents)
        finally:
            self._active_user_searches = max(0, self._active_user_searches - 1)

    async def _search_all_impl(self, query: str, include_equivalents: bool = False) -> DepoKarsilastirmaRaporu:
        target_query = query.strip()
        matched_name = ""

        # Eğer tam barkod değilse en uygun ürünü bul
        if not target_query.isdigit() or len(target_query) < 8:
            products = await self.find_products(target_query, limit=1)
            if products:
                target_query = products[0]["barcode"]
                matched_name = products[0]["name"]
                print(f"[Motor] Kelime araması '{query}' -> Barkod: {target_query} ({matched_name})")

        # Kanonik barkod çözümleme: Eğer Botanik'ten gelen dahili/sahte/promosyon bir barkodsa, doğrudan gerçek EAN'a geç!
        canonical_target = catalog.resolve_canonical_barcode(target_query)
        if canonical_target and canonical_target != target_query:
            print(f"[Motor] '{target_query}' dahili/promosyon kod yerine doğrudan gerçek EAN ile sorgulanıyor: {canonical_target}")
            target_query = canonical_target

        # Ürün adı ve tüm alternatif barkodlar katalogdan
        cat_info = catalog.get_by_barcode(target_query)
        all_barcodes = set([target_query])
        primary_barcode = target_query
        if cat_info:
            matched_name = cat_info["name"]
            if cat_info.get("barcode") and str(cat_info["barcode"]).isdigit():
                primary_barcode = str(cat_info["barcode"]).strip()
                all_barcodes.add(primary_barcode)
            for b in cat_info.get("all_barcodes", []):
                if str(b).isdigit() and len(str(b)) >= 8:
                    all_barcodes.add(str(b).strip())

        # Depolarda öncelikle güncel birincil barkodu sorgula (örn: eski/yeni barkod dönüşümleri)
        search_target = primary_barcode if primary_barcode.isdigit() and len(primary_barcode) >= 8 else target_query

        tasks = []
        for depo_kodu, adapter in self.adapters.items():
            tasks.append(self._safe_search(adapter, search_target))

        # Eşzamanlı sorgula
        results_nested = await asyncio.gather(*tasks)

        all_results: List[DepoUrunSarti] = []
        for res_list in results_nested:
            if res_list:
                for res in res_list:
                    # Barkod filtreleme: Aranan ürünle kesinlikle eşleşen teklifleri al
                    is_match = False
                    if any(b == res.barkod or (len(b) >= 8 and b in res.barkod) for b in all_barcodes):
                        is_match = True
                    elif not res.barkod or not res.barkod.isdigit() or len(res.barkod) < 8:
                        target_name_lower = (matched_name or (cat_info.get("name") if cat_info else query)).lower()
                        res_name_lower = (res.urun_adi or "").lower()
                        main_words = [w for w in target_name_lower.split() if len(w) > 3 and not w.isdigit()]
                        if main_words and any(w in res_name_lower for w in main_words):
                            is_match = True
                    if is_match:
                        all_results.append(res)

        # Eğer ilk denenen barkodda depolarda sonuç bulunamazsa ve alternatif barkodlar varsa dene
        if not all_results:
            other_barcodes = [b for b in all_barcodes if b != search_target]
            for alt_b in other_barcodes[:2]:
                tasks_alt = [self._safe_search(adapter, alt_b) for adapter in self.adapters.values()]
                results_alt = await asyncio.gather(*tasks_alt)
                for res_list in results_alt:
                    if res_list:
                        for res in res_list:
                            is_match = False
                            if any(b == res.barkod or (len(b) >= 8 and b in res.barkod) for b in all_barcodes):
                                is_match = True
                            elif not res.barkod or not res.barkod.isdigit() or len(res.barkod) < 8:
                                target_name_lower = (matched_name or (cat_info.get("name") if cat_info else query)).lower()
                                res_name_lower = (res.urun_adi or "").lower()
                                main_words = [w for w in target_name_lower.split() if len(w) > 3 and not w.isdigit()]
                                if main_words and any(w in res_name_lower for w in main_words):
                                    is_match = True
                            if is_match:
                                all_results.append(res)
                if all_results:
                    search_target = alt_b
                    break

        # B) HALA SONUÇ YOKSA (Örn: Botanik'te 869922222211 gibi sahte/dahili barkodla açılmış OTC/dermokozmetik ürünler):
        if not all_results:
            p_name = matched_name or (cat_info.get("name") if cat_info else query)
            if p_name:
                print(f"[Motor] Barkod ({search_target}) depolarda bulunamadı, akıllı ürün adı eşleme devrede: '{p_name}'")
                
                # 1. Adım: Katalogdan gerçek uluslararası geçerli barkodları keşfet (TRIA / WEBLISTE)
                canonical_bcs = catalog.find_canonical_barcodes_by_name(p_name, exclude_barcode=search_target)
                for can_b in canonical_bcs:
                    if can_b not in all_barcodes:
                        all_barcodes.add(can_b)
                        tasks_can = [self._safe_search(adapter, can_b) for adapter in self.adapters.values()]
                        results_can = await asyncio.gather(*tasks_can)
                        for res_list in results_can:
                            if res_list:
                                for res in res_list:
                                    if any(b == res.barkod or b in res.barkod for b in all_barcodes):
                                        all_results.append(res)
                        if all_results:
                            search_target = can_b
                            print(f"[Motor] Gerçek barkod başarıyla eşleştirildi: {can_b} ({len(all_results)} depo/pazaryeri sonucu)")
                            if cat_info and cat_info.get("id"):
                                catalog.add_barcode_to_product(cat_info["id"], can_b)
                            break

                # 2. Adım: Hala depolarda çıkmadıysa, pazaryerlerinde (Farmazon, Ecza1, EczaneTakas) ürün adıyla doğrudan ara!
                if not all_results:
                    mp_query = catalog.clean_name_for_marketplace(p_name)
                    if mp_query and len(mp_query) >= 3:
                        print(f"[Motor] Pazaryerinde metin araması yapılıyor: '{mp_query}'")
                        mp_adapters = [a for k, a in self.adapters.items() if k in (DepoKodu.FARMAZON, DepoKodu.ECZA1, DepoKodu.ECZANETAKAS)]
                        if mp_adapters:
                            tasks_mp = [self._safe_search(a, mp_query) for a in mp_adapters]
                            results_mp = await asyncio.gather(*tasks_mp)
                            for res_list in results_mp:
                                if res_list:
                                    for res in res_list:
                                        all_results.append(res)
                                        if res.barkod and res.barkod.isdigit() and len(res.barkod) >= 8:
                                            all_barcodes.add(res.barkod)
                                            if cat_info and cat_info.get("id"):
                                                catalog.add_barcode_to_product(cat_info["id"], res.barkod)

        # -----------------------------------------------------------------
        # KDV Uzlaştırma:
        # 1. Öncelik: Geleneksel depolarda (Selçuk, Alliance, Nevzat, İSKOOP, BEK) resmi KDV oranı
        # 2. Öncelik: Eczane otomasyonunda (Tria / Botanik) kayıtlı resmi KDV oranı
        # 3. Öncelik: Katalog / İsim takviye edici analizi
        # -----------------------------------------------------------------
        wholesaler_kdvs = [
            r.kdv_orani for r in all_results
            if r.depo in (DepoKodu.SELCUK, DepoKodu.ALLIANCE, DepoKodu.NEVZAT, DepoKodu.ISKOOP, DepoKodu.BEK)
            and r.kdv_orani is not None and r.kdv_orani > 0
        ]

        canonical_kdv = None
        if any(abs(k - 1.0) < 0.1 for k in wholesaler_kdvs):
            canonical_kdv = 1.0
        elif wholesaler_kdvs:
            from collections import Counter
            canonical_kdv = Counter(wholesaler_kdvs).most_common(1)[0][0]

        # Ulusal depolardan KDV gelmediyse veya depolar stoksuzsa, eczane otomasyonundan (Tria/Botanik/TEBEOS) sor
        if canonical_kdv is None:
            active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
            try:
                if active_oto == "TRIA":
                    from backend.tria_client import tria_client
                    tria_kdv = tria_client.get_product_vat(search_target)
                    if tria_kdv is not None and tria_kdv > 0:
                        canonical_kdv = tria_kdv
                elif active_oto == "BOTANIK":
                    from backend.botanik_client import botanik_client
                    bot_kdv = botanik_client.get_product_vat(search_target)
                    if bot_kdv is not None and bot_kdv > 0:
                        canonical_kdv = bot_kdv
                elif active_oto == "TEBEOS":
                    from backend.tebeos_client import tebeos_client
                    teb_kdv = tebeos_client.get_product_vat(search_target)
                    if teb_kdv is not None and teb_kdv > 0:
                        canonical_kdv = teb_kdv
            except Exception as e:
                print(f"[Motor] Otomasyon KDV sorgu hatası: {e}")

        # Eğer hala bulunamadıysa katalog veya isim analizi
        if canonical_kdv is None:
            if cat_info and cat_info.get("vat") and float(cat_info["vat"]) > 0:
                canonical_kdv = float(cat_info["vat"])
            else:
                name_sample = (matched_name or query)
                for r in all_results:
                    if r.urun_adi:
                        name_sample = r.urun_adi
                        break
                name_lower = name_sample.lower()
                supplement_keywords = [
                    "takviye edici", "gida takviyesi", "gıda takviyesi", "omega", "balık yağı", "balik yagi",
                    "vitamin", "mineral", "multivitamin", "kolajen", "kollajen", "collagen",
                    "magnezyum", "magnesium", "çinko", "zinc", "probiyotik", "probiotik",
                    "d3", "b12", "c vitamini", "ester-c", "sambucol", "solgar", "ocean",
                    "venatura", "zade vital", "supradyn", "pharmaton", "vefail", "coenzyme", "koenzim",
                    "krill", "propolis", "kara mürver", "melatonin", "glukozamin", "glucosamine", "laktaz", "damla"
                ]
                if any(kw in name_lower for kw in supplement_keywords):
                    canonical_kdv = 1.0
                else:
                    canonical_kdv = 10.0

        # Pazaryerlerine ve alım gruplarına (ve KDV'si eksik depolara) kanonik KDV'yi uygula
        # Farmazon ve Ecza1 pazaryerlerinde satıcı teklif fiyatları KDV DAHİLDİR.
        # Bu platformların KDV Hariç net maliyeti, ulusal depodaki resmi KDV oranına
        # bölünerek hesaplanır (Örn: KDV Dahil 110 ₺ -> KDV Hariç 100 ₺).
        kdv_multiplier = 1.0 + (canonical_kdv / 100.0)

        for r in all_results:
            if r.depo in (DepoKodu.FARMAZON, DepoKodu.ECZA1, DepoKodu.ECZANETAKAS):
                r.kdv_orani = canonical_kdv

                # Farmazon, Ecza1 ve EczaneTakas'ta satıcı teklif fiyatları KDV DAHİLDİR.
                # Dolayısıyla net_birim_maliyet_kdvli (KDV Dahil) referans alınarak
                # KDV Hariç fiyat canonical_kdv oranına göre düşülerek hesaplanır:
                raw_kdvli = r.net_birim_maliyet_kdvli if r.net_birim_maliyet_kdvli > 0 else r.net_birim_maliyet
                r.net_birim_maliyet_kdvli = round(raw_kdvli, 2)
                r.net_birim_maliyet = round(raw_kdvli / kdv_multiplier, 2)
                r.depocu_satis_fiyati = r.net_birim_maliyet

                # Pazaryerindeki tüm satıcı tekliflerini de ulusal depodaki KDV oranına göre güncelle
                if r.pazaryeri_teklifleri:
                    for off in r.pazaryeri_teklifleri:
                        off_kdvli = float(off.get("fiyat_kdvli") or off.get("fiyat") or 0.0)
                        off["fiyat_kdvli"] = round(off_kdvli, 2)
                        off["fiyat"] = round(off_kdvli, 2)
                        off["fiyat_kdvsiz"] = round(off_kdvli / kdv_multiplier, 2)
                        off["kdv"] = canonical_kdv

            elif r.depo == DepoKodu.ECZATREND:
                # Eczatrend ortak alım grubunda girilen barem net fiyatı KDV HARİÇ fiyattır
                r.kdv_orani = canonical_kdv
                if r.net_birim_maliyet > 0:
                    r.net_birim_maliyet_kdvli = round(r.net_birim_maliyet * kdv_multiplier, 2)

            elif r.kdv_orani <= 0:
                r.kdv_orani = canonical_kdv
                r.net_birim_maliyet_kdvli = round(r.net_birim_maliyet * kdv_multiplier, 2)

        # Depo bazında birleştir:
        # - İSKOOP, BEK vb. çoklu şart sunan depolarda her vadeyi (90 Gün Vade & Kredi Kartı) ayrı satır olarak koru;
        # - Pazaryeri platformlarında (Farmazon, Ecza1) ise aynı depo altında teklifleri birleştir.
        depo_groups: Dict[Any, DepoUrunSarti] = {}
        for r in all_results:
            group_key = (r.depo, r.depo_adi) if r.depo in (DepoKodu.ISKOOP, DepoKodu.BEK) else r.depo
            if group_key not in depo_groups:
                depo_groups[group_key] = r
            else:
                existing = depo_groups[group_key]
                # En ucuz olanı ana kayıt olarak belirle
                take_r_as_main = (
                    (r.stok_durumu == StokDurumu.VAR and existing.stok_durumu != StokDurumu.VAR) or
                    (r.stok_durumu == existing.stok_durumu and r.net_birim_maliyet > 0 and (existing.net_birim_maliyet <= 0 or r.net_birim_maliyet < existing.net_birim_maliyet))
                )
                main_rec = r if take_r_as_main else existing
                other_rec = existing if take_r_as_main else r

                # Pazaryeri tekliflerini birleştir
                merged_offers = (main_rec.pazaryeri_teklifleri or []) + (other_rec.pazaryeri_teklifleri or [])
                seen_ids = set()
                unique_offers = []
                for off in merged_offers:
                    i_id = off.get("ilan_id") or f"{off.get('satici')}_{off.get('fiyat_kdvsiz')}"
                    if i_id not in seen_ids:
                        seen_ids.add(i_id)
                        unique_offers.append(off)
                unique_offers.sort(key=lambda x: x.get("fiyat_kdvsiz", 0.0))

                main_rec.pazaryeri_teklifleri = unique_offers
                if unique_offers:
                    main_rec.stok_adedi = len(unique_offers)
                    main_rec.ozel_kampanya_notu = f"{len(unique_offers)} Eczane Satışta (Farklı Fiyatlar)"
                    if unique_offers[0].get("miad") and unique_offers[0].get("miad") != "-":
                        main_rec.miad = unique_offers[0].get("miad")

                depo_groups[group_key] = main_rec

        all_results = list(depo_groups.values())

        # Maliyete göre en uygun olanı sırala: Stokta olanlar önce, ardından en düşük birim maliyet
        all_results.sort(key=lambda x: (
            0 if x.stok_durumu == StokDurumu.VAR else 1,
            x.net_birim_maliyet if x.net_birim_maliyet > 0 else 999999
        ))

        # Soğuk Zincir Tespiti
        cold_keywords = [
            "soğuk zincir", "soguk zincir", "2-8", "+2/+8", "2°c", "8°c",
            "insülin", "insulin", "lantus", "humalog", "novorapid", "levemir", "tresiba", "toujeo",
            "aşı", "asi", "gardasil", "rotarix", "nimenrix", "bexsero", "varilrix",
            "ozempic", "saxenda", "trulicity", "enbrel", "humira", "clexane", "enox"
        ]
        soguk_zincir = any(r.soguk_zincir for r in all_results)
        if not soguk_zincir and any(kw in (matched_name or query).lower() for kw in cold_keywords):
            soguk_zincir = True
        
        if soguk_zincir:
            for r in all_results:
                r.soguk_zincir = True

        # SGK Kamu İskontosu, Eczacı Kârı ve PSF
        kamu_iskontosu = max([r.kamu_iskontosu for r in all_results if r.kamu_iskontosu > 0] or [0.0])
        eczaci_kari = max([r.eczaci_kari for r in all_results if r.eczaci_kari > 0] or [0.0])
        psf = max([r.perakende_satis_fiyati for r in all_results if r.perakende_satis_fiyati > 0] or [0.0])

        if cat_info:
            if kamu_iskontosu == 0.0 and cat_info.get("institution_discount"):
                kamu_iskontosu = float(cat_info["institution_discount"])
            if eczaci_kari == 0.0 and cat_info.get("profit_rate"):
                eczaci_kari = float(cat_info["profit_rate"])
            if psf == 0.0 and cat_info.get("price"):
                psf = float(cat_info["price"])

        # Kamu Satış Fiyatı (KSF) Hesaplama: PSF * (1 - Kamu İskontosu / 100)
        kamu_fiyati = round(psf * (1.0 - (kamu_iskontosu / 100.0)), 2) if (psf > 0 and kamu_iskontosu > 0) else round(psf, 2)

        # Eşdeğer Kodu ve Muadiller
        esdeger_kodu = None
        esdegerler = []
        for r in all_results:
            if r.esdeger_kodu and not esdeger_kodu:
                esdeger_kodu = r.esdeger_kodu
            if r.esdegerler and not esdegerler:
                esdegerler = r.esdegerler

        if include_equivalents and not esdegerler:
            active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
            try:
                if active_oto == "TRIA":
                    from backend.tria_client import tria_client
                    eq_res = await asyncio.to_thread(tria_client.get_product_equivalents, search_target)
                    if eq_res.get("found"):
                        esdeger_kodu = esdeger_kodu or eq_res.get("esdeger_kodu")
                        esdegerler = eq_res.get("muadiller", [])
                elif active_oto == "BOTANIK":
                    from backend.botanik_client import botanik_client
                    eq_res = await asyncio.to_thread(botanik_client.get_product_equivalents, search_target)
                    if eq_res.get("found"):
                        esdeger_kodu = esdeger_kodu or eq_res.get("esdeger_kodu")
                        esdegerler = eq_res.get("muadiller", [])
                elif active_oto == "TEBEOS":
                    from backend.tebeos_client import tebeos_client
                    eq_res = await asyncio.to_thread(tebeos_client.get_product_equivalents, search_target)
                    if eq_res.get("found"):
                        esdeger_kodu = esdeger_kodu or eq_res.get("esdeger_kodu")
                        esdegerler = eq_res.get("muadiller", [])
            except Exception as e:
                print(f"[Motor] Otomasyon eşdeğer sorgu hatası: {e}")

        en_avantajli: Optional[DepoKodu] = None
        en_dusuk_fiyat: Optional[float] = None
        en_dusuk_fiyat_kdvli: Optional[float] = None
        stoktaki_depolar = []

        urun_adi = matched_name or query
        for res in all_results:
            if not urun_adi or urun_adi == query:
                urun_adi = res.urun_adi

            # Her deponun kârlarını hesapla
            r_alis_kdvli = res.net_birim_maliyet_kdvli if res.net_birim_maliyet_kdvli > 0 else round(res.net_birim_maliyet * (1.0 + (res.kdv_orani / 100.0)), 2)
            res.kamu_fiyati = kamu_fiyati
            res.kamu_kari = round(kamu_fiyati - r_alis_kdvli, 2) if (kamu_fiyati > 0 and r_alis_kdvli > 0) else 0.0
            res.perakende_kari = round(psf - r_alis_kdvli, 2) if (psf > 0 and r_alis_kdvli > 0) else 0.0

            if res.stok_durumu == StokDurumu.VAR:
                if res.depo not in stoktaki_depolar:
                    stoktaki_depolar.append(res.depo)
                if en_dusuk_fiyat is None and res.net_birim_maliyet > 0:
                    en_dusuk_fiyat = res.net_birim_maliyet
                    en_dusuk_fiyat_kdvli = res.net_birim_maliyet_kdvli
                    en_avantajli = res.depo

        best_cost_kdvli = en_dusuk_fiyat_kdvli or 0.0
        kamu_kari = round(kamu_fiyati - best_cost_kdvli, 2) if (kamu_fiyati > 0 and best_cost_kdvli > 0) else 0.0
        perakende_kari = round(psf - best_cost_kdvli, 2) if (psf > 0 and best_cost_kdvli > 0) else 0.0

        # Muadiller Anlık MF & Kârlılık Analizi (Yalnızca include_equivalents=True ise burada çalışır;
        # normal aramada arayüz açıldıktan sonra /api/products/equivalents ile arka planda yüklenir)
        en_karli_muadil = None
        muadil_kar_avantaji = 0.0

        def clean_brand_name(text: str) -> str:
            if not text:
                return ""
            tr_map = {'ı': 'i', 'I': 'i', 'İ': 'i', 'ş': 's', 'Ş': 's', 'ğ': 'g', 'Ğ': 'g', 'ü': 'u', 'Ü': 'u', 'ö': 'o', 'Ö': 'o', 'ç': 'c', 'Ç': 'c'}
            n = text
            for k, v in tr_map.items():
                n = n.replace(k, v)
            words = re.findall(r'[a-z0-9]+', n.lower())
            return words[0] if words else ""

        if include_equivalents and esdegerler:
            active_oto = os.environ.get("ACTIVE_OTOMASYON", "TRIA").strip().upper()
            oto_map = {}
            oto_brand_map = {}
            try:
                if active_oto == "TRIA":
                    from backend.tria_client import tria_client
                    eq_oto = tria_client.get_product_equivalents(search_target)
                elif active_oto == "BOTANIK":
                    from backend.botanik_client import botanik_client
                    eq_oto = botanik_client.get_product_equivalents(search_target)
                elif active_oto == "TEBEOS":
                    from backend.tebeos_client import tebeos_client
                    eq_oto = tebeos_client.get_product_equivalents(search_target)
                else:
                    eq_oto = {}
                if eq_oto and eq_oto.get("found"):
                    for item in eq_oto.get("muadiller", []):
                        m_k = str(item.get("mal_kodu", "")).strip()
                        m_b = str(item.get("barkod", "")).strip()
                        m_n = str(item.get("urun_adi", "")).strip()
                        if m_k: oto_map[m_k] = item
                        if m_b: oto_map[m_b] = item
                        b_clean = clean_brand_name(m_n)
                        if b_clean and (b_clean not in oto_brand_map or item.get("stok", 0) > oto_brand_map[b_clean].get("stok", 0)):
                            oto_brand_map[b_clean] = item
            except Exception:
                pass

            # Her muadilin kâr farkını ve avantajını hesapla, stok ve barkodları kesinleştir
            for eq in esdegerler:
                m_kod = str(eq.get("kod") or eq.get("mal_kodu") or "").strip()
                m_ad = str(eq.get("ad") or eq.get("urun_adi") or "").strip()
                m_brand = clean_brand_name(m_ad)

                # Eşleşme: 1. Selçuk kodu/barkod, 2. Marka adı
                m_oto = oto_map.get(m_kod) or oto_brand_map.get(m_brand) or {}

                # 3. 13 haneli EAN barkodunu katalogdan doğrula
                real_bc = m_oto.get("barkod") or eq.get("barkod")
                if not real_bc or len(str(real_bc)) < 8 or not str(real_bc).isdigit():
                    try:
                        suggs = catalog.search_suggestions(m_ad, limit=1)
                        if suggs and suggs[0].get("barcode"):
                            real_bc = suggs[0]["barcode"]
                            if not m_oto:
                                m_oto = oto_map.get(real_bc, {})
                    except Exception:
                        pass

                # 4. Eğer hala stok bilgisi yoksa aktif otomasyondan (TRIA, BOTANIK veya TEBEOS) tekil analizden çek
                if (not m_oto or "stok" not in m_oto) and (real_bc or m_brand):
                    try:
                        single_res = None
                        if active_oto == "TRIA":
                            from backend.tria_client import tria_client
                            single_res = tria_client.get_product_analysis(m_ad or m_brand, barcode=str(real_bc or ""))
                        elif active_oto == "BOTANIK":
                            from backend.botanik_client import botanik_client
                            single_res = botanik_client.get_product_analysis(m_ad or m_brand, barcode=str(real_bc or ""))
                        elif active_oto == "TEBEOS":
                            from backend.tebeos_client import tebeos_client
                            single_res = tebeos_client.get_product_analysis(m_ad or m_brand, barcode=str(real_bc or ""))

                        if single_res and single_res.get("found"):
                            aylik_cikis = 0
                            if single_res.get("aylik_cikislar"):
                                aylik_cikis = single_res["aylik_cikislar"][-1].get("toplam", 0)
                            else:
                                aylik_cikis = int(single_res.get("ort_aylik_cikis", 0))
                            mf_var = any((g.get("mf") or 0) > 0 for g in (single_res.get("son_girisler") or []))
                            m_oto = {
                                "stok": single_res.get("stok", 0),
                                "cikis_30gun": aylik_cikis,
                                "barkod": single_res.get("barkod") or real_bc or m_kod,
                                "gecmis_mf_var": mf_var,
                                "gecmis_mf_bilgi": ""
                            }
                            if not real_bc:
                                real_bc = m_oto.get("barkod")
                    except Exception:
                        pass

                eq["stok"] = m_oto.get("stok", eq.get("stok", 0))
                eq["cikis_30gun"] = m_oto.get("cikis_30gun", eq.get("cikis_30gun", 0))
                eq["barkod"] = real_bc or eq.get("barkod") or m_kod
                eq["gecmis_mf_var"] = m_oto.get("gecmis_mf_var", eq.get("gecmis_mf_var", False))
                eq["gecmis_mf_bilgi"] = m_oto.get("gecmis_mf_bilgi", eq.get("gecmis_mf_bilgi", ""))
                eq["gecmis_mf_kisa"] = m_oto.get("gecmis_mf_kisa", eq.get("gecmis_mf_kisa", ""))

                # Kamu İskontosu ve KSF ön doğrulama
                eq_kamu_isk = float(eq.get("kamu_iskontosu") or 0.0)
                if eq_kamu_isk <= 0.0 and m_oto and float(m_oto.get("kamu_iskontosu") or 0.0) > 0.0:
                    eq_kamu_isk = float(m_oto["kamu_iskontosu"])
                if eq_kamu_isk <= 0.0 and real_bc:
                    try:
                        cat_eq = catalog.get_by_barcode(str(real_bc))
                        if cat_eq and float(cat_eq.get("institution_discount") or 0.0) > 0.0:
                            eq_kamu_isk = float(cat_eq["institution_discount"])
                    except Exception:
                        pass
                if eq_kamu_isk <= 0.0 and kamu_iskontosu > 0.0 and eq.get("is_current"):
                    eq_kamu_isk = kamu_iskontosu

                eq_psf = float(eq.get("psf") or eq.get("etiket_fiyati") or (m_oto.get("psf") if m_oto else 0.0) or 0.0)
                existing_ksf = float(eq.get("ksf") or eq.get("kamu_fiyati") or (m_oto.get("ksf") if m_oto else 0.0) or 0.0)
                if existing_ksf > 0 and (eq_psf <= 0 or existing_ksf < eq_psf):
                    eq_ksf = round(existing_ksf, 2)
                    if eq_kamu_isk <= 0.0 and eq_psf > eq_ksf > 0:
                        eq_kamu_isk = round((1.0 - (eq_ksf / eq_psf)) * 100.0, 2)
                else:
                    eq_ksf = round(eq_psf * (1.0 - (eq_kamu_isk / 100.0)), 2) if (eq_psf > 0 and eq_kamu_isk > 0) else round(eq_psf, 2)

                eq["psf"] = round(eq_psf, 2)
                eq["kamu_iskontosu"] = round(eq_kamu_isk, 2)
                eq["ksf"] = eq_ksf
                eq["kamu_fiyati"] = eq_ksf

            # Aktif depolardan (Alliance, İSKOOP, Selçuk, Eczatrend, Nevzat, BEK, DNA) tüm muadillerin ANLIK CANLI MF ve birim maliyetlerini çek
            await self.enrich_equivalents_with_live_mf(
                esdegerler=esdegerler,
                search_target=search_target,
                current_results=all_results,
                base_kamu_kari=kamu_kari,
                canonical_kdv=canonical_kdv
            )

            for item in esdegerler:
                if item.get("is_best_deal"):
                    en_karli_muadil = item
                    muadil_kar_avantaji = float(item.get("kar_farki") or 0.0)
                    break

        return DepoKarsilastirmaRaporu(
            barkod=search_target if (search_target and search_target.isdigit() and len(search_target) >= 8) else target_query,
            urun_adi=matched_name or urun_adi,
            en_avantajli_depo=en_avantajli,
            en_dusuk_maliyet=en_dusuk_fiyat,
            en_dusuk_maliyet_kdvli=en_dusuk_fiyat_kdvli,
            stokta_bulunan_depolar=stoktaki_depolar,
            sonuclar=all_results,
            soguk_zincir=soguk_zincir,
            kamu_iskontosu=kamu_iskontosu,
            eczaci_kari=eczaci_kari,
            psf=psf,
            kamu_fiyati=kamu_fiyati,
            kamu_kari=kamu_kari,
            perakende_kari=perakende_kari,
            esdeger_kodu=esdeger_kodu,
            esdegerler=esdegerler,
            en_karli_muadil=en_karli_muadil,
            muadil_kar_avantaji=muadil_kar_avantaji
        )

    async def enrich_equivalents_with_live_mf(
        self,
        esdegerler: List[Dict[str, Any]],
        search_target: str = "",
        current_results: Optional[List[DepoUrunSarti]] = None,
        base_kamu_kari: float = 0.0,
        canonical_kdv: float = 10.0
    ) -> List[Dict[str, Any]]:
        """
        Muadil / Eşdeğer listesindeki her ilacın barkodunu aktif toptancı depolarda
        (Alliance, İSKOOP, Eczatrend, Selçuk, Nevzat, BEK, DNA) paralel sorgulayarak
        anlık canlı MF kademelerini, net birim maliyetlerini ve SGK reçete kâr farklarını günceller.
        """
        if not esdegerler:
            return esdegerler

        from backend.core.cost_calculator import CostCalculator
        try:
            from backend.mf_resolver import mf_resolver
        except Exception:
            mf_resolver = None

        wholesale_codes = (
            DepoKodu.ALLIANCE,
            DepoKodu.ISKOOP,
            DepoKodu.ECZATREND,
            DepoKodu.SELCUK,
            DepoKodu.NEVZAT,
            DepoKodu.BEK,
            DepoKodu.DNA
        )
        lockless_http_codes = (
            DepoKodu.ECZATREND,
            DepoKodu.BEK,
            DepoKodu.DNA
        )
        playwright_fast_codes = (
            DepoKodu.ALLIANCE,
            DepoKodu.ISKOOP
        )

        http_adapters = [ad for k, ad in self.adapters.items() if k in lockless_http_codes]
        pw_adapters = [ad for k, ad in self.adapters.items() if k in playwright_fast_codes]
        query_adapters = http_adapters + pw_adapters

        sem = asyncio.Semaphore(6)
        now_ts = time.time()

        async def _query_adapter_single(ad: BaseDepoAdapter, bc_str: str, allow_playwright: bool = True) -> List[DepoUrunSarti]:
            if not bc_str or getattr(ad, "_cart_busy", 0) > 0:
                return []
            is_pw = ad.depo_kodu in (DepoKodu.ALLIANCE, DepoKodu.ISKOOP, DepoKodu.SELCUK, DepoKodu.NEVZAT)
            if is_pw:
                if not allow_playwright or self._active_user_searches > 0:
                    return []
                # İSKOOP'ta MATNR önbellekte yoksa 24'lü tarama yapıp tarayıcı kilidini meşgul etmesin
                if ad.depo_kodu == DepoKodu.ISKOOP and bc_str not in getattr(ad, "_matnr_cache", {}):
                    return []
            async with sem:
                if is_pw and self._active_user_searches > 0:
                    return []
                try:
                    try:
                        return await asyncio.wait_for(
                            ad.search_product(bc_str, include_equivalents=False, is_background=True),
                            timeout=3.2
                        )
                    except TypeError:
                        return await asyncio.wait_for(ad.search_product(bc_str), timeout=3.2)
                except Exception:
                    return []

        async def _fetch_live_for_eq(eq: Dict[str, Any], idx: int = 0):
            bc = str(eq.get("barkod") or eq.get("kod") or "").strip()
            m_ad = str(eq.get("urun_adi") or eq.get("ad") or "").strip()
            try:
                can_bc = catalog.resolve_canonical_barcode(bc)
                if can_bc and len(can_bc) >= 8 and can_bc.isdigit():
                    bc = can_bc
                    eq["barkod"] = bc
            except Exception:
                pass

            if (not bc or len(bc) < 8 or not bc.isdigit()) and m_ad:
                try:
                    suggs = catalog.search_suggestions(m_ad, limit=1)
                    if suggs and suggs[0].get("barcode"):
                        bc = str(suggs[0]["barcode"]).strip()
                        eq["barkod"] = bc
                except Exception:
                    pass

            depo_sartlar: List[DepoUrunSarti] = []
            is_curr = bool(eq.get("is_current")) or (search_target and bc == str(search_target).strip())
            if is_curr:
                eq["is_current"] = True
                if current_results:
                    depo_sartlar = [r for r in current_results if r.depo in wholesale_codes]

            # 3 dakikalık canlı muadil önbelleği kontrolü (0 ms yanıt)
            if not depo_sartlar and bc in self._eq_live_cache:
                c_ts, c_list = self._eq_live_cache[bc]
                if (now_ts - c_ts) < 180.0 and c_list:
                    depo_sartlar = list(c_list)

            # Selçuk'tan zaten canlı MF ve maliyet gelmiş olanlarda tarayıcı kilidini sadece ilk 4 öncelikli muadil için kullan
            allow_pw = (idx < 4) or is_curr or (int(eq.get("stok") or 0) > 0)

            if not depo_sartlar and bc and len(bc) >= 8 and bc.isdigit() and query_adapters:
                nested = await asyncio.gather(*[_query_adapter_single(ad, bc, allow_playwright=allow_pw) for ad in query_adapters], return_exceptions=True)
                for r_list in nested:
                    if isinstance(r_list, list):
                        for r in r_list:
                            if not r.barkod or r.barkod == bc or bc in str(r.barkod):
                                depo_sartlar.append(r)
                if depo_sartlar:
                    self._eq_live_cache[bc] = (now_ts, list(depo_sartlar))

            # Canlı depo sonuçlarını işle
            def _has_live_mf(s: DepoUrunSarti) -> bool:
                m_txt = str(s.mf_metni or "").strip().upper()
                return bool(m_txt and m_txt not in ("YOK", "-", "0", "NONE", "PAZARYERİ", "PAZARYERI") and "+" in m_txt)

            mf_offers = [r for r in depo_sartlar if _has_live_mf(r)]
            mf_offers.sort(key=lambda r: (
                0 if r.stok_durumu == StokDurumu.VAR else 1,
                r.net_birim_maliyet_kdvli if r.net_birim_maliyet_kdvli > 0 else 999999
            ))
            depo_sartlar.sort(key=lambda r: (
                0 if r.stok_durumu == StokDurumu.VAR else 1,
                0 if _has_live_mf(r) else 1,
                r.net_birim_maliyet_kdvli if r.net_birim_maliyet_kdvli > 0 else 999999
            ))

            kdv_val = float(eq.get("kdv_orani") or canonical_kdv or 10.0)
            kdv_mult = 1.0 + (kdv_val / 100.0)

            if mf_offers:
                best_r = mf_offers[0]
                # Tüm MF veren depoların kademelerini birleştir (en düşük maliyetli olanı koru)
                kademe_by_text: Dict[str, Dict[str, Any]] = {}
                depo_names_with_mf: List[str] = []

                for r_off in mf_offers:
                    short_depo = (
                        "Alliance" if r_off.depo == DepoKodu.ALLIANCE else
                        "İSKOOP" if r_off.depo == DepoKodu.ISKOOP else
                        "Selçuk" if r_off.depo == DepoKodu.SELCUK else
                        "Eczatrend" if r_off.depo == DepoKodu.ECZATREND else
                        "Nevzat" if r_off.depo == DepoKodu.NEVZAT else
                        "BEK" if r_off.depo == DepoKodu.BEK else
                        r_off.depo_adi
                    )
                    if short_depo not in depo_names_with_mf:
                        depo_names_with_mf.append(short_depo)

                    r_kads = list(r_off.kademeler or [])
                    if not r_kads and _has_live_mf(r_off):
                        calc = CostCalculator.calculate(
                            dsf=r_off.depocu_satis_fiyati if r_off.depocu_satis_fiyati > 0 else r_off.net_birim_maliyet,
                            psf=r_off.perakende_satis_fiyati,
                            kdv_orani=r_off.kdv_orani or kdv_val,
                            mf_str=r_off.mf_metni,
                            ticari_iskonto=r_off.ticari_iskonto,
                            vade_gun=r_off.vade_gun
                        )
                        r_kads = list(calc.kademeler or [])

                    for k_obj in r_kads:
                        if isinstance(k_obj, dict):
                            a = int(k_obj.get("alinan") or 0)
                            h = int(k_obj.get("hediye") or 0)
                            m_txt = str(k_obj.get("mf_text") or f"{a}+{h}").strip()
                            net_kdvsiz = float(k_obj.get("net_birim_maliyet") or k_obj.get("birim_maliyet") or 0.0)
                            net_kdvli = float(k_obj.get("net_birim_maliyet_kdvli") or k_obj.get("birim_maliyet_kdvli") or (net_kdvsiz * kdv_mult))
                            isk_pct = float(k_obj.get("toplam_iskonto_yuzdesi") or k_obj.get("iskonto_yuzdesi") or (round((h / (a + h)) * 100.0, 1) if (a + h) > 0 else 0.0))
                        else:
                            a = int(getattr(k_obj, "alinan", 0) or 0)
                            h = int(getattr(k_obj, "hediye", 0) or 0)
                            m_txt = str(getattr(k_obj, "mf_text", f"{a}+{h}")).strip()
                            net_kdvsiz = float(getattr(k_obj, "net_birim_maliyet", 0.0) or 0.0)
                            net_kdvli = float(getattr(k_obj, "net_birim_maliyet_kdvli", 0.0) or (net_kdvsiz * kdv_mult))
                            isk_pct = float(getattr(k_obj, "toplam_iskonto_yuzdesi", 0.0) or (round((h / (a + h)) * 100.0, 1) if (a + h) > 0 else 0.0))

                        if a <= 0 or h <= 0:
                            continue
                        k_dict = {
                            "alinan": a,
                            "hediye": h,
                            "mf_text": m_txt,
                            "net_birim_maliyet": round(net_kdvsiz, 2),
                            "birim_maliyet": round(net_kdvsiz, 2),
                            "net_birim_maliyet_kdvli": round(net_kdvli, 2),
                            "birim_maliyet_kdvli": round(net_kdvli, 2),
                            "iskonto_yuzdesi": round(isk_pct, 1),
                            "toplam_iskonto_yuzdesi": round(isk_pct, 1),
                            "depo": short_depo
                        }
                        if m_txt not in kademe_by_text or (0 < k_dict["net_birim_maliyet_kdvli"] < kademe_by_text[m_txt]["net_birim_maliyet_kdvli"]):
                            kademe_by_text[m_txt] = k_dict

                merged_kademeler = sorted(
                    kademe_by_text.values(),
                    key=lambda x: (x["net_birim_maliyet_kdvli"] if x["net_birim_maliyet_kdvli"] > 0 else 999999)
                )
                # Aynı zamanda alinan adede göre sıralı gösterim metni
                ordered_by_qty = sorted(merged_kademeler, key=lambda x: x["alinan"])
                full_mf_str = " / ".join(x["mf_text"] for x in ordered_by_qty) if ordered_by_qty else best_r.mf_metni
                best_tier_str = merged_kademeler[0]["mf_text"] if merged_kademeler else best_r.mf_metni.split("/")[0].strip()

                eq["mf"] = full_mf_str
                eq["en_iyi_mf"] = best_tier_str
                eq["kademeler"] = merged_kademeler
                eq["depo"] = " • ".join(depo_names_with_mf[:2]) if depo_names_with_mf else best_r.depo_adi
                eq["depo_stok"] = (best_r.stok_durumu == StokDurumu.VAR)
                eq["vade"] = f"{best_r.vade_gun} Gün"
                eq["iskonto"] = round(float(best_r.ticari_iskonto or 0.0), 2)

                best_net_kdvli = merged_kademeler[0]["net_birim_maliyet_kdvli"] if (merged_kademeler and merged_kademeler[0]["net_birim_maliyet_kdvli"] > 0) else best_r.net_birim_maliyet_kdvli
                best_net_kdvsiz = merged_kademeler[0]["net_birim_maliyet"] if (merged_kademeler and merged_kademeler[0]["net_birim_maliyet"] > 0) else best_r.net_birim_maliyet
                if best_net_kdvli > 0:
                    eq["net_birim_maliyet_kdvli"] = round(best_net_kdvli, 2)
                    eq["birim_maliyet_kdvli"] = round(best_net_kdvli, 2)
                if best_net_kdvsiz > 0:
                    eq["net_birim_maliyet"] = round(best_net_kdvsiz, 2)
                    eq["birim_maliyet"] = round(best_net_kdvsiz, 2)
                if best_r.perakende_satis_fiyati > 0:
                    eq["psf"] = round(best_r.perakende_satis_fiyati, 2)
                if best_r.kamu_iskontosu > 0:
                    eq["kamu_iskontosu"] = round(best_r.kamu_iskontosu, 2)

                if mf_resolver and bc:
                    try:
                        mf_resolver.set_cached_mf(bc, full_mf_str, eq["depo"])
                    except Exception:
                        pass

            elif depo_sartlar:
                # Canlı depoda bulundu fakat aktif MF yok (eğer Selçuk'tan zaten MF gelmediyse güncelle)
                existing_mf = str(eq.get("en_iyi_mf") or eq.get("mf") or "").strip()
                if not (existing_mf and existing_mf != "YOK" and "+" in existing_mf):
                    best_r = depo_sartlar[0]
                    short_depo = (
                        "Alliance" if best_r.depo == DepoKodu.ALLIANCE else
                        "İSKOOP" if best_r.depo == DepoKodu.ISKOOP else
                        "Selçuk" if best_r.depo == DepoKodu.SELCUK else
                        "Eczatrend" if best_r.depo == DepoKodu.ECZATREND else
                        best_r.depo_adi
                    )
                    eq["mf"] = "YOK"
                    eq["en_iyi_mf"] = "YOK"
                    eq["kademeler"] = []
                    eq["depo"] = short_depo
                    eq["depo_stok"] = (best_r.stok_durumu == StokDurumu.VAR)
                    eq["vade"] = f"{best_r.vade_gun} Gün"
                    eq["iskonto"] = round(float(best_r.ticari_iskonto or 0.0), 2)
                    if best_r.net_birim_maliyet_kdvli > 0:
                        eq["net_birim_maliyet_kdvli"] = round(best_r.net_birim_maliyet_kdvli, 2)
                        eq["birim_maliyet_kdvli"] = round(best_r.net_birim_maliyet_kdvli, 2)
                    if best_r.net_birim_maliyet > 0:
                        eq["net_birim_maliyet"] = round(best_r.net_birim_maliyet, 2)
                        eq["birim_maliyet"] = round(best_r.net_birim_maliyet, 2)
                    if best_r.perakende_satis_fiyati > 0:
                        eq["psf"] = round(best_r.perakende_satis_fiyati, 2)
                    if best_r.kamu_iskontosu > 0:
                        eq["kamu_iskontosu"] = round(best_r.kamu_iskontosu, 2)

            eq["live_mf_checked"] = True

            # KSF, SGK Reçete Kârı ve Elden Satış Kârını canlı MF maliyetine göre yeniden hesapla
            eq_psf = float(eq.get("psf") or eq.get("etiket_fiyati") or 0.0)
            eq_kamu_isk = float(eq.get("kamu_iskontosu") or 0.0)
            existing_ksf = float(eq.get("ksf") or eq.get("kamu_fiyati") or 0.0)
            if existing_ksf > 0 and (eq_psf <= 0 or existing_ksf < eq_psf):
                eq_ksf = round(existing_ksf, 2)
                if eq_kamu_isk <= 0.0 and eq_psf > eq_ksf > 0:
                    eq_kamu_isk = round((1.0 - (eq_ksf / eq_psf)) * 100.0, 2)
            else:
                eq_ksf = round(eq_psf * (1.0 - (eq_kamu_isk / 100.0)), 2) if (eq_psf > 0 and eq_kamu_isk > 0) else round(eq_psf, 2)

            eq_net_kdvli = float(eq.get("net_birim_maliyet_kdvli") or eq.get("birim_maliyet_kdvli") or 0.0)
            eq["kamu_iskontosu"] = round(eq_kamu_isk, 2)
            eq["ksf"] = eq_ksf
            eq["kamu_fiyati"] = eq_ksf
            if eq_ksf > 0 and eq_net_kdvli > 0:
                eq["kamu_kari"] = round(eq_ksf - eq_net_kdvli, 2)
            if eq_psf > 0 and eq_net_kdvli > 0:
                eq["perakende_kari"] = round(eq_psf - eq_net_kdvli, 2)

        await asyncio.gather(*[_fetch_live_for_eq(eq, idx) for idx, eq in enumerate(esdegerler[:15])], return_exceptions=True)

        # Aranan ilacın güncel kamu kârını bul
        curr_item = next((x for x in esdegerler if x.get("is_current")), None)
        ref_kamu_kari = float(curr_item.get("kamu_kari") or 0.0) if curr_item else float(base_kamu_kari or 0.0)
        if ref_kamu_kari <= 0.0 and base_kamu_kari > 0.0:
            ref_kamu_kari = float(base_kamu_kari)

        for eq in esdegerler:
            eq["is_best_deal"] = False
            eq_kamu_kari = float(eq.get("kamu_kari") or 0.0)
            kar_farki = round(eq_kamu_kari - ref_kamu_kari, 2)
            eq["kar_farki"] = kar_farki
            eq["is_more_profitable"] = (kar_farki > 0 and not eq.get("is_current"))
            eq["kar_artis_yuzdesi"] = round((kar_farki / ref_kamu_kari * 100.0), 1) if (ref_kamu_kari > 0 and kar_farki > 0) else 0.0

        # En yüksek SGK reçete kârı (ve canlı MF avantajı) en başta olacak şekilde sırala
        esdegerler.sort(
            key=lambda x: (
                round(float(x.get("kamu_kari") or 0.0), 2),
                1 if (x.get("en_iyi_mf") and "+" in str(x.get("en_iyi_mf"))) else 0,
                int(x.get("stok") or 0)
            ),
            reverse=True
        )

        for item in esdegerler:
            if float(item.get("kar_farki") or 0.0) > 0 and not item.get("is_current"):
                item["is_best_deal"] = True
                break

        return esdegerler

    async def _safe_search(self, adapter: BaseDepoAdapter, query: str) -> List[DepoUrunSarti]:
        is_marketplace = adapter.depo_kodu in (
            DepoKodu.FARMAZON,
            DepoKodu.ECZA1,
            DepoKodu.ECZANETAKAS,
            DepoKodu.ECZATREND,
            DepoKodu.DNA
        )
        t_limit = 4.5 if is_marketplace else 6.0
        try:
            try:
                return await asyncio.wait_for(adapter.search_product(query, include_equivalents=False), timeout=t_limit)
            except TypeError:
                return await asyncio.wait_for(adapter.search_product(query), timeout=t_limit)
        except asyncio.TimeoutError:
            print(f"[{adapter.depo_adi}] Arama zaman aşımına uğradı ({t_limit}s)")
            return []
        except Exception as e:
            print(f"[{adapter.depo_adi}] Arama hatası: {e}")
            return []

    async def close_all(self):
        close_tasks = [ad.close() for ad in self.adapters.values()]
        if close_tasks:
            await asyncio.gather(*close_tasks, return_exceptions=True)

    async def add_to_cart(self, depo: str, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """İlgili deponun sepetine ürün ekler."""
        depo_clean = depo.upper().strip()
        matched_adapter = None
        for code, adapter in self.adapters.items():
            if code.value.upper() == depo_clean or code.name.upper() == depo_clean or depo_clean in adapter.depo_adi.upper():
                matched_adapter = adapter
                break

        if not matched_adapter:
            return {
                "success": False,
                "message": f"'{depo}' deposu için aktif veya yetkili bir bağlantı bulunamadı. Lütfen giriş bilgilerini kontrol edin."
            }

        try:
            return await matched_adapter.add_to_cart(urun_id=urun_id, miktar=miktar, **kwargs)
        except Exception as e:
            print(f"[{matched_adapter.depo_adi}] Sepete ekleme hatası: {e}")
            return {
                "success": False,
                "message": f"{matched_adapter.depo_adi} sepete ekleme sırasında hata oluştu: {str(e)}"
            }

    async def bulk_add_to_cart(self, depo: str, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """İlgili deponun sepetine toplu ürün ekler."""
        depo_clean = depo.upper().strip()
        matched_adapter = None
        for code, adapter in self.adapters.items():
            if code.value.upper() == depo_clean or code.name.upper() == depo_clean or depo_clean in adapter.depo_adi.upper():
                matched_adapter = adapter
                break

        if not matched_adapter:
            return {
                "success": False,
                "message": f"'{depo}' deposu için aktif veya yetkili bir bağlantı bulunamadı. Lütfen giriş bilgilerini kontrol edin.",
                "total_items": len(items),
                "success_count": 0,
                "failed_count": len(items),
                "items": []
            }

        try:
            res = await matched_adapter.bulk_add_to_cart(items=items)
            if res and isinstance(res, dict):
                items_res = res.get("items", [])
                missing = []
                for it in items_res:
                    if not it.get("success"):
                        missing.append({
                            "barcode": it.get("barcode"),
                            "name": it.get("name") or it.get("urun_adi"),
                            "miktar": it.get("miktar", 1),
                            "message": it.get("message", "Depoda yok")
                        })
                res["missing_items"] = missing
            return res
        except Exception as e:
            print(f"[{matched_adapter.depo_adi}] Toplu sepete ekleme hatası: {e}")
            return {
                "success": False,
                "message": f"{matched_adapter.depo_adi} toplu sepete ekleme sırasında hata oluştu: {str(e)}",
                "total_items": len(items),
                "success_count": 0,
                "failed_count": len(items),
                "items": [],
                "missing_items": [
                    {
                        "barcode": it.get("barcode") or it.get("barkod"),
                        "name": it.get("name") or it.get("urun_adi"),
                        "miktar": it.get("miktar", 1),
                        "message": str(e)
                    }
                    for it in items
                ]
            }

    async def cascade_bulk_add_to_cart(
        self, 
        start_depo: str = "ALLIANCE", 
        items: List[Dict[str, Any]] = None, 
        cascade_order: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Akıllı Şelale Sepet Dağıtımı:
        Belirtilen ana depodan başlayarak ürünleri ekler. 
        O depoda stokta olmayan / satış şartı bulunmayan ürünleri otomatik olarak
        sıradaki depoya devreder (örn. Alliance -> Selçuk -> İSKOOP -> Nevzat).
        Hiçbir depoda bulunamayan ürünleri ise 'Yok Listesi' olarak derler.
        """
        if not items:
            return {
                "success": False,
                "message": "Gönderilecek ürün listesi boş.",
                "total_requested": 0,
                "total_added": 0,
                "total_yok": 0,
                "depo_breakdown": {},
                "yok_listesi": [],
                "items_trace": []
            }

        start_depo = (start_depo or "ALLIANCE").upper().strip()
        all_supported = ["ALLIANCE", "SELCUK", "ISKOOP", "NEVZAT"]
        
        if not cascade_order:
            ordered_depos = [start_depo] + [d for d in all_supported if d != start_depo]
        else:
            ordered_depos = [d.upper().strip() for d in cascade_order if d.upper().strip() in all_supported]
            for d in all_supported:
                if d not in ordered_depos:
                    ordered_depos.append(d)

        DEPO_NAMES = {
            "ALLIANCE": "Alliance Healthcare",
            "SELCUK": "Selçuk Ecza",
            "ISKOOP": "İSKOOP",
            "NEVZAT": "Nevzat Ecza"
        }

        # İlaç takip haritası
        item_tracker = {}
        for it in items:
            bc = str(it.get("barcode") or it.get("barkod") or "").strip()
            if len(bc) == 14 and bc.startswith("0"):
                bc = bc[1:]
            qty = max(1, int(it.get("miktar") or it.get("quantity") or 1))
            name = str(it.get("name") or it.get("urun_adi") or bc).strip()
            item_tracker[bc] = {
                "barcode": bc,
                "name": name,
                "miktar": qty,
                "status": "PENDING",
                "assigned_depo": None,
                "assigned_depo_name": None,
                "net_fiyat": 0.0,
                "vade": 30,
                "toplam_tutar": 0.0,
                "message": "",
                "history": []
            }

        depo_breakdown = {
            d: {
                "depo_code": d,
                "depo_name": DEPO_NAMES.get(d, d),
                "count": 0,
                "total_amount": 0.0,
                "items": []
            }
            for d in ordered_depos
        }

        remaining_barcodes = list(item_tracker.keys())

        for current_depo in ordered_depos:
            if not remaining_barcodes:
                break

            current_items = [
                {
                    "barcode": bc,
                    "barkod": bc,
                    "name": item_tracker[bc]["name"],
                    "urun_adi": item_tracker[bc]["name"],
                    "miktar": item_tracker[bc]["miktar"]
                }
                for bc in remaining_barcodes
            ]

            print(f"[Şelale Dağıtım] {current_depo} deposuna {len(current_items)} kalem sorgulanıyor...")
            depo_res = await self.bulk_add_to_cart(depo=current_depo, items=current_items)

            successful_in_this_depo = []
            if depo_res.get("success") or depo_res.get("success_count", 0) > 0 or depo_res.get("items"):
                for it_res in depo_res.get("items", []):
                    bc = str(it_res.get("barcode") or "").strip()
                    if not bc or bc not in item_tracker:
                        continue
                    
                    is_ok = bool(it_res.get("success"))
                    msg = str(it_res.get("message") or "")
                    
                    item_tracker[bc]["history"].append({
                        "depo": current_depo,
                        "depo_name": DEPO_NAMES.get(current_depo, current_depo),
                        "success": is_ok,
                        "message": msg
                    })

                    if is_ok:
                        successful_in_this_depo.append(bc)
                        item_tracker[bc]["status"] = "ADDED"
                        item_tracker[bc]["assigned_depo"] = current_depo
                        item_tracker[bc]["assigned_depo_name"] = DEPO_NAMES.get(current_depo, current_depo)
                        net_fiyat = float(it_res.get("net_fiyat") or 0.0)
                        vade = int(it_res.get("vade") or 30)
                        toplam_tutar = float(it_res.get("toplam_tutar") or (net_fiyat * item_tracker[bc]["miktar"]))
                        item_tracker[bc]["net_fiyat"] = net_fiyat
                        item_tracker[bc]["vade"] = vade
                        item_tracker[bc]["toplam_tutar"] = toplam_tutar
                        item_tracker[bc]["message"] = msg or "Sepete eklendi"

                        depo_breakdown[current_depo]["items"].append({
                            "barcode": bc,
                            "name": item_tracker[bc]["name"],
                            "miktar": item_tracker[bc]["miktar"],
                            "net_fiyat": net_fiyat,
                            "vade": vade,
                            "toplam_tutar": toplam_tutar,
                            "message": msg
                        })
                        depo_breakdown[current_depo]["count"] += 1
                        depo_breakdown[current_depo]["total_amount"] += toplam_tutar

            remaining_barcodes = [bc for bc in remaining_barcodes if bc not in successful_in_this_depo]

        # Hiçbir depoda bulunamayanlar: YOK LİSTESİ
        yok_listesi = []
        for bc in remaining_barcodes:
            item_tracker[bc]["status"] = "YOK"
            item_tracker[bc]["message"] = "Hiçbir depoda stok veya satış koşulu bulunamadı."
            yok_listesi.append({
                "barcode": bc,
                "name": item_tracker[bc]["name"],
                "miktar": item_tracker[bc]["miktar"],
                "message": item_tracker[bc]["message"],
                "history": item_tracker[bc]["history"]
            })

        total_added = sum(d["count"] for d in depo_breakdown.values())
        total_requested = len(item_tracker)
        total_yok = len(yok_listesi)

        all_items_trace = list(item_tracker.values())

        return {
            "success": True,
            "cascade": True,
            "start_depo": start_depo,
            "total_requested": total_requested,
            "total_added": total_added,
            "total_yok": total_yok,
            "depo_breakdown": depo_breakdown,
            "yok_listesi": yok_listesi,
            "items_trace": all_items_trace,
            "message": f"Şelale siparişi tamamlandı: {total_added} kalem depolara dağıtıldı, {total_yok} kalem hiçbir depoda bulunamadı."
        }

    def _get_adapter_by_depo(self, depo: str):
        depo_norm = depo.upper().replace("İ", "I").strip()
        for code, adapter in self.adapters.items():
            c_val = code.value.upper().replace("İ", "I")
            c_name = code.name.upper().replace("İ", "I")
            depo_adi_norm = adapter.depo_adi.upper().replace("İ", "I")
            if c_val == depo_norm or c_name == depo_norm or depo_norm in depo_adi_norm or depo_adi_norm in depo_norm:
                return adapter
        return None

    async def get_cart_status(self, depo: str) -> Dict[str, Any]:
        """İlgili deponun sepet durumunu sorgular."""
        adapter = self._get_adapter_by_depo(depo)
        if not adapter:
            return {"success": False, "message": f"'{depo}' deposu için aktif adaptör bulunamadı."}
        try:
            return await adapter.get_cart_status()
        except Exception as e:
            return {"success": False, "message": f"{adapter.depo_adi} sepet sorgulama hatası: {str(e)}"}

    async def clear_cart(self, depo: str) -> Dict[str, Any]:
        """İlgili deponun sepetini temizler."""
        adapter = self._get_adapter_by_depo(depo)
        if not adapter:
            return {"success": False, "message": f"'{depo}' deposu için aktif adaptör bulunamadı."}
        try:
            return await adapter.clear_cart()
        except Exception as e:
            return {"success": False, "message": f"{adapter.depo_adi} sepet temizleme hatası: {str(e)}"}

    async def finalize_order(self, depo: str, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        """İlgili depodaki tekli siparişi sonlandırır (depoya iletir)."""
        adapter = self._get_adapter_by_depo(depo)
        if not adapter:
            return {"success": False, "message": f"'{depo}' deposu için aktif adaptör bulunamadı."}
        try:
            return await adapter.finalize_order(urun_id=urun_id, miktar=miktar, force=force, **kwargs)
        except Exception as e:
            return {"success": False, "message": f"{adapter.depo_adi} sipariş sonlandırma hatası: {str(e)}"}

    async def reload_adapters(self):
        await self.close_all()
        self.adapters.clear()
        self._init_adapters()

