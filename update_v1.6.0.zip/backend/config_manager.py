# -*- coding: utf-8 -*-
"""
backend/config_manager.py
-------------------------
Eczane Depo ve Otomasyon (.env) Giriş Bilgileri & Konfigürasyon Yöneticisi.
"""

import os
from pathlib import Path
from backend.botanik_client import botanik_client

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"


def get_active_otomasyon() -> str:
    """
    Aktif eczane otomasyonunu döner.
    .env içerisinde ACTIVE_OTOMASYON tanımlı değilse:
    1) TRIA_DB_HOST tanımlı ve Botanik config yoksa TRIA,
    2) TEBEOS_DB_HOST tanımlıysa TEBEOS,
    3) Varsayılan olarak BOTANIK döner (Botanik config dosyasından otomatik okunduğu için).
    """
    val = os.environ.get("ACTIVE_OTOMASYON", "").strip().upper()
    if val in ("TRIA", "BOTANIK", "TEBEOS", "ECZANEM"):
        return val
    if os.environ.get("ECZANEM_SERVER", "").strip():
        return "ECZANEM"
    if os.environ.get("TEBEOS_DB_HOST", "").strip():
        return "TEBEOS"
    if os.environ.get("TRIA_DB_HOST", "").strip() and not os.environ.get("BOTANIK_DB_SERVER", "").strip():
        bot_cfg = botanik_client.read_botanik_config_file()
        if not bot_cfg.get("found"):
            return "TRIA"
    return "BOTANIK"


def load_env():
    if ENV_FILE.exists():
        with open(ENV_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    k_clean = k.strip()
                    v_clean = v.strip()
                    if k_clean not in os.environ:
                        os.environ[k_clean] = v_clean
    if "ACTIVE_OTOMASYON" not in os.environ or not os.environ.get("ACTIVE_OTOMASYON", "").strip():
        os.environ["ACTIVE_OTOMASYON"] = get_active_otomasyon()


def get_current_credentials():
    def _is_active(depo: str, has_creds: bool):
        if not has_creds:
            return "0"
        return os.environ.get(f"{depo.upper()}_ACTIVE", "1")

    bot_cfg = botanik_client.get_config()
    return {
        "alliance": {
            "pharmacy_code": os.environ.get("ALLIANCE_PHARMACY_CODE", ""),
            "username": os.environ.get("ALLIANCE_USERNAME", ""),
            "password": os.environ.get("ALLIANCE_PASSWORD", ""),
            "active": _is_active("ALLIANCE", bool(os.environ.get("ALLIANCE_PHARMACY_CODE", "").strip() and os.environ.get("ALLIANCE_USERNAME", "").strip() and os.environ.get("ALLIANCE_PASSWORD", "").strip()))
        },
        "selcuk": {
            "username": os.environ.get("SELCUK_USERNAME", ""),
            "password": os.environ.get("SELCUK_PASSWORD", ""),
            "active": _is_active("SELCUK", bool(os.environ.get("SELCUK_USERNAME", "").strip() and os.environ.get("SELCUK_PASSWORD", "").strip()))
        },
        "nevzat": {
            "account_code": os.environ.get("NEVZAT_ACCOUNT_CODE", ""),
            "username": os.environ.get("NEVZAT_USERNAME", ""),
            "password": os.environ.get("NEVZAT_PASSWORD", ""),
            "active": _is_active("NEVZAT", bool(os.environ.get("NEVZAT_ACCOUNT_CODE", "").strip() and os.environ.get("NEVZAT_USERNAME", "").strip() and os.environ.get("NEVZAT_PASSWORD", "").strip()))
        },
        "iskoop": {
            "username": os.environ.get("ISKOOP_USERNAME", ""),
            "password": os.environ.get("ISKOOP_PASSWORD", ""),
            "active": _is_active("ISKOOP", bool(os.environ.get("ISKOOP_USERNAME", "").strip() and os.environ.get("ISKOOP_PASSWORD", "").strip()))
        },
        "bek": {
            "username": os.environ.get("BEK_USERNAME", ""),
            "password": os.environ.get("BEK_PASSWORD", ""),
            "active": _is_active("BEK", bool(os.environ.get("BEK_USERNAME", "").strip() and os.environ.get("BEK_PASSWORD", "").strip()))
        },
        "ecza1": {
            "username": os.environ.get("ECZA1_USERNAME", ""),
            "password": os.environ.get("ECZA1_PASSWORD", ""),
            "active": _is_active("ECZA1", bool(os.environ.get("ECZA1_USERNAME", "").strip() and os.environ.get("ECZA1_PASSWORD", "").strip()))
        },
        "farmazon": {
            "username": os.environ.get("FARMAZON_USERNAME", ""),
            "password": os.environ.get("FARMAZON_PASSWORD", ""),
            "active": _is_active("FARMAZON", bool(os.environ.get("FARMAZON_USERNAME", "").strip() and os.environ.get("FARMAZON_PASSWORD", "").strip()))
        },
        "dna": {
            "username": os.environ.get("DNA_USERNAME", ""),
            "password": os.environ.get("DNA_PASSWORD", ""),
            "active": _is_active("DNA", bool(os.environ.get("DNA_USERNAME", "").strip() and os.environ.get("DNA_PASSWORD", "").strip()))
        },
        "eczatrend": {
            "username": os.environ.get("ECZATREND_USERNAME", ""),
            "password": os.environ.get("ECZATREND_PASSWORD", ""),
            "active": _is_active("ECZATREND", bool(os.environ.get("ECZATREND_USERNAME", "").strip() and os.environ.get("ECZATREND_PASSWORD", "").strip()))
        },
        "eczanetakas": {
            "username": os.environ.get("ECZANETAKAS_USERNAME", ""),
            "password": os.environ.get("ECZANETAKAS_PASSWORD", ""),
            "active": _is_active("ECZANETAKAS", bool(os.environ.get("ECZANETAKAS_USERNAME", "").strip() and os.environ.get("ECZANETAKAS_PASSWORD", "").strip()))
        },
        "tria": {
            "host": os.environ.get("TRIA_DB_HOST", ""),
            "port": os.environ.get("TRIA_DB_PORT", "1521"),
            "sid": os.environ.get("TRIA_DB_SID", "ORCL"),
            "user": os.environ.get("TRIA_DB_USER", ""),
            "password": os.environ.get("TRIA_DB_PASSWORD", "")
        },
        "botanik": {
            "server": os.environ.get("BOTANIK_DB_SERVER", "") or bot_cfg.get("server", r".\BOTANIKSQL"),
            "database": os.environ.get("BOTANIK_DB_DATABASE", "") or bot_cfg.get("database", "eczane"),
            "user": os.environ.get("BOTANIK_DB_USER", "") or bot_cfg.get("user", "sa"),
            "password": os.environ.get("BOTANIK_DB_PASSWORD", "") or bot_cfg.get("password", "123"),
            "trusted": os.environ.get("BOTANIK_DB_TRUSTED", "false")
        },
        "tebeos": {
            "host": os.environ.get("TEBEOS_DB_HOST", ""),
            "port": str(os.environ.get("TEBEOS_DB_PORT", "5454")),
            "database": os.environ.get("TEBEOS_DB_DATABASE", "tebeos_db"),
            "user": os.environ.get("TEBEOS_DB_USER", "tebeos"),
            "password": os.environ.get("TEBEOS_DB_PASSWORD", "123")
        },
        "eczanem": {
            "server": os.environ.get("ECZANEM_SERVER", ""),
            "port": str(os.environ.get("ECZANEM_PORT", "1433")),
            "database": os.environ.get("ECZANEM_DATABASE", "eczanem"),
            "user": os.environ.get("ECZANEM_USER", "eczanem"),
            "password": os.environ.get("ECZANEM_PASSWORD", "1234")
        },
        "active_otomasyon": os.environ.get("ACTIVE_OTOMASYON", "BOTANIK")
    }


def save_credentials_to_env(new_creds: dict):
    mapping = {
        ("alliance", "pharmacy_code"): "ALLIANCE_PHARMACY_CODE",
        ("alliance", "username"): "ALLIANCE_USERNAME",
        ("alliance", "password"): "ALLIANCE_PASSWORD",
        ("alliance", "active"): "ALLIANCE_ACTIVE",
        ("selcuk", "username"): "SELCUK_USERNAME",
        ("selcuk", "password"): "SELCUK_PASSWORD",
        ("selcuk", "active"): "SELCUK_ACTIVE",
        ("nevzat", "account_code"): "NEVZAT_ACCOUNT_CODE",
        ("nevzat", "username"): "NEVZAT_USERNAME",
        ("nevzat", "password"): "NEVZAT_PASSWORD",
        ("nevzat", "active"): "NEVZAT_ACTIVE",
        ("iskoop", "username"): "ISKOOP_USERNAME",
        ("iskoop", "password"): "ISKOOP_PASSWORD",
        ("iskoop", "active"): "ISKOOP_ACTIVE",
        ("bek", "username"): "BEK_USERNAME",
        ("bek", "password"): "BEK_PASSWORD",
        ("bek", "active"): "BEK_ACTIVE",
        ("ecza1", "username"): "ECZA1_USERNAME",
        ("ecza1", "password"): "ECZA1_PASSWORD",
        ("ecza1", "active"): "ECZA1_ACTIVE",
        ("farmazon", "username"): "FARMAZON_USERNAME",
        ("farmazon", "password"): "FARMAZON_PASSWORD",
        ("farmazon", "active"): "FARMAZON_ACTIVE",
        ("dna", "username"): "DNA_USERNAME",
        ("dna", "password"): "DNA_PASSWORD",
        ("dna", "active"): "DNA_ACTIVE",
        ("eczatrend", "username"): "ECZATREND_USERNAME",
        ("eczatrend", "password"): "ECZATREND_PASSWORD",
        ("eczatrend", "active"): "ECZATREND_ACTIVE",
        ("eczanetakas", "username"): "ECZANETAKAS_USERNAME",
        ("eczanetakas", "password"): "ECZANETAKAS_PASSWORD",
        ("eczanetakas", "active"): "ECZANETAKAS_ACTIVE",
        ("tria", "host"): "TRIA_DB_HOST",
        ("tria", "port"): "TRIA_DB_PORT",
        ("tria", "sid"): "TRIA_DB_SID",
        ("tria", "user"): "TRIA_DB_USER",
        ("tria", "password"): "TRIA_DB_PASSWORD",
        ("botanik", "server"): "BOTANIK_DB_SERVER",
        ("botanik", "database"): "BOTANIK_DB_DATABASE",
        ("botanik", "user"): "BOTANIK_DB_USER",
        ("botanik", "password"): "BOTANIK_DB_PASSWORD",
        ("botanik", "trusted"): "BOTANIK_DB_TRUSTED",
        ("tebeos", "host"): "TEBEOS_DB_HOST",
        ("tebeos", "port"): "TEBEOS_DB_PORT",
        ("tebeos", "database"): "TEBEOS_DB_DATABASE",
        ("tebeos", "user"): "TEBEOS_DB_USER",
        ("tebeos", "password"): "TEBEOS_DB_PASSWORD",
        ("eczanem", "server"): "ECZANEM_SERVER",
        ("eczanem", "port"): "ECZANEM_PORT",
        ("eczanem", "database"): "ECZANEM_DATABASE",
        ("eczanem", "user"): "ECZANEM_USER",
        ("eczanem", "password"): "ECZANEM_PASSWORD",
    }

    flat_updates = {}
    for (depo, field), env_var in mapping.items():
        if depo in new_creds and field in new_creds[depo]:
            val = str(new_creds[depo][field]).strip()
            flat_updates[env_var] = val

    req_checks = {
        "ALLIANCE": ["ALLIANCE_PHARMACY_CODE", "ALLIANCE_USERNAME", "ALLIANCE_PASSWORD"],
        "SELCUK": ["SELCUK_USERNAME", "SELCUK_PASSWORD"],
        "NEVZAT": ["NEVZAT_ACCOUNT_CODE", "NEVZAT_USERNAME", "NEVZAT_PASSWORD"],
        "ISKOOP": ["ISKOOP_USERNAME", "ISKOOP_PASSWORD"],
        "BEK": ["BEK_USERNAME", "BEK_PASSWORD"],
        "ECZA1": ["ECZA1_USERNAME", "ECZA1_PASSWORD"],
        "FARMAZON": ["FARMAZON_USERNAME", "FARMAZON_PASSWORD"],
        "DNA": ["DNA_USERNAME", "DNA_PASSWORD"],
        "ECZATREND": ["ECZATREND_USERNAME", "ECZATREND_PASSWORD"],
        "ECZANETAKAS": ["ECZANETAKAS_USERNAME", "ECZANETAKAS_PASSWORD"],
    }
    for depo_prefix, fields in req_checks.items():
        has_all = all(bool(flat_updates.get(f, os.environ.get(f, "")).strip()) for f in fields)
        if not has_all:
            flat_updates[f"{depo_prefix}_ACTIVE"] = "0"

    if "active_otomasyon" in new_creds:
        flat_updates["ACTIVE_OTOMASYON"] = str(new_creds["active_otomasyon"]).strip()

    lines = []
    if ENV_FILE.exists():
        with open(ENV_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()

    updated_keys = set()
    new_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            k, _ = stripped.split("=", 1)
            k = k.strip()
            if k in flat_updates:
                new_lines.append(f"{k}={flat_updates[k]}\n")
                updated_keys.add(k)
                os.environ[k] = flat_updates[k]
                continue
        new_lines.append(line)

    for k, v in flat_updates.items():
        if k not in updated_keys:
            new_lines.append(f"{k}={v}\n")
            os.environ[k] = v

    with open(ENV_FILE, "w", encoding="utf-8") as f:
        f.writelines(new_lines)
