# -*- coding: utf-8 -*-
import os
import sys
import time
import socket
import shutil
import urllib.request
import subprocess
import webbrowser
from pathlib import Path


def get_base_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def _no_window_kwargs() -> dict:
    if sys.platform != "win32":
        return {}
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = getattr(subprocess, "SW_HIDE", 0)
    return {
        "creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
        "startupinfo": si,
        "stdin": subprocess.DEVNULL,
    }


def find_python(base_dir: str) -> str:
    rt_dir = os.path.join(base_dir, "runtime")
    rt_pyw = os.path.join(rt_dir, "pythonw.exe")
    rt_py = os.path.join(rt_dir, "python.exe")
    rt_tria_pos = os.path.join(rt_dir, "TriaPcPOS.exe")
    rt_tria = os.path.join(rt_dir, "Tria.exe")
    if os.path.isfile(rt_pyw) and not os.path.isfile(rt_tria_pos):
        try:
            shutil.copy2(rt_pyw, rt_tria_pos)
        except Exception:
            pass
    if os.path.isfile(rt_py) and not os.path.isfile(rt_tria):
        try:
            shutil.copy2(rt_py, rt_tria)
        except Exception:
            pass
    candidates = [
        rt_tria_pos,
        rt_pyw,
        rt_tria,
        rt_py,
        os.path.expanduser(r"~\anaconda3\pythonw.exe"),
        r"C:\Users\eczac\anaconda3\pythonw.exe",
        os.path.expanduser(r"~\anaconda3\python.exe"),
        r"C:\Users\eczac\anaconda3\python.exe",
        r"C:\ProgramData\Anaconda3\python.exe",
        "pythonw",
        "python",
    ]
    for c in candidates:
        if c in ("pythonw", "python") or os.path.isfile(c):
            return c
    return "python"


def is_port_open(port: int = 8080, timeout: float = 0.08) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            return s.connect_ex(("127.0.0.1", port)) == 0
    except Exception:
        return False


def is_server_healthy(port: int = 8080, timeout: float = 0.8) -> bool:
    if not is_port_open(port, timeout=0.08):
        return False
    try:
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}/api/version",
            headers={"User-Agent": "FarmaRadarLauncher", "Cache-Control": "no-cache"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False


def kill_port_process(port: int = 8080):
    """Yalnızca port açık ama HTTP yanıt vermiyorsa (asılı kalmış süreç varsa) temizler."""
    try:
        nw = _no_window_kwargs()
        out = subprocess.check_output(
            ["netstat", "-ano", "-p", "tcp"],
            stderr=subprocess.DEVNULL,
            **nw,
        ).decode("latin1", errors="ignore")
        pids = set()
        for line in out.splitlines():
            if f":{port} " in line and "LISTENING" in line.upper():
                parts = line.strip().split()
                if parts:
                    pid = parts[-1]
                    if pid.isdigit() and int(pid) != os.getpid():
                        pids.add(pid)
        for pid in pids:
            subprocess.run(
                ["taskkill", "/F", "/PID", str(pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                **nw,
            )
        if pids:
            for _ in range(15):
                if not is_port_open(port, 0.05):
                    break
                time.sleep(0.05)
    except Exception:
        pass


def open_app_window(target_url: str):
    """Chrome veya Edge uygulama penceresinde (--app) tek pencere olarak açar; yoksa varsayılan tarayıcıyı kullanır."""
    browser_candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    ]
    for b_exe in browser_candidates:
        if b_exe and os.path.isfile(b_exe):
            try:
                subprocess.Popen(
                    [b_exe, f"--app={target_url}", "--window-size=1440,920"],
                    close_fds=True,
                )
                return
            except Exception:
                pass
    try:
        webbrowser.open(target_url)
    except Exception:
        pass


def ensure_startup_splash_html(base_dir: str, port: int = 8080) -> str:
    """
    Sabah ilk açılışta tarayıcının 'Sayfa görüntülenemiyor' hatası vermeden milisaniyeler içinde
    açılmasını sağlayan ve sunucu ayağa kalktığı anda otomatik olarak ana ekrana geçen karşılama ekranı.
    """
    data_dir = os.path.join(base_dir, "data")
    os.makedirs(data_dir, exist_ok=True)
    splash_path = os.path.join(data_dir, "startup_splash.html")
    html = f"""<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Farma Radar Başlatılıyor...</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: radial-gradient(circle at 50% 25%, #1e293b 0%, #0f172a 65%, #020617 100%);
    color: #f8fafc;
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    overflow: hidden;
  }}
  .card {{
    width: 440px;
    max-width: 92vw;
    padding: 36px 32px;
    border-radius: 28px;
    background: rgba(15, 23, 42, 0.82);
    border: 1px solid rgba(56, 189, 248, 0.24);
    box-shadow: 0 25px 60px rgba(0, 0, 0, 0.55), 0 0 40px rgba(14, 165, 233, 0.12);
    text-align: center;
  }}
  .radar-wrap {{
    position: relative;
    width: 76px;
    height: 76px;
    margin: 0 auto 22px;
    display: flex;
    align-items: center;
    justify-content: center;
  }}
  .ring {{
    position: absolute;
    inset: 0;
    border-radius: 999px;
    border: 2.5px solid rgba(16, 185, 129, 0.35);
    animation: pulse 1.6s ease-out infinite;
  }}
  .ring2 {{
    position: absolute;
    inset: -8px;
    border-radius: 999px;
    border: 2px solid rgba(56, 189, 248, 0.22);
    animation: pulse 1.6s ease-out 0.5s infinite;
  }}
  .core {{
    width: 60px;
    height: 60px;
    border-radius: 20px;
    background: linear-gradient(135deg, #10b981 0%, #0284c7 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 900;
    color: #fff;
    box-shadow: 0 10px 25px rgba(16, 185, 129, 0.35);
  }}
  @keyframes pulse {{
    0% {{ transform: scale(0.88); opacity: 0.9; }}
    100% {{ transform: scale(1.38); opacity: 0; }}
  }}
  .badge {{
    display: inline-block;
    padding: 4px 12px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    background: rgba(16, 185, 129, 0.15);
    color: #34d399;
    border: 1px solid rgba(16, 185, 129, 0.3);
    margin-bottom: 12px;
  }}
  h1 {{
    font-size: 22px;
    font-weight: 800;
    letter-spacing: -0.02em;
    color: #ffffff;
    margin-bottom: 8px;
  }}
  p {{
    font-size: 13px;
    color: #94a3b8;
    line-height: 1.5;
    min-height: 20px;
  }}
  .bar-track {{
    margin-top: 22px;
    height: 6px;
    width: 100%;
    border-radius: 999px;
    background: rgba(51, 65, 85, 0.7);
    overflow: hidden;
    position: relative;
  }}
  .bar-fill {{
    position: absolute;
    top: 0;
    bottom: 0;
    width: 42%;
    border-radius: 999px;
    background: linear-gradient(90deg, #10b981, #38bdf8, #10b981);
    animation: slide 1.15s ease-in-out infinite;
  }}
  @keyframes slide {{
    0% {{ left: -42%; }}
    100% {{ left: 100%; }}
  }}
</style>
</head>
<body>
  <div class="card">
    <div class="radar-wrap">
      <div class="ring"></div>
      <div class="ring2"></div>
      <div class="core">FR</div>
    </div>
    <div class="badge">AKILLI DEPO &amp; MF SİSTEMİ</div>
    <h1>Farma Radar Başlatılıyor</h1>
    <p id="statusText">Eczane otomasyonu ve depo servisleri hazırlanıyor...</p>
    <div class="bar-track"><div class="bar-fill"></div></div>
  </div>
  <script>
    const TARGET = "http://localhost:{port}/";
    const HEALTH = "http://127.0.0.1:{port}/api/version";
    let attempts = 0;
    let redirected = false;

    async function checkReady() {{
      if (redirected) return;
      attempts++;
      if (attempts === 6) {{
        document.getElementById("statusText").innerText = "Veritabanı ve depo oturumları bağlanıyor...";
      }} else if (attempts === 16) {{
        document.getElementById("statusText").innerText = "Neredeyse hazır, ekran açılıyor...";
      }}
      try {{
        const ctrl = new AbortController();
        const tid = setTimeout(() => ctrl.abort(), 900);
        await fetch(HEALTH + "?t=" + Date.now(), {{ mode: "no-cors", cache: "no-store", signal: ctrl.signal }});
        clearTimeout(tid);
        redirected = true;
        document.getElementById("statusText").innerText = "Bağlantı hazır! Açılıyor...";
        window.location.replace(TARGET);
        return;
      }} catch (e) {{}}
      setTimeout(checkReady, 220);
    }}
    checkReady();
  </script>
</body>
</html>"""
    try:
        with open(splash_path, "w", encoding="utf-8") as f:
            f.write(html)
    except Exception:
        pass
    return Path(splash_path).resolve().as_uri()


def main():
    base_dir = get_base_dir()
    os.chdir(base_dir)

    server_script = os.path.join(base_dir, "server.py")
    if not os.path.isfile(server_script):
        parent = os.path.dirname(base_dir)
        if os.path.isfile(os.path.join(parent, "server.py")):
            base_dir = parent
            server_script = os.path.join(base_dir, "server.py")
            os.chdir(base_dir)

    # 1. Sunucu zaten ayaktaysa milisaniyeler içinde doğrudan aç ve çık
    if is_server_healthy(8080, timeout=0.6):
        open_app_window("http://localhost:8080")
        sys.exit(0)

    # 2. Yalnızca port 8080 meşgul ama yanıt vermiyorsa asılı kalan eski süreci temizle
    if is_port_open(8080, timeout=0.08):
        kill_port_process(8080)

    py_exe = find_python(base_dir)

    # 3. Açılışı hiç bekletmeden doğrudan server.py'yi (--no-browser ve TRIA_EXE_REEXEC=1 ile tek süreçte) başlat
    creationflags = 0
    if sys.platform == "win32":
        creationflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)

    env = os.environ.copy()
    env["NO_AUTO_BROWSER"] = "1"
    env["TRIA_EXE_REEXEC"] = "1"

    subprocess.Popen(
        [py_exe, server_script, "--no-browser"],
        cwd=base_dir,
        env=env,
        creationflags=creationflags,
        close_fds=True,
    )

    # Çok hızlı disklerde 0.35 sn içinde ayağa kalktıysa direkt localhost aç; değilse anında şık karşılama ekranını aç
    for _ in range(3):
        time.sleep(0.12)
        if is_server_healthy(8080, timeout=0.3):
            open_app_window("http://localhost:8080")
            sys.exit(0)

    splash_uri = ensure_startup_splash_html(base_dir, 8080)
    open_app_window(splash_uri)

    # Arka plan emniyet ağı: Tarayıcı anında açıldıktan sonra sunucunun ayağa kalkmasını sessizce doğrula;
    # olağandışı bir başlangıç hatası olursa (sunucu 7 sn içinde açılmazsa) buluttan onarım güncellemesi çekip tekrar başlat.
    for _ in range(28):
        time.sleep(0.25)
        if is_server_healthy(8080, timeout=0.4):
            sys.exit(0)

    try:
        heal_code = (
            "import sys; "
            f"sys.path = [r'{base_dir}'] + [p for p in sys.path if 'eczanedepopro' not in p.lower() or 'site-packages' in p.lower() or 'runtime' in p.lower()]; "
            "from backend.updater import updater; "
            "chk = updater.check_for_updates(timeout=6.0); "
            "if chk.get('download_url'): "
            "    updater.apply_update(chk['download_url'], chk.get('sha256', ''), chk.get('latest_version', ''))"
        )
        subprocess.run(
            [py_exe, "-c", heal_code],
            cwd=base_dir,
            timeout=15.0,
            **_no_window_kwargs(),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        subprocess.Popen(
            [py_exe, server_script, "--no-browser"],
            cwd=base_dir,
            env=env,
            creationflags=creationflags,
            close_fds=True,
        )
    except Exception:
        pass
    sys.exit(0)


if __name__ == "__main__":
    main()
