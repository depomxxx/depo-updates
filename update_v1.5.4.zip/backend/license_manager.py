# -*- coding: utf-8 -*-
"""
backend/license_manager.py
--------------------------
Farma Radar - Ticari Lisanslama, Üye Eczacı Kayıt ve Bulut (Online) Abonelik Doğrulama Motoru.

MİMARİ (Çift Katmanlı Güvenlik + Uzaktan Bulut Kontrolü):
1. Kriptografik İmzalı Lisans Anahtarı (Offline + Online):
   - Lisans anahtarı; Eczane Adı, Eczacı Adı Soyadı, Telefon, GLN, Bitiş Tarihi (YYYY-MM-DD),
     PC Limiti ve Donanım Kimliği (HWID) bilgilerini HMAC-SHA256 imzası ile barındırır.
   - Hem FR-... hem EDP-... önekli anahtarları destekler.
2. Uzaktan Online Lisans Kontrolü (GitHub / Merkezi Sunucu Senkronizasyonu):
   - Yönetici (Admin) CRM panelinden (license_admin_tool.py) bir eczanenin süresini uzattığında,
     durumunu ASKIDA (Pasif) veya AKTİF yaptığında ya da HWID tanımladığında `licenses_cloud.json`
     otomatik olarak GitHub Canlı Portalına yüklenir.
   - Eczanedeki Farma Radar istemcisi periyodik olarak ve açılışta bu imzalı bulut listesini
     kontrol eder; yeni anahtar kopyalamaya gerek kalmadan süreyi otomatik uzatır veya
     askıya alınan/süresi biten eczanenin erişimini anında kısıtlar.
"""

import os
import sys
import json
import time
import hmac
import base64
import hashlib
import socket
import uuid
import datetime
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, Tuple

# Sadece geliştirici (Admin) lisans üreticide tam karşılığı bulunan doğrulama anahtarı
_MASTER_VERIFY_SALT = b"EczaneDepoPro_Commercial_v1_MasterKey_2026_!#987"


def _normalize_tr(text: str) -> str:
    """Türkçe karakter duyarsız büyük harf normalizasyonu (eşleştirme için)."""
    if not text:
        return ""
    tr_map = str.maketrans({
        "ç": "C", "Ç": "C",
        "ğ": "G", "Ğ": "G",
        "ı": "I", "I": "I", "i": "I", "İ": "I",
        "ö": "O", "Ö": "O",
        "ş": "S", "Ş": "S",
        "ü": "U", "Ü": "U",
    })
    cleaned = text.translate(tr_map).upper()
    return " ".join(cleaned.split())


class LicenseManager:
    def __init__(self, base_dir: Optional[str] = None):
        if base_dir:
            self.base_dir = base_dir
        else:
            if getattr(sys, "frozen", False):
                self.base_dir = os.path.dirname(os.path.abspath(sys.executable))
            else:
                self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        self.license_file = os.path.join(self.base_dir, "license.json")
        self.version_file = os.path.join(self.base_dir, "version.json")
        self._last_cloud_sync_ts: float = 0.0
        self._cloud_cache_ttl: float = 25.0  # 25 saniyede bir sıfır-önbellekli otomatik kontrol
        self._cached_status: Optional[Dict[str, Any]] = None
        self._cached_status_ts: float = 0.0

    def get_hardware_id(self) -> str:
        """Bu bilgisayarın benzersiz donanım kimliğini (HWID) üretir (XXXX-XXXX-XXXX)."""
        raw_id = ""
        if sys.platform == "win32":
            try:
                import subprocess
                out = subprocess.check_output(
                    "wmic csproduct get uuid",
                    shell=True,
                    stderr=subprocess.DEVNULL
                ).decode("utf-8", errors="ignore")
                lines = [ln.strip() for ln in out.splitlines() if ln.strip() and "UUID" not in ln.upper()]
                if lines:
                    raw_id = lines[0]
            except Exception:
                pass
        if not raw_id:
            raw_id = f"{socket.gethostname()}-{uuid.getnode()}"
        digest = hashlib.sha256(raw_id.encode("utf-8")).hexdigest().upper()
        return f"{digest[0:4]}-{digest[4:8]}-{digest[8:12]}"

    @staticmethod
    def generate_license_key(
        pharmacy_name: str,
        gln_no: str = "",
        expires_at: str = "2027-12-31",
        max_pcs: int = 10,
        hwid_lock: str = "ANY",
        plan: str = "PRO_YILLIK",
        pharmacist_name: str = "",
        phone: str = "",
        city: str = "",
        prefix: str = "FR"
    ) -> str:
        """
        Yönetici (Admin) için kriptografik imzalı lisans anahtarı üretir.
        Format: FR-<BASE64URL_PAYLOAD>.<HMAC_IMZA_16> (veya EDP-...)
        """
        clean_exp = expires_at.strip().replace("/", "-")
        payload_dict = {
            "e": pharmacy_name.strip().upper()[:40],
            "fn": pharmacist_name.strip()[:40],
            "tel": phone.strip()[:20],
            "ct": city.strip().upper()[:25],
            "g": gln_no.strip()[:20],
            "x": clean_exp,
            "m": int(max_pcs),
            "h": (hwid_lock or "ANY").strip().upper(),
            "p": plan.strip().upper(),
        }
        payload_json = json.dumps(payload_dict, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        b64_payload = base64.urlsafe_b64encode(payload_json).decode("ascii").rstrip("=")
        sig = hmac.new(_MASTER_VERIFY_SALT, b64_payload.encode("ascii"), hashlib.sha256).hexdigest().upper()[:16]
        pfx = (prefix or "FR").strip().upper().rstrip("-")
        return f"{pfx}-{b64_payload}.{sig}"

    @staticmethod
    def sign_cloud_registry(records: list, updated_at: str) -> str:
        """Bulut lisans listesinin (licenses_cloud.json) bütünlük imzasını üretir."""
        canonical = json.dumps(
            {"updated_at": updated_at, "count": len(records), "items": records},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":")
        ).encode("utf-8")
        return hmac.new(_MASTER_VERIFY_SALT, canonical, hashlib.sha256).hexdigest().upper()[:32]

    def verify_license_key(self, key_str: str) -> Dict[str, Any]:
        """Verilen lisans anahtarının kriptografik imzasını, donanım kilidini ve süresini doğrular."""
        clean_key = (key_str or "").strip()
        if not (clean_key.startswith("FR-") or clean_key.startswith("EDP-")) or "." not in clean_key:
            return {"valid": False, "message": "Geçersiz lisans anahtarı formatı (FR-... veya EDP-... ile başlamalıdır)."}

        try:
            body_part = clean_key.split("-", 1)[1]
            b64_payload, given_sig = body_part.rsplit(".", 1)
            expected_sig = hmac.new(
                _MASTER_VERIFY_SALT,
                b64_payload.encode("ascii"),
                hashlib.sha256
            ).hexdigest().upper()[:16]

            if not hmac.compare_digest(given_sig.upper(), expected_sig):
                return {"valid": False, "message": "Lisans imzası geçersiz veya değiştirilmiş!"}

            pad = "=" * ((4 - len(b64_payload) % 4) % 4)
            payload_bytes = base64.urlsafe_b64decode((b64_payload + pad).encode("ascii"))
            data = json.loads(payload_bytes.decode("utf-8"))

            pharmacy_name = data.get("e", "ECZANE")
            pharmacist_name = data.get("fn", "")
            phone = data.get("tel", "")
            city = data.get("ct", "")
            gln_no = data.get("g", "")
            expires_at = data.get("x", "2027-12-31")
            max_pcs = int(data.get("m", 10))
            hwid_lock = data.get("h", "ANY")
            plan = data.get("p", "PRO_YILLIK")

            my_hwid = self.get_hardware_id()
            if hwid_lock and hwid_lock != "ANY" and hwid_lock != my_hwid:
                return {
                    "valid": False,
                    "unactivated": True,
                    "restricted": True,
                    "hwid_mismatch": True,
                    "status": "HWID_UYUMSUZ",
                    "pharmacy_name": pharmacy_name,
                    "my_hwid": my_hwid,
                    "hwid_lock": hwid_lock,
                    "message": f"Bu lisans başka bir bilgisayara ({hwid_lock}) tanımlanmış. Bu PC HWID: {my_hwid}"
                }

            exp_date = datetime.date.fromisoformat(expires_at[:10])
            today = datetime.date.today()
            days_left = (exp_date - today).days

            if days_left < 0:
                return {
                    "valid": False,
                    "unactivated": False,
                    "restricted": True,
                    "expired": True,
                    "suspended": False,
                    "status": "SURESI_DOLDU",
                    "pharmacy_name": pharmacy_name,
                    "pharmacist_name": pharmacist_name,
                    "phone": phone,
                    "city": city,
                    "gln_no": gln_no,
                    "expires_at": expires_at,
                    "days_left": days_left,
                    "max_pcs": max_pcs,
                    "hwid_lock": hwid_lock,
                    "my_hwid": my_hwid,
                    "plan": plan,
                    "license_key": clean_key,
                    "message": (
                        f"Lisans süreniz {expires_at} tarihinde dolmuştur ({abs(days_left)} gün geçti). "
                        f"Depo Sorgulama, Sepete Ekleme, Toplu Sipariş ve MF Asistanı özellikleri kısıtlanmıştır."
                    )
                }

            return {
                "valid": True,
                "unactivated": False,
                "restricted": False,
                "expired": False,
                "suspended": False,
                "expiring_soon": (0 <= days_left <= 15),
                "status": "AKTIF",
                "pharmacy_name": pharmacy_name,
                "pharmacist_name": pharmacist_name,
                "phone": phone,
                "city": city,
                "gln_no": gln_no,
                "expires_at": expires_at,
                "days_left": days_left,
                "max_pcs": max_pcs,
                "hwid_lock": hwid_lock,
                "my_hwid": my_hwid,
                "plan": plan,
                "license_key": clean_key,
                "message": f"Lisans Aktif ({pharmacy_name} - Kalan Süre: {days_left} gün)"
            }
        except Exception as e:
            return {
                "valid": False,
                "unactivated": True,
                "restricted": True,
                "status": "GECERSIZ_ANAHTAR",
                "message": f"Lisans anahtarı çözümlenemedi: {str(e)}"
            }

    def _get_local_cloud_registry_files(self) -> list:
        """Yerel diskte (Admin CRM veya Releases klasörlerinde) bulunan imzalı licenses_cloud.json dosyalarını döndürür."""
        candidates = [
            os.path.join(self.base_dir, "releases", "licenses_cloud.json"),
            os.path.join(self.base_dir, "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "releases", "licenses_cloud.json"),
            os.path.join(os.path.dirname(self.base_dir), "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "releases", "licenses_cloud.json"),
            r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases\licenses_cloud.json",
            r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases\licenses_cloud.json",
            r"C:\EczaneDepoPro\releases\licenses_cloud.json",
        ]
        out = []
        for c in candidates:
            if c and os.path.isfile(c) and c not in out:
                out.append(c)
        return out

    def _get_cloud_registry_urls(self) -> list:
        """Bulut lisans manifestosu (`licenses_cloud.json`) için kontrol edilecek URL listesini (Sıfır-Önbellekli) döndürür."""
        urls = []
        ts = int(time.time() * 1000)

        # 1. Yerel ağda (veya aynı bilgisayarda) Admin CRM (Port 8095) açıksa doğrudan oradan kontrol et
        urls.append(f"http://127.0.0.1:8095/api/cloud-registry?t={ts}")

        # 2. Sıfır-Önbellekli (Zero-Cache) GitHub REST API (CDN gecikmesini tamamen bypass eder)
        gh_api_url = f"https://api.github.com/repos/depomxxx/depo-updates/contents/licenses_cloud.json?ref=main&t={ts}"
        urls.append(gh_api_url)

        # 3. version.json içindeki özel/LAN manifest sunucusu
        try:
            if os.path.isfile(self.version_file):
                with open(self.version_file, "r", encoding="utf-8") as f:
                    vdata = json.load(f)
                m_url = str(vdata.get("manifest_url") or "").strip()
                if m_url.startswith("http") and "/" in m_url:
                    base_u = m_url.rsplit("/", 1)[0]
                    cand_u = f"{base_u}/licenses_cloud.json?t={ts}"
                    if cand_u not in urls:
                        urls.append(cand_u)
        except Exception:
            pass

        # 4. Yedek GitHub Raw URL
        default_gh = f"https://raw.githubusercontent.com/depomxxx/depo-updates/main/licenses_cloud.json?t={ts}"
        if default_gh not in urls:
            urls.append(default_gh)

        return urls

    def _validate_registry_dict(self, parsed: Any) -> bool:
        if not isinstance(parsed, dict) or not isinstance(parsed.get("items"), list):
            return False
        given_sig = parsed.get("signature", "")
        if given_sig:
            exp_sig = self.sign_cloud_registry(parsed["items"], parsed.get("updated_at", ""))
            if not hmac.compare_digest(given_sig.upper(), exp_sig):
                return False
        return True

    def _fetch_latest_cloud_registry(self, timeout: float = 3.5) -> Tuple[Optional[dict], str]:
        """Hem yerel CRM/Releases dosyalarını hem de Sıfır-Önbellekli GitHub API / CRM sunucusunu tarayıp en güncel kaydı seçer."""
        best_data = None
        best_source = ""
        best_updated_at = ""

        # A) Önce yerel diskteki imzalı licenses_cloud.json dosyalarını kontrol et (0ms gecikme)
        for fpath in self._get_local_cloud_registry_files():
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    parsed = json.load(f)
                if self._validate_registry_dict(parsed):
                    upd = str(parsed.get("updated_at") or "")
                    if best_data is None or upd >= best_updated_at:
                        best_data = parsed
                        best_updated_at = upd
                        best_source = f"local:{fpath}"
            except Exception:
                continue

        # B) HTTP / GitHub API kaynaklarını kontrol et
        for url in self._get_cloud_registry_urls():
            try:
                is_local_crm = "127.0.0.1:8095" in url
                req_timeout = 0.8 if is_local_crm else timeout
                headers = {
                    "User-Agent": "FarmaRadar-LicenseClient/1.5",
                    "Cache-Control": "no-cache, no-store, must-revalidate",
                    "Pragma": "no-cache",
                }
                if "api.github.com/" in url:
                    headers["Accept"] = "application/vnd.github.raw+json"
                    headers["X-GitHub-Api-Version"] = "2022-11-28"

                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=req_timeout) as resp:
                    if resp.status == 200:
                        raw = resp.read().decode("utf-8", errors="replace")
                        parsed = json.loads(raw)
                        # Eğer GitHub API base64 JSON döndürdüyse çözümle
                        if isinstance(parsed, dict) and parsed.get("encoding") == "base64" and parsed.get("content"):
                            dec = base64.b64decode(parsed["content"]).decode("utf-8", errors="replace")
                            parsed = json.loads(dec)
                        if self._validate_registry_dict(parsed):
                            upd = str(parsed.get("updated_at") or "")
                            if best_data is None or upd >= best_updated_at:
                                best_data = parsed
                                best_updated_at = upd
                                best_source = url
                            # Canlı CRM (8095) veya GitHub API'den güncel yanıt alındıysa yeterli
                            if is_local_crm or "api.github.com/" in url:
                                break
            except Exception:
                continue

        return best_data, best_source

    def _read_saved_license_file(self) -> dict:
        if os.path.isfile(self.license_file):
            try:
                with open(self.license_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _write_saved_license_file(self, data: dict):
        try:
            with open(self.license_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self._cached_status = None
        except Exception:
            pass

    def sync_with_cloud(self, force: bool = False, timeout: float = 3.5) -> Dict[str, Any]:
        """
        Merkezi GitHub / Admin CRM bulut kayıt defterinden (`licenses_cloud.json`)
        bu eczanenin lisans durumunu sorgular:
        - Süresi uzatılmışsa veya kısaltılmışsa yeni anahtarı ve tarihi otomatik indirip kaydeder.
        - Yönetici tarafından ASKIDA / KISITLI (Pasif) yapılmışsa veya CRM'den silinmişse özellikleri kısıtlar.
        - Tekrar AKTİF yapılmışsa kısıtlamayı otomatik kaldırır.
        """
        now_ts = time.time()
        if not force and (now_ts - self._last_cloud_sync_ts) < self._cloud_cache_ttl:
            return {"synced": False, "cached": True}

        self._last_cloud_sync_ts = now_ts
        self._cached_status = None
        saved = self._read_saved_license_file()
        if not saved or not (saved.get("license_key") or "").strip():
            return {"synced": False, "unactivated": True}

        my_hwid = self.get_hardware_id()
        my_key = (saved.get("license_key") or "").strip()
        my_name_norm = _normalize_tr(saved.get("pharmacy_name") or "")
        my_gln = (saved.get("gln_no") or "").strip()
        my_crm_id = (saved.get("crm_id") or "").strip()

        cloud_data, source_url = self._fetch_latest_cloud_registry(timeout=timeout)
        if not cloud_data:
            return {"synced": False, "message": "Bulut lisans sunucusuna ulaşılamadı (Çevrimdışı mod)."}

        items = cloud_data.get("items") or []
        matched_record = None

        # 1. Öncelik: CRM ID veya birebir Lisans Anahtarı veya Donanım Kilidi (HWID) eşleşmesi
        for item in items:
            it_id = (item.get("id") or "").strip()
            it_key = (item.get("license_key") or "").strip()
            it_hwid = (item.get("hwid_lock") or "ANY").strip().upper()
            if my_crm_id and it_id and my_crm_id == it_id:
                matched_record = item
                break
            if my_key and it_key and my_key == it_key:
                matched_record = item
                break
            if it_hwid and it_hwid != "ANY" and it_hwid == my_hwid:
                matched_record = item
                break

        # 2. Öncelik: Eczane Adı (veya Eczane Adı + GLN) eşleşmesi
        if not matched_record:
            for item in items:
                it_name_norm = _normalize_tr(item.get("pharmacy_name") or "")
                if my_name_norm and it_name_norm and my_name_norm == it_name_norm:
                    matched_record = item
                    break
            if not matched_record and my_gln:
                for item in items:
                    it_gln = (item.get("gln_no") or "").strip()
                    if it_gln and my_gln == it_gln:
                        matched_record = item
                        break

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if not matched_record:
            # Eğer bu eczane daha önce CRM'de kayıtlıydı (crm_id varsa) ve yönetici CRM'den kaydı sildiyse:
            if my_crm_id and len(items) > 0:
                saved["remote_status"] = "ASKIDA"
                saved["remote_checked_at"] = now_str
                self._write_saved_license_file(saved)
                return {
                    "synced": True,
                    "matched": False,
                    "deleted_from_crm": True,
                    "remote_status": "ASKIDA",
                    "source": source_url
                }
            return {"synced": True, "matched": False, "source": source_url}

        # Eşleşen kayıt bulundu! Şimdi durumu (AKTIF / ASKIDA / KISITLI) ve yeni lisans anahtarını uygula
        remote_status = (matched_record.get("status") or "AKTIF").strip().upper()
        remote_key = (matched_record.get("license_key") or "").strip()
        remote_exp = (matched_record.get("expires_at") or "").strip()[:10]

        if remote_key and (remote_key != my_key or saved.get("expires_at") != remote_exp):
            # Yönetici süreyi uzatmış, kısaltmış veya bilgileri güncellemiş; yeni anahtarı doğrula ve kaydet
            v_res = self.verify_license_key(remote_key)
            if v_res.get("pharmacy_name"):
                saved["license_key"] = remote_key
                saved["pharmacy_name"] = v_res.get("pharmacy_name", matched_record.get("pharmacy_name", ""))
                saved["expires_at"] = v_res.get("expires_at", remote_exp)
                saved["max_pcs"] = v_res.get("max_pcs", matched_record.get("max_pcs", 15))
                saved["hwid_lock"] = v_res.get("hwid_lock", matched_record.get("hwid_lock", "ANY"))
                saved["plan"] = v_res.get("plan", matched_record.get("plan", "PRO_YILLIK"))
            elif remote_exp:
                saved["expires_at"] = remote_exp

        saved["crm_id"] = matched_record.get("id", saved.get("crm_id", ""))
        saved["remote_status"] = remote_status
        saved["remote_checked_at"] = now_str
        saved["my_hwid"] = my_hwid
        self._write_saved_license_file(saved)

        return {
            "synced": True,
            "matched": True,
            "remote_status": remote_status,
            "expires_at": saved.get("expires_at", remote_exp),
            "pharmacy_name": saved.get("pharmacy_name", matched_record.get("pharmacy_name", "")),
            "checked_at": now_str,
            "source": source_url
        }

    def ensure_default_license(self, force_cloud: bool = False) -> Dict[str, Any]:
        """
        Kurulu sistemde license.json varsa doğrular ve bulut ile senkronize eder.
        İlk kurulumda (anahtar girilmemişse) otomatik sahte lisans ÜRETMEZ;
        doğrudan Lisans Anahtarı (FR-...) ister (unactivated=True).
        """
        my_hwid = self.get_hardware_id()

        # Önce bulut senkronizasyonunu çalıştır (25 sn önbellekli veya force_cloud=True ise anında)
        try:
            self.sync_with_cloud(force=force_cloud)
        except Exception:
            pass

        if os.path.isfile(self.license_file):
            try:
                saved = self._read_saved_license_file()
                key = (saved.get("license_key") or "").strip()
                saved_pname = _normalize_tr(saved.get("pharmacy_name") or "")

                # Eski sürümlerden kalma sahte/varsayılan "FARMA RADAR ECZANESİ" anahtarı varsa ve CRM'de yoksa geçersiz say
                if key and saved_pname == _normalize_tr("FARMA RADAR ECZANESİ") and not saved.get("crm_id"):
                    return {
                        "valid": False,
                        "unactivated": True,
                        "restricted": True,
                        "expired": False,
                        "suspended": False,
                        "status": "ANAHTAR_BEKLENIYOR",
                        "pharmacy_name": "Yeni Kurulum — Lisans Bekleniyor",
                        "my_hwid": my_hwid,
                        "message": "Programı kullanabilmek için lütfen Farma Radar Kurumsal Lisans Anahtarınızı (FR-... veya EDP-...) giriniz."
                    }

                if key:
                    res = self.verify_license_key(key)
                    res["activated_at"] = saved.get("activated_at", "")
                    res["remote_checked_at"] = saved.get("remote_checked_at", "")
                    res["crm_id"] = saved.get("crm_id", "")
                    if saved.get("pharmacist_name"):
                        res["pharmacist_name"] = saved["pharmacist_name"]
                    if saved.get("phone"):
                        res["phone"] = saved["phone"]
                    if saved.get("city"):
                        res["city"] = saved["city"]

                    # CRM'de bitiş tarihi güncellenmişse (anahtar yenilenmeden tarih çekildiyse) onu da kontrol et
                    saved_exp = str(saved.get("expires_at") or "").strip()[:10]
                    if saved_exp and saved_exp != res.get("expires_at"):
                        try:
                            exp_d = datetime.date.fromisoformat(saved_exp)
                            d_left = (exp_d - datetime.date.today()).days
                            res["expires_at"] = saved_exp
                            res["days_left"] = d_left
                            if d_left < 0:
                                res["valid"] = False
                                res["unactivated"] = False
                                res["restricted"] = True
                                res["expired"] = True
                                res["status"] = "SURESI_DOLDU"
                                res["message"] = (
                                    f"Lisans süreniz {saved_exp} tarihinde dolmuştur ({abs(d_left)} gün geçti). "
                                    f"Depo Sorgulama, Sepete Ekleme, Toplu Sipariş ve MF Asistanı özellikleri kısıtlanmıştır."
                                )
                        except Exception:
                            pass

                    # Uzaktan yönetici tarafından ASKIDA / KISITLI / PASIF yapıldıysa özellikleri kısıtla!
                    remote_st = (saved.get("remote_status") or "AKTIF").strip().upper()
                    if remote_st in ("ASKIDA", "KISITLI", "PASIF"):
                        res["valid"] = False
                        res["unactivated"] = False
                        res["restricted"] = True
                        res["suspended"] = True
                        res["status"] = "ASKIDA"
                        res["message"] = (
                            f"Lisansınız ({res.get('pharmacy_name', 'Eczane')}) yönetici tarafından kısıtlanmıştır (ASKIDA). "
                            f"Depo Sorgulama, Sepete Ekleme, Toplu Sipariş ve MF Asistanı özellikleri kapatılmıştır."
                        )
                    return res
            except Exception:
                pass

        # İlk kurulum: Henüz hiçbir lisans anahtarı girilmemiş -> Program açılmaz, doğrudan anahtar ister!
        return {
            "valid": False,
            "unactivated": True,
            "restricted": True,
            "expired": False,
            "suspended": False,
            "status": "ANAHTAR_BEKLENIYOR",
            "pharmacy_name": "Yeni Kurulum — Lisans Anahtarı Gerekli",
            "expires_at": "-",
            "days_left": 0,
            "my_hwid": my_hwid,
            "license_key": "",
            "message": "Hoş geldiniz! Farma Radar sistemini başlatmak için lütfen yöneticinizden aldığınız Lisans Anahtarını (FR-... veya EDP-...) giriniz."
        }

    def activate_license(
        self,
        key_str: str,
        pharmacist_name: str = "",
        phone: str = "",
        city: str = ""
    ) -> Dict[str, Any]:
        """Lisans anahtarını doğrular ve üye eczacı iletişim bilgileriyle birlikte license.json'a kaydeder."""
        check = self.verify_license_key(key_str)
        # İmza geçersizse veya HWID uyumsuzsa hemen reddet
        if not check.get("pharmacy_name") or check.get("hwid_mismatch"):
            return check

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        final_pharmacist = pharmacist_name.strip() or check.get("pharmacist_name", "")
        final_phone = phone.strip() or check.get("phone", "")
        final_city = city.strip() or check.get("city", "")
        prev_saved = self._read_saved_license_file()

        save_data = {
            "license_key": key_str.strip(),
            "pharmacy_name": check["pharmacy_name"],
            "pharmacist_name": final_pharmacist,
            "phone": final_phone,
            "city": final_city,
            "gln_no": check.get("gln_no", ""),
            "expires_at": check["expires_at"],
            "max_pcs": check.get("max_pcs", 10),
            "hwid_lock": check.get("hwid_lock", "ANY"),
            "plan": check.get("plan", "PRO_YILLIK"),
            "remote_status": "AKTIF",
            "crm_id": prev_saved.get("crm_id", ""),
            "activated_at": now_str,
            "my_hwid": self.get_hardware_id(),
            "pc_name": socket.gethostname()
        }
        try:
            self._write_saved_license_file(save_data)
            # Yeni anahtar girildiğinde bulut durumuyla anında senkronize et (eski anahtarla bypass yapılmasını önler)
            self.sync_with_cloud(force=True)
            final_status = self.get_status(force_cloud=False)
            return final_status
        except Exception as e:
            return {"valid": False, "unactivated": True, "restricted": True, "message": f"Lisans dosyası kaydedilemedi: {str(e)}"}

    def get_status(self, force_cloud: bool = False) -> Dict[str, Any]:
        """Mevcut lisans durumunu (bulut doğrulaması dahil) ve bu bilgisayarın HWID bilgisini döndürür."""
        now_ts = time.time()
        if not force_cloud and self._cached_status is not None and (now_ts - self._cached_status_ts) < 5.0:
            return self._cached_status

        info = self.ensure_default_license(force_cloud=force_cloud)
        info["my_hwid"] = self.get_hardware_id()
        info["pc_name"] = socket.gethostname()
        self._cached_status = info
        self._cached_status_ts = now_ts
        return info

    def is_feature_allowed(self) -> Tuple[bool, Dict[str, Any]]:
        """Korumalı özelliklerin (Depo Sorgu, Sepete Ekleme, Toplu Sipariş, MF Asistanı) çalışmasına izin verilip verilmediğini döndürür."""
        st = self.get_status(force_cloud=False)
        return bool(st.get("valid", False)), st


license_manager = LicenseManager()
