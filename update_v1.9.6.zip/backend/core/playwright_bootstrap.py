# -*- coding: utf-8 -*-
"""
backend/core/playwright_bootstrap.py
------------------------------------
Yeni kurulan bilgisayarlarda '%LOCALAPPDATA%\\ms-playwright' indirili olmasa bile
Playwright tabanlı tüm depo adaptörlerinin (Selçuk, Alliance, Nevzat, İSKOOP, BEK,
Ecza1, Farmazon ve Piyasa Motoru) bilgisayarda kurulu Google Chrome veya Microsoft Edge
üzerinden sıfır indirme beklemesiyle anında çalışmasını sağlar.
"""

import os
import sys
import subprocess
from typing import Optional

_PATCHED = False
_CACHED_SYSTEM_BROWSER: Optional[str] = None


def find_system_chromium_executable() -> Optional[str]:
    """Windows üzerinde kurulu Google Chrome veya Microsoft Edge çalıştırılabilir dosyasını bulur."""
    global _CACHED_SYSTEM_BROWSER
    if _CACHED_SYSTEM_BROWSER and os.path.isfile(_CACHED_SYSTEM_BROWSER):
        return _CACHED_SYSTEM_BROWSER

    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
    ]
    for path in candidates:
        if path and os.path.isfile(path):
            _CACHED_SYSTEM_BROWSER = path
            return path

    if sys.platform == "win32":
        try:
            import winreg
            for subkey in (
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe",
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe",
            ):
                for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                    try:
                        with winreg.OpenKey(hive, subkey) as k:
                            val, _ = winreg.QueryValueEx(k, "")
                            if val and os.path.isfile(val):
                                _CACHED_SYSTEM_BROWSER = val
                                return val
                    except OSError:
                        pass
        except Exception:
            pass

    return None


def install_playwright_resilient_launcher():
    """
    Playwright Async & Sync BrowserType.launch metodunu sarmalayarak:
    1) Gömülü/indirili ms-playwright chromium varsa onu kullanır.
    2) Yoksa (yeni kurulum yapılan bilgisayarlarda) sistemdeki Chrome veya Edge'i anında devreye sokar.
    3) Hiçbiri yoksa tek seferlik 'playwright install chromium' indirip tekrar dener.
    """
    global _PATCHED
    if _PATCHED:
        return
    _PATCHED = True

    try:
        from playwright.async_api._generated import BrowserType as AsyncBrowserType
        orig_async_launch = AsyncBrowserType.launch

        async def _resilient_async_launch(self, *args, **kwargs):
            # Eğer çağıran zaten özel executable_path veya channel verdiyse dokunma
            if not kwargs.get("executable_path") and not kwargs.get("channel"):
                try:
                    default_exe = self.executable_path
                except Exception:
                    default_exe = ""
                if not default_exe or not os.path.isfile(default_exe):
                    sys_exe = find_system_chromium_executable()
                    if sys_exe:
                        kwargs["executable_path"] = sys_exe

            try:
                return await orig_async_launch(self, *args, **kwargs)
            except Exception as err:
                err_txt = str(err)
                if "Executable doesn't exist" in err_txt and not kwargs.get("executable_path"):
                    sys_exe = find_system_chromium_executable()
                    if sys_exe:
                        kwargs["executable_path"] = sys_exe
                        return await orig_async_launch(self, *args, **kwargs)
                    # Son çare: Chrome/Edge bile yoksa arka planda indir
                    try:
                        cflags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000) if sys.platform == "win32" else 0
                        subprocess.run(
                            [sys.executable, "-m", "playwright", "install", "chromium"],
                            creationflags=cflags,
                            timeout=180,
                        )
                        return await orig_async_launch(self, *args, **kwargs)
                    except Exception:
                        pass
                raise

        AsyncBrowserType.launch = _resilient_async_launch
    except Exception as e:
        print(f"[PlaywrightBootstrap] Async kanca uyarısı: {e}")
