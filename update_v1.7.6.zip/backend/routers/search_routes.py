# -*- coding: utf-8 -*-
"""
backend/routers/search_routes.py
--------------------------------
İlaç/OTC katalog önerileri, çoklu barkod senkronizasyonu, tüm depolarda
canlı fiyat/MF karşılaştırması, EczaneTakas / Eczatrend ortak alım ve E-Ticaret piyasa kıyaslama uç noktaları.
"""

import os
import re
import html as html_lib
import asyncio
import tempfile
from pathlib import Path
from fastapi import APIRouter, Query, UploadFile, File, Request
from fastapi.responses import JSONResponse, HTMLResponse

import backend.app_state as app_state
from backend.models import DepoKarsilastirmaRaporu, DepoKodu
from backend.catalog import catalog
from backend.tria_client import tria_client
from backend.botanik_client import botanik_client
from backend.tebeos_client import tebeos_client
from backend.eczanem_client import eczanem_client
from backend.market.models import MarketPriceReport
from backend.order_tracker import order_tracker
from backend.core.session_store import SessionStore
from backend.license_manager import license_manager

router = APIRouter()

_portal_pw = None
_portal_browser = None
_portal_lock = asyncio.Lock()


def _norm_tr(s: str) -> str:
    txt = str(s or "").strip().upper()
    for a, b in (("İ", "I"), ("I", "I"), ("Ğ", "G"), ("Ü", "U"), ("Ş", "S"), ("Ö", "O"), ("Ç", "C")):
        txt = txt.replace(a, b)
    return re.sub(r"[^A-Z0-9]+", " ", txt).strip()


async def _enrich_offers_with_erp_metrics(offers: list, depo_code: str = "") -> tuple[list, str]:
    """
    EczaneTakas veya Eczatrend teklif listesini aktif eczane otomasyonundan
    (BOTANIK, TRIA, TEBEOS veya ECZANEM) tek seferde (toplu/bulk) çekilen:
      - eczane_stok (Anlık Raf Stoğu)
      - cikis_1ay   (Son 30 Günlük Çıkış)
      - cikis_3ay   (Son 90 Günlük Çıkış)
    ve ayrıca bugünkü ortak sipariş / teklif katılım durumu (siparis_durumu, katilindi vb.)
    verileriyle zenginleştirir.
    """
    from backend.config_manager import get_active_otomasyon
    active_oto = get_active_otomasyon()
    clean_depo = str(depo_code or "").strip().upper()

    try:
        orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
    except Exception:
        orders_map = {}

    try:
        joined_map = await asyncio.to_thread(order_tracker.get_today_joined_offers, clean_depo)
    except Exception:
        joined_map = {}

    working_offers = [dict(o) for o in (offers or [])]

    # Bugün katılınmış ancak kalan stoğu 0'a düştüğü için portalın açık listesinden düşmüş teklifleri en üste ekle
    if joined_map:
        existing_ids = set()
        for o in working_offers:
            oid = str(o.get("teklif_no") or o.get("offer_id") or "").strip()
            if oid:
                existing_ids.add(oid)
        prepended = []
        for okey, j in joined_map.items():
            jid = str(j.get("offer_id") or "").strip()
            if not jid or jid in existing_ids:
                continue
            if clean_depo == "ECZANETAKAS":
                prepended.append({
                    "teklif_no": jid,
                    "katil_url": j.get("katil_url") or f"https://eczanetakas.com/katil/{jid}",
                    "urun_adi": j.get("urun_adi") or f"EczaneTakas #{jid}",
                    "barcode": j.get("barkod") or "",
                    "kalan_stok": 0,
                    "ekleyen": j.get("satici") or "Katılınan Teklif",
                    "miad": j.get("miad") or "-",
                    "depo_fiyati": float(j.get("depo_fiyati") or 0.0),
                    "satis_fiyati": float(j.get("fiyat_kdvli") or 0.0),
                    "mf": j.get("mf") or "YOK",
                    "not": j.get("not_metni") or ""
                })
            elif clean_depo == "ECZATREND":
                prepended.append({
                    "offer_id": jid,
                    "urun_adi": j.get("urun_adi") or f"Eczatrend #{jid[:8]}",
                    "barcode": j.get("barkod") or "",
                    "satici": j.get("satici") or "Grup Eczanesi",
                    "groupName": j.get("group_name") or "Ortak Alım",
                    "mf": j.get("mf") or "BAREM",
                    "hedef": int(j.get("miktar") or 1),
                    "alinan": int(j.get("miktar") or 1),
                    "kalan": 0,
                    "doluluk": "%100",
                    "depo_fiyati": float(j.get("depo_fiyati") or 0.0),
                    "fiyat_kdvsiz": float(j.get("fiyat_kdvsiz") or 0.0),
                    "fiyat_kdvli": float(j.get("fiyat_kdvli") or 0.0),
                    "kalan_sure": j.get("miad") or "Tamamlandı",
                    "katil_url": "https://eczatrend.com/eczanet/panelNew/main.html"
                })
        if prepended:
            working_offers = prepended + working_offers

    if not working_offers:
        return [], active_oto

    barcodes = []
    seen_bc = set()
    for o in working_offers:
        bc = str(o.get("barkod") or o.get("barcode") or "").strip()
        if bc and bc not in seen_bc:
            seen_bc.add(bc)
            barcodes.append(bc)

    metrics_map = {}
    used_oto = active_oto

    if barcodes:
        order_to_try = [active_oto] + [x for x in ("BOTANIK", "TRIA", "TEBEOS", "ECZANEM") if x != active_oto]
        for cand_oto in order_to_try:
            try:
                if cand_oto == "BOTANIK":
                    cand_map = await asyncio.to_thread(botanik_client.get_bulk_stock_and_sales_map, barcodes)
                elif cand_oto == "TRIA":
                    cand_map = await asyncio.to_thread(tria_client.get_bulk_stock_and_sales_map, barcodes)
                elif cand_oto == "TEBEOS":
                    cand_map = await asyncio.to_thread(tebeos_client.get_bulk_stock_and_sales_map, barcodes)
                elif cand_oto == "ECZANEM":
                    cand_map = await asyncio.to_thread(eczanem_client.get_bulk_stock_and_sales_map, barcodes)
                else:
                    cand_map = {}

                if cand_map and any(v.get("found") for v in cand_map.values()):
                    metrics_map = cand_map
                    used_oto = cand_oto
                    break
                elif not metrics_map and cand_map:
                    metrics_map = cand_map
            except Exception as e:
                print(f"[ERP Enrich - {cand_oto}] Uyarı: {e}")

    enriched = []
    for o in working_offers:
        item = dict(o)
        bc = str(item.get("barkod") or item.get("barcode") or "").strip()
        nm = str(item.get("urun_adi") or item.get("name") or "").strip().upper()
        t_no = str(item.get("teklif_no") or "").strip()
        o_id = str(item.get("offer_id") or "").strip()
        offer_key = f"ET_{t_no[:24]}" if t_no else (f"ETR_{o_id[:24]}" if o_id else "")

        m = metrics_map.get(bc) or {}
        item["eczane_stok"] = int(m.get("stok", 0))
        item["cikis_1ay"] = int(m.get("cikis_1ay", 0))
        item["cikis_3ay"] = int(m.get("cikis_3ay", 0))
        item["erp_found"] = bool(m.get("found", False))
        item["otomasyon_kaynak"] = used_oto

        joined_entry = joined_map.get(offer_key) if offer_key else None
        offer_ord = orders_map.get(offer_key) if offer_key else None
        prod_ord = (
            (orders_map.get(bc) if bc else None)
            or (orders_map.get(bc[1:]) if len(bc) == 14 and bc.startswith("0") else None)
            or (orders_map.get("0" + bc) if len(bc) == 13 and bc.isdigit() else None)
            or (orders_map.get(nm) if nm else None)
            or (orders_map.get(f"NAME:{nm[:26]}") if nm else None)
        )
        ord_info = joined_entry or offer_ord or prod_ord
        if ord_info:
            item["siparis_durumu"] = str(ord_info.get("durum") or "SIPARIS_VERILDI")
            item["siparis_depo"] = str(ord_info.get("depo") or clean_depo or "DEPO")
            item["siparis_miktar"] = int(ord_info.get("miktar") or 1)
            item["siparis_masa"] = str(ord_info.get("masa_adi") or "")
            item["siparis_saat"] = str(ord_info.get("saat") or "")
            item["katilindi"] = bool(
                joined_entry is not None
                or offer_ord is not None
                or (item["siparis_durumu"] == "SIPARIS_VERILDI" and item["siparis_depo"].upper() == clean_depo)
            )
            item["katilinan_miktar"] = int((joined_entry or offer_ord or ord_info).get("miktar") or 1) if item["katilindi"] else 0
        else:
            item["siparis_durumu"] = None
            item["siparis_depo"] = None
            item["siparis_miktar"] = None
            item["siparis_masa"] = None
            item["siparis_saat"] = None
            item["katilindi"] = False
            item["katilinan_miktar"] = 0

        enriched.append(item)

    return enriched, used_oto


@router.get("/api/eczanetakas/offers")
async def get_eczanetakas_active_offers_endpoint(refresh: bool = False):
    """EczaneTakas portalındaki tüm aktif teklifleri (barkod, fiyat ve anlık stok / 1-3 aylık çıkış bilgileriyle) döndürür."""
    motor = app_state.get_motor()
    et_adapter = motor.adapters.get(DepoKodu.ECZANETAKAS)
    if not et_adapter:
        return {
            "success": False,
            "message": "EczaneTakas aktif değil veya giriş bilgileri tanımlanmamış.",
            "count": 0,
            "offers": []
        }
    try:
        offers = await et_adapter.get_active_offers(force_refresh=bool(refresh))
        enriched_offers, used_oto = await _enrich_offers_with_erp_metrics(offers, depo_code="ECZANETAKAS")
        return {
            "success": True,
            "otomasyon": used_oto,
            "count": len(enriched_offers),
            "offers": enriched_offers
        }
    except Exception as e:
        return {
            "success": False,
            "message": str(e),
            "count": 0,
            "offers": []
        }


@router.post("/api/eczanetakas/join")
async def join_eczanetakas_offer_endpoint(request: Request):
    """EczaneTakas teklifine şifre sormadan doğrudan uygulama içinden (arka plan oturumuyla) katılır."""
    data = await request.json()
    teklif_no = str(data.get("teklif_no") or data.get("urun_id") or "").strip()
    barcode = str(data.get("barcode") or data.get("barkod") or "").strip()
    urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
    try:
        miktar = max(1, int(data.get("miktar") or 1))
    except Exception:
        miktar = 1

    if not teklif_no:
        return JSONResponse(status_code=400, content={"success": False, "message": "Teklif numarası belirtilmedi."})

    motor = app_state.get_motor()
    et_adapter = motor.adapters.get(DepoKodu.ECZANETAKAS)
    if not et_adapter:
        return JSONResponse(status_code=400, content={"success": False, "message": "EczaneTakas aktif değil veya giriş bilgileri tanımlanmamış."})

    cached_meta = {}
    try:
        for off in (getattr(et_adapter, "_cached_offers", None) or []):
            if str(off.get("teklif_no") or "").strip() == teklif_no:
                cached_meta = dict(off)
                break
    except Exception:
        pass

    eff_bc = barcode or str(cached_meta.get("barcode") or "").strip()
    eff_name = urun_adi or str(cached_meta.get("urun_adi") or "").strip()

    res = await et_adapter.add_to_cart(urun_id=teklif_no, barcode=eff_bc, miktar=miktar, name=eff_name)
    if res.get("success") and not res.get("simulated"):
        try:
            recorded = await asyncio.to_thread(
                order_tracker.record_joined_offer,
                "ECZANETAKAS",
                teklif_no,
                eff_bc,
                eff_name or f"EczaneTakas #{teklif_no}",
                miktar,
                cached_meta
            )
            res["order_record"] = recorded
            res["siparis_durumu"] = "SIPARIS_VERILDI"
            res["siparis_depo"] = "ECZANETAKAS"
            res["siparis_miktar"] = recorded.get("miktar", miktar)
            res["siparis_saat"] = recorded.get("saat", "")
            res["siparis_masa"] = recorded.get("masa_adi", "")
            res["barcode"] = recorded.get("barkod") or eff_bc
            res["urun_adi"] = recorded.get("urun_adi") or eff_name
            try:
                license_manager.record_activity("cart", f"EczaneTakas Katılım: {(eff_name or teklif_no)[:30]} x{miktar}")
            except Exception:
                pass
        except Exception as e:
            print(f"[EczaneTakas Join] OrderTracker kayıt hatası: {e}")
    return res


@router.get("/api/eczatrend/offers")
async def get_eczatrend_active_offers_endpoint(refresh: bool = False, q: str = ""):
    """Eczatrend ortak alım portalındaki aktif grup tekliflerini (anlık stok ve 1-3 aylık çıkış bilgileriyle) döndürür."""
    motor = app_state.get_motor()
    etr_adapter = motor.adapters.get(DepoKodu.ECZATREND)
    if not etr_adapter:
        return {
            "success": False,
            "message": "Eczatrend aktif değil veya giriş bilgileri tanımlanmamış.",
            "count": 0,
            "offers": []
        }
    try:
        offers = await etr_adapter.get_active_offers(force_refresh=bool(refresh), search_query=q)
        enriched_offers, used_oto = await _enrich_offers_with_erp_metrics(offers, depo_code="ECZATREND")
        return {
            "success": True,
            "otomasyon": used_oto,
            "count": len(enriched_offers),
            "offers": enriched_offers
        }
    except Exception as e:
        return {
            "success": False,
            "message": str(e),
            "count": 0,
            "offers": []
        }


@router.post("/api/eczatrend/join")
async def join_eczatrend_offer_endpoint(request: Request):
    """Eczatrend ortak alım teklifine şifre sormadan doğrudan uygulama içinden (arka plan oturumuyla) katılır."""
    data = await request.json()
    offer_id = str(data.get("offer_id") or data.get("urun_id") or "").strip()
    barcode = str(data.get("barcode") or data.get("barkod") or "").strip()
    urun_adi = str(data.get("urun_adi") or data.get("name") or "").strip()
    try:
        miktar = max(1, int(data.get("miktar") or 1))
    except Exception:
        miktar = 1

    if not offer_id:
        return JSONResponse(status_code=400, content={"success": False, "message": "Eczatrend teklif kodu (offer_id) belirtilmedi."})

    motor = app_state.get_motor()
    etr_adapter = motor.adapters.get(DepoKodu.ECZATREND)
    if not etr_adapter:
        return JSONResponse(status_code=400, content={"success": False, "message": "Eczatrend aktif değil veya giriş bilgileri tanımlanmamış."})

    cached_meta = {}
    try:
        for off in (getattr(etr_adapter, "_OFFERS_CACHE", None) or []):
            if str(off.get("offer_id") or "").strip() == offer_id:
                cached_meta = dict(off)
                break
    except Exception:
        pass

    eff_bc = barcode or str(cached_meta.get("barcode") or "").strip()
    eff_name = urun_adi or str(cached_meta.get("urun_adi") or "").strip()

    res = await etr_adapter.add_to_cart(urun_id=offer_id, barcode=eff_bc, miktar=miktar, name=eff_name)
    if res.get("success"):
        try:
            recorded = await asyncio.to_thread(
                order_tracker.record_joined_offer,
                "ECZATREND",
                offer_id,
                eff_bc,
                eff_name or f"Eczatrend #{offer_id[:8]}",
                miktar,
                cached_meta
            )
            res["order_record"] = recorded
            res["siparis_durumu"] = "SIPARIS_VERILDI"
            res["siparis_depo"] = "ECZATREND"
            res["siparis_miktar"] = recorded.get("miktar", miktar)
            res["siparis_saat"] = recorded.get("saat", "")
            res["siparis_masa"] = recorded.get("masa_adi", "")
            res["barcode"] = recorded.get("barkod") or eff_bc
            res["urun_adi"] = recorded.get("urun_adi") or eff_name
            try:
                license_manager.record_activity("cart", f"Eczatrend Katılım: {(eff_name or offer_id)[:30]} x{miktar}")
            except Exception:
                pass
        except Exception as e:
            print(f"[Eczatrend Join] OrderTracker kayıt hatası: {e}")
    return res


@router.post("/api/portal/open-browser")
async def open_authenticated_portal_browser_endpoint(request: Request):
    """
    İSKOOP, Selçuk, Nevzat, Hedef (Alliance), Eczatrend ve EczaneTakas portallarını
    arka planda hazır tutulan oturum çerezleriyle (şifre sormadan, doğrudan giriş yapılmış halde)
    görünür tarayıcı penceresinde açar.
    """
    global _portal_pw, _portal_browser
    data = await request.json()
    depo_raw = str(data.get("depo") or "").strip().upper()
    target_url = str(data.get("target_url") or data.get("url") or "").strip()

    default_urls = {
        "ECZANETAKAS": "https://eczanetakas.com/teklifler/",
        "ECZATREND": "https://eczatrend.com/eczanet/panelNew/main.html",
        "SELCUK": "https://webdepo.selcukecza.com.tr/Siparis/hizlisiparis.aspx",
        "ALLIANCE": "https://esiparisv2.alliance-healthcare.com.tr/Sales/QuickOrder",
        "HEDEF": "https://esiparisv2.alliance-healthcare.com.tr/Sales/QuickOrder",
        "ISKOOP": "https://esube.iskoop.org/FrameWorkT1",
        "NEVZAT": "http://webdepo.nevzatecza.com.tr/Siparis/hizlisiparis.aspx",
    }
    if depo_raw == "HEDEF":
        depo_raw = "ALLIANCE"

    if not target_url:
        target_url = default_urls.get(depo_raw, "https://eczanetakas.com/teklifler/")

    motor = app_state.get_motor()
    depo_enum_map = {
        "ECZANETAKAS": DepoKodu.ECZANETAKAS,
        "ECZATREND": DepoKodu.ECZATREND,
        "SELCUK": DepoKodu.SELCUK,
        "ALLIANCE": DepoKodu.ALLIANCE,
        "ISKOOP": DepoKodu.ISKOOP,
        "NEVZAT": DepoKodu.NEVZAT,
    }
    dk = depo_enum_map.get(depo_raw)
    adp = motor.adapters.get(dk) if (motor and dk) else None

    # 1. Arka plan adaptör oturumunun güncel olduğundan emin ol
    if adp:
        try:
            await adp.login()
        except Exception as e:
            print(f"[PortalOpen - {depo_raw}] Login uyarısı: {e}")

    async with _portal_lock:
        try:
            from playwright.async_api import async_playwright
            if _portal_pw is None:
                _portal_pw = await async_playwright().start()
            if _portal_browser is None or not _portal_browser.is_connected():
                _portal_browser = await _portal_pw.chromium.launch(
                    headless=False,
                    args=["--start-maximized", "--no-sandbox", "--disable-setuid-sandbox"]
                )

            session_key = depo_raw.lower()
            session_file = SessionStore.get_session_file(session_key)
            context = None

            if depo_raw in ("SELCUK", "NEVZAT", "ALLIANCE", "ISKOOP") and session_file.exists():
                try:
                    context = await _portal_browser.new_context(
                        storage_state=str(session_file),
                        no_viewport=True
                    )
                except Exception:
                    context = await _portal_browser.new_context(no_viewport=True)
            else:
                context = await _portal_browser.new_context(no_viewport=True)

            # EczaneTakas & Eczatrend için aktif çerezleri tarayıcıya enjekte et
            if depo_raw == "ECZANETAKAS":
                cookies_to_add = []
                saved = SessionStore.load_state("eczanetakas") or {}
                c_map = dict(saved.get("cookies") or {})
                if adp and getattr(adp, "_client", None):
                    c_map.update(dict(adp._client.cookies))
                for ck_name, ck_val in c_map.items():
                    cookies_to_add.append({
                        "name": str(ck_name),
                        "value": str(ck_val),
                        "domain": "eczanetakas.com",
                        "path": "/"
                    })
                if cookies_to_add:
                    await context.add_cookies(cookies_to_add)

            elif depo_raw == "ECZATREND":
                cookies_to_add = []
                saved = SessionStore.load_state("eczatrend") or {}
                c_map = dict(saved.get("cookies") or {})
                if adp and getattr(adp, "_client", None):
                    c_map.update(dict(adp._client.cookies))
                for ck_name, ck_val in c_map.items():
                    cookies_to_add.append({
                        "name": str(ck_name),
                        "value": str(ck_val),
                        "domain": "eczatrend.com",
                        "path": "/"
                    })
                if cookies_to_add:
                    await context.add_cookies(cookies_to_add)

            page = await context.new_page()
            await page.goto(target_url, wait_until="domcontentloaded", timeout=20000)

            # Olası oturum düşmelerine karşı otomatik form doldurma güvencesi
            cur_url = (page.url or "").lower()
            if depo_raw == "ECZANETAKAS" and "giris.php" in cur_url:
                u = os.environ.get("ECZANETAKAS_USERNAME", "").strip()
                p = os.environ.get("ECZANETAKAS_PASSWORD", "").strip()
                if u and p:
                    await page.fill('input[name="eposta"]', u)
                    await page.fill('input[name="sifre"]', p)
                    await page.click('button[type="submit"], input[type="submit"]')
                    await page.wait_for_load_state("domcontentloaded")
                    if target_url and "giris.php" not in target_url.lower():
                        await page.goto(target_url, wait_until="domcontentloaded", timeout=15000)

            elif depo_raw == "ECZATREND" and "sitelogin" in cur_url:
                u = os.environ.get("ECZATREND_USERNAME", "").strip()
                p = os.environ.get("ECZATREND_PASSWORD", "").strip()
                if u and p:
                    await page.fill("#username", u)
                    await page.fill("#password", p)
                    await page.evaluate("() => { if (typeof login === 'function') login(); else document.querySelector('button, input[type=submit]')?.click(); }")
                    await asyncio.sleep(1.5)
                    await page.goto(target_url, wait_until="domcontentloaded", timeout=15000)

            elif depo_raw == "SELCUK" and "login" in cur_url:
                u = os.environ.get("SELCUK_USERNAME", "").strip()
                p = os.environ.get("SELCUK_PASSWORD", "").strip()
                if u and p:
                    await page.fill("#txtKullaniciAdi", u)
                    await page.fill("#txtSifre", p)
                    await page.click("#btnGiris")

            elif depo_raw == "NEVZAT" and "login" in cur_url:
                ac = os.environ.get("NEVZAT_ACCOUNT_CODE", "").strip()
                u = os.environ.get("NEVZAT_USERNAME", "").strip()
                p = os.environ.get("NEVZAT_PASSWORD", "").strip()
                if ac and u and p:
                    await page.fill("#txtEczaneKodu", ac)
                    await page.fill("#txtKullaniciAdi", u)
                    await page.fill("#txtSifre", p)
                    await page.click("#btnLogin")

            elif depo_raw == "ALLIANCE" and "login" in cur_url:
                pc = os.environ.get("ALLIANCE_PHARMACY_CODE", "").strip()
                u = os.environ.get("ALLIANCE_USERNAME", "").strip()
                p = os.environ.get("ALLIANCE_PASSWORD", "").strip()
                if pc and u and p:
                    await page.fill("#pharmacyCode", pc)
                    await page.fill("#Customer_username", u)
                    await page.fill("#Customer_password", p)
                    await page.click(".Customer_login__button")

            elif depo_raw == "ISKOOP":
                has_login = await page.query_selector("#logonuidfield")
                if has_login:
                    u = os.environ.get("ISKOOP_USERNAME", "").strip()
                    p = os.environ.get("ISKOOP_PASSWORD", "").strip()
                    if u and p:
                        await page.fill("#logonuidfield", u)
                        await page.fill("#logonpassfield", p)
                        await page.click('input[name="login"]')

            await page.bring_to_front()
            return {
                "success": True,
                "depo": depo_raw,
                "url": page.url,
                "message": f"{depo_raw} portalı otomatik giriş yapılmış olarak açıldı."
            }
        except Exception as e:
            return {
                "success": False,
                "depo": depo_raw,
                "fallback_url": f"/api/portal/auto-login?depo={depo_raw}&target={target_url}",
                "message": str(e)
            }


@router.get("/api/portal/auto-login", response_class=HTMLResponse)
async def portal_auto_login_bridge_endpoint(depo: str = Query("ECZANETAKAS"), target: str = Query("")):
    """
    Tarayıcı sekmesinde doğrudan otomatik giriş formu göndererek şifre sormadan portala bağlar.
    """
    depo_up = (depo or "ECZANETAKAS").strip().upper()
    if depo_up == "ECZANETAKAS":
        u = html_lib.escape(os.environ.get("ECZANETAKAS_USERNAME", "").strip())
        p = html_lib.escape(os.environ.get("ECZANETAKAS_PASSWORD", "").strip())
        if u and p:
            return HTMLResponse(f"""<!DOCTYPE html>
<html lang="tr"><head><meta charset="utf-8"><title>EczaneTakas Otomatik Giriş...</title></head>
<body style="background:#0f172a;color:#e2e8f0;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
<div style="text-align:center;">
  <div style="font-size:1.1rem;font-weight:700;color:#2dd4bf;margin-bottom:8px;">🔄 EczaneTakas Oturumu Açılıyor...</div>
  <div style="font-size:0.85rem;color:#94a3b8;">Kayıtlı bilgilerinizle otomatik giriş yapılıyor, lütfen bekleyin.</div>
  <form id="etAutoForm" method="POST" action="https://eczanetakas.com/giris.php">
    <input type="hidden" name="eposta" value="{u}" />
    <input type="hidden" name="sifre" value="{p}" />
  </form>
</div>
<script>document.getElementById('etAutoForm').submit();</script>
</body></html>""")

    elif depo_up == "ISKOOP":
        u = html_lib.escape(os.environ.get("ISKOOP_USERNAME", "").strip())
        p = html_lib.escape(os.environ.get("ISKOOP_PASSWORD", "").strip())
        if u and p:
            return HTMLResponse(f"""<!DOCTYPE html>
<html lang="tr"><head><meta charset="utf-8"><title>İSKOOP Otomatik Giriş...</title></head>
<body style="background:#0f172a;color:#e2e8f0;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
<div style="text-align:center;">
  <div style="font-size:1.1rem;font-weight:700;color:#38bdf8;margin-bottom:8px;">🔄 İSKOOP e-Şube Oturumu Açılıyor...</div>
  <form id="iskAutoForm" method="POST" action="https://esube.iskoop.org/irj/portal">
    <input type="hidden" name="login_submit" value="on" />
    <input type="hidden" name="login_do_redirect" value="1" />
    <input type="hidden" name="j_user" value="{u}" />
    <input type="hidden" name="j_password" value="{p}" />
  </form>
</div>
<script>document.getElementById('iskAutoForm').submit();</script>
</body></html>""")

    fallback = html_lib.escape(target or "https://eczanetakas.com/teklifler/")
    return HTMLResponse(f'<html><head><meta http-equiv="refresh" content="0;url={fallback}"></head></html>')


@router.get("/api/catalog/suggest")
async def suggest_endpoint(q: str = Query(..., min_length=2)):
    """Kullanıcı yazarken anlık ilaç ve OTC önerisi sunar."""
    suggestions = await asyncio.to_thread(catalog.search_suggestions, q, 15)
    return suggestions


@router.get("/api/catalog/stats")
async def catalog_stats_endpoint():
    """Katalogdaki toplam tekil ürün ve çoklu barkod sayılarını döndürür."""
    with catalog._get_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM products")
        total_p = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM product_barcodes")
        total_b = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM product_barcodes WHERE is_primary = 0")
        total_sec = cur.fetchone()[0]
    return {
        "total_products": total_p,
        "total_barcodes": total_b,
        "secondary_barcodes": total_sec
    }


@router.post("/api/catalog/sync-tria")
async def catalog_sync_tria_endpoint():
    """TRIA Oracle'dan çoklu barkod senkronizasyonunu tetikler."""
    try:
        catalog.sync_from_tria()
        return {"success": True, "message": "TRIA çoklu barkod senkronizasyonu tamamlandı."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})


@router.post("/api/catalog/sync-botanik")
async def catalog_sync_botanik_endpoint():
    """Botanik MS SQL'den çoklu barkod senkronizasyonunu tetikler."""
    try:
        catalog.sync_from_botanik()
        return {"success": True, "message": "Botanik çoklu barkod senkronizasyonu başarıyla tamamlandı."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})


@router.post("/api/catalog/sync-eczanem")
async def catalog_sync_eczanem_endpoint():
    """Eczanem MS SQL'den çoklu barkod ve raf stoğu senkronizasyonunu tetikler."""
    try:
        await asyncio.to_thread(catalog.sync_from_eczanem)
        return {"success": True, "message": "Eczanem ürün ve çoklu barkod senkronizasyonu başarıyla tamamlandı."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})


@router.post("/api/catalog/upload-excel")
async def catalog_upload_excel_endpoint(file: UploadFile = File(...)):
    """Kullanıcının yüklediği Dermokozmetik / OTC Excel dosyasını kataloğa aktarır."""
    try:
        suffix = Path(file.filename).suffix
        if suffix.lower() not in [".xlsx", ".xls"]:
            return JSONResponse(status_code=400, content={"success": False, "error": "Lütfen geçerli bir Excel (.xlsx) dosyası yükleyin."})

        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = Path(tmp.name)

        res = catalog.import_custom_excel(tmp_path)
        try:
            tmp_path.unlink()
        except Exception:
            pass
        return res
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})


@router.get("/api/products/find")
async def find_products_endpoint(q: str = Query(..., min_length=2)):
    """
    Kullanıcı arama yaptığında:
    - Barkod ise doğrudan tekil barkod döndürür.
    - Kelime araması ise (örn: 'ocean', 'parol', 'solgar') eşleşen tüm ürünleri döndürür.
    """
    motor = app_state.get_motor()
    clean_q = q.strip()
    if clean_q.isdigit() and len(clean_q) >= 8:
        cat_item = catalog.get_by_barcode(clean_q)
        return {
            "is_barcode": True,
            "barcode": clean_q,
            "count": 1,
            "products": [cat_item] if cat_item else [{
                "barcode": clean_q,
                "name": f"Ürün Barkodu: {clean_q}",
                "manufacturer": "Genel",
                "price": 0.0
            }]
        }

    products = await motor.find_products(clean_q, limit=20)
    return {
        "is_barcode": False,
        "count": len(products),
        "products": products
    }


@router.get("/api/search", response_model=DepoKarsilastirmaRaporu)
async def search_endpoint(
    q: str = Query(..., description="Barkod veya Ürün Adı"),
    name: str = Query("", description="Ürün Adı (Yedek)"),
    urun_id: str = Query("", description="Otomasyon Ürün ID (Yedek)")
):
    from backend.config_manager import get_active_otomasyon
    motor = app_state.get_motor()
    clean_q = q.strip()
    clean_name = (name or "").strip()
    clean_uid = (urun_id or "").strip()
    if not clean_q and not clean_name:
        return JSONResponse(status_code=400, content={"error": "Arama ifadesi boş olamaz"})

    rapor = await motor.search_all(clean_q or clean_name)

    # Eğer barkodla aramada hiçbir depodan gerçek sonuç gelmediyse ve ürün adı biliniyorsa, isimden kanonik barkodu bulup tekrar dene
    has_depo_res = any(
        (getattr(r.stok_durumu, "value", str(r.stok_durumu)) == "VAR" or r.depocu_satis_fiyati > 0 or r.net_birim_maliyet > 0)
        for r in (rapor.sonuclar or [])
    )
    if not has_depo_res and clean_name:
        alt_bcs = catalog.find_canonical_barcodes_by_name(clean_name, exclude_barcode=clean_q)
        if not alt_bcs:
            found_prods = await motor.find_products(clean_name, limit=1)
            if found_prods and found_prods[0].get("barcode"):
                alt_bcs = [str(found_prods[0]["barcode"]).strip()]
        for alt_bc in alt_bcs[:1]:
            if alt_bc and alt_bc != clean_q and alt_bc != rapor.barkod:
                alt_rapor = await motor.search_all(alt_bc)
                if alt_rapor and alt_rapor.sonuclar:
                    rapor = alt_rapor
                    break

    cat_item = catalog.get_by_barcode(rapor.barkod)
    if cat_item and cat_item.get("name"):
        rapor.urun_adi = cat_item["name"]
    elif clean_name and (not rapor.urun_adi or rapor.urun_adi.startswith("Ürün (Barkod:")):
        rapor.urun_adi = clean_name

    # Canlı aramada bulunan depo MF bilgisini anında mf_resolver önbelleğine de kaydet
    try:
        from backend.mf_resolver import mf_resolver
        if rapor and rapor.barkod and rapor.sonuclar:
            live_mf_str = None
            live_mf_depo = None
            live_mf_price = 0.0
            any_b2b_var = False
            for sr in rapor.sonuclar:
                d_code = str(getattr(sr.depo, "value", sr.depo) or "").upper()
                if d_code not in ("SELCUK", "ALLIANCE", "ISKOOP", "NEVZAT"):
                    continue
                st_val = str(getattr(sr.stok_durumu, "value", sr.stok_durumu) or "").upper()
                p_val = float(getattr(sr, "psf", 0) or getattr(sr, "depocu_satis_fiyati", 0) or getattr(sr, "net_birim_maliyet_kdvli", 0) or 0.0)
                if st_val == "VAR" or p_val > 0:
                    any_b2b_var = True
                    if p_val > 0 and live_mf_price <= 0:
                        live_mf_price = p_val
                if mf_resolver.is_valid_mf(getattr(sr, "mf_metni", None)):
                    live_mf_str = str(sr.mf_metni).strip()
                    live_mf_depo = "Selçuk" if d_code == "SELCUK" else ("Alliance" if d_code == "ALLIANCE" else ("İSKOOP" if d_code == "ISKOOP" else "Nevzat"))
                    if p_val > 0:
                        live_mf_price = p_val
                    break
            if live_mf_str or any_b2b_var:
                mf_resolver.set_cached_mf(rapor.barkod, live_mf_str, live_mf_depo, live_mf_price)
                if clean_q and clean_q.isdigit() and clean_q != rapor.barkod:
                    mf_resolver.set_cached_mf(clean_q, live_mf_str, live_mf_depo, live_mf_price)
    except Exception:
        pass

    active_oto = get_active_otomasyon()
    oto_res = None

    if active_oto == "ECZANEM":
        try:
            oto_res = await asyncio.to_thread(eczanem_client.get_product_analysis, clean_q, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and clean_uid and clean_uid.isdigit() and len(clean_uid) <= 9:
                oto_res = await asyncio.to_thread(eczanem_client.get_product_analysis, clean_uid, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and (clean_name or rapor.urun_adi):
                fb_name = clean_name or rapor.urun_adi
                if fb_name and not fb_name.startswith("Ürün (Barkod:"):
                    oto_res = await asyncio.to_thread(eczanem_client.get_product_analysis, fb_name, barcode=rapor.barkod)
            rapor.tria_bilgisi = oto_res
            rapor.botanik_bilgisi = oto_res
        except Exception as e:
            print(f"[Eczanem] Arama hatası: {e}")
            oto_res = {"found": False, "connected": False, "kaynak": "ECZANEM", "message": "Eczanem otomasyonuna bağlanılamadı."}
    elif active_oto == "TEBEOS":
        try:
            oto_res = await asyncio.to_thread(tebeos_client.get_product_analysis, clean_q, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and (clean_name or rapor.urun_adi):
                oto_res = await asyncio.to_thread(tebeos_client.get_product_analysis, clean_name or rapor.urun_adi, barcode=rapor.barkod)
            rapor.tria_bilgisi = oto_res
        except Exception as e:
            print(f"[Tebeos] Arama hatası: {e}")
            oto_res = {"found": False, "connected": False, "kaynak": "TEBEOS", "message": "TEBEOS otomasyonuna bağlanılamadı."}
    elif active_oto == "TRIA":
        try:
            oto_res = await asyncio.to_thread(tria_client.get_product_analysis, clean_q, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and (clean_name or rapor.urun_adi):
                oto_res = await asyncio.to_thread(tria_client.get_product_analysis, clean_name or rapor.urun_adi, barcode=rapor.barkod)
            rapor.tria_bilgisi = oto_res
        except Exception as e:
            print(f"[Tria] Arama hatası: {e}")
            oto_res = {"found": False, "connected": False, "kaynak": "TRIA", "message": "TRIA otomasyonuna bağlanılamadı."}
    else:  # BOTANIK
        try:
            oto_res = await asyncio.to_thread(botanik_client.get_product_analysis, clean_q, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and clean_uid and clean_uid.isdigit() and len(clean_uid) <= 9:
                oto_res = await asyncio.to_thread(botanik_client.get_product_analysis, clean_uid, barcode=rapor.barkod)
            if (not oto_res or not oto_res.get("found")) and (clean_name or rapor.urun_adi):
                fb_name = clean_name or rapor.urun_adi
                if fb_name and not fb_name.startswith("Ürün (Barkod:"):
                    oto_res = await asyncio.to_thread(botanik_client.get_product_analysis, fb_name, barcode=rapor.barkod)
            rapor.botanik_bilgisi = oto_res
        except Exception as e:
            print(f"[Botanik] Arama hatası: {e}")
            oto_res = {"found": False, "connected": False, "kaynak": "BOTANIK", "message": "Botanik otomasyonuna bağlanılamadı."}

    # Eğer TRIA seçili kalmış ama bağlanamamışsa ve Botanik aktifse otomatik Botanik'e düş
    if oto_res and not oto_res.get("connected", True) and active_oto not in ("BOTANIK", "ECZANEM"):
        try:
            bot_try = await asyncio.to_thread(botanik_client.get_product_analysis, clean_q, barcode=rapor.barkod)
            if (not bot_try or not bot_try.get("found")) and (clean_name or rapor.urun_adi):
                bot_try = await asyncio.to_thread(botanik_client.get_product_analysis, clean_name or rapor.urun_adi, barcode=rapor.barkod)
            if bot_try and bot_try.get("connected"):
                oto_res = bot_try
                rapor.botanik_bilgisi = oto_res
        except Exception:
            pass

    if oto_res and oto_res.get("found") and oto_res.get("urun_adi"):
        if not rapor.urun_adi or rapor.urun_adi.startswith("Ürün (Barkod:"):
            rapor.urun_adi = oto_res["urun_adi"]

    rapor.otomasyon_bilgisi = oto_res
    rapor.tria_bilgisi = oto_res
    if oto_res and oto_res.get("kaynak") in ("BOTANIK", "ECZANEM"):
        rapor.botanik_bilgisi = oto_res
    elif oto_res and oto_res.get("kaynak") in ("TRIA", "TEBEOS"):
        rapor.tria_bilgisi = oto_res

    try:
        from backend.models import StokDurumu
        orders_map = await asyncio.to_thread(order_tracker.get_today_orders_map)
        joined_all = await asyncio.to_thread(order_tracker.get_today_joined_offers)
        bc_key = str(rapor.barkod or "").strip()
        nm_key = str(rapor.urun_adi or "").strip().upper()
        norm_nm = _norm_tr(nm_key)

        ord_info = (
            orders_map.get(bc_key)
            or (orders_map.get(bc_key[1:]) if len(bc_key) == 14 and bc_key.startswith("0") else None)
            or (orders_map.get("0" + bc_key) if len(bc_key) == 13 else None)
            or orders_map.get(nm_key)
            or orders_map.get(f"NAME:{nm_key[:24]}")
        )

        # Bugün katılınan EczaneTakas / Eczatrend tekliflerinden bu ürüne ait olanları bul
        matched_joined = []
        joined_iter = (joined_all.values() if isinstance(joined_all, dict) else (joined_all or []))
        for jo in joined_iter:
            if not isinstance(jo, dict):
                continue
            j_bc = str(jo.get("barcode") or jo.get("barkod") or "").strip()
            j_nm = _norm_tr(str(jo.get("urun_adi") or ""))
            bc_match = bool(
                bc_key and j_bc and (
                    bc_key == j_bc
                    or (len(bc_key) == 14 and bc_key.startswith("0") and bc_key[1:] == j_bc)
                    or (len(j_bc) == 14 and j_bc.startswith("0") and j_bc[1:] == bc_key)
                )
            )
            nm_match = bool(norm_nm and j_nm and len(norm_nm) >= 4 and (norm_nm == j_nm or norm_nm in j_nm or j_nm in norm_nm))
            if bc_match or nm_match:
                matched_joined.append(jo)

        if not ord_info and matched_joined:
            first_jo = matched_joined[0]
            total_j_qty = sum(int(x.get("miktar") or x.get("katilinan_miktar") or x.get("siparis_miktar") or 1) for x in matched_joined)
            ord_info = {
                "durum": "SIPARIS_VERILDI",
                "depo": str(first_jo.get("depo") or "ECZANETAKAS"),
                "miktar": total_j_qty,
                "masa": str(first_jo.get("masa_adi") or first_jo.get("siparis_masa") or ""),
                "saat": str(first_jo.get("saat") or first_jo.get("siparis_saat") or ""),
                "urun_adi": str(first_jo.get("urun_adi") or rapor.urun_adi or ""),
            }

        if ord_info:
            rapor.bugun_siparis = ord_info

        for sart in (rapor.sonuclar or []):
            s_depo = str(getattr(sart.depo, "value", sart.depo) or "").upper()
            if ord_info:
                sart.siparis_durumu = ord_info.get("durum")
                sart.siparis_depo = ord_info.get("depo")
                sart.siparis_miktar = int(ord_info.get("miktar") or 1)
                sart.siparis_masa = ord_info.get("masa") or ord_info.get("masa_adi")
                sart.siparis_saat = ord_info.get("saat")
                if str(ord_info.get("depo") or "").upper() == s_depo and ord_info.get("durum") == "SIPARIS_VERILDI":
                    sart.katilindi = True
                    sart.katilinan_miktar = int(ord_info.get("miktar") or 1)

            if s_depo in ("ECZANETAKAS", "ECZATREND"):
                depo_joined = [j for j in matched_joined if str(j.get("depo") or "").upper() == s_depo]
                joined_by_id = {}
                for j in depo_joined:
                    jid = str(j.get("offer_id") or j.get("teklif_no") or "").strip()
                    if jid:
                        joined_by_id[jid] = j

                seen_ids = set()
                for pt in (sart.pazaryeri_teklifleri or []):
                    pid = str(pt.get("teklif_no") or pt.get("offer_id") or "").strip()
                    if pid:
                        seen_ids.add(pid)
                    j_hit = joined_by_id.get(pid)
                    o_key = f"ET_{pid}" if s_depo == "ECZANETAKAS" else f"ETR_{pid[:24]}"
                    o_hit = orders_map.get(o_key) if pid else None
                    if j_hit or o_hit:
                        q_val = int((j_hit or {}).get("miktar") or (j_hit or {}).get("katilinan_miktar") or (o_hit or {}).get("miktar") or 1)
                        pt["katilindi"] = True
                        pt["katilinan_miktar"] = q_val
                        pt["siparis_durumu"] = "SIPARIS_VERILDI"
                        pt["siparis_depo"] = s_depo
                        pt["siparis_miktar"] = q_val
                        pt["siparis_masa"] = str((j_hit or {}).get("masa_adi") or (j_hit or {}).get("siparis_masa") or (o_hit or {}).get("masa") or (o_hit or {}).get("masa_adi") or "")
                        pt["siparis_saat"] = str((j_hit or {}).get("saat") or (j_hit or {}).get("siparis_saat") or (o_hit or {}).get("saat") or "")
                    elif ord_info:
                        pt["siparis_durumu"] = ord_info.get("durum")
                        pt["siparis_depo"] = ord_info.get("depo")
                        pt["siparis_miktar"] = int(ord_info.get("miktar") or 1)
                        pt["siparis_masa"] = ord_info.get("masa") or ord_info.get("masa_adi")
                        pt["siparis_saat"] = ord_info.get("saat")

                # Kalan stoğu bittiği için aktif listeden düşen ama bugün katılınmış teklifleri en başa ekle
                for jid, j in joined_by_id.items():
                    if jid not in seen_ids:
                        q_val = int(j.get("miktar") or j.get("katilinan_miktar") or j.get("siparis_miktar") or 1)
                        fiyat_kdvli = float(j.get("fiyat_kdvli") or j.get("satis_fiyati") or j.get("fiyat") or 0.0)
                        fiyat_kdvsiz = float(j.get("fiyat_kdvsiz") or (round(fiyat_kdvli / 1.10, 2) if fiyat_kdvli > 0 else 0.0))
                        j_masa = str(j.get("masa_adi") or j.get("siparis_masa") or "")
                        j_saat = str(j.get("saat") or j.get("siparis_saat") or "")
                        if s_depo == "ECZANETAKAS":
                            pt_item = {
                                "teklif_no": jid,
                                "satici": str(j.get("satici") or j.get("ekleyen") or "EczaneTakas İlanı"),
                                "stok": int(j.get("kalan_stok") or 0),
                                "fiyat": fiyat_kdvli,
                                "fiyat_kdvli": fiyat_kdvli,
                                "fiyat_kdvsiz": fiyat_kdvsiz,
                                "mf": str(j.get("mf") or "YOK"),
                                "miad": str(j.get("miad") or "-"),
                                "not": str(j.get("not_metni") or j.get("not") or "Bugün katıldığınız teklif"),
                                "katil_url": str(j.get("katil_url") or f"https://eczanetakas.com/teklifler/katil/{jid}"),
                                "katilindi": True,
                                "katilinan_miktar": q_val,
                                "siparis_durumu": "SIPARIS_VERILDI",
                                "siparis_depo": "ECZANETAKAS",
                                "siparis_miktar": q_val,
                                "siparis_masa": j_masa,
                                "siparis_saat": j_saat,
                            }
                        else:
                            pt_item = {
                                "offer_id": jid,
                                "satici": str(j.get("satici") or j.get("ekleyen") or "Grup Eczanesi"),
                                "pharmacy": str(j.get("satici") or j.get("ekleyen") or "Grup Eczanesi"),
                                "groupName": str(j.get("group_name") or j.get("groupName") or "Ortak Alım"),
                                "fiyat": fiyat_kdvli,
                                "fiyat_kdvsiz": fiyat_kdvsiz,
                                "depocu_fiyat": float(j.get("depo_fiyati") or j.get("depocu_fiyat") or 0.0),
                                "psf": float(j.get("psf") or 0.0),
                                "kdv": 10.0,
                                "mf": str(j.get("mf") or "BAREM"),
                                "hedef": int(j.get("hedef") or 0),
                                "kalan": int(j.get("kalan") or 0),
                                "alinan": int(j.get("alinan") or q_val),
                                "doluluk": str(j.get("doluluk") or "%100"),
                                "kalan_sure": str(j.get("miad") or j.get("kalan_sure") or ""),
                                "tur": "Katılınan Teklif",
                                "durum": "Katılındı",
                                "katilindi": True,
                                "katilinan_miktar": q_val,
                                "siparis_durumu": "SIPARIS_VERILDI",
                                "siparis_depo": "ECZATREND",
                                "siparis_miktar": q_val,
                                "siparis_masa": j_masa,
                                "siparis_saat": j_saat,
                            }
                        sart.pazaryeri_teklifleri.insert(0, pt_item)

                if depo_joined:
                    total_depo_qty = sum(int(x.get("miktar") or x.get("katilinan_miktar") or x.get("siparis_miktar") or 1) for x in depo_joined)
                    sart.katilindi = True
                    sart.katilinan_miktar = max(int(sart.katilinan_miktar or 0), total_depo_qty)
                    sart.siparis_durumu = "SIPARIS_VERILDI"
                    sart.siparis_depo = s_depo
                    sart.siparis_miktar = sart.katilinan_miktar
                    sart.siparis_masa = str(depo_joined[0].get("masa_adi") or depo_joined[0].get("siparis_masa") or sart.siparis_masa or "")
                    sart.siparis_saat = str(depo_joined[0].get("saat") or depo_joined[0].get("siparis_saat") or sart.siparis_saat or "")
                    if sart.net_birim_maliyet_kdvli <= 0 and sart.pazaryeri_teklifleri:
                        best_pt = sart.pazaryeri_teklifleri[0]
                        sart.urun_id = str(best_pt.get("teklif_no") or best_pt.get("offer_id") or "")
                        sart.net_birim_maliyet_kdvli = float(best_pt.get("fiyat") or 0.0)
                        sart.net_birim_maliyet = float(best_pt.get("fiyat_kdvsiz") or 0.0)
                        sart.depocu_satis_fiyati = float(best_pt.get("depocu_fiyat") or best_pt.get("fiyat_kdvsiz") or 0.0)
                        sart.mf_metni = str(best_pt.get("mf") or "YOK")
                        sart.miad = str(best_pt.get("miad") or best_pt.get("kalan_sure") or "")
                        sart.ozel_kampanya_notu = f"✅ BUGÜN KATILINDI ({sart.katilinan_miktar} Kutu • {sart.siparis_saat or 'Bugün'}) • {best_pt.get('satici', '')}"
    except Exception as e:
        print(f"[SearchOrderEnrich] Hata: {e}")

    try:
        prod_lbl = (rapor.urun_adi or clean_name or clean_q or "").strip()
        license_manager.record_activity("search", f"Depo Sorgu: {prod_lbl[:38]}")
    except Exception:
        pass

    return rapor


@router.get("/api/market/search", response_model=MarketPriceReport)
async def market_search_endpoint(q: str = Query(..., description="Barkod veya Ürün Adı")):
    m_engine = app_state.get_market_engine()
    clean_q = q.strip()
    if not clean_q:
        return JSONResponse(status_code=400, content={"error": "Arama ifadesi boş olamaz"})

    report = await m_engine.generate_market_report(clean_q)
    try:
        license_manager.record_activity("search", f"Piyasa Fiyat Kıyaslama: {clean_q[:32]}")
    except Exception:
        pass
    return report
