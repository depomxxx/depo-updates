# -*- coding: utf-8 -*-
CORE_CART_JS = """        const searchInput = document.getElementById('searchInput');
        const suggestBox = document.getElementById('suggestBox');
        const loading = document.getElementById('loading');
        const loadingText = document.getElementById('loadingText');
        const results = document.getElementById('results');
        const productSelection = document.getElementById('productSelection');
        const selectionGrid = document.getElementById('selectionGrid');
        const tableBody = document.getElementById('tableBody');
        const simQtyInput = document.getElementById('simQtyInput');

        let debounceTimer;
        let currentReport = null;
        let selectedDepoForSim = null;

        // Anlık öneri sistemi (Sıfır gecikmeli istemci önbelleği, klavye gezintisi ve odaklanma)
        let suggestAbortController = null;
        let currentSuggestions = [];
        let selectedSuggestIndex = -1;
        const clientSuggestCache = {};

        function highlightMatch(text, query) {
            if (!query) return text;
            const terms = query.trim().split(/\\\\s+/).filter(t => t.length > 0);
            if (terms.length === 0) return text;
            try {
                const escaped = terms.map(t => t.replace(/[.*+?^${}()|[\\\\]\\\\\\\\]/g, '\\\\\\\\$&')).join('|');
                const regex = new RegExp(`(${escaped})`, 'gi');
                return text.replace(regex, '<span class="bg-amber-100 text-amber-900 font-bold px-0.5 rounded">$1</span>');
            } catch (e) {
                return text;
            }
        }

        async function fetchAndRenderSuggestions(val) {
            const query = val.trim();
            if (query.length < 2) {
                suggestBox.classList.add('hidden');
                currentSuggestions = [];
                selectedSuggestIndex = -1;
                return;
            }

            // İstemci önbelleği kontrolü (Anında 0 ms gösterim)
            if (clientSuggestCache[query]) {
                currentSuggestions = clientSuggestCache[query];
                selectedSuggestIndex = -1;
                renderSuggestions(currentSuggestions, query);
                return;
            }

            if (suggestAbortController) {
                suggestAbortController.abort();
            }
            suggestAbortController = new AbortController();

            try {
                const res = await fetch(`/api/catalog/suggest?q=${encodeURIComponent(query)}`, {
                    signal: suggestAbortController.signal
                });
                if (res.ok) {
                    const items = await res.json();
                    clientSuggestCache[query] = items;
                    currentSuggestions = items;
                    selectedSuggestIndex = -1;
                    renderSuggestions(items, query);
                }
            } catch(e) {
                if (e.name !== 'AbortError') {
                    console.error("Öneri hatası:", e);
                }
            }
        }

        searchInput.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            const val = this.value;
            if (val.trim().length < 2) {
                suggestBox.classList.add('hidden');
                return;
            }
            // Hızlı 30ms gecikme (yazarken donma olmadan anında tepki)
            debounceTimer = setTimeout(() => {
                fetchAndRenderSuggestions(val);
            }, 30);
        });

        // Arama kutusuna tıklandığında (focus) mevcut metin varsa önerileri hemen aç
        searchInput.addEventListener('focus', function () {
            if (this.value.trim().length >= 2) {
                fetchAndRenderSuggestions(this.value);
            }
        });

        // Klavye Yön Tuşları (Yukarı/Aşağı) ve Enter ile Anında Seçim
        searchInput.addEventListener('keydown', function (e) {
            const isSuggestOpen = !suggestBox.classList.contains('hidden') && currentSuggestions.length > 0;

            if (e.key === 'ArrowDown') {
                if (isSuggestOpen) {
                    e.preventDefault();
                    selectedSuggestIndex = (selectedSuggestIndex + 1) % currentSuggestions.length;
                    updateSuggestHighlight();
                }
            } else if (e.key === 'ArrowUp') {
                if (isSuggestOpen) {
                    e.preventDefault();
                    selectedSuggestIndex = (selectedSuggestIndex - 1 + currentSuggestions.length) % currentSuggestions.length;
                    updateSuggestHighlight();
                }
            } else if (e.key === 'Enter') {
                if (isSuggestOpen && selectedSuggestIndex >= 0 && selectedSuggestIndex < currentSuggestions.length) {
                    e.preventDefault();
                    const chosen = currentSuggestions[selectedSuggestIndex];
                    selectAndSearch(chosen.barcode, chosen.name);
                } else if (isSuggestOpen && currentSuggestions.length > 0 && !/^\\d{8,14}$/.test(searchInput.value.trim())) {
                    // Kullanıcı Enter bastıysa ve listede öneriler varsa en üstteki 1. ürünü otomatik seç
                    e.preventDefault();
                    const chosen = currentSuggestions[0];
                    selectAndSearch(chosen.barcode, chosen.name);
                } else {
                    suggestBox.classList.add('hidden');
                    handleSearchSubmit();
                }
            } else if (e.key === 'Escape') {
                suggestBox.classList.add('hidden');
                selectedSuggestIndex = -1;
            }
        });

        function updateSuggestHighlight() {
            const rows = suggestBox.querySelectorAll('.suggest-item-row');
            rows.forEach((row, idx) => {
                if (idx === selectedSuggestIndex) {
                    row.classList.add('bg-emerald-50', 'border-l-4', 'border-l-emerald-600', 'pl-3');
                    row.classList.remove('hover:bg-slate-50');
                    row.scrollIntoView({ block: 'nearest' });
                } else {
                    row.classList.remove('bg-emerald-50', 'border-l-4', 'border-l-emerald-600', 'pl-3');
                    row.classList.add('hover:bg-slate-50');
                }
            });
        }

        function renderSuggestions(items, query = '') {
            if (!items || items.length === 0) {
                suggestBox.classList.add('hidden');
                return;
            }

            suggestBox.innerHTML = '';
            const ownCount = items.filter(it => (it.in_pharmacy_db || 0) >= 1).length;
            
            // Başlık / İpucu çubuğu
            const headerDiv = document.createElement('div');
            headerDiv.className = 'px-4 py-1.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-medium select-none';
            headerDiv.innerHTML = `
                <div class="flex items-center space-x-2">
                    <span><i class="fa-solid fa-bolt text-amber-500 mr-1"></i> Akıllı İlaç & Ürün Seçimi (${items.length})</span>
                    ${ownCount > 0 ? `<span class="px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 font-bold text-[10px]"><i class="fa-solid fa-house-medical mr-1"></i>${ownCount} Eczane Kartı Öncelikli</span>` : ''}
                </div>
                <span class="text-slate-400 hidden sm:inline">Yön tuşları <kbd class="px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px]">↑</kbd> <kbd class="px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px]">↓</kbd> ile seçip <kbd class="px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px]">Enter</kbd> yapın</span>
            `;
            suggestBox.appendChild(headerDiv);

            items.forEach((item, index) => {
                const multiBadge = (item.barcode_count && item.barcode_count > 1)
                    ? `<span class="ml-1.5 px-1.5 py-0.5 text-[10px] font-semibold bg-indigo-50 text-indigo-700 rounded border border-indigo-200" title="Kayıtlı Tüm Barkodlar: ${(item.all_barcodes || []).join(', ')}">+${item.barcode_count - 1} Barkod</span>` 
                    : '';
                const inOwnDb = item.in_pharmacy_db || 0;
                const ownStock = item.pharmacy_stock || 0;
                let sourceBadge = '';
                let iconBoxClass = 'bg-slate-100 text-slate-500';
                let iconHtml = '<i class="fa-solid fa-tablets"></i>';

                if (inOwnDb >= 2) {
                    iconBoxClass = ownStock > 0
                        ? 'bg-emerald-100 text-emerald-700 border border-emerald-300'
                        : 'bg-indigo-100 text-indigo-700 border border-indigo-200';
                    iconHtml = '<i class="fa-solid fa-house-medical"></i>';
                    if (ownStock > 0) {
                        sourceBadge = `<span class="ml-1.5 px-1.5 py-0.5 text-[10px] font-black bg-emerald-100 text-emerald-800 rounded border border-emerald-300" title="Eczanenizin kendi veritabanında aktif ve stoklu ürün"><i class="fa-solid fa-cubes-stacked mr-1"></i>Stok: ${ownStock} Kutu</span>`;
                    } else {
                        sourceBadge = `<span class="ml-1.5 px-1.5 py-0.5 text-[10px] font-bold bg-indigo-50 text-indigo-700 rounded border border-indigo-200" title="Eczanenizin kendi veritabanında hareket görmüş aktif kart"><i class="fa-solid fa-house-medical mr-1"></i>Eczane Kartı (Stok: 0)</span>`;
                    }
                } else if (inOwnDb === 1) {
                    iconBoxClass = 'bg-sky-50 text-sky-700 border border-sky-200';
                    iconHtml = '<i class="fa-solid fa-database"></i>';
                    sourceBadge = `<span class="ml-1.5 px-1.5 py-0.5 text-[10px] font-semibold bg-sky-50 text-sky-700 rounded border border-sky-200" title="Eczane veritabanında kayıtlı kart"><i class="fa-solid fa-database mr-1"></i>Eczanede Kayıtlı</span>`;
                } else {
                    sourceBadge = `<span class="ml-1.5 px-1.5 py-0.5 text-[10px] font-medium bg-slate-100 text-slate-500 rounded" title="Eczane veritabanında yok — Genel İlaç/OTC Kataloğu">Genel Katalog</span>`;
                }

                const highlightedName = highlightMatch(item.name, query);
                const div = document.createElement('div');
                div.className = 'suggest-item-row px-4 py-2.5 hover:bg-slate-50 cursor-pointer flex items-center justify-between transition border-b border-slate-100/60 last:border-b-0';
                div.innerHTML = `
                    <div class="flex items-center space-x-3 min-w-0">
                        <div class="w-8 h-8 rounded-lg ${iconBoxClass} flex items-center justify-center text-xs font-bold shrink-0">
                            ${iconHtml}
                        </div>
                        <div class="min-w-0">
                            <div class="text-sm font-semibold text-slate-800 truncate">${highlightedName}</div>
                            <div class="text-xs text-slate-400 font-mono flex flex-wrap items-center gap-y-0.5">${item.barcode}${sourceBadge}${multiBadge} <span class="mx-1">•</span> <span class="text-slate-500 font-sans">${item.manufacturer || 'Genel'}</span></div>
                        </div>
                    </div>
                    <div class="text-right shrink-0 ml-3">
                        <div class="text-xs font-semibold text-slate-700">${item.price ? item.price.toFixed(2) + ' ₺' : ''}</div>
                        <span class="text-[10px] text-emerald-600 font-semibold flex items-center justify-end space-x-1">
                            <span>Karşılaştır</span>
                            <i class="fa-solid fa-arrow-right text-[9px]"></i>
                        </span>
                    </div>
                `;
                div.onmouseenter = () => {
                    selectedSuggestIndex = index;
                    updateSuggestHighlight();
                };
                div.onclick = (e) => {
                    e.stopPropagation();
                    selectAndSearch(item.barcode, item.name);
                };
                suggestBox.appendChild(div);
            });

            suggestBox.classList.remove('hidden');
        }

        // Tıklama dışına çıkınca öneri kutusunu kapat
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !suggestBox.contains(e.target)) {
                suggestBox.classList.add('hidden');
                selectedSuggestIndex = -1;
            }
        });

        async function selectAndSearch(barcode, name) {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Depo Sorgulama')) return;
            // Önceki aramadan kalan önerileri tamamen temizle (karışmayı önler)
            currentSuggestions = [];
            selectedSuggestIndex = -1;

            const input = document.getElementById('searchInput');
            if (input && name) input.value = name;
            else if (input && barcode) input.value = barcode;

            window.lastDepoSearchQuery = (name || barcode || '').trim();
            window.lastDepoSearchBarcode = (barcode || '').trim();
            const mInp = document.getElementById('marketSearchInput');
            if (mInp && window.lastDepoSearchQuery) {
                mInp.value = window.lastDepoSearchQuery;
            }

            const sBox = document.getElementById('suggestBox');
            if (sBox) sBox.classList.add('hidden');
            const pSel = document.getElementById('productSelection');
            if (pSel) pSel.classList.add('hidden');

            // Sayfanın en üstüne yumuşak kaydır
            window.scrollTo({ top: 0, behavior: 'smooth' });

            const q = (barcode || '').toString().trim();
            // Doğrudan geçerli 8-14 haneli EAN barkod ise hemen sorgula
            if (q && /^\\d{8,14}$/.test(q)) {
                performBarcodeSearch(q, name || '');
                return;
            }

            // Eğer barkod geçerli EAN değilse (örn: depo kodu veya salt isim), önce 13 haneli EAN barkodunu çöz
            const targetText = (name || q).trim();
            if (targetText) {
                try {
                    const res = await fetch(`/api/products/find?q=${encodeURIComponent(targetText)}`);
                    if (res.ok) {
                        const data = await res.json();
                        const foundBc = data.barcode || (data.products && data.products.length > 0 ? data.products[0].barcode : null);
                        const foundName = data.name || (data.products && data.products.length > 0 ? data.products[0].name : null);
                        if (foundBc && /^\\d{8,14}$/.test(foundBc)) {
                            if (input && foundName) input.value = foundName;
                            performBarcodeSearch(foundBc, foundName || name || '');
                            return;
                        }
                    }
                } catch (e) {
                    console.warn('[selectAndSearch] Barkod çözümleme hatası:', e);
                }
            }

            handleSearchSubmit(q || name);
        }

        async function handleSearchSubmit(customQuery) {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Depo Sorgulama')) return;
            if (customQuery) {
                // Özel parametre ile geldiyse eski önerileri sıfırla
                currentSuggestions = [];
                selectedSuggestIndex = -1;
            }

            const query = (customQuery || searchInput.value).trim();
            if (!query) return;

            window.lastDepoSearchQuery = query;
            const mInp = document.getElementById('marketSearchInput');
            if (mInp) mInp.value = query;

            suggestBox.classList.add('hidden');

            // Eğer doğrudan barkod ise (en az 8 hane rakam), direkt depo sorgula
            if (/^\\d{8,14}$/.test(query)) {
                productSelection.classList.add('hidden');
                performBarcodeSearch(query);
                return;
            }

            // AKILLI EŞLEŞTİRME: Yalnızca kullanıcı arama kutusuna yazıp enter'a bastıysa önerilerle eşleştir
            if (!customQuery && currentSuggestions && currentSuggestions.length > 0) {
                const qLower = query.toLowerCase();
                const exact = currentSuggestions.find(s => (s.name || '').toLowerCase() === qLower || s.barcode === query);
                if (exact) {
                    currentSuggestions = [];
                    selectAndSearch(exact.barcode, exact.name);
                    return;
                }
                if (currentSuggestions.length === 1) {
                    const onlySug = currentSuggestions[0];
                    currentSuggestions = [];
                    selectAndSearch(onlySug.barcode, onlySug.name);
                    return;
                }
            }

            // Metin araması: Eşleşen ürünleri bul
            loadingText.innerText = `'${query}' için ürünler taranıyor...`;
            loading.classList.remove('hidden');
            results.classList.add('hidden');
            productSelection.classList.add('hidden');

            const abortCtrl = new AbortController();
            const timeoutId = setTimeout(() => abortCtrl.abort(), 10000);

            try {
                const res = await fetch(`/api/products/find?q=${encodeURIComponent(query)}`, {
                    signal: abortCtrl.signal
                });
                clearTimeout(timeoutId);
                if (!res.ok) throw new Error("Arama yapılamadı");
                const data = await res.json();

                if (data.is_barcode || (data.products && data.products.length === 1)) {
                    // Tek bir ürün eşleştiyse doğrudan depolarda karşılaştır
                    const targetBarcode = data.barcode || data.products[0].barcode;
                    const targetName = (data.products && data.products[0] && data.products[0].name) || '';
                    performBarcodeSearch(targetBarcode, targetName);
                } else if (data.products && data.products.length > 1) {
                    // Birden fazla ürün bulundu (örn: OTC markası) -> Kullanıcıya ürün seçtir
                    renderProductSelection(data.products, query);
                } else {
                    alert(`'${query}' aramasıyla eşleşen ürün bulunamadı. Lütfen barkod veya farklı bir isim deneyin.`);
                }
            } catch (err) {
                clearTimeout(timeoutId);
                if (err.name === 'AbortError') {
                    alert(`'${query}' araması zaman aşımına uğradı. Lütfen doğrudan barkod yazarak deneyin.`);
                } else {
                    alert("Hata oluştu: " + err.message);
                }
            } finally {
                loading.classList.add('hidden');
            }
        }

        function renderProductSelection(products, query) {
            document.getElementById('selectionTitle').innerText = `'${query}' ile Eşleşen Ürünler`;
            document.getElementById('selectionCount').innerText = `${products.length} Farklı Ürün`;

            selectionGrid.innerHTML = '';
            products.forEach(p => {
                const inOwnDb = p.in_pharmacy_db || 0;
                const ownStock = p.pharmacy_stock || 0;
                let badgeHtml = `<span class="px-2 py-0.5 text-[10px] font-medium bg-slate-100 text-slate-500 rounded">Genel Katalog</span>`;
                let borderClass = 'border-slate-200 hover:border-emerald-500';
                if (inOwnDb >= 2) {
                    if (ownStock > 0) {
                        badgeHtml = `<span class="px-2 py-0.5 text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300 rounded"><i class="fa-solid fa-cubes-stacked mr-1"></i>Stok: ${ownStock} Kutu</span>`;
                        borderClass = 'border-emerald-300 hover:border-emerald-600 ring-1 ring-emerald-500/10';
                    } else {
                        badgeHtml = `<span class="px-2 py-0.5 text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 rounded"><i class="fa-solid fa-house-medical mr-1"></i>Eczane Kartı (Stok: 0)</span>`;
                        borderClass = 'border-indigo-200 hover:border-indigo-500';
                    }
                } else if (inOwnDb === 1) {
                    badgeHtml = `<span class="px-2 py-0.5 text-[10px] font-semibold bg-sky-50 text-sky-700 border border-sky-200 rounded"><i class="fa-solid fa-database mr-1"></i>Eczanede Kayıtlı</span>`;
                }

                const card = document.createElement('div');
                card.className = `bg-white p-5 rounded-2xl border ${borderClass} hover:shadow-md transition cursor-pointer flex flex-col justify-between`;
                card.onclick = () => selectAndSearch(p.barcode, p.name);

                card.innerHTML = `
                    <div>
                        <div class="flex items-center justify-between gap-1.5 mb-2 flex-wrap">
                            <span class="px-2 py-0.5 text-[11px] font-mono font-bold bg-slate-100 text-slate-700 rounded">${p.barcode}</span>
                            ${badgeHtml}
                        </div>
                        <h4 class="text-sm font-bold text-slate-900 leading-snug line-clamp-2">${p.name}</h4>
                        <div class="text-[11px] text-slate-400 mt-1">${p.manufacturer || 'Genel'}</div>
                    </div>
                    <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div class="text-xs text-slate-500">
                            ${p.price ? `<span class="font-bold text-slate-800 text-sm">${p.price.toFixed(2)} ₺</span>` : ''}
                        </div>
                        <button class="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold rounded-lg transition flex items-center space-x-1">
                            <span>Karşılaştır</span>
                            <i class="fa-solid fa-arrow-right text-[10px]"></i>
                        </button>
                    </div>
                `;
                selectionGrid.appendChild(card);
            });

            productSelection.classList.remove('hidden');
        }

        async function performBarcodeSearch(barcode, productName = '', urunId = '') {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Depo Sorgulama')) return;
            currentReport = null;
            loadingText.innerText = "Tüm aktif depolarda ve pazaryerlerinde eşzamanlı ticari şartlar taranıyor...";
            loading.classList.remove('hidden');
            results.classList.add('hidden');

            const searchCtrl = new AbortController();
            const timeoutId = setTimeout(() => searchCtrl.abort(), 40000);

            try {
                let searchUrl = `/api/search?q=${encodeURIComponent(barcode)}`;
                if (productName) searchUrl += `&name=${encodeURIComponent(productName)}`;
                if (urunId) searchUrl += `&urun_id=${encodeURIComponent(urunId)}`;
                const res = await fetch(searchUrl, {
                    signal: searchCtrl.signal
                });
                clearTimeout(timeoutId);
                if (res.status === 403) {
                    if (typeof loadLicenseStatus === 'function') await loadLicenseStatus(false);
                    if (window.checkLicenseBeforeAction) window.checkLicenseBeforeAction('Depo Sorgulama');
                    return;
                }
                if (!res.ok) throw new Error("Arama başarısız");
                const data = await res.json();
                currentReport = data;
                renderResults(data);
            } catch (err) {
                clearTimeout(timeoutId);
                if (err.name === 'AbortError') {
                    alert("Depo sorgusu zaman aşımına uğradı. Depo portalları geç yanıt veriyor olabilir, lütfen tekrar deneyin.");
                } else {
                    alert("Depo sorgu hatası: " + err.message);
                }
            } finally {
                loading.classList.add('hidden');
            }
        }

        function renderTodayOrderedBannerForCurrentReport(data) {
            const todayOrdBanner = document.getElementById('resTodayOrderedBanner');
            if (!todayOrdBanner || !data) return;
            const ord = data.bugun_siparis;
            const repBc = String(data.barkod || (ord && ord.barkod) || '').trim();
            const normRepBc = (repBc.length === 14 && repBc.startsWith('0')) ? repBc.slice(1) : repBc;
            const repNm = String(data.urun_adi || (ord && ord.urun_adi) || '').trim().toUpperCase();

            // Bu ürün şu an hangi depoların aktif sepetinde bulunuyor?
            const activeCartMatches = [];
            if (typeof getActiveCartGroupsByDepo === 'function') {
                const groups = getActiveCartGroupsByDepo() || {};
                Object.keys(groups).forEach(dKey => {
                    const grp = groups[dKey];
                    if (!grp || !Array.isArray(grp.items)) return;
                    grp.items.forEach(it => {
                        const itBc = String(it.barkod || '').trim();
                        const normItBc = (itBc.length === 14 && itBc.startsWith('0')) ? itBc.slice(1) : itBc;
                        const itNm = String(it.urun_adi || '').trim().toUpperCase();
                        if ((normRepBc && normItBc && normRepBc === normItBc) || (repNm && itNm && repNm === itNm)) {
                            activeCartMatches.push({
                                depo: dKey,
                                shortName: grp.shortName || dKey,
                                miktar: it.miktar || 1,
                                saat: it.saat || '--:--',
                                masa_adi: it.masa_adi || 'Eczane PC'
                            });
                        }
                    });
                });
            }

            if (activeCartMatches.length > 0) {
                const safeBc = repBc.replace(/'/g, "\\'");
                const safeNm = String(data.urun_adi || (ord && ord.urun_adi) || '').replace(/'/g, "\\'");
                const depoSummaryTitle = activeCartMatches.map(m => `${m.depo} (${m.miktar} Kutu)`).join(' + ');
                const depoDetailsText = activeCartMatches.map(m => `<strong>${m.depo}</strong> sepetine <strong>${m.miktar} Kutu</strong> (Saat ${m.saat} • ${m.masa_adi})`).join(' ve ');
                const targetModalTab = activeCartMatches.length === 1 ? activeCartMatches[0].depo : 'ALL';
                const depoButtonsHtml = activeCartMatches.map(m => `
                    <button type="button" onclick="openMultiDepotCartModal('${m.depo}')" class="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold transition cursor-pointer shadow-xs">
                        <i class="fa-solid fa-basket-shopping mr-1"></i>${m.shortName} Sepeti (${m.miktar})
                    </button>
                `).join('');
                todayOrdBanner.classList.remove('hidden');
                todayOrdBanner.innerHTML = `
                    <div class="p-3.5 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        <div class="flex items-center space-x-3">
                            <div class="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center text-base shrink-0">
                                <i class="fa-solid fa-cart-shopping"></i>
                            </div>
                            <div class="text-xs">
                                <div class="font-black text-sm">🛒 Bu Ürün Bugün ${depoSummaryTitle} Sepetine Eklendi</div>
                                <div class="mt-0.5">
                                    ${depoDetailsText} eklendi.
                                </div>
                            </div>
                        </div>
                        <div class="flex flex-wrap items-center gap-2 shrink-0">
                            ${depoButtonsHtml}
                            ${activeCartMatches.length > 1 ? `
                                <button type="button" onclick="openMultiDepotCartModal('ALL')" class="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-extrabold transition cursor-pointer shadow-xs">
                                    <i class="fa-solid fa-layer-group mr-1"></i>Tüm Sepetleri Gör
                                </button>
                            ` : `
                                <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeNm}', '${activeCartMatches[0].depo}', ${activeCartMatches[0].miktar})" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition cursor-pointer">
                                    <i class="fa-solid fa-check mr-1"></i>Sipariş Verildi İşaretle
                                </button>
                            `}
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeNm}', event)" class="px-2.5 py-1.5 rounded-xl bg-white hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-amber-300 text-xs font-bold transition cursor-pointer" title="Sepet İşaretini Kaldır">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </div>
                    </div>
                `;
                return;
            }

            if (ord && ord.durum) {
                const isFinalized = ord.durum === 'SIPARIS_VERILDI';
                const isSkipped = ord.durum === 'SIPARIS_VERILMEYECEK';
                const safeBc = (data.barkod || ord.barkod || '').replace(/'/g, "\\'");
                const safeNm = (data.urun_adi || ord.urun_adi || '').replace(/'/g, "\\'");
                todayOrdBanner.classList.remove('hidden');
                if (isFinalized) {
                    todayOrdBanner.innerHTML = `
                        <div class="p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-lg shadow-emerald-600/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl shrink-0">
                                    <i class="fa-solid fa-circle-check"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black uppercase tracking-wider text-emerald-100">⚠️ Mükerrer Sipariş Uyarısı — Bugün Sipariş Verildi!</div>
                                    <div class="text-sm font-bold mt-0.5">
                                        Bu ürün bugün saat <strong>${ord.saat || '--:--'}</strong> itibarıyla <strong>${ord.masa_adi || ord.masa || 'Eczane PC'}</strong> üzerinden <strong>${ord.depo || 'Depo'}</strong> deposuna <strong>${ord.miktar || 1} Kutu</strong> olarak sipariş verilip sonlandırılmıştır.
                                    </div>
                                </div>
                            </div>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeNm}', event)" class="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold border border-white/30 transition shrink-0 cursor-pointer">
                                <i class="fa-solid fa-rotate-left mr-1"></i>İşareti Kaldır
                            </button>
                        </div>
                    `;
                } else if (isSkipped) {
                    const isYokBanner = String(ord.depo || '').toUpperCase() === 'YOK_LISTESI';
                    todayOrdBanner.innerHTML = `
                        <div class="p-4 rounded-2xl ${isYokBanner ? 'bg-gradient-to-r from-rose-700 via-rose-800 to-slate-900' : 'bg-gradient-to-r from-slate-700 via-slate-800 to-rose-950'} text-white shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-xl bg-rose-500/30 border border-rose-400/40 flex items-center justify-center text-xl text-rose-200 shrink-0">
                                    <i class="fa-solid ${isYokBanner ? 'fa-triangle-exclamation' : 'fa-ban'}"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black uppercase tracking-wider text-rose-200">${isYokBanner ? '🚨 Bugün Yok Listesine Eklendi (Depolarda Yok)' : '🚫 Bugün Sipariş Verilmeyecek Olarak İşaretlendi'}</div>
                                    <div class="text-sm font-bold mt-0.5">
                                        Bu ürün bugün saat <strong>${ord.saat || '--:--'}</strong> itibarıyla <strong>${ord.masa_adi || ord.masa || 'Eczane PC'}</strong> tarafından <strong>${isYokBanner ? 'Yok Listesi' : 'Sipariş Verilmeyecek'}</strong> olarak işaretlenmiştir.
                                    </div>
                                </div>
                            </div>
                            <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeNm}', event)" class="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold border border-white/30 transition shrink-0 cursor-pointer">
                                <i class="fa-solid fa-rotate-left mr-1"></i>İşareti Kaldır
                            </button>
                        </div>
                    `;
                } else {
                    todayOrdBanner.innerHTML = `
                        <div class="p-3.5 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                            <div class="flex items-center space-x-3">
                                <div class="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center text-base shrink-0">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-black text-sm">🛒 Bu Ürün Bugün ${ord.depo || 'Depo'} Sepetine Eklendi</div>
                                    <div class="mt-0.5">
                                        Saat <strong>${ord.saat || '--:--'}</strong> itibarıyla <strong>${ord.masa_adi || ord.masa || 'Eczane PC'}</strong> bilgisayarından <strong>${ord.depo || 'Depo'}</strong> sepetine <strong>${ord.miktar || 1} Kutu</strong> eklendi.
                                    </div>
                                </div>
                            </div>
                            <div class="flex flex-wrap items-center gap-2 shrink-0">
                                <button type="button" onclick="openMultiDepotCartModal('${ord.depo || 'SELCUK'}')" class="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold transition cursor-pointer shadow-xs">
                                    <i class="fa-solid fa-basket-shopping mr-1"></i>Sepeti Gör & Sepete Git
                                </button>
                                <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeNm}', '${ord.depo || 'SELCUK'}', ${ord.miktar || 1})" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition cursor-pointer">
                                    <i class="fa-solid fa-check mr-1"></i>Sipariş Verildi İşaretle
                                </button>
                                <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeNm}', event)" class="px-2.5 py-1.5 rounded-xl bg-white hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-amber-300 text-xs font-bold transition cursor-pointer" title="Sepet İşaretini Kaldır">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                        </div>
                    `;
                }
            } else {
                const safeBc = (data.barkod || '').replace(/'/g, "\\'");
                const safeNm = (data.urun_adi || '').replace(/'/g, "\\'");
                todayOrdBanner.classList.remove('hidden');
                todayOrdBanner.innerHTML = `
                    <div class="px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200/90 flex flex-wrap items-center justify-between gap-2">
                        <div class="flex items-center space-x-2 text-xs text-slate-600 font-semibold">
                            <i class="fa-solid fa-network-wired text-indigo-500"></i>
                            <span>Ortak Eczane Sipariş Durumu: <strong class="text-slate-800">Bugün İşlem Yapılmadı</strong></span>
                        </div>
                        <div class="flex flex-wrap items-center gap-1.5">
                            <button type="button" onclick="markItemYokDirect('${safeBc}', '${safeNm}')" class="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold transition cursor-pointer shadow-2xs">
                                <i class="fa-solid fa-triangle-exclamation mr-1"></i>Yok Listesine Ekle
                            </button>
                            <button type="button" onclick="markItemSkippedDirect('${safeBc}', '${safeNm}')" class="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-xs font-extrabold transition cursor-pointer">
                                <i class="fa-solid fa-ban mr-1"></i>Verilmeyecek
                            </button>
                            <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeNm}', 'MANUEL', 1)" class="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-extrabold transition cursor-pointer">
                                <i class="fa-solid fa-check mr-1"></i>Sipariş Verildi
                            </button>
                        </div>
                    </div>
                `;
            }
        }

        function refreshCurrentSearchOrderBanner() {
            if (typeof currentReport === 'undefined' || !currentReport) return;
            const orders = window.todayOrdersMap || {};
            const bc = String(currentReport.barkod || '').trim();
            const nm = String(currentReport.urun_adi || '').trim().toUpperCase();
            let ordInfo = (bc && orders[bc])
                || (bc.length === 14 && bc.startsWith('0') ? orders[bc.slice(1)] : null)
                || (bc.length === 13 && /^\d+$/.test(bc) ? orders['0' + bc] : null)
                || (nm && orders[nm])
                || (nm && orders['NAME:' + nm.slice(0, 24)])
                || (nm && orders['NAME:' + nm.slice(0, 26)])
                || null;
            if (!ordInfo && Array.isArray(currentReport.sonuclar)) {
                for (const s of currentReport.sonuclar) {
                    const sBc = String(s.barkod || '').trim();
                    const sNm = String(s.urun_adi || '').trim().toUpperCase();
                    let found = (sBc && orders[sBc])
                        || (sBc.length === 14 && sBc.startsWith('0') ? orders[sBc.slice(1)] : null)
                        || (sBc.length === 13 && /^\d+$/.test(sBc) ? orders['0' + sBc] : null)
                        || (sNm && orders[sNm])
                        || (sNm && orders['NAME:' + sNm.slice(0, 24)])
                        || (sNm && orders['NAME:' + sNm.slice(0, 26)])
                        || null;
                    if (!found && Array.isArray(s.pazaryeri_teklifleri)) {
                        for (const pt of s.pazaryeri_teklifleri) {
                            const tid = String(pt.teklif_no || pt.offer_id || '').trim();
                            if (tid) {
                                found = orders['ET_' + tid] || orders['ETR_' + tid.slice(0, 24)] || null;
                            }
                            if (!found && pt.katilindi) {
                                found = {
                                    durum: 'SIPARIS_VERILDI',
                                    depo: String(s.depo || 'ECZANETAKAS'),
                                    miktar: parseInt(pt.katilinan_miktar || pt.siparis_miktar || 1, 10) || 1,
                                    masa: pt.siparis_masa || '',
                                    saat: pt.siparis_saat || '',
                                    urun_adi: currentReport.urun_adi || s.urun_adi || ''
                                };
                            }
                            if (found) break;
                        }
                    }
                    if (!found && s.katilindi) {
                        found = {
                            durum: 'SIPARIS_VERILDI',
                            depo: String(s.depo || 'ECZANETAKAS'),
                            miktar: parseInt(s.katilinan_miktar || s.siparis_miktar || 1, 10) || 1,
                            masa: s.siparis_masa || '',
                            saat: s.siparis_saat || '',
                            urun_adi: currentReport.urun_adi || s.urun_adi || ''
                        };
                    }
                    if (found && (!ordInfo || found.durum === 'SIPARIS_VERILDI')) {
                        ordInfo = found;
                        if (found.durum === 'SIPARIS_VERILDI') break;
                    }
                }
            }
            if (ordInfo) {
                currentReport.bugun_siparis = ordInfo;
            }
            renderTodayOrderedBannerForCurrentReport(currentReport);
        }
        window.refreshCurrentSearchOrderBanner = refreshCurrentSearchOrderBanner;

        function renderResults(data) {
            const sInp = document.getElementById('searchInput');
            if (sInp && data.urun_adi) sInp.value = data.urun_adi;

            window.lastDepoSearchQuery = (data.urun_adi || data.barkod || (sInp ? sInp.value : '') || '').trim();
            window.lastDepoSearchBarcode = (data.barkod || '').trim();
            const mInp = document.getElementById('marketSearchInput');
            if (mInp && window.lastDepoSearchQuery) {
                mInp.value = window.lastDepoSearchQuery;
            }

            document.getElementById('resBarcode').innerText = data.barkod;
            document.getElementById('resTitle').innerText = data.urun_adi;
            document.getElementById('resStockCount').innerText = `${data.stokta_bulunan_depolar.length} Depoda Stok Mevcut`;

            // Soğuk Zincir Rozeti
            const coldBadge = document.getElementById('resColdChainBadge');
            if (data.soguk_zincir) {
                coldBadge.classList.remove('hidden');
                coldBadge.classList.add('inline-flex');
            } else {
                coldBadge.classList.add('hidden');
                coldBadge.classList.remove('inline-flex');
            }

            // Muadiller / Eşdeğer Butonu
            const eqBtn = document.getElementById('resEquivalentsBtn');
            const eqCount = (data.esdegerler && data.esdegerler.length > 0) ? data.esdegerler.length : 0;
            if (eqCount > 0 || data.esdeger_kodu) {
                eqBtn.classList.remove('hidden');
                eqBtn.classList.add('inline-flex');
                document.getElementById('resEquivalentsBtnText').innerText = eqCount > 0 ? `Muadiller (${eqCount})` : 'Muadiller';
            } else {
                eqBtn.classList.add('hidden');
                eqBtn.classList.remove('inline-flex');
            }

            // SGK Kamu İskontosu, Eczacı Kârı, PSF ve KSF
            const kamuIsk = data.kamu_iskontosu || 0;
            const eczaciKari = data.eczaci_kari || 0;
            const psf = data.psf || 0;
            const ksf = data.kamu_fiyati || (psf > 0 ? (psf * (1.0 - (kamuIsk / 100.0))) : 0);

            document.getElementById('resKamuIsk').innerText = `%${kamuIsk.toFixed(1)}`;
            document.getElementById('resEczaciKari').innerText = `%${eczaciKari.toFixed(1)}`;
            document.getElementById('resPsf').innerText = `${psf.toFixed(2)} ₺`;
            document.getElementById('resKsf').innerText = `${ksf.toFixed(2)} ₺`;

            // Tahmini Kutu Başı Kârlar (Kamu vs Elden)
            const kamuKari = data.kamu_kari !== undefined ? data.kamu_kari : (ksf > 0 && data.en_dusuk_maliyet_kdvli > 0 ? (ksf - data.en_dusuk_maliyet_kdvli) : 0);
            const perakendeKari = data.perakende_kari !== undefined ? data.perakende_kari : (psf > 0 && data.en_dusuk_maliyet_kdvli > 0 ? (psf - data.en_dusuk_maliyet_kdvli) : 0);

            const kamuProfitEl = document.getElementById('resKamuProfit');
            const perakendeProfitEl = document.getElementById('resPerakendeProfit');

            if (kamuKari < 0) {
                kamuProfitEl.innerText = `${kamuKari.toFixed(2)} ₺ (Zarar!)`;
                kamuProfitEl.className = 'font-extrabold text-red-600 ml-1';
            } else {
                kamuProfitEl.innerText = `+${kamuKari.toFixed(2)} ₺`;
                kamuProfitEl.className = 'font-extrabold text-blue-800 ml-1';
            }

            perakendeProfitEl.innerText = `+${perakendeKari.toFixed(2)} ₺`;

            // Daha Kârlı Muadil Rozeti (En kârlı muadil varsa üst arama sonucunda uyarır)
            const muadilAlertEl = document.getElementById('resMuadilProfitOpportunity');
            const bestMuadilNameEl = document.getElementById('resBestMuadilName');
            const bestMuadilGainEl = document.getElementById('resBestMuadilGain');
            if (data.en_karli_muadil && data.muadil_kar_avantaji > 0) {
                if (bestMuadilNameEl) bestMuadilNameEl.innerText = data.en_karli_muadil.urun_adi || data.en_karli_muadil.ad || 'Muadil İlaç';
                if (bestMuadilGainEl) bestMuadilGainEl.innerText = `+${data.muadil_kar_avantaji.toFixed(2)} ₺`;
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('hidden');
                    muadilAlertEl.classList.add('inline-flex');
                }
            } else {
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('inline-flex');
                    muadilAlertEl.classList.add('hidden');
                }
            }

            // KDV bilgisi ve ürün tipi rozeti
            let kdv = 10;
            if (data.sonuclar && data.sonuclar.length > 0) {
                const foundKdv = data.sonuclar.find(s => s.kdv_orani && s.kdv_orani > 0);
                if (foundKdv) kdv = foundKdv.kdv_orani;
            }
            let kdvBadge = '';
            if (Math.abs(kdv - 1.0) < 0.1) {
                kdvBadge = `<span class="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded border border-amber-300 ml-1.5"><i class="fa-solid fa-seedling mr-1"></i>Gıda Takviyesi (%1 KDV)</span>`;
            } else if (Math.abs(kdv - 20.0) < 0.1) {
                kdvBadge = `<span class="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded border border-blue-300 ml-1.5"><i class="fa-solid fa-pump-soap mr-1"></i>Kozmetik / Itriyat (%20 KDV)</span>`;
            } else {
                kdvBadge = `<span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-300 ml-1.5"><i class="fa-solid fa-capsules mr-1"></i>İlaç (%10 KDV)</span>`;
            }
            document.getElementById('resVatInfo').innerHTML = `<i class="fa-solid fa-receipt mr-1"></i>KDV: <strong>%${kdv}</strong> ${kdvBadge}`;

            // Bugün sipariş verildi / sepette uyarısı
            renderTodayOrderedBannerForCurrentReport(data);

            const bestBanner = document.getElementById('bestDealBanner');
            let defaultBestIndex = 0;
            if (data.en_avantajli_depo && data.en_dusuk_maliyet !== null) {
                bestBanner.classList.remove('hidden');
                const foundIdx = data.sonuclar.findIndex(s => s.depo === data.en_avantajli_depo && Math.abs(s.net_birim_maliyet - data.en_dusuk_maliyet) < 0.01);
                defaultBestIndex = foundIdx >= 0 ? foundIdx : 0;
                const bestRow = data.sonuclar[defaultBestIndex] || data.sonuclar[0];
                document.getElementById('bestDepoName').innerText = bestRow ? bestRow.depo_adi : data.en_avantajli_depo;
                document.getElementById('bestCost').innerHTML = `${(data.en_dusuk_maliyet || 0).toFixed(2)} ₺ <span class="text-[10px] font-normal">(KDV H.)</span>`;
                document.getElementById('bestCostKdvli').innerText = (data.en_dusuk_maliyet_kdvli || 0).toFixed(2) + ' ₺';
                const titleEl = document.getElementById('bestDealBannerTitle');
                if (titleEl) titleEl.innerText = 'En Avantajlı Depo';
                const resetBtn = document.getElementById('btnResetToBestDeal');
                if (resetBtn) resetBtn.classList.add('hidden');
            } else {
                bestBanner.classList.add('hidden');
            }

            window.defaultBestRowIndex = defaultBestIndex;
            selectedRowIndex = defaultBestIndex;

            // Simülatör Depo Seçim Kutusunu (#simDepoSelect) Doldur
            const simDepoSelectEl = document.getElementById('simDepoSelect');
            if (simDepoSelectEl && Array.isArray(data.sonuclar)) {
                simDepoSelectEl.innerHTML = data.sonuclar.map((it, idx) => {
                    const isB = idx === defaultBestIndex;
                    const priceStr = (it.net_birim_maliyet || it.depocu_satis_fiyati || 0).toFixed(2);
                    const stkStr = it.stok_durumu === 'VAR' ? '' : ' [YOK]';
                    return `<option value="${idx}" ${isB ? 'selected' : ''}>${isB ? '🏆 ' : ''}${it.depo_adi} (${priceStr} ₺)${stkStr}</option>`;
                }).join('');
            }

            tableBody.innerHTML = '';

            data.sonuclar.forEach((item, index) => {
                const isBest = (item.depo === data.en_avantajli_depo && Math.abs(item.net_birim_maliyet - data.en_dusuk_maliyet) < 0.01);
                const isSelectedRow = (index === selectedRowIndex);
                const tr = document.createElement('tr');
                tr.id = `depoRow_${index}`;
                tr.dataset.isBest = isBest ? '1' : '0';
                tr.className = `hover:bg-slate-50/80 transition ${isBest ? 'bg-emerald-50/40 font-medium' : (isSelectedRow ? 'bg-indigo-50/40 ring-1 ring-inset ring-indigo-300' : '')}`;

                let depoColor = 'text-slate-700 font-bold';
                if (item.depo === 'ALLIANCE') depoColor = 'text-sky-700 font-bold';
                if (item.depo === 'SELCUK') depoColor = 'text-emerald-700 font-bold';
                if (item.depo === 'NEVZAT') depoColor = 'text-orange-700 font-bold';
                if (item.depo === 'ISKOOP') depoColor = 'text-red-700 font-bold';
                if (item.depo === 'BEK') depoColor = 'text-teal-700 font-bold';
                if (item.depo === 'ECZA1') depoColor = 'text-purple-700 font-bold';
                if (item.depo === 'FARMAZON') depoColor = 'text-amber-600 font-bold';
                if (item.depo === 'DNA') depoColor = 'text-cyan-700 font-bold';
                if (item.depo === 'ECZATREND') depoColor = 'text-orange-600 font-bold';
                if (item.depo === 'ECZANETAKAS') depoColor = 'text-sky-700 font-bold';

                let stockBadge = item.stok_durumu === 'VAR' 
                    ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800"><i class="fa-solid fa-check mr-1"></i>VAR ${item.stok_adedi ? `(${item.stok_adedi})` : ''}</span>`
                    : `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-500"><i class="fa-solid fa-xmark mr-1"></i>YOK</span>`;

                if (item.depo === 'ECZATREND') {
                    if (item.stok_adedi > 0) {
                        stockBadge = `<span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-extrabold bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs" title="Kampanyayı tamamlamak için kalan adet"><i class="fa-solid fa-hourglass-half mr-1 text-[11px] text-amber-700"></i>Kalan: ${item.stok_adedi} Adet</span>`;
                    } else {
                        stockBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-500" title="Kampanya hedefine ulaşıldı"><i class="fa-solid fa-check-double mr-1 text-[10px]"></i>Hedef Doldu</span>`;
                    }
                } else if (item.depo === 'ECZANETAKAS') {
                    if (item.stok_durumu === 'VAR' && item.stok_adedi > 0) {
                        stockBadge = `<span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-extrabold bg-sky-100 text-sky-900 border border-sky-300 shadow-2xs" title="EczaneTakas açık tekliflerde kalan toplam stok"><i class="fa-solid fa-boxes-stacked mr-1 text-[11px] text-sky-700"></i>Kalan: ${item.stok_adedi} Kutu</span>`;
                    } else {
                        stockBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-500" title="Açık teklif bulunmuyor"><i class="fa-solid fa-xmark mr-1 text-[10px]"></i>YOK</span>`;
                    }
                }

                // Soğuk Zincir Simgesi
                const rowColdIcon = item.soguk_zincir ? `<span class="text-sky-500 text-xs ml-1" title="Soğuk Zincir (+2°C / +8°C)"><i class="fa-solid fa-snowflake"></i></span>` : '';

                // MF Kademeleri veya Pazaryeri Satıcı Teklifleri HTML (MF'siz Fiyat ve MF'li Birim Fiyat KDV Hariç)
                const baseSingleNet = (item.ticari_iskonto && item.ticari_iskonto > 0 && item.depocu_satis_fiyati > 0)
                    ? (item.depocu_satis_fiyati * (1.0 - (item.ticari_iskonto / 100.0)))
                    : (item.net_birim_maliyet || item.depocu_satis_fiyati || 0);

                // Gerçekten indirim sağlayan veya hediye kutu içeren baremler
                const realKademeler = (item.kademeler || []).filter(k => 
                    (k.hediye && k.hediye > 0) || 
                    (k.net_birim_maliyet && k.net_birim_maliyet < (baseSingleNet - 0.02))
                );
                const hasRealMf = realKademeler.length > 0 || (item.hediye && item.hediye > 0);

                let mfHtml = '';
                if (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri.length > 0) {
                    const isFarmazon = item.depo === 'FARMAZON';
                    const isEczatrend = item.depo === 'ECZATREND';
                    const isEczanetakas = item.depo === 'ECZANETAKAS';
                    let btnCls = 'bg-purple-100 hover:bg-purple-200 text-purple-900 border-purple-300';
                    let btnLabel = `${item.pazaryeri_teklifleri.length} Farklı Satıcı Fiyatı`;
                    let btnIcon = 'fa-tags';
                    if (isFarmazon) {
                        btnCls = 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300';
                    } else if (isEczatrend) {
                        btnCls = 'bg-orange-100 hover:bg-orange-200 text-orange-950 border-orange-300';
                        btnLabel = `${item.pazaryeri_teklifleri.length} Grup Teklifi (${item.mf_metni})`;
                        btnIcon = 'fa-people-group';
                    } else if (isEczanetakas) {
                        btnCls = 'bg-sky-100 hover:bg-sky-200 text-sky-950 border-sky-300';
                        btnLabel = `${item.pazaryeri_teklifleri.length} Eczane Teklifi (${item.mf_metni})`;
                        btnIcon = 'fa-arrow-right-arrow-left';
                    }
                    mfHtml = `
                        <div class="flex flex-col space-y-1">
                            ${isEczatrend ? `
                                <div class="inline-flex items-center space-x-1.5 text-xs font-bold text-orange-900">
                                    <span class="px-2 py-0.5 rounded bg-orange-100 border border-orange-300"><i class="fa-solid fa-users mr-1"></i>Barem: ${item.mf_metni}</span>
                                    <span class="text-[10px] text-slate-500 font-medium">Hedef: ${item.pazaryeri_teklifleri[0]?.hedef || '-'} Kutu</span>
                                </div>
                            ` : isEczanetakas ? `
                                <div class="inline-flex items-center space-x-1.5 text-xs font-bold text-sky-900">
                                    <span class="px-2 py-0.5 rounded bg-sky-100 border border-sky-300"><i class="fa-solid fa-handshake mr-1"></i>Barem: ${item.mf_metni}</span>
                                    <span class="text-[10px] text-slate-500 font-medium truncate max-w-xs" title="${item.ozel_kampanya_notu || ''}">${item.ozel_kampanya_notu || ''}</span>
                                </div>
                            ` : ''}
                            <button type="button" onclick="toggleOffersRow(${index})" class="px-2.5 py-1 text-xs font-bold rounded-xl border ${btnCls} transition flex items-center space-x-1.5 cursor-pointer shadow-2xs">
                                <i class="fa-solid ${btnIcon} text-[10px]"></i>
                                <span>${btnLabel}</span>
                                <i id="offersChevron_${index}" class="fa-solid fa-chevron-down text-[10px] transition-transform duration-200"></i>
                            </button>
                        </div>
                    `;
                } else if (realKademeler.length > 0) {
                    mfHtml = `
                        <div class="flex flex-col space-y-1.5">
                            <div class="flex items-center space-x-1.5 text-[11px] text-slate-500">
                                <span>MF'siz (1 Adet):</span>
                                <span class="font-mono text-slate-700 font-semibold text-[10px]">${baseSingleNet.toFixed(2)} ₺</span>
                            </div>
                            <div class="flex flex-wrap gap-1.5">` + realKademeler.map(k => {
                                const tot = (k.alinan || 0) + (k.hediye || 0);
                                const tierMfliNet = (k.net_birim_maliyet && k.net_birim_maliyet > 0) ? k.net_birim_maliyet : (tot > 0 ? (((k.alinan || 1) * baseSingleNet) / tot) : baseSingleNet);
                                const tierMfliKdvli = (k.net_birim_maliyet_kdvli && k.net_birim_maliyet_kdvli > 0) ? k.net_birim_maliyet_kdvli : (tierMfliNet * (1.0 + (item.kdv_orani || 10.0) / 100.0));
                                return `
                                    <button type="button" onclick="setSimWithTier(${index}, ${k.alinan}, ${k.hediye})" class="group inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-indigo-50/90 hover:bg-indigo-600 hover:text-white border border-indigo-200 text-indigo-900 transition shadow-2xs cursor-pointer text-left" title="MF Barem: ${k.mf_text} — Tıklayarak siparişe aktarın (KDV Dahil: ${tierMfliKdvli.toFixed(2)} ₺)">
                                        <span class="font-bold text-xs">${k.mf_text}</span>
                                        <span class="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 group-hover:bg-emerald-500 group-hover:text-white font-extrabold font-mono text-emerald-800" title="MF'li Birim Net Maliyet (KDV Hariç)">
                                            ${tierMfliNet.toFixed(2)} ₺
                                        </span>
                                        <span class="text-[9px] text-slate-500 group-hover:text-indigo-200 font-mono" title="KDV Dahil Net Maliyet">
                                            (${tierMfliKdvli.toFixed(2)} ₺ KDV'li)
                                        </span>
                                    </button>
                                `;
                            }).join('') + `</div>
                        </div>
                    `;
                } else if (item.mf_metni && item.mf_metni !== 'YOK' && item.mf_metni !== 'None' && item.mf_metni !== '-' && item.mf_metni.trim() !== '') {
                    const parsedParts = [];
                    const rgx = /([0-9]+)\\s*\\+\\s*([0-9]+)/g;
                    let mMatch;
                    while ((mMatch = rgx.exec(String(item.mf_metni))) !== null) {
                        const aVal = parseInt(mMatch[1], 10) || 1;
                        const hVal = parseInt(mMatch[2], 10) || 0;
                        parsedParts.push({ label: `${aVal}+${hVal}`, alinan: aVal, hediye: hVal });
                    }
                    if (parsedParts.length === 0) {
                        parsedParts.push({
                            label: item.mf_metni.trim(),
                            alinan: item.alinan || 1,
                            hediye: item.hediye || 0
                        });
                    }
                    mfHtml = `
                        <div class="flex flex-col space-y-1">
                            <div class="flex items-center space-x-1.5 text-[11px] text-slate-500">
                                <span>MF'siz (1 Adet):</span>
                                <span class="font-mono text-slate-700 text-[10px] font-semibold">${baseSingleNet.toFixed(2)} ₺</span>
                            </div>
                            <div class="flex flex-wrap gap-1">` + parsedParts.map(pObj => {
                                const alinan = pObj.alinan;
                                const hediye = pObj.hediye;
                                const tot = alinan + hediye;
                                const partNet = tot > 0 ? ((alinan * baseSingleNet) / tot) : baseSingleNet;
                                const partKdvli = partNet * (1.0 + (item.kdv_orani || 10.0) / 100.0);
                                return `
                                    <button type="button" onclick="setSimWithTier(${index}, ${alinan}, ${hediye})" class="group inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-600 hover:text-white border border-emerald-300 text-emerald-950 transition shadow-2xs cursor-pointer text-left" title="MF Barem: ${pObj.label} — Tıklayarak siparişe aktarın (${alinan} Adet • KDV Dahil: ${partKdvli.toFixed(2)} ₺)">
                                        <span class="font-bold text-xs">${pObj.label}</span>
                                        <span class="text-[10px] px-1.5 py-0.5 rounded bg-white group-hover:bg-white/20 font-black font-mono text-emerald-700 group-hover:text-white border border-emerald-200 group-hover:border-transparent">
                                            ${partNet.toFixed(2)} ₺
                                        </span>
                                        <span class="text-[9px] text-slate-500 group-hover:text-emerald-200 font-mono">
                                            (${partKdvli.toFixed(2)} ₺ KDV'li)
                                        </span>
                                    </button>
                                `;
                            }).join('') + `</div>
                        </div>
                    `;
                } else if (item.hediye && item.hediye > 0) {
                    const tot = (item.alinan || 1) + item.hediye;
                    const singleMfliNet = tot > 0 ? (((item.alinan || 1) * baseSingleNet) / tot) : baseSingleNet;
                    const singleMfliKdvli = singleMfliNet * (1.0 + (item.kdv_orani || 10.0) / 100.0);
                    mfHtml = `
                        <div class="flex flex-col space-y-1">
                            <div class="flex items-center space-x-1.5 text-[11px] text-slate-500">
                                <span>MF'siz (1 Adet):</span>
                                <span class="font-mono text-slate-700 text-[10px] font-semibold">${baseSingleNet.toFixed(2)} ₺</span>
                            </div>
                            <button type="button" onclick="setSimWithTier(${index}, ${item.alinan || 1}, ${item.hediye})" class="group inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-600 hover:text-white border border-emerald-300 text-emerald-950 transition shadow-2xs cursor-pointer text-left" title="Tıklayarak siparişe aktarın">
                                <span class="font-bold text-xs">${item.alinan || 1}+${item.hediye}</span>
                                <span class="text-[10px] px-1.5 py-0.5 rounded bg-white group-hover:bg-white/20 font-black font-mono text-emerald-700 group-hover:text-white border border-emerald-200 group-hover:border-transparent">
                                    ${singleMfliNet.toFixed(2)} ₺
                                </span>
                                <span class="text-[9px] text-slate-500 group-hover:text-emerald-200 font-mono">
                                    (${singleMfliKdvli.toFixed(2)} ₺ KDV'li)
                                </span>
                            </button>
                        </div>
                    `;
                } else if (item.depo === 'ECZANETAKAS' && item.stok_durumu !== 'VAR') {
                    mfHtml = `
                        <div class="flex flex-col items-start space-y-1">
                            <span class="text-[11px] font-medium text-slate-500">${item.ozel_kampanya_notu || 'Bu ürün için şu an açık teklif yok.'}</span>
                            <button type="button" onclick="openEczaneTakasOffersModal()" class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl text-xs font-extrabold bg-sky-50 hover:bg-sky-600 text-sky-800 hover:text-white border border-sky-200 hover:border-sky-600 transition cursor-pointer shadow-2xs">
                                <i class="fa-solid fa-list-check text-[10px]"></i>
                                <span>Portaldaki Tüm Açık Teklifleri Gör ➔</span>
                            </button>
                        </div>
                    `;
                } else {
                    mfHtml = `
                        <span class="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-400">MF Yok</span>
                    `;
                }

                // Miad ve İskonto Rozetleri
                const miadBadge = item.miad 
                    ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200 mt-1" title="Son Kullanma Tarihi / Miad"><i class="fa-regular fa-calendar-check mr-1 text-[10px]"></i>Miad: ${item.miad}</span>` 
                    : '';

                const iskBadge = (item.ticari_iskonto && item.ticari_iskonto > 0)
                    ? `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 mt-1" title="Ticari / Nakit İskonto"><i class="fa-solid fa-percent mr-0.5 text-[8px]"></i>%${item.ticari_iskonto.toFixed(1)} İsk</span>`
                    : '';

                const isEczatrendItem = item.depo === 'ECZATREND';
                const isEczanetakasItem = item.depo === 'ECZANETAKAS';
                const primaryPt = (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri[0]) ? item.pazaryeri_teklifleri[0] : {};
                const rowOrdMatch = ((isEczatrendItem || isEczanetakasItem) && typeof window.findTodayOrderMatchForOffer === 'function')
                    ? window.findTodayOrderMatchForOffer({
                        teklif_no: primaryPt.teklif_no || item.urun_id || '',
                        offer_id: primaryPt.offer_id || item.urun_id || '',
                        barcode: item.barkod || '',
                        urun_adi: item.urun_adi || '',
                        katilindi: Boolean(item.katilindi || primaryPt.katilindi),
                        katilinan_miktar: item.katilinan_miktar || primaryPt.katilinan_miktar || 0,
                        siparis_durumu: item.siparis_durumu || primaryPt.siparis_durumu || null,
                        siparis_depo: item.siparis_depo || primaryPt.siparis_depo || null,
                        siparis_miktar: item.siparis_miktar || primaryPt.siparis_miktar || 0,
                        siparis_saat: item.siparis_saat || primaryPt.siparis_saat || '',
                        siparis_masa: item.siparis_masa || primaryPt.siparis_masa || ''
                    }, item.depo)
                    : null;
                const isRowJoinedToday = Boolean(rowOrdMatch && rowOrdMatch.isThisOfferJoined);
                const rowJoinedQty = rowOrdMatch ? (rowOrdMatch.siparis_miktar || 1) : 1;
                const rowJoinedTime = rowOrdMatch ? (rowOrdMatch.siparis_saat || '') : '';
                const rowJoinedBadgeCol1 = isRowJoinedToday ? `
                    <div class="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-black shadow-2xs">
                        <i class="fa-solid fa-circle-check"></i>
                        <span>BUGÜN KATILINDI / SİPARİŞ VERİLDİ: ${rowJoinedQty} KUTU${rowJoinedTime ? ' (' + rowJoinedTime + ')' : ''}</span>
                    </div>
                ` : '';

                const offersBadgeCol1 = (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri.length > 0) ? `
                    <button type="button" onclick="toggleOffersRow(${index})" class="mt-1 text-[11px] font-bold ${isEczatrendItem ? 'text-orange-700 hover:text-orange-900' : isEczanetakasItem ? 'text-sky-700 hover:text-sky-900' : 'text-amber-700 hover:text-amber-900'} flex items-center space-x-1 cursor-pointer">
                        <i class="fa-solid ${isEczatrendItem ? 'fa-people-group' : isEczanetakasItem ? 'fa-arrow-right-arrow-left' : 'fa-layer-group'} text-[10px]"></i>
                        <span>${isEczatrendItem ? 'Grup Teklifleri & Kalanı Gör' : isEczanetakasItem ? 'Tüm Eczane Tekliflerini Gör' : 'Fiyat Detaylarını Gör'} (${item.pazaryeri_teklifleri.length})</span>
                    </button>
                ` : '';

                const safeItemName = (item.urun_adi || '').replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
                const DEPO_PORTAL_CARTS = {
                    'SELCUK': 'https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx',
                    'ALLIANCE': 'https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart',
                    'ISKOOP': 'https://esube.iskoop.org/FrameWorkT1/#/baskets',
                    'NEVZAT': 'http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx',
                    'ECZANETAKAS': 'https://eczanetakas.com/teklifler/1'
                };
                const cartPortalUrl = DEPO_PORTAL_CARTS[item.depo];
                const cartLinkBadge = cartPortalUrl ? `
                    <a href="${cartPortalUrl}" target="_blank" class="mt-1 text-[10px] font-bold text-slate-400 hover:text-slate-800 flex items-center space-x-1 transition" title="${item.depo_adi} canlı portal sayfasını yeni sekmede aç">
                        <i class="fa-solid fa-cart-shopping text-[9px] text-slate-500"></i>
                        <span>${item.depo === 'ECZANETAKAS' ? 'Takas Portalı ↗' : 'Sepeti Gör ↗'}</span>
                    </a>
                ` : '';

                const selectRowBtnHtml = isSelectedRow
                    ? `<button type="button" id="btnSelectDepoRow_${index}" onclick="selectDepoForSimulation(${index}, event)" class="px-2 py-0.5 text-[10px] ${isBest ? 'bg-emerald-600 text-white' : 'bg-indigo-600 text-white'} rounded-full font-bold uppercase tracking-wider cursor-pointer transition shadow-2xs" title="Şu anda bu deponun şartları simüle ediliyor">✓ Seçili</button>`
                    : `<button type="button" id="btnSelectDepoRow_${index}" onclick="selectDepoForSimulation(${index}, event)" class="px-2 py-0.5 text-[10px] bg-slate-100 hover:bg-indigo-600 text-slate-700 hover:text-white border border-slate-300 hover:border-indigo-600 rounded-full font-bold transition cursor-pointer shadow-2xs" title="Bu depoyu seçerek simülatör ve sepet hesabını ${item.depo_adi} şartlarına göre yap">🎯 Seç & Hesapla</button>`;

                tr.innerHTML = `
                    <td class="py-4 px-6">
                        <div class="flex flex-col items-start">
                            <div class="flex flex-wrap items-center gap-1.5">
                                <span class="${depoColor} cursor-pointer hover:underline" onclick="selectDepoForSimulation(${index}, event)" title="${item.depo_adi} şartlarını seç">${item.depo_adi}</span>
                                ${rowColdIcon}
                                ${isBest ? '<span class="px-2 py-0.5 text-[10px] bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-full font-extrabold uppercase tracking-wider">🏆 En Avantajlı</span>' : ''}
                                ${selectRowBtnHtml}
                            </div>
                            ${rowJoinedBadgeCol1}
                            ${miadBadge}
                            ${offersBadgeCol1}
                            ${cartLinkBadge}
                        </div>
                    </td>
                    <td class="py-4 px-6">${stockBadge}</td>
                    <td class="py-4 px-6 text-slate-700 font-semibold">${item.depocu_satis_fiyati.toFixed(2)} ₺</td>
                    <td class="py-4 px-6">${mfHtml}</td>
                    <td class="py-4 px-6 text-slate-600">
                        <div class="font-medium">${item.vade_gun > 0 ? item.vade_gun + ' Gün' : 'Peşin / Kredi Kartı'}</div>
                        ${iskBadge}
                    </td>
                    <td class="py-4 px-6">
                        <div class="text-base font-extrabold ${isBest ? 'text-emerald-600' : 'text-slate-900'}">
                            ${item.net_birim_maliyet.toFixed(2)} ₺
                        </div>
                        <div class="text-[10px] text-slate-500 font-medium">
                            KDV Hariç ${realKademeler.length > 0 ? `(${realKademeler[0].mf_text} ile)` : ''}
                        </div>
                        ${psf > 0 ? `
                        <div class="text-[10px] text-slate-500 mt-1 flex flex-col space-y-0.5">
                            <span title="SGK Reçeteli Kutu Kârı: KSF - Alış" class="${(item.kamu_kari || 0) < 0 ? 'text-red-600 font-bold' : 'text-blue-700 font-medium'}">
                                <i class="fa-solid fa-file-prescription mr-1 text-[9px]"></i>SGK: ${(item.kamu_kari || 0) >= 0 ? '+' : ''}${(item.kamu_kari || 0).toFixed(2)} ₺
                            </span>
                            <span title="Elden Satış Kutu Kârı: PSF - Alış" class="text-emerald-700 font-medium">
                                <i class="fa-solid fa-hand-holding-dollar mr-1 text-[9px]"></i>Elden: +${(item.perakende_kari || 0).toFixed(2)} ₺
                            </span>
                        </div>
                        ` : ''}
                    </td>
                    <td class="py-4 px-6 text-right font-bold text-slate-700">
                        <div class="text-base font-extrabold text-slate-900">${item.net_birim_maliyet_kdvli.toFixed(2)} ₺</div>
                        <div class="text-[10px] text-slate-400 font-normal">%${item.kdv_orani} KDV Dahil</div>
                        ${(realKademeler.length > 0 && Math.abs(baseSingleNet - item.net_birim_maliyet) > 0.05) ? `
                            <div class="text-[10px] text-slate-500 mt-0.5 font-medium" title="1 Adet Tek Alımda KDV Dahil Tutar">
                                1 Adet: ${(baseSingleNet * (1 + item.kdv_orani/100)).toFixed(2)} ₺
                            </div>
                        ` : ''}
                    </td>
                    <td class="py-4 px-6 text-right">
                        ${item.depo === 'ECZATREND' ? `
                            <div class="flex flex-col items-end space-y-1.5">
                                ${((item.stok_durumu === 'VAR' || isRowJoinedToday) && item.pazaryeri_teklifleri && item.pazaryeri_teklifleri[0] && item.pazaryeri_teklifleri[0].offer_id) ? `
                                    <div class="flex items-center justify-end space-x-1">
                                        <div class="inline-flex items-center rounded-lg border border-slate-300 bg-white overflow-hidden">
                                            <button type="button" onclick="stepOfferJoinQty('etrJoinQty_${item.pazaryeri_teklifleri[0].offer_id}', -1, ${item.pazaryeri_teklifleri[0].kalan || 99})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">-</button>
                                            <input type="number" id="etrJoinQty_${item.pazaryeri_teklifleri[0].offer_id}" value="1" min="1" max="${item.pazaryeri_teklifleri[0].kalan || 99}" class="w-10 text-center text-xs font-black text-slate-800 focus:outline-none py-0.5" />
                                            <button type="button" onclick="stepOfferJoinQty('etrJoinQty_${item.pazaryeri_teklifleri[0].offer_id}', 1, ${item.pazaryeri_teklifleri[0].kalan || 99})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">+</button>
                                        </div>
                                        ${isRowJoinedToday ? `
                                            <button type="button" onclick="joinEczatrendOfferDirect('${item.pazaryeri_teklifleri[0].offer_id}', '${item.barkod}', '${safeItemName}', ${item.pazaryeri_teklifleri[0].kalan || 99}, this)" class="px-3 py-1.5 rounded-xl text-xs font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm shadow-emerald-200 transition flex items-center space-x-1 whitespace-nowrap cursor-pointer" title="Bu ortak alıma bugün ${rowJoinedQty} kutu katıldınız. İlave kutu eklemek için tıklayın.">
                                                <i class="fa-solid fa-circle-check text-[11px]"></i>
                                                <span>Katılındı (${rowJoinedQty} Kt)</span>
                                            </button>
                                        ` : `
                                            <button type="button" onclick="joinEczatrendOfferDirect('${item.pazaryeri_teklifleri[0].offer_id}', '${item.barkod}', '${safeItemName}', ${item.pazaryeri_teklifleri[0].kalan || 99}, this)" class="px-3 py-1.5 rounded-xl text-xs font-black bg-orange-600 hover:bg-orange-700 text-white shadow-sm shadow-orange-200 transition flex items-center space-x-1 whitespace-nowrap cursor-pointer" title="Şifre girmeden doğrudan ortak alıma katıl">
                                                <i class="fa-solid fa-bolt text-[11px] text-amber-200"></i>
                                                <span>Hemen Katıl</span>
                                            </button>
                                        `}
                                        <button type="button" onclick="openAuthenticatedPortal('ECZATREND', 'https://eczatrend.com/eczanet/panelNew/main.html')" class="px-2 py-1.5 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer" title="Hazır oturumla Eczatrend portalını aç">↗</button>
                                    </div>
                                ` : `
                                    <button type="button" onclick="openAuthenticatedPortal('ECZATREND', 'https://eczatrend.com/eczanet/panelNew/main.html')" class="px-3 py-1.5 rounded-xl text-xs font-bold bg-orange-600 hover:bg-orange-700 text-white shadow-sm shadow-orange-200 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer" title="Şifre girmeden doğrudan Eczatrend portalını aç">
                                        <i class="fa-solid fa-people-group text-[11px]"></i>
                                        <span>Ortak Alıma Git</span>
                                        <i class="fa-solid fa-arrow-up-right-from-square text-[9px] ml-0.5 opacity-80"></i>
                                    </button>
                                `}
                            </div>
                        ` : item.depo === 'ECZANETAKAS' ? `
                            <div class="flex flex-col items-end space-y-1.5">
                                ${((item.stok_durumu === 'VAR' || isRowJoinedToday) && item.pazaryeri_teklifleri && item.pazaryeri_teklifleri[0] && item.pazaryeri_teklifleri[0].teklif_no) ? `
                                    <div class="flex items-center justify-end space-x-1">
                                        <div class="inline-flex items-center rounded-lg border border-slate-300 bg-white overflow-hidden">
                                            <button type="button" onclick="stepOfferJoinQty('etJoinQty_${item.pazaryeri_teklifleri[0].teklif_no}', -1, ${item.pazaryeri_teklifleri[0].stok || 99})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">-</button>
                                            <input type="number" id="etJoinQty_${item.pazaryeri_teklifleri[0].teklif_no}" value="1" min="1" max="${item.pazaryeri_teklifleri[0].stok || 99}" class="w-10 text-center text-xs font-black text-slate-800 focus:outline-none py-0.5" />
                                            <button type="button" onclick="stepOfferJoinQty('etJoinQty_${item.pazaryeri_teklifleri[0].teklif_no}', 1, ${item.pazaryeri_teklifleri[0].stok || 99})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">+</button>
                                        </div>
                                        ${isRowJoinedToday ? `
                                            <button type="button" onclick="joinEczaneTakasOfferDirect('${item.pazaryeri_teklifleri[0].teklif_no}', '${item.barkod}', '${safeItemName}', ${item.pazaryeri_teklifleri[0].stok || 99}, this)" class="px-3 py-1.5 rounded-xl text-xs font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm shadow-emerald-200 transition flex items-center space-x-1 whitespace-nowrap cursor-pointer" title="Bu teklife bugün ${rowJoinedQty} kutu katıldınız. İlave kutu eklemek için tıklayın.">
                                                <i class="fa-solid fa-circle-check text-[11px]"></i>
                                                <span>Katılındı (${rowJoinedQty} Kt)</span>
                                            </button>
                                        ` : `
                                            <button type="button" onclick="joinEczaneTakasOfferDirect('${item.pazaryeri_teklifleri[0].teklif_no}', '${item.barkod}', '${safeItemName}', ${item.pazaryeri_teklifleri[0].stok || 99}, this)" class="px-3 py-1.5 rounded-xl text-xs font-black bg-sky-600 hover:bg-sky-700 text-white shadow-sm shadow-sky-200 transition flex items-center space-x-1 whitespace-nowrap cursor-pointer" title="Şifre girmeden doğrudan teklife katıl">
                                                <i class="fa-solid fa-bolt text-[11px] text-amber-200"></i>
                                                <span>Teklife Katıl</span>
                                            </button>
                                        `}
                                        <button type="button" onclick="openAuthenticatedPortal('ECZANETAKAS', '${item.pazaryeri_teklifleri[0].katil_url || ('https://eczanetakas.com/katil/' + item.pazaryeri_teklifleri[0].teklif_no)}')" class="px-2 py-1.5 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer" title="Hazır oturumla EczaneTakas teklif sayfasını aç">↗</button>
                                    </div>
                                ` : `
                                    <button type="button" onclick="openEczaneTakasOffersModal()" class="px-3 py-1.5 rounded-xl text-xs font-bold bg-sky-600 hover:bg-sky-700 text-white shadow-sm shadow-sky-200 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer" title="EczaneTakas üzerindeki tüm aktif ilaç tekliflerini listele">
                                        <i class="fa-solid fa-list-ul text-[11px]"></i>
                                        <span>Açık Teklifleri Gör</span>
                                    </button>
                                `}
                            </div>
                        ` : ['ECZA1', 'FARMAZON'].includes(item.depo) ? `
                            <div class="flex items-center justify-end">
                                <button type="button" onclick="toggleOffersRow(${index})" class="px-3 py-1.5 rounded-xl text-xs font-bold ${item.depo === 'FARMAZON' ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-200' : 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-200'} transition flex items-center space-x-1 shadow-sm cursor-pointer whitespace-nowrap" title="Tüm satıcıların fiyatlarını ve stoklarını gör">
                                    <i class="fa-solid fa-list-ul text-[10px]"></i>
                                    <span>Teklifleri Gör</span>
                                </button>
                            </div>
                        ` : `
                            <div class="flex flex-col items-end space-y-1.5 min-w-[190px]">
                                <div class="flex items-center justify-end space-x-1.5 w-full">
                                    <input type="number" id="qty_${index}" min="1" value="1" class="w-14 px-2 py-1 text-xs border border-slate-300 rounded-lg text-center font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none" title="Sipariş Adedi" />
                                    <button onclick="addToCart('${item.depo}', '${item.urun_id || item.barkod}', '${item.barkod}', ${index}, this, '${safeItemName}')" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center space-x-1 shadow-sm cursor-pointer whitespace-nowrap" title="${item.depo_adi} sepetine ekle">
                                        <i class="fa-solid fa-cart-plus text-[11px]"></i>
                                        <span>Sepete At</span>
                                    </button>
                                </div>
                                <button onclick="quickFinalizeOrder('${item.depo}', '${item.urun_id || item.barkod}', '${item.barkod}', ${index}, '${safeItemName}', ${item.net_birim_maliyet_kdvli || item.depocu_satis_fiyati || 0})" class="w-full px-2.5 py-1 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white rounded-lg text-xs font-black transition flex items-center justify-center space-x-1.5 shadow-xs hover:shadow cursor-pointer whitespace-nowrap" title="Tekli acil siparişi hemen depoya ilet ve sonlandır (Sepet kontrolü ile)">
                                    <i class="fa-solid fa-bolt-lightning text-amber-200 animate-pulse text-[11px]"></i>
                                    <span>Siparişi Sonlandır</span>
                                </button>
                            </div>
                        `}
                    </td>
                `;
                tableBody.appendChild(tr);

                // Pazaryeri (Farmazon & Ecza1) ve Alım Grubu (Eczatrend) Detaylı Satıcı Teklifleri Akordiyon Satırı
                if (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri.length > 0) {
                    const trOffers = document.createElement('tr');
                    trOffers.id = `offersRow_${index}`;
                    trOffers.className = 'hidden bg-slate-50/90 border-y border-dashed border-slate-300';

                    const isFarmazon = item.depo === 'FARMAZON';
                    const isEczatrend = item.depo === 'ECZATREND';
                    const isEczanetakas = item.depo === 'ECZANETAKAS';
                    let themeHeader = isFarmazon ? 'text-amber-900 bg-amber-50/90 border-amber-200' : 'text-purple-900 bg-purple-50/90 border-purple-200';
                    let iconHeader = isFarmazon ? 'fa-store text-amber-600' : 'fa-cart-shopping text-purple-600';
                    if (isEczatrend) {
                        themeHeader = 'text-orange-950 bg-orange-50/90 border-orange-200';
                        iconHeader = 'fa-people-group text-orange-600';
                    } else if (isEczanetakas) {
                        themeHeader = 'text-sky-950 bg-sky-50/90 border-sky-200';
                        iconHeader = 'fa-arrow-right-arrow-left text-sky-600';
                    }

                    let offersTbody = '';
                    let tableHeaderHtml = '';

                    if (isEczatrend) {
                        tableHeaderHtml = `
                            <tr>
                                <th class="py-2.5 px-3 text-center w-20">Sıra</th>
                                <th class="py-2.5 px-3">Açan Eczane & Grup</th>
                                <th class="py-2.5 px-3 text-center w-24">Barem (MF)</th>
                                <th class="py-2.5 px-3 text-center w-28">Hedef / Alınan</th>
                                <th class="py-2.5 px-3 text-center w-28">Kalan Adet</th>
                                <th class="py-2.5 px-3 text-right w-28">Birim KDV Hariç</th>
                                <th class="py-2.5 px-3 text-right w-28">Birim KDV Dahil</th>
                                <th class="py-2.5 px-3 text-center w-36">Durum & Süre</th>
                                <th class="py-2.5 px-3 text-right w-24">İşlem</th>
                            </tr>
                        `;
                        offersTbody = item.pazaryeri_teklifleri.map((off, oIdx) => {
                            const isCheapest = oIdx === 0;
                            const isAcik = (off.kalan || 0) > 0;
                            const offMatch = (typeof window.findTodayOrderMatchForOffer === 'function')
                                ? window.findTodayOrderMatchForOffer({
                                    offer_id: off.offer_id || '',
                                    barcode: item.barkod || '',
                                    urun_adi: item.urun_adi || '',
                                    katilindi: off.katilindi,
                                    katilinan_miktar: off.katilinan_miktar,
                                    siparis_durumu: off.siparis_durumu,
                                    siparis_depo: off.siparis_depo,
                                    siparis_miktar: off.siparis_miktar,
                                    siparis_saat: off.siparis_saat,
                                    siparis_masa: off.siparis_masa
                                }, 'ECZATREND')
                                : null;
                            const isOffJoined = Boolean(offMatch && offMatch.isThisOfferJoined);
                            const offJoinedQty = offMatch ? (offMatch.siparis_miktar || 1) : 1;
                            const offJoinedSaat = offMatch ? (offMatch.siparis_saat || '') : '';
                            const durumBadge = isOffJoined
                                ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-black bg-emerald-600 text-white shadow-2xs"><i class="fa-solid fa-circle-check mr-1 text-[9px]"></i>Katılındı (${offJoinedQty} Kt${offJoinedSaat ? ' • ' + offJoinedSaat : ''})</span>`
                                : (isAcik
                                    ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200"><i class="fa-solid fa-circle-check mr-1 text-[9px]"></i>Alıma Açık</span>`
                                    : `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-500"><i class="fa-solid fa-flag-checkered mr-1 text-[9px]"></i>Hedef Doldu</span>`);

                            return `
                                <tr class="hover:bg-white transition ${isOffJoined ? 'bg-emerald-50/80 border-l-4 border-l-emerald-600' : (isCheapest ? 'bg-orange-50/40' : '')}">
                                    <td class="py-2.5 px-3 text-center">
                                        ${isCheapest ? '<span class="px-1.5 py-0.5 text-[10px] font-black rounded bg-orange-600 text-white uppercase tracking-wider">En Uygun</span>' : `<span class="text-slate-400 font-mono text-[11px]">#${oIdx + 1}</span>`}
                                    </td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-bold text-slate-900 flex items-center">
                                            <i class="fa-solid fa-hospital text-[11px] text-orange-600 mr-1.5"></i>
                                            <span>${off.satici || off.pharmacy}</span>
                                            <span class="text-[10px] text-slate-500 font-normal ml-1.5 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">${off.groupName}</span>
                                        </div>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-black bg-indigo-100 text-indigo-900 border border-indigo-200 font-mono">
                                            ${off.mf || 'Barem'}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-center text-xs">
                                        <div class="font-bold text-slate-800">${off.hedef} Kutu Hedef</div>
                                        <div class="text-[10px] text-slate-500 font-medium">Alınan: ${off.alinan} (${off.doluluk})</div>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-black ${isAcik ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-slate-100 text-slate-500'}">
                                            ${off.kalan} Kutu
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-bold text-slate-800 font-mono">
                                        ${(off.fiyat_kdvsiz || 0).toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-extrabold text-orange-700 font-mono">
                                        ${(off.fiyat || 0).toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        ${durumBadge}
                                        ${off.kalan_sure ? `<span class="text-[10px] text-slate-500 block mt-0.5 font-medium">${off.kalan_sure}</span>` : ''}
                                    </td>
                                    <td class="py-2.5 px-3 text-right">
                                        <div class="inline-flex items-center justify-end space-x-1">
                                            <div class="inline-flex items-center rounded-lg border border-slate-300 bg-white overflow-hidden">
                                                <button type="button" onclick="stepOfferJoinQty('etrJoinQty_${off.offer_id}', -1, ${off.kalan || 99})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">-</button>
                                                <input type="number" id="etrJoinQty_${off.offer_id}" value="1" min="1" max="${off.kalan || 99}" class="w-10 text-center text-[11px] font-black text-slate-800 focus:outline-none py-0.5" />
                                                <button type="button" onclick="stepOfferJoinQty('etrJoinQty_${off.offer_id}', 1, ${off.kalan || 99})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">+</button>
                                            </div>
                                            ${isOffJoined ? `
                                                <button type="button" onclick="joinEczatrendOfferDirect('${off.offer_id}', '${item.barkod}', '${safeItemName}', ${off.kalan || 99}, this)" class="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow-2xs transition cursor-pointer">
                                                    <i class="fa-solid fa-circle-check mr-1 text-[10px]"></i>Katılındı (${offJoinedQty} Kt)
                                                </button>
                                            ` : `
                                                <button type="button" onclick="joinEczatrendOfferDirect('${off.offer_id}', '${item.barkod}', '${safeItemName}', ${off.kalan || 99}, this)" class="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-black bg-orange-600 hover:bg-orange-700 text-white shadow-2xs transition cursor-pointer">
                                                    <i class="fa-solid fa-bolt mr-1 text-[10px] text-amber-200"></i>Katıl
                                                </button>
                                            `}
                                            <button type="button" onclick="openAuthenticatedPortal('ECZATREND', 'https://eczatrend.com/eczanet/panelNew/main.html')" class="px-1.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-[10px] font-bold cursor-pointer" title="Hazır oturumla aç">↗</button>
                                        </div>
                                    </td>
                                </tr>
                            `;
                        }).join('');
                    } else if (isEczanetakas) {
                        tableHeaderHtml = `
                            <tr>
                                <th class="py-2.5 px-3 text-center w-20">Sıra</th>
                                <th class="py-2.5 px-3">Teklifi Veren Eczane</th>
                                <th class="py-2.5 px-3 text-center w-24">Barem (MF)</th>
                                <th class="py-2.5 px-3 text-center w-28">Kalan Kutu</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Hariç</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Dahil</th>
                                <th class="py-2.5 px-3 text-center w-28">Miad Tarihi</th>
                                <th class="py-2.5 px-3">Not / Açıklama</th>
                                <th class="py-2.5 px-3 text-right w-40">Hızlı Katıl</th>
                            </tr>
                        `;
                        offersTbody = item.pazaryeri_teklifleri.map((off, oIdx) => {
                            const isCheapest = oIdx === 0;
                            const kdvli = (off.fiyat_kdvli != null ? off.fiyat_kdvli : (off.fiyat || 0));
                            const kdvsiz = (off.fiyat_kdvsiz != null ? off.fiyat_kdvsiz : (kdvli / (1.0 + (item.kdv_orani || 10.0) / 100.0)));
                            const katilLink = off.katil_url || `https://eczanetakas.com/katil/${off.teklif_no}`;
                            const offMatch = (typeof window.findTodayOrderMatchForOffer === 'function')
                                ? window.findTodayOrderMatchForOffer({
                                    teklif_no: off.teklif_no || '',
                                    barcode: item.barkod || '',
                                    urun_adi: item.urun_adi || '',
                                    katilindi: off.katilindi,
                                    katilinan_miktar: off.katilinan_miktar,
                                    siparis_durumu: off.siparis_durumu,
                                    siparis_depo: off.siparis_depo,
                                    siparis_miktar: off.siparis_miktar,
                                    siparis_saat: off.siparis_saat,
                                    siparis_masa: off.siparis_masa
                                }, 'ECZANETAKAS')
                                : null;
                            const isOffJoined = Boolean(offMatch && offMatch.isThisOfferJoined);
                            const offJoinedQty = offMatch ? (offMatch.siparis_miktar || 1) : 1;
                            const offJoinedSaat = offMatch ? (offMatch.siparis_saat || '') : '';
                            return `
                                <tr class="hover:bg-white transition ${isOffJoined ? 'bg-emerald-50/80 border-l-4 border-l-emerald-600' : (isCheapest ? 'bg-sky-50/40' : '')}">
                                    <td class="py-2.5 px-3 text-center">
                                        ${isCheapest ? '<span class="px-1.5 py-0.5 text-[10px] font-black rounded bg-sky-600 text-white uppercase tracking-wider">En Uygun</span>' : `<span class="text-slate-400 font-mono text-[11px]">#${oIdx + 1}</span>`}
                                    </td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-bold text-slate-900 flex flex-wrap items-center gap-1.5">
                                            <i class="fa-solid fa-hospital text-[11px] text-sky-600"></i>
                                            <span>${off.satici || 'Eczane'}</span>
                                            <span class="text-[10px] text-slate-500 font-mono">#${off.teklif_no || ''}</span>
                                            ${isOffJoined ? `<span class="px-1.5 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-black">✅ Katılındı (${offJoinedQty} Kt${offJoinedSaat ? ' • ' + offJoinedSaat : ''})</span>` : ''}
                                        </div>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-black bg-indigo-100 text-indigo-900 border border-indigo-200 font-mono">
                                            ${off.mf || 'MF Yok'}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-black bg-sky-100 text-sky-900 border border-sky-300">
                                            ${off.stok} Kutu
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-bold text-slate-800 font-mono">
                                        ${kdvsiz.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-extrabold text-sky-700 font-mono">
                                        ${kdvli.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-800 font-mono">
                                            <i class="fa-regular fa-calendar-check mr-1 text-[10px] text-slate-500"></i>${off.miad || '-'}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-[11px] text-slate-600">
                                        ${off.not ? `<span class="italic text-slate-500">${off.not}</span>` : '<span class="text-slate-400">-</span>'}
                                    </td>
                                    <td class="py-2.5 px-3 text-right">
                                        <div class="inline-flex items-center justify-end space-x-1">
                                            <div class="inline-flex items-center rounded-lg border border-slate-300 bg-white overflow-hidden">
                                                <button type="button" onclick="stepOfferJoinQty('etJoinQty_${off.teklif_no}', -1, ${off.stok || 99})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">-</button>
                                                <input type="number" id="etJoinQty_${off.teklif_no}" value="1" min="1" max="${off.stok || 99}" class="w-10 text-center text-[11px] font-black text-slate-800 focus:outline-none py-0.5" />
                                                <button type="button" onclick="stepOfferJoinQty('etJoinQty_${off.teklif_no}', 1, ${off.stok || 99})" class="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100 font-black text-xs cursor-pointer">+</button>
                                            </div>
                                            ${isOffJoined ? `
                                                <button type="button" onclick="joinEczaneTakasOfferDirect('${off.teklif_no}', '${item.barkod}', '${safeItemName}', ${off.stok || 99}, this)" class="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow-2xs transition cursor-pointer">
                                                    <i class="fa-solid fa-circle-check mr-1 text-[10px]"></i>Katılındı (${offJoinedQty} Kt)
                                                </button>
                                            ` : `
                                                <button type="button" onclick="joinEczaneTakasOfferDirect('${off.teklif_no}', '${item.barkod}', '${safeItemName}', ${off.stok || 99}, this)" class="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-black bg-sky-600 hover:bg-sky-700 text-white shadow-2xs transition cursor-pointer">
                                                    <i class="fa-solid fa-bolt mr-1 text-[10px] text-amber-200"></i>Katıl
                                                </button>
                                            `}
                                            <button type="button" onclick="openAuthenticatedPortal('ECZANETAKAS', '${katilLink}')" class="px-1.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-[10px] font-bold cursor-pointer" title="Hazır oturumla aç">↗</button>
                                        </div>
                                    </td>
                                </tr>
                            `;
                        }).join('');
                    } else {
                        tableHeaderHtml = `
                            <tr>
                                <th class="py-2.5 px-3 text-center w-20">Sıra</th>
                                <th class="py-2.5 px-3">Satıcı (Eczane / Mağaza)</th>
                                <th class="py-2.5 px-3 text-center w-24">Stok</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Hariç</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Dahil</th>
                                <th class="py-2.5 px-3 text-center w-28">Miad</th>
                                <th class="py-2.5 px-3">Kargo & Koşullar</th>
                            </tr>
                        `;
                        offersTbody = item.pazaryeri_teklifleri.map((off, oIdx) => {
                            const isCheapest = oIdx === 0;
                            const ratingTag = off.puan ? `
                                <span class="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-100 text-amber-800 ml-1.5 border border-amber-200" title="Satıcı Puanı: ${off.puan.toFixed(1)} / 10">
                                    <i class="fa-solid fa-star text-[9px] text-amber-500 mr-0.5"></i>${off.puan.toFixed(1)}
                                </span>
                            ` : '';

                            const miadDisplay = (off.miad && off.miad !== '-') ? `
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-800 font-mono">
                                    <i class="fa-regular fa-calendar-check mr-1 text-[10px] text-slate-500"></i>${off.miad}
                                </span>
                            ` : '<span class="text-slate-400 font-mono">-</span>';

                            const termsList = [];
                            if (off.min_tutar && off.min_tutar > 0) termsList.push(`Min: <strong>${off.min_tutar} ₺</strong>`);
                            if (off.ucretsiz_kargo && off.ucretsiz_kargo > 0) termsList.push(`<span class="text-emerald-700 font-semibold">${off.ucretsiz_kargo} ₺ Kargo Bedava</span>`);
                            if (off.kargo) termsList.push(`<span class="text-slate-500">${off.kargo}</span>`);
                            if (off.e_fatura) termsList.push(`<span class="text-purple-700 font-bold">e-Fatura</span>`);

                            const termsHtml = termsList.length > 0 ? termsList.join(' • ') : '<span class="text-slate-400">-</span>';
                            const noteHtml = off.aciklama ? `<div class="text-[10px] text-slate-500 italic mt-0.5 truncate max-w-sm" title="${off.aciklama}">${off.aciklama}</div>` : '';

                            return `
                                <tr class="hover:bg-white transition ${isCheapest ? 'bg-emerald-50/40' : ''}">
                                    <td class="py-2.5 px-3 text-center">
                                        ${isCheapest ? '<span class="px-1.5 py-0.5 text-[10px] font-black rounded bg-emerald-600 text-white uppercase tracking-wider">En Uygun</span>' : `<span class="text-slate-400 font-mono text-[11px]">#${oIdx + 1}</span>`}
                                    </td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-bold text-slate-900 flex items-center">
                                            <i class="fa-solid fa-shop text-[11px] text-slate-400 mr-1.5"></i>
                                            <span>${off.satici}</span>
                                            ${ratingTag}
                                        </div>
                                        ${noteHtml}
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${off.stok > 5 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
                                            ${off.stok} Kutu
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-bold text-slate-800 font-mono">
                                        ${off.fiyat_kdvsiz.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-extrabold text-emerald-700 font-mono">
                                        ${off.fiyat_kdvli.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        ${miadDisplay}
                                    </td>
                                    <td class="py-2.5 px-3 text-[11px] text-slate-600">
                                        ${termsHtml}
                                    </td>
                                </tr>
                            `;
                        }).join('');
                    }

                    trOffers.innerHTML = `
                        <td colspan="8" class="p-3 sm:p-4">
                            <div class="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden">
                                <div class="px-4 py-3 border-b flex flex-wrap items-center justify-between gap-2 ${themeHeader}">
                                    <div class="flex items-center space-x-2 font-bold text-xs">
                                        <i class="fa-solid ${iconHeader} text-sm"></i>
                                        <span>${isEczatrend ? `Eczatrend — Ortak Alım Grubu Teklifleri & Barem Kademeleri (${item.pazaryeri_teklifleri.length} Teklif)` : isEczanetakas ? `EczaneTakas — Açık Teklifler & Satıcı Eczaneler (${item.pazaryeri_teklifleri.length} Teklif)` : `${item.depo_adi} — Tüm Satıcı Eczane Teklifleri (${item.pazaryeri_teklifleri.length} Farklı Satıcı)`}</span>
                                    </div>
                                    <div class="text-[11px] font-medium text-slate-600 flex items-center space-x-2">
                                        <span>KDV Oranı: <strong>%${item.kdv_orani}</strong></span>
                                        <span>•</span>
                                        <span>Fiyata Göre Sıralı (En Düşük &rarr; En Yüksek)</span>
                                    </div>
                                </div>
                                <div class="overflow-x-auto max-h-72 overflow-y-auto divide-y divide-slate-100">
                                    <table class="w-full text-left text-xs">
                                        <thead class="bg-slate-100/80 text-[11px] font-bold text-slate-600 sticky top-0 backdrop-blur-xs">
                                            ${tableHeaderHtml}
                                        </thead>
                                        <tbody class="divide-y divide-slate-100 font-sans">
                                            ${offersTbody}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </td>
                    `;
                    tableBody.appendChild(trOffers);
                }
            });

            // Simülatörü ve EczaneTakas Kampanya Açma barını güncelle
            selectedDepoForSim = data.en_avantajli_depo || (data.sonuclar[0] ? data.sonuclar[0].depo : null);
            updateSimulator();
            initEtCampaignForCurrentReport(data);

            // Tria / Botanik / TEBEOS Eczane Raf Stoğu & Aylık Satış / Çıkış Hızı Paneli
            const otoInfo = data.otomasyon_bilgisi || data.botanik_bilgisi || data.tria_bilgisi;
            renderTriaAnalysis(otoInfo);

            // SGK Eşdeğer Grubu ve Muadiller Analizi (Canlı MF Kârlılık, Raf Stoğu ve Satış Hızı)
            loadEquivalentsAnalysis(
                data.barkod || data.barcode,
                (otoInfo && otoInfo.mal_kodu) || '',
                data.esdegerler || [],
                data.esdeger_kodu || '',
                kamuKari,
                data.en_karli_muadil,
                data.muadil_kar_avantaji
            );

            results.classList.remove('hidden');
        }

        // ================= Farma Radar Logo Tıklaması -> Sıfır Anasayfa & Temiz Arama Motoru =================
        function resetToHomeSearch() {
            if (typeof switchMainView === 'function') {
                switchMainView('depo');
            }
            if (typeof toggleSideWidget === 'function') {
                toggleSideWidget(false);
            }
            ['esdegerModal', 'settingsModal', 'multiDepotCartModal', 'endOfDaySummaryModal', 'bulkOrderModal', 'quickFinalizeModal', 'bulkFinalizeModal'].forEach(id => {
                const m = document.getElementById(id);
                if (m) {
                    m.classList.add('hidden');
                    if (m.style && m.style.display === 'flex') m.style.display = 'none';
                }
            });
            ['suggestBox', 'productSelection', 'results', 'loading'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.classList.add('hidden');
            });
            const sInput = document.getElementById('searchInput');
            if (sInput) {
                sInput.value = '';
                setTimeout(() => sInput.focus(), 50);
            }
            const mInput = document.getElementById('marketSearchInput');
            if (mInput) {
                mInput.value = '';
            }
            currentReport = null;
            window.lastDepoSearchQuery = '';
            window.lastDepoSearchBarcode = '';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // ================= Eczane Otomasyonu (Botanik & Tria) Analiz & Raf Stoğu Görselleştirme =================
        window.currentOtomasyonSource = 'TRIA';
        window.currentOtomasyonMovementsTab = 'cikis';

        function openCurrentOtomasyonSettings() {
            const src = (window.currentOtomasyonSource || window.activeOtomasyon || 'TRIA').toUpperCase();
            if (src === 'TEBEOS') openSettingsModal('tebeos');
            else if (src === 'TRIA') openSettingsModal('tria');
            else openSettingsModal('botanik');
        }

        function switchOtomasyonMovementsTab(tab) {
            window.currentOtomasyonMovementsTab = tab;
            const btnCikis = document.getElementById('tabBtnCikislar');
            const btnGiris = document.getElementById('tabBtnGirisler');
            const btnBoth = document.getElementById('tabBtnBoth');
            const btnMuadil = document.getElementById('tabBtnMuadiller');
            const boxCikis = document.getElementById('boxCikislarView');
            const boxGiris = document.getElementById('boxGirislerView');
            const boxMuadil = document.getElementById('boxMuadillerView');
            const legendCikis = document.getElementById('cikisLegend');
            const legendGiris = document.getElementById('girisLegend');
            const legendMuadil = document.getElementById('muadilLegend');
            const badgeGiris = document.getElementById('badgeGirisCount');
            const badgeMuadil = document.getElementById('badgeMuadilCount');

            if (btnCikis) btnCikis.className = 'px-2.5 py-1 rounded-lg text-[11px] font-bold bg-indigo-50/90 hover:bg-indigo-100 text-indigo-800 border border-indigo-200/80 transition flex items-center space-x-1 cursor-pointer';
            if (btnGiris) btnGiris.className = 'px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-50/90 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 transition flex items-center space-x-1 cursor-pointer';
            if (btnMuadil) btnMuadil.className = 'px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-50/90 hover:bg-amber-100 text-amber-900 border border-amber-200/80 transition flex items-center space-x-1 cursor-pointer';
            if (badgeGiris) badgeGiris.className = 'px-1.5 py-0.2 rounded-full text-[9px] font-extrabold bg-emerald-200/80 text-emerald-900';
            if (badgeMuadil) badgeMuadil.className = 'px-1.5 py-0.2 rounded-full text-[9px] font-extrabold bg-amber-200 text-amber-950';

            if (boxCikis) boxCikis.classList.add('hidden');
            if (boxGiris) boxGiris.classList.add('hidden');
            if (boxMuadil) boxMuadil.classList.add('hidden');
            if (legendCikis) legendCikis.classList.add('hidden');
            if (legendGiris) legendGiris.classList.add('hidden');
            if (legendMuadil) legendMuadil.classList.add('hidden');

            if (tab === 'cikis') {
                if (btnCikis) btnCikis.className = 'px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-indigo-600 text-white shadow-sm transition flex items-center space-x-1 cursor-pointer';
                if (boxCikis) boxCikis.classList.remove('hidden');
                if (legendCikis) legendCikis.classList.remove('hidden');
            } else if (tab === 'giris') {
                if (btnGiris) btnGiris.className = 'px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-emerald-600 text-white shadow-sm transition flex items-center space-x-1 cursor-pointer';
                if (badgeGiris) badgeGiris.className = 'px-1.5 py-0.2 rounded-full text-[9px] font-extrabold bg-white text-emerald-800';
                if (boxGiris) boxGiris.classList.remove('hidden');
                if (legendGiris) legendGiris.classList.remove('hidden');
            } else if (tab === 'both') {
                if (boxCikis) boxCikis.classList.remove('hidden');
                if (boxGiris) boxGiris.classList.remove('hidden');
                if (legendCikis) legendCikis.classList.remove('hidden');
                if (legendGiris) legendGiris.classList.remove('hidden');
            } else if (tab === 'muadil') {
                if (btnMuadil) btnMuadil.className = 'px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-amber-500 text-white shadow-sm transition flex items-center space-x-1 cursor-pointer';
                if (badgeMuadil) badgeMuadil.className = 'px-1.5 py-0.2 rounded-full text-[9px] font-extrabold bg-white text-amber-900';
                if (boxMuadil) boxMuadil.classList.remove('hidden');
                if (legendMuadil) legendMuadil.classList.remove('hidden');
            }
        }

        function scrollToMuadillerTab() {
            switchOtomasyonMovementsTab('muadil');
            const targetEl = document.getElementById('tabBtnMuadiller') || document.getElementById('boxMuadillerView');
            if (targetEl) {
                targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        function _buildCompactMuadilRowHtml(item, closeModalOnSelect = false) {
            const isCur = !!item.is_current;
            const isBestDeal = !!item.is_best_deal;
            const mName = item.urun_adi || item.ad || '';
            const safeName = mName.replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
            const searchCode = item.barkod || item.kod || item.mal_kodu || '';

            const psf = item.psf || item.etiket_fiyati || 0;
            const ksf = item.ksf || item.kamu_fiyati || (psf > 0 ? (psf * (1.0 - ((item.kamu_iskontosu || 0) / 100.0))) : 0);
            const netKdvli = item.net_birim_maliyet_kdvli || item.birim_maliyet_kdvli || 0;
            const kamuKari = (item.kamu_kari !== undefined && item.kamu_kari !== null) ? item.kamu_kari : (ksf > 0 && netKdvli > 0 ? (ksf - netKdvli) : 0);
            const perakendeKari = (item.perakende_kari !== undefined && item.perakende_kari !== null) ? item.perakende_kari : (psf > 0 && netKdvli > 0 ? (psf - netKdvli) : 0);
            const karFarki = item.kar_farki || 0;
            const karArtis = item.kar_artis_yuzdesi || 0;

            let cardBorder = 'border-slate-200 bg-white hover:border-indigo-300 hover:bg-slate-50/70';
            if (isBestDeal) {
                cardBorder = 'border-2 border-amber-400 bg-gradient-to-r from-amber-50/80 via-yellow-50/40 to-emerald-50/50 shadow-2xs';
            } else if (isCur) {
                cardBorder = 'border-indigo-300 bg-indigo-50/50';
            } else if (karFarki > 0) {
                cardBorder = 'border-emerald-300 bg-gradient-to-r from-emerald-50/50 to-teal-50/30 hover:border-emerald-400';
            }

            const stockBadge = item.stok > 0
                ? `<span class="px-1.5 py-0.5 rounded text-[9.5px] leading-none font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300">Stok: ${item.stok} Kt</span>`
                : `<span class="px-1.5 py-0.5 rounded text-[9.5px] leading-none font-semibold bg-slate-100 text-slate-500 border border-slate-200">Stok: 0</span>`;

            const salesBadge = `<span class="px-1.5 py-0.5 rounded text-[9.5px] leading-none font-bold bg-sky-50 text-sky-800 border border-sky-200">30G: ${item.cikis_30gun || 0} Kt</span>`;

            const rawBestMf = (item.en_iyi_mf && item.en_iyi_mf !== '-' && item.en_iyi_mf !== 'YOK') ? item.en_iyi_mf : null;
            const rawFullMf = (item.mf && item.mf !== '-' && item.mf !== 'YOK') ? item.mf : null;
            const liveMf = rawBestMf || rawFullMf;
            let mfPill = '';
            if (liveMf) {
                mfPill = `<span class="px-1.5 py-0.5 rounded text-[9.5px] leading-none font-black bg-amber-500 text-white" title="Canlı MF: ${rawFullMf || liveMf}"><i class="fa-solid fa-gift text-[8px] mr-0.5"></i>${rawFullMf || liveMf} ${item.depo ? '(' + String(item.depo).substring(0, 6) + ')' : ''}</span>`;
            } else if (item.gecmis_mf_var && (item.gecmis_mf_kisa || item.gecmis_mf_bilgi)) {
                mfPill = `<span class="px-1.5 py-0.5 rounded text-[9.5px] leading-none font-bold bg-indigo-100 text-indigo-800 border border-indigo-200" title="${item.gecmis_mf_bilgi || ''}">Son MF: ${item.gecmis_mf_kisa || 'Var'}</span>`;
            }

            const actionClick = closeModalOnSelect
                ? `closeEsdegerModal(); selectAndSearch('${searchCode}', '${safeName}')`
                : `selectAndSearch('${searchCode}', '${safeName}')`;

            return `
                <div class="rounded-xl px-3 py-2 border ${cardBorder} transition group">
                    <!-- 1. Satır: Tam İlaç İsmi + Durum Rozetleri + Kıyasla Butonu -->
                    <div class="flex items-start justify-between gap-2">
                        <div class="min-w-0 flex-1 cursor-pointer" onclick="${actionClick}">
                            <div class="flex flex-wrap items-center gap-1.5">
                                ${isBestDeal ? `<span class="px-1.5 py-0.2 rounded text-[9px] font-black bg-amber-500 text-white uppercase shrink-0"><i class="fa-solid fa-trophy mr-0.5"></i>EN KÂRLI</span>` : ''}
                                ${isCur ? `<span class="px-1.5 py-0.2 rounded text-[9px] font-black bg-indigo-600 text-white uppercase shrink-0">Aranan</span>` : ''}
                                ${(!isCur && karFarki > 0) ? `<span class="px-1.5 py-0.2 rounded text-[9px] font-black bg-emerald-600 text-white shrink-0">+${karFarki.toFixed(2)} ₺ Avantaj ${karArtis > 0 ? '(%' + karArtis + ')' : ''}</span>` : ''}
                                <h4 class="text-xs font-extrabold text-slate-900 group-hover:text-indigo-700 leading-snug break-words">${mName}</h4>
                            </div>
                        </div>
                        <button type="button" onclick="${actionClick}" class="px-2.5 py-1 rounded-lg text-[10px] font-extrabold bg-indigo-600 hover:bg-indigo-700 text-white transition cursor-pointer shrink-0 flex items-center space-x-1 shadow-2xs" title="Bu muadili tüm depolarda karşılaştır">
                            <i class="fa-solid fa-magnifying-glass-dollar text-[9px]"></i>
                            <span>Kıyasla</span>
                        </button>
                    </div>

                    <!-- 2. Satır: Stok, Çıkış, MF ve Renkli Alış/Kâr Hapları -->
                    <div class="flex flex-wrap items-center justify-between gap-1.5 mt-1.5 pt-1 border-t border-slate-200/60 text-[10px]">
                        <div class="flex flex-wrap items-center gap-1">
                            ${stockBadge}
                            ${salesBadge}
                            ${mfPill}
                        </div>
                        <div class="flex flex-wrap items-center gap-1 font-mono">
                            <span class="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200 font-bold" title="KDV Dahil Net Birim Alış">Alış: <strong>${netKdvli.toFixed(2)}₺</strong></span>
                            <span class="px-1.5 py-0.5 rounded ${kamuKari >= 0 ? 'bg-blue-50 text-blue-800 border-blue-200' : 'bg-rose-50 text-rose-700 border-rose-200'} border font-bold" title="SGK Reçeteli Kutu Kârı">SGK: <strong>${kamuKari >= 0 ? '+' : ''}${kamuKari.toFixed(2)}₺</strong></span>
                            <span class="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold" title="Perakende Elden Kutu Kârı">Elden: <strong>+${perakendeKari.toFixed(2)}₺</strong></span>
                        </div>
                    </div>
                </div>
            `;
        }

        async function loadEquivalentsAnalysis(barcode, malKodu, fallbackEquivalents, fallbackGrupKodu, currentKamuKari, directEnKarliMuadil, directMuadilAvantaji) {
            const gridEl = document.getElementById('otomasyonMuadillerGrid');
            const badgeCountEl = document.getElementById('badgeMuadilCount');
            const darkGrupEl = document.getElementById('darkEsdegerKodu');
            const topEqBtn = document.getElementById('resEquivalentsBtn');
            const topEqBtnText = document.getElementById('resEquivalentsBtnText');
            const bannerEl = document.getElementById('boxMuadilHighlightBanner');
            const muadilAlertEl = document.getElementById('resMuadilProfitOpportunity');
            const bestMuadilNameEl = document.getElementById('resBestMuadilName');
            const bestMuadilGainEl = document.getElementById('resBestMuadilGain');

            if (!gridEl) return;

            gridEl.innerHTML = `
                <div class="bg-amber-50/50 border border-amber-200 rounded-xl p-3 text-center text-xs text-amber-800">
                    <i class="fa-solid fa-spinner animate-spin mr-1.5 text-amber-600"></i>Eşdeğer ilaçlar ve canlı depo kârlılıkları taranıyor...
                </div>
            `;

            let eqData = null;
            if (fallbackEquivalents && fallbackEquivalents.length > 0) {
                const hasValidBarcodes = fallbackEquivalents.some(e => e.barkod && String(e.barkod).length >= 8 && /^\\d+$/.test(String(e.barkod)));
                const hasLiveMfChecked = fallbackEquivalents.some(e => e.live_mf_checked || (e.en_iyi_mf && e.en_iyi_mf !== 'YOK' && e.en_iyi_mf !== '-') || (e.mf && e.mf !== 'YOK' && e.mf !== '-'));
                if (hasValidBarcodes && hasLiveMfChecked) {
                    eqData = {
                        found: true,
                        esdeger_kodu: fallbackGrupKodu || 'DEPO_ESDEGER',
                        count: fallbackEquivalents.length,
                        en_karli_muadil: directEnKarliMuadil || null,
                        muadil_kar_avantaji: directMuadilAvantaji || 0.0,
                        current_kamu_kari: currentKamuKari || 0.0,
                        muadiller: fallbackEquivalents
                    };
                }
            }

            if (!eqData) {
                try {
                    const target = barcode || malKodu || '';
                    if (target) {
                        const resp = await fetch(`/api/products/equivalents?barcode=${encodeURIComponent(target)}&kod=${encodeURIComponent(malKodu || '')}`);
                        if (resp.ok) {
                            const json = await resp.json();
                            if (json && json.found && json.muadiller && json.muadiller.length > 0) {
                                eqData = json;
                            }
                        }
                    }
                } catch (e) {
                    console.warn('[Muadiller] Otomasyon eşdeğer sorgulama hatası:', e);
                }
            }

            if (!eqData && fallbackEquivalents && fallbackEquivalents.length > 0) {
                eqData = {
                    found: true,
                    esdeger_kodu: fallbackGrupKodu || 'DEPO_ESDEGER',
                    count: fallbackEquivalents.length,
                    en_karli_muadil: directEnKarliMuadil || null,
                    muadil_kar_avantaji: directMuadilAvantaji || 0.0,
                    current_kamu_kari: currentKamuKari || 0.0,
                    muadiller: fallbackEquivalents
                };
            }

            if (eqData && eqData.muadiller && typeof currentReport === 'object' && currentReport) {
                currentReport.esdegerler = eqData.muadiller;
                if (eqData.esdeger_kodu) currentReport.esdeger_kodu = eqData.esdeger_kodu;
                if (eqData.en_karli_muadil) currentReport.en_karli_muadil = eqData.en_karli_muadil;
                if (eqData.muadil_kar_avantaji !== undefined) currentReport.muadil_kar_avantaji = eqData.muadil_kar_avantaji;
            }

            if (!eqData || !eqData.muadiller || eqData.muadiller.length === 0) {
                if (badgeCountEl) badgeCountEl.innerText = '0';
                if (darkGrupEl) darkGrupEl.innerText = fallbackGrupKodu || 'Yok';
                if (bannerEl) { bannerEl.innerHTML = ''; bannerEl.classList.add('hidden'); }
                if (muadilAlertEl) { muadilAlertEl.classList.remove('inline-flex'); muadilAlertEl.classList.add('hidden'); }
                gridEl.innerHTML = `
                    <div class="bg-slate-50 border border-slate-200 rounded-xl p-4 text-center text-xs text-slate-500">
                        <i class="fa-solid fa-circle-info text-amber-500 mr-1.5"></i>
                        Bu ilacın kayıtlı bir SGK eşdeğer grubu veya canlı muadili bulunamadı.
                    </div>
                `;
                return;
            }

            const muadiller = eqData.muadiller;
            const count = muadiller.length;
            if (badgeCountEl) badgeCountEl.innerText = count;
            if (darkGrupEl) darkGrupEl.innerText = eqData.esdeger_kodu || 'SGK Grubu';
            if (topEqBtn && topEqBtnText) {
                topEqBtn.classList.remove('hidden');
                topEqBtn.classList.add('inline-flex');
                topEqBtnText.innerText = `Muadiller (${count})`;
                topEqBtn.onclick = function() { openEsdegerModal(); };
            }

            const bestM = eqData.en_karli_muadil || directEnKarliMuadil;
            const bestGain = (eqData.muadil_kar_avantaji !== undefined && eqData.muadil_kar_avantaji !== null) ? eqData.muadil_kar_avantaji : (directMuadilAvantaji || 0);

            // 1. Üst Arama Sonucu Bildirim Rozeti (#resMuadilProfitOpportunity)
            if (bestM && bestGain > 0) {
                if (bestMuadilNameEl) bestMuadilNameEl.innerText = bestM.urun_adi || bestM.ad || 'Muadil İlaç';
                if (bestMuadilGainEl) bestMuadilGainEl.innerText = `+${bestGain.toFixed(2)} ₺`;
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('hidden');
                    muadilAlertEl.classList.add('inline-flex');
                }
            } else {
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('inline-flex');
                    muadilAlertEl.classList.add('hidden');
                }
            }

            // 2. Muadiller Sekmesi İçi Kompakt Vurgu Bannerı (#boxMuadilHighlightBanner)
            if (bannerEl) {
                if (bestM && bestGain > 0) {
                    const mName = bestM.urun_adi || bestM.ad || '';
                    const mSafeName = mName.replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
                    const mCode = bestM.barkod || bestM.kod || bestM.mal_kodu || '';
                    const mLiveMf = (bestM.en_iyi_mf && bestM.en_iyi_mf !== 'YOK' && bestM.en_iyi_mf !== '-') ? bestM.en_iyi_mf : ((bestM.mf && bestM.mf !== 'YOK' && bestM.mf !== '-') ? bestM.mf : 'Barem Yok');
                    const mCostKdvli = bestM.net_birim_maliyet_kdvli || bestM.birim_maliyet_kdvli || 0;

                    bannerEl.innerHTML = `
                        <div class="px-3 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white shadow-2xs flex items-center justify-between gap-2">
                            <div class="min-w-0 flex-1">
                                <div class="text-[9.5px] uppercase tracking-wider font-black text-amber-100 flex items-center gap-1">
                                    <i class="fa-solid fa-trophy text-yellow-200"></i>
                                    <span>EN KÂRLI MUADİL FIRSATI (+${bestGain.toFixed(2)} ₺/Kt Avantaj)</span>
                                </div>
                                <div class="text-xs font-black text-white truncate mt-0.5">${mName}</div>
                                <div class="text-[10px] text-amber-100 flex items-center gap-2">
                                    <span>MF: <strong>${mLiveMf}</strong> ${bestM.depo ? '(' + bestM.depo + ')' : ''}</span>
                                    <span>•</span>
                                    <span>Net Alış: <strong>${mCostKdvli.toFixed(2)} ₺</strong></span>
                                </div>
                            </div>
                            <button type="button" onclick="selectAndSearch('${mCode}', '${mSafeName}')" class="px-2.5 py-1.5 rounded-lg bg-white hover:bg-amber-50 text-amber-950 font-black text-[11px] transition cursor-pointer shrink-0 shadow-2xs">
                                Kıyasla &rarr;
                            </button>
                        </div>
                    `;
                    bannerEl.classList.remove('hidden');
                } else {
                    bannerEl.innerHTML = '';
                    bannerEl.classList.add('hidden');
                }
            }

            // 3. Muadil Satırlarını Kompakt ve Renkli Olarak Render Et
            gridEl.innerHTML = muadiller.map(item => _buildCompactMuadilRowHtml(item, false)).join('');
        }

        function renderTriaAnalysis(tria) {
            const stockQtyEl = document.getElementById('triaStockQty');
            const stockBoxEl = document.getElementById('triaStockMetricBox');
            const statusBadgeEl = document.getElementById('triaStockStatusBadge');
            const gridEl = document.getElementById('triaMonthlyGrid');
            const girisGridEl = document.getElementById('otomasyonGirislerGrid');
            const girisBadgeEl = document.getElementById('badgeGirisCount');
            const avgMonthlyEl = document.getElementById('triaAvgMonthly');
            const avgDailyEl = document.getElementById('triaAvgDaily');
            const daysLeftEl = document.getElementById('triaDaysLeft');
            const suggestedEl = document.getElementById('triaOrderSuggested');
            const brandBadgeEl = document.getElementById('otoBrandBadge');
            const brandTextEl = document.getElementById('otoBrandText');
            const hostSubBadgeEl = document.getElementById('triaHostSubBadge');

            if (!tria || !tria.found) {
                stockQtyEl.innerText = '--';
                if (stockBoxEl) stockBoxEl.className = 'bg-slate-50 rounded-xl p-2.5 border border-slate-200 shadow-2xs transition';
                statusBadgeEl.className = 'px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase bg-slate-200 text-slate-600';
                statusBadgeEl.innerText = (!tria || !tria.connected) ? 'BAĞLANTI YOK' : 'KAYIT YOK';
                avgMonthlyEl.innerText = '--';
                avgDailyEl.innerText = '-- / Gün';
                daysLeftEl.innerText = '--';
                suggestedEl.innerText = '--';
                if (girisBadgeEl) girisBadgeEl.innerText = '0';
                gridEl.innerHTML = `
                    <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center col-span-full text-xs text-slate-500">
                        <i class="fa-solid fa-circle-info mr-1.5 text-amber-500"></i>
                        ${tria && tria.message ? tria.message : 'Bu ilaç eczane otomasyonunda bulunamadı veya henüz satış/stok hareketi oluşmamış.'}
                    </div>
                `;
                if (girisGridEl) {
                    girisGridEl.innerHTML = `
                        <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center col-span-full text-xs text-slate-500">
                            Depo alış faturaları bulunamadı.
                        </div>
                    `;
                }
                return;
            }

            // 0. Otomasyon Kaynağı ve Başlık Rozeti
            window.currentOtomasyonSource = tria.kaynak || 'BOTANIK';
            if (tria.kaynak === 'TEBEOS') {
                if (brandBadgeEl) brandBadgeEl.className = 'inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold tracking-wider uppercase bg-sky-50 text-sky-700 border border-sky-200';
                if (brandTextEl) brandTextEl.innerText = 'TEBEOS STOK & 6 AYLIK ÖZET';
                if (hostSubBadgeEl) hostSubBadgeEl.innerText = `PostgreSQL`;
            } else if (tria.kaynak === 'BOTANIK') {
                if (brandBadgeEl) brandBadgeEl.className = 'inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold tracking-wider uppercase bg-emerald-50 text-emerald-700 border border-emerald-200';
                if (brandTextEl) brandTextEl.innerText = 'BOTANİK STOK & 6 AYLIK ÖZET';
                if (hostSubBadgeEl) hostSubBadgeEl.innerText = `MS SQL`;
            } else {
                if (brandBadgeEl) brandBadgeEl.className = 'inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold tracking-wider uppercase bg-amber-50 text-amber-800 border border-amber-200';
                if (brandTextEl) brandTextEl.innerText = 'TRIA STOK & 6 AYLIK ÖZET';
                if (hostSubBadgeEl) hostSubBadgeEl.innerText = (tria.mal_kodu ? `Kod: ${tria.mal_kodu}` : 'Oracle');
            }

            // 1. Raf Stoğu & Dinamik Renkli Kutu
            stockQtyEl.innerText = tria.stok;

            if (tria.hareketsiz_kart) {
                if (stockBoxEl) stockBoxEl.className = 'bg-gradient-to-br from-slate-50 to-slate-100/80 rounded-xl p-2.5 border border-slate-300 shadow-2xs transition';
                statusBadgeEl.className = 'px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-slate-200 text-slate-700';
                statusBadgeEl.innerText = 'HAREKET YOK';
                daysLeftEl.innerText = '-';
                avgMonthlyEl.innerText = '0 Kt';
                avgDailyEl.innerText = '~0 / Gün';
                suggestedEl.innerText = '1 Kt';
            } else if (tria.stok <= 0) {
                if (stockBoxEl) stockBoxEl.className = 'bg-gradient-to-br from-rose-50 via-red-50/70 to-white rounded-xl p-2.5 border border-rose-300 shadow-2xs transition';
                statusBadgeEl.className = 'px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-rose-600 text-white';
                statusBadgeEl.innerText = 'TÜKENDİ';
            } else if (tria.kalan_gun < 10) {
                if (stockBoxEl) stockBoxEl.className = 'bg-gradient-to-br from-amber-50 via-orange-50/70 to-white rounded-xl p-2.5 border border-amber-300 shadow-2xs transition';
                statusBadgeEl.className = 'px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-amber-500 text-white';
                statusBadgeEl.innerText = 'KRİTİK AZ';
            } else {
                if (stockBoxEl) stockBoxEl.className = 'bg-gradient-to-br from-emerald-50 via-teal-50/60 to-white rounded-xl p-2.5 border border-emerald-300 shadow-2xs transition';
                statusBadgeEl.className = 'px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-emerald-600 text-white';
                statusBadgeEl.innerText = 'STOKTA';
            }

            // 2. Metrikler
            if (!tria.hareketsiz_kart) {
                avgMonthlyEl.innerText = `${tria.ort_aylik_cikis} Kt`;
                avgDailyEl.innerText = `~${tria.ort_gunluk_cikis} / Gün`;
                
                if (tria.stok <= 0) {
                    daysLeftEl.innerText = '0 Gün';
                } else if (tria.kalan_gun >= 90) {
                    daysLeftEl.innerText = '> 90 Gün';
                } else {
                    daysLeftEl.innerText = `~${tria.kalan_gun} Gün`;
                }

                suggestedEl.innerText = `${tria.onerilen_siparis} Kt`;
            }

            if (tria.onerilen_siparis > 0) {
                simQtyInput.value = tria.onerilen_siparis;
                updateSimulator();
            } else if (tria.hareketsiz_kart) {
                simQtyInput.value = 1;
                updateSimulator();
            }

            // 3. ÇIKIŞLAR: Renklendirilmiş Aylık Satış Kartları Grid (6 Takvim Ayı)
            const cikislar = tria.aylik_cikislar || [];
            if (cikislar.length === 0) {
                gridEl.innerHTML = `
                    <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center col-span-full text-xs text-slate-500">
                        Son 6 ayda herhangi bir çıkış hareketi bulunamadı.
                    </div>
                `;
            } else {
                gridEl.innerHTML = cikislar.map(m => {
                    const nakitPct = m.toplam > 0 ? Math.round((m.nakit / m.toplam) * 100) : 0;
                    const recetePct = m.toplam > 0 ? (100 - nakitPct) : 0;
                    const boxStyle = m.is_current
                        ? 'bg-gradient-to-br from-indigo-50 via-sky-50/70 to-white border-indigo-300 ring-1 ring-indigo-200/60 shadow-2xs'
                        : (m.toplam > 0 ? 'bg-gradient-to-br from-white via-slate-50/60 to-indigo-50/20 border-slate-200 hover:border-indigo-300' : 'bg-slate-50/60 border-slate-200/70 opacity-75');

                    return `
                        <div class="${boxStyle} border rounded-xl p-2 flex flex-col justify-between transition">
                            <div class="flex items-center justify-between text-[10px] mb-1">
                                <span class="font-bold ${m.is_current ? 'text-indigo-900 font-extrabold' : 'text-slate-600'} truncate" title="${m.label}">
                                    ${m.label}
                                </span>
                                <span class="px-1.5 py-0.2 rounded-md font-black ${m.is_current ? 'bg-indigo-600 text-white' : (m.toplam > 0 ? 'bg-slate-800 text-white' : 'bg-slate-200 text-slate-600')} text-[10px] shrink-0 ml-1">
                                    ${m.toplam}
                                </span>
                            </div>
                            
                            <div class="my-1">
                                <div class="w-full bg-slate-200 rounded-full h-1.5 flex overflow-hidden">
                                    <div style="width: ${nakitPct}%" class="bg-emerald-500 h-full" title="Nakit: ${m.nakit} kutu (%${nakitPct})"></div>
                                    <div style="width: ${recetePct}%" class="bg-indigo-500 h-full" title="SGK: ${m.receteli} kutu (%${recetePct})"></div>
                                </div>
                            </div>

                            <div class="flex items-center justify-between text-[9px] pt-0.5">
                                <span class="px-1 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200/70 font-extrabold" title="Nakit Satış">${m.nakit} N</span>
                                <span class="px-1 py-0.2 rounded bg-indigo-50 text-indigo-700 border border-indigo-200/70 font-extrabold" title="SGK Reçeteli">${m.receteli} R</span>
                            </div>
                        </div>
                    `;
                }).join('');
            }

            // 4. ALIŞLAR (GİRİŞLER): Depoya Göre Renklendirilmiş Son Fatura Kartları
            const girisler = tria.son_girisler || [];
            if (girisBadgeEl) girisBadgeEl.innerText = girisler.length;

            if (girisGridEl) {
                if (girisler.length === 0) {
                    girisGridEl.innerHTML = `
                        <div class="bg-emerald-50/40 border border-emerald-200 rounded-xl p-3 text-center col-span-full text-xs text-emerald-800">
                            Son 6 ayda sisteme girilmiş kayıtlı depo faturası bulunamadı.
                        </div>
                    `;
                } else {
                    girisGridEl.innerHTML = girisler.map(g => {
                        const dUp = String(g.depo || '').toUpperCase();
                        let cardTheme = 'from-emerald-50/70 to-white border-emerald-200 border-l-4 border-l-emerald-500';
                        let depoTextCls = 'text-emerald-900';
                        if (dUp.includes('ALLIANCE')) {
                            cardTheme = 'from-sky-50/70 to-white border-sky-200 border-l-4 border-l-sky-500';
                            depoTextCls = 'text-sky-900';
                        } else if (dUp.includes('NEVZAT')) {
                            cardTheme = 'from-amber-50/70 to-white border-amber-200 border-l-4 border-l-amber-500';
                            depoTextCls = 'text-amber-900';
                        } else if (dUp.includes('ISKOOP') || dUp.includes('İSKOOP')) {
                            cardTheme = 'from-rose-50/70 to-white border-rose-200 border-l-4 border-l-rose-500';
                            depoTextCls = 'text-rose-900';
                        }
                        const mfBadge = g.mf > 0
                            ? `<span class="ml-1 px-1.5 py-0.2 rounded text-[9px] font-black bg-amber-500 text-white shadow-2xs">+${g.mf} MF</span>`
                            : `<span class="ml-1 px-1.5 py-0.2 rounded text-[8.5px] font-semibold bg-slate-100 text-slate-500">MF Yok</span>`;

                        return `
                            <div class="bg-gradient-to-br ${cardTheme} hover:shadow-xs border rounded-xl p-2.5 flex flex-col justify-between transition">
                                <div class="flex items-center justify-between text-[10px] mb-1.5 pb-1 border-b border-slate-200/60">
                                    <span class="font-extrabold ${depoTextCls} truncate" title="${g.depo}">${g.depo}</span>
                                    <span class="px-1.5 py-0.2 rounded bg-white/80 text-slate-600 border border-slate-200/70 font-mono text-[9px] font-bold shrink-0">${g.tarih}</span>
                                </div>

                                <div class="flex items-center justify-between gap-1">
                                    <div class="text-xs font-black text-slate-900 flex items-center flex-wrap">
                                        <span class="px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-900 border border-indigo-200 text-[10px] font-black">${g.adet} Kt</span>
                                        ${mfBadge}
                                    </div>
                                    <div class="px-2 py-0.5 rounded-lg bg-emerald-600 text-white text-[11px] font-black font-mono shadow-2xs" title="Fatura Birim Net Maliyet">
                                        ${g.maliyet.toFixed(2)} ₺
                                    </div>
                                </div>
                            </div>
                        `;
                    }).join('');
                }
            }
        }

        function setSuggestedQty() {
            const oto = currentReport ? (currentReport.otomasyon_bilgisi || currentReport.botanik_bilgisi || currentReport.tria_bilgisi) : null;
            if (!oto) {
                showToast('Bilgi', 'Öneri için otomasyon verisi bulunamadı.', 'error');
                return;
            }
            const qty = oto.onerilen_siparis > 0 ? oto.onerilen_siparis : Math.max(1, Math.round(oto.ort_aylik_cikis || 10));
            setSimulatorQty(qty);
            showToast('Önerilen Miktar Seçildi', `30 günlük güvenlik ihtiyacınıza göre ${qty} kutu sipariş miktarı belirlendi.`, 'success');
        }

        function toggleMfDetails() {
            const box = document.getElementById('simResultsBox');
            const icon = document.getElementById('mfToggleIcon');
            if (!box || !icon) return;
            if (box.classList.contains('hidden')) {
                box.classList.remove('hidden');
                icon.className = 'fa-solid fa-circle-chevron-up text-[10px]';
            } else {
                box.classList.add('hidden');
                icon.className = 'fa-solid fa-circle-chevron-down text-[10px]';
            }
        }

        async function openEsdegerModal() {
            if (!currentReport) return;
            const modal = document.getElementById('esdegerModal');
            const list = document.getElementById('modalEsdegerList');
            const countEl = document.getElementById('modalEsdegerCount');
            const kodEl = document.getElementById('modalEsdegerKodu');

            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
            }
            if (kodEl) kodEl.innerText = currentReport.esdeger_kodu ? `SGK Grubu: ${currentReport.esdeger_kodu}` : 'SGK Eşdeğer Grubu';

            let eqList = currentReport.esdegerler || [];
            const needsLiveRefresh = eqList.length === 0 || !eqList.some(e => e.live_mf_checked);

            function renderModalItems(items) {
                if (countEl) countEl.innerText = items.length;
                if (!list) return;
                if (items.length === 0) {
                    list.innerHTML = `
                        <div class="p-6 text-center text-slate-400 text-xs bg-white rounded-xl border border-dashed border-slate-200">
                            <i class="fa-solid fa-circle-exclamation text-xl text-slate-300 mb-1.5 block"></i>
                            Bu ilaç için SGK eşdeğer grubunda kayıtlı muadil ilaç bulunamadı.
                        </div>
                    `;
                    return;
                }
                list.innerHTML = items.map(eq => _buildCompactMuadilRowHtml(eq, true)).join('');
            }

            renderModalItems(eqList);

            if (needsLiveRefresh && currentReport.barkod) {
                try {
                    const resp = await fetch(`/api/products/equivalents?barcode=${encodeURIComponent(currentReport.barkod)}`);
                    if (resp.ok) {
                        const json = await resp.json();
                        if (json && json.found && json.muadiller && json.muadiller.length > 0) {
                            currentReport.esdegerler = json.muadiller;
                            if (json.esdeger_kodu) currentReport.esdeger_kodu = json.esdeger_kodu;
                            if (json.en_karli_muadil) currentReport.en_karli_muadil = json.en_karli_muadil;
                            if (json.muadil_kar_avantaji !== undefined) currentReport.muadil_kar_avantaji = json.muadil_kar_avantaji;
                            if (kodEl) kodEl.innerText = currentReport.esdeger_kodu ? `SGK Grubu: ${currentReport.esdeger_kodu}` : 'SGK Eşdeğer Grubu';
                            renderModalItems(json.muadiller);
                        }
                    }
                } catch (e) {}
            }
        }

        function closeEsdegerModal() {
            const modal = document.getElementById('esdegerModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
        }

        // ================= Simülatör & Depo Seçim Fonksiyonları =================
        function setSimulatorQty(qty) {
            if (simQtyInput) simQtyInput.value = qty;
            updateSimulator();
        }

        function onSimulatorChange() {
            updateSimulator();
        }

        let selectedRowIndex = null;

        function selectDepoForSimulation(rowIndex, ev) {
            if (ev) ev.stopPropagation();
            if (!currentReport || !currentReport.sonuclar || !currentReport.sonuclar[rowIndex]) return;
            selectedRowIndex = rowIndex;

            const simSelect = document.getElementById('simDepoSelect');
            if (simSelect) simSelect.value = String(rowIndex);

            // Tablo satırlarındaki seçili vurguyu ve butonları güncelle
            currentReport.sonuclar.forEach((it, idx) => {
                const trEl = document.getElementById(`depoRow_${idx}`);
                const btnEl = document.getElementById(`btnSelectDepoRow_${idx}`);
                const isBest = trEl && trEl.dataset.isBest === '1';
                const isSel = idx === rowIndex;
                if (trEl) {
                    if (isSel) {
                        trEl.className = isBest
                            ? 'bg-emerald-50/70 ring-2 ring-inset ring-emerald-500 font-medium transition'
                            : 'bg-indigo-50/60 ring-2 ring-inset ring-indigo-500 font-medium transition';
                    } else {
                        trEl.className = `hover:bg-slate-50/80 transition ${isBest ? 'bg-emerald-50/30 font-medium' : ''}`;
                    }
                }
                if (btnEl) {
                    if (isSel) {
                        btnEl.className = `px-2 py-0.5 text-[10px] ${isBest ? 'bg-emerald-600 text-white' : 'bg-indigo-600 text-white'} rounded-full font-bold uppercase tracking-wider cursor-pointer transition shadow-2xs`;
                        btnEl.innerHTML = '✓ Seçili';
                    } else {
                        btnEl.className = 'px-2 py-0.5 text-[10px] bg-slate-100 hover:bg-indigo-600 text-slate-700 hover:text-white border border-slate-300 hover:border-indigo-600 rounded-full font-bold transition cursor-pointer shadow-2xs';
                        btnEl.innerHTML = '🎯 Seç & Hesapla';
                    }
                }
            });

            // Sol karttaki Seçili / En Avantajlı Depo bannerını güncelle
            const selItem = currentReport.sonuclar[rowIndex];
            const isDefaultBest = (rowIndex === (window.defaultBestRowIndex || 0));
            const bestNameEl = document.getElementById('bestDepoName');
            const bestCostEl = document.getElementById('bestCost');
            const bestCostKdvliEl = document.getElementById('bestCostKdvli');
            const titleEl = document.getElementById('bestDealBannerTitle');
            const resetBtn = document.getElementById('btnResetToBestDeal');
            const bannerEl = document.getElementById('bestDealBanner');
            const iconBoxEl = document.getElementById('bestDealIconBox');
            const iconEl = document.getElementById('bestDealIcon');

            if (selItem && bestNameEl) {
                bestNameEl.innerText = selItem.depo_adi;
                if (bestCostEl) bestCostEl.innerHTML = `${(selItem.net_birim_maliyet || 0).toFixed(2)} ₺ <span class="text-[10px] font-normal">(KDV H.)</span>`;
                if (bestCostKdvliEl) bestCostKdvliEl.innerText = `${(selItem.net_birim_maliyet_kdvli || 0).toFixed(2)} ₺`;
                if (isDefaultBest) {
                    if (titleEl) { titleEl.innerText = 'En Avantajlı Depo'; titleEl.className = 'text-[10px] font-bold text-emerald-800 uppercase tracking-wider'; }
                    if (resetBtn) resetBtn.classList.add('hidden');
                    if (bannerEl) bannerEl.className = 'bg-gradient-to-r from-emerald-50 via-teal-50/70 to-emerald-50/50 border border-emerald-200 rounded-xl p-3 flex items-center justify-between gap-3';
                    if (iconBoxEl) iconBoxEl.className = 'w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-sm shrink-0 shadow-2xs';
                    if (iconEl) iconEl.className = 'fa-solid fa-trophy';
                } else {
                    if (titleEl) { titleEl.innerText = 'Seçili Depo Şartları'; titleEl.className = 'text-[10px] font-bold text-indigo-800 uppercase tracking-wider'; }
                    if (resetBtn) resetBtn.classList.remove('hidden');
                    if (bannerEl) bannerEl.className = 'bg-gradient-to-r from-indigo-50 via-sky-50/70 to-indigo-50/40 border border-indigo-300 rounded-xl p-3 flex items-center justify-between gap-3';
                    if (iconBoxEl) iconBoxEl.className = 'w-9 h-9 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-sm shrink-0 shadow-2xs';
                    if (iconEl) iconEl.className = 'fa-solid fa-bullseye';
                }
            }

            updateSimulator();
        }

        function resetSimToBestDeal() {
            const bestIdx = typeof window.defaultBestRowIndex === 'number' ? window.defaultBestRowIndex : 0;
            selectDepoForSimulation(bestIdx);
        }

        function setSimWithTier(rowIndex, alinan, hediye) {
            const targetQty = (parseInt(alinan) || 1) + (parseInt(hediye) || 0);
            const rowQty = document.getElementById(`qty_${rowIndex}`);
            if (rowQty) {
                rowQty.value = parseInt(alinan) || 1;
                rowQty.classList.add('ring-2', 'ring-emerald-500', 'bg-emerald-50');
                setTimeout(() => rowQty.classList.remove('ring-2', 'ring-emerald-500', 'bg-emerald-50'), 1500);
            }
            const qtyInput = document.getElementById('simQtyInput');
            if (qtyInput) qtyInput.value = targetQty;
            selectDepoForSimulation(rowIndex);
            const resultsBox = document.getElementById('simResultsBox');
            if (resultsBox && resultsBox.classList.contains('hidden')) {
                toggleMfDetails();
            }
            const etDrawer = document.getElementById('etCampaignDrawer');
            if (etDrawer && !etDrawer.classList.contains('hidden') && typeof applyEtCampaignMfPreset === 'function') {
                applyEtCampaignMfPreset(parseInt(alinan) || 1, parseInt(hediye) || 0);
            }
        }

        function selectMfTierAnalysis(depoIndex, alinan, hediye, mfText) {
            setSimWithTier(depoIndex, alinan, hediye);
        }

        function updateSimulator() {
            if (!currentReport || !currentReport.sonuclar || currentReport.sonuclar.length === 0) return;

            const qtyInput = document.getElementById('simQtyInput');
            const qty = qtyInput ? (parseInt(qtyInput.value) || 1) : 1;
            let depoItem = null;
            if (selectedRowIndex !== null && currentReport.sonuclar[selectedRowIndex]) {
                depoItem = currentReport.sonuclar[selectedRowIndex];
            } else {
                depoItem = currentReport.sonuclar.find(s => s.depo === currentReport.en_avantajli_depo && Math.abs(s.net_birim_maliyet - currentReport.en_dusuk_maliyet) < 0.01) || currentReport.sonuclar[0];
            }

            if (!depoItem) return;

            const dsf = depoItem.depocu_satis_fiyati || 0;
            const kdvOrani = depoItem.kdv_orani || 10.0;
            const kdvMultiplier = 1.0 + (kdvOrani / 100.0);
            const iskMultiplier = 1.0 - ((depoItem.ticari_iskonto || 0.0) / 100.0);

            let paidBoxes = qty;
            let freeBoxes = 0;
            let totalReceived = qty;

            // MF Kademesi varsa hesapla
            let tierVolumeNetPrice = null;
            if (depoItem.kademeler && depoItem.kademeler.length > 0) {
                let bestKademe = null;
                for (let k of depoItem.kademeler) {
                    const lot = (k.alinan || 1) + (k.hediye || 0);
                    if (qty >= lot) {
                        bestKademe = k;
                    }
                }

                if (bestKademe) {
                    if (bestKademe.hediye > 0) {
                        const lotSize = bestKademe.alinan + bestKademe.hediye;
                        const fullLots = Math.floor(qty / lotSize);
                        const remainder = qty % lotSize;
                        paidBoxes = (fullLots * bestKademe.alinan) + remainder;
                        freeBoxes = fullLots * bestKademe.hediye;
                        totalReceived = paidBoxes + freeBoxes;
                    } else if (bestKademe.net_birim_maliyet && bestKademe.net_birim_maliyet > 0) {
                        tierVolumeNetPrice = bestKademe.net_birim_maliyet;
                    }
                }
            }

            const totalInvoiceNet = (tierVolumeNetPrice !== null) ? (paidBoxes * tierVolumeNetPrice) : (paidBoxes * dsf * iskMultiplier);
            const totalInvoiceKdvli = totalInvoiceNet * kdvMultiplier;
            const unitNet = totalReceived > 0 ? (totalInvoiceNet / totalReceived) : 0;
            const unitKdvli = unitNet * kdvMultiplier;

            const elPaid = document.getElementById('simPaidBoxes');
            if (elPaid) elPaid.innerText = `${paidBoxes} Kutu`;
            const elFree = document.getElementById('simFreeBoxes');
            if (elFree) elFree.innerText = freeBoxes > 0 ? `+${freeBoxes} Kutu` : `0 Kutu`;
            const elTotal = document.getElementById('simTotalBoxes');
            if (elTotal) elTotal.innerText = `${totalReceived} Kutu`;
            const elUnitNet = document.getElementById('simUnitNet');
            if (elUnitNet) elUnitNet.innerText = `${unitNet.toFixed(2)} ₺`;
            const elUnitKdv = document.getElementById('simUnitKdvli');
            if (elUnitKdv) elUnitKdv.innerText = `${unitKdvli.toFixed(2)} ₺`;
            const elTotalInv = document.getElementById('simTotalInvoice');
            if (elTotalInv) elTotalInv.innerText = `${totalInvoiceNet.toFixed(2)} ₺`;
            const elInvKdv = document.getElementById('simInvoiceKdvli');
            if (elInvKdv) elInvKdv.innerText = `KDV Dahil: ${totalInvoiceKdvli.toFixed(2)} ₺`;

            const elDepoNote = document.getElementById('simDepoNote');
            if (elDepoNote) elDepoNote.innerText = `${depoItem.depo_adi} (${depoItem.mf_metni || 'MF Yok'})`;
            const simMfTextEl = document.getElementById('simMfText');
            if (simMfTextEl) simMfTextEl.innerText = `${depoItem.depo_adi}: ${depoItem.mf_metni || 'MF Yok'}`;

            selectedDepoForSim = depoItem.depo;
            const simBtn = document.getElementById('simAddToCartBtn');
            const simText = document.getElementById('simAddToCartText');
            if (simBtn && simText) {
                if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depoItem.depo)) {
                    simBtn.classList.add('opacity-50', 'cursor-not-allowed');
                    simBtn.disabled = true;
                    simText.innerText = `${depoItem.depo_adi} (Portal)`;
                } else {
                    simBtn.classList.remove('opacity-50', 'cursor-not-allowed');
                    simBtn.disabled = false;
                    simText.innerText = `${depoItem.depo_adi}'a At (${paidBoxes} Kt)`;
                }
            }
        }

        // ================= EczaneTakas Otomatik Kampanya / Teklif Açma Modülü =================
        let _etCampSearchTimer = null;
        let _etCampPrepareSeq = 0;
        let _etCampState = {
            liveDepoKdvli: 0,
            portalPrice: 0,
            kdvOrani: 10,
            matchedId: 0,
            matchedName: '',
            pharmacies: []
        };

        function _formatIsoDatePlusMonths(monthsToAdd) {
            const now = new Date();
            const target = new Date(now.getFullYear(), now.getMonth() + monthsToAdd + 1, 0);
            const yyyy = target.getFullYear();
            const mm = String(target.getMonth() + 1).padStart(2, '0');
            const dd = String(target.getDate()).padStart(2, '0');
            return `${yyyy}-${mm}-${dd}`;
        }

        function _formatIsoDatePlusDays(daysToAdd) {
            const d = new Date();
            d.setDate(d.getDate() + daysToAdd);
            const yyyy = d.getFullYear();
            const mm = String(d.getMonth() + 1).padStart(2, '0');
            const dd = String(d.getDate()).padStart(2, '0');
            return `${yyyy}-${mm}-${dd}`;
        }

        window.syncEtCampaignBarVisibility = function() {
            const bar = document.getElementById('etCampaignHeaderBar');
            const drawer = document.getElementById('etCampaignDrawer');
            if (!bar) return;
            if (window.isEczaneTakasActive) {
                bar.classList.remove('hidden');
                bar.classList.add('flex');
            } else {
                bar.classList.add('hidden');
                bar.classList.remove('flex');
                if (drawer) drawer.classList.add('hidden');
                const icon = document.getElementById('etCampToggleIcon');
                if (icon) icon.style.transform = 'rotate(0deg)';
            }
        };

        function toggleEtCampaignDrawer(forceOpen = null) {
            if (!window.isEczaneTakasActive) {
                showToast('Bilgi', 'Kampanya açabilmek için EczaneTakas hesabınızın aktif olması gerekir.', 'error');
                return;
            }
            const drawer = document.getElementById('etCampaignDrawer');
            const icon = document.getElementById('etCampToggleIcon');
            const btnText = document.getElementById('etCampToggleBtnText');
            if (!drawer) return;

            const shouldOpen = (forceOpen !== null) ? Boolean(forceOpen) : drawer.classList.contains('hidden');
            if (shouldOpen) {
                drawer.classList.remove('hidden');
                if (icon) icon.style.transform = 'rotate(180deg)';
                if (btnText) btnText.innerText = 'Formu Gizle';
                recalcEtCampaignPrice();
            } else {
                drawer.classList.add('hidden');
                if (icon) icon.style.transform = 'rotate(0deg)';
                if (btnText) btnText.innerText = 'Teklif / Kampanya Aç';
            }
        }

        function _renderEtCampPriceSourcePills() {
            const box = document.getElementById('etCampPriceSourcePills');
            if (!box) return;
            const pills = [];
            if (_etCampState.liveDepoKdvli > 0) {
                pills.push(`<button type="button" onclick="setEtCampBasePriceValue(${_etCampState.liveDepoKdvli.toFixed(2)})" class="px-1.5 py-0.5 rounded bg-sky-50 hover:bg-sky-100 text-[9.5px] font-bold text-sky-800 border border-sky-200 cursor-pointer" title="Canlı depo KDV dahil fiyatını baz al">Depo: ${_etCampState.liveDepoKdvli.toFixed(2)}₺</button>`);
            }
            if (_etCampState.portalPrice > 0 && Math.abs(_etCampState.portalPrice - _etCampState.liveDepoKdvli) > 0.05) {
                pills.push(`<button type="button" onclick="setEtCampBasePriceValue(${_etCampState.portalPrice.toFixed(2)})" class="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-[9.5px] font-bold text-slate-700 cursor-pointer" title="EczaneTakas portalında kayıtlı fiyatı baz al">Portal: ${_etCampState.portalPrice.toFixed(2)}₺</button>`);
            }
            box.innerHTML = pills.length > 0 ? pills.join('') : `<span class="text-[9.5px] text-slate-400">Baz fiyatı düzenleyebilirsiniz</span>`;
        }

        function setEtCampBasePriceValue(val) {
            const inp = document.getElementById('etCampBazFiyat');
            if (inp && val > 0) {
                inp.value = Number(val).toFixed(2);
                recalcEtCampaignPrice();
            }
        }

        function setEtCampQuickAdet(val) {
            const inp = document.getElementById('etCampAdet');
            if (inp) {
                inp.value = parseInt(val) || 10;
                recalcEtCampaignPrice();
            }
        }

        function syncEtCampMinToBarem() {
            const s1 = Math.max(1, parseInt((document.getElementById('etCampSart1') || {}).value) || 1);
            const s2 = Math.max(0, parseInt((document.getElementById('etCampSart2') || {}).value) || 0);
            const minInp = document.getElementById('etCampMinAlim');
            const adetInp = document.getElementById('etCampAdet');
            const tot = s1 + s2;
            if (minInp) minInp.value = tot;
            if (adetInp && (parseInt(adetInp.value) || 0) < tot) {
                adetInp.value = tot;
            }
            recalcEtCampaignPrice();
        }

        function setEtCampKomisyon(pct) {
            const inp = document.getElementById('etCampKomisyon');
            if (inp) {
                inp.value = parseFloat(pct) || 0;
                recalcEtCampaignPrice();
            }
        }

        function applyEtCampaignMfPreset(alinan, hediye) {
            const s1El = document.getElementById('etCampSart1');
            const s2El = document.getElementById('etCampSart2');
            const adetEl = document.getElementById('etCampAdet');
            const a = Math.max(1, parseInt(alinan) || 1);
            const h = Math.max(0, parseInt(hediye) || 0);
            if (s1El) s1El.value = a;
            if (s2El) s2El.value = h;
            if (adetEl && (parseInt(adetEl.value) || 0) < (a + h)) {
                adetEl.value = a + h;
            }
            recalcEtCampaignPrice();
        }

        function setEtCampMiadOffsetMonths(months) {
            const miadEl = document.getElementById('etCampMiad');
            if (miadEl) {
                miadEl.value = _formatIsoDatePlusMonths(months);
            }
        }

        function onEtCampHedefChange() {
            const sel = document.getElementById('etCampHedef');
            const box = document.getElementById('etCampPharmaciesBox');
            if (!sel || !box) return;
            if (sel.value === '1') {
                box.classList.remove('hidden');
            } else {
                box.classList.add('hidden');
            }
        }

        function onEtCampEndSwitchChange() {
            const chk = document.getElementById('etCampEndSwitch');
            const dt = document.getElementById('etCampEndDate');
            if (!chk || !dt) return;
            if (chk.checked) {
                dt.disabled = false;
                dt.className = 'w-full bg-white border border-slate-300 text-slate-800 font-bold text-xs rounded-xl px-2.5 py-2 focus:outline-none focus:border-sky-500';
                if (!dt.value) dt.value = _formatIsoDatePlusDays(15);
            } else {
                dt.disabled = true;
                dt.className = 'w-full bg-slate-100 border border-slate-200 text-slate-500 font-semibold text-xs rounded-xl px-2.5 py-2 focus:outline-none focus:border-sky-500 disabled:opacity-60';
            }
        }

        function toggleAllEtCampPharmacies() {
            const checks = document.querySelectorAll('.et-camp-pharmacy-chk');
            if (!checks.length) return;
            const anyUnchecked = Array.from(checks).some(c => !c.checked);
            checks.forEach(c => { c.checked = anyUnchecked; });
        }

        function recalcEtCampaignPrice() {
            const s1 = Math.max(1, parseInt((document.getElementById('etCampSart1') || {}).value) || 1);
            const s2 = Math.max(0, parseInt((document.getElementById('etCampSart2') || {}).value) || 0);
            const kom = Math.max(0, Math.min(99, parseFloat((document.getElementById('etCampKomisyon') || {}).value) || 0));
            const baz = Math.max(0, parseFloat((document.getElementById('etCampBazFiyat') || {}).value) || 0);

            const netKdvli = baz > 0 ? (((baz * s1) / (s1 + s2)) * (1.0 - (kom / 100.0))) : 0;
            const kdvMult = 1.0 + ((_etCampState.kdvOrani || 10.0) / 100.0);
            const netKdvsiz = kdvMult > 0 ? (netKdvli / kdvMult) : netKdvli;
            const discPct = (baz > 0 && netKdvli < baz) ? (((baz - netKdvli) / baz) * 100.0) : 0;

            const netKdvliEl = document.getElementById('etCampNetKdvli');
            const netKdvsizEl = document.getElementById('etCampNetKdvsiz');
            const headerNetEl = document.getElementById('etCampHeaderNetBadge');
            const baremSumEl = document.getElementById('etCampBaremSummary');
            const discEl = document.getElementById('etCampDiscountBadge');

            if (netKdvliEl) netKdvliEl.innerText = `${netKdvli.toFixed(2)} ₺`;
            if (netKdvsizEl) netKdvsizEl.innerText = `KDV H: ${netKdvsiz.toFixed(2)} ₺`;
            if (headerNetEl) headerNetEl.innerText = netKdvli > 0 ? `${netKdvli.toFixed(2)} ₺` : '-- ₺';
            if (baremSumEl) {
                baremSumEl.innerText = s2 > 0 ? `${s1} + ${s2} Barem` : `${s1} + 0 (MF'siz)`;
            }
            if (discEl) {
                if (discPct >= 0.1) {
                    discEl.innerText = `-%${discPct.toFixed(1)}`;
                    discEl.classList.remove('hidden');
                } else {
                    discEl.classList.add('hidden');
                }
            }
        }

        async function onEtCampaignProductChange() {
            const sel = document.getElementById('etCampUrunSelect');
            const matchBadge = document.getElementById('etCampMatchBadge');
            const subText = document.getElementById('etCampHeaderSubtext');
            if (!sel) return;
            const uid = parseInt(sel.value) || 0;
            const optText = (sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : '').trim();
            if (uid >= 1) {
                _etCampState.matchedId = uid;
                _etCampState.matchedName = optText;
                if (matchBadge) {
                    matchBadge.className = 'px-1.5 py-0.5 rounded text-[9.5px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300';
                    matchBadge.innerText = '✓ Ürün Hazır';
                }
                if (subText) subText.innerText = optText;
                try {
                    const r = await fetch(`/api/eczanetakas/campaign/product-price?urun_id=${uid}`);
                    if (r.ok) {
                        const j = await r.json();
                        if (j && j.portal_price > 0) {
                            _etCampState.portalPrice = Number(j.portal_price);
                            const bazInp = document.getElementById('etCampBazFiyat');
                            if (bazInp && (parseFloat(bazInp.value) || 0) <= 0) {
                                bazInp.value = _etCampState.portalPrice.toFixed(2);
                            }
                            _renderEtCampPriceSourcePills();
                            recalcEtCampaignPrice();
                        }
                    }
                } catch (e) {}
            } else {
                if (matchBadge) {
                    matchBadge.className = 'px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-amber-100 text-amber-800 border border-amber-300';
                    matchBadge.innerText = 'Ürün Seçiniz';
                }
            }
        }

        function searchEtCampaignProductsDebounced(term) {
            if (_etCampSearchTimer) clearTimeout(_etCampSearchTimer);
            const clean = String(term || '').trim();
            if (clean.length < 2) return;
            _etCampSearchTimer = setTimeout(async () => {
                try {
                    const r = await fetch(`/api/eczanetakas/campaign/prepare?q=${encodeURIComponent(clean)}`);
                    if (!r.ok) return;
                    const j = await r.json();
                    if (!j.success || !Array.isArray(j.candidates)) return;
                    const sel = document.getElementById('etCampUrunSelect');
                    if (!sel) return;
                    if (j.candidates.length === 0) {
                        sel.innerHTML = `<option value="0">"${clean}" için EczaneTakas'ta ürün bulunamadı</option>`;
                        return;
                    }
                    sel.innerHTML = j.candidates.map((c, idx) =>
                        `<option value="${c.id}" ${idx === 0 ? 'selected' : ''}>${c.name}</option>`
                    ).join('');
                    await onEtCampaignProductChange();
                } catch (e) {}
            }, 260);
        }

        async function initEtCampaignForCurrentReport(data) {
            const seq = ++_etCampPrepareSeq;
            const feedbackEl = document.getElementById('etCampFeedbackBox');
            if (feedbackEl) {
                feedbackEl.classList.add('hidden');
                feedbackEl.innerHTML = '';
            }

            // Çekmece yeni aramada kapalı başlasın
            const drawer = document.getElementById('etCampaignDrawer');
            const icon = document.getElementById('etCampToggleIcon');
            const btnText = document.getElementById('etCampToggleBtnText');
            if (drawer) drawer.classList.add('hidden');
            if (icon) icon.style.transform = 'rotate(0deg)';
            if (btnText) btnText.innerText = 'Teklif / Kampanya Aç';

            // Eğer aktiflik henüz okunmadıysa bir kez sorgula
            if (typeof window.isEczaneTakasActive === 'undefined') {
                try {
                    const credRes = await fetch('/api/settings/credentials');
                    if (credRes.ok) {
                        const c = await credRes.json();
                        const etCfg = c.eczanetakas || {};
                        window.isEczaneTakasActive = Boolean(
                            (etCfg.username || '').trim() &&
                            (etCfg.password || '').trim() &&
                            (etCfg.active === "1" || etCfg.active === true || etCfg.active === 1)
                        );
                    }
                } catch (e) {
                    window.isEczaneTakasActive = false;
                }
            }

            window.syncEtCampaignBarVisibility();
            if (!window.isEczaneTakasActive || !data) return;

            // 1. Canlı depo verilerinden KDV, KDV Dahil Baz Depo Fiyatı ve MF Şablonlarını çıkar
            let kdv = 10.0;
            let bestDepoDsf = 0.0;
            let bestDepoSingleKdvli = 0.0;
            const mfSet = new Map();
            mfSet.set('1+0', { alinan: 1, hediye: 0, label: "1+0 (MF'siz)" });

            const sonuclar = Array.isArray(data.sonuclar) ? data.sonuclar : [];
            sonuclar.forEach(s => {
                if (s.kdv_orani && s.kdv_orani > 0) kdv = s.kdv_orani;
                const isMainDepo = !['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(s.depo);
                if (isMainDepo && s.depocu_satis_fiyati > 0) {
                    const iskMult = 1.0 - ((s.ticari_iskonto || 0) / 100.0);
                    const singleKdvsiz = s.depocu_satis_fiyati * iskMult;
                    const singleKdvli = singleKdvsiz * (1.0 + ((s.kdv_orani || kdv) / 100.0));
                    if (bestDepoSingleKdvli <= 0 || (s.stok_durumu === 'VAR' && singleKdvli < bestDepoSingleKdvli)) {
                        bestDepoSingleKdvli = singleKdvli;
                        bestDepoDsf = s.depocu_satis_fiyati;
                    }
                }
                if (Array.isArray(s.kademeler)) {
                    s.kademeler.forEach(k => {
                        const a = parseInt(k.alinan) || 0;
                        const h = parseInt(k.hediye) || 0;
                        if (a >= 1 && h >= 1) {
                            const key = `${a}+${h}`;
                            if (!mfSet.has(key)) mfSet.set(key, { alinan: a, hediye: h, label: `${a}+${h} (${s.depo_adi.split(' ')[0]})` });
                        }
                    });
                } else if (s.mf_metni && !['YOK', '-', 'None'].includes(String(s.mf_metni).trim())) {
                    const rgx = /([0-9]+)\\s*\\+\\s*([0-9]+)/g;
                    let m;
                    while ((m = rgx.exec(String(s.mf_metni))) !== null) {
                        const a = parseInt(m[1], 10) || 0;
                        const h = parseInt(m[2], 10) || 0;
                        if (a >= 1 && h >= 1) {
                            const key = `${a}+${h}`;
                            if (!mfSet.has(key)) mfSet.set(key, { alinan: a, hediye: h, label: `${a}+${h}` });
                        }
                    }
                }
            });

            // Yaygın standart MF kısayollarını da ekle
            [[10, 1], [10, 2], [10, 3], [20, 5], [50, 10]].forEach(([a, h]) => {
                const key = `${a}+${h}`;
                if (mfSet.size < 8 && !mfSet.has(key)) {
                    mfSet.set(key, { alinan: a, hediye: h, label: key });
                }
            });

            _etCampState.kdvOrani = kdv;
            _etCampState.liveDepoKdvli = bestDepoSingleKdvli > 0 ? Number(bestDepoSingleKdvli.toFixed(2)) : 0;
            _etCampState.portalPrice = 0;
            _etCampState.matchedId = 0;
            _etCampState.matchedName = '';

            // MF şablon butonlarını çiz
            const presetsEl = document.getElementById('etCampMfPresets');
            if (presetsEl) {
                presetsEl.innerHTML = Array.from(mfSet.values()).map((p, idx) => {
                    const cls = idx === 0
                        ? 'px-2 py-0.5 rounded-lg text-[11px] font-bold bg-slate-100 hover:bg-sky-600 hover:text-white text-slate-700 transition cursor-pointer'
                        : 'px-2 py-0.5 rounded-lg text-[11px] font-extrabold bg-sky-50 hover:bg-sky-600 text-sky-900 hover:text-white border border-sky-200 hover:border-sky-600 transition cursor-pointer';
                    return `<button type="button" onclick="applyEtCampaignMfPreset(${p.alinan}, ${p.hediye})" class="${cls}">${p.label}</button>`;
                }).join('');
            }

            // Varsayılan barem: canlı depoda MF varsa ilk gerçek MF'yi seç, yoksa 1+0
            const allPresets = Array.from(mfSet.values());
            const firstRealMf = allPresets.find(p => p.hediye > 0 && p.label.includes('('));
            const s1El = document.getElementById('etCampSart1');
            const s2El = document.getElementById('etCampSart2');
            const adetEl = document.getElementById('etCampAdet');
            const minEl = document.getElementById('etCampMinAlim');
            const komEl = document.getElementById('etCampKomisyon');
            const bazEl = document.getElementById('etCampBazFiyat');
            const miadEl = document.getElementById('etCampMiad');
            const notEl = document.getElementById('etCampAciklama');
            const searchInp = document.getElementById('etCampUrunSearchInput');

            if (firstRealMf) {
                if (s1El) s1El.value = firstRealMf.alinan;
                if (s2El) s2El.value = firstRealMf.hediye;
                if (adetEl) adetEl.value = Math.max(20, firstRealMf.alinan + firstRealMf.hediye);
            } else {
                if (s1El) s1El.value = 1;
                if (s2El) s2El.value = 0;
                if (adetEl) adetEl.value = 20;
            }
            if (minEl) minEl.value = 1;
            if (komEl) komEl.value = 0;
            if (bazEl) bazEl.value = _etCampState.liveDepoKdvli > 0 ? _etCampState.liveDepoKdvli.toFixed(2) : '0.00';
            if (miadEl && !miadEl.value) miadEl.value = _formatIsoDatePlusMonths(12);
            if (notEl) notEl.value = '';
            if (searchInp) searchInp.value = '';

            _renderEtCampPriceSourcePills();
            recalcEtCampaignPrice();

            // 2. Arka planda EczaneTakas ürün eşleştirmesini (/api/eczanetakas/campaign/prepare) getir
            const matchBadge = document.getElementById('etCampMatchBadge');
            const subText = document.getElementById('etCampHeaderSubtext');
            const sel = document.getElementById('etCampUrunSelect');
            if (matchBadge) {
                matchBadge.className = 'px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-sky-100 text-sky-800 border border-sky-200';
                matchBadge.innerText = 'Eşleştiriliyor...';
            }
            if (subText) subText.innerText = data.urun_adi || 'Ürün kontrol ediliyor...';
            if (sel) sel.innerHTML = '<option value="0">EczaneTakas kataloğu taranıyor...</option>';

            try {
                const bc = data.barkod || data.barcode || '';
                const nm = data.urun_adi || data.name || '';
                const resp = await fetch(`/api/eczanetakas/campaign/prepare?barcode=${encodeURIComponent(bc)}&name=${encodeURIComponent(nm)}`);
                if (seq !== _etCampPrepareSeq) return;
                if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
                const prep = await resp.json();
                if (seq !== _etCampPrepareSeq) return;

                if (prep.active === false) {
                    window.isEczaneTakasActive = false;
                    window.syncEtCampaignBarVisibility();
                    return;
                }

                if (!prep.success) {
                    if (matchBadge) {
                        matchBadge.className = 'px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-rose-100 text-rose-800 border border-rose-200';
                        matchBadge.innerText = 'Oturum Hatası';
                    }
                    if (subText) subText.innerText = prep.message || 'EczaneTakas bağlantısı kurulamadı';
                    if (sel) sel.innerHTML = `<option value="0">${prep.message || 'Bağlantı hatası'}</option>`;
                    return;
                }

                // Grup eczaneleri listesini doldur (Hedef = Özel için)
                if (Array.isArray(prep.pharmacies)) {
                    _etCampState.pharmacies = prep.pharmacies;
                    const pListEl = document.getElementById('etCampPharmaciesList');
                    if (pListEl) {
                        pListEl.innerHTML = prep.pharmacies.map(ph => `
                            <label class="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-50 hover:bg-sky-50 border border-slate-200 cursor-pointer truncate">
                                <input type="checkbox" value="${ph.id}" class="et-camp-pharmacy-chk rounded text-sky-600 focus:ring-sky-500" />
                                <span class="truncate font-semibold text-slate-700" title="${ph.name}">${ph.name}</span>
                            </label>
                        `).join('');
                    }
                }

                const catInfoEl = document.getElementById('etCampCatalogInfo');
                if (catInfoEl && prep.total_catalog_count) {
                    catInfoEl.innerText = `EczaneTakas Kataloğu (${prep.total_catalog_count} ürün)`;
                }

                const cands = Array.isArray(prep.candidates) ? prep.candidates : [];
                if (prep.matched && prep.urun_id > 0) {
                    _etCampState.matchedId = prep.urun_id;
                    _etCampState.matchedName = prep.urun_adi;
                    _etCampState.portalPrice = Number(prep.portal_price || 0);
                    if (sel) {
                        sel.innerHTML = cands.map(c =>
                            `<option value="${c.id}" ${c.id === prep.urun_id ? 'selected' : ''}>${c.name}</option>`
                        ).join('');
                    }
                    if (bazEl && (parseFloat(bazEl.value) || 0) <= 0 && _etCampState.portalPrice > 0) {
                        bazEl.value = _etCampState.portalPrice.toFixed(2);
                    }
                    _renderEtCampPriceSourcePills();
                    recalcEtCampaignPrice();
                    if (matchBadge) {
                        matchBadge.className = 'px-1.5 py-0.5 rounded text-[9.5px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300';
                        matchBadge.innerText = '✓ Ürün Eşleşti';
                    }
                    if (subText) subText.innerText = prep.urun_adi;
                } else {
                    if (sel) {
                        const opts = ['<option value="0">-- Sağdaki kutudan ürün arayıp seçin --</option>'].concat(
                            cands.map(c => `<option value="${c.id}">${c.name}</option>`)
                        );
                        sel.innerHTML = opts.join('');
                    }
                    if (matchBadge) {
                        matchBadge.className = 'px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-amber-100 text-amber-900 border border-amber-300';
                        matchBadge.innerText = 'Manuel Seçim';
                    }
                    if (subText) subText.innerText = 'Ürün listeden seçilerek teklif açılabilir';
                }
            } catch (err) {
                if (matchBadge) {
                    matchBadge.className = 'px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-amber-100 text-amber-800 border border-amber-200';
                    matchBadge.innerText = 'Hazır';
                }
            }
        }

        async function submitEtCampaignForm() {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('EczaneTakas Teklif Açma')) return;

            const sel = document.getElementById('etCampUrunSelect');
            const urunId = sel ? (parseInt(sel.value) || 0) : 0;
            const urunAdi = (sel && sel.options[sel.selectedIndex]) ? sel.options[sel.selectedIndex].text.trim() : '';
            const adet = parseInt((document.getElementById('etCampAdet') || {}).value) || 0;
            const minAlim = parseInt((document.getElementById('etCampMinAlim') || {}).value) || 1;
            const sart1 = parseInt((document.getElementById('etCampSart1') || {}).value) || 1;
            const sart2 = parseInt((document.getElementById('etCampSart2') || {}).value) || 0;
            const komisyon = parseFloat((document.getElementById('etCampKomisyon') || {}).value) || 0;
            const bazFiyat = parseFloat((document.getElementById('etCampBazFiyat') || {}).value) || 0;
            const miad = String((document.getElementById('etCampMiad') || {}).value || '').trim();
            const hedef = String((document.getElementById('etCampHedef') || {}).value || '0');
            const aciklama = String((document.getElementById('etCampAciklama') || {}).value || '').trim();
            const bitisAktif = Boolean((document.getElementById('etCampEndSwitch') || {}).checked);
            const bitisTarihi = String((document.getElementById('etCampEndDate') || {}).value || '').trim();
            const feedbackEl = document.getElementById('etCampFeedbackBox');
            const submitBtn = document.getElementById('etCampSubmitBtn');

            const showCampMsg = (msg, isOk) => {
                if (!feedbackEl) return;
                feedbackEl.classList.remove('hidden');
                feedbackEl.className = isOk
                    ? 'rounded-xl px-3.5 py-2.5 text-xs font-bold border bg-emerald-50 border-emerald-300 text-emerald-900 flex flex-wrap items-center justify-between gap-2'
                    : 'rounded-xl px-3.5 py-2.5 text-xs font-bold border bg-rose-50 border-rose-300 text-rose-800';
                feedbackEl.innerHTML = msg;
            };

            if (urunId < 1) {
                showCampMsg('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Lütfen EczaneTakas ürün listesinden teklif açılacak ürünü seçin.', false);
                return;
            }
            if (adet < 1) {
                showCampMsg('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Satılacak kutu adedi en az 1 olmalıdır.', false);
                return;
            }
            if (minAlim < 1 || minAlim > adet) {
                showCampMsg(`<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Minimum alım adedi (${minAlim}) 1 ile toplam adet (${adet}) arasında olmalıdır.`, false);
                return;
            }
            if (bazFiyat <= 0) {
                showCampMsg('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Lütfen geçerli bir Baz Depo Fiyatı girin.', false);
                return;
            }
            if (!/^\\d{4}-\\d{2}-\\d{2}$/.test(miad)) {
                showCampMsg('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Lütfen ürünün Miad Tarihini seçin.', false);
                return;
            }

            const uyeler = [];
            if (hedef === '1') {
                document.querySelectorAll('.et-camp-pharmacy-chk:checked').forEach(chk => {
                    if (chk.value) uyeler.push(chk.value);
                });
                if (uyeler.length === 0) {
                    showCampMsg('<i class="fa-solid fa-circle-exclamation mr-1.5"></i>Hedef olarak "Özel" seçildiğinde listeden en az 1 eczane seçmelisiniz.', false);
                    return;
                }
            }

            const netPreview = (((bazFiyat * sart1) / (sart1 + sart2)) * (1.0 - (komisyon / 100.0))).toFixed(2);
            const mfLabel = sart2 > 0 ? `${sart1}+${sart2}` : '1+0 (MF Yok)';
            const confirmTxt = `EczaneTakas'ta aşağıdaki teklifi yayına almak istediğinize emin misiniz?\\n\\n`
                + `• Ürün: ${urunAdi}\\n`
                + `• Adet: ${adet} Kutu (Min. Alım: ${minAlim})\\n`
                + `• Alım Şartı: ${mfLabel}${komisyon > 0 ? ' + %' + komisyon + ' Komisyon/İsk.' : ''}\\n`
                + `• Baz Fiyat: ${bazFiyat.toFixed(2)} ₺  ➔  Net Satış Fiyatı: ${netPreview} ₺ (KDV Dahil)\\n`
                + `• Miad: ${miad}`;
            if (!window.confirm(confirmTxt)) return;

            const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1.5"></i>Yayınlanıyor...';
            }

            try {
                const res = await fetch('/api/eczanetakas/campaign/create', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        urun_id: urunId,
                        urun_adi: urunAdi,
                        adet: adet,
                        minumum: minAlim,
                        alimsarti1: sart1,
                        alimsarti2: sart2,
                        komisyon: komisyon,
                        baz_fiyat: bazFiyat,
                        miad: miad,
                        hedef: hedef,
                        uyeler: uyeler,
                        aciklama: aciklama,
                        bitis_aktif: bitisAktif,
                        teklifbitis: bitisTarihi
                    })
                });
                const result = await res.json();
                if (result.success) {
                    showCampMsg(
                        `<div><i class="fa-solid fa-circle-check text-emerald-600 mr-1.5"></i><strong>${urunAdi}</strong> için <strong>${adet} kutu (${mfLabel} • Net: ${result.netfiyat || netPreview} ₺)</strong> teklifiniz EczaneTakas'ta yayına alındı! <span class="font-normal text-emerald-800">${result.message || ''}</span></div>`
                        + `<button type="button" onclick="openAuthenticatedPortal('ECZANETAKAS', 'https://eczanetakas.com/tekliflerim/')" class="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-black cursor-pointer shrink-0">Verdiğim Teklifleri Gör ↗</button>`,
                        true
                    );
                    showToast('Kampanya Yayınlandı', `${urunAdi} teklifiniz EczaneTakas'ta yayına alındı!`, 'success');
                } else {
                    showCampMsg(`<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>${result.message || 'Teklif oluşturulamadı.'}`, false);
                    showToast('Teklif Açılamadı', result.message || 'EczaneTakas teklifi kaydedilemedi.', 'error');
                }
            } catch (err) {
                showCampMsg(`<i class="fa-solid fa-triangle-exclamation mr-1.5"></i>Bağlantı hatası: ${err.message}`, false);
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = origBtnHtml;
                }
            }
        }

        // ================= Sepete Ekleme & Bildirimler =================
        function showToast(title, message, type = 'success') {
            const container = document.getElementById('toastContainer');
            if (!container) return;
            const toast = document.createElement('div');
            const isSuccess = type === 'success';
            const bgClass = isSuccess ? 'bg-emerald-600 text-white shadow-emerald-200' : 'bg-rose-600 text-white shadow-rose-200';
            const icon = isSuccess ? 'fa-circle-check' : 'fa-triangle-exclamation';

            toast.className = `${bgClass} pointer-events-auto flex items-start space-x-3 px-4 py-3 rounded-2xl shadow-xl transition-all duration-300 transform translate-y-[-20px] opacity-0 max-w-md`;
            toast.innerHTML = `
                <i class="fa-solid ${icon} text-lg mt-0.5 shrink-0"></i>
                <div class="flex-1 text-xs">
                    <div class="font-bold text-sm leading-tight">${title}</div>
                    <div class="mt-0.5 text-white/90 leading-relaxed">${message}</div>
                </div>
                <button onclick="this.parentElement.remove()" class="text-white/70 hover:text-white ml-2 cursor-pointer">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            `;
            container.appendChild(toast);
            setTimeout(() => {
                toast.classList.remove('translate-y-[-20px]', 'opacity-0');
            }, 10);
            setTimeout(() => {
                toast.classList.add('opacity-0', 'translate-y-[-10px]');
                setTimeout(() => toast.remove(), 300);
            }, 5000);
        }

        async function addToCart(depo, urunId, barkod, rowIndex, btn, explicitName = '') {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Sepete Ekleme')) return;
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depo)) {
                showToast('Bilgi', 'Ortak alım grubu ve pazaryeri siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const qtyInput = document.getElementById(`qty_${rowIndex}`);
            const miktar = parseInt(qtyInput ? qtyInput.value : 1) || 1;

            const originalContent = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1"></i>Ekleniyor...`;

            const prodName = explicitName || ((typeof currentReport !== 'undefined' && currentReport) ? (currentReport.urun_adi || currentReport.name || '') : '');
            const effBc = (barkod && barkod !== 'undefined' && barkod !== 'null')
                ? String(barkod).trim()
                : ((typeof currentReport !== 'undefined' && currentReport && currentReport.barkod) ? String(currentReport.barkod).trim() : String(urunId || '').trim());
            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: urunId,
                        barkod: effBc,
                        miktar: miktar,
                        name: prodName
                    })
                });
                const result = await res.json();
                if (result.success) {
                    let extra = '';
                    if (result.sepet_no) extra += ` (Belge No: ${result.sepet_no})`;
                    if (result.sepet_tutari) extra += ` (Sepet Tutarı: ${result.sepet_tutari} ₺)`;
                    if (typeof recordDepotSessionFromSingleAdd === 'function') {
                        recordDepotSessionFromSingleAdd(depo, result.sepet_tutari, result.sepet_no, result.portal_url);
                    }
                    const dUp = String(depo || 'SELCUK').toUpperCase();
                    if (typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus([{ barkod: effBc, urun_adi: prodName, miktar: miktar, depo: dUp }], 'SEPETTE', dUp);
                    }
                    if (typeof updateMultiDepotCartUI === 'function') {
                        updateMultiDepotCartUI();
                    }
                    if (typeof syncTodayOrdersAcrossPCs === 'function') {
                        await syncTodayOrdersAcrossPCs();
                    }
                    if (typeof refreshCurrentSearchOrderBanner === 'function') {
                        refreshCurrentSearchOrderBanner();
                    }
                    showToast('Sepete Eklendi', `${result.message || `${miktar} kutu başarıyla ${depo} sepetine eklendi!`}${extra}`, 'success');
                } else {
                    showToast('Hata', result.message || `${depo} sepetine eklenemedi.`, 'error');
                }
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalContent;
            }
        }

        // ================= TEKLİ SİPARİŞİ TAMAMLA & SONLANDIR =================
        function closeQuickFinalizeModal() {
            const modal = document.getElementById('quickFinalizeModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
        }

        async function quickFinalizeOrder(depo, urunId, barkod, rowIndex, urunAdi, unitPrice) {
            if (window.checkLicenseBeforeAction && !window.checkLicenseBeforeAction('Sipariş Gönderme')) return;
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depo)) {
                showToast('Bilgi', 'Ortak alım grubu ve pazaryeri siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const qtyInput = document.getElementById(`qty_${rowIndex}`);
            const miktar = parseInt(qtyInput ? qtyInput.value : 1) || 1;
            const cleanUrunAdi = urunAdi || 'Ürün';

            const modal = document.getElementById('quickFinalizeModal');
            const badgeEl = document.getElementById('quickFinDepoBadge');
            const bodyEl = document.getElementById('quickFinBody');
            const footerEl = document.getElementById('quickFinFooter');

            if (!modal || !bodyEl || !footerEl) return;

            if (badgeEl) badgeEl.innerText = depo === 'SELCUK' ? 'Selçuk Ecza' : (depo === 'NEVZAT' ? 'Nevzat Ecza' : (depo === 'ALLIANCE' ? 'Alliance Healthcare' : (depo === 'ISKOOP' ? 'İSKOOP' : depo)));
            
            modal.classList.remove('hidden');
            modal.style.display = 'flex';

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-circle-notch fa-spin text-3xl text-amber-500 mb-3"></i>
                    <div class="font-extrabold text-slate-800 text-sm">Depo Sepeti Kontrol Ediliyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depo} sepet durumu ve mevcut siparişler sorgulanıyor...</div>
                </div>
            `;
            footerEl.innerHTML = `
                <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
            `;

            try {
                const res = await fetch('/api/cart/quick-finalize-check', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: urunId,
                        barkod: barkod,
                        miktar: miktar,
                        urun_adi: cleanUrunAdi
                    })
                });
                const checkData = await res.json();

                if (!checkData.success) {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-exclamation mr-1.5"></i>Sepet Sorgulanamadı</div>
                            <div>${checkData.message || 'Depo sepet bilgisi alınamadı.'}</div>
                        </div>
                    `;
                    return;
                }

                const totalEst = miktar * (unitPrice || 0);
                const alreadyInCart = !!checkData.already_in_cart;
                const sessionItems = checkData.session_items || [];
                const foreignItems = checkData.foreign_items || [];

                if (checkData.can_finalize_directly) {
                    // Sepette yabancı ürün YOK! Doğrudan sonlandırılabilir
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Ürün Özeti -->
                            <div class="p-4 rounded-2xl bg-emerald-50/70 border-2 border-emerald-300 shadow-xs flex items-center justify-between">
                                <div class="pr-3">
                                    <div class="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-black uppercase tracking-wider mb-1">
                                        <i class="fa-solid fa-circle-check"></i>
                                        <span>${alreadyInCart ? 'Az Önce Sepete Eklendi' : 'Şimdi Sepete Eklenecek'}</span>
                                    </div>
                                    <div class="text-base font-black text-slate-900 leading-snug">${cleanUrunAdi}</div>
                                    <div class="text-xs text-slate-600 mt-1">
                                        Birim Fiyat: <strong class="text-slate-900 font-mono">${(unitPrice || 0).toFixed(2)} ₺</strong> (KDV Dahil)
                                    </div>
                                </div>
                                <div class="text-right shrink-0 pl-3 border-l border-emerald-200">
                                    <div class="text-[10px] text-emerald-700 font-bold uppercase">Miktar</div>
                                    <div class="text-2xl font-black text-emerald-700 font-mono">${miktar} <span class="text-xs font-bold text-emerald-600">Kutu</span></div>
                                    <div class="text-xs font-extrabold text-slate-800 mt-0.5 font-mono">~${totalEst.toFixed(2)} ₺</div>
                                </div>
                            </div>

                            ${sessionItems.length > 1 ? `
                            <!-- Bu Oturumda Eklenen Diğer Ürünler (Yeşil) -->
                            <div class="bg-emerald-50/60 rounded-2xl border border-emerald-200 p-3 max-h-36 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-check-double mr-1 text-emerald-600"></i>Bu Siparişte Eklenen Ürünler (${sessionItems.length} Kalem):</span>
                                    <span class="font-mono text-emerald-700">${(checkData.total_amount || 0).toFixed(2)} ₺</span>
                                </div>
                                ${sessionItems.map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-2.5 rounded-lg bg-white border border-emerald-200 text-xs">
                                        <span class="font-bold text-emerald-950 truncate mr-2"><i class="fa-solid fa-circle-check text-emerald-500 mr-1.5 text-[10px]"></i>${it.ad}</span>
                                        <span class="font-extrabold text-emerald-700 whitespace-nowrap font-mono">${it.miktar} Kutu (${(it.tutar || 0).toFixed(2)} ₺)</span>
                                    </div>
                                `).join('')}
                            </div>
                            ` : ''}

                            <!-- Güvenlik Onayı -->
                            <div class="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start space-x-3">
                                <div class="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                                    <i class="fa-solid fa-shield-check text-sm"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-bold text-emerald-950 text-sm">Sepet Kontrolü Başarılı — Yabancı Ürün Yok ✅</div>
                                    <div class="text-emerald-800 mt-0.5 leading-relaxed">
                                        ${checkData.item_count === 0 ? 'Depo sepetiniz şu an boş, ürün eklenip doğrudan onaylanacak.' : 'Sepette sadece sizin bu oturumda eklediğiniz ürün(ler) yer alıyor.'}
                                        Onay verdiğinizde sipariş <strong>doğrudan ${depo} sistemine iletilip sonlandırılacaktır</strong>.
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;

                    footerEl.innerHTML = `
                        <div class="flex items-center justify-between w-full">
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
                            <button type="button" id="btnExecuteFinalize" onclick="executeFinalize('${depo}', '${urunId}', '${barkod}', ${miktar}, false, ${alreadyInCart})" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md hover:shadow-lg transition flex items-center space-x-2 cursor-pointer">
                                <i class="fa-solid fa-paper-plane text-xs"></i>
                                <span>Siparişi Onayla & Gönder</span>
                            </button>
                        </div>
                    `;
                } else {
                    // Sepette BAŞKA / ÖNCEDEN KALMIŞ YABANCI ÜRÜNLER VAR! Kırmızı uyarı göster
                    bodyEl.innerHTML = `
                        <div class="space-y-3.5">
                            <!-- Kırmızı Dikkat Uyarısı -->
                            <div class="p-3.5 rounded-2xl bg-rose-100 border-2 border-rose-500 flex items-start justify-between gap-2 shadow-sm">
                                <div class="flex items-start space-x-3">
                                    <div class="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow">
                                        <i class="fa-solid fa-triangle-exclamation text-sm"></i>
                                    </div>
                                    <div class="text-xs">
                                        <div class="font-black text-rose-950 text-sm">🚨 Sepette Önceden Kalmış Ürünler Var!</div>
                                        <div class="text-rose-900 mt-0.5 leading-relaxed">
                                            ${depo} sepetinizde önceden eklenmiş <strong class="underline">${foreignItems.length} farklı ürün</strong> tespit edildi (Toplam: <strong>${(checkData.total_amount || 0).toFixed(2)} ₺</strong>).
                                        </div>
                                    </div>
                                </div>
                                <button type="button" onclick="onlyClearCart('${depo}')" class="px-2.5 py-1 rounded-lg bg-white/80 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-300 text-[10px] font-bold transition shrink-0 cursor-pointer" title="Sepeti tamamen boşalt">
                                    <i class="fa-solid fa-trash-can mr-1"></i>Boşalt
                                </button>
                            </div>

                            <!-- KIRMIZI: Başka Eklenen / Önceden Sepette Olan Yabancı Ürünler -->
                            <div class="bg-rose-50 rounded-2xl border-2 border-rose-400 p-3 max-h-40 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-black text-rose-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-ban mr-1 text-rose-600"></i>🚨 Önceden Sepette Olanlar (${foreignItems.length} Kalem):</span>
                                    <span class="px-2 py-0.5 rounded bg-rose-600 text-white text-[9px] font-black">ÖNCEKİ</span>
                                </div>
                                ${foreignItems.map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-2.5 rounded-lg bg-rose-100/90 border border-rose-300 text-xs">
                                        <span class="font-extrabold text-rose-950 truncate mr-2"><i class="fa-solid fa-circle-exclamation text-rose-600 mr-1.5 text-[10px]"></i>${it.ad}</span>
                                        <span class="font-black text-rose-800 whitespace-nowrap font-mono">${it.miktar} Kutu (${(it.tutar || 0).toFixed(2)} ₺)</span>
                                    </div>
                                `).join('')}
                            </div>

                            <!-- YEŞİL: Şimdi / Bu Siparişte Eklenen Ürünler -->
                            <div class="p-3 rounded-2xl bg-emerald-50 border-2 border-emerald-400 space-y-1.5">
                                <div class="flex items-center justify-between">
                                    <span class="text-emerald-800 font-black uppercase text-[10px]"><i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>✅ Şimdi Eklenen Ürün:</span>
                                    <span class="px-2 py-0.5 rounded bg-emerald-600 text-white text-[9px] font-black">YENİ</span>
                                </div>
                                <div class="flex items-center justify-between text-xs pt-1">
                                    <div class="font-black text-emerald-950">${cleanUrunAdi} (${miktar} Kutu)</div>
                                    <div class="font-black text-emerald-700 text-sm font-mono">${alreadyInCart ? '' : '+'}${totalEst.toFixed(2)} ₺</div>
                                </div>
                            </div>
                        </div>
                    `;

                    const safeCleanName = cleanUrunAdi.replace(/'/g, "\\\\'");
                    footerEl.innerHTML = `
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition w-full sm:w-auto cursor-pointer">Vazgeç</button>
                            <div class="flex flex-wrap items-center gap-2 justify-end w-full sm:w-auto">
                                <button type="button" onclick="clearCartAndFinalize('${depo}', '${urunId}', '${barkod}', ${miktar}, '${safeCleanName}', ${unitPrice})" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition flex items-center space-x-1.5 cursor-pointer shadow-sm" title="Önceki ürünleri siler ve sadece bu ürünü gönderir">
                                    <i class="fa-solid fa-check text-[10px]"></i>
                                    <span>Sadece Bunu Gönder</span>
                                </button>
                                <button type="button" onclick="executeFinalize('${depo}', '${urunId}', '${barkod}', ${miktar}, true, ${alreadyInCart})" class="px-4 py-2 bg-gradient-to-r from-rose-600 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white rounded-xl text-xs font-black shadow-sm transition flex items-center space-x-1.5 cursor-pointer" title="Önceki ürünlerle beraber tüm sepeti onaylar">
                                    <i class="fa-solid fa-paper-plane text-[10px]"></i>
                                    <span>Tüm Sepeti Gönder</span>
                                </button>
                            </div>
                        </div>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
            }
        }

        async function executeFinalize(depo, urunId, barkod, miktar, force, alreadyInCart = false) {
            if (window._quickFinalizeInFlight) return;
            const bodyEl = document.getElementById('quickFinBody');
            const footerEl = document.getElementById('quickFinFooter');
            if (!bodyEl || !footerEl) return;
            window._quickFinalizeInFlight = true;

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-spinner fa-spin text-4xl text-emerald-500 mb-3"></i>
                    <div class="text-base font-extrabold text-slate-800">Sipariş Depoya İletiliyor...</div>
                    <div class="text-xs text-slate-500 mt-1">${depo} sistemine bağlanılıyor ve sipariş doğrudan onaylanıyor...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            try {
                const res = await fetch('/api/cart/finalize', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: urunId,
                        barkod: barkod || (currentReport && currentReport.barkod) || '',
                        urun_adi: (currentReport && currentReport.urun_adi) || '',
                        miktar: miktar,
                        force: force,
                        already_in_cart: alreadyInCart
                    })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-emerald-500/20">
                                <i class="fa-solid fa-circle-check animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sipariş Başarıyla Sonlandırıldı! 🎉</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message}</p>
                            </div>
                            ${result.order_info ? `
                                <div class="p-3 rounded-2xl bg-slate-100 border border-slate-200 text-xs font-mono font-bold text-slate-700 max-w-sm mx-auto">
                                    ${result.order_info}
                                </div>
                            ` : ''}
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            ${result.portal_url ? `<a href="${result.portal_url}" target="_blank" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-sm"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>WebDepo'da İncele</span></a>` : ''}
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Tamam</button>
                        </div>
                    `;
                    showToast('Sipariş Sonlandırıldı', result.message, 'success');
                    if (typeof markBulkSessionFinalizedInUI === 'function') markBulkSessionFinalizedInUI(depo);
                    const finBc = String(barkod || (currentReport && currentReport.barkod) || '').trim();
                    const finNm = String((currentReport && currentReport.urun_adi) || '').trim().toUpperCase();
                    window.todayOrdersMap = window.todayOrdersMap || {};
                    const nowHm = new Date().toTimeString().slice(0, 5);
                    const finEntry = {
                        barkod: finBc,
                        urun_adi: (currentReport && currentReport.urun_adi) || finBc,
                        durum: 'SIPARIS_VERILDI',
                        depo: String(depo || 'DEPO').toUpperCase(),
                        miktar: parseInt(miktar) || 1,
                        masa_adi: window.currentPcName || 'Bu Bilgisayar',
                        saat: nowHm
                    };
                    if (finBc && (!window.todayOrdersMap[finBc] || window.todayOrdersMap[finBc].durum !== 'SEPETTE')) {
                        window.todayOrdersMap[finBc] = finEntry;
                    }
                    if (finNm && (!window.todayOrdersMap[finNm] || window.todayOrdersMap[finNm].durum !== 'SEPETTE')) {
                        window.todayOrdersMap[finNm] = finEntry;
                    }
                    if (typeof refreshCurrentSearchOrderBanner === 'function') refreshCurrentSearchOrderBanner();
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sipariş Onaylanamadı</div>
                            <div class="leading-relaxed">${result.message || 'Bilinmeyen bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            } finally {
                window._quickFinalizeInFlight = false;
            }
        }

        async function clearCartAndFinalize(depo, urunId, barkod, miktar, urunAdi, unitPrice) {
            const bodyEl = document.getElementById('quickFinBody');
            if (bodyEl) {
                bodyEl.innerHTML = `
                    <div class="text-center py-8">
                        <i class="fa-solid fa-spinner fa-spin text-3xl text-rose-500 mb-3"></i>
                        <div class="font-bold text-slate-800 text-sm">Sepet Temizleniyor...</div>
                        <div class="text-xs text-slate-400 mt-1">Önceki ürünler siliniyor, ardından acil ürün eklenecek...</div>
                    </div>
                `;
            }
            try {
                await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo })
                });
                await executeFinalize(depo, urunId, barkod, miktar, true, false);
            } catch (e) {
                showToast('Hata', 'Sepet temizlenirken hata: ' + e.message, 'error');
            }
        }

        async function onlyClearCart(depo) {
            const bodyEl = document.getElementById('quickFinBody');
            const footerEl = document.getElementById('quickFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-8">
                    <i class="fa-solid fa-spinner fa-spin text-3xl text-rose-500 mb-3"></i>
                    <div class="font-bold text-slate-800 text-sm">Sepet Boşaltılıyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depo} sepetindeki tüm ürünler siliniyor...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            try {
                const res = await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-rose-500/20">
                                <i class="fa-solid fa-trash-can animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sepetiniz Başarıyla Boşaltıldı 🗑️</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message || `${depo} sepetindeki tüm ürünler temizlendi.`}</p>
                                <p class="text-[11px] text-slate-400 mt-1.5 font-bold">Herhangi bir sipariş onaylanmamış veya iletilmemiştir.</p>
                            </div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                        </div>
                    `;
                    showToast('Sepet Boşaltıldı', `${depo} sepetiniz temizlendi (Sipariş verilmedi).`, 'info');
                    if (typeof markBulkSessionClearedInUI === 'function') markBulkSessionClearedInUI(depo);
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                    if (window.smartOrderLoadedOnce && typeof loadSmartOrderList === 'function') loadSmartOrderList(true);
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sepet Temizlenemedi</div>
                            <div class="leading-relaxed">${result.message || 'Sepet boşaltılırken bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        // ================= GÜNLÜK TOPLU SİPARİŞİ SONLANDIRMA FONKSİYONLARI =================
        function getDepoSessionDisplayInfo(depoCode) {
            const dKey = String(depoCode || 'SELCUK').toUpperCase();
            const prettyNames = {
                'SELCUK': 'Selçuk Ecza Deposu',
                'NEVZAT': 'Nevzat Ecza Deposu',
                'ALLIANCE': 'Alliance Healthcare',
                'ISKOOP': 'İSKOOP E-Şube',
                'BEK': 'Bursa Ecza Koop (BEK)',
                'DNA': 'DNA Ecza Deposu'
            };
            const sessions = (window.currentBulkState && window.currentBulkState.depoSessions) || {};
            const s = sessions[dKey] || {};
            const groups = (typeof getActiveCartGroupsByDepo === 'function') ? getActiveCartGroupsByDepo() : {};
            const g = groups[dKey] || {};
            const itemCount = (g.items && g.items.length) ? g.items.length : (s.count || 0);
            const boxCount = g.totalBoxes || itemCount;
            const rawAmount = g.sepetTutari || (s.amount ? s.amount.toFixed(2) : '');
            return {
                code: dKey,
                name: g.name || s.name || prettyNames[dKey] || dKey,
                shortName: g.shortName || dKey,
                count: itemCount,
                boxes: boxCount,
                amountText: (rawAmount && parseFloat(rawAmount) > 0) ? `${rawAmount} ₺` : ''
            };
        }

        function getUnfinalizedBulkDepos(excludeDepo = null) {
            const sessions = (window.currentBulkState && window.currentBulkState.depoSessions) || {};
            const ex = excludeDepo ? String(excludeDepo).toUpperCase() : null;
            const set = new Set();
            for (const k of Object.keys(sessions)) {
                const s = sessions[k];
                if (s && s.count > 0 && !s.finalized && !s.cleared && k.toUpperCase() !== ex) {
                    set.add(k.toUpperCase());
                }
            }
            if (typeof getActiveCartGroupsByDepo === 'function') {
                const groups = getActiveCartGroupsByDepo();
                for (const dKey of Object.keys(groups)) {
                    const g = groups[dKey];
                    if (g && g.items && g.items.length > 0 && dKey.toUpperCase() !== ex) {
                        const sess = sessions[dKey.toUpperCase()];
                        if (!sess || (!sess.finalized && !sess.cleared)) {
                            set.add(dKey.toUpperCase());
                        }
                    }
                }
            }
            return Array.from(set);
        }

        function getNextUnfinalizedBulkDepo(excludeDepo = null) {
            const list = getUnfinalizedBulkDepos(excludeDepo);
            return list.length > 0 ? list[0] : null;
        }

        function updateBulkMainFinalizeButtonUI() {
            const btnFin = document.getElementById('btnBulkFinalize');
            if (!btnFin) return;
            const unfinList = getUnfinalizedBulkDepos();
            const sessions = (window.currentBulkState && window.currentBulkState.depoSessions) || {};
            const allKeys = Object.keys(sessions).filter(k => sessions[k] && sessions[k].count > 0);
            const missingAfter = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];

            if (unfinList.length > 0) {
                const nextDepo = unfinList[0];
                if (window.currentBulkState) window.currentBulkState.depo = nextDepo;
                const info = getDepoSessionDisplayInfo(nextDepo);
                btnFin.disabled = false;
                btnFin.className = 'px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-500/20 transition flex items-center space-x-1.5 cursor-pointer';
                if (unfinList.length > 1) {
                    btnFin.innerHTML = `<i class="fa-solid fa-paper-plane text-xs"></i><span>${info.name} Siparişini Sonlandır (${unfinList.length} Depo Bekliyor)</span>`;
                } else {
                    btnFin.innerHTML = `<i class="fa-solid fa-paper-plane text-xs"></i><span>${info.name} Siparişini Sonlandır (${info.count} Kalem)</span>`;
                }
            } else if (missingAfter.length > 0) {
                btnFin.disabled = false;
                btnFin.className = 'px-5 py-2.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white rounded-xl text-xs font-black shadow-md shadow-rose-500/20 transition flex items-center space-x-1.5 cursor-pointer active:scale-95';
                btnFin.innerHTML = `<i class="fa-solid fa-ban text-xs"></i><span>🚨 Kalan ${missingAfter.length} Eksik Ürünü Yok Listesine At</span>`;
            } else if (allKeys.length > 0) {
                btnFin.disabled = true;
                btnFin.className = 'px-5 py-2.5 bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm flex items-center space-x-1.5 opacity-90 cursor-default';
                btnFin.innerHTML = `<i class="fa-solid fa-circle-check text-xs"></i><span>Tüm Siparişler Depolara İletildi ✅</span>`;
            }
            if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
        }

        function markBulkSessionFinalizedInUI(depo) {
            const cleanDepo = (depo || '').toUpperCase();
            if (window.singleAddDepoMeta && window.singleAddDepoMeta[cleanDepo]) {
                delete window.singleAddDepoMeta[cleanDepo];
            }
            // 1. Anlık olarak todayOrdersMap içindeki bu depoya ait SEPETTE kayıtlarını SIPARIS_VERILDI yap (veya çoklu depoysa bu depoyu düş)
            if (window.todayOrdersMap) {
                Object.keys(window.todayOrdersMap).forEach(k => {
                    const entry = window.todayOrdersMap[k];
                    if (!entry || entry.durum !== 'SEPETTE') return;
                    const dStr = String(entry.depo || '').toUpperCase();
                    if (dStr === cleanDepo) {
                        entry.durum = 'SIPARIS_VERILDI';
                    } else if (dStr.includes('+')) {
                        const parts = dStr.split('+').map(p => p.trim()).filter(Boolean);
                        if (parts.includes(cleanDepo)) {
                            const rem = parts.filter(p => p !== cleanDepo);
                            if (rem.length > 0) {
                                entry.depo = rem.join(' + ');
                            } else {
                                entry.durum = 'SIPARIS_VERILDI';
                                entry.depo = cleanDepo;
                            }
                        }
                    }
                });
            }
            if (typeof criticalStockItems !== 'undefined' && Array.isArray(criticalStockItems)) {
                let critMutated = false;
                criticalStockItems.forEach(it => {
                    if (!it || it.siparis_durumu !== 'SEPETTE') return;
                    const dStr = String(it.siparis_depo || '').toUpperCase();
                    if (dStr === cleanDepo) {
                        it.siparis_durumu = 'SIPARIS_VERILDI';
                        critMutated = true;
                    } else if (dStr.includes('+')) {
                        const parts = dStr.split('+').map(p => p.trim()).filter(Boolean);
                        if (parts.includes(cleanDepo)) {
                            const rem = parts.filter(p => p !== cleanDepo);
                            it.siparis_depo = rem.length > 0 ? rem.join(' + ') : cleanDepo;
                            if (rem.length === 0) it.siparis_durumu = 'SIPARIS_VERILDI';
                            critMutated = true;
                        }
                    }
                });
                if (critMutated) {
                    criticalStockItems.sort((a, b) => {
                        const aDone = (a.siparis_durumu === 'SIPARIS_VERILDI' || a.siparis_durumu === 'SIPARIS_VERILMEYECEK' || a.siparis_durumu === 'SEPETTE') ? 1 : 0;
                        const bDone = (b.siparis_durumu === 'SIPARIS_VERILDI' || b.siparis_durumu === 'SIPARIS_VERILMEYECEK' || b.siparis_durumu === 'SEPETTE') ? 1 : 0;
                        return aDone - bDone;
                    });
                    if (typeof renderCriticalList === 'function') renderCriticalList();
                }
            }
            if (window.smartOrderItems && Array.isArray(window.smartOrderItems)) {
                let smartMutated = false;
                window.smartOrderItems.forEach(it => {
                    if (!it || it.siparis_durumu !== 'SEPETTE') return;
                    const dStr = String(it.siparis_depo || '').toUpperCase();
                    if (dStr === cleanDepo) {
                        it.siparis_durumu = 'SIPARIS_VERILDI';
                        smartMutated = true;
                    } else if (dStr.includes('+')) {
                        const parts = dStr.split('+').map(p => p.trim()).filter(Boolean);
                        if (parts.includes(cleanDepo)) {
                            const rem = parts.filter(p => p !== cleanDepo);
                            it.siparis_depo = rem.length > 0 ? rem.join(' + ') : cleanDepo;
                            if (rem.length === 0) it.siparis_durumu = 'SIPARIS_VERILDI';
                            smartMutated = true;
                        }
                    }
                });
                if (smartMutated && typeof renderSmartOrderTable === 'function') {
                    renderSmartOrderTable();
                }
            }
            if (typeof refreshCurrentSearchOrderBanner === 'function') {
                refreshCurrentSearchOrderBanner();
            }
            // 2. Toplu sipariş hafızasını güncelle (Yalnızca bu depoya gerçekten eklenmiş ADDED kalemleri ORDERED yap)
            if (window.currentBulkState) {
                if (Array.isArray(window.currentBulkState.allResults)) {
                    window.currentBulkState.allResults.forEach(r => {
                        if (r.status === 'ADDED' && r.assigned_depo && r.assigned_depo.toUpperCase() === cleanDepo) {
                            r.status = 'ORDERED';
                            r.message = 'Sipariş Verildi';
                        }
                    });
                }
                window.currentBulkState.depoSessions = window.currentBulkState.depoSessions || {};
                if (window.currentBulkState.depoSessions[cleanDepo]) {
                    window.currentBulkState.depoSessions[cleanDepo].finalized = true;
                }
            }
            const unfinAfter = getUnfinalizedBulkDepos(cleanDepo);
            const missingAfter = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];
            const pText = document.getElementById('bulkProgressText');
            if (pText) {
                if (unfinAfter.length > 0) {
                    const nextInfo = getDepoSessionDisplayInfo(unfinAfter[0]);
                    pText.innerHTML = `<strong class="text-emerald-700">${cleanDepo} Siparişi Onaylandı ✅:</strong> Sırada onay bekleyen <strong class="text-indigo-700">${unfinAfter.length} depo (${nextInfo.name} - ${nextInfo.count} Kalem)</strong> bulunuyor.`;
                } else if (missingAfter.length > 0) {
                    pText.innerHTML = `<strong class="text-emerald-700">${cleanDepo} Siparişi Onaylandı ✅:</strong> Geriye sipariş verilmeyen <strong class="text-rose-600">${missingAfter.length} eksik ürün</strong> kaldı. Başka depoya aktarabilirsiniz.`;
                } else {
                    pText.innerHTML = `<strong class="text-emerald-700">Tüm Siparişler Onaylandı ✅:</strong> Seçilen tüm depolardaki siparişler başarıyla iletildi!`;
                }
            }
            // Eğer sonlandırılmamış depo kalmadıysa ve sadece sipariş verilmeyen (eksik) ürünler kaldıysa, otomatik Eksikler sekmesine geç
            if (unfinAfter.length === 0 && missingAfter.length > 0 && typeof switchBulkResultTab === 'function') {
                switchBulkResultTab('YOK');
            }
            updateBulkMainFinalizeButtonUI();
            if (typeof renderDepoBreakdownPills === 'function') renderDepoBreakdownPills();
            if (typeof renderBulkItemsTable === 'function') renderBulkItemsTable();
            if (typeof updateMultiDepotCartUI === 'function') updateMultiDepotCartUI();
            if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
            if (window.smartOrderLoadedOnce && typeof loadSmartOrderList === 'function') loadSmartOrderList(true);
        }

        function markBulkSessionClearedInUI(depo) {
            const cleanDepo = (depo || '').toUpperCase();
            if (window.singleAddDepoMeta && window.singleAddDepoMeta[cleanDepo]) {
                delete window.singleAddDepoMeta[cleanDepo];
            }
            if (window.todayOrdersMap) {
                Object.keys(window.todayOrdersMap).forEach(k => {
                    const entry = window.todayOrdersMap[k];
                    if (!entry || entry.durum !== 'SEPETTE') return;
                    const dStr = String(entry.depo || '').toUpperCase();
                    if (dStr === cleanDepo) {
                        delete window.todayOrdersMap[k];
                    } else if (dStr.includes('+')) {
                        const parts = dStr.split('+').map(p => p.trim()).filter(Boolean);
                        if (parts.includes(cleanDepo)) {
                            const rem = parts.filter(p => p !== cleanDepo);
                            if (rem.length > 0) {
                                entry.depo = rem.join(' + ');
                            } else {
                                delete window.todayOrdersMap[k];
                            }
                        }
                    }
                });
            }
            if (typeof criticalStockItems !== 'undefined' && Array.isArray(criticalStockItems)) {
                let critCleared = false;
                criticalStockItems.forEach(it => {
                    if (!it || it.siparis_durumu !== 'SEPETTE') return;
                    const dStr = String(it.siparis_depo || '').toUpperCase();
                    if (dStr === cleanDepo) {
                        it.siparis_durumu = null;
                        it.siparis_depo = null;
                        it.siparis_miktar = null;
                        critCleared = true;
                    } else if (dStr.includes('+')) {
                        const parts = dStr.split('+').map(p => p.trim()).filter(Boolean);
                        if (parts.includes(cleanDepo)) {
                            const rem = parts.filter(p => p !== cleanDepo);
                            if (rem.length > 0) {
                                it.siparis_depo = rem.join(' + ');
                            } else {
                                it.siparis_durumu = null;
                                it.siparis_depo = null;
                                it.siparis_miktar = null;
                            }
                            critCleared = true;
                        }
                    }
                });
                if (critCleared && typeof renderCriticalList === 'function') {
                    renderCriticalList();
                }
            }
            if (window.smartOrderItems && Array.isArray(window.smartOrderItems)) {
                let smartCleared = false;
                window.smartOrderItems.forEach(it => {
                    if (!it || it.siparis_durumu !== 'SEPETTE') return;
                    const dStr = String(it.siparis_depo || '').toUpperCase();
                    if (dStr === cleanDepo) {
                        it.siparis_durumu = null;
                        it.siparis_depo = null;
                        it.siparis_miktar = null;
                        smartCleared = true;
                    } else if (dStr.includes('+')) {
                        const parts = dStr.split('+').map(p => p.trim()).filter(Boolean);
                        if (parts.includes(cleanDepo)) {
                            const rem = parts.filter(p => p !== cleanDepo);
                            if (rem.length > 0) {
                                it.siparis_depo = rem.join(' + ');
                            } else {
                                it.siparis_durumu = null;
                                it.siparis_depo = null;
                                it.siparis_miktar = null;
                            }
                            smartCleared = true;
                        }
                    }
                });
                if (smartCleared && typeof renderSmartOrderTable === 'function') {
                    renderSmartOrderTable();
                }
            }
            if (typeof refreshCurrentSearchOrderBanner === 'function') {
                refreshCurrentSearchOrderBanner();
            }
            if (window.currentBulkState && Array.isArray(window.currentBulkState.allResults)) {
                window.currentBulkState.allResults.forEach(r => {
                    if (r.status === 'ADDED' && r.assigned_depo && r.assigned_depo.toUpperCase() === cleanDepo) {
                        r.status = 'CLEARED';
                        r.message = 'Sepetten Silindi';
                    }
                });
                if (window.currentBulkState.depoSessions && window.currentBulkState.depoSessions[cleanDepo]) {
                    window.currentBulkState.depoSessions[cleanDepo].cleared = true;
                }
            }
            updateBulkMainFinalizeButtonUI();
            if (typeof renderDepoBreakdownPills === 'function') renderDepoBreakdownPills();
            if (typeof renderBulkItemsTable === 'function') renderBulkItemsTable();
            if (typeof updateMultiDepotCartUI === 'function') updateMultiDepotCartUI();
            if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
            if (window.smartOrderLoadedOnce && typeof loadSmartOrderList === 'function') loadSmartOrderList(true);
        }

        function closeBulkFinalizeModal(alsoCloseBulkModal = false) {
            const modal = document.getElementById('bulkFinalizeModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
            const missing = (window.currentBulkState && window.currentBulkState.missingItems) ? window.currentBulkState.missingItems : [];
            const remainingDepos = getUnfinalizedBulkDepos();
            // Sipariş verilmeyen hiçbir ürün veya sonlandırılmamış depo kalmadıysa ana toplu sipariş modalını da kapat
            if ((alsoCloseBulkModal || (missing.length === 0 && remainingDepos.length === 0)) && missing.length === 0 && remainingDepos.length === 0) {
                if (typeof closeBulkOrderModal === 'function') {
                    closeBulkOrderModal();
                }
            }
            if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
        }

        function collectExpectedCartItemsForDepo(depo) {
            const targetDepo = (depo || 'SELCUK').toUpperCase();
            const map = new Map();
            const sess = (window.currentBulkState && window.currentBulkState.depoSessions && window.currentBulkState.depoSessions[targetDepo]) || null;

            // 1. Toplu sipariş hafızasındaki kalemler (Sadece henüz sonlandırılmamış ve gerçekten bu depoya ADDED olanlar!)
            const combinedBulkResults = [
                ...((window.currentBulkState && Array.isArray(window.currentBulkState.preservedResults)) ? window.currentBulkState.preservedResults : []),
                ...((window.currentBulkState && Array.isArray(window.currentBulkState.allResults)) ? window.currentBulkState.allResults : [])
            ];
            if (combinedBulkResults.length > 0 && (!sess || (!sess.finalized && !sess.cleared))) {
                combinedBulkResults
                    .filter(r => r && r.status === 'ADDED' && r.assigned_depo && r.assigned_depo.toUpperCase() === targetDepo)
                    .forEach(it => {
                        const key = (it.barcode || it.name || '').trim().toUpperCase();
                        if (key) {
                            map.set(key, {
                                barcode: it.barcode || '',
                                name: it.name || '',
                                miktar: parseInt(it.miktar) || 1,
                                urun_id: it.urun_id || ''
                            });
                        }
                    });
            }

            // 2. Tekli arama veya hızlı gönderimle SEPETTE olarak işaretlenmiş kalemler
            if (typeof getActiveCartGroupsByDepo === 'function') {
                const groups = getActiveCartGroupsByDepo();
                const grp = groups[targetDepo];
                if (grp && Array.isArray(grp.items)) {
                    grp.items.forEach(it => {
                        const bcKey = (it.barkod || '').trim().toUpperCase();
                        const nmKey = (it.urun_adi || '').trim().toUpperCase();
                        if ((bcKey && map.has(bcKey)) || (nmKey && map.has(nmKey))) return;
                        const key = bcKey || nmKey;
                        if (key) {
                            map.set(key, {
                                barcode: it.barkod || '',
                                name: it.urun_adi || '',
                                miktar: parseInt(it.miktar) || 1,
                                urun_id: it.barkod || ''
                            });
                        }
                    });
                }
            }

            return Array.from(map.values());
        }

        async function openBulkFinalizeFlow(customDepo) {
            if (!customDepo && getUnfinalizedBulkDepos().length === 0) {
                const missingAfter = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];
                if (missingAfter.length > 0 && typeof moveAllMissingBulkItemsToYok === 'function') {
                    await moveAllMissingBulkItemsToYok(false);
                    return;
                }
                showToast('Bilgi', 'Sepette onay bekleyen aktif depo siparişi bulunmuyor.', 'info');
                return;
            }
            const depo = (customDepo || getNextUnfinalizedBulkDepo() || (window.currentBulkState && window.currentBulkState.depo) || 'SELCUK').toUpperCase();
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depo)) {
                showToast('Bilgi', 'Pazaryeri ve ortak alım siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            if (typeof closeMultiDepotCartModal === 'function') {
                closeMultiDepotCartModal();
            }

            const modal = document.getElementById('bulkFinalizeModal');
            const badgeEl = document.getElementById('bulkFinDepoBadge');
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');

            if (!modal || !bodyEl || !footerEl) return;

            const depoNames = {
                'SELCUK': 'Selçuk Ecza',
                'NEVZAT': 'Nevzat Ecza',
                'ALLIANCE': 'Alliance Healthcare',
                'ISKOOP': 'İSKOOP E-Şube'
            };
            if (badgeEl) badgeEl.innerText = depoNames[depo] || depo;

            modal.classList.remove('hidden');
            modal.style.display = 'flex';

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-circle-notch fa-spin text-3xl text-emerald-500 mb-3"></i>
                    <div class="font-extrabold text-slate-800 text-sm">Depo Sepeti ve Sipariş Listesi Kontrol Ediliyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depoNames[depo] || depo} canlı sepetindeki ürünler bugünkü listenizle karşılaştırılıyor...</div>
                </div>
            `;
            footerEl.innerHTML = `
                <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
            `;

            // Bugünkü siparişte ilgili depoya eklenen kalemleri (toplu + tekli aramadan eklenenler) al
            const addedItems = collectExpectedCartItemsForDepo(depo);

            try {
                const res = await fetch('/api/cart/bulk-finalize-check', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        items: addedItems
                    })
                });
                const checkData = await res.json();

                if (!checkData.success) {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-exclamation mr-1.5"></i>Sepet Sorgulanamadı</div>
                            <div>${checkData.message || 'Depo sepet bilgisi alınamadı.'}</div>
                        </div>
                    `;
                    return;
                }

                if (checkData.cart_count === 0) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-8 space-y-3">
                            <div class="w-14 h-14 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto text-2xl">
                                <i class="fa-solid fa-cart-shopping"></i>
                            </div>
                            <div class="font-black text-slate-900 text-sm">${depoNames[depo] || depo} Sepeti Boş Görünüyor</div>
                            <p class="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                                ${depoNames[depo] || depo} canlı sepetinde şu anda ürün bulunmuyor. Siparişinizi depo web sayfasından zaten onayladıysanız aşağıdaki butonla <strong>Sipariş Verildi</strong> olarak işaretleyebilir veya sepet uyarısını temizleyebilirsiniz.
                            </p>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex flex-wrap items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                            <div class="flex flex-wrap items-center gap-2">
                                <button type="button" onclick="onlyClearCartFromBulk('${depo}')" class="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition cursor-pointer">
                                    <i class="fa-solid fa-trash-can mr-1"></i>Sepet Uyarısını Temizle
                                </button>
                                <button type="button" onclick="confirmEmptyCartAsOrdered('${depo}')" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm transition cursor-pointer">
                                    <i class="fa-solid fa-circle-check mr-1"></i>Sipariş Verildi Olarak İşaretle
                                </button>
                            </div>
                        </div>
                    `;
                    return;
                }

                if (!checkData.has_extra_items) {
                    // Sepette sadece bugünkü sipariş ürünleri var! Doğrudan onaylanabilir
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Başarılı Eşleşme Bilgisi -->
                            <div class="p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-300 flex items-start space-x-3.5">
                                <div class="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                                    <i class="fa-solid fa-shield-check text-base"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-extrabold text-emerald-950 text-sm">Sepet Kontrolü Başarılı — Yabancı Ürün Yok ✅</div>
                                    <div class="text-emerald-800 mt-1 leading-relaxed">
                                        ${depoNames[depo] || depo} sepetinizde sadece az önce eklediğiniz <strong>${checkData.cart_count} kalem ürün</strong> yer alıyor.
                                        Sepette önceden kalmış veya yabancı bir ürün bulunmamaktadır.
                                    </div>
                                </div>
                            </div>

                            <!-- Sepet Tutarı ve Kalem Sayısı Kartı -->
                            <div class="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center justify-between gap-2">
                                <div>
                                    <div class="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Onaylanacak Sipariş</div>
                                    <div class="text-base font-black text-slate-900 mt-0.5">${checkData.cart_count} Kalem İlaç</div>
                                </div>
                                <div class="flex items-center gap-3">
                                    <div class="text-right">
                                        <div class="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Sepet Tutarı</div>
                                        <div class="text-lg font-black text-emerald-600 font-mono">${(checkData.total_amount || 0).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺</div>
                                    </div>
                                    <button type="button" onclick="onlyClearCartFromBulk('${depo}')" class="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-500 hover:text-rose-700 border border-slate-200 hover:border-rose-200 text-[10px] font-bold transition cursor-pointer" title="Sepeti tamamen boşalt">
                                        <i class="fa-solid fa-trash-can mr-1"></i>Boşalt
                                    </button>
                                </div>
                            </div>

                            <!-- Sepetteki Ürünlerin Listesi (Yeşil Onaylı) -->
                            <div class="bg-emerald-50/50 rounded-2xl border border-emerald-200 p-3 max-h-56 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-black text-emerald-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>✅ Sepetteki Ürünler (${checkData.cart_count} Kalem):</span>
                                    <span class="px-2 py-0.5 rounded bg-emerald-600 text-white text-[9px] font-black">HAZIR</span>
                                </div>
                                ${(checkData.all_items || []).map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-3 rounded-xl bg-white border border-emerald-200 text-xs">
                                        <span class="font-bold text-emerald-950 truncate mr-2"><i class="fa-solid fa-check text-emerald-500 mr-1.5 text-[10px]"></i>${it.ad || it.urun_adi || 'Ürün'}</span>
                                        <span class="font-extrabold text-emerald-700 whitespace-nowrap font-mono">${it.miktar} Kutu ${(it.tutar ? `(${it.tutar.toFixed(2)} ₺)` : '')}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `;

                    footerEl.innerHTML = `
                        <div class="flex items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
                            <button type="button" onclick="executeBulkFinalizeSubmit('${depo}', true)" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md hover:shadow-lg transition flex items-center space-x-2 cursor-pointer">
                                <i class="fa-solid fa-paper-plane text-xs"></i>
                                <span>Siparişi Onayla & Depoya Gönder</span>
                            </button>
                        </div>
                    `;
                } else {
                    // Sepette FARKLI / ÖNCEDEN EKLENMİŞ YABANCI ÜRÜNLER VAR! Kırmızı uyarı göster
                    bodyEl.innerHTML = `
                        <div class="space-y-3.5">
                            <!-- Kırmızı Dikkat Uyarısı -->
                            <div class="p-3.5 rounded-2xl bg-rose-100 border-2 border-rose-500 flex items-start justify-between gap-2 shadow-sm">
                                <div class="flex items-start space-x-3">
                                    <div class="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow">
                                        <i class="fa-solid fa-triangle-exclamation text-sm"></i>
                                    </div>
                                    <div class="text-xs">
                                        <div class="font-black text-rose-950 text-sm">🚨 Depo Sepetinde Önceden Kalmış Ürünler Var!</div>
                                        <div class="text-rose-900 mt-0.5 leading-relaxed">
                                            ${depoNames[depo] || depo} sepetinizde <strong class="underline">${checkData.extra_count} farklı ürün</strong> daha bulundu.
                                            Sepet Toplamı: <strong>${(checkData.total_amount || 0).toFixed(2)} ₺</strong>
                                        </div>
                                    </div>
                                </div>
                                <button type="button" onclick="onlyClearCartFromBulk('${depo}')" class="px-2.5 py-1 rounded-lg bg-white/80 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-300 text-[10px] font-bold transition shrink-0 cursor-pointer" title="Sepeti tamamen boşalt">
                                    <i class="fa-solid fa-trash-can mr-1"></i>Boşalt
                                </button>
                            </div>

                            <!-- KIRMIZI: Farklı / Önceden Eklenmiş Ürünler Listesi -->
                            <div class="bg-rose-50 rounded-2xl border-2 border-rose-400 p-3 max-h-40 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-black text-rose-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-ban mr-1 text-rose-600"></i>🚨 Önceden Sepette Olanlar (${checkData.extra_count} Kalem):</span>
                                    <span class="px-2 py-0.5 rounded bg-rose-600 text-white text-[9px] font-black">${(checkData.extra_total || 0).toFixed(2)} ₺</span>
                                </div>
                                ${(checkData.extra_items || []).map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-3 rounded-xl bg-rose-100/90 border border-rose-300 text-xs shadow-2xs">
                                        <span class="font-extrabold text-rose-950 truncate mr-2"><i class="fa-solid fa-circle-exclamation text-rose-600 mr-1.5 text-[10px]"></i>${it.ad || it.urun_adi || 'Ürün'}</span>
                                        <span class="font-black text-rose-800 whitespace-nowrap font-mono">${it.miktar} Kutu ${(it.tutar ? `(${it.tutar.toFixed(2)} ₺)` : '')}</span>
                                    </div>
                                `).join('')}
                            </div>

                            <!-- YEŞİL: Şimdi / Bu Siparişte Eklenen Kalemler -->
                            <div class="bg-emerald-50 rounded-2xl border-2 border-emerald-300 p-3 max-h-36 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-black text-emerald-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>✅ Şimdi Eklenenler (${checkData.matched_count} Kalem):</span>
                                    <span class="px-2 py-0.5 rounded bg-emerald-600 text-white text-[9px] font-black">YENİ</span>
                                </div>
                                ${(checkData.matched_items || []).map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-2.5 rounded-lg bg-white border border-emerald-200 text-xs">
                                        <span class="font-bold text-emerald-950 truncate mr-2"><i class="fa-solid fa-check text-emerald-500 mr-1.5 text-[10px]"></i>${it.ad || it.urun_adi || 'Ürün'}</span>
                                        <span class="font-extrabold text-emerald-700 whitespace-nowrap font-mono">${it.miktar} Kutu</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `;

                    footerEl.innerHTML = `
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition w-full sm:w-auto cursor-pointer">Vazgeç</button>
                            <div class="flex flex-wrap items-center gap-2 justify-end w-full sm:w-auto">
                                <button type="button" onclick="cleanCartAndSubmitBulk('${depo}')" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition flex items-center space-x-1.5 cursor-pointer shadow-sm" title="Önceki ürünleri çıkarır ve yalnızca yeni eklediklerinizi gönderir">
                                    <i class="fa-solid fa-check text-[10px]"></i>
                                    <span>Sadece Yeni Eklenenleri Gönder</span>
                                </button>
                                <button type="button" onclick="executeBulkFinalizeSubmit('${depo}', true)" class="px-4 py-2 bg-gradient-to-r from-rose-600 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white rounded-xl text-xs font-black shadow-sm transition flex items-center space-x-1.5 cursor-pointer" title="Tüm sepeti beraber onaylar">
                                    <i class="fa-solid fa-paper-plane text-[10px]"></i>
                                    <span>Tüm Sepeti Gönder</span>
                                </button>
                            </div>
                        </div>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
            }
        }

        async function executeBulkFinalizeSubmit(depo, force) {
            if (window._bulkFinalizeInFlight) return;
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');
            if (!bodyEl || !footerEl) return;
            window._bulkFinalizeInFlight = true;

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-spinner fa-spin text-4xl text-emerald-500 mb-3"></i>
                    <div class="font-black text-slate-800 text-base">Sipariş Depoya İletiliyor ve Sonlandırılıyor...</div>
                    <div class="text-xs text-slate-500 mt-1">${depo} B2B sistemi üzerinde sipariş onaylanıyor, lütfen bekleyiniz...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            const addedItems = collectExpectedCartItemsForDepo(depo);

            try {
                const res = await fetch('/api/cart/finalize', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: '',
                        barkod: '',
                        miktar: 1,
                        force: force,
                        items: addedItems
                    })
                });
                const result = await res.json();

                if (result.success) {
                    const sentInfo = getDepoSessionDisplayInfo(depo);
                    const sentCount = sentInfo.count || (addedItems ? addedItems.length : 0);
                    showToast('Sipariş Sonlandırıldı', result.message, 'success');
                    markBulkSessionFinalizedInUI(depo);
                    if (typeof syncTodayOrdersAcrossPCs === 'function') await syncTodayOrdersAcrossPCs();
                    const remainingDepos = getUnfinalizedBulkDepos(depo);
                    const nextDepo = remainingDepos.length > 0 ? remainingDepos[0] : null;
                    const nextSess = nextDepo ? getDepoSessionDisplayInfo(nextDepo) : null;
                    const missingItems = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];
                    const missingYokHtml = missingItems.length > 0 ? `
                        <div id="bulkFinMissingYokBox" class="p-3.5 rounded-2xl bg-rose-50 border-2 border-rose-300 text-left max-w-lg mx-auto mt-3 shadow-xs space-y-2">
                            <div class="flex items-start justify-between gap-2">
                                <div class="flex items-start space-x-2">
                                    <div class="w-7 h-7 rounded-lg bg-rose-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                                        <i class="fa-solid fa-ban text-xs"></i>
                                    </div>
                                    <div>
                                        <div class="text-xs font-black text-rose-950">🚨 Depolarda Bulunamayan ${missingItems.length} Eksik Ürün Var</div>
                                        <div class="text-[11px] font-medium text-rose-800 mt-0.5">Siparişi verilemeyen bu ilaçları tüm bilgisayarlarda görünen ortak <strong>Yok Listesi</strong>'ne tek tıkla atabilirsiniz:</div>
                                    </div>
                                </div>
                            </div>
                            <div class="max-h-24 overflow-y-auto bg-white/80 rounded-xl border border-rose-200 px-2.5 py-1.5 text-[11px] font-bold text-slate-700 space-y-0.5">
                                ${missingItems.map((m, idx) => `<div class="truncate">${idx + 1}. ${m.name || m.barcode} <span class="text-[10px] font-mono text-slate-400">(${m.barcode || ''})</span></div>`).join('')}
                            </div>
                            <button type="button" onclick="moveAllMissingBulkItemsToYok(true)" class="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white text-xs font-black shadow-sm transition flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98">
                                <i class="fa-solid fa-ban text-xs"></i>
                                <span>🚨 Depolarda Olmayan ${missingItems.length} Ürünü Yok Listesine At</span>
                            </button>
                        </div>
                    ` : '';
                    const remainingHtml = remainingDepos.length > 0 ? `
                        <div class="p-4 rounded-2xl bg-amber-50 border-2 border-amber-400 text-left max-w-lg mx-auto mt-3 shadow-sm space-y-2.5">
                            <div class="flex items-start space-x-2.5">
                                <div class="w-7 h-7 rounded-lg bg-amber-500 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                                    <i class="fa-solid fa-triangle-exclamation text-xs"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-amber-950 uppercase tracking-wide">
                                        ⚠️ DİKKAT: Diğer Depo Sepetiniz Henüz Gönderilmedi! (${remainingDepos.length} Depo Bekliyor)
                                    </div>
                                    <div class="text-[11px] font-bold text-amber-800 mt-0.5">
                                        <strong>${sentInfo.name}</strong> siparişiniz gönderildi; ancak aşağıdaki deponun ürünleri hâlâ sepette onay bekliyor:
                                    </div>
                                </div>
                            </div>
                            <div class="space-y-2 pt-1">
                                ${remainingDepos.map(rk => {
                                    const rs = getDepoSessionDisplayInfo(rk);
                                    const badgeText = `${rs.count} Kalem (${rs.boxes || rs.count} Kutu)` + (rs.amount > 0 ? ` • ${rs.amount.toFixed(2)} ₺` : '');
                                    return `
                                    <div class="p-2.5 rounded-xl bg-white border-2 border-amber-300 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs">
                                        <div>
                                            <div class="flex items-center space-x-1.5">
                                                <span class="px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-black">⏳ HENÜZ GÖNDERİLMEDİ</span>
                                                <span class="text-xs font-black text-slate-900">${rs.name}</span>
                                            </div>
                                            <div class="text-[11px] font-bold text-slate-600 mt-1">Sepette Bekleyen: <strong class="text-indigo-700 font-mono">${badgeText}</strong></div>
                                        </div>
                                        <button type="button" onclick="openBulkFinalizeFlow('${rk}')" class="px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white text-xs font-black flex items-center justify-center space-x-1.5 transition cursor-pointer shadow-sm shrink-0">
                                            <i class="fa-solid fa-paper-plane text-[10px]"></i>
                                            <span>${rs.name} Siparişini Sonlandır ➔</span>
                                        </button>
                                    </div>`;
                                }).join('')}
                            </div>
                        </div>
                    ` : `
                        <div class="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold max-w-md mx-auto mt-3 flex items-center justify-center space-x-2">
                            <i class="fa-solid fa-circle-check text-emerald-600 text-sm"></i>
                            <span>Sepette bekleyen başka depo kalmadı. Tüm depo siparişleriniz tamamlandı!</span>
                        </div>
                    `;

                    bodyEl.innerHTML = `
                        <div class="text-center py-5 space-y-3.5">
                            <div class="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-2xl shadow-lg shadow-emerald-500/20">
                                <i class="fa-solid fa-check animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">${sentInfo.name} Siparişi Gönderildi! 🎉</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message || `${sentInfo.name} siparişiniz depoya başarıyla iletildi.`}</p>
                                <div class="mt-2 inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-black">
                                    <i class="fa-solid fa-circle-check text-emerald-600"></i>
                                    <span>✅ ${sentInfo.name}: SİPARİŞ ONAYLANDI ${sentCount > 0 ? `(${sentCount} Kalem)` : ''}</span>
                                </div>
                                ${result.order_info ? `<div class="mt-2 block"><span class="inline-block px-3 py-1 rounded-xl bg-slate-100 border border-slate-200 text-slate-800 text-xs font-mono font-bold">${result.order_info}</span></div>` : ''}
                            </div>
                            ${remainingHtml}
                            ${missingYokHtml}
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex flex-wrap items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal(true)" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition cursor-pointer">${nextDepo ? 'Kapat' : 'Tamam'}</button>
                            <div class="flex flex-wrap items-center gap-2">
                                ${result.portal_url ? `<a href="${result.portal_url}" target="_blank" class="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1.5"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Portal ↗</span></a>` : ''}
                                ${nextDepo ? `
                                    <button type="button" onclick="openBulkFinalizeFlow('${nextDepo}')" class="px-4 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white rounded-xl text-xs font-black shadow-md transition flex items-center space-x-1.5 cursor-pointer">
                                        <i class="fa-solid fa-forward-step text-xs"></i>
                                        <span>Sıradaki: ${nextSess.name} (${nextSess.count} Kalem) ➔</span>
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                    `;
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sipariş Onaylanamadı</div>
                            <div class="leading-relaxed">${result.message || 'Bilinmeyen bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            } finally {
                window._bulkFinalizeInFlight = false;
            }
        }

        async function cleanCartAndSubmitBulk(depo) {
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-spinner fa-spin text-4xl text-rose-500 mb-3"></i>
                    <div class="font-black text-slate-800 text-base">Farklı Ürünler Temizleniyor & Günlük Sipariş Hazırlanıyor...</div>
                    <div class="text-xs text-slate-500 mt-1">Önceki yabancı ürünler sepetten çıkarılıyor, ardından sadece bugünkü siparişiniz eklenip depoya gönderilecek...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            const addedItems = collectExpectedCartItemsForDepo(depo);

            try {
                const res = await fetch('/api/cart/bulk-finalize-clean-submit', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        items: addedItems
                    })
                });
                const result = await res.json();

                if (result.success) {
                    const sentInfo = getDepoSessionDisplayInfo(depo);
                    const sentCount = sentInfo.count || (addedItems ? addedItems.length : 0);
                    showToast('Sipariş Sonlandırıldı', result.message || 'Farklı ürünler çıkarılarak sipariş onaylandı.', 'success');
                    markBulkSessionFinalizedInUI(depo);
                    if (typeof syncTodayOrdersAcrossPCs === 'function') await syncTodayOrdersAcrossPCs();
                    const remainingDepos = getUnfinalizedBulkDepos(depo);
                    const nextDepo = remainingDepos.length > 0 ? remainingDepos[0] : null;
                    const nextSess = nextDepo ? getDepoSessionDisplayInfo(nextDepo) : null;
                    const missingItems = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];
                    const missingYokHtml = missingItems.length > 0 ? `
                        <div id="bulkFinMissingYokBox" class="p-3.5 rounded-2xl bg-rose-50 border-2 border-rose-300 text-left max-w-lg mx-auto mt-3 shadow-xs space-y-2">
                            <div class="flex items-start justify-between gap-2">
                                <div class="flex items-start space-x-2">
                                    <div class="w-7 h-7 rounded-lg bg-rose-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                                        <i class="fa-solid fa-ban text-xs"></i>
                                    </div>
                                    <div>
                                        <div class="text-xs font-black text-rose-950">🚨 Depolarda Bulunamayan ${missingItems.length} Eksik Ürün Var</div>
                                        <div class="text-[11px] font-medium text-rose-800 mt-0.5">Siparişi verilemeyen bu ilaçları tüm bilgisayarlarda görünen ortak <strong>Yok Listesi</strong>'ne tek tıkla atabilirsiniz:</div>
                                    </div>
                                </div>
                            </div>
                            <div class="max-h-24 overflow-y-auto bg-white/80 rounded-xl border border-rose-200 px-2.5 py-1.5 text-[11px] font-bold text-slate-700 space-y-0.5">
                                ${missingItems.map((m, idx) => `<div class="truncate">${idx + 1}. ${m.name || m.barcode} <span class="text-[10px] font-mono text-slate-400">(${m.barcode || ''})</span></div>`).join('')}
                            </div>
                            <button type="button" onclick="moveAllMissingBulkItemsToYok(true)" class="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white text-xs font-black shadow-sm transition flex items-center justify-center space-x-1.5 cursor-pointer active:scale-98">
                                <i class="fa-solid fa-ban text-xs"></i>
                                <span>🚨 Depolarda Olmayan ${missingItems.length} Ürünü Yok Listesine At</span>
                            </button>
                        </div>
                    ` : '';
                    const remainingHtml = remainingDepos.length > 0 ? `
                        <div class="p-4 rounded-2xl bg-amber-50 border-2 border-amber-400 text-left max-w-lg mx-auto mt-3 shadow-sm space-y-2.5">
                            <div class="flex items-start space-x-2.5">
                                <div class="w-7 h-7 rounded-lg bg-amber-500 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                                    <i class="fa-solid fa-triangle-exclamation text-xs"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-amber-950 uppercase tracking-wide">
                                        ⚠️ DİKKAT: Diğer Depo Sepetiniz Henüz Gönderilmedi! (${remainingDepos.length} Depo Bekliyor)
                                    </div>
                                    <div class="text-[11px] font-bold text-amber-800 mt-0.5">
                                        <strong>${sentInfo.name}</strong> siparişiniz gönderildi; ancak aşağıdaki deponun ürünleri hâlâ sepette onay bekliyor:
                                    </div>
                                </div>
                            </div>
                            <div class="space-y-2 pt-1">
                                ${remainingDepos.map(rk => {
                                    const rs = getDepoSessionDisplayInfo(rk);
                                    const badgeText = `${rs.count} Kalem (${rs.boxes || rs.count} Kutu)` + (rs.amount > 0 ? ` • ${rs.amount.toFixed(2)} ₺` : '');
                                    return `
                                    <div class="p-2.5 rounded-xl bg-white border-2 border-amber-300 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs">
                                        <div>
                                            <div class="flex items-center space-x-1.5">
                                                <span class="px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-black">⏳ HENÜZ GÖNDERİLMEDİ</span>
                                                <span class="text-xs font-black text-slate-900">${rs.name}</span>
                                            </div>
                                            <div class="text-[11px] font-bold text-slate-600 mt-1">Sepette Bekleyen: <strong class="text-indigo-700 font-mono">${badgeText}</strong></div>
                                        </div>
                                        <button type="button" onclick="openBulkFinalizeFlow('${rk}')" class="px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white text-xs font-black flex items-center justify-center space-x-1.5 transition cursor-pointer shadow-sm shrink-0">
                                            <i class="fa-solid fa-paper-plane text-[10px]"></i>
                                            <span>${rs.name} Siparişini Sonlandır ➔</span>
                                        </button>
                                    </div>`;
                                }).join('')}
                            </div>
                        </div>
                    ` : `
                        <div class="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold max-w-md mx-auto mt-3 flex items-center justify-center space-x-2">
                            <i class="fa-solid fa-circle-check text-emerald-600 text-sm"></i>
                            <span>Sepette bekleyen başka depo kalmadı. Tüm depo siparişleriniz tamamlandı!</span>
                        </div>
                    `;

                    bodyEl.innerHTML = `
                        <div class="text-center py-5 space-y-3.5">
                            <div class="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-2xl shadow-lg shadow-emerald-500/20">
                                <i class="fa-solid fa-check animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">${sentInfo.name} Siparişi Gönderildi! 🎉</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">Farklı ürünler sepetten arındırıldı ve yalnızca bugünkü siparişiniz depoya aktarılıp onaylandı.</p>
                                <div class="mt-2 inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-black">
                                    <i class="fa-solid fa-circle-check text-emerald-600"></i>
                                    <span>✅ ${sentInfo.name}: SİPARİŞ ONAYLANDI ${sentCount > 0 ? `(${sentCount} Kalem)` : ''}</span>
                                </div>
                                ${result.order_info ? `<div class="mt-2 block"><span class="inline-block px-3 py-1 rounded-xl bg-slate-100 border border-slate-200 text-slate-800 text-xs font-mono font-bold">${result.order_info}</span></div>` : ''}
                            </div>
                            ${remainingHtml}
                            ${missingYokHtml}
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex flex-wrap items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal(true)" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition cursor-pointer">${nextDepo ? 'Kapat' : 'Tamam'}</button>
                            <div class="flex flex-wrap items-center gap-2">
                                ${result.portal_url ? `<a href="${result.portal_url}" target="_blank" class="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1.5"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Portal ↗</span></a>` : ''}
                                ${nextDepo ? `
                                    <button type="button" onclick="openBulkFinalizeFlow('${nextDepo}')" class="px-4 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white rounded-xl text-xs font-black shadow-md transition flex items-center space-x-1.5 cursor-pointer">
                                        <i class="fa-solid fa-forward-step text-xs"></i>
                                        <span>Sıradaki: ${nextSess.name} (${nextSess.count} Kalem) ➔</span>
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                    `;
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>İşlem Tamamlanamadı</div>
                            <div class="leading-relaxed">${result.message || 'Sipariş iletilirken bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        async function confirmEmptyCartAsOrdered(depo) {
            const addedItems = collectExpectedCartItemsForDepo(depo);
            try {
                await fetch('/api/orders/mark', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        items: addedItems,
                        durum: 'SIPARIS_VERILDI',
                        depo: depo,
                        clear_depo_cart: true
                    })
                });
            } catch (e) {}
            markBulkSessionFinalizedInUI(depo);
            if (typeof syncTodayOrdersAcrossPCs === 'function') await syncTodayOrdersAcrossPCs();
            closeBulkFinalizeModal(true);
            showToast('Sipariş Verildi İşaretlendi', `${depo} sepetindeki ürünler sipariş verildi olarak güncellendi.`, 'success');
        }

        async function onlyClearCartFromBulk(depo) {
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-8">
                    <i class="fa-solid fa-spinner fa-spin text-3xl text-rose-500 mb-3"></i>
                    <div class="font-bold text-slate-800 text-sm">Sepet Boşaltılıyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depo} sepetindeki tüm ürünler siliniyor...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            try {
                const res = await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-rose-500/20">
                                <i class="fa-solid fa-trash-can animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sepetiniz Başarıyla Boşaltıldı 🗑️</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message || `${depo} sepetindeki tüm ürünler temizlendi.`}</p>
                                <p class="text-[11px] text-slate-400 mt-1.5 font-bold">Herhangi bir sipariş onaylanmamış veya iletilmemiştir.</p>
                            </div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                        </div>
                    `;
                    showToast('Sepet Boşaltıldı', `${depo} sepetiniz temizlendi (Sipariş verilmedi).`, 'info');
                    markBulkSessionClearedInUI(depo);
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sepet Temizlenemedi</div>
                            <div class="leading-relaxed">${result.message || 'Sepet boşaltılırken bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }


        async function addSimulatedToCart(btn) {

            if (!currentReport || !selectedDepoForSim) return;
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(selectedDepoForSim)) {
                showToast('Bilgi', 'Pazaryeri ve ortak alım siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const miktar = parseInt(simQtyInput.value) || 1;
            const targetItem = currentReport.sonuclar.find(s => s.depo === selectedDepoForSim) || currentReport.sonuclar[0];
            const urunId = targetItem ? (targetItem.urun_id || targetItem.barkod) : currentReport.barkod;
            const barkod = currentReport.barkod;

            const originalContent = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1"></i>Sepete Ekleniyor...`;

            const prodName = (targetItem && (targetItem.urun_adi || targetItem.name)) || ((typeof currentReport !== 'undefined' && currentReport) ? (currentReport.urun_adi || currentReport.name || '') : '');
            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: selectedDepoForSim,
                        urun_id: urunId,
                        barkod: barkod,
                        miktar: miktar,
                        name: prodName
                    })
                });
                const result = await res.json();
                if (result.success) {
                    let extra = '';
                    if (result.sepet_no) extra += ` (Belge No: ${result.sepet_no})`;
                    if (result.sepet_tutari) extra += ` (Sepet Tutarı: ${result.sepet_tutari} ₺)`;
                    if (typeof recordDepotSessionFromSingleAdd === 'function') {
                        recordDepotSessionFromSingleAdd(selectedDepoForSim, result.sepet_tutari, result.sepet_no, result.portal_url);
                    }
                    const dUp = String(selectedDepoForSim || 'SELCUK').toUpperCase();
                    if (typeof applyOptimisticOrderStatus === 'function') {
                        applyOptimisticOrderStatus([{ barkod: String(barkod || ''), urun_adi: prodName, miktar: miktar, depo: dUp }], 'SEPETTE', dUp);
                    }
                    if (typeof updateMultiDepotCartUI === 'function') {
                        updateMultiDepotCartUI();
                    }
                    if (typeof syncTodayOrdersAcrossPCs === 'function') {
                        await syncTodayOrdersAcrossPCs();
                    }
                    if (typeof refreshCurrentSearchOrderBanner === 'function') {
                        refreshCurrentSearchOrderBanner();
                    }
                    showToast('Simülasyon Sepete Eklendi', `${result.message || `${miktar} kutu ${selectedDepoForSim} sepetine taslak olarak eklendi.`}${extra}`, 'success');
                } else {
                    showToast('Hata', result.message || 'Sepete ekleme başarısız oldu.', 'error');
                }
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalContent;
            }
        }

        // ================= Pazaryeri (Farmazon & Ecza1) Teklif Akordiyonu =================
        function toggleOffersRow(index) {
            const row = document.getElementById(`offersRow_${index}`);
            const chevron = document.getElementById(`offersChevron_${index}`);
            if (!row) return;
            if (row.classList.contains('hidden')) {
                row.classList.remove('hidden');
                if (chevron) chevron.style.transform = 'rotate(180deg)';
            } else {
                row.classList.add('hidden');
                if (chevron) chevron.style.transform = 'rotate(0deg)';
            }
        }

"""
