# -*- coding: utf-8 -*-
"""
backend/license_manager.py
--------------------------
Farma Radar - Ticari Lisanslama, Üye Eczacı Kayıt ve Bulut (Online) Abonelik Doğrulama Motoru.

MİMARİ (Çift Katmanlı Güvenlik + Uzaktan Bulut Kontrolü):
1. Kriptografik İmzalı Lisans Anahtarı (Offline + Online):
   - Lisans anahtarı; Eczane Adı, Eczacı Adı Soyadı, Telefon, GLN, Bitiş Tarihi (YYYY-MM-DD),
     PC Limiti ve Donanım Kimliği (HWID) bilgilerini HMAC-SHA256 imzası ile barındırır.
   - Hem FR-... hem EDP-... önekli anahtarları destekler.
2. Uzaktan Online Lisans Kontrolü (GitHub / Merkezi Sunucu Senkronizasyonu):
   - Yönetici (Admin) CRM panelinden (license_admin_tool.py) bir eczanenin süresini uzattığında,
     durumunu ASKIDA (Pasif) veya AKTİF yaptığında ya da HWID tanımladığında `licenses_cloud.json`
     otomatik olarak GitHub Canlı Portalına yüklenir.
   - Eczanedeki Farma Radar istemcisi periyodik olarak ve açılışta bu imzalı bulut listesini
     kontrol eder; yeni anahtar kopyalamaya gerek kalmadan süreyi otomatik uzatır veya
     askıya alınan/süresi biten eczanenin erişimini anında kısıtlar.
"""

import os
import sys
import json
import time
import hmac
import base64
import hashlib
import socket
import uuid
import datetime
import threading
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, Tuple

# Sadece geliştirici (Admin) lisans üreticide tam karşılığı bulunan doğrulama anahtarı
_MASTER_VERIFY_SALT = b"EczaneDepoPro_Commercial_v1_MasterKey_2026_!#987"
_CLOUD_SYNC_BYTES = [
    34, 11, 10, 62, 37, 41, 49, 41, 54, 21, 24, 64, 93, 56, 36, 11, 3, 55, 21, 5,
    10, 14, 5, 54, 110, 34, 2, 43, 126, 40, 0, 31, 7, 6, 121, 19, 58, 7, 98, 83
]


def _normalize_tr(text: str) -> str:
    """Türkçe karakter duyarsız büyük harf normalizasyonu (eşleştirme için)."""
    if not text:
        return ""
    tr_map = str.maketrans({
        "ç": "C", "Ç": "C",
        "ğ": "G", "Ğ": "G",
        "ı": "I", "I": "I", "i": "I", "İ": "I",
        "ö": "O", "Ö": "O",
        "ş": "S", "Ş": "S",
        "ü": "U", "Ü": "U",
    })
    cleaned = text.translate(tr_map).upper()
    return " ".join(cleaned.split())


class LicenseManager:
    def __init__(self, base_dir: Optional[str] = None):
        if base_dir:
            self.base_dir = base_dir
        else:
            if getattr(sys, "frozen", False):
                self.base_dir = os.path.dirname(os.path.abspath(sys.executable))
            else:
                self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        self.license_file = os.path.join(self.base_dir, "license.json")
        self.version_file = os.path.join(self.base_dir, "version.json")
        self.telemetry_file = os.path.join(self.base_dir, "data", "usage_telemetry.json")
        self._last_cloud_sync_ts: float = 0.0
        self._cloud_cache_ttl: float = 25.0  # 25 saniyede bir sıfır-önbellekli otomatik kontrol
        self._cached_status: Optional[Dict[str, Any]] = None
        self._cached_status_ts: float = 0.0
        self._cached_hwid: Optional[str] = None
        self._last_telemetry_push_ts: float = 0.0
        self._telemetry_push_running: bool = False
        self._telemetry_lock = threading.Lock()

    def get_hardware_id(self) -> str:
        """Bu bilgisayarın benzersiz donanım kimliğini (HWID) üretir (XXXX-XXXX-XXXX) ve bellekte önbellekler (siyah pencere açmaz)."""
        if self._cached_hwid:
            return self._cached_hwid
        raw_id = ""
        if sys.platform == "win32":
            try:
                import subprocess
                si = subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                si.wShowWindow = getattr(subprocess, "SW_HIDE", 0)
                cflags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
                out = subprocess.check_output(
                    ["wmic", "csproduct", "get", "uuid"],
                    creationflags=cflags,
                    startupinfo=si,
                    stdin=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=2.5
                ).decode("utf-8", errors="ignore")
                lines = [ln.strip() for ln in out.splitlines() if ln.strip() and "UUID" not in ln.upper()]
                if lines:
                    raw_id = lines[0]
            except Exception:
                pass
            if not raw_id:
                try:
                    import winreg
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as rk:
                        val, _ = winreg.QueryValueEx(rk, "MachineGuid")
                        if val:
                            raw_id = str(val).strip()
                except Exception:
                    pass
        if not raw_id:
            raw_id = f"{socket.gethostname()}-{uuid.getnode()}"
        digest = hashlib.sha256(raw_id.encode("utf-8")).hexdigest().upper()
        self._cached_hwid = f"{digest[0:4]}-{digest[4:8]}-{digest[8:12]}"
        return self._cached_hwid

    @staticmethod
    def generate_license_key(
        pharmacy_name: str,
        gln_no: str = "",
        expires_at: str = "2027-12-31",
        max_pcs: int = 10,
        hwid_lock: str = "ANY",
        plan: str = "PRO_YILLIK",
        pharmacist_name: str = "",
        phone: str = "",
        city: str = "",
        prefix: str = "FR"
    ) -> str:
        """
        Yönetici (Admin) için kriptografik imzalı lisans anahtarı üretir.
        Format: FR-<BASE64URL_PAYLOAD>.<HMAC_IMZA_16> (veya EDP-...)
        """
        clean_exp = expires_at.strip().replace("/", "-")
        payload_dict = {
            "e": pharmacy_name.strip().upper()[:40],
            "fn": pharmacist_name.strip()[:40],
            "tel": phone.strip()[:20],
            "ct": city.strip().upper()[:25],
            "g": gln_no.strip()[:20],
            "x": clean_exp,
            "m": int(max_pcs),
            "h": (hwid_lock or "ANY").strip().upper(),
            "p": plan.strip().upper(),
        }
        payload_json = json.dumps(payload_dict, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        b64_payload = base64.urlsafe_b64encode(payload_json).decode("ascii").rstrip("=")
        sig = hmac.new(_MASTER_VERIFY_SALT, b64_payload.encode("ascii"), hashlib.sha256).hexdigest().upper()[:16]
        pfx = (prefix or "FR").strip().upper().rstrip("-")
        return f"{pfx}-{b64_payload}.{sig}"

    @staticmethod
    def sign_cloud_registry(records: list, updated_at: str) -> str:
        """Bulut lisans listesinin (licenses_cloud.json) bütünlük imzasını üretir."""
        canonical = json.dumps(
            {"updated_at": updated_at, "count": len(records), "items": records},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":")
        ).encode("utf-8")
        return hmac.new(_MASTER_VERIFY_SALT, canonical, hashlib.sha256).hexdigest().upper()[:32]

    def verify_license_key(self, key_str: str) -> Dict[str, Any]:
        """Verilen lisans anahtarının kriptografik imzasını, donanım kilidini ve süresini doğrular."""
        clean_key = (key_str or "").strip()
        if not (clean_key.startswith("FR-") or clean_key.startswith("EDP-")) or "." not in clean_key:
            return {"valid": False, "message": "Geçersiz lisans anahtarı formatı (FR-... veya EDP-... ile başlamalıdır)."}

        try:
            body_part = clean_key.split("-", 1)[1]
            b64_payload, given_sig = body_part.rsplit(".", 1)
            expected_sig = hmac.new(
                _MASTER_VERIFY_SALT,
                b64_payload.encode("ascii"),
                hashlib.sha256
            ).hexdigest().upper()[:16]

            if not hmac.compare_digest(given_sig.upper(), expected_sig):
                return {"valid": False, "message": "Lisans imzası geçersiz veya değiştirilmiş!"}

            pad = "=" * ((4 - len(b64_payload) % 4) % 4)
            payload_bytes = base64.urlsafe_b64decode((b64_payload + pad).encode("ascii"))
            data = json.loads(payload_bytes.decode("utf-8"))

            pharmacy_name = data.get("e", "ECZANE")
            pharmacist_name = data.get("fn", "")
            phone = data.get("tel", "")
            city = data.get("ct", "")
            gln_no = data.get("g", "")
            expires_at = data.get("x", "2027-12-31")
            max_pcs = int(data.get("m", 10))
            hwid_lock = data.get("h", "ANY")
            plan = data.get("p", "PRO_YILLIK")

            my_hwid = self.get_hardware_id()
            if hwid_lock and hwid_lock != "ANY" and hwid_lock != my_hwid:
                return {
                    "valid": False,
                    "unactivated": True,
                    "restricted": True,
                    "hwid_mismatch": True,
                    "status": "HWID_UYUMSUZ",
                    "pharmacy_name": pharmacy_name,
                    "my_hwid": my_hwid,
                    "hwid_lock": hwid_lock,
                    "message": f"Bu lisans başka bir bilgisayara ({hwid_lock}) tanımlanmış. Bu PC HWID: {my_hwid}"
                }

            exp_date = datetime.date.fromisoformat(expires_at[:10])
            today = datetime.date.today()
            days_left = (exp_date - today).days

            if days_left < 0:
                return {
                    "valid": False,
                    "unactivated": False,
                    "restricted": True,
                    "expired": True,
                    "suspended": False,
                    "status": "SURESI_DOLDU",
                    "pharmacy_name": pharmacy_name,
                    "pharmacist_name": pharmacist_name,
                    "phone": phone,
                    "city": city,
                    "gln_no": gln_no,
                    "expires_at": expires_at,
                    "days_left": days_left,
                    "max_pcs": max_pcs,
                    "hwid_lock": hwid_lock,
                    "my_hwid": my_hwid,
                    "plan": plan,
                    "license_key": clean_key,
                    "message": (
                        f"Lisans süreniz {expires_at} tarihinde dolmuştur ({abs(days_left)} gün geçti). "
                        f"Depo Sorgulama, Sepete Ekleme, Toplu Sipariş ve MF Asistanı özellikleri kısıtlanmıştır."
                    )
                }

            return {
                "valid": True,
                "unactivated": False,
                "restricted": False,
                "expired": False,
                "suspended": False,
                "expiring_soon": (0 <= days_left <= 15),
                "status": "AKTIF",
                "pharmacy_name": pharmacy_name,
                "pharmacist_name": pharmacist_name,
                "phone": phone,
                "city": city,
                "gln_no": gln_no,
                "expires_at": expires_at,
                "days_left": days_left,
                "max_pcs": max_pcs,
                "hwid_lock": hwid_lock,
                "my_hwid": my_hwid,
                "plan": plan,
                "license_key": clean_key,
                "message": f"Lisans Aktif ({pharmacy_name} - Kalan Süre: {days_left} gün)"
            }
        except Exception as e:
            return {
                "valid": False,
                "unactivated": True,
                "restricted": True,
                "status": "GECERSIZ_ANAHTAR",
                "message": f"Lisans anahtarı çözümlenemedi: {str(e)}"
            }

    def _get_local_cloud_registry_files(self) -> list:
        """Yerel diskte (Admin CRM veya Releases klasörlerinde) bulunan imzalı licenses_cloud.json dosyalarını döndürür."""
        candidates = [
            os.path.join(self.base_dir, "releases", "licenses_cloud.json"),
            os.path.join(self.base_dir, "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "releases", "licenses_cloud.json"),
            os.path.join(os.path.dirname(self.base_dir), "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "releases", "licenses_cloud.json"),
            r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases\licenses_cloud.json",
            r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases\licenses_cloud.json",
            r"C:\EczaneDepoPro\releases\licenses_cloud.json",
        ]
        out = []
        for c in candidates:
            if c and os.path.isfile(c) and c not in out:
                out.append(c)
        return out

    def _get_cloud_registry_urls(self) -> list:
        """Bulut lisans manifestosu (`licenses_cloud.json`) için kontrol edilecek URL listesini (Sıfır-Önbellekli) döndürür."""
        urls = []
        ts = int(time.time() * 1000)

        # 1. Yerel ağda (veya aynı bilgisayarda) Admin CRM (Port 8095) açıksa doğrudan oradan kontrol et
        urls.append(f"http://127.0.0.1:8095/api/cloud-registry?t={ts}")

        # 2. Sıfır-Önbellekli (Zero-Cache) GitHub REST API (CDN gecikmesini tamamen bypass eder)
        gh_api_url = f"https://api.github.com/repos/depomxxx/depo-updates/contents/licenses_cloud.json?ref=main&t={ts}"
        urls.append(gh_api_url)

        # 3. version.json içindeki özel/LAN manifest sunucusu
        try:
            if os.path.isfile(self.version_file):
                with open(self.version_file, "r", encoding="utf-8") as f:
                    vdata = json.load(f)
                m_url = str(vdata.get("manifest_url") or "").strip()
                if m_url.startswith("http") and "/" in m_url:
                    base_u = m_url.rsplit("/", 1)[0]
                    cand_u = f"{base_u}/licenses_cloud.json?t={ts}"
                    if cand_u not in urls:
                        urls.append(cand_u)
        except Exception:
            pass

        # 4. Yedek GitHub Raw URL
        default_gh = f"https://raw.githubusercontent.com/depomxxx/depo-updates/main/licenses_cloud.json?t={ts}"
        if default_gh not in urls:
            urls.append(default_gh)

        return urls

    def _validate_registry_dict(self, parsed: Any) -> bool:
        if not isinstance(parsed, dict) or not isinstance(parsed.get("items"), list):
            return False
        given_sig = parsed.get("signature", "")
        if given_sig:
            exp_sig = self.sign_cloud_registry(parsed["items"], parsed.get("updated_at", ""))
            if not hmac.compare_digest(given_sig.upper(), exp_sig):
                return False
        return True

    def _fetch_latest_cloud_registry(self, timeout: float = 3.5) -> Tuple[Optional[dict], str]:
        """Hem yerel CRM/Releases dosyalarını hem de Sıfır-Önbellekli GitHub API / CRM sunucusunu tarayıp tüm kayıtları birleştirir."""
        best_data = None
        best_source = ""
        best_updated_at = ""
        merged_items: list = []

        def _merge_parsed(parsed: dict, src_label: str):
            nonlocal best_data, best_source, best_updated_at
            upd = str(parsed.get("updated_at") or "")
            if best_data is None or upd >= best_updated_at:
                best_data = parsed
                best_updated_at = upd
                best_source = src_label
            for it in (parsed.get("items") or []):
                if not isinstance(it, dict):
                    continue
                it_id = (it.get("id") or "").strip()
                it_gln = "".join(ch for ch in str(it.get("gln_no") or "") if ch.isdigit())
                it_name = _normalize_tr(it.get("pharmacy_name") or "")
                it_upd = str(it.get("updated_at") or upd or "")
                found_idx = -1
                for idx, ex in enumerate(merged_items):
                    ex_id = (ex.get("id") or "").strip()
                    ex_gln = "".join(ch for ch in str(ex.get("gln_no") or "") if ch.isdigit())
                    ex_name = _normalize_tr(ex.get("pharmacy_name") or "")
                    if (it_id and ex_id and it_id == ex_id) or (len(it_gln) >= 8 and it_gln == ex_gln and (not it_name or not ex_name or it_name == ex_name)) or (it_name and ex_name and it_name == ex_name):
                        found_idx = idx
                        break
                if found_idx == -1:
                    merged_items.append(dict(it))
                else:
                    ex = merged_items[found_idx]
                    ex_upd = str(ex.get("updated_at") or "")
                    if it_upd >= ex_upd:
                        merged = {**ex, **{k: v for k, v in it.items() if v not in (None, "")}}
                    else:
                        merged = {**it, **{k: v for k, v in ex.items() if v not in (None, "")}}
                    merged_items[found_idx] = merged

        # A) Önce yerel diskteki imzalı licenses_cloud.json dosyalarını kontrol et (0ms gecikme)
        for fpath in self._get_local_cloud_registry_files():
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    parsed = json.load(f)
                if self._validate_registry_dict(parsed):
                    _merge_parsed(parsed, f"local:{fpath}")
            except Exception:
                continue

        # B) HTTP / GitHub API kaynaklarını kontrol et
        gh_creds = self._get_cloud_sync_credentials()
        gh_token = (gh_creds.get("token") or "").strip()
        got_github = False
        for url in self._get_cloud_registry_urls():
            try:
                is_local_crm = "127.0.0.1:8095" in url
                if got_github and not is_local_crm:
                    continue
                req_timeout = 0.8 if is_local_crm else timeout
                headers = {
                    "User-Agent": "FarmaRadar-LicenseClient/1.5",
                    "Cache-Control": "no-cache, no-store, must-revalidate",
                    "Pragma": "no-cache",
                }
                if "api.github.com/" in url:
                    headers["Accept"] = "application/vnd.github.raw+json"
                    headers["X-GitHub-Api-Version"] = "2022-11-28"
                    if gh_token:
                        headers["Authorization"] = f"Bearer {gh_token}"

                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=req_timeout) as resp:
                    if resp.status == 200:
                        raw = resp.read().decode("utf-8", errors="replace")
                        parsed = json.loads(raw)
                        # Eğer GitHub API base64 JSON döndürdüyse çözümle
                        if isinstance(parsed, dict) and parsed.get("encoding") == "base64" and parsed.get("content"):
                            dec = base64.b64decode(parsed["content"]).decode("utf-8", errors="replace")
                            parsed = json.loads(dec)
                        if self._validate_registry_dict(parsed):
                            _merge_parsed(parsed, url)
                            if "api.github.com/" in url or "raw.githubusercontent.com/" in url:
                                got_github = True
            except Exception:
                continue

        if best_data is not None and merged_items:
            best_data = dict(best_data)
            best_data["items"] = merged_items
            best_data["count"] = len(merged_items)

        return best_data, best_source

    def _read_saved_license_file(self) -> dict:
        if os.path.isfile(self.license_file):
            try:
                with open(self.license_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _write_saved_license_file(self, data: dict):
        try:
            with open(self.license_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self._cached_status = None
        except Exception:
            pass

    def _get_cloud_sync_credentials(self) -> Dict[str, str]:
        """GitHub bulut lisans senkronizasyonu için depo ve yetkilendirme bilgilerini döndürür."""
        cfg = {"owner": "depomxxx", "repo": "depo-updates", "branch": "main", "token": ""}
        candidates = [
            os.path.join(self.base_dir, "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "github_config.json"),
            os.path.join(os.path.dirname(self.base_dir), "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "github_config.json"),
            r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\github_config.json",
            r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\github_config.json",
        ]
        for c in candidates:
            if c and os.path.isfile(c):
                try:
                    with open(c, "r", encoding="utf-8") as f:
                        loaded = json.load(f)
                    for k in ("owner", "repo", "branch", "token"):
                        if loaded.get(k):
                            cfg[k] = str(loaded[k]).strip()
                    if cfg["token"]:
                        return cfg
                except Exception:
                    pass
        try:
            cfg["token"] = bytes([b ^ _MASTER_VERIFY_SALT[i % len(_MASTER_VERIFY_SALT)] for i, b in enumerate(_CLOUD_SYNC_BYTES)]).decode("ascii")
        except Exception:
            pass
        return cfg

    def _push_record_to_cloud_and_local_crm(self, record: dict) -> Dict[str, Any]:
        """
        Yeni kayıt olan veya güncellenen eczane lisans kaydını:
        1. Varsa yerel Admin CRM veritabanına (SQLite + JSON) ve yerel releases/licenses_cloud.json dosyalarına yazar,
        2. Doğrudan GitHub Bulut Лиsans Kayıt Defterine (depomxxx/depo-updates/licenses_cloud.json) imzalı olarak ekler.
        Böylece eczane kendi bilgisayarından kayıt olduğunda yönetici CRM ekranına otomatik düşer.
        """
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        gh = self._get_cloud_sync_credentials()
        owner = gh.get("owner") or "depomxxx"
        repo = gh.get("repo") or "depo-updates"
        branch = gh.get("branch") or "main"
        token = gh.get("token") or ""

        # 1. Mevcut bulut listesini (veya yerel listeyi) çek
        cloud_data, _ = self._fetch_latest_cloud_registry(timeout=4.5)
        items = list((cloud_data or {}).get("items") or [])

        rec_id = (record.get("id") or "").strip()
        rec_name_norm = _normalize_tr(record.get("pharmacy_name") or "")
        rec_gln = "".join(ch for ch in str(record.get("gln_no") or "") if ch.isdigit())

        clean_item = {
            "id": rec_id or str(uuid.uuid4())[:8].upper(),
            "pharmacy_name": (record.get("pharmacy_name") or "").strip().upper(),
            "pharmacist_name": (record.get("pharmacist_name") or "").strip(),
            "phone": (record.get("phone") or "").strip(),
            "city": (record.get("city") or "").strip().upper(),
            "gln_no": (record.get("gln_no") or "").strip(),
            "otomasyon": (record.get("otomasyon") or "BOTANIK").strip().upper(),
            "plan": (record.get("plan") or "DENEME_30GUN").strip().upper(),
            "expires_at": (record.get("expires_at") or "").strip()[:10],
            "max_pcs": int(record.get("max_pcs") or 15),
            "hwid_lock": (record.get("hwid_lock") or "ANY").strip().upper(),
            "registered_hwid": (record.get("registered_hwid") or self.get_hardware_id()).strip().upper(),
            "status": (record.get("status") or "AKTIF").strip().upper(),
            "license_key": (record.get("license_key") or "").strip(),
            "created_at": record.get("created_at") or now_str,
            "updated_at": now_str,
        }

        replaced = False
        for idx, it in enumerate(items):
            it_id = (it.get("id") or "").strip()
            it_name_norm = _normalize_tr(it.get("pharmacy_name") or "")
            it_gln = "".join(ch for ch in str(it.get("gln_no") or "") if ch.isdigit())
            if (clean_item["id"] and it_id == clean_item["id"]) or (rec_gln and len(rec_gln) >= 8 and it_gln == rec_gln) or (rec_name_norm and it_name_norm == rec_name_norm):
                clean_item["id"] = it_id or clean_item["id"]
                clean_item["created_at"] = it.get("created_at") or clean_item["created_at"]
                items[idx] = clean_item
                replaced = True
                break
        if not replaced:
            items.insert(0, clean_item)

        sig = self.sign_cloud_registry(items, now_str)
        payload_obj = {
            "updated_at": now_str,
            "count": len(items),
            "signature": sig,
            "items": items,
        }
        raw_json = json.dumps(payload_obj, ensure_ascii=False, indent=2)

        # 2. Yerel releases/licenses_cloud.json dosyalarına yaz
        for rel_dir in (
            os.path.join(self.base_dir, "releases"),
            os.path.join(self.base_dir, "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "releases"),
            r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases",
            r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases",
            r"C:\EczaneDepoPro\releases",
        ):
            try:
                parent_d = os.path.dirname(rel_dir)
                if os.path.isdir(parent_d):
                    os.makedirs(rel_dir, exist_ok=True)
                    with open(os.path.join(rel_dir, "licenses_cloud.json"), "w", encoding="utf-8") as f:
                        f.write(raw_json)
            except Exception:
                pass

        # 3. Aynı bilgisayarda Admin CRM SQLite veritabanı varsa oraya da doğrudan kaydet
        for crm_db_path in (
            r"C:\EczaneDepoPro\data\farma_radar_eczane_kayitlari.db",
            os.path.join(self.base_dir, "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "farma_radar_eczane_kayitlari.db"),
            r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\farma_radar_eczane_kayitlari.db",
            r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\farma_radar_eczane_kayitlari.db",
        ):
            if os.path.isfile(crm_db_path):
                try:
                    import sqlite3
                    with sqlite3.connect(crm_db_path) as conn:
                        conn.execute("""
                            INSERT OR REPLACE INTO pharmacies (
                                id, pharmacy_name, pharmacist_name, phone, city, gln_no,
                                otomasyon, plan, expires_at, max_pcs, hwid_lock, status,
                                payment_info, notes, license_key, created_at, updated_at
                            ) VALUES (
                                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                                COALESCE((SELECT payment_info FROM pharmacies WHERE id = ?), '30 Gün Deneme (Otomatik Kayıt)'),
                                COALESCE((SELECT notes FROM pharmacies WHERE id = ?), ?),
                                ?, ?, ?
                            )
                        """, (
                            clean_item["id"],
                            clean_item["pharmacy_name"],
                            clean_item["pharmacist_name"],
                            clean_item["phone"],
                            clean_item["city"],
                            clean_item["gln_no"],
                            clean_item["otomasyon"],
                            clean_item["plan"],
                            clean_item["expires_at"],
                            clean_item["max_pcs"],
                            clean_item["hwid_lock"],
                            clean_item["status"],
                            clean_item["id"],
                            clean_item["id"],
                            f"Otomatik Kayıt • HWID: {clean_item['registered_hwid']}",
                            clean_item["license_key"],
                            clean_item["created_at"],
                            now_str
                        ))
                        conn.commit()
                except Exception:
                    pass

        # 4. GitHub REST API üzerinden merkezi bulut listesini güncelle
        cloud_pushed = False
        if token:
            api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/licenses_cloud.json"
            headers = {
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {token}",
                "User-Agent": "FarmaRadar-AutoTrial/1.5",
                "X-GitHub-Api-Version": "2022-11-28",
            }
            for _attempt in range(2):
                existing_sha = None
                try:
                    req_get = urllib.request.Request(f"{api_url}?ref={branch}&t={int(time.time()*1000)}", headers=headers, method="GET")
                    with urllib.request.urlopen(req_get, timeout=6.0) as resp:
                        if resp.status == 200:
                            g_data = json.loads(resp.read().decode("utf-8"))
                            existing_sha = g_data.get("sha")
                except Exception:
                    pass

                put_body = {
                    "message": f"Auto Pharmacy Registration: {clean_item['pharmacy_name']} (GLN: {clean_item['gln_no']}) - {now_str}",
                    "content": base64.b64encode(raw_json.encode("utf-8")).decode("ascii"),
                    "branch": branch,
                }
                if existing_sha:
                    put_body["sha"] = existing_sha

                try:
                    req_put = urllib.request.Request(
                        api_url,
                        data=json.dumps(put_body).encode("utf-8"),
                        headers={**headers, "Content-Type": "application/json"},
                        method="PUT",
                    )
                    with urllib.request.urlopen(req_put, timeout=10.0) as resp:
                        if resp.status in (200, 201):
                            cloud_pushed = True
                            break
                except Exception:
                    time.sleep(0.4)

        return {"cloud_pushed": cloud_pushed, "record": clean_item}

    def register_pharmacy_trial(
        self,
        pharmacy_name: str,
        gln_no: str,
        phone: str,
        pharmacist_name: str = "",
        city: str = "",
        otomasyon: str = "BOTANIK"
    ) -> Dict[str, Any]:
        """
        Eczane ilk kurulumda veya kilit ekranında GLN, Eczane Adı ve Telefon numarasını girdiğinde:
        1. Önce GitHub Bulut Lisans Sistemini (`licenses_cloud.json`) kontrol eder:
           - Eğer bu GLN / Eczane / HWID daha önce kayıt olmuşsa mevcut kalan süresini (veya yöneticinin uzattığı süreyi) çeker;
             süresi bitmişse veya askıdaysa tekrar 30 gün sıfırlanmasını engeller.
        2. İlk kez kayıt oluyorsa otomatik olarak **30 Günlük Deneme Lisansı (`DENEME_30GUN`)** üretip aktif eder,
           ve bu eczaneyi GitHub + Yönetici Lisans CRM sistemine otomatik kaydeder.
        """
        clean_pname = (pharmacy_name or "").strip().upper()
        clean_gln = "".join(ch for ch in str(gln_no or "") if ch.isdigit())
        clean_phone = (phone or "").strip()
        clean_fn = (pharmacist_name or "").strip()
        clean_city = (city or "").strip().upper()
        clean_oto = (otomasyon or "BOTANIK").strip().upper()
        my_hwid = self.get_hardware_id()

        if len(clean_pname) < 3 or _normalize_tr(clean_pname) == _normalize_tr("FARMA RADAR ECZANESİ"):
            return {"valid": False, "unactivated": True, "restricted": True, "message": "Lütfen geçerli Eczane Adınızı giriniz (Örn: ŞİFA ECZANESİ)."}
        if len(clean_gln) < 8:
            return {"valid": False, "unactivated": True, "restricted": True, "message": "Lütfen 13 haneli Eczane GLN Numaranızı giriniz (Örn: 8680001...)."}
        if len("".join(ch for ch in clean_phone if ch.isdigit())) < 10:
            return {"valid": False, "unactivated": True, "restricted": True, "message": "Lütfen geçerli Cep Telefonu numaranızı giriniz (05XX...)."}

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 1. GitHub Bulut Kayıt Defterinde bu GLN / Eczane / HWID zaten var mı kontrol et
        cloud_data, _ = self._fetch_latest_cloud_registry(timeout=4.5)
        cloud_items = (cloud_data or {}).get("items") or []
        existing_cloud = None
        pname_norm = _normalize_tr(clean_pname)

        for it in cloud_items:
            it_gln = "".join(ch for ch in str(it.get("gln_no") or "") if ch.isdigit())
            it_name_norm = _normalize_tr(it.get("pharmacy_name") or "")
            it_hwid = (it.get("hwid_lock") or "ANY").strip().upper()
            it_reg_hwid = (it.get("registered_hwid") or "").strip().upper()
            if clean_gln and it_gln and clean_gln == it_gln:
                existing_cloud = it
                break
            if pname_norm and it_name_norm and pname_norm == it_name_norm:
                existing_cloud = it
                break
            if my_hwid and ((it_hwid != "ANY" and it_hwid == my_hwid) or (it_reg_hwid and it_reg_hwid == my_hwid)):
                existing_cloud = it
                break

        if existing_cloud:
            # Zaten bulutta kayıtlı: mevcut bitiş tarihini ve durumunu koru (30 gün sıfırlanmasın, uzatıldıysa yeni tarih gelsin)
            crm_id = existing_cloud.get("id") or str(uuid.uuid4())[:8].upper()
            exp_str = (existing_cloud.get("expires_at") or "").strip()[:10]
            plan_str = (existing_cloud.get("plan") or "DENEME_30GUN").strip().upper()
            status_str = (existing_cloud.get("status") or "AKTIF").strip().upper()
            max_pcs = int(existing_cloud.get("max_pcs") or 15)
            hwid_lock = (existing_cloud.get("hwid_lock") or "ANY").strip().upper()

            key_str = self.generate_license_key(
                pharmacy_name=clean_pname,
                gln_no=clean_gln,
                expires_at=exp_str,
                max_pcs=max_pcs,
                hwid_lock=hwid_lock,
                plan=plan_str,
                pharmacist_name=clean_fn or existing_cloud.get("pharmacist_name", ""),
                phone=clean_phone or existing_cloud.get("phone", ""),
                city=clean_city or existing_cloud.get("city", ""),
            )
            save_data = {
                "crm_id": crm_id,
                "license_key": key_str,
                "pharmacy_name": clean_pname,
                "pharmacist_name": clean_fn or existing_cloud.get("pharmacist_name", ""),
                "phone": clean_phone or existing_cloud.get("phone", ""),
                "city": clean_city or existing_cloud.get("city", ""),
                "gln_no": clean_gln,
                "otomasyon": clean_oto,
                "expires_at": exp_str,
                "max_pcs": max_pcs,
                "hwid_lock": hwid_lock,
                "plan": plan_str,
                "remote_status": status_str,
                "activated_at": now_str,
                "remote_checked_at": now_str,
                "my_hwid": my_hwid,
                "pc_name": socket.gethostname(),
            }
            self._write_saved_license_file(save_data)
            self._push_record_to_cloud_and_local_crm({
                **existing_cloud,
                **save_data,
                "id": crm_id,
                "status": status_str,
                "registered_hwid": my_hwid,
            })
            st = self.get_status(force_cloud=False)
            if st.get("valid"):
                st["message"] = (
                    f"✅ {clean_pname} (GLN: {clean_gln}) mevcut bulut lisansınız doğrulandı ve etkinleştirildi! "
                    f"(Kalan Süre: {st.get('days_left', 0)} Gün — Bitiş: {exp_str})"
                )
            else:
                st["message"] = (
                    f"⚠️ {clean_pname} (GLN: {clean_gln}) için tanımlı 30 günlük deneme süreniz dolmuş veya lisansınız askıdadır "
                    f"(Bitiş: {exp_str}). Süre uzatımı için yöneticinizle iletişime geçiniz."
                )
            return st

        # 2. YENİ ECZANE KAYDI -> Otomatik 30 Günlük Deneme Lisansı (DENEME_30GUN) Tanımla!
        crm_id = str(uuid.uuid4())[:8].upper()
        exp_date = datetime.date.today() + datetime.timedelta(days=30)
        exp_str = exp_date.isoformat()
        plan_str = "DENEME_30GUN"

        key_str = self.generate_license_key(
            pharmacy_name=clean_pname,
            gln_no=clean_gln,
            expires_at=exp_str,
            max_pcs=15,
            hwid_lock="ANY",
            plan=plan_str,
            pharmacist_name=clean_fn,
            phone=clean_phone,
            city=clean_city,
        )

        save_data = {
            "crm_id": crm_id,
            "license_key": key_str,
            "pharmacy_name": clean_pname,
            "pharmacist_name": clean_fn,
            "phone": clean_phone,
            "city": clean_city,
            "gln_no": clean_gln,
            "otomasyon": clean_oto,
            "expires_at": exp_str,
            "max_pcs": 15,
            "hwid_lock": "ANY",
            "plan": plan_str,
            "remote_status": "AKTIF",
            "activated_at": now_str,
            "remote_checked_at": now_str,
            "my_hwid": my_hwid,
            "pc_name": socket.gethostname(),
        }
        self._write_saved_license_file(save_data)

        push_res = self._push_record_to_cloud_and_local_crm({
            "id": crm_id,
            "pharmacy_name": clean_pname,
            "pharmacist_name": clean_fn,
            "phone": clean_phone,
            "city": clean_city,
            "gln_no": clean_gln,
            "otomasyon": clean_oto,
            "plan": plan_str,
            "expires_at": exp_str,
            "max_pcs": 15,
            "hwid_lock": "ANY",
            "registered_hwid": my_hwid,
            "status": "AKTIF",
            "license_key": key_str,
            "created_at": now_str,
            "updated_at": now_str,
        })

        st = self.get_status(force_cloud=False)
        st["cloud_pushed"] = push_res.get("cloud_pushed", False)
        st["message"] = (
            f"🎁 Hoş geldiniz! {clean_pname} (GLN: {clean_gln}) için 30 Günlük Otomatik Lisansınız tanımlandı "
            f"ve merkezi lisans sistemine kaydedildi (Bitiş: {exp_str} • 30 Gün)."
        )
        try:
            self.record_activity("registration", "30 Gün Deneme Kaydı Yapıldı", force_cloud=True)
        except Exception:
            pass
        return st

    def _lookup_license_from_lan_peers(self, clean_gln: str = "") -> Optional[Dict[str, Any]]:
        """
        Aynı eczane yerel ağındaki (LAN 192.168.x.x:8080) diğer Farma Radar bilgisayarlarını
        paralel (~300ms) tarayarak eşleşen GLN'nin (veya aktif lisansın) lisans anahtarını çeker.
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed
        local_ip = ""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
        except Exception:
            return None

        parts = local_ip.split(".")
        if len(parts) != 4 or parts[0] not in ("192", "10", "172"):
            return None
        prefix = f"{parts[0]}.{parts[1]}.{parts[2]}."
        candidates = [f"{prefix}{i}" for i in range(1, 255) if f"{prefix}{i}" != local_ip]

        def _probe(ip: str) -> Optional[Dict[str, Any]]:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sk:
                    sk.settimeout(0.22)
                    if sk.connect_ex((ip, 8080)) != 0:
                        return None
                req = urllib.request.Request(
                    f"http://{ip}:8080/api/license/status",
                    headers={"User-Agent": "FarmaRadar-LAN-Peer/1.0"}
                )
                with urllib.request.urlopen(req, timeout=0.6) as resp:
                    if resp.status == 200:
                        data = json.loads(resp.read().decode("utf-8", errors="replace"))
                        peer_gln = "".join(ch for ch in str(data.get("gln_no") or "") if ch.isdigit())
                        peer_key = str(data.get("license_key") or "").strip()
                        if peer_key and not data.get("unactivated"):
                            if not clean_gln or (peer_gln and peer_gln == clean_gln):
                                data["lan_peer_ip"] = ip
                                return data
            except Exception:
                return None
            return None

        try:
            with ThreadPoolExecutor(max_workers=48) as ex:
                futs = [ex.submit(_probe, ip) for ip in candidates]
                for f in as_completed(futs):
                    res = f.result()
                    if res:
                        return res
        except Exception:
            pass
        return None

    def lookup_license_by_gln(self, gln_no: str, auto_activate: bool = True) -> Dict[str, Any]:
        """
        Eczanenin başka bir bilgisayarına kurulum yapıldığında 13 haneli GLN numarası girilir girilmez:
        1. GitHub Bulut Lisans Kayıt Defteri (`licenses_cloud.json`) ve Yerel CRM veritabanını,
        2. Aynı yerel ağdaki (LAN) diğer Farma Radar bilgisayarlarını,
        3. Bağlı TEBEOS veritabanındaki eczane kayıtlarını (`isletme_tanim_lp`, `eczane_ms`)
        kontrol ederek bu GLN'ye ait Lisans Anahtarını (`FR-...`) ve tüm eczane bilgilerini otomatik getirir
        ve `auto_activate=True` ise bu bilgisayarda anında etkinleştirir.
        """
        raw_input = (gln_no or "").strip()
        clean_gln = "".join(ch for ch in raw_input if ch.isdigit())
        if len(clean_gln) < 8:
            return {
                "found": False,
                "valid": False,
                "message": "Lütfen en az 13 haneli Eczane GLN numaranızı giriniz (Örn: 8680001...)."
            }

        my_hwid = self.get_hardware_id()
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 1. Bulut ve yerel kayıt defterlerinde bu GLN var mı?
        cloud_data, cloud_src = self._fetch_latest_cloud_registry(timeout=4.0)
        items = list((cloud_data or {}).get("items") or [])
        matched = None

        for it in items:
            it_gln = "".join(ch for ch in str(it.get("gln_no") or "") if ch.isdigit())
            it_key = str(it.get("license_key") or "").strip()
            if not it_gln and it_key:
                v_tmp = self.verify_license_key(it_key)
                it_gln = "".join(ch for ch in str(v_tmp.get("gln_no") or "") if ch.isdigit())
            if it_gln and it_gln == clean_gln:
                matched = dict(it)
                break

        # 2. Bulutta bulunamadıysa yerel ağdaki (LAN) diğer Farma Radar bilgisayarlarına bak
        from_lan_peer = False
        if not matched:
            lan_peer = self._lookup_license_from_lan_peers(clean_gln)
            if lan_peer:
                peer_oto = (lan_peer.get("otomasyon") or "").strip().upper()
                try:
                    from backend.tebeos_client import tebeos_client
                    tb_check = tebeos_client.get_pharmacy_info_by_gln(clean_gln)
                    if tb_check and tb_check.get("found"):
                        peer_oto = "TEBEOS"
                except Exception:
                    pass
                matched = {
                    "id": lan_peer.get("crm_id") or "",
                    "pharmacy_name": lan_peer.get("pharmacy_name") or "",
                    "pharmacist_name": lan_peer.get("pharmacist_name") or "",
                    "phone": lan_peer.get("phone") or "",
                    "city": lan_peer.get("city") or "",
                    "gln_no": clean_gln,
                    "otomasyon": peer_oto or os.getenv("ACTIVE_OTOMASYON", "BOTANIK"),
                    "plan": lan_peer.get("plan") or "DENEME_30GUN",
                    "expires_at": lan_peer.get("expires_at") or "",
                    "max_pcs": lan_peer.get("max_pcs") or 15,
                    "hwid_lock": "ANY",
                    "status": lan_peer.get("status") or "AKTIF",
                    "license_key": lan_peer.get("license_key") or "",
                }
                cloud_src = f"lan:{lan_peer.get('lan_peer_ip')}"
                from_lan_peer = True

        # 3. Eğer hala bulunamadıysa bağlı TEBEOS veritabanından bu GLN'nin bilgilerini çekip otomatik lisans üret!
        if not matched:
            try:
                from backend.tebeos_client import tebeos_client
                tb_info = tebeos_client.get_pharmacy_info_by_gln(clean_gln)
                if tb_info and tb_info.get("found") and tb_info.get("pharmacy_name"):
                    reg_res = self.register_pharmacy_trial(
                        pharmacy_name=tb_info["pharmacy_name"],
                        gln_no=clean_gln,
                        phone=tb_info.get("phone") or "05000000000",
                        pharmacist_name=tb_info.get("pharmacist_name") or "",
                        city=tb_info.get("city") or "",
                        otomasyon="TEBEOS",
                    )
                    reg_res["found"] = True
                    reg_res["activated"] = bool(auto_activate and reg_res.get("valid"))
                    reg_res["otomasyon"] = "TEBEOS"
                    reg_res["source"] = tb_info.get("source", "tebeos")
                    return reg_res
            except Exception:
                pass

        if not matched:
            return {
                "found": False,
                "valid": False,
                "gln_no": clean_gln,
                "message": f"GLN ({clean_gln}) için kayıtlı lisans bulunamadı. Eczane Adı ve Telefon bilgilerinizi girerek yeni 30 günlük lisansınızı hemen başlatabilirsiniz."
            }

        # Eşleşen kaydın lisans anahtarı içindeki (FR-...) gömülü alanları da çözümle
        raw_key = str(matched.get("license_key") or "").strip()
        v_info = self.verify_license_key(raw_key) if raw_key else {}

        pname = (matched.get("pharmacy_name") or v_info.get("pharmacy_name") or "").strip().upper()
        pharmacist = (matched.get("pharmacist_name") or v_info.get("pharmacist_name") or "").strip()
        phone = (matched.get("phone") or v_info.get("phone") or "").strip()
        city = (matched.get("city") or v_info.get("city") or "").strip().upper()
        oto = (matched.get("otomasyon") or os.getenv("ACTIVE_OTOMASYON", "BOTANIK")).strip().upper()
        exp_str = (matched.get("expires_at") or v_info.get("expires_at") or "").strip()[:10]
        plan_str = (matched.get("plan") or v_info.get("plan") or "DENEME_30GUN").strip().upper()
        status_str = (matched.get("status") or "AKTIF").strip().upper()
        max_pcs = int(matched.get("max_pcs") or v_info.get("max_pcs") or 15)
        hwid_lock = (matched.get("hwid_lock") or v_info.get("hwid_lock") or "ANY").strip().upper()
        if max_pcs > 1 and hwid_lock != "ANY" and hwid_lock != my_hwid:
            hwid_lock = "ANY"
        crm_id = (matched.get("id") or matched.get("crm_id") or str(uuid.uuid4())[:8].upper()).strip()

        # Anahtar yoksa veya çoklu bilgisayar için güncellenmesi gerekiyorsa imzalı FR-... anahtarını üret
        if not raw_key or not v_info.get("pharmacy_name") or v_info.get("hwid_mismatch") or v_info.get("expires_at") != exp_str:
            raw_key = self.generate_license_key(
                pharmacy_name=pname,
                gln_no=clean_gln,
                expires_at=exp_str,
                max_pcs=max_pcs,
                hwid_lock=hwid_lock,
                plan=plan_str,
                pharmacist_name=pharmacist,
                phone=phone,
                city=city,
            )

        if from_lan_peer:
            try:
                threading.Thread(
                    target=self._push_record_to_cloud_and_local_crm,
                    args=({
                        "id": crm_id,
                        "pharmacy_name": pname,
                        "pharmacist_name": pharmacist,
                        "phone": phone,
                        "city": city,
                        "gln_no": clean_gln,
                        "otomasyon": oto,
                        "plan": plan_str,
                        "expires_at": exp_str,
                        "max_pcs": max_pcs,
                        "hwid_lock": hwid_lock,
                        "registered_hwid": my_hwid,
                        "status": status_str,
                        "license_key": raw_key,
                    },),
                    daemon=True
                ).start()
            except Exception:
                pass

        if auto_activate:
            save_data = {
                "crm_id": crm_id,
                "license_key": raw_key,
                "pharmacy_name": pname,
                "pharmacist_name": pharmacist,
                "phone": phone,
                "city": city,
                "gln_no": clean_gln,
                "otomasyon": oto,
                "expires_at": exp_str,
                "max_pcs": max_pcs,
                "hwid_lock": hwid_lock,
                "plan": plan_str,
                "remote_status": status_str,
                "activated_at": now_str,
                "remote_checked_at": now_str,
                "my_hwid": my_hwid,
                "pc_name": socket.gethostname(),
            }
            self._write_saved_license_file(save_data)
            st = self.get_status(force_cloud=False)
            st["found"] = True
            st["activated"] = bool(st.get("valid"))
            st["license_key"] = raw_key
            st["pharmacy_name"] = pname
            st["pharmacist_name"] = pharmacist
            st["phone"] = phone
            st["city"] = city
            st["gln_no"] = clean_gln
            st["otomasyon"] = oto
            st["source"] = cloud_src
            if st.get("valid"):
                st["message"] = (
                    f"🎉 {pname} (GLN: {clean_gln}) kayıtlı lisans anahtarınız otomatik getirildi ve bu bilgisayarda etkinleştirildi! "
                    f"(Bitiş: {exp_str} • {st.get('days_left', 0)} Gün Kaldı)"
                )
            return st

        v_final = self.verify_license_key(raw_key)
        return {
            "found": True,
            "activated": False,
            "valid": bool(v_final.get("valid")) and status_str not in ("ASKIDA", "KISITLI", "PASIF"),
            "license_key": raw_key,
            "pharmacy_name": pname,
            "pharmacist_name": pharmacist,
            "phone": phone,
            "city": city,
            "gln_no": clean_gln,
            "otomasyon": oto,
            "plan": plan_str,
            "expires_at": exp_str,
            "days_left": v_final.get("days_left", 0),
            "status": status_str,
            "my_hwid": my_hwid,
            "source": cloud_src,
            "message": f"✅ {pname} (GLN: {clean_gln}) lisans anahtarı otomatik yüklendi (Bitiş: {exp_str})."
        }

    def sync_with_cloud(self, force: bool = False, timeout: float = 3.5) -> Dict[str, Any]:
        """
        Merkezi GitHub / Admin CRM bulut kayıt defterinden (`licenses_cloud.json`)
        bu eczanenin lisans durumunu sorgular:
        - Süresi uzatılmışsa veya kısaltılmışsa yeni anahtarı ve tarihi otomatik indirip kaydeder.
        - Yönetici tarafından ASKIDA / KISITLI (Pasif) yapılmışsa veya CRM'den silinmişse özellikleri kısıtlar.
        - Tekrar AKTİF yapılmışsa kısıtlamayı otomatik kaldırır.
        """
        now_ts = time.time()
        if not force and (now_ts - self._last_cloud_sync_ts) < self._cloud_cache_ttl:
            return {"synced": False, "cached": True}

        self._last_cloud_sync_ts = now_ts
        self._cached_status = None
        saved = self._read_saved_license_file()
        if not saved or not (saved.get("license_key") or "").strip():
            return {"synced": False, "unactivated": True}

        my_hwid = self.get_hardware_id()
        my_key = (saved.get("license_key") or "").strip()
        my_name_norm = _normalize_tr(saved.get("pharmacy_name") or "")
        my_gln = (saved.get("gln_no") or "").strip()
        my_crm_id = (saved.get("crm_id") or "").strip()

        cloud_data, source_url = self._fetch_latest_cloud_registry(timeout=timeout)
        if not cloud_data:
            return {"synced": False, "message": "Bulut lisans sunucusuna ulaşılamadı (Çevrimdışı mod)."}

        items = cloud_data.get("items") or []
        matched_record = None

        # 1. Öncelik: CRM ID veya birebir Lisans Anahtarı veya Donanım Kilidi (HWID) eşleşmesi
        for item in items:
            it_id = (item.get("id") or "").strip()
            it_key = (item.get("license_key") or "").strip()
            it_hwid = (item.get("hwid_lock") or "ANY").strip().upper()
            if my_crm_id and it_id and my_crm_id == it_id:
                matched_record = item
                break
            if my_key and it_key and my_key == it_key:
                matched_record = item
                break
            if it_hwid and it_hwid != "ANY" and it_hwid == my_hwid:
                matched_record = item
                break

        # 2. Öncelik: Eczane Adı (veya Eczane Adı + GLN) eşleşmesi
        if not matched_record:
            for item in items:
                it_name_norm = _normalize_tr(item.get("pharmacy_name") or "")
                if my_name_norm and it_name_norm and my_name_norm == it_name_norm:
                    matched_record = item
                    break
            if not matched_record and my_gln:
                for item in items:
                    it_gln = (item.get("gln_no") or "").strip()
                    if it_gln and my_gln == it_gln:
                        matched_record = item
                        break

        # 3. Öncelik: Eski sürümlerden (v1.5.1 öncesi) kalma "FARMA RADAR ECZANESİ" kurulumlarında
        # .env içindeki Tria/Depo kullanıcı ipuçlarından (ARASTIRMA, GAMZE, EDA, RUYA vb.) otomatik eşleştir
        if not matched_record and my_name_norm == _normalize_tr("FARMA RADAR ECZANESİ") and socket.gethostname().upper() != "CICOBEY":
            env_hint = self._get_env_identity_text()
            if env_hint:
                for item in items:
                    it_name_norm = _normalize_tr(item.get("pharmacy_name") or "")
                    it_fn_norm = _normalize_tr(item.get("pharmacist_name") or "")
                    first_word = it_name_norm.replace("ECZANESI", "").strip()
                    fn_first = (it_fn_norm.split()[0] if it_fn_norm.split() else "")
                    if (first_word and len(first_word) >= 3 and first_word in env_hint) or (fn_first and len(fn_first) >= 4 and fn_first in env_hint):
                        matched_record = item
                        break

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if not matched_record:
            # Eğer bu eczanede geçerli imzalı bir FR-... lisansı ve GLN varsa ancak bulut listesinde henüz yoksa,
            # bulut kayıt defterine (licenses_cloud.json) otomatik senkronize et (çevrimdışı kayıtların kaybolmasını önler).
            v_check = self.verify_license_key(my_key) if my_key else {}
            if v_check.get("valid") and my_name_norm and my_name_norm != _normalize_tr("FARMA RADAR ECZANESİ"):
                try:
                    threading.Thread(
                        target=self._push_record_to_cloud_and_local_crm,
                        args=({
                            "id": my_crm_id or str(uuid.uuid4())[:8].upper(),
                            "pharmacy_name": saved.get("pharmacy_name") or v_check.get("pharmacy_name") or "",
                            "pharmacist_name": saved.get("pharmacist_name") or v_check.get("pharmacist_name") or "",
                            "phone": saved.get("phone") or v_check.get("phone") or "",
                            "city": saved.get("city") or v_check.get("city") or "",
                            "gln_no": my_gln or v_check.get("gln_no") or "",
                            "otomasyon": saved.get("otomasyon") or os.getenv("ACTIVE_OTOMASYON", "BOTANIK"),
                            "plan": saved.get("plan") or v_check.get("plan") or "DENEME_30GUN",
                            "expires_at": saved.get("expires_at") or v_check.get("expires_at") or "",
                            "max_pcs": saved.get("max_pcs") or v_check.get("max_pcs") or 15,
                            "hwid_lock": saved.get("hwid_lock") or v_check.get("hwid_lock") or "ANY",
                            "registered_hwid": my_hwid,
                            "status": saved.get("remote_status") or "AKTIF",
                            "license_key": my_key,
                            "created_at": saved.get("activated_at") or now_str,
                        },),
                        daemon=True
                    ).start()
                except Exception:
                    pass
                return {"synced": True, "matched": True, "auto_pushed": True, "source": source_url}
            return {"synced": True, "matched": False, "source": source_url}

        # Eşleşen kayıt bulundu! Şimdi durumu (AKTIF / ASKIDA / KISITLI) ve yeni lisans anahtarını uygula
        remote_status = (matched_record.get("status") or "AKTIF").strip().upper()
        remote_key = (matched_record.get("license_key") or "").strip()
        remote_exp = (matched_record.get("expires_at") or "").strip()[:10]

        if remote_key and (remote_key != my_key or saved.get("expires_at") != remote_exp or my_name_norm == _normalize_tr("FARMA RADAR ECZANESİ")):
            # Yönetici süreyi uzatmış, kısaltmış veya bilgileri güncellemiş; yeni anahtarı doğrula ve kaydet
            v_res = self.verify_license_key(remote_key)
            if v_res.get("pharmacy_name"):
                saved["license_key"] = remote_key
                saved["pharmacy_name"] = v_res.get("pharmacy_name", matched_record.get("pharmacy_name", ""))
                saved["pharmacist_name"] = matched_record.get("pharmacist_name", saved.get("pharmacist_name", ""))
                saved["phone"] = matched_record.get("phone", saved.get("phone", ""))
                saved["city"] = matched_record.get("city", saved.get("city", ""))
                saved["gln_no"] = matched_record.get("gln_no", saved.get("gln_no", ""))
                saved["otomasyon"] = matched_record.get("otomasyon", saved.get("otomasyon", ""))
                saved["expires_at"] = v_res.get("expires_at", remote_exp)
                saved["max_pcs"] = v_res.get("max_pcs", matched_record.get("max_pcs", 15))
                saved["hwid_lock"] = v_res.get("hwid_lock", matched_record.get("hwid_lock", "ANY"))
                saved["plan"] = v_res.get("plan", matched_record.get("plan", "PRO_YILLIK"))
            elif remote_exp:
                saved["expires_at"] = remote_exp

        saved["crm_id"] = matched_record.get("id", saved.get("crm_id", ""))
        saved["remote_status"] = remote_status
        saved["remote_checked_at"] = now_str
        saved["my_hwid"] = my_hwid
        self._write_saved_license_file(saved)

        try:
            self.record_activity("heartbeat", "Program Açık (Canlı)")
        except Exception:
            pass

        return {
            "synced": True,
            "matched": True,
            "remote_status": remote_status,
            "expires_at": saved.get("expires_at", remote_exp),
            "pharmacy_name": saved.get("pharmacy_name", matched_record.get("pharmacy_name", "")),
            "checked_at": now_str,
            "source": source_url
        }

    def ensure_default_license(self, force_cloud: bool = False) -> Dict[str, Any]:
        """
        Kurulu sistemde license.json varsa doğrular ve bulut ile senkronize eder.
        İlk kurulumda (anahtar girilmemişse) otomatik sahte lisans ÜRETMEZ;
        doğrudan Lisans Anahtarı (FR-...) ister (unactivated=True).
        """
        my_hwid = self.get_hardware_id()

        # Önce bulut senkronizasyonunu çalıştır (25 sn önbellekli veya force_cloud=True ise anında)
        try:
            self.sync_with_cloud(force=force_cloud)
        except Exception:
            pass

        if os.path.isfile(self.license_file):
            try:
                saved = self._read_saved_license_file()
                key = (saved.get("license_key") or "").strip()
                saved_pname = _normalize_tr(saved.get("pharmacy_name") or "")

                # Eski sürümlerden kalma sahte/varsayılan "FARMA RADAR ECZANESİ" anahtarı varsa ve CRM'de yoksa geçersiz say
                if key and saved_pname == _normalize_tr("FARMA RADAR ECZANESİ") and not saved.get("crm_id"):
                    return {
                        "valid": False,
                        "unactivated": True,
                        "restricted": True,
                        "expired": False,
                        "suspended": False,
                        "status": "ANAHTAR_BEKLENIYOR",
                        "pharmacy_name": "Yeni Kurulum — Lisans Bekleniyor",
                        "my_hwid": my_hwid,
                        "message": "Programı kullanabilmek için lütfen Farma Radar Kurumsal Lisans Anahtarınızı (FR-... veya EDP-...) giriniz."
                    }

                if key:
                    res = self.verify_license_key(key)
                    res["activated_at"] = saved.get("activated_at", "")
                    res["remote_checked_at"] = saved.get("remote_checked_at", "")
                    res["crm_id"] = saved.get("crm_id", "")
                    if saved.get("pharmacist_name"):
                        res["pharmacist_name"] = saved["pharmacist_name"]
                    if saved.get("phone"):
                        res["phone"] = saved["phone"]
                    if saved.get("city"):
                        res["city"] = saved["city"]
                    if saved.get("gln_no"):
                        res["gln_no"] = saved["gln_no"]
                    if saved.get("otomasyon"):
                        res["otomasyon"] = saved["otomasyon"]

                    # CRM'de bitiş tarihi güncellenmişse (anahtar yenilenmeden tarih çekildiyse) onu da kontrol et
                    saved_exp = str(saved.get("expires_at") or "").strip()[:10]
                    if saved_exp and saved_exp != res.get("expires_at"):
                        try:
                            exp_d = datetime.date.fromisoformat(saved_exp)
                            d_left = (exp_d - datetime.date.today()).days
                            res["expires_at"] = saved_exp
                            res["days_left"] = d_left
                            if d_left < 0:
                                res["valid"] = False
                                res["unactivated"] = False
                                res["restricted"] = True
                                res["expired"] = True
                                res["status"] = "SURESI_DOLDU"
                                res["message"] = (
                                    f"Lisans süreniz {saved_exp} tarihinde dolmuştur ({abs(d_left)} gün geçti). "
                                    f"Depo Sorgulama, Sepete Ekleme, Toplu Sipariş ve MF Asistanı özellikleri kısıtlanmıştır."
                                )
                        except Exception:
                            pass

                    # Uzaktan yönetici tarafından ASKIDA / KISITLI / PASIF yapıldıysa özellikleri kısıtla!
                    remote_st = (saved.get("remote_status") or "AKTIF").strip().upper()
                    if remote_st in ("ASKIDA", "KISITLI", "PASIF"):
                        res["valid"] = False
                        res["unactivated"] = False
                        res["restricted"] = True
                        res["suspended"] = True
                        res["status"] = "ASKIDA"
                        res["message"] = (
                            f"Lisansınız ({res.get('pharmacy_name', 'Eczane')}) yönetici tarafından kısıtlanmıştır (ASKIDA). "
                            f"Depo Sorgulama, Sepete Ekleme, Toplu Sipariş ve MF Asistanı özellikleri kapatılmıştır."
                        )
                    return res
            except Exception:
                pass

        # İlk kurulum: Henüz hiçbir lisans anahtarı girilmemiş -> Program açılmaz, doğrudan anahtar ister!
        return {
            "valid": False,
            "unactivated": True,
            "restricted": True,
            "expired": False,
            "suspended": False,
            "status": "ANAHTAR_BEKLENIYOR",
            "pharmacy_name": "Yeni Kurulum — Lisans Anahtarı Gerekli",
            "expires_at": "-",
            "days_left": 0,
            "my_hwid": my_hwid,
            "license_key": "",
            "message": "Hoş geldiniz! Farma Radar sistemini başlatmak için lütfen yöneticinizden aldığınız Lisans Anahtarını (FR-... veya EDP-...) giriniz."
        }

    def activate_license(
        self,
        key_str: str,
        pharmacist_name: str = "",
        phone: str = "",
        city: str = ""
    ) -> Dict[str, Any]:
        """Lisans anahtarını (veya 13 haneli GLN numarasını) doğrular ve üye eczacı iletişim bilgileriyle birlikte license.json'a kaydeder."""
        clean_inp = (key_str or "").strip()
        only_digits = "".join(ch for ch in clean_inp if ch.isdigit())
        if not (clean_inp.upper().startswith("FR-") or clean_inp.upper().startswith("EDP-")) and len(only_digits) >= 8:
            return self.lookup_license_by_gln(only_digits, auto_activate=True)

        check = self.verify_license_key(key_str)
        # İmza geçersizse veya HWID uyumsuzsa hemen reddet
        if not check.get("pharmacy_name") or check.get("hwid_mismatch"):
            return check

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        final_pharmacist = pharmacist_name.strip() or check.get("pharmacist_name", "")
        final_phone = phone.strip() or check.get("phone", "")
        final_city = city.strip() or check.get("city", "")
        prev_saved = self._read_saved_license_file()

        save_data = {
            "license_key": key_str.strip(),
            "pharmacy_name": check["pharmacy_name"],
            "pharmacist_name": final_pharmacist,
            "phone": final_phone,
            "city": final_city,
            "gln_no": check.get("gln_no", ""),
            "expires_at": check["expires_at"],
            "max_pcs": check.get("max_pcs", 10),
            "hwid_lock": check.get("hwid_lock", "ANY"),
            "plan": check.get("plan", "PRO_YILLIK"),
            "remote_status": "AKTIF",
            "crm_id": prev_saved.get("crm_id", ""),
            "activated_at": now_str,
            "my_hwid": self.get_hardware_id(),
            "pc_name": socket.gethostname()
        }
        try:
            self._write_saved_license_file(save_data)
            # Yeni anahtar girildiğinde bulut durumuyla anında senkronize et (eski anahtarla bypass yapılmasını önler)
            self.sync_with_cloud(force=True)
            final_status = self.get_status(force_cloud=False)
            try:
                self.record_activity("activation", "Lisans Anahtarı Etkinleştirildi", force_cloud=True)
            except Exception:
                pass
            return final_status
        except Exception as e:
            return {"valid": False, "unactivated": True, "restricted": True, "message": f"Lisans dosyası kaydedilemedi: {str(e)}"}

    def get_status(self, force_cloud: bool = False) -> Dict[str, Any]:
        """Mevcut lisans durumunu (bulut doğrulaması dahil) ve bu bilgisayarın HWID bilgisini döndürür."""
        now_ts = time.time()
        if not force_cloud and self._cached_status is not None and (now_ts - self._cached_status_ts) < 5.0:
            return self._cached_status

        info = self.ensure_default_license(force_cloud=force_cloud)
        info["my_hwid"] = self.get_hardware_id()
        info["pc_name"] = socket.gethostname()
        self._cached_status = info
        self._cached_status_ts = now_ts
        return info

    def is_feature_allowed(self) -> Tuple[bool, Dict[str, Any]]:
        """Korumalı özelliklerin (Depo Sorgu, Sepete Ekleme, Toplu Sipariş, MF Asistanı) çalışmasına izin verilip verilmediğini döndürür."""
        st = self.get_status(force_cloud=False)
        return bool(st.get("valid", False)), st

    def _get_env_identity_text(self) -> str:
        """Eski sürümlerden kalan kurulumlarda .env içindeki Tria/Botanik/Depo kullanıcı adlarından eczaneyi tanır."""
        parts = []
        env_path = os.path.join(self.base_dir, ".env")
        if os.path.isfile(env_path):
            try:
                with open(env_path, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        s = line.strip()
                        if "=" in s and not s.startswith("#"):
                            k, v = s.split("=", 1)
                            ku = k.strip().upper()
                            if any(w in ku for w in ("USER", "PHARMACY", "SERVER", "DATABASE", "ACCOUNT")):
                                parts.append(v.strip())
            except Exception:
                pass
        return _normalize_tr(" ".join(parts))

    def _get_app_version_str(self) -> str:
        try:
            ver_txt = os.path.join(self.base_dir, "VERSION")
            if os.path.isfile(ver_txt):
                with open(ver_txt, "r", encoding="utf-8") as f:
                    v = f.read().strip()
                    if v:
                        return v
            if os.path.isfile(self.version_file):
                with open(self.version_file, "r", encoding="utf-8") as f:
                    d = json.load(f)
                    if d.get("version"):
                        return str(d["version"]).strip()
        except Exception:
            pass
        return "1.5.8"

    def _read_local_telemetry(self) -> Dict[str, Any]:
        try:
            if os.path.isfile(self.telemetry_file):
                with open(self.telemetry_file, "r", encoding="utf-8") as f:
                    d = json.load(f)
                    if isinstance(d, dict):
                        return d
        except Exception:
            pass
        return {}

    def _write_local_telemetry(self, data: Dict[str, Any]) -> None:
        try:
            os.makedirs(os.path.dirname(self.telemetry_file), exist_ok=True)
            with open(self.telemetry_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _get_local_lan_ip(self) -> str:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))
                return str(s.getsockname()[0] or "")
        except Exception:
            return ""

    def _get_desk_label(self) -> str:
        try:
            from backend.order_tracker import order_tracker
            dn = str(getattr(order_tracker, "pc_name", "") or "").strip()
            if dn:
                return dn
        except Exception:
            pass
        return socket.gethostname()

    def get_local_device_telemetry(self) -> Dict[str, Any]:
        """Bu bilgisayarın yerel kullanım telemetri özetini döndürür (aynı eczane LAN eşleştirmesi için)."""
        saved = self._read_saved_license_file()
        tel = self._read_local_telemetry()
        my_hwid = self.get_hardware_id()
        pc_name = socket.gethostname()
        today_str = datetime.datetime.now().strftime("%Y-%m-%d")
        is_today = (tel.get("today_date") == today_str)
        dev = {
            "hwid": my_hwid,
            "pc_name": pc_name,
            "desk_name": tel.get("desk_name") or self._get_desk_label(),
            "local_ip": tel.get("local_ip") or self._get_local_lan_ip(),
            "app_version": tel.get("app_version") or self._get_app_version_str(),
            "last_seen_at": tel.get("last_seen_at") or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "last_action": tel.get("last_action") or "Program Açık (Canlı)",
            "today_date": today_str if is_today else (tel.get("today_date") or today_str),
            "today_searches": int(tel.get("today_searches") or 0) if is_today else 0,
            "today_cart_adds": int(tel.get("today_cart_adds") or 0) if is_today else 0,
            "today_smart_orders": int(tel.get("today_smart_orders") or 0) if is_today else 0,
            "total_searches": int(tel.get("total_searches") or 0),
            "total_cart_adds": int(tel.get("total_cart_adds") or 0),
            "total_smart_orders": int(tel.get("total_smart_orders") or 0),
            "total_days_used": int(tel.get("total_days_used") or 1),
            "recent_actions": list(tel.get("recent_actions") or [])[-15:],
        }
        return {
            "pharmacy_name": (saved.get("pharmacy_name") or "").strip().upper(),
            "gln_no": "".join(ch for ch in str(saved.get("gln_no") or "") if ch.isdigit()),
            "device": dev,
        }

    def _collect_lan_peer_devices(self, clean_gln: str, pname_norm: str) -> Dict[str, Dict[str, Any]]:
        """Aynı yerel ağdaki (ARP komşularındaki) diğer eczane bilgisayarlarının aktif kullanım verilerini toplar."""
        peers: Dict[str, Dict[str, Any]] = {}
        local_ip = self._get_local_lan_ip()
        if not local_ip:
            return peers
        cand_ips = []
        try:
            import re
            import subprocess
            arp_kwargs: Dict[str, Any] = {"text": True, "errors": "ignore", "timeout": 1.5, "stdin": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
            if sys.platform == "win32":
                si = subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                si.wShowWindow = getattr(subprocess, "SW_HIDE", 0)
                arp_kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
                arp_kwargs["startupinfo"] = si
            arp_out = subprocess.check_output(["arp", "-a"], **arp_kwargs)
            for m in re.finditer(r"\b((?:192\.168|10\.|172\.(?:1[6-9]|2\d|3[01]))\.[0-9.]+)\b", arp_out):
                ip_s = m.group(1)
                if ip_s != local_ip and not ip_s.endswith(".255") and not ip_s.endswith(".1") and ip_s not in cand_ips:
                    cand_ips.append(ip_s)
        except Exception:
            pass
        if not cand_ips:
            return peers

        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _fetch_peer(ip: str) -> Optional[Dict[str, Any]]:
            try:
                req = urllib.request.Request(
                    f"http://{ip}:8080/api/license/local-telemetry",
                    headers={"User-Agent": "FarmaRadar-LAN-Telemetry/1.0"}
                )
                with urllib.request.urlopen(req, timeout=0.65) as resp:
                    if resp.status == 200:
                        d = json.loads(resp.read().decode("utf-8", errors="replace"))
                        p_gln = "".join(ch for ch in str(d.get("gln_no") or "") if ch.isdigit())
                        p_name = _normalize_tr(d.get("pharmacy_name") or "")
                        if (clean_gln and p_gln and clean_gln == p_gln) or (pname_norm and p_name and pname_norm == p_name):
                            dev = d.get("device")
                            if isinstance(dev, dict):
                                if not dev.get("local_ip"):
                                    dev["local_ip"] = ip
                                return dev
            except Exception:
                return None
            return None

        try:
            with ThreadPoolExecutor(max_workers=12) as ex:
                futs = [ex.submit(_fetch_peer, ip) for ip in cand_ips[:24]]
                for f in as_completed(futs):
                    dev = f.result()
                    if dev:
                        d_key = (str(dev.get("hwid") or "").strip().upper() or str(dev.get("pc_name") or "").strip().upper())
                        if d_key:
                            peers[d_key] = dev
        except Exception:
            pass
        return peers

    @staticmethod
    def _merge_devices_into_entry(existing_item: Optional[Dict[str, Any]], new_entry: Dict[str, Any], extra_devices: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
        """
        Aynı eczaneye ait birden fazla bilgisayarın (devices) kullanım istatistiklerini birbirini ezmeden birleştirir
        ve eczane genel toplamlarını tüm aktif bilgisayarların toplamı olarak hesaplar.
        """
        today_str = datetime.datetime.now().strftime("%Y-%m-%d")
        devices: Dict[str, Dict[str, Any]] = {}

        if isinstance(existing_item, dict):
            old_devs = existing_item.get("devices")
            if isinstance(old_devs, dict):
                for k, v in old_devs.items():
                    if isinstance(v, dict):
                        devices[str(k).strip().upper()] = dict(v)
            # Eski tek-bilgisayarlı kayıt varsa onu da devices içine taşı (veri kaybını önle)
            legacy_pc = str(existing_item.get("last_pc_name") or "").strip()
            legacy_hwid = str(existing_item.get("hwid") or "").strip().upper()
            legacy_key = legacy_hwid or legacy_pc.upper()
            if legacy_key and legacy_key not in devices and existing_item.get("last_seen_at"):
                devices[legacy_key] = {
                    "hwid": legacy_hwid,
                    "pc_name": legacy_pc or legacy_hwid,
                    "desk_name": legacy_pc or legacy_hwid,
                    "local_ip": "",
                    "app_version": str(existing_item.get("app_version") or ""),
                    "last_seen_at": str(existing_item.get("last_seen_at") or ""),
                    "last_action": str(existing_item.get("last_action") or ""),
                    "today_date": str(existing_item.get("today_date") or ""),
                    "today_searches": int(existing_item.get("today_searches") or 0),
                    "today_cart_adds": int(existing_item.get("today_cart_adds") or 0),
                    "today_smart_orders": int(existing_item.get("today_smart_orders") or 0),
                    "total_searches": int(existing_item.get("total_searches") or 0),
                    "total_cart_adds": int(existing_item.get("total_cart_adds") or 0),
                    "total_smart_orders": int(existing_item.get("total_smart_orders") or 0),
                    "total_days_used": int(existing_item.get("total_days_used") or 1),
                    "recent_actions": [],
                }

        def _upsert_dev(dev_obj: Dict[str, Any]):
            if not isinstance(dev_obj, dict):
                return
            dk = (str(dev_obj.get("hwid") or "").strip().upper() or str(dev_obj.get("pc_name") or "").strip().upper())
            if not dk:
                return
            prev = devices.get(dk, {})
            merged_dev = dict(prev)
            merged_dev.update(dev_obj)
            merged_dev["total_searches"] = max(int(prev.get("total_searches") or 0), int(dev_obj.get("total_searches") or 0))
            merged_dev["total_cart_adds"] = max(int(prev.get("total_cart_adds") or 0), int(dev_obj.get("total_cart_adds") or 0))
            merged_dev["total_smart_orders"] = max(int(prev.get("total_smart_orders") or 0), int(dev_obj.get("total_smart_orders") or 0))
            merged_dev["total_days_used"] = max(int(prev.get("total_days_used") or 0), int(dev_obj.get("total_days_used") or 1))

            # Eğer gelen verinin last_seen_at değeri eskiyse güncel olanı koru
            if str(prev.get("last_seen_at") or "") > str(dev_obj.get("last_seen_at") or ""):
                merged_dev["last_seen_at"] = prev["last_seen_at"]
                if prev.get("last_action") and prev.get("last_action") != "Program Açık (Canlı)":
                    merged_dev["last_action"] = prev["last_action"]
                if prev.get("today_date") == today_str:
                    merged_dev["today_date"] = today_str
                    merged_dev["today_searches"] = max(int(prev.get("today_searches") or 0), int(dev_obj.get("today_searches") or 0) if dev_obj.get("today_date") == today_str else 0)
                    merged_dev["today_cart_adds"] = max(int(prev.get("today_cart_adds") or 0), int(dev_obj.get("today_cart_adds") or 0) if dev_obj.get("today_date") == today_str else 0)
                    merged_dev["today_smart_orders"] = max(int(prev.get("today_smart_orders") or 0), int(dev_obj.get("today_smart_orders") or 0) if dev_obj.get("today_date") == today_str else 0)

            # recent_actions birleştir (saate göre tekilleştir, son 15 işlemi tut)
            ra_map = {}
            for act_it in list(prev.get("recent_actions") or []) + list(dev_obj.get("recent_actions") or []):
                if isinstance(act_it, dict) and act_it.get("t"):
                    ra_map[f"{act_it.get('t')}|{act_it.get('detail','')}"] = act_it
            merged_ra = sorted(ra_map.values(), key=lambda x: str(x.get("t") or ""))[-15:]
            merged_dev["recent_actions"] = merged_ra
            devices[dk] = merged_dev

        my_dev = new_entry.get("my_device")
        if isinstance(my_dev, dict):
            _upsert_dev(my_dev)
        if isinstance(extra_devices, dict):
            for ed in extra_devices.values():
                _upsert_dev(ed)

        # Şimdi tüm bilgisayarların toplamından eczane özetini hesapla
        sum_today_s = 0
        sum_today_c = 0
        sum_today_sm = 0
        sum_tot_s = 0
        sum_tot_c = 0
        sum_tot_sm = 0
        max_days = int((existing_item or {}).get("total_days_used") or 0)
        newest_seen = ""
        newest_pc = ""
        newest_ver = ""
        newest_hwid = ""
        newest_action = ""
        newest_real_action = ""
        newest_real_pc = ""
        newest_real_seen = ""

        for dv in devices.values():
            if dv.get("today_date") == today_str:
                sum_today_s += int(dv.get("today_searches") or 0)
                sum_today_c += int(dv.get("today_cart_adds") or 0)
                sum_today_sm += int(dv.get("today_smart_orders") or 0)
            sum_tot_s += int(dv.get("total_searches") or 0)
            sum_tot_c += int(dv.get("total_cart_adds") or 0)
            sum_tot_sm += int(dv.get("total_smart_orders") or 0)
            max_days = max(max_days, int(dv.get("total_days_used") or 1))

            d_seen = str(dv.get("last_seen_at") or "")
            d_pc = str(dv.get("pc_name") or dv.get("desk_name") or "")
            d_act = str(dv.get("last_action") or "")
            if d_seen >= newest_seen:
                newest_seen = d_seen
                newest_pc = d_pc
                newest_ver = str(dv.get("app_version") or "")
                newest_hwid = str(dv.get("hwid") or "")
                newest_action = d_act
            if d_act and d_act != "Program Açık (Canlı)" and d_seen[:10] == today_str and d_seen >= newest_real_seen:
                newest_real_seen = d_seen
                newest_real_action = d_act
                newest_real_pc = d_pc

        out = dict(existing_item or {})
        for k, v in new_entry.items():
            if k != "my_device" and (v not in ("", None) or k not in out):
                out[k] = v

        out["today_date"] = today_str
        out["today_searches"] = sum_today_s
        out["today_cart_adds"] = sum_today_c
        out["today_smart_orders"] = sum_today_sm
        out["total_searches"] = max(int((existing_item or {}).get("total_searches") or 0), sum_tot_s)
        out["total_cart_adds"] = max(int((existing_item or {}).get("total_cart_adds") or 0), sum_tot_c)
        out["total_smart_orders"] = max(int((existing_item or {}).get("total_smart_orders") or 0), sum_tot_sm)
        out["total_days_used"] = max(1, max_days)
        out["last_seen_at"] = newest_seen or new_entry.get("last_seen_at", "")
        out["last_pc_name"] = newest_pc or new_entry.get("last_pc_name", "")
        out["app_version"] = newest_ver or new_entry.get("app_version", "")
        out["hwid"] = newest_hwid or new_entry.get("hwid", "")
        if newest_real_action:
            out["last_action"] = f"[{newest_real_pc}] {newest_real_action}" if (len(devices) > 1 and newest_real_pc and not newest_real_action.startswith("[")) else newest_real_action
        else:
            out["last_action"] = newest_action or new_entry.get("last_action", "Program Açık (Canlı)")
        out["pc_count"] = len(devices)
        out["devices"] = devices
        return out

    def record_activity(self, action_type: str = "heartbeat", detail: str = "", force_cloud: bool = False) -> Dict[str, Any]:
        """
        Eczanenin ve BU BİLGİSAYARIN programı aktif olarak nasıl kullandığını (Son Görülme, Son İşlem,
        Bilgisayar Bazlı Sorgu / Sepet / Toplu Sipariş sayıları, Saatli Son İşlemler Geçmişi, IP, HWID, Sürüm)
        kaydeder ve arka planda Farma Radar Lisans (CRM) + GitHub Bulut sistemine bildirir.
        """
        saved = self._read_saved_license_file()
        pname = (saved.get("pharmacy_name") or "").strip().upper()
        if not pname or _normalize_tr(pname) == _normalize_tr("FARMA RADAR ECZANESİ"):
            if socket.gethostname().upper() != "CICOBEY":
                try:
                    self.sync_with_cloud(force=True)
                    saved = self._read_saved_license_file()
                    pname = (saved.get("pharmacy_name") or "").strip().upper()
                except Exception:
                    pass
            if not pname or _normalize_tr(pname) == _normalize_tr("FARMA RADAR ECZANESİ"):
                return {"recorded": False}

        now_dt = datetime.datetime.now()
        now_str = now_dt.strftime("%Y-%m-%d %H:%M:%S")
        today_str = now_dt.strftime("%Y-%m-%d")
        pc_name = socket.gethostname()
        my_hwid = self.get_hardware_id()
        local_ip = self._get_local_lan_ip()
        desk_name = self._get_desk_label()
        app_ver = self._get_app_version_str()

        with self._telemetry_lock:
            tel = self._read_local_telemetry()
            if tel.get("today_date") != today_str:
                tel["today_date"] = today_str
                tel["today_searches"] = 0
                tel["today_cart_adds"] = 0
                tel["today_smart_orders"] = 0
                tel["last_action"] = "Program Açık (Canlı)"

            used_dates = list(tel.get("used_dates") or [])
            if today_str not in used_dates:
                used_dates.append(today_str)
                if len(used_dates) > 365:
                    used_dates = used_dates[-365:]
            tel["used_dates"] = used_dates
            tel["total_days_used"] = len(used_dates)

            act = (action_type or "heartbeat").lower()
            action_label = ""
            if act == "search":
                tel["today_searches"] = int(tel.get("today_searches") or 0) + 1
                tel["total_searches"] = int(tel.get("total_searches") or 0) + 1
                action_label = detail or "Depo Fiyat Sorgulama"
                tel["last_action"] = action_label
            elif act == "cart":
                tel["today_cart_adds"] = int(tel.get("today_cart_adds") or 0) + 1
                tel["total_cart_adds"] = int(tel.get("total_cart_adds") or 0) + 1
                action_label = detail or "Sepete Ürün / Sipariş Ekleme"
                tel["last_action"] = action_label
            elif act in ("smart_order", "critical_stock", "mf_resolve"):
                tel["today_smart_orders"] = int(tel.get("today_smart_orders") or 0) + 1
                tel["total_smart_orders"] = int(tel.get("total_smart_orders") or 0) + 1
                action_label = detail or "Toplu Sipariş / Kritik Stok"
                tel["last_action"] = action_label
            elif act != "heartbeat" and detail:
                action_label = detail
                tel["last_action"] = detail
            elif not tel.get("last_action"):
                tel["last_action"] = "Program Açık (Canlı)"

            recent_actions = list(tel.get("recent_actions") or [])
            if action_label:
                if not recent_actions or recent_actions[-1].get("detail") != action_label or recent_actions[-1].get("t", "")[:16] != now_str[:16]:
                    recent_actions.append({
                        "t": now_str,
                        "type": act,
                        "detail": action_label[:90],
                    })
                    if len(recent_actions) > 15:
                        recent_actions = recent_actions[-15:]
            tel["recent_actions"] = recent_actions

            tel["last_seen_at"] = now_str
            tel["app_version"] = app_ver
            tel["last_pc_name"] = pc_name
            tel["desk_name"] = desk_name
            tel["local_ip"] = local_ip
            tel["hwid"] = my_hwid

            my_device = {
                "hwid": my_hwid,
                "pc_name": pc_name,
                "desk_name": desk_name,
                "local_ip": local_ip,
                "app_version": app_ver,
                "last_seen_at": now_str,
                "last_action": tel["last_action"],
                "today_date": today_str,
                "today_searches": int(tel.get("today_searches") or 0),
                "today_cart_adds": int(tel.get("today_cart_adds") or 0),
                "today_smart_orders": int(tel.get("today_smart_orders") or 0),
                "total_searches": int(tel.get("total_searches") or 0),
                "total_cart_adds": int(tel.get("total_cart_adds") or 0),
                "total_smart_orders": int(tel.get("total_smart_orders") or 0),
                "total_days_used": int(tel.get("total_days_used") or 1),
                "recent_actions": recent_actions,
            }

            entry = {
                "id": (saved.get("crm_id") or "").strip(),
                "pharmacy_name": pname,
                "pharmacist_name": (saved.get("pharmacist_name") or "").strip(),
                "phone": (saved.get("phone") or "").strip(),
                "city": (saved.get("city") or "").strip().upper(),
                "gln_no": "".join(ch for ch in str(saved.get("gln_no") or "") if ch.isdigit()),
                "otomasyon": (saved.get("otomasyon") or os.getenv("ACTIVE_OTOMASYON", "BOTANIK")).strip().upper(),
                "plan": (saved.get("plan") or "DENEME_30GUN").strip().upper(),
                "expires_at": (saved.get("expires_at") or "").strip()[:10],
                "status": (saved.get("remote_status") or "AKTIF").strip().upper(),
                "hwid": my_hwid,
                "last_pc_name": pc_name,
                "app_version": app_ver,
                "last_seen_at": now_str,
                "last_action": tel["last_action"],
                "today_date": today_str,
                "today_searches": int(tel.get("today_searches") or 0),
                "today_cart_adds": int(tel.get("today_cart_adds") or 0),
                "today_smart_orders": int(tel.get("today_smart_orders") or 0),
                "total_searches": int(tel.get("total_searches") or 0),
                "total_cart_adds": int(tel.get("total_cart_adds") or 0),
                "total_smart_orders": int(tel.get("total_smart_orders") or 0),
                "total_days_used": int(tel.get("total_days_used") or 1),
                "my_device": my_device,
            }
            self._write_local_telemetry(tel)

        now_ts = time.time()
        min_interval = 18.0 if act in ("search", "cart", "smart_order", "critical_stock", "mf_resolve", "registration", "activation") else 80.0
        should_push = force_cloud or (self._last_telemetry_push_ts == 0.0) or ((now_ts - self._last_telemetry_push_ts) >= min_interval)

        if should_push and not self._telemetry_push_running:
            self._last_telemetry_push_ts = now_ts
            self._telemetry_push_running = True
            t = threading.Thread(target=self._push_telemetry_worker, args=(entry,), daemon=True)
            t.start()

        return {"recorded": True, "telemetry": entry}

    def _push_telemetry_worker(self, entry: Dict[str, Any]) -> None:
        try:
            self._push_telemetry_to_cloud_and_local_crm(entry)
        except Exception:
            pass
        finally:
            self._telemetry_push_running = False

    def _push_telemetry_to_cloud_and_local_crm(self, entry: Dict[str, Any]) -> None:
        """
        Eczanenin bilgisayar bazlı canlı kullanım verilerini (devices):
        1. Aynı yerel ağdaki diğer Farma Radar bilgisayarlarının anlık verileriyle birleştirir.
        2. GitHub (`depomxxx/depo-updates/contents/telemetry_cloud.json`) bulutuna ve yerel dosyalara gönderir.
        3. Aynı bilgisayardaki Admin CRM SQLite veritabanına (varsa) anında yazar.
        """
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        pname = (entry.get("pharmacy_name") or "").strip().upper()
        pname_norm = _normalize_tr(pname)
        gln_no = "".join(ch for ch in str(entry.get("gln_no") or "") if ch.isdigit())
        rec_id = (entry.get("id") or "").strip()

        # Aynı eczane LAN ağındaki diğer bilgisayarların anlık telemetrisini de topla
        peer_devices = self._collect_lan_peer_devices(gln_no, pname_norm)

        gh = self._get_cloud_sync_credentials()
        owner = gh.get("owner") or "depomxxx"
        repo = gh.get("repo") or "depo-updates"
        branch = gh.get("branch") or "main"
        token = gh.get("token") or ""

        api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/telemetry_cloud.json"
        headers = {
            "Accept": "application/vnd.github+json",
            "User-Agent": "FarmaRadar-Telemetry/1.7",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"

        merged_record: Optional[Dict[str, Any]] = None

        for attempt in range(3):
            existing_sha = None
            items = []
            try:
                req_get = urllib.request.Request(f"{api_url}?ref={branch}&t={int(time.time()*1000)}", headers=headers, method="GET")
                with urllib.request.urlopen(req_get, timeout=5.0) as resp:
                    if resp.status == 200:
                        g_data = json.loads(resp.read().decode("utf-8"))
                        existing_sha = g_data.get("sha")
                        content_b64 = g_data.get("content") or ""
                        if content_b64:
                            decoded = json.loads(base64.b64decode(content_b64).decode("utf-8"))
                            if isinstance(decoded, dict) and isinstance(decoded.get("items"), list):
                                items = decoded["items"]
            except Exception:
                pass

            if not items:
                for rel_dir in (
                    os.path.join(self.base_dir, "releases"),
                    os.path.join(self.base_dir, "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "releases"),
                ):
                    tf = os.path.join(rel_dir, "telemetry_cloud.json")
                    if os.path.isfile(tf):
                        try:
                            with open(tf, "r", encoding="utf-8") as f:
                                d = json.load(f)
                                if isinstance(d, dict) and isinstance(d.get("items"), list):
                                    items = d["items"]
                                    break
                        except Exception:
                            pass

            replaced = False
            for idx, it in enumerate(items):
                it_id = (it.get("id") or "").strip()
                it_name_norm = _normalize_tr(it.get("pharmacy_name") or "")
                it_gln = "".join(ch for ch in str(it.get("gln_no") or "") if ch.isdigit())
                if (rec_id and it_id == rec_id) or (len(gln_no) >= 8 and it_gln == gln_no) or (pname_norm and it_name_norm == pname_norm):
                    merged_record = self._merge_devices_into_entry(it, entry, peer_devices)
                    items[idx] = merged_record
                    replaced = True
                    break
            if not replaced:
                merged_record = self._merge_devices_into_entry(None, entry, peer_devices)
                items.insert(0, merged_record)

            payload_obj = {
                "updated_at": now_str,
                "count": len(items),
                "items": items,
            }
            raw_json = json.dumps(payload_obj, ensure_ascii=False, indent=2)

            for rel_dir in (
                os.path.join(self.base_dir, "releases"),
                os.path.join(self.base_dir, "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "releases"),
                r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases",
                r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\releases",
                r"C:\EczaneDepoPro\releases",
            ):
                try:
                    parent_d = os.path.dirname(rel_dir)
                    if os.path.isdir(parent_d):
                        os.makedirs(rel_dir, exist_ok=True)
                        with open(os.path.join(rel_dir, "telemetry_cloud.json"), "w", encoding="utf-8") as f:
                            f.write(raw_json)
                except Exception:
                    pass

            if not token:
                break

            put_body = {
                "message": f"Telemetry MultiPC: {pname} ({entry.get('last_pc_name', 'PC')} - {entry.get('last_action', 'Active')}) - {now_str}",
                "content": base64.b64encode(raw_json.encode("utf-8")).decode("ascii"),
                "branch": branch,
            }
            if existing_sha:
                put_body["sha"] = existing_sha
            try:
                req_put = urllib.request.Request(
                    api_url,
                    data=json.dumps(put_body).encode("utf-8"),
                    headers={**headers, "Content-Type": "application/json"},
                    method="PUT",
                )
                with urllib.request.urlopen(req_put, timeout=8.0) as resp:
                    if resp.status in (200, 201):
                        break
            except urllib.error.HTTPError as he:
                if he.code in (409, 422) and attempt < 2:
                    time.sleep(0.4)
                    continue
                break
            except Exception:
                break

        if merged_record is None:
            merged_record = self._merge_devices_into_entry(None, entry, peer_devices)

        # Yerel Admin CRM SQLite veritabanlarını güncelle (varsa)
        for crm_db_path in (
            r"C:\EczaneDepoPro\data\farma_radar_eczane_kayitlari.db",
            os.path.join(self.base_dir, "ECZANE_DEPO_PRO_MERKEZ", "2_GUNCELLEME_VE_LISANS_YONETIMI", "farma_radar_eczane_kayitlari.db"),
            r"C:\Users\eczac\OneDrive\Masaüstü\depoprogrami\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\farma_radar_eczane_kayitlari.db",
            r"C:\Users\eczac\OneDrive\Masaüstü\ECZANE_DEPO_PRO_MERKEZ\2_GUNCELLEME_VE_LISANS_YONETIMI\farma_radar_eczane_kayitlari.db",
        ):
            if os.path.isfile(crm_db_path):
                try:
                    import sqlite3
                    with sqlite3.connect(crm_db_path) as conn:
                        conn.row_factory = sqlite3.Row
                        for col_sql in (
                            "ALTER TABLE pharmacies ADD COLUMN last_seen_at TEXT DEFAULT ''",
                            "ALTER TABLE pharmacies ADD COLUMN last_action TEXT DEFAULT ''",
                            "ALTER TABLE pharmacies ADD COLUMN today_date TEXT DEFAULT ''",
                            "ALTER TABLE pharmacies ADD COLUMN today_searches INTEGER DEFAULT 0",
                            "ALTER TABLE pharmacies ADD COLUMN today_cart_adds INTEGER DEFAULT 0",
                            "ALTER TABLE pharmacies ADD COLUMN today_smart_orders INTEGER DEFAULT 0",
                            "ALTER TABLE pharmacies ADD COLUMN total_searches INTEGER DEFAULT 0",
                            "ALTER TABLE pharmacies ADD COLUMN total_cart_adds INTEGER DEFAULT 0",
                            "ALTER TABLE pharmacies ADD COLUMN total_smart_orders INTEGER DEFAULT 0",
                            "ALTER TABLE pharmacies ADD COLUMN total_days_used INTEGER DEFAULT 0",
                            "ALTER TABLE pharmacies ADD COLUMN app_version TEXT DEFAULT ''",
                            "ALTER TABLE pharmacies ADD COLUMN last_pc_name TEXT DEFAULT ''",
                            "ALTER TABLE pharmacies ADD COLUMN devices_json TEXT DEFAULT '{}'",
                        ):
                            try:
                                conn.execute(col_sql)
                            except Exception:
                                pass

                        rows = conn.execute("SELECT id, pharmacy_name, gln_no, devices_json FROM pharmacies").fetchall()
                        target_row = None
                        for r in rows:
                            if rec_id and r["id"] == rec_id:
                                target_row = r
                                break
                        if not target_row:
                            for r in rows:
                                if pname_norm and _normalize_tr(r["pharmacy_name"] or "") == pname_norm:
                                    target_row = r
                                    break
                        if not target_row and len(gln_no) >= 8:
                            for r in rows:
                                if (r["gln_no"] or "").strip() == gln_no:
                                    target_row = r
                                    break

                        if target_row:
                            db_devs = {}
                            try:
                                db_devs = json.loads(target_row["devices_json"] or "{}")
                            except Exception:
                                db_devs = {}
                            final_rec = self._merge_devices_into_entry({"devices": db_devs}, entry, merged_record.get("devices") or peer_devices)
                            conn.execute("""
                                UPDATE pharmacies
                                SET last_seen_at = ?,
                                    last_action = ?,
                                    today_date = ?,
                                    today_searches = ?,
                                    today_cart_adds = ?,
                                    today_smart_orders = ?,
                                    total_searches = MAX(COALESCE(total_searches, 0), ?),
                                    total_cart_adds = MAX(COALESCE(total_cart_adds, 0), ?),
                                    total_smart_orders = MAX(COALESCE(total_smart_orders, 0), ?),
                                    total_days_used = MAX(COALESCE(total_days_used, 0), ?),
                                    app_version = ?,
                                    last_pc_name = ?,
                                    devices_json = ?
                                WHERE id = ?
                            """, (
                                final_rec.get("last_seen_at", now_str),
                                final_rec.get("last_action", ""),
                                final_rec.get("today_date", ""),
                                int(final_rec.get("today_searches") or 0),
                                int(final_rec.get("today_cart_adds") or 0),
                                int(final_rec.get("today_smart_orders") or 0),
                                int(final_rec.get("total_searches") or 0),
                                int(final_rec.get("total_cart_adds") or 0),
                                int(final_rec.get("total_smart_orders") or 0),
                                int(final_rec.get("total_days_used") or 1),
                                final_rec.get("app_version", ""),
                                final_rec.get("last_pc_name", ""),
                                json.dumps(final_rec.get("devices") or {}, ensure_ascii=False),
                                target_row["id"],
                            ))
                            conn.commit()
                except Exception:
                    pass


license_manager = LicenseManager()
