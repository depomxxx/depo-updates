# -*- coding: utf-8 -*-
CORE_CART_JS = """        const searchInput = document.getElementById('searchInput');
        const suggestBox = document.getElementById('suggestBox');
        const loading = document.getElementById('loading');
        const loadingText = document.getElementById('loadingText');
        const results = document.getElementById('results');
        const productSelection = document.getElementById('productSelection');
        const selectionGrid = document.getElementById('selectionGrid');
        const tableBody = document.getElementById('tableBody');
        const simQtyInput = document.getElementById('simQtyInput');

        let debounceTimer;
        let currentReport = null;
        let selectedDepoForSim = null;

        // Anlık öneri sistemi (Sıfır gecikmeli istemci önbelleği, klavye gezintisi ve odaklanma)
        let suggestAbortController = null;
        let currentSuggestions = [];
        let selectedSuggestIndex = -1;
        const clientSuggestCache = {};

        function highlightMatch(text, query) {
            if (!query) return text;
            const terms = query.trim().split(/\\\\s+/).filter(t => t.length > 0);
            if (terms.length === 0) return text;
            try {
                const escaped = terms.map(t => t.replace(/[.*+?^${}()|[\\\\]\\\\\\\\]/g, '\\\\\\\\$&')).join('|');
                const regex = new RegExp(`(${escaped})`, 'gi');
                return text.replace(regex, '<span class="bg-amber-100 text-amber-900 font-bold px-0.5 rounded">$1</span>');
            } catch (e) {
                return text;
            }
        }

        async function fetchAndRenderSuggestions(val) {
            const query = val.trim();
            if (query.length < 2) {
                suggestBox.classList.add('hidden');
                currentSuggestions = [];
                selectedSuggestIndex = -1;
                return;
            }

            // İstemci önbelleği kontrolü (Anında 0 ms gösterim)
            if (clientSuggestCache[query]) {
                currentSuggestions = clientSuggestCache[query];
                selectedSuggestIndex = -1;
                renderSuggestions(currentSuggestions, query);
                return;
            }

            if (suggestAbortController) {
                suggestAbortController.abort();
            }
            suggestAbortController = new AbortController();

            try {
                const res = await fetch(`/api/catalog/suggest?q=${encodeURIComponent(query)}`, {
                    signal: suggestAbortController.signal
                });
                if (res.ok) {
                    const items = await res.json();
                    clientSuggestCache[query] = items;
                    currentSuggestions = items;
                    selectedSuggestIndex = -1;
                    renderSuggestions(items, query);
                }
            } catch(e) {
                if (e.name !== 'AbortError') {
                    console.error("Öneri hatası:", e);
                }
            }
        }

        searchInput.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            const val = this.value;
            if (val.trim().length < 2) {
                suggestBox.classList.add('hidden');
                return;
            }
            // Hızlı 30ms gecikme (yazarken donma olmadan anında tepki)
            debounceTimer = setTimeout(() => {
                fetchAndRenderSuggestions(val);
            }, 30);
        });

        // Arama kutusuna tıklandığında (focus) mevcut metin varsa önerileri hemen aç
        searchInput.addEventListener('focus', function () {
            if (this.value.trim().length >= 2) {
                fetchAndRenderSuggestions(this.value);
            }
        });

        // Klavye Yön Tuşları (Yukarı/Aşağı) ve Enter ile Anında Seçim
        searchInput.addEventListener('keydown', function (e) {
            const isSuggestOpen = !suggestBox.classList.contains('hidden') && currentSuggestions.length > 0;

            if (e.key === 'ArrowDown') {
                if (isSuggestOpen) {
                    e.preventDefault();
                    selectedSuggestIndex = (selectedSuggestIndex + 1) % currentSuggestions.length;
                    updateSuggestHighlight();
                }
            } else if (e.key === 'ArrowUp') {
                if (isSuggestOpen) {
                    e.preventDefault();
                    selectedSuggestIndex = (selectedSuggestIndex - 1 + currentSuggestions.length) % currentSuggestions.length;
                    updateSuggestHighlight();
                }
            } else if (e.key === 'Enter') {
                if (isSuggestOpen && selectedSuggestIndex >= 0 && selectedSuggestIndex < currentSuggestions.length) {
                    e.preventDefault();
                    const chosen = currentSuggestions[selectedSuggestIndex];
                    selectAndSearch(chosen.barcode, chosen.name);
                } else if (isSuggestOpen && currentSuggestions.length > 0 && !/^\\d{8,14}$/.test(searchInput.value.trim())) {
                    // Kullanıcı Enter bastıysa ve listede öneriler varsa en üstteki 1. ürünü otomatik seç
                    e.preventDefault();
                    const chosen = currentSuggestions[0];
                    selectAndSearch(chosen.barcode, chosen.name);
                } else {
                    suggestBox.classList.add('hidden');
                    handleSearchSubmit();
                }
            } else if (e.key === 'Escape') {
                suggestBox.classList.add('hidden');
                selectedSuggestIndex = -1;
            }
        });

        function updateSuggestHighlight() {
            const rows = suggestBox.querySelectorAll('.suggest-item-row');
            rows.forEach((row, idx) => {
                if (idx === selectedSuggestIndex) {
                    row.classList.add('bg-emerald-50', 'border-l-4', 'border-l-emerald-600', 'pl-3');
                    row.classList.remove('hover:bg-slate-50');
                    row.scrollIntoView({ block: 'nearest' });
                } else {
                    row.classList.remove('bg-emerald-50', 'border-l-4', 'border-l-emerald-600', 'pl-3');
                    row.classList.add('hover:bg-slate-50');
                }
            });
        }

        function renderSuggestions(items, query = '') {
            if (!items || items.length === 0) {
                suggestBox.classList.add('hidden');
                return;
            }

            suggestBox.innerHTML = '';
            
            // Başlık / İpucu çubuğu
            const headerDiv = document.createElement('div');
            headerDiv.className = 'px-4 py-1.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-medium select-none';
            headerDiv.innerHTML = `
                <span><i class="fa-solid fa-bolt text-amber-500 mr-1"></i> Akıllı İlaç & Ürün Seçimi (${items.length})</span>
                <span class="text-slate-400">Yön tuşları <kbd class="px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px]">↑</kbd> <kbd class="px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px]">↓</kbd> ile seçip <kbd class="px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px]">Enter</kbd> yapın</span>
            `;
            suggestBox.appendChild(headerDiv);

            items.forEach((item, index) => {
                const multiBadge = (item.barcode_count && item.barcode_count > 1)
                    ? `<span class="ml-1.5 px-1.5 py-0.5 text-[10px] font-semibold bg-indigo-50 text-indigo-700 rounded border border-indigo-200" title="Kayıtlı Tüm Barkodlar: ${(item.all_barcodes || []).join(', ')}">+${item.barcode_count - 1} Barkod</span>` 
                    : '';
                const highlightedName = highlightMatch(item.name, query);
                const div = document.createElement('div');
                div.className = 'suggest-item-row px-4 py-2.5 hover:bg-slate-50 cursor-pointer flex items-center justify-between transition border-b border-slate-100/60 last:border-b-0';
                div.innerHTML = `
                    <div class="flex items-center space-x-3 min-w-0">
                        <div class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center text-xs font-bold shrink-0">
                            <i class="fa-solid fa-tablets"></i>
                        </div>
                        <div class="min-w-0">
                            <div class="text-sm font-semibold text-slate-800 truncate">${highlightedName}</div>
                            <div class="text-xs text-slate-400 font-mono">${item.barcode}${multiBadge} • <span class="text-slate-500">${item.manufacturer || 'Genel'}</span></div>
                        </div>
                    </div>
                    <div class="text-right shrink-0 ml-3">
                        <div class="text-xs font-semibold text-slate-700">${item.price ? item.price.toFixed(2) + ' ₺' : ''}</div>
                        <span class="text-[10px] text-emerald-600 font-semibold flex items-center justify-end space-x-1">
                            <span>Karşılaştır</span>
                            <i class="fa-solid fa-arrow-right text-[9px]"></i>
                        </span>
                    </div>
                `;
                div.onmouseenter = () => {
                    selectedSuggestIndex = index;
                    updateSuggestHighlight();
                };
                div.onclick = (e) => {
                    e.stopPropagation();
                    selectAndSearch(item.barcode, item.name);
                };
                suggestBox.appendChild(div);
            });

            suggestBox.classList.remove('hidden');
        }

        // Tıklama dışına çıkınca öneri kutusunu kapat
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !suggestBox.contains(e.target)) {
                suggestBox.classList.add('hidden');
                selectedSuggestIndex = -1;
            }
        });

        async function selectAndSearch(barcode, name) {
            // Önceki aramadan kalan önerileri tamamen temizle (karışmayı önler)
            currentSuggestions = [];
            selectedSuggestIndex = -1;

            const input = document.getElementById('searchInput');
            if (input && name) input.value = name;
            else if (input && barcode) input.value = barcode;

            const sBox = document.getElementById('suggestBox');
            if (sBox) sBox.classList.add('hidden');
            const pSel = document.getElementById('productSelection');
            if (pSel) pSel.classList.add('hidden');

            // Sayfanın en üstüne yumuşak kaydır
            window.scrollTo({ top: 0, behavior: 'smooth' });

            const q = (barcode || '').toString().trim();
            // Doğrudan geçerli 8-14 haneli EAN barkod ise hemen sorgula
            if (q && /^\\d{8,14}$/.test(q)) {
                performBarcodeSearch(q);
                return;
            }

            // Eğer barkod geçerli EAN değilse (örn: depo kodu veya salt isim), önce 13 haneli EAN barkodunu çöz
            const targetText = (name || q).trim();
            if (targetText) {
                try {
                    const res = await fetch(`/api/products/find?q=${encodeURIComponent(targetText)}`);
                    if (res.ok) {
                        const data = await res.json();
                        const foundBc = data.barcode || (data.products && data.products.length > 0 ? data.products[0].barcode : null);
                        const foundName = data.name || (data.products && data.products.length > 0 ? data.products[0].name : null);
                        if (foundBc && /^\\d{8,14}$/.test(foundBc)) {
                            if (input && foundName) input.value = foundName;
                            performBarcodeSearch(foundBc);
                            return;
                        }
                    }
                } catch (e) {
                    console.warn('[selectAndSearch] Barkod çözümleme hatası:', e);
                }
            }

            handleSearchSubmit(q || name);
        }

        async function handleSearchSubmit(customQuery) {
            if (customQuery) {
                // Özel parametre ile geldiyse eski önerileri sıfırla
                currentSuggestions = [];
                selectedSuggestIndex = -1;
            }

            const query = (customQuery || searchInput.value).trim();
            if (!query) return;

            suggestBox.classList.add('hidden');

            // Eğer doğrudan barkod ise (en az 8 hane rakam), direkt depo sorgula
            if (/^\\d{8,14}$/.test(query)) {
                productSelection.classList.add('hidden');
                performBarcodeSearch(query);
                return;
            }

            // AKILLI EŞLEŞTİRME: Yalnızca kullanıcı arama kutusuna yazıp enter'a bastıysa önerilerle eşleştir
            if (!customQuery && currentSuggestions && currentSuggestions.length > 0) {
                const qLower = query.toLowerCase();
                const exact = currentSuggestions.find(s => (s.name || '').toLowerCase() === qLower || s.barcode === query);
                if (exact) {
                    currentSuggestions = [];
                    selectAndSearch(exact.barcode, exact.name);
                    return;
                }
                if (currentSuggestions.length === 1) {
                    const onlySug = currentSuggestions[0];
                    currentSuggestions = [];
                    selectAndSearch(onlySug.barcode, onlySug.name);
                    return;
                }
            }

            // Metin araması: Eşleşen ürünleri bul
            loadingText.innerText = `'${query}' için ürünler taranıyor...`;
            loading.classList.remove('hidden');
            results.classList.add('hidden');
            productSelection.classList.add('hidden');

            const abortCtrl = new AbortController();
            const timeoutId = setTimeout(() => abortCtrl.abort(), 10000);

            try {
                const res = await fetch(`/api/products/find?q=${encodeURIComponent(query)}`, {
                    signal: abortCtrl.signal
                });
                clearTimeout(timeoutId);
                if (!res.ok) throw new Error("Arama yapılamadı");
                const data = await res.json();

                if (data.is_barcode || (data.products && data.products.length === 1)) {
                    // Tek bir ürün eşleştiyse doğrudan depolarda karşılaştır
                    const targetBarcode = data.barcode || data.products[0].barcode;
                    performBarcodeSearch(targetBarcode);
                } else if (data.products && data.products.length > 1) {
                    // Birden fazla ürün bulundu (örn: OTC markası) -> Kullanıcıya ürün seçtir
                    renderProductSelection(data.products, query);
                } else {
                    alert(`'${query}' aramasıyla eşleşen ürün bulunamadı. Lütfen barkod veya farklı bir isim deneyin.`);
                }
            } catch (err) {
                clearTimeout(timeoutId);
                if (err.name === 'AbortError') {
                    alert(`'${query}' araması zaman aşımına uğradı. Lütfen doğrudan barkod yazarak deneyin.`);
                } else {
                    alert("Hata oluştu: " + err.message);
                }
            } finally {
                loading.classList.add('hidden');
            }
        }

        function renderProductSelection(products, query) {
            document.getElementById('selectionTitle').innerText = `'${query}' ile Eşleşen Ürünler`;
            document.getElementById('selectionCount').innerText = `${products.length} Farklı Ürün`;

            selectionGrid.innerHTML = '';
            products.forEach(p => {
                const card = document.createElement('div');
                card.className = 'bg-white p-5 rounded-2xl border border-slate-200 hover:border-emerald-500 hover:shadow-md transition cursor-pointer flex flex-col justify-between';
                card.onclick = () => selectAndSearch(p.barcode, p.name);

                card.innerHTML = `
                    <div>
                        <div class="flex items-center justify-between mb-2">
                            <span class="px-2 py-0.5 text-[11px] font-mono font-bold bg-slate-100 text-slate-700 rounded">${p.barcode}</span>
                            <span class="text-xs text-slate-400">${p.manufacturer || 'Genel'}</span>
                        </div>
                        <h4 class="text-sm font-bold text-slate-900 leading-snug line-clamp-2">${p.name}</h4>
                    </div>
                    <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div class="text-xs text-slate-500">
                            ${p.price ? `<span class="font-bold text-slate-800 text-sm">${p.price.toFixed(2)} ₺</span>` : ''}
                        </div>
                        <button class="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold rounded-lg transition flex items-center space-x-1">
                            <span>Karşılaştır</span>
                            <i class="fa-solid fa-arrow-right text-[10px]"></i>
                        </button>
                    </div>
                `;
                selectionGrid.appendChild(card);
            });

            productSelection.classList.remove('hidden');
        }

        async function performBarcodeSearch(barcode) {
            currentReport = null;
            loadingText.innerText = "Tüm aktif depolarda ve pazaryerlerinde eşzamanlı ticari şartlar taranıyor...";
            loading.classList.remove('hidden');
            results.classList.add('hidden');

            const searchCtrl = new AbortController();
            const timeoutId = setTimeout(() => searchCtrl.abort(), 40000);

            try {
                const res = await fetch(`/api/search?q=${encodeURIComponent(barcode)}`, {
                    signal: searchCtrl.signal
                });
                clearTimeout(timeoutId);
                if (!res.ok) throw new Error("Arama başarısız");
                const data = await res.json();
                currentReport = data;
                renderResults(data);
            } catch (err) {
                clearTimeout(timeoutId);
                if (err.name === 'AbortError') {
                    alert("Depo sorgusu zaman aşımına uğradı. Depo portalları geç yanıt veriyor olabilir, lütfen tekrar deneyin.");
                } else {
                    alert("Depo sorgu hatası: " + err.message);
                }
            } finally {
                loading.classList.add('hidden');
            }
        }

        function renderResults(data) {
            const sInp = document.getElementById('searchInput');
            if (sInp && data.urun_adi) sInp.value = data.urun_adi;

            document.getElementById('resBarcode').innerText = data.barkod;
            document.getElementById('resTitle').innerText = data.urun_adi;
            document.getElementById('resStockCount').innerText = `${data.stokta_bulunan_depolar.length} Depoda Stok Mevcut`;

            // Soğuk Zincir Rozeti
            const coldBadge = document.getElementById('resColdChainBadge');
            if (data.soguk_zincir) {
                coldBadge.classList.remove('hidden');
                coldBadge.classList.add('inline-flex');
            } else {
                coldBadge.classList.add('hidden');
                coldBadge.classList.remove('inline-flex');
            }

            // Muadiller / Eşdeğer Butonu
            const eqBtn = document.getElementById('resEquivalentsBtn');
            const eqCount = (data.esdegerler && data.esdegerler.length > 0) ? data.esdegerler.length : 0;
            if (eqCount > 0 || data.esdeger_kodu) {
                eqBtn.classList.remove('hidden');
                eqBtn.classList.add('inline-flex');
                document.getElementById('resEquivalentsBtnText').innerText = eqCount > 0 ? `Muadiller (${eqCount})` : 'Muadiller';
            } else {
                eqBtn.classList.add('hidden');
                eqBtn.classList.remove('inline-flex');
            }

            // SGK Kamu İskontosu, Eczacı Kârı, PSF ve KSF
            const kamuIsk = data.kamu_iskontosu || 0;
            const eczaciKari = data.eczaci_kari || 0;
            const psf = data.psf || 0;
            const ksf = data.kamu_fiyati || (psf > 0 ? (psf * (1.0 - (kamuIsk / 100.0))) : 0);

            document.getElementById('resKamuIsk').innerText = `%${kamuIsk.toFixed(1)}`;
            document.getElementById('resEczaciKari').innerText = `%${eczaciKari.toFixed(1)}`;
            document.getElementById('resPsf').innerText = `${psf.toFixed(2)} ₺`;
            document.getElementById('resKsf').innerText = `${ksf.toFixed(2)} ₺`;

            // Tahmini Kutu Başı Kârlar (Kamu vs Elden)
            const kamuKari = data.kamu_kari !== undefined ? data.kamu_kari : (ksf > 0 && data.en_dusuk_maliyet_kdvli > 0 ? (ksf - data.en_dusuk_maliyet_kdvli) : 0);
            const perakendeKari = data.perakende_kari !== undefined ? data.perakende_kari : (psf > 0 && data.en_dusuk_maliyet_kdvli > 0 ? (psf - data.en_dusuk_maliyet_kdvli) : 0);

            const kamuProfitEl = document.getElementById('resKamuProfit');
            const perakendeProfitEl = document.getElementById('resPerakendeProfit');

            if (kamuKari < 0) {
                kamuProfitEl.innerText = `${kamuKari.toFixed(2)} ₺ (Zarar!)`;
                kamuProfitEl.className = 'font-extrabold text-red-600 ml-1';
            } else {
                kamuProfitEl.innerText = `+${kamuKari.toFixed(2)} ₺`;
                kamuProfitEl.className = 'font-extrabold text-blue-800 ml-1';
            }

            perakendeProfitEl.innerText = `+${perakendeKari.toFixed(2)} ₺`;

            // Daha Kârlı Muadil Rozeti (En kârlı muadil varsa üst arama sonucunda uyarır)
            const muadilAlertEl = document.getElementById('resMuadilProfitOpportunity');
            const bestMuadilNameEl = document.getElementById('resBestMuadilName');
            const bestMuadilGainEl = document.getElementById('resBestMuadilGain');
            if (data.en_karli_muadil && data.muadil_kar_avantaji > 0) {
                if (bestMuadilNameEl) bestMuadilNameEl.innerText = data.en_karli_muadil.urun_adi || data.en_karli_muadil.ad || 'Muadil İlaç';
                if (bestMuadilGainEl) bestMuadilGainEl.innerText = `+${data.muadil_kar_avantaji.toFixed(2)} ₺`;
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('hidden');
                    muadilAlertEl.classList.add('inline-flex');
                }
            } else {
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('inline-flex');
                    muadilAlertEl.classList.add('hidden');
                }
            }

            // KDV bilgisi ve ürün tipi rozeti
            let kdv = 10;
            if (data.sonuclar && data.sonuclar.length > 0) {
                const foundKdv = data.sonuclar.find(s => s.kdv_orani && s.kdv_orani > 0);
                if (foundKdv) kdv = foundKdv.kdv_orani;
            }
            let kdvBadge = '';
            if (Math.abs(kdv - 1.0) < 0.1) {
                kdvBadge = `<span class="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded border border-amber-300 ml-1.5"><i class="fa-solid fa-seedling mr-1"></i>Gıda Takviyesi (%1 KDV)</span>`;
            } else if (Math.abs(kdv - 20.0) < 0.1) {
                kdvBadge = `<span class="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded border border-blue-300 ml-1.5"><i class="fa-solid fa-pump-soap mr-1"></i>Kozmetik / Itriyat (%20 KDV)</span>`;
            } else {
                kdvBadge = `<span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-300 ml-1.5"><i class="fa-solid fa-capsules mr-1"></i>İlaç (%10 KDV)</span>`;
            }
            document.getElementById('resVatInfo').innerHTML = `<i class="fa-solid fa-receipt mr-1"></i>KDV: <strong>%${kdv}</strong> ${kdvBadge}`;

            // Bugün sipariş verildi / sepette uyarısı
            const todayOrdBanner = document.getElementById('resTodayOrderedBanner');
            if (todayOrdBanner) {
                const ord = data.bugun_siparis;
                if (ord && ord.durum) {
                    const isFinalized = ord.durum === 'SIPARIS_VERILDI';
                    const isSkipped = ord.durum === 'SIPARIS_VERILMEYECEK';
                    const safeBc = (data.barkod || ord.barkod || '').replace(/'/g, "\\\\'");
                    const safeNm = (data.urun_adi || ord.urun_adi || '').replace(/'/g, "\\\\'");
                    todayOrdBanner.classList.remove('hidden');
                    if (isFinalized) {
                        todayOrdBanner.innerHTML = `
                            <div class="p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-lg shadow-emerald-600/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                                <div class="flex items-center space-x-3">
                                    <div class="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl shrink-0">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </div>
                                    <div>
                                        <div class="text-xs font-black uppercase tracking-wider text-emerald-100">⚠️ Mükerrer Sipariş Uyarısı — Bugün Sipariş Verildi!</div>
                                        <div class="text-sm font-bold mt-0.5">
                                            Bu ürün bugün saat <strong>${ord.saat || '--:--'}</strong> itibarıyla <strong>${ord.masa_adi || ord.masa || 'Eczane PC'}</strong> üzerinden <strong>${ord.depo || 'Depo'}</strong> deposuna <strong>${ord.miktar || 1} Kutu</strong> olarak sipariş verilip sonlandırılmıştır.
                                        </div>
                                    </div>
                                </div>
                                <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeNm}', event)" class="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold border border-white/30 transition shrink-0 cursor-pointer">
                                    <i class="fa-solid fa-rotate-left mr-1"></i>İşareti Kaldır
                                </button>
                            </div>
                        `;
                    } else if (isSkipped) {
                        todayOrdBanner.innerHTML = `
                            <div class="p-4 rounded-2xl bg-gradient-to-r from-slate-700 via-slate-800 to-rose-950 text-white shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                                <div class="flex items-center space-x-3">
                                    <div class="w-10 h-10 rounded-xl bg-rose-500/30 border border-rose-400/40 flex items-center justify-center text-xl text-rose-300 shrink-0">
                                        <i class="fa-solid fa-ban"></i>
                                    </div>
                                    <div>
                                        <div class="text-xs font-black uppercase tracking-wider text-rose-200">🚫 Bugün Sipariş Verilmeyecek Olarak İşaretlendi</div>
                                        <div class="text-sm font-bold mt-0.5">
                                            Bu ürün bugün saat <strong>${ord.saat || '--:--'}</strong> itibarıyla <strong>${ord.masa_adi || ord.masa || 'Eczane PC'}</strong> tarafından <strong>Sipariş Verilmeyecek</strong> olarak işaretlenmiştir.
                                        </div>
                                    </div>
                                </div>
                                <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeNm}', event)" class="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold border border-white/30 transition shrink-0 cursor-pointer">
                                    <i class="fa-solid fa-rotate-left mr-1"></i>İşareti Kaldır
                                </button>
                            </div>
                        `;
                    } else {
                        todayOrdBanner.innerHTML = `
                            <div class="p-3.5 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                                <div class="flex items-center space-x-3">
                                    <div class="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center text-base shrink-0">
                                        <i class="fa-solid fa-cart-shopping"></i>
                                    </div>
                                    <div class="text-xs">
                                        <div class="font-black text-sm">🛒 Bu Ürün Bugün Depo Sepetine Eklendi</div>
                                        <div class="mt-0.5">
                                            Saat <strong>${ord.saat || '--:--'}</strong> itibarıyla <strong>${ord.masa_adi || ord.masa || 'Eczane PC'}</strong> bilgisayarından <strong>${ord.depo || 'Depo'}</strong> sepetine <strong>${ord.miktar || 1} Kutu</strong> eklendi.
                                        </div>
                                    </div>
                                </div>
                                <div class="flex items-center space-x-2 shrink-0">
                                    <button type="button" onclick="markItemOrderedDirect('${safeBc}', '${safeNm}', '${ord.depo || 'SELCUK'}', ${ord.miktar || 1})" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition cursor-pointer">
                                        <i class="fa-solid fa-check mr-1"></i>Sipariş Verildi İşaretle
                                    </button>
                                    <button type="button" onclick="unmarkItemOrderStatus('${safeBc}', '${safeNm}', event)" class="px-2.5 py-1.5 rounded-xl bg-white hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-amber-300 text-xs font-bold transition cursor-pointer">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                </div>
                            </div>
                        `;
                    }
                } else {
                    todayOrdBanner.classList.add('hidden');
                    todayOrdBanner.innerHTML = '';
                }
            }

            const bestBanner = document.getElementById('bestDealBanner');
            if (data.en_avantajli_depo && data.en_dusuk_maliyet !== null) {
                bestBanner.classList.remove('hidden');
                const bestRow = data.sonuclar.find(s => s.depo === data.en_avantajli_depo && Math.abs(s.net_birim_maliyet - data.en_dusuk_maliyet) < 0.01) || data.sonuclar[0];
                document.getElementById('bestDepoName').innerText = bestRow ? bestRow.depo_adi : data.en_avantajli_depo;
                document.getElementById('bestCost').innerText = (data.en_dusuk_maliyet || 0).toFixed(2) + ' ₺';
                document.getElementById('bestCostKdvli').innerText = (data.en_dusuk_maliyet_kdvli || 0).toFixed(2) + ' ₺';
            } else {
                bestBanner.classList.add('hidden');
            }

            tableBody.innerHTML = '';
            selectedRowIndex = null;

            data.sonuclar.forEach((item, index) => {
                const isBest = (item.depo === data.en_avantajli_depo && Math.abs(item.net_birim_maliyet - data.en_dusuk_maliyet) < 0.01);
                const tr = document.createElement('tr');
                tr.className = `hover:bg-slate-50/80 transition ${isBest ? 'bg-emerald-50/40 font-medium' : ''}`;

                let depoColor = 'text-slate-700 font-bold';
                if (item.depo === 'ALLIANCE') depoColor = 'text-sky-700 font-bold';
                if (item.depo === 'SELCUK') depoColor = 'text-emerald-700 font-bold';
                if (item.depo === 'NEVZAT') depoColor = 'text-orange-700 font-bold';
                if (item.depo === 'ISKOOP') depoColor = 'text-red-700 font-bold';
                if (item.depo === 'BEK') depoColor = 'text-teal-700 font-bold';
                if (item.depo === 'ECZA1') depoColor = 'text-purple-700 font-bold';
                if (item.depo === 'FARMAZON') depoColor = 'text-amber-600 font-bold';
                if (item.depo === 'DNA') depoColor = 'text-cyan-700 font-bold';
                if (item.depo === 'ECZATREND') depoColor = 'text-orange-600 font-bold';
                if (item.depo === 'ECZANETAKAS') depoColor = 'text-sky-700 font-bold';

                let stockBadge = item.stok_durumu === 'VAR' 
                    ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800"><i class="fa-solid fa-check mr-1"></i>VAR ${item.stok_adedi ? `(${item.stok_adedi})` : ''}</span>`
                    : `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-500"><i class="fa-solid fa-xmark mr-1"></i>YOK</span>`;

                if (item.depo === 'ECZATREND') {
                    if (item.stok_adedi > 0) {
                        stockBadge = `<span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-extrabold bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs" title="Kampanyayı tamamlamak için kalan adet"><i class="fa-solid fa-hourglass-half mr-1 text-[11px] text-amber-700"></i>Kalan: ${item.stok_adedi} Adet</span>`;
                    } else {
                        stockBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-500" title="Kampanya hedefine ulaşıldı"><i class="fa-solid fa-check-double mr-1 text-[10px]"></i>Hedef Doldu</span>`;
                    }
                } else if (item.depo === 'ECZANETAKAS') {
                    if (item.stok_durumu === 'VAR' && item.stok_adedi > 0) {
                        stockBadge = `<span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-extrabold bg-sky-100 text-sky-900 border border-sky-300 shadow-2xs" title="EczaneTakas açık tekliflerde kalan toplam stok"><i class="fa-solid fa-boxes-stacked mr-1 text-[11px] text-sky-700"></i>Kalan: ${item.stok_adedi} Kutu</span>`;
                    } else {
                        stockBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-500" title="Açık teklif bulunmuyor"><i class="fa-solid fa-xmark mr-1 text-[10px]"></i>YOK</span>`;
                    }
                }

                // Soğuk Zincir Simgesi
                const rowColdIcon = item.soguk_zincir ? `<span class="text-sky-500 text-xs ml-1" title="Soğuk Zincir (+2°C / +8°C)"><i class="fa-solid fa-snowflake"></i></span>` : '';

                // MF Kademeleri veya Pazaryeri Satıcı Teklifleri HTML (MF'siz Fiyat ve MF'li Birim Fiyat KDV Hariç)
                const baseSingleNet = (item.ticari_iskonto && item.ticari_iskonto > 0 && item.depocu_satis_fiyati > 0)
                    ? (item.depocu_satis_fiyati * (1.0 - (item.ticari_iskonto / 100.0)))
                    : (item.net_birim_maliyet || item.depocu_satis_fiyati || 0);

                // Gerçekten indirim sağlayan veya hediye kutu içeren baremler
                const realKademeler = (item.kademeler || []).filter(k => 
                    (k.hediye && k.hediye > 0) || 
                    (k.net_birim_maliyet && k.net_birim_maliyet < (baseSingleNet - 0.02))
                );
                const hasRealMf = realKademeler.length > 0 || (item.hediye && item.hediye > 0);

                let mfHtml = '';
                if (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri.length > 0) {
                    const isFarmazon = item.depo === 'FARMAZON';
                    const isEczatrend = item.depo === 'ECZATREND';
                    const isEczanetakas = item.depo === 'ECZANETAKAS';
                    let btnCls = 'bg-purple-100 hover:bg-purple-200 text-purple-900 border-purple-300';
                    let btnLabel = `${item.pazaryeri_teklifleri.length} Farklı Satıcı Fiyatı`;
                    let btnIcon = 'fa-tags';
                    if (isFarmazon) {
                        btnCls = 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300';
                    } else if (isEczatrend) {
                        btnCls = 'bg-orange-100 hover:bg-orange-200 text-orange-950 border-orange-300';
                        btnLabel = `${item.pazaryeri_teklifleri.length} Grup Teklifi (${item.mf_metni})`;
                        btnIcon = 'fa-people-group';
                    } else if (isEczanetakas) {
                        btnCls = 'bg-sky-100 hover:bg-sky-200 text-sky-950 border-sky-300';
                        btnLabel = `${item.pazaryeri_teklifleri.length} Eczane Teklifi (${item.mf_metni})`;
                        btnIcon = 'fa-arrow-right-arrow-left';
                    }
                    mfHtml = `
                        <div class="flex flex-col space-y-1">
                            ${isEczatrend ? `
                                <div class="inline-flex items-center space-x-1.5 text-xs font-bold text-orange-900">
                                    <span class="px-2 py-0.5 rounded bg-orange-100 border border-orange-300"><i class="fa-solid fa-users mr-1"></i>Barem: ${item.mf_metni}</span>
                                    <span class="text-[10px] text-slate-500 font-medium">Hedef: ${item.pazaryeri_teklifleri[0]?.hedef || '-'} Kutu</span>
                                </div>
                            ` : isEczanetakas ? `
                                <div class="inline-flex items-center space-x-1.5 text-xs font-bold text-sky-900">
                                    <span class="px-2 py-0.5 rounded bg-sky-100 border border-sky-300"><i class="fa-solid fa-handshake mr-1"></i>Barem: ${item.mf_metni}</span>
                                    <span class="text-[10px] text-slate-500 font-medium truncate max-w-xs" title="${item.ozel_kampanya_notu || ''}">${item.ozel_kampanya_notu || ''}</span>
                                </div>
                            ` : ''}
                            <button type="button" onclick="toggleOffersRow(${index})" class="px-2.5 py-1 text-xs font-bold rounded-xl border ${btnCls} transition flex items-center space-x-1.5 cursor-pointer shadow-2xs">
                                <i class="fa-solid ${btnIcon} text-[10px]"></i>
                                <span>${btnLabel}</span>
                                <i id="offersChevron_${index}" class="fa-solid fa-chevron-down text-[10px] transition-transform duration-200"></i>
                            </button>
                        </div>
                    `;
                } else if (realKademeler.length > 0) {
                    mfHtml = `
                        <div class="flex flex-col space-y-1.5">
                            <div class="flex items-center space-x-1.5 text-[11px] text-slate-500">
                                <span>MF'siz (1 Adet):</span>
                                <span class="font-mono text-slate-700 font-semibold text-[10px]">${baseSingleNet.toFixed(2)} ₺</span>
                            </div>
                            <div class="flex flex-wrap gap-1.5">` + realKademeler.map(k => {
                                const tot = (k.alinan || 0) + (k.hediye || 0);
                                const tierMfliNet = (k.net_birim_maliyet && k.net_birim_maliyet > 0) ? k.net_birim_maliyet : (tot > 0 ? (((k.alinan || 1) * baseSingleNet) / tot) : baseSingleNet);
                                const tierMfliKdvli = (k.net_birim_maliyet_kdvli && k.net_birim_maliyet_kdvli > 0) ? k.net_birim_maliyet_kdvli : (tierMfliNet * (1.0 + (item.kdv_orani || 10.0) / 100.0));
                                return `
                                    <button type="button" onclick="setSimWithTier(${index}, ${k.alinan}, ${k.hediye})" class="group inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-indigo-50/90 hover:bg-indigo-600 hover:text-white border border-indigo-200 text-indigo-900 transition shadow-2xs cursor-pointer text-left" title="MF Barem: ${k.mf_text} — Tıklayarak siparişe aktarın (KDV Dahil: ${tierMfliKdvli.toFixed(2)} ₺)">
                                        <span class="font-bold text-xs">${k.mf_text}</span>
                                        <span class="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 group-hover:bg-emerald-500 group-hover:text-white font-extrabold font-mono text-emerald-800" title="MF'li Birim Net Maliyet (KDV Hariç)">
                                            ${tierMfliNet.toFixed(2)} ₺
                                        </span>
                                        <span class="text-[9px] text-slate-500 group-hover:text-indigo-200 font-mono" title="KDV Dahil Net Maliyet">
                                            (${tierMfliKdvli.toFixed(2)} ₺ KDV'li)
                                        </span>
                                    </button>
                                `;
                            }).join('') + `</div>
                        </div>
                    `;
                } else if (item.hediye && item.hediye > 0) {
                    const tot = (item.alinan || 1) + item.hediye;
                    const singleMfliNet = tot > 0 ? (((item.alinan || 1) * baseSingleNet) / tot) : baseSingleNet;
                    const singleMfliKdvli = singleMfliNet * (1.0 + (item.kdv_orani || 10.0) / 100.0);
                    mfHtml = `
                        <div class="flex flex-col space-y-1">
                            <div class="flex items-center space-x-1.5 text-[11px] text-slate-500">
                                <span>MF'siz (1 Adet):</span>
                                <span class="font-mono text-slate-700 text-[10px] font-semibold">${baseSingleNet.toFixed(2)} ₺</span>
                            </div>
                            <button type="button" onclick="setSimWithTier(${index}, ${item.alinan || 1}, ${item.hediye})" class="group inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-600 hover:text-white border border-emerald-300 text-emerald-950 transition shadow-2xs cursor-pointer text-left" title="Tıklayarak siparişe aktarın">
                                <span class="font-bold text-xs">${item.mf_metni}</span>
                                <span class="text-[10px] px-1.5 py-0.5 rounded bg-white group-hover:bg-white/20 font-black font-mono text-emerald-700 group-hover:text-white border border-emerald-200 group-hover:border-transparent">
                                    ${singleMfliNet.toFixed(2)} ₺
                                </span>
                                <span class="text-[9px] text-slate-500 group-hover:text-emerald-200 font-mono">
                                    (${singleMfliKdvli.toFixed(2)} ₺ KDV'li)
                                </span>
                            </button>
                        </div>
                    `;
                } else if (item.mf_metni && item.mf_metni !== 'YOK' && item.mf_metni !== 'None' && item.mf_metni !== '-' && item.mf_metni.trim() !== '') {
                    const mfParts = item.mf_metni.split('/').map(p => p.trim()).filter(Boolean);
                    mfHtml = `
                        <div class="flex flex-col space-y-1">
                            <div class="flex items-center space-x-1.5 text-[11px] text-slate-500">
                                <span>MF'siz (1 Adet):</span>
                                <span class="font-mono text-slate-700 text-[10px] font-semibold">${baseSingleNet.toFixed(2)} ₺</span>
                            </div>
                            <div class="flex flex-wrap gap-1">` + mfParts.map(part => {
                                const pairMatch = part.match(/(\\d+)\\s*\\+\\s*(\\d+)/);
                                let alinan = 1, hediye = 0;
                                if (pairMatch) {
                                    alinan = parseInt(pairMatch[1], 10);
                                    hediye = parseInt(pairMatch[2], 10);
                                }
                                const tot = alinan + hediye;
                                const partNet = tot > 0 ? ((alinan * baseSingleNet) / tot) : baseSingleNet;
                                const partKdvli = partNet * (1.0 + (item.kdv_orani || 10.0) / 100.0);
                                return `
                                    <button type="button" onclick="setSimWithTier(${index}, ${alinan}, ${hediye})" class="group inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-lg bg-emerald-50 hover:bg-emerald-600 hover:text-white border border-emerald-300 text-emerald-950 transition shadow-2xs cursor-pointer text-left" title="MF Barem: ${part} — Tıklayarak siparişe aktarın (KDV Dahil: ${partKdvli.toFixed(2)} ₺)">
                                        <span class="font-bold text-xs">${part}</span>
                                        <span class="text-[10px] px-1.5 py-0.5 rounded bg-white group-hover:bg-white/20 font-black font-mono text-emerald-700 group-hover:text-white border border-emerald-200 group-hover:border-transparent">
                                            ${partNet.toFixed(2)} ₺
                                        </span>
                                    </button>
                                `;
                            }).join('') + `</div>
                        </div>
                    `;
                } else if (item.depo === 'ECZANETAKAS' && item.stok_durumu !== 'VAR') {
                    mfHtml = `
                        <div class="flex flex-col items-start space-y-1">
                            <span class="text-[11px] font-medium text-slate-500">${item.ozel_kampanya_notu || 'Bu ürün için şu an açık teklif yok.'}</span>
                            <button type="button" onclick="openEczaneTakasOffersModal()" class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl text-xs font-extrabold bg-sky-50 hover:bg-sky-600 text-sky-800 hover:text-white border border-sky-200 hover:border-sky-600 transition cursor-pointer shadow-2xs">
                                <i class="fa-solid fa-list-check text-[10px]"></i>
                                <span>Portaldaki Tüm Açık Teklifleri Gör ➔</span>
                            </button>
                        </div>
                    `;
                } else {
                    mfHtml = `
                        <span class="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-400">MF Yok</span>
                    `;
                }

                // Miad ve İskonto Rozetleri
                const miadBadge = item.miad 
                    ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200 mt-1" title="Son Kullanma Tarihi / Miad"><i class="fa-regular fa-calendar-check mr-1 text-[10px]"></i>Miad: ${item.miad}</span>` 
                    : '';

                const iskBadge = (item.ticari_iskonto && item.ticari_iskonto > 0)
                    ? `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 mt-1" title="Ticari / Nakit İskonto"><i class="fa-solid fa-percent mr-0.5 text-[8px]"></i>%${item.ticari_iskonto.toFixed(1)} İsk</span>`
                    : '';

                const isEczatrendItem = item.depo === 'ECZATREND';
                const isEczanetakasItem = item.depo === 'ECZANETAKAS';
                const offersBadgeCol1 = (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri.length > 0) ? `
                    <button type="button" onclick="toggleOffersRow(${index})" class="mt-1 text-[11px] font-bold ${isEczatrendItem ? 'text-orange-700 hover:text-orange-900' : isEczanetakasItem ? 'text-sky-700 hover:text-sky-900' : 'text-amber-700 hover:text-amber-900'} flex items-center space-x-1 cursor-pointer">
                        <i class="fa-solid ${isEczatrendItem ? 'fa-people-group' : isEczanetakasItem ? 'fa-arrow-right-arrow-left' : 'fa-layer-group'} text-[10px]"></i>
                        <span>${isEczatrendItem ? 'Grup Teklifleri & Kalanı Gör' : isEczanetakasItem ? 'Tüm Eczane Tekliflerini Gör' : 'Fiyat Detaylarını Gör'} (${item.pazaryeri_teklifleri.length})</span>
                    </button>
                ` : '';

                const safeItemName = (item.urun_adi || '').replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
                const DEPO_PORTAL_CARTS = {
                    'SELCUK': 'https://webdepo.selcukecza.com.tr/Siparis/sepet.aspx',
                    'ALLIANCE': 'https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart',
                    'ISKOOP': 'https://esube.iskoop.org/FrameWorkT1/#/baskets',
                    'NEVZAT': 'http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx',
                    'ECZANETAKAS': 'https://eczanetakas.com/teklifler/1'
                };
                const cartPortalUrl = DEPO_PORTAL_CARTS[item.depo];
                const cartLinkBadge = cartPortalUrl ? `
                    <a href="${cartPortalUrl}" target="_blank" class="mt-1 text-[10px] font-bold text-slate-400 hover:text-slate-800 flex items-center space-x-1 transition" title="${item.depo_adi} canlı portal sayfasını yeni sekmede aç">
                        <i class="fa-solid fa-cart-shopping text-[9px] text-slate-500"></i>
                        <span>${item.depo === 'ECZANETAKAS' ? 'Takas Portalı ↗' : 'Sepeti Gör ↗'}</span>
                    </a>
                ` : '';

                tr.innerHTML = `
                    <td class="py-4 px-6">
                        <div class="flex flex-col items-start">
                            <div class="flex items-center space-x-2">
                                <span class="${depoColor}">${item.depo_adi}</span>
                                ${rowColdIcon}
                                ${isBest ? '<span class="px-2 py-0.5 text-[10px] bg-emerald-600 text-white rounded-full font-bold uppercase tracking-wider">En Avantajlı</span>' : ''}
                            </div>
                            ${miadBadge}
                            ${offersBadgeCol1}
                            ${cartLinkBadge}
                        </div>
                    </td>
                    <td class="py-4 px-6">${stockBadge}</td>
                    <td class="py-4 px-6 text-slate-700 font-semibold">${item.depocu_satis_fiyati.toFixed(2)} ₺</td>
                    <td class="py-4 px-6">${mfHtml}</td>
                    <td class="py-4 px-6 text-slate-600">
                        <div class="font-medium">${item.vade_gun > 0 ? item.vade_gun + ' Gün' : 'Peşin / Kredi Kartı'}</div>
                        ${iskBadge}
                    </td>
                    <td class="py-4 px-6">
                        <div class="text-base font-extrabold ${isBest ? 'text-emerald-600' : 'text-slate-900'}">
                            ${item.net_birim_maliyet.toFixed(2)} ₺
                        </div>
                        <div class="text-[10px] text-slate-500 font-medium">
                            KDV Hariç ${realKademeler.length > 0 ? `(${realKademeler[0].mf_text} ile)` : ''}
                        </div>
                        ${psf > 0 ? `
                        <div class="text-[10px] text-slate-500 mt-1 flex flex-col space-y-0.5">
                            <span title="SGK Reçeteli Kutu Kârı: KSF - Alış" class="${(item.kamu_kari || 0) < 0 ? 'text-red-600 font-bold' : 'text-blue-700 font-medium'}">
                                <i class="fa-solid fa-file-prescription mr-1 text-[9px]"></i>SGK: ${(item.kamu_kari || 0) >= 0 ? '+' : ''}${(item.kamu_kari || 0).toFixed(2)} ₺
                            </span>
                            <span title="Elden Satış Kutu Kârı: PSF - Alış" class="text-emerald-700 font-medium">
                                <i class="fa-solid fa-hand-holding-dollar mr-1 text-[9px]"></i>Elden: +${(item.perakende_kari || 0).toFixed(2)} ₺
                            </span>
                        </div>
                        ` : ''}
                    </td>
                    <td class="py-4 px-6 text-right font-bold text-slate-700">
                        <div class="text-base font-extrabold text-slate-900">${item.net_birim_maliyet_kdvli.toFixed(2)} ₺</div>
                        <div class="text-[10px] text-slate-400 font-normal">%${item.kdv_orani} KDV Dahil</div>
                        ${(realKademeler.length > 0 && Math.abs(baseSingleNet - item.net_birim_maliyet) > 0.05) ? `
                            <div class="text-[10px] text-slate-500 mt-0.5 font-medium" title="1 Adet Tek Alımda KDV Dahil Tutar">
                                1 Adet: ${(baseSingleNet * (1 + item.kdv_orani/100)).toFixed(2)} ₺
                            </div>
                        ` : ''}
                    </td>
                    <td class="py-4 px-6 text-right">
                        ${item.depo === 'ECZATREND' ? `
                            <div class="flex items-center justify-end space-x-1.5">
                                <a href="https://eczatrend.com/eczanet/panelNew/main" target="_blank" class="px-3 py-1.5 rounded-xl text-xs font-bold bg-orange-600 hover:bg-orange-700 text-white shadow-sm shadow-orange-200 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer" title="Eczatrend portalında ortak alıma katıl">
                                    <i class="fa-solid fa-people-group text-[11px]"></i>
                                    <span>Ortak Alıma Git</span>
                                    <i class="fa-solid fa-arrow-up-right-from-square text-[9px] ml-0.5 opacity-80"></i>
                                </a>
                            </div>
                        ` : item.depo === 'ECZANETAKAS' ? `
                            <div class="flex items-center justify-end space-x-1.5">
                                ${item.stok_durumu === 'VAR' ? `
                                    <a href="${(item.pazaryeri_teklifleri && item.pazaryeri_teklifleri[0] && item.pazaryeri_teklifleri[0].katil_url) ? item.pazaryeri_teklifleri[0].katil_url : 'https://eczanetakas.com/teklifler/1'}" target="_blank" class="px-3 py-1.5 rounded-xl text-xs font-bold bg-sky-600 hover:bg-sky-700 text-white shadow-sm shadow-sky-200 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer" title="EczaneTakas portalında teklife katıl">
                                        <i class="fa-solid fa-arrow-right-arrow-left text-[11px]"></i>
                                        <span>Teklife Katıl</span>
                                        <i class="fa-solid fa-arrow-up-right-from-square text-[9px] ml-0.5 opacity-80"></i>
                                    </a>
                                ` : `
                                    <button type="button" onclick="openEczaneTakasOffersModal()" class="px-3 py-1.5 rounded-xl text-xs font-bold bg-sky-600 hover:bg-sky-700 text-white shadow-sm shadow-sky-200 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer" title="EczaneTakas üzerindeki tüm aktif ilaç tekliflerini listele">
                                        <i class="fa-solid fa-list-ul text-[11px]"></i>
                                        <span>Açık Teklifleri Gör</span>
                                    </button>
                                `}
                            </div>
                        ` : ['ECZA1', 'FARMAZON'].includes(item.depo) ? `
                            <div class="flex items-center justify-end">
                                <button type="button" onclick="toggleOffersRow(${index})" class="px-3 py-1.5 rounded-xl text-xs font-bold ${item.depo === 'FARMAZON' ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-200' : 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-200'} transition flex items-center space-x-1 shadow-sm cursor-pointer whitespace-nowrap" title="Tüm satıcıların fiyatlarını ve stoklarını gör">
                                    <i class="fa-solid fa-list-ul text-[10px]"></i>
                                    <span>Teklifleri Gör</span>
                                </button>
                            </div>
                        ` : `
                            <div class="flex flex-col items-end space-y-1.5 min-w-[190px]">
                                <div class="flex items-center justify-end space-x-1.5 w-full">
                                    <input type="number" id="qty_${index}" min="1" value="1" class="w-14 px-2 py-1 text-xs border border-slate-300 rounded-lg text-center font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none" title="Sipariş Adedi" />
                                    <button onclick="addToCart('${item.depo}', '${item.urun_id || item.barkod}', '${item.barkod}', ${index}, this, '${safeItemName}')" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center space-x-1 shadow-sm cursor-pointer whitespace-nowrap" title="${item.depo_adi} sepetine ekle">
                                        <i class="fa-solid fa-cart-plus text-[11px]"></i>
                                        <span>Sepete At</span>
                                    </button>
                                </div>
                                <button onclick="quickFinalizeOrder('${item.depo}', '${item.urun_id || item.barkod}', '${item.barkod}', ${index}, '${safeItemName}', ${item.net_birim_maliyet_kdvli || item.depocu_satis_fiyati || 0})" class="w-full px-2.5 py-1 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white rounded-lg text-xs font-black transition flex items-center justify-center space-x-1.5 shadow-xs hover:shadow cursor-pointer whitespace-nowrap" title="Tekli acil siparişi hemen depoya ilet ve sonlandır (Sepet kontrolü ile)">
                                    <i class="fa-solid fa-bolt-lightning text-amber-200 animate-pulse text-[11px]"></i>
                                    <span>Siparişi Sonlandır</span>
                                </button>
                            </div>
                        `}
                    </td>
                `;
                tableBody.appendChild(tr);

                // Pazaryeri (Farmazon & Ecza1) ve Alım Grubu (Eczatrend) Detaylı Satıcı Teklifleri Akordiyon Satırı
                if (item.pazaryeri_teklifleri && item.pazaryeri_teklifleri.length > 0) {
                    const trOffers = document.createElement('tr');
                    trOffers.id = `offersRow_${index}`;
                    trOffers.className = 'hidden bg-slate-50/90 border-y border-dashed border-slate-300';

                    const isFarmazon = item.depo === 'FARMAZON';
                    const isEczatrend = item.depo === 'ECZATREND';
                    const isEczanetakas = item.depo === 'ECZANETAKAS';
                    let themeHeader = isFarmazon ? 'text-amber-900 bg-amber-50/90 border-amber-200' : 'text-purple-900 bg-purple-50/90 border-purple-200';
                    let iconHeader = isFarmazon ? 'fa-store text-amber-600' : 'fa-cart-shopping text-purple-600';
                    if (isEczatrend) {
                        themeHeader = 'text-orange-950 bg-orange-50/90 border-orange-200';
                        iconHeader = 'fa-people-group text-orange-600';
                    } else if (isEczanetakas) {
                        themeHeader = 'text-sky-950 bg-sky-50/90 border-sky-200';
                        iconHeader = 'fa-arrow-right-arrow-left text-sky-600';
                    }

                    let offersTbody = '';
                    let tableHeaderHtml = '';

                    if (isEczatrend) {
                        tableHeaderHtml = `
                            <tr>
                                <th class="py-2.5 px-3 text-center w-20">Sıra</th>
                                <th class="py-2.5 px-3">Açan Eczane & Grup</th>
                                <th class="py-2.5 px-3 text-center w-24">Barem (MF)</th>
                                <th class="py-2.5 px-3 text-center w-28">Hedef / Alınan</th>
                                <th class="py-2.5 px-3 text-center w-28">Kalan Adet</th>
                                <th class="py-2.5 px-3 text-right w-28">Birim KDV Hariç</th>
                                <th class="py-2.5 px-3 text-right w-28">Birim KDV Dahil</th>
                                <th class="py-2.5 px-3 text-center w-36">Durum & Süre</th>
                                <th class="py-2.5 px-3 text-right w-24">İşlem</th>
                            </tr>
                        `;
                        offersTbody = item.pazaryeri_teklifleri.map((off, oIdx) => {
                            const isCheapest = oIdx === 0;
                            const isAcik = (off.kalan || 0) > 0;
                            const durumBadge = isAcik
                                ? `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200"><i class="fa-solid fa-circle-check mr-1 text-[9px]"></i>Alıma Açık</span>`
                                : `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-500"><i class="fa-solid fa-flag-checkered mr-1 text-[9px]"></i>Hedef Doldu</span>`;

                            return `
                                <tr class="hover:bg-white transition ${isCheapest ? 'bg-orange-50/40' : ''}">
                                    <td class="py-2.5 px-3 text-center">
                                        ${isCheapest ? '<span class="px-1.5 py-0.5 text-[10px] font-black rounded bg-orange-600 text-white uppercase tracking-wider">En Uygun</span>' : `<span class="text-slate-400 font-mono text-[11px]">#${oIdx + 1}</span>`}
                                    </td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-bold text-slate-900 flex items-center">
                                            <i class="fa-solid fa-hospital text-[11px] text-orange-600 mr-1.5"></i>
                                            <span>${off.satici || off.pharmacy}</span>
                                            <span class="text-[10px] text-slate-500 font-normal ml-1.5 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">${off.groupName}</span>
                                        </div>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-black bg-indigo-100 text-indigo-900 border border-indigo-200 font-mono">
                                            ${off.mf || 'Barem'}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-center text-xs">
                                        <div class="font-bold text-slate-800">${off.hedef} Kutu Hedef</div>
                                        <div class="text-[10px] text-slate-500 font-medium">Alınan: ${off.alinan} (${off.doluluk})</div>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-black ${isAcik ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-slate-100 text-slate-500'}">
                                            ${off.kalan} Kutu
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-bold text-slate-800 font-mono">
                                        ${(off.fiyat_kdvsiz || 0).toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-extrabold text-orange-700 font-mono">
                                        ${(off.fiyat || 0).toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        ${durumBadge}
                                        ${off.kalan_sure ? `<span class="text-[10px] text-slate-500 block mt-0.5 font-medium">${off.kalan_sure}</span>` : ''}
                                    </td>
                                    <td class="py-2.5 px-3 text-right">
                                        <a href="https://eczatrend.com/eczanet/panelNew/main" target="_blank" class="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold bg-orange-600 hover:bg-orange-700 text-white shadow-2xs transition">
                                            <i class="fa-solid fa-arrow-up-right-from-square mr-1 text-[10px]"></i>Katıl
                                        </a>
                                    </td>
                                </tr>
                            `;
                        }).join('');
                    } else if (isEczanetakas) {
                        tableHeaderHtml = `
                            <tr>
                                <th class="py-2.5 px-3 text-center w-20">Sıra</th>
                                <th class="py-2.5 px-3">Teklifi Veren Eczane</th>
                                <th class="py-2.5 px-3 text-center w-24">Barem (MF)</th>
                                <th class="py-2.5 px-3 text-center w-28">Kalan Kutu</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Hariç</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Dahil</th>
                                <th class="py-2.5 px-3 text-center w-28">Miad Tarihi</th>
                                <th class="py-2.5 px-3">Not / Açıklama</th>
                                <th class="py-2.5 px-3 text-right w-24">İşlem</th>
                            </tr>
                        `;
                        offersTbody = item.pazaryeri_teklifleri.map((off, oIdx) => {
                            const isCheapest = oIdx === 0;
                            const kdvli = (off.fiyat_kdvli != null ? off.fiyat_kdvli : (off.fiyat || 0));
                            const kdvsiz = (off.fiyat_kdvsiz != null ? off.fiyat_kdvsiz : (kdvli / (1.0 + (item.kdv_orani || 10.0) / 100.0)));
                            const katilLink = off.katil_url || `https://eczanetakas.com/katil/${off.teklif_no}`;
                            return `
                                <tr class="hover:bg-white transition ${isCheapest ? 'bg-sky-50/40' : ''}">
                                    <td class="py-2.5 px-3 text-center">
                                        ${isCheapest ? '<span class="px-1.5 py-0.5 text-[10px] font-black rounded bg-sky-600 text-white uppercase tracking-wider">En Uygun</span>' : `<span class="text-slate-400 font-mono text-[11px]">#${oIdx + 1}</span>`}
                                    </td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-bold text-slate-900 flex items-center">
                                            <i class="fa-solid fa-hospital text-[11px] text-sky-600 mr-1.5"></i>
                                            <span>${off.satici || 'Eczane'}</span>
                                            <span class="text-[10px] text-slate-500 font-mono ml-2">#${off.teklif_no || ''}</span>
                                        </div>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-black bg-indigo-100 text-indigo-900 border border-indigo-200 font-mono">
                                            ${off.mf || 'MF Yok'}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-xl text-xs font-black bg-sky-100 text-sky-900 border border-sky-300">
                                            ${off.stok} Kutu
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-bold text-slate-800 font-mono">
                                        ${kdvsiz.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-extrabold text-sky-700 font-mono">
                                        ${kdvli.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-800 font-mono">
                                            <i class="fa-regular fa-calendar-check mr-1 text-[10px] text-slate-500"></i>${off.miad || '-'}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-[11px] text-slate-600">
                                        ${off.not ? `<span class="italic text-slate-500">${off.not}</span>` : '<span class="text-slate-400">-</span>'}
                                    </td>
                                    <td class="py-2.5 px-3 text-right">
                                        <a href="${katilLink}" target="_blank" class="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold bg-sky-600 hover:bg-sky-700 text-white shadow-2xs transition">
                                            <i class="fa-solid fa-arrow-up-right-from-square mr-1 text-[10px]"></i>Katıl
                                        </a>
                                    </td>
                                </tr>
                            `;
                        }).join('');
                    } else {
                        tableHeaderHtml = `
                            <tr>
                                <th class="py-2.5 px-3 text-center w-20">Sıra</th>
                                <th class="py-2.5 px-3">Satıcı (Eczane / Mağaza)</th>
                                <th class="py-2.5 px-3 text-center w-24">Stok</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Hariç</th>
                                <th class="py-2.5 px-3 text-right w-28">KDV Dahil</th>
                                <th class="py-2.5 px-3 text-center w-28">Miad</th>
                                <th class="py-2.5 px-3">Kargo & Koşullar</th>
                            </tr>
                        `;
                        offersTbody = item.pazaryeri_teklifleri.map((off, oIdx) => {
                            const isCheapest = oIdx === 0;
                            const ratingTag = off.puan ? `
                                <span class="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-100 text-amber-800 ml-1.5 border border-amber-200" title="Satıcı Puanı: ${off.puan.toFixed(1)} / 10">
                                    <i class="fa-solid fa-star text-[9px] text-amber-500 mr-0.5"></i>${off.puan.toFixed(1)}
                                </span>
                            ` : '';

                            const miadDisplay = (off.miad && off.miad !== '-') ? `
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-800 font-mono">
                                    <i class="fa-regular fa-calendar-check mr-1 text-[10px] text-slate-500"></i>${off.miad}
                                </span>
                            ` : '<span class="text-slate-400 font-mono">-</span>';

                            const termsList = [];
                            if (off.min_tutar && off.min_tutar > 0) termsList.push(`Min: <strong>${off.min_tutar} ₺</strong>`);
                            if (off.ucretsiz_kargo && off.ucretsiz_kargo > 0) termsList.push(`<span class="text-emerald-700 font-semibold">${off.ucretsiz_kargo} ₺ Kargo Bedava</span>`);
                            if (off.kargo) termsList.push(`<span class="text-slate-500">${off.kargo}</span>`);
                            if (off.e_fatura) termsList.push(`<span class="text-purple-700 font-bold">e-Fatura</span>`);

                            const termsHtml = termsList.length > 0 ? termsList.join(' • ') : '<span class="text-slate-400">-</span>';
                            const noteHtml = off.aciklama ? `<div class="text-[10px] text-slate-500 italic mt-0.5 truncate max-w-sm" title="${off.aciklama}">${off.aciklama}</div>` : '';

                            return `
                                <tr class="hover:bg-white transition ${isCheapest ? 'bg-emerald-50/40' : ''}">
                                    <td class="py-2.5 px-3 text-center">
                                        ${isCheapest ? '<span class="px-1.5 py-0.5 text-[10px] font-black rounded bg-emerald-600 text-white uppercase tracking-wider">En Uygun</span>' : `<span class="text-slate-400 font-mono text-[11px]">#${oIdx + 1}</span>`}
                                    </td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-bold text-slate-900 flex items-center">
                                            <i class="fa-solid fa-shop text-[11px] text-slate-400 mr-1.5"></i>
                                            <span>${off.satici}</span>
                                            ${ratingTag}
                                        </div>
                                        ${noteHtml}
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${off.stok > 5 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
                                            ${off.stok} Kutu
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-bold text-slate-800 font-mono">
                                        ${off.fiyat_kdvsiz.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-right font-extrabold text-emerald-700 font-mono">
                                        ${off.fiyat_kdvli.toFixed(2)} ₺
                                    </td>
                                    <td class="py-2.5 px-3 text-center">
                                        ${miadDisplay}
                                    </td>
                                    <td class="py-2.5 px-3 text-[11px] text-slate-600">
                                        ${termsHtml}
                                    </td>
                                </tr>
                            `;
                        }).join('');
                    }

                    trOffers.innerHTML = `
                        <td colspan="8" class="p-3 sm:p-4">
                            <div class="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden">
                                <div class="px-4 py-3 border-b flex flex-wrap items-center justify-between gap-2 ${themeHeader}">
                                    <div class="flex items-center space-x-2 font-bold text-xs">
                                        <i class="fa-solid ${iconHeader} text-sm"></i>
                                        <span>${isEczatrend ? `Eczatrend — Ortak Alım Grubu Teklifleri & Barem Kademeleri (${item.pazaryeri_teklifleri.length} Teklif)` : isEczanetakas ? `EczaneTakas — Açık Teklifler & Satıcı Eczaneler (${item.pazaryeri_teklifleri.length} Teklif)` : `${item.depo_adi} — Tüm Satıcı Eczane Teklifleri (${item.pazaryeri_teklifleri.length} Farklı Satıcı)`}</span>
                                    </div>
                                    <div class="text-[11px] font-medium text-slate-600 flex items-center space-x-2">
                                        <span>KDV Oranı: <strong>%${item.kdv_orani}</strong></span>
                                        <span>•</span>
                                        <span>Fiyata Göre Sıralı (En Düşük &rarr; En Yüksek)</span>
                                    </div>
                                </div>
                                <div class="overflow-x-auto max-h-72 overflow-y-auto divide-y divide-slate-100">
                                    <table class="w-full text-left text-xs">
                                        <thead class="bg-slate-100/80 text-[11px] font-bold text-slate-600 sticky top-0 backdrop-blur-xs">
                                            ${tableHeaderHtml}
                                        </thead>
                                        <tbody class="divide-y divide-slate-100 font-sans">
                                            ${offersTbody}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </td>
                    `;
                    tableBody.appendChild(trOffers);
                }
            });

            // Simülatörü güncelle
            selectedDepoForSim = data.en_avantajli_depo || (data.sonuclar[0] ? data.sonuclar[0].depo : null);
            updateSimulator();

            // Tria Eczane Raf Stoğu & Aylık Satış / Çıkış Hızı Paneli
            renderTriaAnalysis(data.tria_bilgisi);

            // SGK Eşdeğer Grubu ve Muadiller Analizi (Canlı MF Kârlılık, Raf Stoğu ve Satış Hızı)
            loadEquivalentsAnalysis(
                data.barkod || data.barcode,
                (data.tria_bilgisi && data.tria_bilgisi.mal_kodu) || '',
                data.esdegerler || [],
                data.esdeger_kodu || '',
                kamuKari,
                data.en_karli_muadil,
                data.muadil_kar_avantaji
            );

            results.classList.remove('hidden');
        }

        // ================= Eczane Otomasyonu (Botanik & Tria) Analiz & Raf Stoğu Görselleştirme =================
        window.currentOtomasyonSource = 'TRIA';
        window.currentOtomasyonMovementsTab = 'cikis';

        function openCurrentOtomasyonSettings() {
            const src = (window.currentOtomasyonSource || window.activeOtomasyon || 'TRIA').toUpperCase();
            if (src === 'TEBEOS') openSettingsModal('tebeos');
            else if (src === 'TRIA') openSettingsModal('tria');
            else openSettingsModal('botanik');
        }

        function switchOtomasyonMovementsTab(tab) {
            window.currentOtomasyonMovementsTab = tab;
            const btnCikis = document.getElementById('tabBtnCikislar');
            const btnGiris = document.getElementById('tabBtnGirisler');
            const btnBoth = document.getElementById('tabBtnBoth');
            const btnMuadil = document.getElementById('tabBtnMuadiller');
            const boxCikis = document.getElementById('boxCikislarView');
            const boxGiris = document.getElementById('boxGirislerView');
            const boxMuadil = document.getElementById('boxMuadillerView');
            const legendCikis = document.getElementById('cikisLegend');
            const legendGiris = document.getElementById('girisLegend');
            const legendMuadil = document.getElementById('muadilLegend');

            const activeClass = 'px-3 py-1.5 rounded-lg text-xs font-bold bg-white/20 text-white transition flex items-center space-x-1.5 cursor-pointer shadow-xs';
            const passiveClass = 'px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-white/10 transition flex items-center space-x-1.5 cursor-pointer';

            if (btnCikis) btnCikis.className = passiveClass;
            if (btnGiris) btnGiris.className = passiveClass;
            if (btnBoth) btnBoth.className = passiveClass;
            if (btnMuadil) btnMuadil.className = passiveClass;
            if (boxCikis) boxCikis.classList.add('hidden');
            if (boxGiris) boxGiris.classList.add('hidden');
            if (boxMuadil) boxMuadil.classList.add('hidden');
            if (legendCikis) legendCikis.classList.add('hidden');
            if (legendGiris) legendGiris.classList.add('hidden');
            if (legendMuadil) legendMuadil.classList.add('hidden');

            if (tab === 'cikis') {
                if (btnCikis) btnCikis.className = activeClass;
                if (boxCikis) boxCikis.classList.remove('hidden');
                if (legendCikis) legendCikis.classList.remove('hidden');
            } else if (tab === 'giris') {
                if (btnGiris) btnGiris.className = activeClass;
                if (boxGiris) boxGiris.classList.remove('hidden');
                if (legendGiris) legendGiris.classList.remove('hidden');
            } else if (tab === 'both') {
                if (btnBoth) btnBoth.className = activeClass;
                if (boxCikis) boxCikis.classList.remove('hidden');
                if (boxGiris) boxGiris.classList.remove('hidden');
                if (legendCikis) legendCikis.classList.remove('hidden');
                if (legendGiris) legendGiris.classList.remove('hidden');
            } else if (tab === 'muadil') {
                if (btnMuadil) btnMuadil.className = activeClass;
                if (boxMuadil) boxMuadil.classList.remove('hidden');
                if (legendMuadil) legendMuadil.classList.remove('hidden');
            }
        }

        function scrollToMuadillerTab() {
            switchOtomasyonMovementsTab('muadil');
            const targetEl = document.getElementById('tabBtnMuadiller') || document.getElementById('boxMuadillerView');
            if (targetEl) {
                targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        async function loadEquivalentsAnalysis(barcode, malKodu, fallbackEquivalents, fallbackGrupKodu, currentKamuKari, directEnKarliMuadil, directMuadilAvantaji) {
            const gridEl = document.getElementById('otomasyonMuadillerGrid');
            const badgeCountEl = document.getElementById('badgeMuadilCount');
            const darkGrupEl = document.getElementById('darkEsdegerKodu');
            const topEqBtn = document.getElementById('resEquivalentsBtn');
            const topEqBtnText = document.getElementById('resEquivalentsBtnText');
            const bannerEl = document.getElementById('boxMuadilHighlightBanner');
            const muadilAlertEl = document.getElementById('resMuadilProfitOpportunity');
            const bestMuadilNameEl = document.getElementById('resBestMuadilName');
            const bestMuadilGainEl = document.getElementById('resBestMuadilGain');

            if (!gridEl) return;

            // Yükleniyor durumu
            gridEl.innerHTML = `
                <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                    <i class="fa-solid fa-spinner animate-spin mr-1.5 text-amber-400"></i>Eşdeğer ilaçlar ve canlı depo kârlılıkları taranıyor...
                </div>
            `;

            let eqData = null;
            if (fallbackEquivalents && fallbackEquivalents.length > 0) {
                const hasValidBarcodes = fallbackEquivalents.some(e => e.barkod && String(e.barkod).length >= 8 && /^\\d+$/.test(String(e.barkod)));
                const hasLiveMfChecked = fallbackEquivalents.some(e => e.live_mf_checked || (e.en_iyi_mf && e.en_iyi_mf !== 'YOK' && e.en_iyi_mf !== '-') || (e.mf && e.mf !== 'YOK' && e.mf !== '-'));
                if (hasValidBarcodes && hasLiveMfChecked) {
                    eqData = {
                        found: true,
                        esdeger_kodu: fallbackGrupKodu || 'DEPO_ESDEGER',
                        count: fallbackEquivalents.length,
                        en_karli_muadil: directEnKarliMuadil || null,
                        muadil_kar_avantaji: directMuadilAvantaji || 0.0,
                        current_kamu_kari: currentKamuKari || 0.0,
                        muadiller: fallbackEquivalents
                    };
                }
            }

            if (!eqData) {
                try {
                    const target = barcode || malKodu || '';
                    if (target) {
                        const resp = await fetch(`/api/products/equivalents?barcode=${encodeURIComponent(target)}&kod=${encodeURIComponent(malKodu || '')}`);
                        if (resp.ok) {
                            const json = await resp.json();
                            if (json && json.found && json.muadiller && json.muadiller.length > 0) {
                                eqData = json;
                            }
                        }
                    }
                } catch (e) {
                    console.warn('[Muadiller] Otomasyon eşdeğer sorgulama hatası:', e);
                }
            }

            if (!eqData && fallbackEquivalents && fallbackEquivalents.length > 0) {
                eqData = {
                    found: true,
                    esdeger_kodu: fallbackGrupKodu || 'DEPO_ESDEGER',
                    count: fallbackEquivalents.length,
                    en_karli_muadil: directEnKarliMuadil || null,
                    muadil_kar_avantaji: directMuadilAvantaji || 0.0,
                    current_kamu_kari: currentKamuKari || 0.0,
                    muadiller: fallbackEquivalents
                };
            }

            if (eqData && eqData.muadiller && typeof currentReport === 'object' && currentReport) {
                currentReport.esdegerler = eqData.muadiller;
                if (eqData.esdeger_kodu) currentReport.esdeger_kodu = eqData.esdeger_kodu;
                if (eqData.en_karli_muadil) currentReport.en_karli_muadil = eqData.en_karli_muadil;
                if (eqData.muadil_kar_avantaji !== undefined) currentReport.muadil_kar_avantaji = eqData.muadil_kar_avantaji;
            }


            if (!eqData || !eqData.muadiller || eqData.muadiller.length === 0) {
                if (badgeCountEl) badgeCountEl.innerText = '0';
                if (darkGrupEl) darkGrupEl.innerText = fallbackGrupKodu || 'Yok';
                if (bannerEl) { bannerEl.innerHTML = ''; bannerEl.classList.add('hidden'); }
                if (muadilAlertEl) { muadilAlertEl.classList.remove('inline-flex'); muadilAlertEl.classList.add('hidden'); }
                gridEl.innerHTML = `
                    <div class="bg-white/5 border border-white/10 rounded-xl p-5 text-center col-span-full text-xs text-slate-400">
                        <i class="fa-solid fa-circle-info text-amber-400 mr-1.5"></i>
                        Bu ilacın kayıtlı bir SGK eşdeğer grubu veya canlı muadili bulunamadı.
                    </div>
                `;
                return;
            }

            // Eşdeğerler var!
            const muadiller = eqData.muadiller;
            const count = muadiller.length;
            if (badgeCountEl) badgeCountEl.innerText = count;
            if (darkGrupEl) darkGrupEl.innerText = eqData.esdeger_kodu || 'SGK Grubu';
            if (topEqBtn && topEqBtnText) {
                topEqBtn.classList.remove('hidden');
                topEqBtn.classList.add('inline-flex');
                topEqBtnText.innerText = `Muadiller (${count})`;
            }

            const bestM = eqData.en_karli_muadil || directEnKarliMuadil;
            const bestGain = (eqData.muadil_kar_avantaji !== undefined && eqData.muadil_kar_avantaji !== null) ? eqData.muadil_kar_avantaji : (directMuadilAvantaji || 0);

            // 1. Üst Arama Sonucu Bildirim Rozeti (#resMuadilProfitOpportunity)
            if (bestM && bestGain > 0) {
                if (bestMuadilNameEl) bestMuadilNameEl.innerText = bestM.urun_adi || bestM.ad || 'Muadil İlaç';
                if (bestMuadilGainEl) bestMuadilGainEl.innerText = `+${bestGain.toFixed(2)} ₺`;
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('hidden');
                    muadilAlertEl.classList.add('inline-flex');
                }
            } else {
                if (muadilAlertEl) {
                    muadilAlertEl.classList.remove('inline-flex');
                    muadilAlertEl.classList.add('hidden');
                }
            }

            // 2. Muadiller Sekmesi İçi En Kârlı İlaç Vurgu Bannerı (#boxMuadilHighlightBanner)
            if (bannerEl) {
                if (bestM && bestGain > 0) {
                    const mName = bestM.urun_adi || bestM.ad || '';
                    const mSafeName = mName.replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
                    const mCode = bestM.barkod || bestM.kod || bestM.mal_kodu || '';
                    const mLiveMf = (bestM.en_iyi_mf && bestM.en_iyi_mf !== 'YOK' && bestM.en_iyi_mf !== '-') ? bestM.en_iyi_mf : ((bestM.mf && bestM.mf !== 'YOK' && bestM.mf !== '-') ? bestM.mf : 'Barem Yok');
                    const mCostKdvli = bestM.net_birim_maliyet_kdvli || bestM.birim_maliyet_kdvli || 0;
                    const mKamuKari = bestM.kamu_kari || 0;
                    const mYuzde = bestM.kar_artis_yuzdesi || 0;

                    bannerEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-gradient-to-r from-amber-950/70 via-emerald-950/70 to-slate-900 border-2 border-amber-400/80 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4">
                            <div class="flex items-center space-x-4">
                                <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center text-2xl shadow-lg shadow-amber-500/30 shrink-0 font-black">
                                    <i class="fa-solid fa-trophy"></i>
                                </div>
                                <div>
                                    <div class="text-[11px] uppercase tracking-wider font-extrabold text-amber-300 flex items-center gap-2 flex-wrap">
                                        <span>🏆 EN KÂRLI ANLIK SGK EŞDEĞERİ</span>
                                        ${mYuzde > 0 ? `<span class="px-2 py-0.5 rounded-full text-[10px] bg-amber-400 text-slate-950 font-black">%${mYuzde} DAHA KÂRLI</span>` : ''}
                                    </div>
                                    <div class="text-base font-black text-white mt-0.5">
                                        ${mName}
                                    </div>
                                    <div class="text-xs text-slate-300 mt-1 flex flex-wrap items-center gap-2 font-medium">
                                        <span class="text-amber-300 font-bold"><i class="fa-solid fa-fire mr-1"></i>Anlık Depo MF: ${mLiveMf} ${bestM.depo ? `(${bestM.depo})` : ''}</span>
                                        <span class="text-slate-500">•</span>
                                        <span>Birim Alış: <strong class="text-white font-mono">${mCostKdvli.toFixed(2)} ₺</strong> (KDV Dahil)</span>
                                        <span class="text-slate-500">•</span>
                                        <span>SGK Reçete Kârı: <strong class="text-emerald-400 font-bold">+${mKamuKari.toFixed(2)} ₺</strong></span>
                                    </div>
                                </div>
                            </div>
                            <div class="flex flex-col sm:flex-row items-center gap-2.5 shrink-0 w-full md:w-auto">
                                <div class="px-3.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-black text-center sm:text-right w-full sm:w-auto">
                                    <div class="text-[10px] uppercase text-emerald-400 font-medium">Kutu Başı Kâr Avantajı</div>
                                    <div class="text-base font-extrabold text-emerald-300">+${bestGain.toFixed(2)} ₺</div>
                                </div>
                                <button type="button" onclick="selectAndSearch('${mCode}', '${mSafeName}')" class="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs transition shadow-lg shadow-amber-500/20 cursor-pointer flex items-center justify-center space-x-2">
                                    <i class="fa-solid fa-arrows-split-up-and-left"></i>
                                    <span>Bu Kârlı Muadili Karşılaştır</span>
                                </button>
                            </div>
                        </div>
                    `;
                    bannerEl.classList.remove('hidden');
                } else {
                    bannerEl.innerHTML = '';
                    bannerEl.classList.add('hidden');
                }
            }

            // 3. Muadil Kartlarını Kârlılık Sırasıyla Render Et
            gridEl.innerHTML = muadiller.map(item => {
                const isCur = !!item.is_current;
                const isBestDeal = !!item.is_best_deal;
                const mName = item.urun_adi || item.ad || '';
                const safeName = mName.replace(/'/g, "\\\\'").replace(/"/g, '&quot;');
                const searchCode = item.barkod || item.kod || item.mal_kodu || '';
                
                const psf = item.psf || item.etiket_fiyati || 0;
                const ksf = item.ksf || item.kamu_fiyati || (psf > 0 ? (psf * (1.0 - ((item.kamu_iskontosu || 0) / 100.0))) : 0);
                const netKdvsiz = item.net_birim_maliyet || item.birim_maliyet || 0;
                const netKdvli = item.net_birim_maliyet_kdvli || item.birim_maliyet_kdvli || 0;
                const kamuKari = (item.kamu_kari !== undefined && item.kamu_kari !== null) ? item.kamu_kari : (ksf > 0 && netKdvli > 0 ? (ksf - netKdvli) : 0);
                const perakendeKari = (item.perakende_kari !== undefined && item.perakende_kari !== null) ? item.perakende_kari : (psf > 0 && netKdvli > 0 ? (psf - netKdvli) : 0);
                const karFarki = item.kar_farki || 0;
                const karArtis = item.kar_artis_yuzdesi || 0;

                let cardBorder = 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10';
                if (isBestDeal) {
                    cardBorder = 'border-2 border-amber-400/80 bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-900 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400/40';
                } else if (isCur) {
                    cardBorder = 'border-indigo-400/60 bg-indigo-950/30 ring-1 ring-indigo-500/30';
                } else if (karFarki > 0) {
                    cardBorder = 'border-emerald-500/40 bg-emerald-950/20 hover:border-emerald-500/60';
                }

                // Stok rozeti
                const stockColor = item.stok > 0 ? 'text-emerald-400' : 'text-amber-400';
                const stockBadge = item.stok > 0 
                    ? `<span class="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">${item.stok} Kutu Stok</span>`
                    : `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">Stok Yok</span>`;

                // Canlı MF Alanı
                const rawBestMf = (item.en_iyi_mf && item.en_iyi_mf !== '-' && item.en_iyi_mf !== 'YOK') ? item.en_iyi_mf : null;
                const rawFullMf = (item.mf && item.mf !== '-' && item.mf !== 'YOK') ? item.mf : null;
                const liveMf = rawBestMf || rawFullMf;
                let mfSectionHtml = '';
                if (liveMf) {
                    const kademeler = item.kademeler || [];
                    mfSectionHtml = `
                        <div class="mt-2.5 p-2 rounded-xl bg-amber-500/15 border border-amber-400/30">
                            <div class="flex items-center justify-between text-xs gap-1">
                                <div class="flex items-center space-x-1.5 min-w-0">
                                    <i class="fa-solid fa-fire text-amber-400 animate-pulse shrink-0"></i>
                                    <span class="text-slate-300 font-medium shrink-0">Anlık Canlı MF:</span>
                                    <strong class="text-amber-300 font-black text-sm font-mono truncate" title="${rawFullMf || liveMf}">${rawFullMf || liveMf}</strong>
                                </div>
                                <span class="text-[10px] font-bold text-amber-200/90 bg-black/30 px-1.5 py-0.5 rounded uppercase tracking-wider shrink-0">${item.depo || 'Canlı Depo'}</span>
                            </div>
                            ${kademeler.length > 0 ? `
                                <div class="flex flex-wrap gap-1 mt-1.5 pt-1.5 border-t border-amber-400/20">
                                    ${kademeler.map(k => {
                                        const kNet = k.net_birim_maliyet || k.birim_maliyet || 0;
                                        const kKdvli = k.net_birim_maliyet_kdvli || k.birim_maliyet_kdvli || 0;
                                        return `
                                            <span class="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-black/40 text-amber-200 border border-amber-400/20" title="KDV Hariç: ${kNet.toFixed(2)} ₺ | KDV Dahil: ${kKdvli.toFixed(2)} ₺">
                                                ${k.mf_text} (${kKdvli.toFixed(1)} ₺)
                                            </span>
                                        `;
                                    }).join('')}
                                </div>
                            ` : ''}
                        </div>
                    `;
                } else if (item.gecmis_mf_var && (item.gecmis_mf_kisa || item.gecmis_mf_bilgi)) {
                    mfSectionHtml = `
                        <div class="mt-2.5 p-1.5 rounded-lg bg-indigo-500/15 border border-indigo-400/30 text-center text-[11px] text-indigo-200 flex items-center justify-center space-x-1.5" title="${item.gecmis_mf_bilgi || ''}">
                            <i class="fa-solid fa-clock-rotate-left text-indigo-400"></i>
                            <span>Anlık MF Yok • <strong>Son Fatura: ${item.gecmis_mf_kisa ? item.gecmis_mf_kisa + ' MF' : item.gecmis_mf_bilgi}</strong></span>
                        </div>
                    `;
                } else {
                    mfSectionHtml = `
                        <div class="mt-2.5 p-1.5 rounded-lg bg-white/5 border border-white/10 text-center text-[11px] text-slate-400 flex items-center justify-center space-x-1">
                            <i class="fa-regular fa-circle-xmark text-slate-500"></i>
                            <span>Anlık MF Yok (Tekli Alım Fiyatı)</span>
                        </div>
                    `;
                }

                // Kâr Farkı Bannerı
                let profitDiffBanner = '';
                if (isBestDeal || karFarki > 0) {
                    profitDiffBanner = `
                        <div class="mt-2.5 px-2.5 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 text-xs font-bold flex items-center justify-between shadow-2xs">
                            <div class="flex items-center space-x-1.5">
                                <i class="fa-solid fa-arrow-trend-up text-emerald-400"></i>
                                <span>Kutu Başı Kâr Avantajı:</span>
                            </div>
                            <span class="text-emerald-300 font-black font-mono text-sm">+${karFarki.toFixed(2)} ₺ ${karArtis > 0 ? `(%${karArtis})` : ''}</span>
                        </div>
                    `;
                } else if (isCur) {
                    profitDiffBanner = `
                        <div class="mt-2.5 px-2 py-1 rounded-lg bg-indigo-500/15 border border-indigo-400/20 text-indigo-300 text-[11px] font-medium text-center">
                            <i class="fa-solid fa-circle-dot text-indigo-400 mr-1"></i>Şu an sorgulanan baz ilaç
                        </div>
                    `;
                }

                return `
                    <div class="rounded-2xl p-4 border ${cardBorder} flex flex-col justify-between transition relative">
                        <div>
                            <!-- Üst Rozetler (En Kârlı / Aranan) -->
                            <div class="flex items-center justify-between gap-2 mb-2">
                                <div class="flex items-center space-x-1.5 flex-wrap">
                                    ${isBestDeal ? `
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 uppercase tracking-wider shadow-sm">
                                            <i class="fa-solid fa-trophy mr-1 text-[10px]"></i>EN KÂRLI MUADİL
                                        </span>
                                    ` : ''}
                                    ${isCur ? `
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-indigo-500 text-white uppercase tracking-wider">
                                            Aranan İlaç
                                        </span>
                                    ` : ''}
                                    ${(!isBestDeal && karFarki > 0) ? `
                                        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/30 text-emerald-300 border border-emerald-500/40">
                                            +${karFarki.toFixed(2)} ₺ Daha Kârlı
                                        </span>
                                    ` : ''}
                                </div>
                                <div class="shrink-0">
                                    ${stockBadge}
                                </div>
                            </div>

                            <!-- İlaç Adı ve Fiyatları -->
                            <div class="min-w-0">
                                <h4 class="text-sm font-black text-white leading-snug line-clamp-2" title="${mName}">
                                    ${mName}
                                </h4>
                                <div class="text-[11px] text-slate-400 font-mono mt-1 flex flex-wrap items-center gap-1.5">
                                    <span>${searchCode}</span>
                                    ${psf > 0 ? `<span class="text-slate-500">•</span><span class="text-slate-300">PSF: <strong>${psf.toFixed(2)} ₺</strong></span>` : ''}
                                    ${ksf > 0 ? `<span class="text-slate-500">•</span><span class="text-indigo-300">KSF: <strong>${ksf.toFixed(2)} ₺</strong></span>` : ''}
                                </div>
                            </div>

                            <!-- Canlı MF Bilgisi -->
                            ${mfSectionHtml}

                            <!-- 3 Sütun Kârlılık ve Birim Maliyet Tablosu -->
                            <div class="grid grid-cols-3 gap-1.5 mt-3 pt-2 border-t border-white/10 text-center">
                                <div class="bg-black/30 rounded-xl p-2 flex flex-col justify-between">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider leading-tight">Net Kutu Alış</div>
                                    <div class="text-xs font-black text-white font-mono mt-1">${netKdvli.toFixed(2)} ₺</div>
                                    <div class="text-[8px] text-slate-500 mt-0.5">KDV Dahil</div>
                                </div>
                                <div class="bg-black/30 rounded-xl p-2 flex flex-col justify-between border ${kamuKari >= 0 ? 'border-blue-500/20' : 'border-red-500/30'}">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider leading-tight">SGK Reçete Kârı</div>
                                    <div class="text-xs font-black ${kamuKari >= 0 ? 'text-blue-400' : 'text-red-400'} font-mono mt-1">
                                        ${kamuKari >= 0 ? '+' : ''}${kamuKari.toFixed(2)} ₺
                                    </div>
                                    <div class="text-[8px] text-slate-500 mt-0.5">KSF - Alış</div>
                                </div>
                                <div class="bg-black/30 rounded-xl p-2 flex flex-col justify-between border border-emerald-500/20">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider leading-tight">Elden Satış Kârı</div>
                                    <div class="text-xs font-black text-emerald-400 font-mono mt-1">
                                        ${perakendeKari >= 0 ? '+' : ''}${perakendeKari.toFixed(2)} ₺
                                    </div>
                                    <div class="text-[8px] text-slate-500 mt-0.5">PSF - Alış</div>
                                </div>
                            </div>

                            <!-- Kâr Farkı Avantaj Rozeti -->
                            ${profitDiffBanner}

                            <!-- 30 Günlük Çıkış & Raf Stoğu Metrikleri -->
                            <div class="grid grid-cols-2 gap-2 mt-2.5 pt-2 border-t border-white/10 text-center">
                                <div class="bg-black/20 rounded-lg p-1.5">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider">Raf Stoğu</div>
                                    <div class="text-xs font-black ${stockColor} mt-0.5">${item.stok} Kutu</div>
                                </div>
                                <div class="bg-black/20 rounded-lg p-1.5">
                                    <div class="text-[9px] text-slate-400 uppercase tracking-wider">30 Gün Satış</div>
                                    <div class="text-xs font-black text-cyan-300 mt-0.5">${item.cikis_30gun} Kutu</div>
                                </div>
                            </div>

                            <!-- Geçmiş MF Göstergesi (varsa) -->
                            ${item.gecmis_mf_var ? `
                                <div class="mt-2 text-[10px] text-amber-300/80 flex items-center space-x-1">
                                    <i class="fa-solid fa-clock-rotate-left text-amber-400"></i>
                                    <span>Eczane Geçmiş Alım MF: <strong>${item.gecmis_mf_bilgi}</strong></span>
                                </div>
                            ` : ''}
                        </div>

                        <!-- Karşılaştırma Butonu -->
                        <div class="mt-3.5 pt-2.5 border-t border-white/10">
                            <button type="button" onclick="selectAndSearch('${searchCode}', '${safeName}')" class="w-full py-2 px-3 rounded-xl text-xs font-black ${isBestDeal ? 'bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-md shadow-amber-500/20' : 'bg-indigo-600/90 hover:bg-indigo-600 text-white shadow-sm'} transition flex items-center justify-center space-x-1.5 cursor-pointer">
                                <i class="fa-solid ${isBestDeal ? 'fa-crown' : 'fa-arrows-split-up-and-left'} text-[11px]"></i>
                                <span>${isBestDeal ? 'Bu Kârlı Muadili Karşılaştır' : 'Tüm Depolarda Karşılaştır'}</span>
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        function renderTriaAnalysis(tria) {
            const stockQtyEl = document.getElementById('triaStockQty');
            const statusBadgeEl = document.getElementById('triaStockStatusBadge');
            const gridEl = document.getElementById('triaMonthlyGrid');
            const girisGridEl = document.getElementById('otomasyonGirislerGrid');
            const girisBadgeEl = document.getElementById('badgeGirisCount');
            const avgMonthlyEl = document.getElementById('triaAvgMonthly');
            const avgDailyEl = document.getElementById('triaAvgDaily');
            const daysLeftEl = document.getElementById('triaDaysLeft');
            const suggestedEl = document.getElementById('triaOrderSuggested');
            const brandBadgeEl = document.getElementById('otoBrandBadge');
            const brandTextEl = document.getElementById('otoBrandText');
            const hostSubBadgeEl = document.getElementById('triaHostSubBadge');

            if (!tria || !tria.found) {
                stockQtyEl.innerText = '--';
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-slate-700 text-slate-300';
                statusBadgeEl.innerText = (!tria || !tria.connected) ? 'BAĞLANTI YOK' : 'STOK KAYDI BULUNAMADI';
                avgMonthlyEl.innerText = '--';
                avgDailyEl.innerText = '-- / Gün';
                daysLeftEl.innerText = '--';
                suggestedEl.innerText = '--';
                if (girisBadgeEl) girisBadgeEl.innerText = '0';
                gridEl.innerHTML = `
                    <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                        <i class="fa-solid fa-circle-info mr-1.5 text-amber-400"></i>
                        ${tria && tria.message ? tria.message : 'Bu ilaç eczane otomasyonunda bulunamadı veya henüz satış/stok hareketi oluşmamış.'}
                    </div>
                `;
                if (girisGridEl) {
                    girisGridEl.innerHTML = `
                        <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                            Depo alış faturaları bulunamadı.
                        </div>
                    `;
                }
                return;
            }

            // 0. Otomasyon Kaynağı ve Başlık Rozeti (Botanik vs Tria vs Tebeos)
            window.currentOtomasyonSource = tria.kaynak || 'BOTANIK';
            if (tria.kaynak === 'TEBEOS') {
                if (brandBadgeEl) brandBadgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-sky-500/20 text-sky-300 border border-sky-400/30';
                if (brandTextEl) brandTextEl.innerText = 'TEBEOS ECZANE OTOMASYONU • CANLI ENTEGRASYON';
                if (hostSubBadgeEl) hostSubBadgeEl.innerText = `PostgreSQL 5454 (${tria.mal_adi ? tria.mal_adi.substring(0, 24) : 'Bağlı'})`;
            } else if (tria.kaynak === 'BOTANIK') {
                if (brandBadgeEl) brandBadgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/30';
                if (brandTextEl) brandTextEl.innerText = 'BOTANİK ECZANE OTOMASYONU • CANLI ENTEGRASYON';
                if (hostSubBadgeEl) hostSubBadgeEl.innerText = `MS SQL Server (${tria.mal_adi ? tria.mal_adi.substring(0, 24) : 'Bağlı'})`;
            } else {
                if (brandBadgeEl) brandBadgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-500/20 text-amber-300 border border-amber-400/30';
                if (brandTextEl) brandTextEl.innerText = 'TRIA ECZANE OTOMASYONU • CANLI ENTEGRASYON';
                if (hostSubBadgeEl) hostSubBadgeEl.innerText = (tria.mal_kodu ? `TRIA Kod: ${tria.mal_kodu}` : 'Oracle ORCL');
            }

            // 1. Raf Stoğu
            stockQtyEl.innerText = tria.stok;

            // Durum Rozeti
            if (tria.hareketsiz_kart) {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-slate-500/25 text-slate-300 border border-slate-500/40';
                statusBadgeEl.innerText = 'HAREKET YOK';
                daysLeftEl.innerText = '-';
                avgMonthlyEl.innerText = '0 Kutu';
                avgDailyEl.innerText = '~0 / Gün';
                suggestedEl.innerText = '1 Kutu (Öneri)';
            } else if (tria.stok <= 0) {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-rose-500/25 text-rose-300 border border-rose-500/40';
                statusBadgeEl.innerText = 'TÜKENDİ';
            } else if (tria.kalan_gun < 10) {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-amber-500/25 text-amber-300 border border-amber-500/40';
                statusBadgeEl.innerText = 'KRİTİK AZ';
            } else if (tria.kalan_gun <= 30) {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-emerald-500/25 text-emerald-300 border border-emerald-500/40';
                statusBadgeEl.innerText = 'YETERLİ';
            } else {
                statusBadgeEl.className = 'ml-1.5 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-sky-500/25 text-sky-300 border border-sky-500/40';
                statusBadgeEl.innerText = 'YÜKSEK STOK';
            }

            // 2. Metrikler
            if (!tria.hareketsiz_kart) {
                avgMonthlyEl.innerText = `${tria.ort_aylik_cikis} Kutu`;
                avgDailyEl.innerText = `~${tria.ort_gunluk_cikis} / Gün`;
                
                if (tria.stok <= 0) {
                    daysLeftEl.innerText = '0 Gün';
                } else if (tria.kalan_gun >= 90) {
                    daysLeftEl.innerText = '> 90 Gün';
                } else {
                    daysLeftEl.innerText = `~${tria.kalan_gun} Gün`;
                }

                suggestedEl.innerText = `${tria.onerilen_siparis} Kutu`;
            }

            // Otomatik olarak simülatör sipariş miktarını önerilen değere ayarla
            if (tria.onerilen_siparis > 0) {
                simQtyInput.value = tria.onerilen_siparis;
                updateSimulator();
            } else if (tria.hareketsiz_kart) {
                simQtyInput.value = 1;
                updateSimulator();
            }

            // 3. ÇIKIŞLAR: Aylık Satış Kartları Grid (6 Takvim Ayı: Nakit vs Reçeteli)
            const cikislar = tria.aylik_cikislar || [];
            if (cikislar.length === 0) {
                gridEl.innerHTML = `
                    <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                        Son 6 ayda herhangi bir çıkış hareketi bulunamadı.
                    </div>
                `;
            } else {
                gridEl.innerHTML = cikislar.map(m => {
                    const nakitPct = m.toplam > 0 ? Math.round((m.nakit / m.toplam) * 100) : 0;
                    const recetePct = m.toplam > 0 ? (100 - nakitPct) : 0;

                    return `
                        <div class="bg-white/5 hover:bg-white/10 border ${m.is_current ? 'border-amber-400/50 bg-amber-500/5' : 'border-white/10'} rounded-xl p-3 flex flex-col justify-between transition group">
                            <div class="flex items-center justify-between text-[11px] mb-2">
                                <span class="font-bold ${m.is_current ? 'text-amber-300 font-extrabold' : 'text-slate-300'} group-hover:text-white truncate" title="${m.label}">
                                    ${m.label}
                                </span>
                                <span class="font-black text-emerald-400 text-xs shrink-0 ml-1">
                                    ${m.toplam} <span class="text-[9px] font-normal text-slate-400">Kt</span>
                                </span>
                            </div>
                            
                            <!-- Orantılı Çıkış Barı: Nakit (Yeşil) vs SGK Reçete (Mavi) -->
                            <div class="my-1.5">
                                <div class="w-full bg-white/10 rounded-full h-2 flex overflow-hidden">
                                    <div style="width: ${nakitPct}%" class="bg-emerald-400 h-full transition-all duration-500" title="Nakit / Elden: ${m.nakit} kutu (%${nakitPct})"></div>
                                    <div style="width: ${recetePct}%" class="bg-blue-400 h-full transition-all duration-500" title="SGK / Reçete: ${m.receteli} kutu (%${recetePct})"></div>
                                </div>
                            </div>

                            <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1.5 border-t border-white/5">
                                <span class="text-emerald-300 font-semibold" title="Nakit / Elden Satış">
                                    <i class="fa-solid fa-coins mr-0.5 text-[8px]"></i>${m.nakit}
                                </span>
                                <span class="text-blue-300 font-semibold" title="SGK Reçeteli Çıkış">
                                    <i class="fa-solid fa-file-prescription mr-0.5 text-[8px]"></i>${m.receteli}
                                </span>
                            </div>
                        </div>
                    `;
                }).join('');
            }

            // 4. GİRİŞLER: Son Depo Alış Faturaları Kartları Grid
            const girisler = tria.son_girisler || [];
            if (girisBadgeEl) girisBadgeEl.innerText = girisler.length;

            if (girisGridEl) {
                if (girisler.length === 0) {
                    girisGridEl.innerHTML = `
                        <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-center col-span-full text-xs text-slate-400">
                            <i class="fa-solid fa-circle-info mr-1.5 text-cyan-400"></i>
                            Bu ilaca ait son 6 ayda sisteme girilmiş kayıtlı depo faturası bulunamadı.
                        </div>
                    `;
                } else {
                    girisGridEl.innerHTML = girisler.map(g => {
                        const depoUpper = (g.depo || '').toUpperCase();
                        let badgeColor = 'bg-slate-700 text-slate-200 border-slate-600';
                        let depoIcon = 'fa-solid fa-truck-ramp-box';

                        if (depoUpper.includes('ISKOOP') || depoUpper.includes('İSKOOP')) {
                            badgeColor = 'bg-rose-500/20 text-rose-300 border-rose-500/30';
                            depoIcon = 'fa-solid fa-building text-rose-400';
                        } else if (depoUpper.includes('HEDEF') || depoUpper.includes('ALLIANCE')) {
                            badgeColor = 'bg-sky-500/20 text-sky-300 border-sky-500/30';
                            depoIcon = 'fa-solid fa-truck-medical text-sky-400';
                        } else if (depoUpper.includes('SELCUK') || depoUpper.includes('SELÇUK')) {
                            badgeColor = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
                            depoIcon = 'fa-solid fa-building-columns text-emerald-400';
                        } else if (depoUpper.includes('NEVZAT')) {
                            badgeColor = 'bg-amber-500/20 text-amber-300 border-amber-500/30';
                            depoIcon = 'fa-solid fa-truck text-amber-400';
                        } else if (depoUpper.includes('DNA')) {
                            badgeColor = 'bg-purple-500/20 text-purple-300 border-purple-500/30';
                            depoIcon = 'fa-solid fa-boxes-packing text-purple-400';
                        }

                        const mfBadge = g.mf > 0 ? `<span class="ml-1 px-1.5 py-0.2 rounded text-[10px] font-black bg-amber-500/30 text-amber-200 border border-amber-400/30">+${g.mf} MF</span>` : '';

                        return `
                            <div class="bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-3 flex flex-col justify-between transition group">
                                <div class="flex items-center justify-between text-[11px] mb-2 pb-1.5 border-b border-white/5">
                                    <span class="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold border ${badgeColor}">
                                        <i class="${depoIcon} mr-1"></i>
                                        <span>${g.depo}</span>
                                    </span>
                                    <span class="text-slate-400 font-mono text-[10px] flex items-center">
                                        <i class="fa-regular fa-calendar mr-1"></i>${g.tarih}
                                    </span>
                                </div>

                                <div class="flex items-center justify-between my-1">
                                    <div>
                                        <div class="text-[10px] text-slate-400">Gelen Miktar</div>
                                        <div class="text-sm font-black text-white flex items-center">
                                            <span>${g.adet} Kutu</span>
                                            ${mfBadge}
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <div class="text-[10px] text-slate-400">Birim Net Maliyet</div>
                                        <div class="text-sm font-black text-emerald-400 font-mono">
                                            ${g.maliyet.toFixed(2)} ₺
                                        </div>
                                    </div>
                                </div>

                                <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1.5 border-t border-white/5 mt-1 font-mono">
                                    <span class="truncate max-w-[150px]" title="Fatura No: ${g.fatura_no || '-'}">Fat: ${g.fatura_no || '-'}</span>
                                    <span class="text-cyan-300 font-bold">Toplam: ${g.toplam_adet} Kutu</span>
                                </div>
                            </div>
                        `;
                    }).join('');
                }
            }
        }

        function setSuggestedQty() {
            const oto = currentReport ? (currentReport.otomasyon_bilgisi || currentReport.botanik_bilgisi || currentReport.tria_bilgisi) : null;
            if (!oto) {
                showToast('Bilgi', 'Öneri için otomasyon verisi bulunamadı.', 'error');
                return;
            }
            const qty = oto.onerilen_siparis > 0 ? oto.onerilen_siparis : Math.max(1, Math.round(oto.ort_aylik_cikis || 10));
            setSimulatorQty(qty);
            showToast('Önerilen Miktar Seçildi', `30 günlük güvenlik ihtiyacınıza göre ${qty} kutu sipariş miktarı belirlendi.`, 'success');
        }

        function toggleMfDetails() {
            const box = document.getElementById('simResultsBox');
            const icon = document.getElementById('mfToggleIcon');
            if (!box || !icon) return;
            if (box.classList.contains('hidden')) {
                box.classList.remove('hidden');
                icon.className = 'fa-solid fa-circle-chevron-up mr-1';
            } else {
                box.classList.add('hidden');
                icon.className = 'fa-solid fa-circle-chevron-down mr-1';
            }
        }

        async function openEsdegerModal() {
            if (!currentReport) return;
            const modal = document.getElementById('esdegerModal');
            const list = document.getElementById('modalEsdegerList');
            const countEl = document.getElementById('modalEsdegerCount');
            const kodEl = document.getElementById('modalEsdegerKodu');

            modal.classList.remove('hidden');
            kodEl.innerText = currentReport.esdeger_kodu ? `SGK Kodu: ${currentReport.esdeger_kodu}` : 'SGK Eşdeğer Grubu';

            let eqList = currentReport.esdegerler || [];
            const needsLiveRefresh = eqList.length === 0 || !eqList.some(e => e.live_mf_checked);

            function renderModalItems(items) {
                countEl.innerText = items.length;
                list.innerHTML = '';
                if (items.length === 0) {
                    list.innerHTML = `
                        <div class="p-8 text-center text-slate-400 text-xs bg-white rounded-2xl border border-dashed border-slate-200">
                            <i class="fa-solid fa-circle-exclamation text-2xl text-slate-300 mb-2 block"></i>
                            Bu ilaç için SGK eşdeğer grubunda kayıtlı muadil ilaç bulunamadı.
                        </div>
                    `;
                    return;
                }
                items.forEach(eq => {
                    const div = document.createElement('div');
                    const isBest = !!eq.is_best_deal;
                    const karFarki = eq.kar_farki || 0;
                    let borderCls = 'bg-white border-slate-200 hover:border-indigo-400 hover:shadow-xs';
                    if (isBest) borderCls = 'bg-amber-50/70 border-2 border-amber-400 shadow-sm';
                    else if (eq.is_current) borderCls = 'bg-indigo-50/60 border-indigo-300';
                    else if (karFarki > 0) borderCls = 'bg-emerald-50/40 border-emerald-300';

                    div.className = `p-4 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${borderCls}`;

                    const isSameTag = eq.is_current ? `<span class="px-2 py-0.5 bg-indigo-600 text-white text-[10px] font-bold rounded">Aranan İlaç</span>` : '';
                    const bestTag = isBest ? `<span class="px-2 py-0.5 bg-amber-500 text-slate-950 text-[10px] font-black rounded"><i class="fa-solid fa-trophy mr-1"></i>EN KÂRLI MUADİL</span>` : '';
                    const profitTag = (!eq.is_current && karFarki > 0) ? `<span class="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded">+${karFarki.toFixed(2)} ₺ Kâr Avantajı</span>` : '';

                    const mName = eq.ad || eq.urun_adi || '';
                    const safeName = mName.replace(/'/g, "\\\\'");
                    const psfVal = eq.psf || eq.etiket_fiyati || 0;
                    const ksfVal = eq.ksf || eq.kamu_fiyati || (psfVal > 0 ? psfVal * (1 - ((eq.kamu_iskontosu || 0) / 100.0)) : 0);
                    const netKdvli = eq.net_birim_maliyet_kdvli || eq.birim_maliyet_kdvli || 0;
                    const kamuKari = (eq.kamu_kari !== undefined && eq.kamu_kari !== null) ? eq.kamu_kari : (ksfVal > 0 && netKdvli > 0 ? (ksfVal - netKdvli) : 0);
                    const eldenKari = (eq.perakende_kari !== undefined && eq.perakende_kari !== null) ? eq.perakende_kari : (psfVal > 0 && netKdvli > 0 ? (psfVal - netKdvli) : 0);

                    const rawFullMf = (eq.mf && eq.mf !== 'YOK' && eq.mf !== '-') ? eq.mf : ((eq.en_iyi_mf && eq.en_iyi_mf !== 'YOK' && eq.en_iyi_mf !== '-') ? eq.en_iyi_mf : null);
                    const kademeler = eq.kademeler || [];
                    const mfBadgeHtml = rawFullMf
                        ? `<span class="inline-flex items-center px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 font-black text-[11px]"><i class="fa-solid fa-fire text-amber-600 mr-1"></i>Canlı MF: ${rawFullMf} ${eq.depo ? `(${eq.depo})` : ''}</span>`
                        : (eq.gecmis_mf_var && eq.gecmis_mf_kisa ? `<span class="inline-flex items-center px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 border border-indigo-200 font-bold text-[11px]">Son Fatura MF: ${eq.gecmis_mf_kisa}</span>` : `<span class="text-slate-400">MF: YOK</span>`);

                    const kademelerHtml = kademeler.length > 0 ? `
                        <div class="flex flex-wrap gap-1.5 mt-1.5">
                            ${kademeler.map(k => {
                                const kKdvli = k.net_birim_maliyet_kdvli || k.birim_maliyet_kdvli || 0;
                                return `<span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-50 text-amber-900 border border-amber-300">${k.mf_text} → ${kKdvli.toFixed(2)} ₺ (KDV Dahil)</span>`;
                            }).join('')}
                        </div>
                    ` : '';

                    div.innerHTML = `
                        <div class="flex items-start space-x-3">
                            <div class="w-9 h-9 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center text-sm font-bold shrink-0 mt-0.5">
                                <i class="fa-solid fa-pills"></i>
                            </div>
                            <div>
                                <div class="flex flex-wrap items-center gap-1.5">
                                    <span class="text-sm font-bold text-slate-900">${mName}</span>
                                    ${bestTag}
                                    ${isSameTag}
                                    ${profitTag}
                                </div>
                                <div class="text-[11px] text-slate-500 mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1">
                                    <span>Barkod: <strong class="font-mono text-slate-700">${eq.barkod || eq.kod}</strong></span>
                                    <span>•</span>
                                    <span>Raf Stoğu: <strong class="${eq.stok > 0 ? 'text-emerald-600 font-bold' : 'text-slate-500'}">${eq.stok || 0} Kutu</strong></span>
                                    <span>•</span>
                                    <span>30 Gün Satış: <strong class="text-cyan-700 font-bold">${eq.cikis_30gun || 0} Kutu</strong></span>
                                    <span>•</span>
                                    <span>PSF: <strong class="text-slate-800">${psfVal > 0 ? psfVal.toFixed(2) + ' ₺' : '-'}</strong></span>
                                    ${ksfVal > 0 ? `<span>•</span><span>KSF: <strong class="text-indigo-700">${ksfVal.toFixed(2)} ₺</strong></span>` : ''}
                                    ${netKdvli > 0 ? `<span>•</span><span>Net Alış (KDV'li): <strong class="text-slate-900">${netKdvli.toFixed(2)} ₺</strong></span>` : ''}
                                    <span>•</span>
                                    <span>SGK Kârı: <strong class="${kamuKari >= 0 ? 'text-blue-600' : 'text-red-600'} font-bold">${kamuKari >= 0 ? '+' : ''}${kamuKari.toFixed(2)} ₺</strong></span>
                                    <span>•</span>
                                    <span>Elden Kârı: <strong class="text-emerald-600 font-bold">${eldenKari >= 0 ? '+' : ''}${eldenKari.toFixed(2)} ₺</strong></span>
                                    <span>•</span>
                                    ${mfBadgeHtml}
                                    ${eq.vade ? `<span>•</span><span>Vade: <strong>${eq.vade}</strong></span>` : ''}
                                    ${eq.iskonto > 0 ? `<span>• İsk: <strong class="text-blue-600">%${eq.iskonto}</strong></span>` : ''}
                                </div>
                                ${kademelerHtml}
                            </div>
                        </div>
                        <div class="shrink-0 flex items-center space-x-2">
                            <button onclick="closeEsdegerModal(); selectAndSearch('${eq.barkod || eq.kod}', '${safeName}')" class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center space-x-1.5 shadow-sm shadow-emerald-200 cursor-pointer">
                                <i class="fa-solid fa-arrows-split-up-and-left text-[11px]"></i>
                                <span>Tüm Depolarda Karşılaştır</span>
                            </button>
                        </div>
                    `;
                    list.appendChild(div);
                });
            }

            renderModalItems(eqList);

            if (needsLiveRefresh && currentReport.barkod) {
                try {
                    const resp = await fetch(`/api/products/equivalents?barcode=${encodeURIComponent(currentReport.barkod)}`);
                    if (resp.ok) {
                        const json = await resp.json();
                        if (json && json.found && json.muadiller && json.muadiller.length > 0) {
                            currentReport.esdegerler = json.muadiller;
                            if (json.esdeger_kodu) currentReport.esdeger_kodu = json.esdeger_kodu;
                            if (json.en_karli_muadil) currentReport.en_karli_muadil = json.en_karli_muadil;
                            if (json.muadil_kar_avantaji !== undefined) currentReport.muadil_kar_avantaji = json.muadil_kar_avantaji;
                            kodEl.innerText = currentReport.esdeger_kodu ? `SGK Kodu: ${currentReport.esdeger_kodu}` : 'SGK Eşdeğer Grubu';
                            renderModalItems(json.muadiller);
                        }
                    }
                } catch (e) {}
            }
        }

        function closeEsdegerModal() {
            document.getElementById('esdegerModal').classList.add('hidden');
        }

        // Simülatör Fonksiyonları
        function setSimulatorQty(qty) {
            simQtyInput.value = qty;
            updateSimulator();
        }

        function onSimulatorChange() {
            updateSimulator();
        }

        let selectedRowIndex = null;

        function setSimWithTier(rowIndex, alinan, hediye) {
            selectedRowIndex = rowIndex;
            const targetQty = (parseInt(alinan) || 1) + (parseInt(hediye) || 0);
            const rowQty = document.getElementById(`qty_${rowIndex}`);
            if (rowQty) {
                rowQty.value = parseInt(alinan) || 1;
                rowQty.classList.add('ring-2', 'ring-emerald-500', 'bg-emerald-50');
                setTimeout(() => rowQty.classList.remove('ring-2', 'ring-emerald-500', 'bg-emerald-50'), 1500);
            }
            const qtyInput = document.getElementById('simQtyInput');
            if (qtyInput) qtyInput.value = targetQty;
            updateSimulator();
            const resultsBox = document.getElementById('simResultsBox');
            if (resultsBox && resultsBox.classList.contains('hidden')) {
                toggleMfDetails();
            }
        }

        function selectMfTierAnalysis(depoIndex, alinan, hediye, mfText) {
            setSimWithTier(depoIndex, alinan, hediye);
        }

        function updateSimulator() {
            if (!currentReport || !currentReport.sonuclar || currentReport.sonuclar.length === 0) return;

            const qtyInput = document.getElementById('simQtyInput');
            const qty = qtyInput ? (parseInt(qtyInput.value) || 1) : 1;
            let depoItem = null;
            if (selectedRowIndex !== null && currentReport.sonuclar[selectedRowIndex]) {
                depoItem = currentReport.sonuclar[selectedRowIndex];
            } else {
                depoItem = currentReport.sonuclar.find(s => s.depo === currentReport.en_avantajli_depo && Math.abs(s.net_birim_maliyet - currentReport.en_dusuk_maliyet) < 0.01) || currentReport.sonuclar[0];
            }

            if (!depoItem) return;

            const dsf = depoItem.depocu_satis_fiyati || 0;
            const kdvOrani = depoItem.kdv_orani || 10.0;
            const kdvMultiplier = 1.0 + (kdvOrani / 100.0);
            const iskMultiplier = 1.0 - ((depoItem.ticari_iskonto || 0.0) / 100.0);

            let paidBoxes = qty;
            let freeBoxes = 0;
            let totalReceived = qty;

            // MF Kademesi varsa hesapla
            let tierVolumeNetPrice = null;
            if (depoItem.kademeler && depoItem.kademeler.length > 0) {
                let bestKademe = null;
                for (let k of depoItem.kademeler) {
                    const lot = (k.alinan || 1) + (k.hediye || 0);
                    if (qty >= lot) {
                        bestKademe = k;
                    }
                }

                if (bestKademe) {
                    if (bestKademe.hediye > 0) {
                        const lotSize = bestKademe.alinan + bestKademe.hediye;
                        const fullLots = Math.floor(qty / lotSize);
                        const remainder = qty % lotSize;
                        paidBoxes = (fullLots * bestKademe.alinan) + remainder;
                        freeBoxes = fullLots * bestKademe.hediye;
                        totalReceived = paidBoxes + freeBoxes;
                    } else if (bestKademe.net_birim_maliyet && bestKademe.net_birim_maliyet > 0) {
                        tierVolumeNetPrice = bestKademe.net_birim_maliyet;
                    }
                }
            }

            const totalInvoiceNet = (tierVolumeNetPrice !== null) ? (paidBoxes * tierVolumeNetPrice) : (paidBoxes * dsf * iskMultiplier);
            const totalInvoiceKdvli = totalInvoiceNet * kdvMultiplier;
            const unitNet = totalReceived > 0 ? (totalInvoiceNet / totalReceived) : 0;
            const unitKdvli = unitNet * kdvMultiplier;

            const elPaid = document.getElementById('simPaidBoxes');
            if (elPaid) elPaid.innerText = `${paidBoxes} Kutu`;
            const elFree = document.getElementById('simFreeBoxes');
            if (elFree) elFree.innerText = freeBoxes > 0 ? `+${freeBoxes} Kutu` : `0 Kutu`;
            const elTotal = document.getElementById('simTotalBoxes');
            if (elTotal) elTotal.innerText = `${totalReceived} Kutu`;
            const elUnitNet = document.getElementById('simUnitNet');
            if (elUnitNet) elUnitNet.innerText = `${unitNet.toFixed(2)} ₺`;
            const elUnitKdv = document.getElementById('simUnitKdvli');
            if (elUnitKdv) elUnitKdv.innerText = `${unitKdvli.toFixed(2)} ₺`;
            const elTotalInv = document.getElementById('simTotalInvoice');
            if (elTotalInv) elTotalInv.innerText = `${totalInvoiceNet.toFixed(2)} ₺`;
            const elInvKdv = document.getElementById('simInvoiceKdvli');
            if (elInvKdv) elInvKdv.innerText = `KDV Dahil: ${totalInvoiceKdvli.toFixed(2)} ₺`;

            const elDepoNote = document.getElementById('simDepoNote');
            if (elDepoNote) elDepoNote.innerText = `Hesaplama ${depoItem.depo_adi} şartlarına göre (${depoItem.mf_metni}) yapılmıştır.`;
            const simMfTextEl = document.getElementById('simMfText');
            if (simMfTextEl) simMfTextEl.innerText = `${depoItem.depo_adi}: ${depoItem.mf_metni}`;

            selectedDepoForSim = depoItem.depo;
            const simBtn = document.getElementById('simAddToCartBtn');
            const simText = document.getElementById('simAddToCartText');
            if (simBtn && simText) {
                if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depoItem.depo)) {
                    simBtn.classList.add('opacity-50', 'cursor-not-allowed');
                    simBtn.disabled = true;
                    simText.innerText = `${depoItem.depo_adi} (Pazaryeri Portalı)`;
                } else {
                    simBtn.classList.remove('opacity-50', 'cursor-not-allowed');
                    simBtn.disabled = false;
                    simText.innerText = `${depoItem.depo_adi} Sepetine Ekle (${paidBoxes} Kutu)`;
                }
            }
        }

        // ================= Sepete Ekleme & Bildirimler =================
        function showToast(title, message, type = 'success') {
            const container = document.getElementById('toastContainer');
            if (!container) return;
            const toast = document.createElement('div');
            const isSuccess = type === 'success';
            const bgClass = isSuccess ? 'bg-emerald-600 text-white shadow-emerald-200' : 'bg-rose-600 text-white shadow-rose-200';
            const icon = isSuccess ? 'fa-circle-check' : 'fa-triangle-exclamation';

            toast.className = `${bgClass} pointer-events-auto flex items-start space-x-3 px-4 py-3 rounded-2xl shadow-xl transition-all duration-300 transform translate-y-[-20px] opacity-0 max-w-md`;
            toast.innerHTML = `
                <i class="fa-solid ${icon} text-lg mt-0.5 shrink-0"></i>
                <div class="flex-1 text-xs">
                    <div class="font-bold text-sm leading-tight">${title}</div>
                    <div class="mt-0.5 text-white/90 leading-relaxed">${message}</div>
                </div>
                <button onclick="this.parentElement.remove()" class="text-white/70 hover:text-white ml-2 cursor-pointer">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            `;
            container.appendChild(toast);
            setTimeout(() => {
                toast.classList.remove('translate-y-[-20px]', 'opacity-0');
            }, 10);
            setTimeout(() => {
                toast.classList.add('opacity-0', 'translate-y-[-10px]');
                setTimeout(() => toast.remove(), 300);
            }, 5000);
        }

        async function addToCart(depo, urunId, barkod, rowIndex, btn, explicitName = '') {
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depo)) {
                showToast('Bilgi', 'Ortak alım grubu ve pazaryeri siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const qtyInput = document.getElementById(`qty_${rowIndex}`);
            const miktar = parseInt(qtyInput ? qtyInput.value : 1) || 1;

            const originalContent = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1"></i>Ekleniyor...`;

            const prodName = explicitName || ((typeof currentReport !== 'undefined' && currentReport) ? (currentReport.urun_adi || currentReport.name || '') : '');
            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: urunId,
                        barkod: barkod,
                        miktar: miktar,
                        name: prodName
                    })
                });
                const result = await res.json();
                if (result.success) {
                    let extra = '';
                    if (result.sepet_no) extra += ` (Belge No: ${result.sepet_no})`;
                    if (result.sepet_tutari) extra += ` (Sepet Tutarı: ${result.sepet_tutari} ₺)`;
                    showToast('Sepete Eklendi', `${result.message || `${miktar} kutu başarıyla ${depo} sepetine eklendi!`}${extra}`, 'success');
                } else {
                    showToast('Hata', result.message || `${depo} sepetine eklenemedi.`, 'error');
                }
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalContent;
            }
        }

        // ================= TEKLİ SİPARİŞİ TAMAMLA & SONLANDIR =================
        function closeQuickFinalizeModal() {
            const modal = document.getElementById('quickFinalizeModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
        }

        async function quickFinalizeOrder(depo, urunId, barkod, rowIndex, urunAdi, unitPrice) {
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depo)) {
                showToast('Bilgi', 'Ortak alım grubu ve pazaryeri siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const qtyInput = document.getElementById(`qty_${rowIndex}`);
            const miktar = parseInt(qtyInput ? qtyInput.value : 1) || 1;
            const cleanUrunAdi = urunAdi || 'Ürün';

            const modal = document.getElementById('quickFinalizeModal');
            const badgeEl = document.getElementById('quickFinDepoBadge');
            const bodyEl = document.getElementById('quickFinBody');
            const footerEl = document.getElementById('quickFinFooter');

            if (!modal || !bodyEl || !footerEl) return;

            if (badgeEl) badgeEl.innerText = depo === 'SELCUK' ? 'Selçuk Ecza' : (depo === 'NEVZAT' ? 'Nevzat Ecza' : (depo === 'ALLIANCE' ? 'Alliance Healthcare' : (depo === 'ISKOOP' ? 'İSKOOP' : depo)));
            
            modal.classList.remove('hidden');
            modal.style.display = 'flex';

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-circle-notch fa-spin text-3xl text-amber-500 mb-3"></i>
                    <div class="font-extrabold text-slate-800 text-sm">Depo Sepeti Kontrol Ediliyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depo} sepet durumu ve mevcut siparişler sorgulanıyor...</div>
                </div>
            `;
            footerEl.innerHTML = `
                <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
            `;

            try {
                const res = await fetch('/api/cart/quick-finalize-check', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: urunId,
                        barkod: barkod,
                        miktar: miktar,
                        urun_adi: cleanUrunAdi
                    })
                });
                const checkData = await res.json();

                if (!checkData.success) {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-exclamation mr-1.5"></i>Sepet Sorgulanamadı</div>
                            <div>${checkData.message || 'Depo sepet bilgisi alınamadı.'}</div>
                        </div>
                    `;
                    return;
                }

                const totalEst = miktar * (unitPrice || 0);
                const alreadyInCart = !!checkData.already_in_cart;
                const sessionItems = checkData.session_items || [];
                const foreignItems = checkData.foreign_items || [];

                if (checkData.can_finalize_directly) {
                    // Sepette yabancı ürün YOK! Doğrudan sonlandırılabilir
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Ürün Özeti -->
                            <div class="p-4 rounded-2xl bg-emerald-50/70 border-2 border-emerald-300 shadow-xs flex items-center justify-between">
                                <div class="pr-3">
                                    <div class="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-black uppercase tracking-wider mb-1">
                                        <i class="fa-solid fa-circle-check"></i>
                                        <span>${alreadyInCart ? 'Az Önce Sepete Eklendi' : 'Şimdi Sepete Eklenecek'}</span>
                                    </div>
                                    <div class="text-base font-black text-slate-900 leading-snug">${cleanUrunAdi}</div>
                                    <div class="text-xs text-slate-600 mt-1">
                                        Birim Fiyat: <strong class="text-slate-900 font-mono">${(unitPrice || 0).toFixed(2)} ₺</strong> (KDV Dahil)
                                    </div>
                                </div>
                                <div class="text-right shrink-0 pl-3 border-l border-emerald-200">
                                    <div class="text-[10px] text-emerald-700 font-bold uppercase">Miktar</div>
                                    <div class="text-2xl font-black text-emerald-700 font-mono">${miktar} <span class="text-xs font-bold text-emerald-600">Kutu</span></div>
                                    <div class="text-xs font-extrabold text-slate-800 mt-0.5 font-mono">~${totalEst.toFixed(2)} ₺</div>
                                </div>
                            </div>

                            ${sessionItems.length > 1 ? `
                            <!-- Bu Oturumda Eklenen Diğer Ürünler (Yeşil) -->
                            <div class="bg-emerald-50/60 rounded-2xl border border-emerald-200 p-3 max-h-36 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-check-double mr-1 text-emerald-600"></i>Bu Siparişte Eklenen Ürünler (${sessionItems.length} Kalem):</span>
                                    <span class="font-mono text-emerald-700">${(checkData.total_amount || 0).toFixed(2)} ₺</span>
                                </div>
                                ${sessionItems.map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-2.5 rounded-lg bg-white border border-emerald-200 text-xs">
                                        <span class="font-bold text-emerald-950 truncate mr-2"><i class="fa-solid fa-circle-check text-emerald-500 mr-1.5 text-[10px]"></i>${it.ad}</span>
                                        <span class="font-extrabold text-emerald-700 whitespace-nowrap font-mono">${it.miktar} Kutu (${(it.tutar || 0).toFixed(2)} ₺)</span>
                                    </div>
                                `).join('')}
                            </div>
                            ` : ''}

                            <!-- Güvenlik Onayı -->
                            <div class="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start space-x-3">
                                <div class="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                                    <i class="fa-solid fa-shield-check text-sm"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-bold text-emerald-950 text-sm">Sepet Kontrolü Başarılı — Yabancı Ürün Yok ✅</div>
                                    <div class="text-emerald-800 mt-0.5 leading-relaxed">
                                        ${checkData.item_count === 0 ? 'Depo sepetiniz şu an boş, ürün eklenip doğrudan onaylanacak.' : 'Sepette sadece sizin bu oturumda eklediğiniz ürün(ler) yer alıyor.'}
                                        Onay verdiğinizde sipariş <strong>doğrudan ${depo} sistemine iletilip sonlandırılacaktır</strong>.
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;

                    footerEl.innerHTML = `
                        <div class="flex items-center justify-between w-full">
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
                            <div class="flex items-center space-x-2">
                                ${checkData.checkout_url ? `<a href="${checkData.checkout_url}" target="_blank" class="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1.5"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Sepeti İncele</span></a>` : ''}
                                <button type="button" id="btnExecuteFinalize" onclick="executeFinalize('${depo}', '${urunId}', '${barkod}', ${miktar}, false, ${alreadyInCart})" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md hover:shadow-lg transition flex items-center space-x-2 cursor-pointer">
                                    <i class="fa-solid fa-paper-plane text-xs"></i>
                                    <span>Evet, Siparişi Sonlandır (Depoya Gönder)</span>
                                </button>
                            </div>
                        </div>
                    `;
                } else {
                    // Sepette BAŞKA / ÖNCEDEN KALMIŞ YABANCI ÜRÜNLER VAR! Kırmızı uyarı göster
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Kırmızı Dikkat Uyarısı -->
                            <div class="p-3.5 rounded-2xl bg-rose-100 border-2 border-rose-500 flex items-start space-x-3 shadow-sm">
                                <div class="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow">
                                    <i class="fa-solid fa-triangle-exclamation text-base"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-black text-rose-950 text-sm">🚨 DİKKAT: Sepette Başka Eklenen / Önceden Kalmış Ürünler Var!</div>
                                    <div class="text-rose-900 mt-0.5 leading-relaxed">
                                        ${depo} sepetinizde bu sipariş dışında önceden eklenmiş <strong class="underline">${foreignItems.length} farklı ürün</strong> tespit edildi! (Toplam Sepet: <strong>${(checkData.total_amount || 0).toFixed(2)} ₺</strong>)
                                    </div>
                                </div>
                            </div>

                            <!-- KIRMIZI: Başka Eklenen / Önceden Sepette Olan Yabancı Ürünler -->
                            <div class="bg-rose-50 rounded-2xl border-2 border-rose-400 p-3 max-h-40 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-black text-rose-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-ban mr-1 text-rose-600"></i>🚨 Başka Eklenen / Önceden Sepette Olanlar (${foreignItems.length} Kalem):</span>
                                    <span class="px-2 py-0.5 rounded bg-rose-600 text-white text-[9px] font-black">DİĞER / ÖNCEKİ</span>
                                </div>
                                ${foreignItems.map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-2.5 rounded-lg bg-rose-100/90 border border-rose-300 text-xs">
                                        <span class="font-extrabold text-rose-950 truncate mr-2"><i class="fa-solid fa-circle-exclamation text-rose-600 mr-1.5 text-[10px]"></i>${it.ad}</span>
                                        <span class="font-black text-rose-800 whitespace-nowrap font-mono">${it.miktar} Kutu (${(it.tutar || 0).toFixed(2)} ₺)</span>
                                    </div>
                                `).join('')}
                            </div>

                            <!-- YEŞİL: Şimdi / Bu Siparişte Eklenen Ürünler -->
                            <div class="p-3 rounded-2xl bg-emerald-50 border-2 border-emerald-400 space-y-1.5">
                                <div class="flex items-center justify-between">
                                    <span class="text-emerald-800 font-black uppercase text-[10px]"><i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>✅ Bu Siparişte / Şimdi Eklenen Ürün:</span>
                                    <span class="px-2 py-0.5 rounded bg-emerald-600 text-white text-[9px] font-black">YENİ EKLENEN</span>
                                </div>
                                <div class="flex items-center justify-between text-xs pt-1">
                                    <div class="font-black text-emerald-950">${cleanUrunAdi} (${miktar} Kutu)</div>
                                    <div class="font-black text-emerald-700 text-sm font-mono">${alreadyInCart ? '' : '+'}${totalEst.toFixed(2)} ₺</div>
                                </div>
                            </div>
                        </div>
                    `;

                    const safeCleanName = cleanUrunAdi.replace(/'/g, "\\\\'");
                    footerEl.innerHTML = `
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition w-full sm:w-auto cursor-pointer">Vazgeç</button>
                            <div class="flex flex-wrap items-center gap-2 justify-end w-full sm:w-auto">
                                ${checkData.checkout_url ? `<a href="${checkData.checkout_url}" target="_blank" class="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Sepeti İncele</span></a>` : ''}
                                <button type="button" onclick="onlyClearCart('${depo}')" class="px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-300 hover:border-rose-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer" title="Sepetteki tüm ürünleri boşaltır (Sipariş göndermez)">
                                    <i class="fa-solid fa-trash-can text-[10px] text-rose-500"></i>
                                    <span>Sadece Sepeti Boşalt</span>
                                </button>
                                <button type="button" onclick="clearCartAndFinalize('${depo}', '${urunId}', '${barkod}', ${miktar}, '${safeCleanName}', ${unitPrice})" class="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition flex items-center space-x-1 cursor-pointer shadow-sm" title="Kırmızı (diğer) ürünleri siler ve sadece bu ürünü gönderir">
                                    <i class="fa-solid fa-broom text-[10px]"></i>
                                    <span>Diğerlerini Sil & Sadece Bunu Gönder</span>
                                </button>
                                <button type="button" onclick="executeFinalize('${depo}', '${urunId}', '${barkod}', ${miktar}, true, ${alreadyInCart})" class="px-4 py-2 bg-gradient-to-r from-rose-600 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white rounded-xl text-xs font-black shadow-sm transition flex items-center space-x-1.5 cursor-pointer" title="Kırmızı ürünlerle beraber tüm sepeti onaylar">
                                    <i class="fa-solid fa-paper-plane text-[10px]"></i>
                                    <span>Tüm Sepeti Beraber Gönder</span>
                                </button>
                            </div>
                        </div>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
            }
        }

        async function executeFinalize(depo, urunId, barkod, miktar, force, alreadyInCart = false) {
            const bodyEl = document.getElementById('quickFinBody');
            const footerEl = document.getElementById('quickFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-spinner fa-spin text-4xl text-emerald-500 mb-3"></i>
                    <div class="text-base font-extrabold text-slate-800">Sipariş Depoya İletiliyor...</div>
                    <div class="text-xs text-slate-500 mt-1">${depo} sistemine bağlanılıyor ve sipariş doğrudan onaylanıyor...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            try {
                const res = await fetch('/api/cart/finalize', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: urunId,
                        barkod: barkod || (currentReport && currentReport.barkod) || '',
                        urun_adi: (currentReport && currentReport.urun_adi) || '',
                        miktar: miktar,
                        force: force,
                        already_in_cart: alreadyInCart
                    })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-emerald-500/20">
                                <i class="fa-solid fa-circle-check animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sipariş Başarıyla Sonlandırıldı! 🎉</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message}</p>
                            </div>
                            ${result.order_info ? `
                                <div class="p-3 rounded-2xl bg-slate-100 border border-slate-200 text-xs font-mono font-bold text-slate-700 max-w-sm mx-auto">
                                    ${result.order_info}
                                </div>
                            ` : ''}
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            ${result.portal_url ? `<a href="${result.portal_url}" target="_blank" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-sm"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>WebDepo'da İncele</span></a>` : ''}
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Tamam</button>
                        </div>
                    `;
                    showToast('Sipariş Sonlandırıldı', result.message, 'success');
                    if (typeof markBulkSessionFinalizedInUI === 'function') markBulkSessionFinalizedInUI(depo);
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sipariş Onaylanamadı</div>
                            <div class="leading-relaxed">${result.message || 'Bilinmeyen bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        async function clearCartAndFinalize(depo, urunId, barkod, miktar, urunAdi, unitPrice) {
            const bodyEl = document.getElementById('quickFinBody');
            if (bodyEl) {
                bodyEl.innerHTML = `
                    <div class="text-center py-8">
                        <i class="fa-solid fa-spinner fa-spin text-3xl text-rose-500 mb-3"></i>
                        <div class="font-bold text-slate-800 text-sm">Sepet Temizleniyor...</div>
                        <div class="text-xs text-slate-400 mt-1">Önceki ürünler siliniyor, ardından acil ürün eklenecek...</div>
                    </div>
                `;
            }
            try {
                await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo })
                });
                await executeFinalize(depo, urunId, barkod, miktar, true, false);
            } catch (e) {
                showToast('Hata', 'Sepet temizlenirken hata: ' + e.message, 'error');
            }
        }

        async function onlyClearCart(depo) {
            const bodyEl = document.getElementById('quickFinBody');
            const footerEl = document.getElementById('quickFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-8">
                    <i class="fa-solid fa-spinner fa-spin text-3xl text-rose-500 mb-3"></i>
                    <div class="font-bold text-slate-800 text-sm">Sepet Boşaltılıyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depo} sepetindeki tüm ürünler siliniyor...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            try {
                const res = await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-rose-500/20">
                                <i class="fa-solid fa-trash-can animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sepetiniz Başarıyla Boşaltıldı 🗑️</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message || `${depo} sepetindeki tüm ürünler temizlendi.`}</p>
                                <p class="text-[11px] text-slate-400 mt-1.5 font-bold">Herhangi bir sipariş onaylanmamış veya iletilmemiştir.</p>
                            </div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            <button type="button" onclick="closeQuickFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                        </div>
                    `;
                    showToast('Sepet Boşaltıldı', `${depo} sepetiniz temizlendi (Sipariş verilmedi).`, 'info');
                    if (typeof markBulkSessionClearedInUI === 'function') markBulkSessionClearedInUI(depo);
                    if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
                    if (window.smartOrderLoadedOnce && typeof loadSmartOrderList === 'function') loadSmartOrderList(true);
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sepet Temizlenemedi</div>
                            <div class="leading-relaxed">${result.message || 'Sepet boşaltılırken bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeQuickFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        // ================= GÜNLÜK TOPLU SİPARİŞİ SONLANDIRMA FONKSİYONLARI =================
        function getUnfinalizedBulkDepos(excludeDepo = null) {
            const sessions = (window.currentBulkState && window.currentBulkState.depoSessions) || {};
            const ex = excludeDepo ? String(excludeDepo).toUpperCase() : null;
            const list = [];
            for (const k of Object.keys(sessions)) {
                const s = sessions[k];
                if (s && s.count > 0 && !s.finalized && !s.cleared && k.toUpperCase() !== ex) {
                    list.push(k.toUpperCase());
                }
            }
            return list;
        }

        function getNextUnfinalizedBulkDepo(excludeDepo = null) {
            const list = getUnfinalizedBulkDepos(excludeDepo);
            return list.length > 0 ? list[0] : null;
        }

        function updateBulkMainFinalizeButtonUI() {
            const btnFin = document.getElementById('btnBulkFinalize');
            if (!btnFin) return;
            const unfinList = getUnfinalizedBulkDepos();
            const sessions = (window.currentBulkState && window.currentBulkState.depoSessions) || {};
            const allKeys = Object.keys(sessions).filter(k => sessions[k] && sessions[k].count > 0);

            if (unfinList.length > 0) {
                const nextDepo = unfinList[0];
                if (window.currentBulkState) window.currentBulkState.depo = nextDepo;
                const nextSess = sessions[nextDepo] || { name: nextDepo, count: 0 };
                btnFin.disabled = false;
                btnFin.className = 'px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-500/20 transition flex items-center space-x-1.5 cursor-pointer';
                if (unfinList.length > 1) {
                    btnFin.innerHTML = `<i class="fa-solid fa-paper-plane text-xs"></i><span>${nextSess.name} Siparişini Sonlandır (${unfinList.length} Depo Bekliyor)</span>`;
                } else {
                    btnFin.innerHTML = `<i class="fa-solid fa-paper-plane text-xs"></i><span>${nextSess.name} Siparişini Sonlandır (${nextSess.count} Kalem)</span>`;
                }
            } else if (allKeys.length > 0) {
                btnFin.className = 'px-5 py-2.5 bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm flex items-center space-x-1.5 cursor-pointer';
                btnFin.innerHTML = `<i class="fa-solid fa-circle-check text-xs"></i><span>Tüm Siparişler Depolara İletildi ✅</span>`;
            }
            if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
        }

        function markBulkSessionFinalizedInUI(depo) {
            const cleanDepo = (depo || '').toUpperCase();
            if (window.currentBulkState) {
                if (Array.isArray(window.currentBulkState.allResults)) {
                    window.currentBulkState.allResults.forEach(r => {
                        if ((r.status === 'ADDED' || r.status === 'ORDERED') && (!r.assigned_depo || r.assigned_depo.toUpperCase() === cleanDepo)) {
                            r.status = 'ORDERED';
                            r.message = 'Sipariş Verildi';
                        }
                    });
                }
                if (window.currentBulkState.depoSessions && window.currentBulkState.depoSessions[cleanDepo]) {
                    window.currentBulkState.depoSessions[cleanDepo].finalized = true;
                }
            }
            const unfinAfter = getUnfinalizedBulkDepos();
            const missingAfter = (window.currentBulkState && Array.isArray(window.currentBulkState.missingItems)) ? window.currentBulkState.missingItems : [];
            const pText = document.getElementById('bulkProgressText');
            if (pText) {
                if (unfinAfter.length > 0) {
                    const nextS = window.currentBulkState.depoSessions[unfinAfter[0]];
                    pText.innerHTML = `<strong class="text-emerald-700">${cleanDepo} Siparişi Onaylandı ✅:</strong> Sırada onay bekleyen <strong class="text-indigo-700">${unfinAfter.length} depo (${nextS ? nextS.name : unfinAfter[0]})</strong> bulunuyor.`;
                } else if (missingAfter.length > 0) {
                    pText.innerHTML = `<strong class="text-emerald-700">${cleanDepo} Siparişi Onaylandı ✅:</strong> Geriye sipariş verilmeyen <strong class="text-rose-600">${missingAfter.length} eksik ürün</strong> kaldı. Başka depoya aktarabilirsiniz.`;
                } else {
                    pText.innerHTML = `<strong class="text-emerald-700">Tüm Siparişler Onaylandı ✅:</strong> Seçilen tüm depolardaki siparişler başarıyla iletildi!`;
                }
            }
            // Eğer sonlandırılmamış depo kalmadıysa ve sadece sipariş verilmeyen (eksik) ürünler kaldıysa, otomatik Eksikler sekmesine geç
            if (unfinAfter.length === 0 && missingAfter.length > 0 && typeof switchBulkResultTab === 'function') {
                switchBulkResultTab('YOK');
            }
            updateBulkMainFinalizeButtonUI();
            if (typeof renderDepoBreakdownPills === 'function') renderDepoBreakdownPills();
            if (typeof renderBulkItemsTable === 'function') renderBulkItemsTable();
            if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
            if (window.smartOrderLoadedOnce && typeof loadSmartOrderList === 'function') loadSmartOrderList(true);
        }

        function markBulkSessionClearedInUI(depo) {
            const cleanDepo = (depo || '').toUpperCase();
            if (window.currentBulkState && Array.isArray(window.currentBulkState.allResults)) {
                window.currentBulkState.allResults.forEach(r => {
                    if (r.status === 'ADDED' && (!r.assigned_depo || r.assigned_depo.toUpperCase() === cleanDepo)) {
                        r.status = 'CLEARED';
                        r.message = 'Sepetten Silindi';
                    }
                });
                if (window.currentBulkState.depoSessions && window.currentBulkState.depoSessions[cleanDepo]) {
                    window.currentBulkState.depoSessions[cleanDepo].cleared = true;
                }
            }
            updateBulkMainFinalizeButtonUI();
            if (typeof renderDepoBreakdownPills === 'function') renderDepoBreakdownPills();
            if (typeof renderBulkItemsTable === 'function') renderBulkItemsTable();
            if (typeof syncTodayOrdersAcrossPCs === 'function') syncTodayOrdersAcrossPCs();
            if (window.smartOrderLoadedOnce && typeof loadSmartOrderList === 'function') loadSmartOrderList(true);
        }

        function closeBulkFinalizeModal(alsoCloseBulkModal = false) {
            const modal = document.getElementById('bulkFinalizeModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
            const missing = (window.currentBulkState && window.currentBulkState.missingItems) ? window.currentBulkState.missingItems : [];
            const remainingDepos = getUnfinalizedBulkDepos();
            // Sipariş verilmeyen hiçbir ürün veya sonlandırılmamış depo kalmadıysa ana toplu sipariş modalını da kapat
            if ((alsoCloseBulkModal || (missing.length === 0 && remainingDepos.length === 0)) && missing.length === 0 && remainingDepos.length === 0) {
                if (typeof closeBulkOrderModal === 'function') {
                    closeBulkOrderModal();
                }
            }
            if (typeof updateMiniBulkCartUI === 'function') updateMiniBulkCartUI();
        }

        async function openBulkFinalizeFlow(customDepo) {
            const depo = (customDepo || getNextUnfinalizedBulkDepo() || (window.currentBulkState && window.currentBulkState.depo) || 'SELCUK').toUpperCase();
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(depo)) {
                showToast('Bilgi', 'Pazaryeri ve ortak alım siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const modal = document.getElementById('bulkFinalizeModal');
            const badgeEl = document.getElementById('bulkFinDepoBadge');
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');

            if (!modal || !bodyEl || !footerEl) return;

            const depoNames = {
                'SELCUK': 'Selçuk Ecza',
                'NEVZAT': 'Nevzat Ecza',
                'ALLIANCE': 'Alliance Healthcare',
                'ISKOOP': 'İSKOOP E-Şube'
            };
            if (badgeEl) badgeEl.innerText = depoNames[depo] || depo;

            modal.classList.remove('hidden');
            modal.style.display = 'flex';

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-circle-notch fa-spin text-3xl text-emerald-500 mb-3"></i>
                    <div class="font-extrabold text-slate-800 text-sm">Depo Sepeti ve Sipariş Listesi Kontrol Ediliyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depoNames[depo] || depo} canlı sepetindeki ürünler bugünkü listenizle karşılaştırılıyor...</div>
                </div>
            `;
            footerEl.innerHTML = `
                <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Vazgeç</button>
            `;

            // Bugünkü siparişte ilgili depoya eklenen kalemleri al
            const addedItems = (window.currentBulkState && window.currentBulkState.allResults)
                ? window.currentBulkState.allResults
                    .filter(r => (r.status === 'ADDED' || r.status === 'ORDERED') && (!r.assigned_depo || r.assigned_depo === depo))
                    .map(it => ({
                        barcode: it.barcode,
                        name: it.name,
                        miktar: it.miktar,
                        urun_id: it.urun_id || ''
                    }))
                : [];

            try {
                const res = await fetch('/api/cart/bulk-finalize-check', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        items: addedItems
                    })
                });
                const checkData = await res.json();

                if (!checkData.success) {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-exclamation mr-1.5"></i>Sepet Sorgulanamadı</div>
                            <div>${checkData.message || 'Depo sepet bilgisi alınamadı.'}</div>
                        </div>
                    `;
                    return;
                }

                if (checkData.cart_count === 0) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-8 space-y-3">
                            <div class="w-14 h-14 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto text-2xl">
                                <i class="fa-solid fa-cart-shopping"></i>
                            </div>
                            <div class="font-black text-slate-900 text-sm">Sepette Ürün Bulunamadı</div>
                            <p class="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                                ${depoNames[depo] || depo} sepetiniz şu anda boş görünüyor. Önce günlük sipariş listesinden ürünleri sepete aktarınız.
                            </p>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                    return;
                }

                if (!checkData.has_extra_items) {
                    // Sepette sadece bugünkü sipariş ürünleri var! Doğrudan onaylanabilir
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Başarılı Eşleşme Bilgisi -->
                            <div class="p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-300 flex items-start space-x-3.5">
                                <div class="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                                    <i class="fa-solid fa-shield-check text-base"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-extrabold text-emerald-950 text-sm">Sepet Kontrolü Başarılı — Yabancı Ürün Yok ✅</div>
                                    <div class="text-emerald-800 mt-1 leading-relaxed">
                                        ${depoNames[depo] || depo} sepetinizde sadece az önce eklediğiniz <strong>${checkData.cart_count} kalem ürün</strong> yer alıyor.
                                        Sepette önceden kalmış veya yabancı bir ürün bulunmamaktadır.
                                    </div>
                                </div>
                            </div>

                            <!-- Sepet Tutarı ve Kalem Sayısı Kartı -->
                            <div class="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center justify-between">
                                <div>
                                    <div class="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Onaylanacak Günlük Sipariş</div>
                                    <div class="text-base font-black text-slate-900 mt-0.5">${checkData.cart_count} Kalem İlaç</div>
                                </div>
                                <div class="text-right">
                                    <div class="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Toplam Sepet Tutarı</div>
                                    <div class="text-xl font-black text-emerald-600 font-mono mt-0.5">${(checkData.total_amount || 0).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺</div>
                                </div>
                            </div>

                            <!-- Sepetteki Ürünlerin Listesi (Yeşil Onaylı) -->
                            <div class="bg-emerald-50/50 rounded-2xl border border-emerald-200 p-3 max-h-56 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-black text-emerald-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>✅ Bu Siparişte Eklenen Ürünler (${checkData.cart_count} Kalem):</span>
                                    <span class="px-2 py-0.5 rounded bg-emerald-600 text-white text-[9px] font-black">YENİ EKLENDİ</span>
                                </div>
                                ${(checkData.all_items || []).map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-3 rounded-xl bg-white border border-emerald-200 text-xs">
                                        <span class="font-bold text-emerald-950 truncate mr-2"><i class="fa-solid fa-check text-emerald-500 mr-1.5 text-[10px]"></i>${it.ad || it.urun_adi || 'Ürün'}</span>
                                        <span class="font-extrabold text-emerald-700 whitespace-nowrap font-mono">${it.miktar} Kutu ${(it.tutar ? `(${it.tutar.toFixed(2)} ₺)` : '')}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `;

                    footerEl.innerHTML = `
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer w-full sm:w-auto">Vazgeç</button>
                            <div class="flex flex-wrap items-center gap-2 justify-end w-full sm:w-auto">
                                ${checkData.checkout_url ? `<a href="${checkData.checkout_url}" target="_blank" class="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Sepeti İncele</span></a>` : ''}
                                <button type="button" onclick="onlyClearCartFromBulk('${depo}')" class="px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-300 hover:border-rose-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer" title="Sepetteki tüm ürünleri boşaltır (Sipariş göndermez)">
                                    <i class="fa-solid fa-trash-can text-[10px] text-rose-500"></i>
                                    <span>Sadece Sepeti Boşalt</span>
                                </button>
                                <button type="button" onclick="executeBulkFinalizeSubmit('${depo}', true)" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md hover:shadow-lg transition flex items-center space-x-2 cursor-pointer">
                                    <i class="fa-solid fa-paper-plane text-xs"></i>
                                    <span>Evet, Günlük Siparişi Sonlandır (Depoya Gönder)</span>
                                </button>
                            </div>
                        </div>
                    `;
                } else {
                    // Sepette FARKLI / ÖNCEDEN EKLENMİŞ YABANCI ÜRÜNLER VAR! Kırmızı uyarı göster
                    bodyEl.innerHTML = `
                        <div class="space-y-4">
                            <!-- Kırmızı Dikkat Uyarısı -->
                            <div class="p-4 rounded-2xl bg-rose-100 border-2 border-rose-500 flex items-start space-x-3.5 shadow-sm">
                                <div class="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow">
                                    <i class="fa-solid fa-triangle-exclamation text-base"></i>
                                </div>
                                <div class="text-xs">
                                    <div class="font-black text-rose-950 text-sm">🚨 DİKKAT: Depo Sepetinde Başka Eklenen / Önceden Kalmış Ürünler Var!</div>
                                    <div class="text-rose-900 mt-1 leading-relaxed">
                                        ${depoNames[depo] || depo} sepetinizde az önce eklediğiniz ürünler dışında <strong class="underline">${checkData.extra_count} farklı ürün</strong> tespit edildi!
                                        Sepet Toplamı: <strong>${(checkData.total_amount || 0).toFixed(2)} ₺</strong> (Başka Eklenen Tutar: <strong>${(checkData.extra_total || 0).toFixed(2)} ₺</strong>).
                                    </div>
                                </div>
                            </div>

                            <!-- KIRMIZI: Farklı / Önceden Eklenmiş Ürünler Listesi -->
                            <div class="bg-rose-50 rounded-2xl border-2 border-rose-400 p-3 max-h-44 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-black text-rose-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-ban mr-1 text-rose-600"></i>🚨 Başka Eklenen / Önceden Sepette Olan Ürünler (${checkData.extra_count} Kalem):</span>
                                    <span class="px-2 py-0.5 rounded bg-rose-600 text-white text-[9px] font-black">${(checkData.extra_total || 0).toFixed(2)} ₺</span>
                                </div>
                                ${(checkData.extra_items || []).map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-3 rounded-xl bg-rose-100/90 border border-rose-300 text-xs shadow-2xs">
                                        <span class="font-extrabold text-rose-950 truncate mr-2"><i class="fa-solid fa-circle-exclamation text-rose-600 mr-1.5 text-[10px]"></i>${it.ad || it.urun_adi || 'Ürün'}</span>
                                        <span class="font-black text-rose-800 whitespace-nowrap font-mono">${it.miktar} Kutu ${(it.tutar ? `(${it.tutar.toFixed(2)} ₺)` : '')}</span>
                                    </div>
                                `).join('')}
                            </div>

                            <!-- YEŞİL: Şimdi / Bu Siparişte Eklenen Kalemler -->
                            <div class="bg-emerald-50 rounded-2xl border-2 border-emerald-300 p-3 max-h-36 overflow-y-auto space-y-1.5">
                                <div class="text-[10px] font-black text-emerald-800 uppercase tracking-wider mb-1 flex items-center justify-between">
                                    <span><i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i>✅ Bu Siparişte Az Önce Eklenenler (${checkData.matched_count} Kalem):</span>
                                    <span class="px-2 py-0.5 rounded bg-emerald-600 text-white text-[9px] font-black">SİZİN EKLEDİĞİNİZ</span>
                                </div>
                                ${(checkData.matched_items || []).map(it => `
                                    <div class="flex items-center justify-between py-1.5 px-2.5 rounded-lg bg-white border border-emerald-200 text-xs">
                                        <span class="font-bold text-emerald-950 truncate mr-2"><i class="fa-solid fa-check text-emerald-500 mr-1.5 text-[10px]"></i>${it.ad || it.urun_adi || 'Ürün'}</span>
                                        <span class="font-extrabold text-emerald-700 whitespace-nowrap font-mono">${it.miktar} Kutu</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `;

                    footerEl.innerHTML = `
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-2 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition w-full sm:w-auto cursor-pointer">Vazgeç</button>
                            <div class="flex flex-wrap items-center gap-2 justify-end w-full sm:w-auto">
                                ${checkData.checkout_url ? `<a href="${checkData.checkout_url}" target="_blank" class="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Sepeti İncele</span></a>` : ''}
                                <button type="button" onclick="onlyClearCartFromBulk('${depo}')" class="px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-300 hover:border-rose-300 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer" title="Sepetteki tüm ürünleri siler (Sipariş verilmez)">
                                    <i class="fa-solid fa-trash-can text-[10px] text-rose-500"></i>
                                    <span>Sadece Sepeti Boşalt</span>
                                </button>
                                <button type="button" onclick="cleanCartAndSubmitBulk('${depo}')" class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition flex items-center space-x-1.5 cursor-pointer shadow-sm" title="Kırmızı işaretli diğer ürünleri çıkarır ve yalnızca sizin eklediğiniz yeşil siparişi depoya iletir">
                                    <i class="fa-solid fa-broom text-[10px]"></i>
                                    <span>Kırmızıları Çıkar & Sadece Eklenenleri Gönder</span>
                                </button>
                                <button type="button" onclick="executeBulkFinalizeSubmit('${depo}', true)" class="px-4 py-2 bg-gradient-to-r from-rose-600 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white rounded-xl text-xs font-black shadow-sm transition flex items-center space-x-1.5 cursor-pointer" title="Mevcut tüm sepeti kırmızı ürünlerle birlikte onaylar">
                                    <i class="fa-solid fa-paper-plane text-[10px]"></i>
                                    <span>Tüm Sepeti Beraber Onayla & Gönder</span>
                                </button>
                            </div>
                        </div>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
            }
        }

        async function executeBulkFinalizeSubmit(depo, force) {
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-spinner fa-spin text-4xl text-emerald-500 mb-3"></i>
                    <div class="font-black text-slate-800 text-base">Sipariş Depoya İletiliyor ve Sonlandırılıyor...</div>
                    <div class="text-xs text-slate-500 mt-1">${depo} B2B sistemi üzerinde sipariş onaylanıyor, lütfen bekleyiniz...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            const addedItems = (window.currentBulkState && window.currentBulkState.allResults)
                ? window.currentBulkState.allResults
                    .filter(r => (r.status === 'ADDED' || r.status === 'ORDERED') && (!r.assigned_depo || r.assigned_depo === depo))
                    .map(it => ({
                        barcode: it.barcode,
                        name: it.name,
                        miktar: it.miktar,
                        urun_id: it.urun_id || ''
                    }))
                : [];

            try {
                const res = await fetch('/api/cart/finalize', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        urun_id: '',
                        barkod: '',
                        miktar: 1,
                        force: force,
                        items: addedItems
                    })
                });
                const result = await res.json();

                if (result.success) {
                    showToast('Sipariş Sonlandırıldı', result.message, 'success');
                    markBulkSessionFinalizedInUI(depo);
                    const remainingDepos = getUnfinalizedBulkDepos();
                    const sessions = (window.currentBulkState && window.currentBulkState.depoSessions) || {};
                    const nextDepo = remainingDepos.length > 0 ? remainingDepos[0] : null;
                    const nextSess = nextDepo ? (sessions[nextDepo] || { name: nextDepo, count: 0, amount: 0 }) : null;
                    const remainingHtml = remainingDepos.length > 0 ? `
                        <div class="p-3.5 rounded-2xl bg-indigo-50 border-2 border-indigo-200 text-left max-w-md mx-auto mt-3">
                            <div class="text-xs font-black text-indigo-950 flex items-center space-x-1.5">
                                <i class="fa-solid fa-layer-group text-indigo-600"></i>
                                <span>Sırada Onay Bekleyen Diğer Depolar (${remainingDepos.length} Depo):</span>
                            </div>
                            <div class="mt-2 space-y-1.5">
                                ${remainingDepos.map(rk => {
                                    const rs = sessions[rk] || { name: rk, count: 0, amount: 0 };
                                    return `<button type="button" onclick="openBulkFinalizeFlow('${rk}')" class="w-full py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold flex items-center justify-between transition cursor-pointer shadow-xs">
                                        <span><i class="fa-solid fa-paper-plane mr-1.5"></i>${rs.name} Siparişini Sonlandır</span>
                                        <span class="bg-white/20 px-2 py-0.5 rounded-lg font-mono text-[11px]">${rs.count} Kalem • ${(rs.amount || 0).toFixed(2)} ₺ ➔</span>
                                    </button>`;
                                }).join('')}
                            </div>
                        </div>
                    ` : '';

                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-emerald-500/20">
                                <i class="fa-solid fa-check animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Günlük Sipariş Başarıyla İletildi! 🎉</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message || `${depo} siparişiniz sisteme kaydedildi.`}</p>
                                ${result.order_info ? `<div class="mt-2.5 inline-block px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-mono font-bold">${result.order_info}</div>` : ''}
                            </div>
                            ${remainingHtml}
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex flex-wrap items-center justify-center gap-2.5 w-full">
                            ${result.portal_url ? `<a href="${result.portal_url}" target="_blank" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-sm"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Depo Panelinde İncele</span></a>` : ''}
                            ${nextDepo ? `
                                <button type="button" onclick="closeBulkFinalizeModal(false)" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Listeye Dön</button>
                                <button type="button" onclick="openBulkFinalizeFlow('${nextDepo}')" class="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white rounded-xl text-xs font-black shadow-md transition flex items-center space-x-1.5 cursor-pointer">
                                    <i class="fa-solid fa-forward-step text-xs"></i>
                                    <span>Sıradaki: ${nextSess.name} Siparişini Sonlandır (${nextSess.count} Kalem) ➔</span>
                                </button>
                            ` : `
                                <button type="button" onclick="closeBulkFinalizeModal(true)" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Tamam</button>
                            `}
                        </div>
                    `;
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sipariş Onaylanamadı</div>
                            <div class="leading-relaxed">${result.message || 'Bilinmeyen bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        async function cleanCartAndSubmitBulk(depo) {
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-10">
                    <i class="fa-solid fa-spinner fa-spin text-4xl text-rose-500 mb-3"></i>
                    <div class="font-black text-slate-800 text-base">Farklı Ürünler Temizleniyor & Günlük Sipariş Hazırlanıyor...</div>
                    <div class="text-xs text-slate-500 mt-1">Önceki yabancı ürünler sepetten çıkarılıyor, ardından sadece bugünkü siparişiniz eklenip depoya gönderilecek...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            const addedItems = (window.currentBulkState && window.currentBulkState.allResults)
                ? window.currentBulkState.allResults
                    .filter(r => (r.status === 'ADDED' || r.status === 'ORDERED') && (!r.assigned_depo || r.assigned_depo === depo))
                    .map(it => ({
                        barcode: it.barcode,
                        name: it.name,
                        miktar: it.miktar,
                        urun_id: it.urun_id || ''
                    }))
                : [];

            try {
                const res = await fetch('/api/cart/bulk-finalize-clean-submit', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: depo,
                        items: addedItems
                    })
                });
                const result = await res.json();

                if (result.success) {
                    showToast('Sipariş Sonlandırıldı', result.message || 'Farklı ürünler çıkarılarak sipariş onaylandı.', 'success');
                    markBulkSessionFinalizedInUI(depo);
                    const remainingDepos = getUnfinalizedBulkDepos();
                    const sessions = (window.currentBulkState && window.currentBulkState.depoSessions) || {};
                    const nextDepo = remainingDepos.length > 0 ? remainingDepos[0] : null;
                    const nextSess = nextDepo ? (sessions[nextDepo] || { name: nextDepo, count: 0, amount: 0 }) : null;
                    const remainingHtml = remainingDepos.length > 0 ? `
                        <div class="p-3.5 rounded-2xl bg-indigo-50 border-2 border-indigo-200 text-left max-w-md mx-auto mt-3">
                            <div class="text-xs font-black text-indigo-950 flex items-center space-x-1.5">
                                <i class="fa-solid fa-layer-group text-indigo-600"></i>
                                <span>Sırada Onay Bekleyen Diğer Depolar (${remainingDepos.length} Depo):</span>
                            </div>
                            <div class="mt-2 space-y-1.5">
                                ${remainingDepos.map(rk => {
                                    const rs = sessions[rk] || { name: rk, count: 0, amount: 0 };
                                    return `<button type="button" onclick="openBulkFinalizeFlow('${rk}')" class="w-full py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold flex items-center justify-between transition cursor-pointer shadow-xs">
                                        <span><i class="fa-solid fa-paper-plane mr-1.5"></i>${rs.name} Siparişini Sonlandır</span>
                                        <span class="bg-white/20 px-2 py-0.5 rounded-lg font-mono text-[11px]">${rs.count} Kalem • ${(rs.amount || 0).toFixed(2)} ₺ ➔</span>
                                    </button>`;
                                }).join('')}
                            </div>
                        </div>
                    ` : '';

                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-emerald-500/20">
                                <i class="fa-solid fa-check animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sadece Günlük Sipariş Başarıyla İletildi! 🎉</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">Farklı ürünler sepetten arındırıldı ve yalnızca bugünkü siparişiniz depoya aktarılıp onaylandı.</p>
                                ${result.order_info ? `<div class="mt-2.5 inline-block px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-mono font-bold">${result.order_info}</div>` : ''}
                            </div>
                            ${remainingHtml}
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex flex-wrap items-center justify-center gap-2.5 w-full">
                            ${result.portal_url ? `<a href="${result.portal_url}" target="_blank" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-sm"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i><span>Depo Panelinde İncele</span></a>` : ''}
                            ${nextDepo ? `
                                <button type="button" onclick="closeBulkFinalizeModal(false)" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Listeye Dön</button>
                                <button type="button" onclick="openBulkFinalizeFlow('${nextDepo}')" class="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white rounded-xl text-xs font-black shadow-md transition flex items-center space-x-1.5 cursor-pointer">
                                    <i class="fa-solid fa-forward-step text-xs"></i>
                                    <span>Sıradaki: ${nextSess.name} Siparişini Sonlandır (${nextSess.count} Kalem) ➔</span>
                                </button>
                            ` : `
                                <button type="button" onclick="closeBulkFinalizeModal(true)" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Tamam</button>
                            `}
                        </div>
                    `;
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>İşlem Tamamlanamadı</div>
                            <div class="leading-relaxed">${result.message || 'Sipariş iletilirken bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }

        async function onlyClearCartFromBulk(depo) {
            const bodyEl = document.getElementById('bulkFinBody');
            const footerEl = document.getElementById('bulkFinFooter');
            if (!bodyEl || !footerEl) return;

            bodyEl.innerHTML = `
                <div class="text-center py-8">
                    <i class="fa-solid fa-spinner fa-spin text-3xl text-rose-500 mb-3"></i>
                    <div class="font-bold text-slate-800 text-sm">Sepet Boşaltılıyor...</div>
                    <div class="text-xs text-slate-400 mt-1">${depo} sepetindeki tüm ürünler siliniyor...</div>
                </div>
            `;
            footerEl.innerHTML = '';

            try {
                const res = await fetch('/api/cart/clear', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ depo: depo })
                });
                const result = await res.json();

                if (result.success) {
                    bodyEl.innerHTML = `
                        <div class="text-center py-6 space-y-4">
                            <div class="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-3xl shadow-lg shadow-rose-500/20">
                                <i class="fa-solid fa-trash-can animate-bounce"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-black text-slate-900">Sepetiniz Başarıyla Boşaltıldı 🗑️</h4>
                                <p class="text-xs text-slate-600 mt-1 font-medium leading-relaxed">${result.message || `${depo} sepetindeki tüm ürünler temizlendi.`}</p>
                                <p class="text-[11px] text-slate-400 mt-1.5 font-bold">Herhangi bir sipariş onaylanmamış veya iletilmemiştir.</p>
                            </div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <div class="flex items-center justify-center space-x-3 w-full">
                            <button type="button" onclick="closeBulkFinalizeModal()" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                        </div>
                    `;
                    showToast('Sepet Boşaltıldı', `${depo} sepetiniz temizlendi (Sipariş verilmedi).`, 'info');
                    markBulkSessionClearedInUI(depo);
                } else {
                    bodyEl.innerHTML = `
                        <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                            <div class="font-bold text-sm mb-1"><i class="fa-solid fa-circle-xmark mr-1.5"></i>Sepet Temizlenemedi</div>
                            <div class="leading-relaxed">${result.message || 'Sepet boşaltılırken bir hata oluştu.'}</div>
                        </div>
                    `;
                    footerEl.innerHTML = `
                        <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                    `;
                }
            } catch (e) {
                bodyEl.innerHTML = `
                    <div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                        <div class="font-bold text-sm mb-1">Ağ / Bağlantı Hatası</div>
                        <div>${e.message}</div>
                    </div>
                `;
                footerEl.innerHTML = `
                    <button type="button" onclick="closeBulkFinalizeModal()" class="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                `;
            }
        }


        async function addSimulatedToCart(btn) {

            if (!currentReport || !selectedDepoForSim) return;
            if (['ECZA1', 'FARMAZON', 'ECZATREND', 'ECZANETAKAS'].includes(selectedDepoForSim)) {
                showToast('Bilgi', 'Pazaryeri ve ortak alım siparişleri doğrudan ilgili platform portalından verilmektedir.', 'error');
                return;
            }

            const miktar = parseInt(simQtyInput.value) || 1;
            const targetItem = currentReport.sonuclar.find(s => s.depo === selectedDepoForSim) || currentReport.sonuclar[0];
            const urunId = targetItem ? (targetItem.urun_id || targetItem.barkod) : currentReport.barkod;
            const barkod = currentReport.barkod;

            const originalContent = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1"></i>Sepete Ekleniyor...`;

            const prodName = (targetItem && (targetItem.urun_adi || targetItem.name)) || ((typeof currentReport !== 'undefined' && currentReport) ? (currentReport.urun_adi || currentReport.name || '') : '');
            try {
                const res = await fetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        depo: selectedDepoForSim,
                        urun_id: urunId,
                        barkod: barkod,
                        miktar: miktar,
                        name: prodName
                    })
                });
                const result = await res.json();
                if (result.success) {
                    let extra = '';
                    if (result.sepet_no) extra += ` (Belge No: ${result.sepet_no})`;
                    if (result.sepet_tutari) extra += ` (Sepet Tutarı: ${result.sepet_tutari} ₺)`;
                    showToast('Simülasyon Sepete Eklendi', `${result.message || `${miktar} kutu ${selectedDepoForSim} sepetine taslak olarak eklendi.`}${extra}`, 'success');
                } else {
                    showToast('Hata', result.message || 'Sepete ekleme başarısız oldu.', 'error');
                }
            } catch (e) {
                showToast('Bağlantı Hatası', e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalContent;
            }
        }

        // ================= Pazaryeri (Farmazon & Ecza1) Teklif Akordiyonu =================
        function toggleOffersRow(index) {
            const row = document.getElementById(`offersRow_${index}`);
            const chevron = document.getElementById(`offersChevron_${index}`);
            if (!row) return;
            if (row.classList.contains('hidden')) {
                row.classList.remove('hidden');
                if (chevron) chevron.style.transform = 'rotate(180deg)';
            } else {
                row.classList.add('hidden');
                if (chevron) chevron.style.transform = 'rotate(0deg)';
            }
        }

"""
