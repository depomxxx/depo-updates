# -*- coding: utf-8 -*-
"""
backend/updater.py
------------------
EDA Depo Otomatik Güncelleme (Auto-Update) Motoru.
1000+ Eczane için merkezi sunucudan (GitHub Releases, AWS S3 veya özel API)
hafif güncelleme paketlerini (~1-2 MB) çeker, doğrular ve güvenle uygular.

GÜVENLİK İLKELERİ:
1. .env (depo kullanıcı adı/şifreleri) ve backend/sessions/ dosyalarına ASLA dokunmaz.
2. products.db ve yerel verileri ezmez.
3. Güncelleme öncesi otomatik yedek alır; hata çıkarsa eski sürüme geri döner (rollback).
"""

import os
import sys
import json
import shutil
import hashlib
import zipfile
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, Tuple

class AutoUpdater:
    def __init__(self, base_dir: Optional[str] = None):
        if base_dir:
            self.base_dir = base_dir
        else:
            # Standalone exe veya script dizini tespiti
            if getattr(sys, 'frozen', False):
                self.base_dir = os.path.dirname(os.path.abspath(sys.executable))
            else:
                self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.version_file = os.path.join(self.base_dir, "version.json")
        self.backup_dir = os.path.join(self.base_dir, "backup")

        # Asla ezilmeyecek veya üzerine yazılmayacak korunan dosyalar/dizinler
        self.PROTECTED_PATTERNS = [
            ".env",
            ".env.local",
            "license.json",
            "data",
            "backend/sessions",
            "backend/data/products.db",
            "runtime",
            "oracle_client",
            "backup"
        ]

    def get_local_version_info(self) -> Dict[str, Any]:
        """Yerel version.json dosyasından mevcut sürüm bilgilerini okur."""
        if os.path.isfile(self.version_file):
            try:
                with open(self.version_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"[Updater] version.json okunamadı: {e}")

        return {
            "version": "1.3.0",
            "app_name": "Farma Radar",
            "channel": "stable",
            "build_date": "2026-10-24",
            "manifest_url": os.environ.get("UPDATE_MANIFEST_URL", "https://raw.githubusercontent.com/depomxxx/depo-updates/main/version.json"),
            "changelog": "Farma Radar kararlı ticari sürüm"
        }

    def _parse_version(self, ver_str: str) -> Tuple[int, ...]:
        """Sürüm metnini ('1.2.4') karşılaştırılabilir integer demetine dönüştürür."""
        clean = ver_str.strip().lstrip("vV")
        parts = []
        for p in clean.split("."):
            num = ""
            for ch in p:
                if ch.isdigit():
                    num += ch
                else:
                    break
            parts.append(int(num) if num else 0)
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts)

    def _discover_lan_manifest(self, current_ver: str) -> Optional[Dict[str, Any]]:
        """Yerel ağdaki (LAN) Merkez/Admin sunucusunda yayınlanmış bir sürüm varsa otomatik bulur."""
        import socket
        import concurrent.futures

        local_ip = "127.0.0.1"
        prefix = "192.168.1"
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            prefix = ".".join(local_ip.split(".")[:3])
        except Exception:
            pass

        priority_ips = [f"{prefix}.197", f"{prefix}.57", f"{prefix}.155", f"{prefix}.100", "127.0.0.1"]
        all_ips = list(dict.fromkeys(priority_ips + [f"{prefix}.{i}" for i in range(1, 255)]))

        def _probe_manifest(ip: str):
            url = f"http://{ip}:8080/releases/version.json"
            try:
                req = urllib.request.Request(url, headers={"User-Agent": f"FarmaRadar-Updater/{current_ver}"})
                with urllib.request.urlopen(req, timeout=0.35) as resp:
                    if resp.status == 200:
                        data = json.loads(resp.read().decode("utf-8"))
                        if data and data.get("version"):
                            return data
            except Exception:
                pass
            return None

        best_data = None
        best_tuple = self._parse_version(current_ver)
        with concurrent.futures.ThreadPoolExecutor(max_workers=64) as ex:
            for res in ex.map(_probe_manifest, all_ips):
                if res:
                    v_t = self._parse_version(res.get("version", "1.0.0"))
                    if v_t >= best_tuple:
                        best_tuple = v_t
                        best_data = res
                        if v_t > self._parse_version(current_ver):
                            break
        return best_data

    def set_manifest_url(self, manifest_url: str, auto_update: Optional[bool] = None) -> Dict[str, Any]:
        """Yerel version.json içindeki manifest_url ve auto_update ayarlarını günceller."""
        info = self.get_local_version_info()
        if manifest_url and manifest_url.strip():
            u = manifest_url.strip()
            if not u.endswith(".json"):
                u = u.rstrip("/") + "/version.json"
            info["manifest_url"] = u
        if auto_update is not None:
            info["auto_update"] = bool(auto_update)
        try:
            with open(self.version_file, "w", encoding="utf-8") as f:
                json.dump(info, f, ensure_ascii=False, indent=2)
            return {"success": True, "manifest_url": info.get("manifest_url"), "auto_update": info.get("auto_update", True)}
        except Exception as e:
            return {"success": False, "message": str(e)}

    def _github_raw_to_api_url(self, raw_url: str) -> Optional[str]:
        """raw.githubusercontent.com URL'sini sıfır önbellekli (anlık) api.github.com contents URL'sine çevirir."""
        if not raw_url or "raw.githubusercontent.com/" not in raw_url:
            return None
        try:
            clean = raw_url.split("?")[0].split("raw.githubusercontent.com/", 1)[1]
            parts = clean.strip("/").split("/")
            if len(parts) >= 4:
                owner, repo, branch = parts[0], parts[1], parts[2]
                file_path = "/".join(parts[3:])
                return f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}?ref={branch}"
        except Exception:
            pass
        return None

    def check_for_updates(self, timeout: float = 2.5) -> Dict[str, Any]:
        """
        Merkezi sunucudan (GitHub Bulut Portalı) VE yerel ağdaki (LAN) Admin dağıtım sunucusundan
        eşzamanlı güncelleme kontrolü yapar. En güncel sürümü hangisinde bulursa onu seçer.
        """
        import time as _time
        local_info = self.get_local_version_info()
        current_ver = local_info.get("version", "1.0.0")
        manifest_url = os.environ.get("UPDATE_MANIFEST_URL") or local_info.get("manifest_url") or "https://raw.githubusercontent.com/depomxxx/depo-updates/main/version.json"

        remote_data = None
        last_err = ""

        # 1. Önce GitHub API (CDN önbelleksiz, 0 saniye gecikmeli) ve Raw URL'den kontrol et
        if manifest_url:
            candidate_urls = []
            api_u = self._github_raw_to_api_url(manifest_url)
            if api_u:
                candidate_urls.append((api_u, True))
            sep = "&" if "?" in manifest_url else "?"
            candidate_urls.append((f"{manifest_url}{sep}t={int(_time.time())}", False))

            for f_url, is_gh_api in candidate_urls:
                try:
                    hdrs = {
                        "User-Agent": f"EDADepo-Updater/{current_ver}",
                        "Cache-Control": "no-cache, no-store, must-revalidate",
                        "Pragma": "no-cache"
                    }
                    if is_gh_api:
                        hdrs["Accept"] = "application/vnd.github.v3.raw"
                    req = urllib.request.Request(f_url, headers=hdrs)
                    with urllib.request.urlopen(req, timeout=timeout) as resp:
                        if resp.status == 200:
                            cand_data = json.loads(resp.read().decode("utf-8"))
                            if cand_data and cand_data.get("version"):
                                if not remote_data or self._parse_version(cand_data["version"]) > self._parse_version(remote_data.get("version", "1.0.0")):
                                    remote_data = cand_data
                                if is_gh_api:
                                    break
                except Exception as e:
                    last_err = str(e)

        # 2. Yalnızca GitHub'a ulaşılamadıysa yerel ağ (LAN) yedeğini kontrol et (Birincil kaynak her zaman GitHub'dır)
        if not remote_data:
            lan_data = self._discover_lan_manifest(current_ver)
            if lan_data and lan_data.get("version"):
                remote_data = lan_data

        if not remote_data:
            return {
                "success": True,
                "update_available": False,
                "current_version": current_ver,
                "manifest_url": manifest_url,
                "auto_update": local_info.get("auto_update", True),
                "message": "Programınız en güncel sürümde."
            }

        remote_ver = remote_data.get("version", "1.0.0")
        is_newer = self._parse_version(remote_ver) > self._parse_version(current_ver)

        return {
            "success": True,
            "update_available": is_newer,
            "current_version": current_ver,
            "latest_version": remote_ver,
            "download_url": remote_data.get("download_url", ""),
            "sha256": remote_data.get("sha256", ""),
            "changelog": remote_data.get("changelog", ""),
            "release_date": remote_data.get("release_date", ""),
            "mandatory": remote_data.get("mandatory", False),
            "manifest_url": manifest_url,
            "auto_update": local_info.get("auto_update", True),
            "message": f"Yeni sürüm ({remote_ver}) mevcut!" if is_newer else "Programınız en güncel sürümde."
        }

    def _is_path_protected(self, rel_path: str) -> bool:
        """Dosya yolunun koruma altında olup olmadığını denetler (.env, şifreler, veritabanı vb.)."""
        norm = rel_path.replace("\\", "/").strip("/").lower()
        for p in self.PROTECTED_PATTERNS:
            p_norm = p.lower()
            if norm == p_norm or norm.startswith(p_norm + "/"):
                return True
        return False

    def apply_update(self, download_url: str, expected_sha256: str = "", new_version: str = "") -> Dict[str, Any]:
        """
        Güncelleme paketini (~1.5 MB zip) indirir, doğrular, mevcut dosyaları yedekler
        ve korunan dosyalar haricindeki kodları (server.py, backend/) günceller.
        """
        if not download_url:
            return {"success": False, "message": "İndirme bağlantısı (download_url) boş."}

        local_info = self.get_local_version_info()
        current_ver = local_info.get("version", "1.0.0")

        temp_zip = os.path.join(self.base_dir, "_temp_update.zip")
        staging_dir = os.path.join(self.base_dir, "_temp_update_extracted")
        backup_folder = os.path.join(self.backup_dir, f"backup_v{current_ver}")

        try:
            print(f"[Updater] Yeni sürüm indiriliyor: {download_url}")
            dl_candidates = [(download_url, False)]
            gh_api_dl = self._github_raw_to_api_url(download_url)
            if gh_api_dl:
                dl_candidates.insert(0, (gh_api_dl, True))

            dl_ok = False
            last_dl_err = None
            for d_url, is_gh_api in dl_candidates:
                try:
                    hdrs = {"User-Agent": f"EDADepo-Updater/{current_ver}"}
                    if is_gh_api:
                        hdrs["Accept"] = "application/vnd.github.v3.raw"
                    req = urllib.request.Request(d_url, headers=hdrs)
                    with urllib.request.urlopen(req, timeout=30) as resp, open(temp_zip, "wb") as out_file:
                        shutil.copyfileobj(resp, out_file)
                    dl_ok = True
                    break
                except Exception as de:
                    last_dl_err = de
            if not dl_ok:
                raise RuntimeError(f"Paket indirilemedi: {last_dl_err}")

            # SHA256 Doğrulama (Eğer hash verilmişse)
            if expected_sha256:
                h = hashlib.sha256()
                with open(temp_zip, "rb") as f:
                    while chunk := f.read(65536):
                        h.update(chunk)
                downloaded_hash = h.hexdigest().lower()
                if downloaded_hash != expected_sha256.lower().strip():
                    if os.path.exists(temp_zip):
                        os.remove(temp_zip)
                    return {"success": False, "message": f"SHA256 hash uyuşmazlığı! Beklenen: {expected_sha256}, İndirilen: {downloaded_hash}"}

            # Zip'i geçici klasöre aç
            if os.path.exists(staging_dir):
                shutil.rmtree(staging_dir, ignore_errors=True)
            os.makedirs(staging_dir, exist_ok=True)

            with zipfile.ZipFile(temp_zip, "r") as z:
                z.extractall(staging_dir)

            # Paket içindeki version.json'dan gerçek sürümü oku
            staged_ver = ""
            staged_v_file = os.path.join(staging_dir, "version.json")
            if os.path.isfile(staged_v_file):
                try:
                    with open(staged_v_file, "r", encoding="utf-8") as sf:
                        staged_ver = json.load(sf).get("version", "")
                except Exception:
                    pass

            # Mevcut kodları yedekle (Rollback güvencesi - kilitli klasör varsa güncellemeyi engelleme)
            try:
                os.makedirs(backup_folder, exist_ok=True)
                if os.path.isfile(os.path.join(self.base_dir, "server.py")):
                    shutil.copy2(os.path.join(self.base_dir, "server.py"), os.path.join(backup_folder, "server.py"))
                if os.path.isdir(os.path.join(self.base_dir, "backend")):
                    target_backend_backup = os.path.join(backup_folder, "backend")
                    if os.path.exists(target_backend_backup):
                        shutil.rmtree(target_backend_backup, ignore_errors=True)
                    # Sadece python kodlarını yedekle (dirs_exist_ok=True ile WinError 183 önlenir)
                    shutil.copytree(
                        os.path.join(self.base_dir, "backend"),
                        target_backend_backup,
                        ignore=shutil.ignore_patterns("sessions", "data", "*.db*", "*.sqlite*", "*.xlsx", "__pycache__"),
                        dirs_exist_ok=True
                    )
            except Exception as bk_err:
                print(f"[Updater] Yedekleme uyarısı (güncellemeye devam ediliyor): {bk_err}")

            # Dosyaları güncelle (Korunan dosyaları ASLA ezme!)
            updated_files_count = 0
            for root, dirs, files in os.walk(staging_dir):
                for file_name in files:
                    src_path = os.path.join(root, file_name)
                    rel_path = os.path.relpath(src_path, staging_dir)

                    if self._is_path_protected(rel_path):
                        print(f"[Updater] Korunan dosya atlandı (ezilmedi): {rel_path}")
                        continue

                    dest_path = os.path.join(self.base_dir, rel_path)
                    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                    shutil.copy2(src_path, dest_path)
                    updated_files_count += 1

            # version.json dosyasını yeni sürüm bilgileriyle (changelog, manifest_url dahil) güncelle
            updated_info = self.get_local_version_info()
            target_version = staged_ver or new_version or updated_info.get("version") or "1.3.0"
            updated_info["version"] = target_version
            updated_info["app_name"] = "Farma Radar"
            updated_info["manifest_url"] = updated_info.get("manifest_url") or "https://raw.githubusercontent.com/depomxxx/depo-updates/main/version.json"
            updated_info["auto_update"] = True
            updated_info["updated_at"] = time_now_str()
            with open(self.version_file, "w", encoding="utf-8") as f:
                json.dump(updated_info, f, ensure_ascii=False, indent=2)

            print(f"[Updater] Başarıyla güncellendi! Toplam {updated_files_count} dosya yenilendi. Yeni sürüm: {target_version}")
            return {
                "success": True,
                "message": f"Sürüm {target_version} başarıyla kuruldu.",
                "new_version": target_version,
                "files_updated": updated_files_count
            }

        except Exception as e:
            # Hata durumunda yedekten geri al (Rollback)
            print(f"[Updater] Güncelleme sırasında hata oluştu, geri alınıyor: {e}")
            try:
                if os.path.exists(backup_folder):
                    bk_server = os.path.join(backup_folder, "server.py")
                    if os.path.isfile(bk_server):
                        shutil.copy2(bk_server, os.path.join(self.base_dir, "server.py"))
                    bk_backend = os.path.join(backup_folder, "backend")
                    if os.path.isdir(bk_backend):
                        for root, _, files in os.walk(bk_backend):
                            for f in files:
                                s = os.path.join(root, f)
                                r = os.path.relpath(s, bk_backend)
                                d = os.path.join(self.base_dir, "backend", r)
                                os.makedirs(os.path.dirname(d), exist_ok=True)
                                shutil.copy2(s, d)
            except Exception as rollback_err:
                print(f"[Updater] Rollback hatası: {rollback_err}")

            return {
                "success": False,
                "message": f"Güncelleme uygulanamadı: {str(e)}"
            }
        finally:
            # Geçici dosyaları temizle
            if os.path.exists(temp_zip):
                try:
                    os.remove(temp_zip)
                except Exception:
                    pass
            if os.path.exists(staging_dir):
                try:
                    shutil.rmtree(staging_dir, ignore_errors=True)
                except Exception:
                    pass

def time_now_str() -> str:
    import datetime
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Singleton instance
updater = AutoUpdater()
