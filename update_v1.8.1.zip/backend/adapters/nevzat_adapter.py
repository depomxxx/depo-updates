import asyncio
import json
import re
from typing import List, Optional, Dict, Any
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.core.cost_calculator import CostCalculator
from backend.core.session_store import SessionStore
try:
    from backend.catalog import catalog
except Exception:
    catalog = None

def clean_float(val: Any) -> float:
    if val is None or val == "":
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).replace("₺", "").replace("TL", "").strip()
    if not s:
        return 0.0
    if "." in s and "," in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except Exception:
        return 0.0

def _parse_cart_adet(val: Any) -> Dict[str, Any]:
    """SepetDoldur'dan dönen 'adet' değerini ('1', '8+2', '10 + 1' vb.) güvenli şekilde ayrıştırır."""
    raw = str(val if val is not None else "1").strip()
    if not raw:
        raw = "1"
    if "+" in raw:
        parts = [p.strip() for p in raw.split("+") if p.strip()]
        try:
            alinan = int(float(parts[0].replace(",", "."))) if parts else 1
        except Exception:
            alinan = 1
        try:
            hediye = int(float(parts[1].replace(",", "."))) if len(parts) > 1 else 0
        except Exception:
            hediye = 0
        alinan = max(1, alinan)
        hediye = max(0, hediye)
        return {
            "miktar": alinan,
            "mf_hediye": hediye,
            "toplam_adet": alinan + hediye,
            "adet_label": f"{alinan}+{hediye}" if hediye > 0 else str(alinan)
        }
    try:
        m = max(1, int(float(raw.replace(",", "."))))
    except Exception:
        m = 1
    return {
        "miktar": m,
        "mf_hediye": 0,
        "toplam_adet": m,
        "adet_label": str(m)
    }

class NevzatAdapter(BaseDepoAdapter):
    BASE_URL = "http://webdepo.nevzatecza.com.tr/Login.aspx"
    MAIN_URL = "http://webdepo.nevzatecza.com.tr/Siparis/hizlisiparis.aspx"

    def __init__(self, account_code: str = "", username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.NEVZAT, "Nevzat Ecza Deposu")
        self.account_code = account_code
        self.username = username
        self.password = password
        self.headless = headless
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
        self._lock = asyncio.Lock()
        self._cart_busy: int = 0
        self._last_added_items: List[Dict[str, Any]] = []
        self._last_added_time: float = 0.0
        self._fast_cart_cache: Dict[str, Dict[str, Any]] = {}

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-setuid-sandbox"]
            )
            
            session_file = SessionStore.get_session_file("nevzat")
            if session_file.exists():
                try:
                    self._context = await self._browser.new_context(storage_state=str(session_file))
                except Exception:
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()
                
            self._page = await self._context.new_page()

    async def is_session_valid(self) -> bool:
        if not self._page:
            await self._init_browser()
            
        try:
            cur_path = (self._page.url or "").split("?")[0].lower()
            if "hizlisiparis" in cur_path and "login.aspx" not in cur_path:
                has_jq = await self._page.evaluate("() => typeof window.jQuery !== 'undefined' && !document.querySelector('#txtEczaneKodu')")
                if has_jq:
                    return True

            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            cur_path = (self._page.url or "").split("?")[0].lower()
            if "login.aspx" in cur_path:
                return False
            has_login_input = await self._page.evaluate("() => !!document.querySelector('#txtEczaneKodu')")
            return not has_login_input
        except Exception:
            return False

    async def _login_unlocked(self) -> bool:
        """Nevzat WebDepo'ya giriş yapar (kilit içinde çağrılır)."""
        if not self.account_code or not self.username or not self.password:
            raise ValueError("Nevzat için Hesap Kodu, Kullanıcı Adı ve Şifre zorunludur.")

        await self._init_browser()
        
        if await self.is_session_valid():
            print("[Nevzat] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            return True

        print("[Nevzat] Giriş yapılıyor...")
        await self._page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=15000)
        cur_path = (self._page.url or "").split("?")[0].lower()
        if "login.aspx" not in cur_path:
            self.is_logged_in = True
            return True

        try:
            await self._page.wait_for_selector("#txtEczaneKodu", timeout=6000)
            await self._page.fill("#txtEczaneKodu", str(self.account_code))
            await self._page.fill("#txtKullaniciAdi", str(self.username))
            await self._page.fill("#txtSifre", str(self.password))
            await self._page.click("#btnGiris")
            await self._page.wait_for_load_state("domcontentloaded")
            await asyncio.sleep(1.2)
        except Exception as e:
            if "login.aspx" in (self._page.url or "").lower():
                raise RuntimeError(f"Nevzat Giriş Başarısız: {e}")

        session_file = SessionStore.get_session_file("nevzat")
        await self._context.storage_state(path=str(session_file))
        print("[Nevzat] Başarıyla giriş yapıldı ve oturum kaydedildi.")
        self.is_logged_in = True
        return True

    async def login(self) -> bool:
        async with self._lock:
            return await self._login_unlocked()

    async def _ensure_ready_page(self, allow_sepet_page: bool = False):
        if not self._page:
            await self._init_browser()
        cur_path = (self._page.url or "").split("?")[0].lower()
        if not cur_path or cur_path == "about:blank" or "login.aspx" in cur_path:
            self.is_logged_in = False
            await self._login_unlocked()
            cur_path = (self._page.url or "").split("?")[0].lower()

        is_ok_page = ("hizlisiparis" in cur_path) or (allow_sepet_page and ("sepet.aspx" in cur_path or "siparisonay.aspx" in cur_path))
        if not is_ok_page:
            await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)
            cur_path = (self._page.url or "").split("?")[0].lower()
            if "login.aspx" in cur_path:
                self.is_logged_in = False
                await self._login_unlocked()
                await self._page.goto(self.MAIN_URL, wait_until="domcontentloaded", timeout=12000)

        for _ in range(10):
            try:
                has_jq = await self._page.evaluate("() => typeof window.jQuery !== 'undefined'")
                if has_jq:
                    break
            except Exception:
                pass
            await asyncio.sleep(0.08)

    async def search_product(self, query: str, include_equivalents: bool = True, is_background: bool = False) -> List[DepoUrunSarti]:
        """Ürün ara ve şartları getir (Tek seferlik paralel AJAX motoru)."""
        if is_background and self._cart_busy > 0:
            return []
        async with self._lock:
            if is_background and self._cart_busy > 0:
                return []
            if not self.is_logged_in:
                await self._login_unlocked()

            await self._ensure_ready_page()
            clean_q = str(query or "").strip()
            if not is_background:
                print(f"[Nevzat] '{clean_q}' sorgulanıyor...")

            fallback_text = ""
            target_barcode = ""
            if clean_q.isdigit() and len(clean_q) >= 8:
                target_barcode = clean_q
                if catalog:
                    prod = catalog.get_by_barcode(clean_q)
                    if not prod and len(clean_q) == 14 and clean_q.startswith("0"):
                        prod = catalog.get_by_barcode(clean_q[1:])
                    if prod and prod.get("name"):
                        words = re.sub(r'[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]', ' ', prod["name"]).strip().split()
                        if len(words) >= 2:
                            fallback_text = f"{words[0]} {words[1]}"
                        elif words:
                            fallback_text = words[0]

            # Tek evaluate çağrısında hem GetUrunler hem de paralel GetIlacDetay sorgularını çalıştır
            batch_res = await self._page.evaluate("""async (param) => {
                function postAjax(url, data) {
                    return new Promise((resolve) => {
                        $.ajax({
                            type: "POST",
                            url: url,
                            timeout: 7000,
                            data: data,
                            success: function(d) {
                                try {
                                    resolve(typeof d === 'string' ? JSON.parse(d) : d);
                                } catch(e) { resolve(null); }
                            },
                            error: function() { resolve(null); }
                        });
                    });
                }

                // 1. Önce doğrudan barkod veya aranan kelime ile sorgula (Selçuk gibi hızlı ve nokta atışı)
                let res = await postAjax("/Siparis/hizlisiparis-ajax.aspx", {
                    action: "GetUrunler",
                    searchText: param.primaryQuery,
                    isInculude: true,
                    isStoktakiler: false,
                    siralama: "ilacASC",
                    marka: "",
                    baslangicSayfasi: 0,
                    topRowNum: 0,
                    sayfaMaxRowAdet: 5,
                    s: "s"
                });

                let urunler = (res && res.obj && res.obj.urunler) ? res.obj.urunler : [];

                // 2. Eğer barkodla çıkmadıysa aynı çağrı içinde ürün adıyla fallback yap
                if (urunler.length === 0 && param.fallbackText && param.fallbackText !== param.primaryQuery) {
                    res = await postAjax("/Siparis/hizlisiparis-ajax.aspx", {
                        action: "GetUrunler",
                        searchText: param.fallbackText,
                        isInculude: true,
                        isStoktakiler: false,
                        siralama: "ilacASC",
                        marka: "",
                        baslangicSayfasi: 0,
                        topRowNum: 0,
                        sayfaMaxRowAdet: 6,
                        s: "s"
                    });
                    urunler = (res && res.obj && res.obj.urunler) ? res.obj.urunler : [];
                }

                if (urunler.length === 0) return [];

                // 3. Adayların detaylarını paralel (Promise.all) olarak tek seferde çek
                const slice = urunler.slice(0, 5);
                const details = await Promise.all(slice.map(async (u) => {
                    const d = await postAjax("/Ilac/IlacGetir-ajax.aspx", {
                        action: "GetIlacDetay",
                        kod: u.kodu,
                        isEsdeger: false,
                        esdeger: "",
                        isJenerik: false,
                        jenerikId: "",
                        tip: null,
                        ILACTIP: u.ILACTIP || "B",
                        kampKodu: ""
                    });
                    return { u: u, d: (d && d.obj) ? d.obj : null };
                }));

                return details.filter(x => x.d !== null);
            }""", {"primaryQuery": clean_q, "fallbackText": fallback_text})

            if not batch_res:
                return []

            sonuclar: List[DepoUrunSarti] = []
            for item in batch_res:
                u = item["u"]
                detay_obj = item["d"]
                sarti = self._parse_nevzat_detay(u, detay_obj, query)

                # Hızlı sepet önbelleğine kaydet (Sepete Ekle tıklandığında 0 arama ile anında ekler)
                kod_str = str(u.get("kodu") or "").strip()
                kamp = (detay_obj.get("kampanyalar") or [{}])[0] if detay_obj.get("kampanyalar") else {}
                grd = (detay_obj.get("grdKampanyalar") or [{}])[0] if detay_obj.get("grdKampanyalar") else {}
                satis_sekli = grd.get("satisSekli") or kamp.get("satisSekli") or detay_obj.get("satisSekli") or "E3"
                etiket_raw = grd.get("etiketFiyati") or detay_obj.get("SonFiyat") or detay_obj.get("etiketFiyati") or "0"
                cep_sube = kamp.get("cepSube") or grd.get("cepSube") or detay_obj.get("cepSube") or "01"
                cache_entry = {
                    "kod": kod_str,
                    "ilacTipi": u.get("ILACTIP") or "B",
                    "satisSekli": satis_sekli,
                    "etiketStr": str(etiket_raw).replace(".", ","),
                    "cepSube": cep_sube,
                    "ad": detay_obj.get("ad") or u.get("ad") or "",
                    "satilabilir": bool(detay_obj.get("satilabilir", True))
                }
                if kod_str:
                    self._fast_cart_cache[kod_str] = cache_entry
                detay_bc = str(detay_obj.get("barkod") or "").strip()
                if detay_bc:
                    self._fast_cart_cache[detay_bc] = cache_entry
                    self._fast_cart_cache[detay_bc.lstrip("0")] = cache_entry

                if target_barcode:
                    clean_target = target_barcode.lstrip("0")
                    clean_detay = detay_bc.lstrip("0")
                    if clean_target and clean_detay and (clean_target == clean_detay or clean_target in clean_detay or clean_detay in clean_target):
                        sarti.barkod = target_barcode
                        self._fast_cart_cache[target_barcode] = cache_entry
                        sonuclar.insert(0, sarti)
                        continue
                sonuclar.append(sarti)

            if target_barcode:
                exact_matches = [s for s in sonuclar if s.barkod == target_barcode]
                if exact_matches:
                    return exact_matches[:3]

            return sonuclar[:5]

    def _parse_nevzat_detay(self, basic_info: Dict[str, Any], detail: Dict[str, Any], query: str) -> DepoUrunSarti:
        kod = str(basic_info.get("kodu", ""))
        ad = detail.get("ad") or basic_info.get("ad", "")
        barkod = detail.get("barkod") or query
        
        stok_durumu_val = basic_info.get("stokDurumu", 0)
        stok_durumu = StokDurumu.VAR if stok_durumu_val == 1 else StokDurumu.YOK

        dsf = clean_float(detail.get("depocuFiyati"))
        psf = clean_float(detail.get("SonFiyat") or detail.get("etiketFiyati"))
        kdv_dict = detail.get("kdv") or {}
        kdv_orani = clean_float(kdv_dict.get("val1") or 10.0)
        kurum_isk = clean_float(detail.get("kurumIskontosu"))
        eczaci_kari = clean_float(detail.get("kar"))
        is_soguk = str(detail.get("saklamastr") or "").lower() in ["soğuk", "soguk", "soğuk zincir"] or str(detail.get("saklama") or "").upper() == "S"

        grd_kampanyalar = detail.get("grdKampanyalar") or []
        mf_text = "YOK"
        vade = 30
        en_iyi_net = dsf
        ticari_iskonto = 0.0
        kampanya_notu = ""

        if grd_kampanyalar:
            g_kamp = grd_kampanyalar[0]
            vade = int(g_kamp.get("gün") or 30)
            
            top_isk = str(g_kamp.get("topIsk", "0"))
            if "+" in top_isk:
                parts = top_isk.split("+")
                ticari_iskonto = sum(clean_float(p) for p in parts)
            else:
                ticari_iskonto = clean_float(top_isk)

            # MF HTML'den ayrıştır (hediye > 0 olan gerçek MF kademelerini al, 10+0 gibi sahte kademeleri ele)
            mf_html = g_kamp.get("mf", "")
            if mf_html:
                soup = BeautifulSoup(mf_html, "html.parser")
                raw_pairs = re.findall(r'(\d+)\s*\+\s*(\d+)', soup.get_text(" ") or mf_html)
                valid_mfs = []
                for a_str, h_str in raw_pairs:
                    try:
                        a_val, h_val = int(a_str), int(h_str)
                        if a_val > 0 and h_val > 0:
                            pair_lbl = f"{a_val}+{h_val}"
                            if pair_lbl not in valid_mfs:
                                valid_mfs.append(pair_lbl)
                    except Exception:
                        pass
                if valid_mfs:
                    mf_text = " / ".join(valid_mfs)

            if mf_text == "YOK":
                kamp_list = detail.get("kampanyalar") or []
                if kamp_list:
                    k0 = kamp_list[0]
                    k_miks = k0.get("miktar") or []
                    k_mfs = k0.get("mf") or []
                    valid_k_mfs = []
                    for m_v, f_v in zip(k_miks, k_mfs):
                        try:
                            if int(m_v) > 0 and int(f_v) > 0:
                                lbl = f"{int(m_v)}+{int(f_v)}"
                                if lbl not in valid_k_mfs:
                                    valid_k_mfs.append(lbl)
                        except Exception:
                            pass
                    if valid_k_mfs:
                        mf_text = " / ".join(valid_k_mfs)

            # Net Fiyat
            if g_kamp.get("mf1Fiyat"):
                en_iyi_net = clean_float(g_kamp.get("mf1Fiyat"))
            elif g_kamp.get("netFiyat"):
                soup_fiyat = BeautifulSoup(g_kamp.get("netFiyat"), "html.parser")
                fiyats = [clean_float(s.get_text(strip=True)) for s in soup_fiyat.find_all("span")]
                float_fiyats = [f for f in fiyats if f > 0]
                if float_fiyats:
                    en_iyi_net = min(float_fiyats)

        # İskonto birleştirme: Kurum İskontosu ve Ticari İskonto
        birlesik_carpan = (1.0 - (kurum_isk / 100.0)) * (1.0 - (ticari_iskonto / 100.0))
        birlesik_iskonto = round((1.0 - birlesik_carpan) * 100.0, 2)

        if dsf > 0 and en_iyi_net > 0 and en_iyi_net < (dsf - 0.01):
            derived_disc = round((1.0 - (en_iyi_net / dsf)) * 100.0, 2)
            if mf_text == "YOK":
                birlesik_iskonto = max(birlesik_iskonto, derived_disc)

        notlar = [f"{vade} Gün Vade"]
        if mf_text != "YOK":
            notlar.append(f"MF: {mf_text}")
        if ticari_iskonto > 0:
            notlar.append(f"İsk: %{ticari_iskonto}")
        if kurum_isk > 0:
            notlar.append(f"Kamu İsk: %{kurum_isk}")
        kampanya_notu = " • ".join(notlar)

        maliyet = CostCalculator.calculate(
            dsf=dsf if dsf > 0 else en_iyi_net,
            psf=psf,
            kdv_orani=kdv_orani,
            mf_str=mf_text,
            ticari_iskonto=birlesik_iskonto,
            vade_gun=vade
        )

        final_net = min(en_iyi_net, maliyet.net_birim_maliyet) if (en_iyi_net > 0 and maliyet.net_birim_maliyet > 0) else maliyet.net_birim_maliyet
        final_net_kdvli = round(final_net * (1.0 + (kdv_orani / 100.0)), 2)

        return DepoUrunSarti(
            depo=DepoKodu.NEVZAT,
            depo_adi=self.depo_adi,
            barkod=barkod,
            urun_id=kod,
            urun_adi=ad,
            stok_durumu=stok_durumu,
            stok_adedi=None,
            depocu_satis_fiyati=round(dsf, 2),
            perakende_satis_fiyati=round(psf, 2),
            kdv_orani=kdv_orani,
            mf_metni=mf_text,
            kademeler=maliyet.kademeler,
            ticari_iskonto=ticari_iskonto,
            vade_gun=vade,
            net_birim_maliyet=round(final_net, 2),
            net_birim_maliyet_kdvli=final_net_kdvli,
            toplam_indirim_yuzdesi=round((1.0 - (final_net / dsf)) * 100.0, 2) if dsf > 0 else 0.0,
            ozel_kampanya_notu=kampanya_notu,
            soguk_zincir=is_soguk,
            kamu_iskontosu=kurum_isk,
            eczaci_kari=eczaci_kari
        )

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """Nevzat Ecza sepetine ürün ekler (Doğrudan ve Hızlı AJAX Motoru)."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._add_to_cart_unlocked(urun_id=urun_id, miktar=miktar, **kwargs)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def _add_to_cart_unlocked(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        if not self.is_logged_in:
            await self._login_unlocked()
        await self._ensure_ready_page()

        target_kod = str(urun_id or "").strip()
        barkod = str(kwargs.get("barkod") or kwargs.get("barcode") or "").strip()
        if len(barkod) == 14 and barkod.startswith("0"):
            barkod = barkod[1:]
        satis_sekli = str(kwargs.get("satis_sekli") or "").strip()
        ilac_tipi = str(kwargs.get("ilac_tipi") or "B").strip()
        product_name = str(kwargs.get("name") or kwargs.get("urun_adi") or "").strip()

        # Önbellekte (arama sırasında alınmış) hazır ürün bilgisi var mı kontrol et
        cached = self._fast_cart_cache.get(target_kod) or (self._fast_cart_cache.get(barkod) if barkod else None)

        if not product_name and catalog and not cached:
            lookup_bc = barkod or (target_kod if (target_kod.isdigit() and len(target_kod) >= 8) else "")
            if lookup_bc:
                prod = catalog.get_by_barcode(lookup_bc)
                if not prod and len(lookup_bc) == 14 and lookup_bc.startswith("0"):
                    prod = catalog.get_by_barcode(lookup_bc[1:])
                if prod and prod.get("name"):
                    product_name = prod["name"]

        res = await self._page.evaluate("""async (param) => {
            function postAsync(url, data, isJson = true) {
                return new Promise((resolve) => {
                    $.ajax({
                        type: 'POST',
                        url: url,
                        timeout: 7000,
                        data: data,
                        dataType: isJson ? 'json' : undefined,
                        success: function(resp) {
                            try {
                                resolve(typeof resp === 'string' && isJson ? JSON.parse(resp) : resp);
                            } catch(e) { resolve(resp); }
                        },
                        error: function(err) {
                            resolve({ error: true, statusText: err.statusText });
                        }
                    });
                });
            }

            async function getSepet() {
                const s = await postAsync('/Ilac/IlacGetir-ajax.aspx', 'action=SepetDoldur', true);
                return (s && s.obj) ? s.obj : { Siparisler: [], topTutar: 0 };
            }

            async function removeExistingIfNeeded(kod, desiredMiktar, forceRemove = false) {
                const sObj = await getSepet();
                const list = sObj.Siparisler || [];
                const found = list.find(x => String(x.ilacKodu || x.kod) === String(kod));
                if (!found) return { existed: false, matched: false, item: null, sObj };
                const baseQty = parseInt(String(found.adet || '1').split('+')[0].trim(), 10) || 1;
                if (!forceRemove && baseQty === desiredMiktar) {
                    return { existed: true, matched: true, item: found, sObj };
                }
                if (found.id) {
                    await postAsync('/Ilac/IlacGetir-ajax.aspx', 'action=SeciliOlanlariSil&kodlar=' + found.id + ';', true);
                }
                return { existed: true, matched: false, item: null, sObj };
            }

            let targetKod = param.kod || '';
            let ilacTipi = param.ilacTipi || 'B';
            let targetBarcode = param.barkod || '';
            let productName = param.productName || '';
            let cached = param.cached || null;

            if (cached && cached.kod) {
                targetKod = String(cached.kod);
                ilacTipi = cached.ilacTipi || ilacTipi;
            }

            // 1. Ürün kodunu çöz: Eğer targetKod zaten <=7 haneli geçerli bir Nevzat ilaç koduysa arama yapma!
            if (!targetKod || targetKod.length > 7 || isNaN(targetKod)) {
                let searchTarget = targetBarcode || targetKod;
                let candidates = [];
                if (searchTarget) {
                    let searchRes = await postAsync("/Siparis/hizlisiparis-ajax.aspx", {
                        action: "GetUrunler",
                        searchText: searchTarget,
                        isInculude: true,
                        isStoktakiler: false,
                        siralama: "ilacASC",
                        marka: "",
                        baslangicSayfasi: 0,
                        topRowNum: 0,
                        sayfaMaxRowAdet: 5,
                        s: "s"
                    });
                    if (searchRes && searchRes.obj && searchRes.obj.urunler) {
                        candidates = searchRes.obj.urunler;
                    }
                    if (candidates.length === 0 && searchTarget.length === 13) {
                        searchRes = await postAsync("/Siparis/hizlisiparis-ajax.aspx", {
                            action: "GetUrunler",
                            searchText: "0" + searchTarget,
                            isInculude: true,
                            isStoktakiler: false,
                            siralama: "ilacASC",
                            marka: "",
                            baslangicSayfasi: 0,
                            topRowNum: 0,
                            sayfaMaxRowAdet: 5,
                            s: "s"
                        });
                        if (searchRes && searchRes.obj && searchRes.obj.urunler) {
                            candidates = searchRes.obj.urunler;
                        }
                    }
                }
                if (candidates.length === 0 && productName) {
                    const cleanWords = productName.replace(/[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]/g, ' ').trim().split(/\\s+/).slice(0, 2).join(' ');
                    if (cleanWords.length >= 2) {
                        let searchRes = await postAsync("/Siparis/hizlisiparis-ajax.aspx", {
                            action: "GetUrunler",
                            searchText: cleanWords,
                            isInculude: true,
                            isStoktakiler: false,
                            siralama: "ilacASC",
                            marka: "",
                            baslangicSayfasi: 0,
                            topRowNum: 0,
                            sayfaMaxRowAdet: 5,
                            s: "s"
                        });
                        if (searchRes && searchRes.obj && searchRes.obj.urunler) {
                            candidates = searchRes.obj.urunler;
                        }
                    }
                }
                if (candidates.length > 0) {
                    targetKod = candidates[0].kodu;
                    ilacTipi = candidates[0].ILACTIP || ilacTipi;
                }
            }

            if (!targetKod || targetKod.length > 7) {
                return { success: false, message: 'Nevzat deposunda ürün kodu tespit edilemedi.' };
            }

            // Eğer ürün zaten sepette aynı miktarla varsa tekrar ekleme hatasına (hataId:9) düşme, farklı miktarsa eskisini sil
            const preCheck = await removeExistingIfNeeded(targetKod, param.miktar, false);
            if (preCheck.matched && preCheck.item) {
                const list = preCheck.sObj.Siparisler || [];
                return {
                    success: true,
                    depo: 'NEVZAT',
                    message: (preCheck.item.ilacAdi || 'Ürün') + ' (' + preCheck.item.adet + ' adet) Nevzat Ecza sepetinde hazır.',
                    urun_adi: preCheck.item.ilacAdi || '',
                    urun_kodu: targetKod,
                    miktar: preCheck.item.adet || param.miktar,
                    cart_count: list.length,
                    cart_total: preCheck.sObj.topTutar || null
                };
            }

            // 2. GetIlacDetay
            const detayVeri = await postAsync('/Ilac/IlacGetir-ajax.aspx', {
                action: 'GetIlacDetay',
                kod: targetKod,
                isEsdeger: false,
                esdeger: '',
                isJenerik: false,
                jenerikId: '',
                tip: null,
                ILACTIP: ilacTipi,
                kampKodu: ''
            });

            if (!detayVeri || !detayVeri.obj) {
                return { success: false, message: 'Nevzat ürün detayı alınamadı.' };
            }

            const obj = detayVeri.obj;
            if (!obj.satilabilir) {
                return { success: false, message: (obj.ad || 'Bu ürün') + ' şu an Nevzat deposunda satılabilir durumda değil (Stok Yok/Pasif).' };
            }

            const kamp = (obj.kampanyalar && obj.kampanyalar.length > 0) ? obj.kampanyalar[0] : {};
            const grd = (obj.grdKampanyalar && obj.grdKampanyalar.length > 0) ? obj.grdKampanyalar[0] : {};

            let satisSekli = param.satisSekli || grd.satisSekli || kamp.satisSekli || obj.satisSekli || 'E3';
            let etiketRaw = grd.etiketFiyati || obj.SonFiyat || obj.etiketFiyati || '0';
            let etiketStr = String(etiketRaw).replace('.', ',');

            async function tryAdd(targetSatisSekli) {
                let cepSube = (kamp && kamp.cepSube) || (grd && grd.cepSube) || obj.cepSube || '01';
                let subeMiktar = param.miktar;

                // WebDepo standart akışı: Önce GetSubeler çağrılır.
                // Şube stoğu tam karşılıyorsa GetSubeler ürünü doğrudan sepete ekler ve obj:null döner.
                // Şube stoğu kısıtlıysa veya cep şube gerekiyorsa obj:[{cepSube, karsilanacak, ...}] döner ve SiparisEkle çağrılır.
                const subelerData = 'action=GetSubeler&kod=' + targetKod +
                    '&miktar=' + param.miktar +
                    '&satisSekli=' + targetSatisSekli +
                    '&etiketFiyati=' + encodeURIComponent(etiketStr) +
                    '&miad=&onerilenFiyat=&tip=&ILACTIP=' + ilacTipi +
                    '&ekstraMf=&ekstraIskonto=&siparisNotu=';
                let subeler = await postAsync('/Ilac/IlacGetir-ajax.aspx', subelerData, true);

                if (subeler && (subeler.hataId === 9 || (subeler.hataStr && subeler.hataStr.includes('mevcuttur')))) {
                    await removeExistingIfNeeded(targetKod, param.miktar, true);
                    subeler = await postAsync('/Ilac/IlacGetir-ajax.aspx', subelerData, true);
                }

                if (subeler && subeler.hataId === 0) {
                    if (!subeler.obj || (Array.isArray(subeler.obj) && subeler.obj.length === 0)) {
                        // GetSubeler doğrudan sepete eklemiş olabilir, kontrol et
                        const checkS = await getSepet();
                        const inCart = (checkS.Siparisler || []).find(x => String(x.ilacKodu || x.kod) === String(targetKod));
                        if (inCart) {
                            return { success: true, item: inCart, sObj: checkS };
                        }
                    } else if (Array.isArray(subeler.obj) && subeler.obj.length > 0) {
                        const validBranches = subeler.obj.filter(b => {
                            const kVal = parseInt(String(b.karsilanacak || '0').split('+')[0].trim(), 10) || 0;
                            return kVal > 0;
                        });
                        const branch = validBranches.find(b => b.chk) || validBranches.find(b => b.kendiCep === '1') || validBranches[0] || subeler.obj[0];
                        if (branch && branch.cepSube) cepSube = branch.cepSube;
                        if (branch && branch.karsilanacak !== undefined && branch.karsilanacak !== null) {
                            let k = String(branch.karsilanacak);
                            if (k.includes('+')) k = k.split('+')[0];
                            const parsedK = parseInt(k.trim(), 10);
                            if (!isNaN(parsedK) && parsedK > 0) {
                                subeMiktar = parsedK;
                            } else if (parsedK === 0) {
                                return { success: false, hataStr: (obj.ad || 'Ürün') + ' için şubede karşılanabilecek stok bulunamadı.' };
                            }
                        }
                    }
                } else if (subeler && subeler.hataStr) {
                    return { success: false, hataStr: subeler.hataStr };
                }

                const ekleData = 'action=SiparisEkle&kod=' + targetKod +
                    '&miktar=' + subeMiktar +
                    '&satisSekli=' + targetSatisSekli +
                    '&etiketFiyati=' + encodeURIComponent(etiketStr) +
                    '&depoId=' + cepSube +
                    '&miad=&onerilenFiyat=&tip=&ILACTIP=' + ilacTipi +
                    '&ekstraMf=&ekstraIskonto=&siparisNotu=';

                const ekleRes = await postAsync('/Ilac/IlacGetir-ajax.aspx', ekleData, true);
                if (!ekleRes || ekleRes.hataId !== 0) {
                    return { success: false, hataStr: (ekleRes && ekleRes.hataStr) || 'Sepete ekleme reddedildi.' };
                }

                const finalS = await getSepet();
                const finalItem = (finalS.Siparisler || []).find(x => String(x.ilacKodu || x.kod) === String(targetKod));
                if (!finalItem) {
                    return { success: false, hataStr: (obj.ad || 'Ürün') + ' istenen miktarda (' + param.miktar + ') şube stoğu tarafından karşılanamadı.' };
                }
                return { success: true, item: finalItem, sObj: finalS };
            }

            let addRes = await tryAdd(satisSekli);

            if (!addRes.success) {
                const fallbacks = [grd.satisSekli, kamp.satisSekli, obj.satisSekli, 'E3', 'M2', 'A6', '01'].filter(s => s && s !== satisSekli);
                for (const fb of fallbacks) {
                    const retryRes = await tryAdd(fb);
                    if (retryRes.success) {
                        addRes = retryRes;
                        satisSekli = fb;
                        break;
                    }
                }
            }

            if (!addRes.success) {
                return { success: false, message: addRes.hataStr || 'Nevzat sepetine eklenemedi.' };
            }

            const sObj = addRes.sObj || await getSepet();
            const siparisler = sObj.Siparisler || [];
            const found = addRes.item || siparisler.find(s => String(s.ilacKodu || s.kod) === String(targetKod));
            const addedItemName = (found && found.ilacAdi) || obj.ad || '';
            const addedMiktar = (found && found.adet) || param.miktar;

            return {
                success: true,
                depo: 'NEVZAT',
                message: addedItemName + ' (' + addedMiktar + ' adet) başarıyla Nevzat Ecza sepetine eklendi.',
                urun_adi: addedItemName,
                urun_kodu: targetKod,
                miktar: addedMiktar,
                cart_count: siparisler.length,
                cart_total: sObj.topTutar || null
            };
        }""", {
            "kod": target_kod,
            "barkod": barkod,
            "productName": product_name,
            "miktar": int(miktar),
            "satisSekli": satis_sekli,
            "ilacTipi": ilac_tipi,
            "cached": cached
        })

        if isinstance(res, dict) and res.get("success"):
            import time as _t
            parsed_m = _parse_cart_adet(res.get("miktar") or miktar)
            self._last_added_items.append({
                "barcode": barkod,
                "miktar": parsed_m["miktar"],
                "name": str(res.get("urun_adi") or ""),
                "urun_id": str(res.get("urun_kodu") or target_kod or "")
            })
            self._last_added_time = _t.time()

        return res

    async def bulk_add_to_cart(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Nevzat Ecza Deposu sepetine toplu (batch) ürün ekler.
        items: [{"barcode": "...", "miktar": 1, "name": "...", "urun_id": "..."}]
        """
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._bulk_add_to_cart_unlocked(items, update_cache=True)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def _bulk_add_to_cart_unlocked(self, items: List[Dict[str, Any]], update_cache: bool = True) -> Dict[str, Any]:
        if not items:
            return {
                "success": False,
                "message": "Eklenecek ürün listesi boş.",
                "total_items": 0,
                "success_count": 0,
                "failed_count": 0,
                "total_amount": 0.0,
                "items": []
            }

        if not self.is_logged_in:
            await self._login_unlocked()
        await self._ensure_ready_page()

        clean_items = []
        for it in items:
            bc = str(it.get("barcode") or it.get("barkod") or "").strip()
            if len(bc) == 14 and bc.startswith("0"):
                bc = bc[1:]
            qty_info = _parse_cart_adet(it.get("miktar") or it.get("quantity") or 1)
            qty = qty_info["miktar"]
            name = str(it.get("name") or it.get("urun_adi") or "").strip()
            u_id = str(it.get("urun_id") or it.get("kod") or "").strip()
            clean_items.append({
                "barcode": bc,
                "miktar": max(1, qty),
                "name": name,
                "urun_id": u_id
            })

        results = await self._page.evaluate("""async (items) => {
            function postAsync(url, data, isJson = true) {
                return new Promise((resolve) => {
                    $.ajax({
                        type: 'POST',
                        url: url,
                        timeout: 7000,
                        data: data,
                        dataType: isJson ? 'json' : undefined,
                        success: function(resp) {
                            try {
                                resolve(typeof resp === 'string' && isJson ? JSON.parse(resp) : resp);
                            } catch(e) { resolve(resp); }
                        },
                        error: function(err) {
                            resolve({ error: true, statusText: err.statusText });
                        }
                    });
                });
            }

            function round2(v) { return Math.round(v * 100) / 100; }

            async function getSepet() {
                const s = await postAsync('/Ilac/IlacGetir-ajax.aspx', 'action=SepetDoldur', true);
                return (s && s.obj) ? s.obj : { Siparisler: [], topTutar: 0 };
            }

            async function processSingleItem(item) {
                const itemRes = {
                    barcode: item.barcode,
                    name: item.name,
                    miktar: item.miktar,
                    success: false,
                    message: '',
                    urun_adi: item.name,
                    urun_id: item.urun_id || '',
                    net_fiyat: 0,
                    vade: 30,
                    toplam_tutar: 0
                };

                try {
                    let targetKod = item.urun_id || '';
                    let ilacTipi = 'B';

                    // 1. Eğer urun_id geçerli bir Nevzat ilaç kodu değilse barkod ile ara
                    if (!targetKod || targetKod.length > 7 || !/^\\d+$/.test(targetKod)) {
                        let searchTarget = item.barcode || '';
                        let searchRes = null;
                        if (searchTarget) {
                            searchRes = await postAsync('/Siparis/hizlisiparis-ajax.aspx', {
                                action: "GetUrunler",
                                searchText: searchTarget,
                                isInculude: true,
                                isStoktakiler: false,
                                siralama: "ilacASC",
                                marka: "",
                                baslangicSayfasi: 0,
                                topRowNum: 0,
                                sayfaMaxRowAdet: 5,
                                s: "s"
                            });
                        }

                        if ((!searchRes || !searchRes.obj || !searchRes.obj.urunler || searchRes.obj.urunler.length === 0) && searchTarget.length === 13) {
                            searchRes = await postAsync('/Siparis/hizlisiparis-ajax.aspx', {
                                action: "GetUrunler",
                                searchText: "0" + searchTarget,
                                isInculude: true,
                                isStoktakiler: false,
                                siralama: "ilacASC",
                                marka: "",
                                baslangicSayfasi: 0,
                                topRowNum: 0,
                                sayfaMaxRowAdet: 5,
                                s: "s"
                            });
                        }

                        if ((!searchRes || !searchRes.obj || !searchRes.obj.urunler || searchRes.obj.urunler.length === 0) && item.name) {
                            const cleanWords = item.name.replace(/[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ ]/g, ' ').trim().split(/\\s+/).slice(0, 2).join(' ');
                            if (cleanWords.length >= 3) {
                                searchRes = await postAsync('/Siparis/hizlisiparis-ajax.aspx', {
                                    action: "GetUrunler",
                                    searchText: cleanWords,
                                    isInculude: true,
                                    isStoktakiler: false,
                                    siralama: "ilacASC",
                                    marka: "",
                                    baslangicSayfasi: 0,
                                    topRowNum: 0,
                                    sayfaMaxRowAdet: 5,
                                    s: "s"
                                });
                            }
                        }

                        if (!searchRes || !searchRes.obj || !searchRes.obj.urunler || searchRes.obj.urunler.length === 0) {
                            itemRes.message = 'Nevzat deposunda ürün bulunamadı.';
                            return itemRes;
                        }

                        targetKod = searchRes.obj.urunler[0].kodu;
                        ilacTipi = searchRes.obj.urunler[0].ILACTIP || ilacTipi;
                        if (searchRes.obj.urunler[0].adi) {
                            itemRes.urun_adi = searchRes.obj.urunler[0].adi;
                        }
                    }

                    itemRes.urun_id = targetKod;

                    // 2. GetIlacDetay
                    const detayVeri = await postAsync('/Ilac/IlacGetir-ajax.aspx', {
                        action: 'GetIlacDetay',
                        kod: targetKod,
                        isEsdeger: false,
                        esdeger: '',
                        isJenerik: false,
                        jenerikId: '',
                        tip: null,
                        ILACTIP: ilacTipi,
                        kampKodu: ''
                    });

                    if (!detayVeri || !detayVeri.obj) {
                        itemRes.message = 'Ürün detayına ulaşılamadı.';
                        return itemRes;
                    }

                    const obj = detayVeri.obj;
                    itemRes.urun_adi = obj.ad || itemRes.urun_adi;

                    if (!obj.satilabilir) {
                        itemRes.message = 'Nevzat deposunda şu an satılabilir durumda değil (Stok Yok/Pasif).';
                        return itemRes;
                    }

                    const kamp = (obj.kampanyalar && obj.kampanyalar.length > 0) ? obj.kampanyalar[0] : {};
                    const grd = (obj.grdKampanyalar && obj.grdKampanyalar.length > 0) ? obj.grdKampanyalar[0] : {};

                    let satisSekli = grd.satisSekli || kamp.satisSekli || obj.satisSekli || 'E3';
                    let etiketRaw = grd.etiketFiyati || obj.SonFiyat || obj.etiketFiyati || '0';
                    let etiketStr = String(etiketRaw).replace('.', ',');

                    async function tryAddBulk(targetSatisSekli) {
                        let cepSube = (kamp && kamp.cepSube) || (grd && grd.cepSube) || obj.cepSube || '01';
                        let subeMiktar = item.miktar;

                        const subelerData = 'action=GetSubeler&kod=' + targetKod +
                            '&miktar=' + item.miktar +
                            '&satisSekli=' + targetSatisSekli +
                            '&etiketFiyati=' + encodeURIComponent(etiketStr) +
                            '&miad=&onerilenFiyat=&tip=&ILACTIP=' + ilacTipi +
                            '&ekstraMf=&ekstraIskonto=&siparisNotu=';
                        let subeler = await postAsync('/Ilac/IlacGetir-ajax.aspx', subelerData, true);

                        if (subeler && (subeler.hataId === 9 || (subeler.hataStr && subeler.hataStr.includes('mevcuttur')))) {
                            const curS = await getSepet();
                            const ex = (curS.Siparisler || []).find(x => String(x.ilacKodu || x.kod) === String(targetKod));
                            if (ex) {
                                const exBase = parseInt(String(ex.adet || '1').split('+')[0].trim(), 10) || 1;
                                if (exBase === item.miktar) {
                                    return { success: true, actualQty: exBase };
                                }
                                if (ex.id) {
                                    await postAsync('/Ilac/IlacGetir-ajax.aspx', 'action=SeciliOlanlariSil&kodlar=' + ex.id + ';', true);
                                    subeler = await postAsync('/Ilac/IlacGetir-ajax.aspx', subelerData, true);
                                }
                            }
                        }

                        if (subeler && subeler.hataId === 0) {
                            if (!subeler.obj || (Array.isArray(subeler.obj) && subeler.obj.length === 0)) {
                                const checkS = await getSepet();
                                const inCart = (checkS.Siparisler || []).find(x => String(x.ilacKodu || x.kod) === String(targetKod));
                                if (inCart) {
                                    const inBase = parseInt(String(inCart.adet || item.miktar).split('+')[0].trim(), 10) || item.miktar;
                                    return { success: true, actualQty: inBase };
                                }
                            } else if (Array.isArray(subeler.obj) && subeler.obj.length > 0) {
                                const validBranches = subeler.obj.filter(b => {
                                    const kVal = parseInt(String(b.karsilanacak || '0').split('+')[0].trim(), 10) || 0;
                                    return kVal > 0;
                                });
                                const branch = validBranches.find(b => b.chk) || validBranches.find(b => b.kendiCep === '1') || validBranches[0] || subeler.obj[0];
                                if (branch && branch.cepSube) cepSube = branch.cepSube;
                                if (branch && branch.karsilanacak !== undefined && branch.karsilanacak !== null) {
                                    let k = String(branch.karsilanacak);
                                    if (k.includes('+')) k = k.split('+')[0];
                                    const parsedK = parseInt(k.trim(), 10);
                                    if (!isNaN(parsedK) && parsedK > 0) {
                                        subeMiktar = parsedK;
                                    } else if (parsedK === 0) {
                                        return { success: false, hataStr: 'Şubede karşılanabilecek stok bulunamadı.' };
                                    }
                                }
                            }
                        } else if (subeler && subeler.hataStr) {
                            return { success: false, hataStr: subeler.hataStr };
                        }

                        const ekleData = 'action=SiparisEkle&kod=' + targetKod +
                            '&miktar=' + subeMiktar +
                            '&satisSekli=' + targetSatisSekli +
                            '&etiketFiyati=' + encodeURIComponent(etiketStr) +
                            '&depoId=' + cepSube +
                            '&miad=&onerilenFiyat=&tip=&ILACTIP=' + ilacTipi +
                            '&ekstraMf=&ekstraIskonto=&siparisNotu=';
                        const ekleRes = await postAsync('/Ilac/IlacGetir-ajax.aspx', ekleData, true);
                        if (ekleRes && ekleRes.hataId === 0) {
                            return { success: true, actualQty: subeMiktar };
                        }
                        return { success: false, hataStr: (ekleRes && ekleRes.hataStr) || 'Sepete ekleme reddedildi.' };
                    }

                    let addRes = await tryAddBulk(satisSekli);

                    if (!addRes.success) {
                        const fallbacks = [grd.satisSekli, kamp.satisSekli, obj.satisSekli, 'E3', 'M2', 'A6', '01'].filter(s => s && s !== satisSekli);
                        for (const fb of fallbacks) {
                            const retryRes = await tryAddBulk(fb);
                            if (retryRes.success) {
                                addRes = retryRes;
                                satisSekli = fb;
                                break;
                            }
                        }
                    }

                    if (addRes.success) {
                        const rawFiyat = parseFloat(String(etiketRaw).replace(',', '.')) || (kamp.fiyat || 0);
                        const effQty = addRes.actualQty || item.miktar;
                        itemRes.success = true;
                        itemRes.miktar = effQty;
                        itemRes.target_kod = targetKod;
                        itemRes.net_fiyat = rawFiyat;
                        itemRes.toplam_tutar = round2(itemRes.net_fiyat * effQty);
                        itemRes.message = `${effQty} Adet Nevzat sepetine eklendi (${satisSekli})`;
                    } else {
                        itemRes.message = addRes.hataStr || 'Sepete ekleme reddedildi.';
                    }

                    return itemRes;
                } catch(err) {
                    itemRes.message = 'Hata: ' + err.toString();
                    return itemRes;
                }
            }

            const results = [];
            for (let i = 0; i < items.length; i++) {
                const res = await processSingleItem(items[i]);
                results.push(res);
                await new Promise(r => setTimeout(r, 20));
            }

            try {
                let finalSepet = await getSepet();
                let cartKods = new Set((finalSepet.Siparisler || []).map(x => String(x.ilacKodu || x.kod || '').trim()));
                let retried = false;
                for (let ri = 0; ri < results.length; ri++) {
                    const r = results[ri];
                    const rKod = String(r.urun_id || r.target_kod || '').trim();
                    if (r.success && rKod && !cartKods.has(rKod)) {
                        await new Promise(w => setTimeout(w, 60));
                        const retryRes = await processSingleItem(items[ri]);
                        if (retryRes && retryRes.success) {
                            results[ri] = retryRes;
                            retried = true;
                        }
                    }
                }
                if (retried) {
                    finalSepet = await getSepet();
                    cartKods = new Set((finalSepet.Siparisler || []).map(x => String(x.ilacKodu || x.kod || '').trim()));
                }
                const cartMap = new Map();
                (finalSepet.Siparisler || []).forEach(x => {
                    const k = String(x.ilacKodu || x.kod || '').trim();
                    if (k) cartMap.set(k, x);
                });
                for (const r of results) {
                    const rKod = String(r.urun_id || r.target_kod || '').trim();
                    if (rKod) r.urun_id = rKod;
                    if (r.success && rKod) {
                        if (!cartKods.has(rKod)) {
                            r.success = false;
                            r.net_fiyat = 0;
                            r.toplam_tutar = 0;
                            r.message = 'Şube stoğu / tevzi sınırı tarafından karşılanamadığı için sepete eklenemedi.';
                        } else {
                            const sRow = cartMap.get(rKod);
                            if (sRow && sRow.ilacAdi) r.urun_adi = sRow.ilacAdi;
                        }
                    }
                }
            } catch(e) {}

            return results;
        }""", clean_items)

        success_items = [r for r in results if r.get("success")]
        failed_items = [r for r in results if not r.get("success")]
        total_amount = round(sum(r.get("toplam_tutar", 0) for r in success_items), 2)

        if update_cache and success_items:
            import time as _t
            now_ts = _t.time()
            prev_items = list(self._last_added_items or []) if (now_ts - float(self._last_added_time or 0.0)) < 21600 else []
            new_entries = [
                {
                    "barcode": r.get("barcode") or "",
                    "miktar": _parse_cart_adet(r.get("miktar") or 1)["miktar"],
                    "name": r.get("urun_adi") or r.get("name") or "",
                    "urun_id": r.get("urun_id") or r.get("target_kod") or ""
                }
                for r in success_items
            ]
            seen_keys = set()
            merged_last = []
            for entry in new_entries + prev_items:
                ek = str(entry.get("urun_id") or entry.get("barcode") or entry.get("name") or "").strip().upper()
                if ek and ek not in seen_keys:
                    seen_keys.add(ek)
                    merged_last.append(entry)
            self._last_added_items = merged_last
            self._last_added_time = now_ts

        return {
            "success": len(success_items) > 0,
            "depo": "NEVZAT",
            "message": f"Nevzat Ecza sepetine {len(success_items)}/{len(items)} kalem ürün taslak olarak eklendi (Toplam: {total_amount:,.2f} ₺).",
            "total_items": len(items),
            "success_count": len(success_items),
            "failed_count": len(failed_items),
            "total_amount": total_amount,
            "items": results
        }

    def get_portal_urls(self) -> dict:
        """Nevzat WebDepo sepet ve sipariş onaylama web arayüzü linklerini döndürür."""
        return {
            "cart_url": "http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx",
            "checkout_url": "http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx"
        }

    async def get_cart_status(self) -> Dict[str, Any]:
        """Nevzat Ecza sepetinin anlık içeriğini ve toplam tutarını sorgular."""
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def _get_cart_status_unlocked(self, allow_sepet_page: bool = True, auto_restore: bool = False) -> Dict[str, Any]:
        if not self.is_logged_in:
            await self._login_unlocked()
        await self._ensure_ready_page(allow_sepet_page=allow_sepet_page)

        async def _fetch_sepet_ajax():
            return await self._page.evaluate("""async () => {
                return new Promise((resolve) => {
                    if (typeof window.jQuery === 'undefined') {
                        return resolve({ error: 'no_jquery' });
                    }
                    $.ajax({
                        type: 'POST',
                        dataType: 'json',
                        timeout: 6000,
                        data: 'action=SepetDoldur',
                        url: '/Ilac/IlacGetir-ajax.aspx',
                        success: function(veri) {
                            try {
                                resolve(typeof veri === 'string' ? JSON.parse(veri) : veri);
                            } catch(e) { resolve(veri); }
                        },
                        error: function(err) { resolve({ error: err.statusText || 'Ağ hatası' }); }
                    });
                });
            }""")

        res = await _fetch_sepet_ajax()
        if not isinstance(res, dict) or res.get("error") or "obj" not in res:
            await self._ensure_ready_page(allow_sepet_page=False)
            res = await _fetch_sepet_ajax()

        def _build_cart_items(siparis_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            parsed_list = []
            for s in siparis_list:
                adet_info = _parse_cart_adet(s.get("adet"))
                tutar_val = clean_float(s.get("tutar"))
                bf_val = clean_float(s.get("birimFiyat") or s.get("fiyat"))
                if bf_val <= 0 and tutar_val > 0 and adet_info["miktar"] > 0:
                    bf_val = round(tutar_val / adet_info["miktar"], 2)
                parsed_list.append({
                    "id": str(s.get("id") or ""),
                    "kod": str(s.get("ilacKodu") or s.get("kod") or ""),
                    "ad": str(s.get("ilacAdi") or s.get("ad") or ""),
                    "miktar": adet_info["miktar"],
                    "mf_hediye": adet_info["mf_hediye"],
                    "toplam_adet": adet_info["toplam_adet"],
                    "adet_label": adet_info["adet_label"],
                    "birim_fiyat": bf_val,
                    "tutar": tutar_val,
                    "satis_sekli": str(s.get("satisSekli") or "")
                })
            return parsed_list

        obj = (res.get("obj") or {}) if isinstance(res, dict) else {}
        siparisler = obj.get("Siparisler") or []
        items = _build_cart_items(siparisler)

        top_tutar = clean_float(obj.get("topTutar")) or sum(it["tutar"] for it in items)

        return {
            "success": True,
            "depo": "NEVZAT",
            "depo_adi": self.depo_adi,
            "supported": True,
            "item_count": len(items),
            "total_amount": round(top_tutar, 2),
            "items": items,
            "cart_url": "http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx",
            "checkout_url": "http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx"
        }

    async def clear_cart(self) -> Dict[str, Any]:
        """Nevzat Ecza sepetindeki tüm ürünleri temizler."""
        self._cart_busy += 1
        try:
            async with self._lock:
                self._last_added_items = []
                self._last_added_time = 0.0
                status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                items = status.get("items", [])
                if not items:
                    return {"success": True, "message": "Nevzat sepeti zaten boş.", "cleared_count": 0}

                ids_str = ";".join([it["id"] for it in items if it.get("id")]) + ";"
                await self._page.evaluate("""async (param) => {
                    return new Promise((resolve) => {
                        $.ajax({
                            type: 'POST',
                            dataType: 'json',
                            timeout: 6000,
                            data: 'action=SeciliOlanlariSil&kodlar=' + param.kodlar,
                            url: '/Ilac/IlacGetir-ajax.aspx',
                            success: function(veri) { resolve(veri); },
                            error: function(err) { resolve({ error: err.statusText }); }
                        });
                    });
                }""", {"kodlar": ids_str})

                new_status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                return {
                    "success": new_status.get("item_count", 0) == 0,
                    "message": f"Nevzat sepeti başarıyla temizlendi ({len(items)} kalem silindi).",
                    "cleared_count": len(items)
                }
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def finalize_order(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        """
        Siparişi Nevzat Ecza sepetine ekler (gerekirse), sepet üzerinden SiparisOnay ekranına geçiş yapar
        ve depoya onaylayarak kesin sipariş oluşturur.
        """
        self._cart_busy += 1
        try:
            async with self._lock:
                return await self._finalize_order_unlocked(urun_id=urun_id, miktar=miktar, force=force, **kwargs)
        finally:
            self._cart_busy = max(0, self._cart_busy - 1)

    async def _finalize_order_unlocked(self, urun_id: str = "", miktar: int = 1, force: bool = False, **kwargs) -> Dict[str, Any]:
        if not self.is_logged_in:
            await self._login_unlocked()
        await self._ensure_ready_page(allow_sepet_page=True)

        # 1. Mevcut sepeti al (gereksiz sepet.aspx navigasyonu olmadan AJAX ile!)
        cart_status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=True)
        existing_items = cart_status.get("items", [])

        fallback_items = kwargs.get("items") or []
        if not existing_items and fallback_items and isinstance(fallback_items, list):
            await self._bulk_add_to_cart_unlocked(fallback_items, update_cache=True)
            cart_status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
            existing_items = cart_status.get("items", [])

        # 2. Eğer ürün belirtildiyse ve henüz sepette yoksa (veya miktarı değiştiyse) sepete ekle/güncelle
        if urun_id:
            u_clean = str(urun_id).strip()
            barkod_clean = str(kwargs.get("barkod") or kwargs.get("barcode") or "").strip()
            cached = self._fast_cart_cache.get(u_clean) or (self._fast_cart_cache.get(barkod_clean) if barkod_clean else None)
            resolved_kod = str(cached.get("kod")) if cached and cached.get("kod") else u_clean
            req_miktar = _parse_cart_adet(miktar)["miktar"]

            matched_cart_item = None
            for it in existing_items:
                it_kod = str(it.get("kod") or "").strip()
                it_id = str(it.get("id") or "").strip()
                if it_kod in (u_clean, resolved_kod) or it_id == u_clean:
                    matched_cart_item = it
                    break

            if not matched_cart_item or int(matched_cart_item.get("miktar") or 1) != req_miktar:
                added_res = await self._add_to_cart_unlocked(urun_id=urun_id, miktar=req_miktar, **kwargs)
                if not added_res.get("success") and not existing_items:
                    return {
                        "success": False,
                        "message": f"Ürün sepete eklenemediği için sipariş sonlandırılamadı: {added_res.get('message')}"
                    }
                cart_status = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                existing_items = cart_status.get("items", [])

        if not existing_items:
            return {
                "success": False,
                "message": "Nevzat sepetinde siparişe dönüştürülecek ürün bulunamadı."
            }

        if len(existing_items) > 1 and not force:
            return {
                "success": False,
                "need_confirmation": True,
                "item_count": len(existing_items),
                "items": existing_items,
                "total_amount": cart_status.get("total_amount", 0.0),
                "message": f"Nevzat Ecza sepetinizde önceden eklenmiş {len(existing_items)} farklı ürün bulunmaktadır (Toplam: {cart_status.get('total_amount', 0.0):,.2f} ₺). Tüm sepeti depoya göndermek için onay veriniz."
            }

        # 3. Şimdi sepet.aspx sayfasına git (domcontentloaded ile hızlı geçiş)
        try:
            await self._page.goto("http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx", wait_until="domcontentloaded", timeout=12000)
            await asyncio.sleep(0.4)
        except Exception:
            pass

        pre_alert = await self._page.evaluate('''() => {
            const m = document.querySelector('.modal.show, #mesajModal.show, .alert-danger, .bootbox.show, #dialogBox');
            return m ? m.innerText.trim() : null;
        }''')
        if pre_alert and any(w in pre_alert.lower() for w in ["karşılanamadı", "karsilanamadi", "iptal", "stok yetersiz"]):
            return {
                "success": False,
                "message": f"Nevzat Ecza Deposu Uyarısı: {pre_alert}",
                "cart_url": "http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx"
            }

        try:
            if not getattr(self, "_dialog_hooked", False):
                self._page.on("dialog", lambda dialog: asyncio.create_task(dialog.accept()))
                self._dialog_hooked = True
        except Exception:
            pass

        try:
            onayla_link = await self._page.wait_for_selector("#ContentPlaceHolder1_btnSiparisiOnayla, a[href*='SiparisOnay.aspx']", timeout=5000)
            if onayla_link:
                try:
                    async with self._page.expect_navigation(timeout=10000):
                        await onayla_link.click()
                except Exception:
                    try:
                        async with self._page.expect_navigation(timeout=8000):
                            await self._page.evaluate("__doPostBack('ctl00$ContentPlaceHolder1$btnSiparisiOnayla','')")
                    except Exception:
                        pass
        except Exception:
            pass

        try:
            await self._page.evaluate('''() => {
                const btn = document.querySelector('#btnModalEvet, #btnModalTamam, .bootbox-accept, .modal.show .btn-primary, .modal.show .btn-success');
                if (btn) btn.click();
            }''')
            await asyncio.sleep(0.6)
        except Exception:
            pass

        if "siparisonay" not in self._page.url.lower():
            try:
                mid_cart = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                if mid_cart.get("success") and mid_cart.get("item_count", 0) == 0:
                    self._last_added_items = []
                    self._last_added_time = 0.0
                    return {
                        "success": True,
                        "depo": "NEVZAT",
                        "depo_adi": self.depo_adi,
                        "message": "Siparişiniz Nevzat Ecza Deposu'na iletildi ve sepet onaylandı!",
                        "current_url": self._page.url,
                        "order_info": "Sipariş Onaylandı",
                        "total_amount": cart_status.get("total_amount", 0.0),
                        "items": existing_items,
                        "portal_url": "http://webdepo.nevzatecza.com.tr/Siparis/List.aspx"
                    }
            except Exception:
                pass
            try:
                await self._page.goto("http://webdepo.nevzatecza.com.tr/Siparis/SiparisOnay.aspx", wait_until="domcontentloaded", timeout=10000)
                await asyncio.sleep(0.4)
            except Exception:
                pass

        if "siparisonay" not in self._page.url.lower():
            try:
                check_empty = await self._get_cart_status_unlocked(allow_sepet_page=True, auto_restore=False)
                if check_empty.get("success") and check_empty.get("item_count", 0) == 0:
                    self._last_added_items = []
                    self._last_added_time = 0.0
                    return {
                        "success": True,
                        "depo": "NEVZAT",
                        "depo_adi": self.depo_adi,
                        "message": "Siparişiniz Nevzat Ecza Deposu'na iletildi ve sonlandırıldı!",
                        "current_url": self._page.url,
                        "order_info": "Sipariş Onaylandı",
                        "total_amount": cart_status.get("total_amount", 0.0),
                        "items": existing_items,
                        "portal_url": "http://webdepo.nevzatecza.com.tr/Siparis/List.aspx"
                    }
            except Exception:
                pass
            modal_msg = await self._page.evaluate('''() => {
                const m = document.querySelector('.modal.show, #mesajModal, .alert, .bootbox, #dialogBox');
                return m ? m.innerText.trim() : null;
            }''')
            err_text = modal_msg or "Siparişiniz Nevzat Ecza tarafından karşılanamadı veya şube stoku yetersiz."
            return {
                "success": False,
                "message": f"Nevzat Ecza Uyarısı: {err_text}",
                "cart_url": "http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx"
            }

        try:
            onay_btn = await self._page.wait_for_selector("#ContentPlaceHolder1_btnSiparisOnay", timeout=7000)
            if not onay_btn:
                return {
                    "success": False,
                    "message": "Sipariş onay butonu bulunamadı. Lütfen WebDepo arayüzünden sepetinizi kontrol edin.",
                    "cart_url": "http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx"
                }

            try:
                async with self._page.expect_navigation(timeout=12000):
                    await self._page.evaluate("__doPostBack('ctl00$ContentPlaceHolder1$btnSiparisOnay','')")
            except Exception:
                try:
                    await self._page.click("#ContentPlaceHolder1_btnSiparisOnay", timeout=5000)
                except Exception:
                    pass

            try:
                await self._page.evaluate('''() => {
                    const btn = document.querySelector('#btnModalEvet, #btnModalTamam, .bootbox-accept, .modal.show .btn-primary');
                    if (btn) btn.click();
                }''')
            except Exception:
                pass

            await asyncio.sleep(1.2)
            current_url = self._page.url
            page_text = await self._page.evaluate("() => document.body.innerText")
            
            order_info = "Sipariş Depoya Başarıyla İletildi"
            order_no = None
            
            if "sno=" in current_url:
                sno_match = re.search(r'sno=([0-9A-Za-z]+)', current_url)
                if sno_match:
                    order_no = sno_match.group(1)
                    order_info = f"Sipariş No: {order_no}"
            
            for line in page_text.splitlines():
                l_lower = line.lower()
                if "sipariş no" in l_lower or "siparişiniz alınmıştır" in l_lower or "başarıyla" in l_lower:
                    order_info = line.strip()
                    break

            self._last_added_items = []
            self._last_added_time = 0.0
            return {
                "success": True,
                "depo": "NEVZAT",
                "depo_adi": self.depo_adi,
                "message": f"Siparişiniz Nevzat Ecza Deposu'na iletildi ve sonlandırıldı! ({order_info})",
                "current_url": current_url,
                "order_no": order_no,
                "order_info": order_info,
                "total_amount": cart_status.get("total_amount", 0.0),
                "items": existing_items,
                "portal_url": "http://webdepo.nevzatecza.com.tr/Siparis/List.aspx"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Sipariş onaylanırken hata oluştu: {str(e)}. Lütfen sepetinizi kontrol ediniz.",
                "cart_url": "http://webdepo.nevzatecza.com.tr/Siparis/sepet.aspx"
            }


    async def close(self):
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
