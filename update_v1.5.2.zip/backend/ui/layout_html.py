# -*- coding: utf-8 -*-
LAYOUT_HTML = """<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farma Radar — Eczane Depo Şart & Net Maliyet Karşılaştırma</title>
    <link rel="icon" type="image/png" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABQxSURBVHhe7ZsJdFRllsdfVaBRUkkA26277bZdTju2tkvbrTPj6ZnpTdwhiDRCEsIWIYQkREAEUUCQLQRQEKQVgbCELCDI6gYiIRvZN5KQfa9Upfb91W/Oq0ow1KtE9ODM6HjP+Z/3eN+/Ku9/v/vde7/3CkH40X40jwH/ryAzX8IPHTLzJXwf4bJZ8L3WH2TmS/g+wtrdSXd92RU5QWa+hO8rDG11dGQfwWUzDOgImfkSvs8wNxbRcnQjorG7XyfIzJfwfYelKpPWXQsRrf6dIDNfwg8BuuwMmpPj/+86QHQYcXRewNGUj7OxCKe6HtFl9XvD3xbqA8vpTHtN9p0y8yVcbYii/dJNWFuK0Ke8hH7hA5hmXY8l6lqs04Zijr4e46IHMaQswtZYILtpX1g7arF1d34tr2XDWIyZyZfxZOb7oasNSb7L2kX3vvnopwfieEHAFSlApIA4ScAdLsAEAcYJ2EMFDJOC0O+di8vRfzZ32k10lXyJoTqnX44ER1s5zYsfxamuusSTme+Hrjbs6jo0S/8d63gB91QBcdoQrDOHY573K2yL78Ey706sL4bgmiggThRwTxSwhgpo3/wrTl3zgALbTu1Dm/vhgBzDkTWo14/633GAQ9uAYeGDOKRZnjkYe8x1mDc/jyNzO87KT3AWpWP5JBHjrhkYV/0HlqhhuMMUuCMEnKECTQsfxW7S9ivQ7bLTsm8h+pyM/jlOG+2LHsF8do+HIzPfD1wtSDen3fA0zjABMSYI42v34zy1DdTVOPPTML8zFuO8W7FNC8Q+eSjW6BE4o1Q4IxQ4JgVAhBL1UwLl66b0K87zd0ydNKx/HlPVFzKe2+3NP8bsFNpffhDRbpR7wPdDVwv6g0swT1HgirsBy5KHcBQdxq2pwrR/PpbYG7BNU+CaKnhmmzABpKOUEyYJuCYpYJISS1gA2U8oqD2dJhPXF9aLubQtGYlD39Ivr/PVhzF/tvV/xgGmwoPoZw6D+JuwvnYfzqxk0NZj2puAOfZnuGdfBzODEKcqcU9SIEZIRyXuSIUHREgRoMAREUDh4wKZcx9DozP2K06C7uAK1G9H9MuxfroVzYIHvnsH2NrL0M37DcRfh/21+7F8nATdrZhPvo1lwe9g7i244q6HqGtwT1Z6Zr135kWpMkRKUaHscYCC8mcEvhwTzIWzn/YrToJLNNC6+E+YMnf65bks3ajj7vxuHeCy6dGs/RuO2OtxLXkIW+o80NZgLzmMcdXfcS+8C3HuL3HEXIc4bTBuqRxKDpBES5AcEeFNgqKUCMMDKB8lcOYJgbxda9FaHH7F9cKStQf1S/fhsvsvobotU75bBxj2xeOYOQLnG3/AuiMGd1MJrsZCrNuicC99BBbehSvhZlwzhnpCXZTE9sz+V+IViOHeHsEeNojCUAWZTwgUrIumudOA3azD7TL7FShBs/BhzCfX+x23FR/57hxgytqHKe4WWPYQtm1hOC6ext3djPnwcpxrn8S97F8R592BGDMM95QA3OFesR74OEA6Z7KAPmwQeaOUZD0ukP/mBOpaNJi7O1EXnpQJ7M34pk/eQv3yvYhOm4wj2rq/GwfYW3IxLrgXcclD2N8Jw1FwELepA3tWCo53JiCu+SvuRffgjrsJogYjTpKESutfSnhKT8h7HfBVNEjLonm8gpxnFeSOFMhdNYGyBm/7q805SNcX22UCJbj0ajpjb8VR+YnfcZn5Er4pnBY9XeufQFz4G9wbxmL74p9g7sRem41tTzzixlDcSx7CnXALrpkhiNLs953tPpASn1QOpXFnZABloUpyeyIgb+NMKmpbsIkiOM00r5+AtSHfr0jd6pHod8zyOyYzX8I3hS5lPvZ5t+Je/ziOj1ZAdx2itgXLyc2IWyfCm3/C/fLtEDMM17SfePv/3lnuex6hxCWVQqkfiAigdcJgckYpyBs1iHNPChTtfJPy+jbsTpdHmOGTt+ja5L/smU9sRD//AfpuxHohM1/CN4HlbDKmubfhXv1n7Hvn4mwrBVMXzpxUHFISXPsY4qLf4oq7EXfUEESpzvdNer0V4JIDFBCpwB4+hOLRSnJHK8gZLZAVOpSSjw9SUfdVo+PUN6NJuBdnY6FMpOtiLh3RN2LvLJeNycyXcKWw1edjeOVuxGV/xLptKvbyj8GqwVF4FFdyHOKGZ3G+/iBiws2IM4binKz0Zn2fdd4LT0mUyl/kYGqfD+CctPZHK8iWGqE5j1JSUkldw+WbI+2bIzHsWSAT6TA0oX7xZuw5KbIxmfkSrgQtZhvTN+zjzLKxuN96GseZD8DUhqPicxwfJODeOApx2cOIc29FnKXCNSUAlySuz8xL59Ka7z13S91f5CBaxweQ84xXfO4ogXOPCRTuWkVhVQPabt1lggwHl6Je/LBMpEu0oU/4F8wHlsrGZOZLuBJE7c7ilytzeOGdzyk4uhc0F6AhC1tyPO6kJ3G/8W+I8++AWSO8DY9HqNTmXh7+UiXwHqV8oEATHkDuswI5oQLZY5TkPiaQM+sRSkuLKblQKxNjy02lS5ppU7tsrHvFn+l+b6bsusx8CV+HpM/L+MWrJ3l0UzaT9xdT1CVi0HTiSFkMa/6KY8UjOBfcgRg7HPf0IZ6HH1JX5+n5JSdcSnrSzHuXhSTeEjGIglCp7CnJDVVQ8JTAuVFDKT2ZSkF5DW2dapkY18VstJODsTScl43ptk5E+9Z42XWZ+RIGwrHKVm5+5Qi/XZPJk1vPcbxGS6cDVn56kfXrV+NY/gjM/4VnsyO+eI2n25Mc4JoU4BHvrf89jU5E765PKnmDKX9OSdazSs6PVpL/jNT+Kih8bxElVReprpTPvgRnaxlqyQGlJ2Tjuh3RaNc+LbsuM19Cf6jT6Llr8UFuXnySB9ecYvPZBrocsPN8K3/alMcfNuQxZ/lqOhJ+A1EC4mRlT7enRPQ4QDp6/315FVDS9LySrFECuaMDyJcy/2MC2cvHUV51keKyKkwWeTmT4GovQxM5AkvxMdm4bsdstGuukgMsLiePJZ1gcNyH3PraEWanF1FnhI9rtDz5bhYPb8ji3jWZ3LjkDCMTVlMWdZu3xntmWdrZeZeAlOj6OoDJCrpeGETeswryRgvkjVGQ87hA1qzfU1FUSH5ZDRqfxNcXruYCtJOHY60+J+Po3puKZt0Y2XWZ+RL8IW7/OYTpe1HNP87f3jpNTpuZ3FYz497P5XdJ2dy3+hS/XvoxNyw4waCXPuLe6I18Pu3+S12dtNf37Pl79vmehx+RCozhARSMUpAdquB8qIK8pwTOvPBTKk6foKCijqaWNpmAvnCWf4Z22g04ui7KeIZ1z9K9aaLsusx8Cb54L7MSYdp2hsRmcNuij0gp1VCkFZmUXMCdy09xz8pPuf21k9yw4BhBLx1gROxBhJeOclPs++yMGund7kq7O88ev+fJT6QCW+QgykcrODdaSc4YBQXPCGQ+raA0dSOllQ1UXayX3bwvTKe2op77e0RRvvHRvvow+r3zZddl5kvoi8z6DkJm70IZvZ8hMem8cfIClXqYc6iSny88yq3LPuNXi4/w0/nHCX4pHVVCKsFzDjAsPoNBCR8xNDaZldPH4Zx0zSXxUil0TRlE7VjFpaRXOErg7EiBwg0zKKlqoLS8GqvdKbt5X+i2TUP3rvyZoWjTo467A9vpbbIxmfkSetFusHD34jSEF/cSMD2ZMe/nUqgRWXe6jhvmHeTGhce48ZUjXDfvEMMSDhCckEbwHAnpBM/JICT+AIMTMrg2OoPpM2ainRriefbnnqKkZbySvKeV5IQqKRilJO/vAlkL/sKFslLyymswGgZ+/CVBdJrpmPcA1lx5t+fqqKIt5tfY67NlYzLzJfQidNMnCFN3I8zczX3LjnKy3syewi5++coBVPEZjJh3iBBJ+JyMHtHpBMWnESxhThrD4tIYGp/OkDnpCLMzeGbGyzRNvwnXBIHznpkPoCBUIOcJgawpd1CTfYbCknraOv2/1PSFtfAobS8/gOjndbg9/0O65t2NaNfLxmTmS5Dw5okChCnbCYg+wA1xKWw7r+boRQsPLD2CMjqVoEvCe5HuFR6fRlBcKkFxaajiUgmJ3es5Bsalo4g9zB9nLiXt+duoHiVQGCpQLDU7zwVRfnw/hZUNXGzs/6muLzRrn8Z4aKVfvnZHDN0bxvodk5kv4cv6TlTRu/jJrN0MmrGLlw9V8Xmri5FvZyJE7SE4PqNnltMJkcTHS+J9HZCCKi7Dcx4Su5/g2HTPuXLye9wyYSFvj7uH8tEC2U8IFO9cTmlVHeVVNThc/uu9L6zFJ2hf8RfcdpNfvnrBg5iz9vsdk1nfQbvo5s9JxxCm7UTx4j6e2XKaz9thekoRg6fvIDDuAMHxqZccIJ95L4Lj9hMSm+qZfZUUDXP2Exj1LkFh6wmI3MTwCSuZ+9T9FKwMo6ryIkVlFZgt8kzuD26rlpb1L2CtOuuXbyv9hI6Ee3Gbu/yOy6zv4PGyBgZP/YDB0bu5aX4GqWUGEk83ETxrN4Ex+wmOyyA4zis6pK94Hwd4sZ/AuDRC4lNRzfiAoRHrGB6xElXkBoSxq3lk3jsUlleQX1pNd5f/m/WHjsNr0WXu7pev2zgBfXKs33FnZ5XcA30Jk3d8hjB5J8qoZP6xM5/DNSbuevVDBs/Y2yMyjWGx+wmRQrvHAXLh3giQICXL4JjdqCLWExKeiCpyLUPGr+PnU9dy+FwFFeUVNLUM/AK0L7Slp9HkH+qX72wrRhN7J87OSr8c47F1/TvA5HDy29fTUcxIJXh2Cpuz2piVUYowfReq2HRvKEviYlO8AqWs3yu4T/L7ygmpDIvdR+DkTYSErUU1KZFrwzZwzbgVbD58motV1VTV+N/k+INZ246htWJAvnZLBLoPYvrlqJf+R/8OqNUa+HlCCoqZe7n1lQz+eV7LPUs+8iyH4EvruUdcrA/6hL10lJzlccaUdwgKW0NQ+FpUEUkoxiwlZssBqmvqKS+vwGa/8l+FuPw85u4Le80Zmhc9ilPvv322XThN++wB3gyVtui4LnY3ATOSuW/pMd74vInh0gzGykNcjrQeR+xDJTkhPpXAqH+imphEcPgagiISUTz3Jn9fvJOyyjpKS8rR6/1n8G8Fp4WWpLFYCg/3+526jeEYt0cP4IBWHcNi96CcsYffLTtBTEYZgTN3XZr1gdAbAVLSk6pEUPQOVOGJBEWsZVh4Isrxa7j9xbc4nVdOWXkl7W1XnvSuBJpDq+n6KLHf73S2lNE569e42iv6d0B9t5mfvbQXxYy93P7qRzy//TxDo5MvhfVAkHKCdJRqf0jMHoZO2uhxwPDwJAaFJxIyfjk7judRfaGK2rorT3pXAkPeITpSXh/wO7u2Tad7h/dXYzLrJdmcLh5akoHixb3cmJDO3zafQxUrhXTK5cnNT+b3Rkkaw2bvQzV5M4FhawkKX4cqfD3C2KW88v4RaqvrKa+oHvBGvylMtfm0HExEtPW/d7DX5tD2+n8hGjsGdoCEWbvPIkxJRjV7L3ctPsqIhAMESuXsMsE9Ca7XIZ4cIe0D9hM89R2CJq4l2BP+iQjPLWXM8j1UVDdQUlqOydj/S81vCmNzBR1nD+K29y8e0Ub7hnFY8g9c4sis7wc+LqknIGILQ2enERibQtAcSaAU3lIUSOgV3VPnPf/OIEQqkdO3EBS2imFhawmetI6AcSu5J+ZtsopqqSi7gFotf6j5bWHpbEBbk/u136c5to7O1Mt/Kygz3w/956vbEcLe5Vqpg5vjFSmVNSkSAj3nUk+QjkrqBqVZlxqdqVsInriKEE/GX8+QiYmETFjOvk/zuVhZTWPDlW9yvg6i04LZ0P9vBMWet8SWqi9p2jIL0We/IDPfLzh9oQHV2NcICNtMSPROVHH7vF1gfBoqaR/gaYjSPMskaPq7BEVIa32Np9MLikjiGinxhb7OwuST1NbUUFl95c3O1YJD20HDjnicnTWyvy0zX4KErcczEZ5ZgHLCGoImbSRoymZU07eiinoX1dR3UU1+G1V4kme9B0ldXkQiw8LWEThxHcLoV4lM2k9FdSPl5TVYbAM3MFcbLouWpg+TMNUV+f27MvMl9GLjkS8Z9PwbCGNXEBi2GpXU0U1c7SlvgeFe4SFh63qyfSKDx69BGLOEsMS9FFfUUVxSTqdG/kDiu4TTaqDlVDKmRv/iJcjMl9AXx/OruDt6HULoUgb9Yw3XhCWhipCy/CqPU64NS+Qn/1jFoDFLuWXaKl5+7xA5OaV8mZlHSUU1LW1qWls7aG/voKOjC3WXFo22G51Oj9FoxGy2YL1KEeKwmegoOImlbeAlJzNfgtNhp6NLQ21jG50tzXxZWEPclgM8NHs9Iyau4toJa7h2/CqGjl/J8IkruD92E1EbD5D+cQ5ZOUV8kZ1HWVU1jS3tNDa20djURktrB61tato7NHR0alF36dBodXTrDOgNJgxGC2aLFZvNht1+ZQ9FLrtnm4nuxgpsxq/vMGXmS6ivqyfzbD5nc0vJLiilvOwC1VX1nMktYfvBz1i98yhL3j/Kil0n2JbxKcdPneNcTg6ZOfkUFFZQW9tAY2M7DY2tHvHNLR20tHbS1t7lcUCnupsujQ5ttx6d3ojBaMZktmKx2L69A6wGXI4r+49TMvMl2Ox2WtUaz46touIixcVVFBVXUFpW6enji0oqyM8v5nxuAbm5xeSeL6WotJrK6npqGpqorW/xoL6hxeOApuZ2jwMuj4BuNFr9VxFgkiLA4nGA7/1cbcjMl+ALq9WOzmCiU6ujXa2htaOTptYOGpvbaWhqo6GpnfqmVuoaW6hvbKGhuZXGFmnmJeEdtLWr6VRrPbPuFW1EbzBjNFuwWC1Y7Xbszq9/B3C1IDNfwg8dMvMl/NDxo/1oXvtvMXSBV5gVbBIAAAAASUVORK5CYII=">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .depo-alliance { border-left-color: #0284c7; }
        .depo-selcuk { border-left-color: #16a34a; }
        .depo-nevzat { border-left-color: #ea580c; }
        .depo-iskoop { border-left-color: #dc2626; }
        .depo-bek { border-left-color: #0d9488; }
        .depo-ecza1 { border-left-color: #9333ea; }
        .depo-farmazon { border-left-color: #ea580c; }
        .depo-dna { border-left-color: #06b6d4; }
        .depo-eczatrend { border-left-color: #f97316; }
        .depo-eczanetakas { border-left-color: #0284c7; }
        .badge-pulse { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: .5; } }
    </style>
    <script>
        (function() {
            var _initVer = null;
            setInterval(function() {
                fetch('/api/version?t=' + Date.now()).then(function(r) { return r.json(); }).then(function(d) {
                    if (d && d.version) {
                        if (!_initVer) _initVer = d.version;
                        else if (d.version !== _initVer) window.location.reload();
                    }
                }).catch(function() {});
            }, 15000);
        })();
    </script>
</head>
<body class="min-h-screen text-slate-800">
    <!-- Toast Notifications Container -->
    <div id="toastContainer" class="fixed top-5 right-5 z-[9999] flex flex-col space-y-2 pointer-events-none"></div>

    <!-- UNIFIED HEADER (Tek ve Zarif Üst Navigasyon Barı) -->
    <header class="bg-white/95 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50 shadow-2xs">
        <div class="max-w-7xl mx-auto px-3 sm:px-5 h-14 flex items-center justify-between gap-2 flex-nowrap">
            <!-- Sol: Logo + Ana Navigasyon Sekmeleri -->
            <div class="flex items-center space-x-3 min-w-0 shrink-0">
                <div class="flex items-center shrink-0 cursor-pointer hover:opacity-90 transition" onclick="resetToHomeSearch()" title="Farma Radar — Sıfır Anasayfa & Arama Motoruna Dön">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ0AAABICAYAAADs8KBjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAADgzSURBVHhe7Z13fFX1/f9PEjYhgKu2Wmurtda22n6rra3aodWqdbBndggkzIQlQ9nK3sgKK2xCwpaNIJsMIIOEQMgmZN+9x/P3+JybQJJ7bxKt+vP75f7xfCT3cz733HPHeZ33/BwJkDx48OChuTgNePDgwUNjOA148ODBQ2M4DdwPWPValIXZGFXlNNzmwYOHxnEauF8w6VTcvnwSVX6GRzg8ePgaOA3cT9hMGkpObaEiea9HODx4aCZOA/cdFj3FhxdRcXiNRzg8eGgGTgP3JTYjd7ZOoWzvPI9wePDQBE4D9ys2i5HC5QMoO7LAIxwePDSC08APCTum7/UEtqlLyP3sXZSn13+vr+vBw/8mnAa+N2zOgmC4nY7myHzUa8PRzP8Puln/Qj/rLTSLeqDdPAzN2VhMiiKn5zWGRV2JVads9nMsBenc+uiPGDMPN/s5HjzcTzgNfF+YbJa7J6U2+yTVK3qiHPIAmv4S5v4SpkAJS6CE1V/C0kfC3EtC21tCNeQXqGIGYSi62KyT2mJQU519AWXu9WbNF2jPruPW2P/BWp3X7Od48HC/4DTwXSNcDpNdnItIVnUhivWDqQ7zxdpXwh7mgzWyNQySsId6YQuRsAdLECRBoAQBXlj7SRi7SygGPIRy3yzsdkOTJ7bNaqQ8+Ril5+LBrm9yvqByeRilCz5o1lwPHu4nnAa+L0xF6ZRPehldfwn7QAnbkNZYB7XDGPEgmpE/QzP5Nxim/g/a8c+hHfIIxmBvrH0kbIESthAv7P0lVL0lqpb7Y9NXNuvkLj2dQOGueWDXNjnfriqmOOpptEfnNznXg4f7CaeB7wNTYQqK0c9hFNbD0DbYh7TDOOwBtPPexnRoFua0vdhuncGefRBj4gY0+6eiWxeEetLzGEPbYQ/wwiYskEAJfTeJvFldsBpVzTq57+yfze2NY93PtRvvbtOfWkvRwB9hKb3hfr4HD/cZTgPfNWZ1AdWT/oQ1QIIRvhhHPIBuyouYjizCfjsNyjKwnI9FGxOAeuqL6Ec8hiHyEXTDH0M35meYI/ywBHlhCfbCHuQjuy5F/5HIWjKkmSe2idtrIijZOtppvhyaFVaG/V6QtmTKqyiX+DvN9eDhfsVp4DvB5rh626wmqlb0QjNAwhz9Y8wjHkU5/z+Y07+A6nwsqfvQLPkQzfAH0Yk5oRJ2YY0IFyag5v9g4Z5ImEKEcLSEYG80/l6cf9eb3GObm3dy6+6QN/XfqA417Xro0/ZRENQG0/UzTc714OF+wGngW8d6z9yv3jcVTVhr7CMfxTr6ZxjmvYH1+gmouonu/BoUk/+MJcIP2/COWAe3xRbujT3YG3ugj+NviLcsGrWBUUeQ1AtDcGvS3pU4O+h33C7KafLkFnaEJfcyxYN/iyHjaJPzlVP/gXLBh03O8+DhfsBp4LtCd3ETVZEPQvTDWMY/i2bOP7Fe3QPVxZgubEE16WUsox7DOurHMLQT9oFtsIV5YZfdEG9swV4QJIRDwhYqxlpAoA8EemEO8iazm8TpdyUydqxCrXeuAXGF8tBciqJ/j1XdeGrVeGELZf1bY8453eg8Dx7uB5wGvgv0t05TOfIp7FEPYf/kGXQzX8d4PhaqirBkHKF6fles456Fj36GZeSjMNgXe3gL7CFeIMRCWBQi/SoEQyAe14iJsDrMwd5kd/Xi4psSFz/+gPz8wmad3Habhtuf/I2KVaGNzreZ9FSMfA5VTFCj8zx4uB9wGvi2sVTlUjb1JUwjHsE+5XkMs/6J6dhcqLqBtTgR1foIDFNegonPYB3zhGNeRDtsYd6yQNQKhiwawTUECQtEwhbkwBrkQ2ZXHxL/I/HVgOfIunQGpf6eW9QYprR9lPj7Yco40uh89Y6PKQntjKUqv9F5Hjz8X8dp4NvEaqlGsbQX5sEPYJ3+B0xz3sK0ZybcuQZl2ej2zMT06T9h6h9h/NNYRz2GeWhH7ANaYgvxvisO9cSiDqJmwxrshSWgBWldfbjYVeJCrwfIPLST4nIVFosJ6mRC3KGY+W8U09+ksV4Xc34i5f1bYDix1O2cZlPnmIrUBrIq1ZSrm64d8XD/YqN5F8HvA6eBbxPFnonohzwCU1/APO9f6OLHYrmdDlWF6M6sw7iwF8x6A9vkF7GNfQpr1EPYBrWpcT3q4EY05LFQL7T+rbjcxZtL3SQufeDNtd1ryC8uQ69VUZZ5yv2HXVMdakjfz51+3pjS3C/GIypPKye9jGrGK27nfB2+ullK1yWH+fmE7TwyZivPjdvJvxcdYldy04FcD//30GWeQLnzEzR7p6HdOwVFwmR0mT/MGJrTwLeF9sIm1COewjrtD9gXvINhcxTWvNPY1aWYM46gWxeKdXEXbJ++hm3ib7BF/wT74Bq3JMhHFgVHPKOOxdFARGS3JUziTr8WJH/gRXI3Ly5+IJG6axXX80rlD1xx7Stuf9l416rdqqd04ksoFjWeIdFu/4jSgJaYRT2Ji+3NZcuFTDpFrkcasB0pbB2thm1BGrADqedKAlZ+8V/t28P/ThQJH6N5V8LcQ8LcXUL7toR667gf5G/BaeDbwJh3CsWE52DC85gXvY9h/XCsmUexacuw5Saij5uIbXk/bHPfxD7p99jH/Az7sM7YB7Vw9JvIoiHSq3VEo0YsROBTdk3uxju8uNHTi8QuEpe7eHGhizdX9q8hNbcEk8kqf+hFGz9CcWZDo1+A9sAcKgf4YVG4v9JrU/ZQ1V3Cei7W7ZymKFDqeHLMZqSBG3ly1CZWnsogpaiaPVfyCVi2i4Qr2d943x7+96LePwNjT9Ff5ahHMvWQ0CV8/IP8LTgN/LeYFSWUzvkX5glPw/x/Y40ZiOlyHGjuYK3MQ3d8GZa1YViXdMU2/WX46OfYRvwIS0R7rKGiHuOeMDRE1GQ4ENuFYHijDmzBlS5eJHfxIflDiXO92pFxNI5r2bnoTI7YgaUoiVvjXsNS5r7T1ZJ/jtL+bdCc+Nz9HFUBitBOqNcPdTunKbZezEYK34JPRCwx5zO/8X48/N9Cve9Th2jUBPdl0Yif9IP8fTgN/DfYLUaq1g7AOOYJ7PNex7KyH+Yza0CRj11dieHyFxi2fQTLe2Kf+TfsE5+F6EewD+6ANawl1jpBT9mKqE2t1o4F+mAVzWri/wAJa0hrsnt5k9TFm5QurUj8QOJC8E/IOvcV6dm5GMzmux96+TJ/KleEuf0SbFYNVeNeQjf3fbdzwED1lL9QOeFF6hatNQ+HgI3ecQ4pIIZnxm2jUNd0h+43xe5ivRIPP1xU+2Zg6OmwMu4r0VDvm4l21BMw6xVsn/fGcGQh1upboK3CcvOcnDmxxITC3H9hm/Q8ttE/haF+2MNFtqRBpkRQk2qtTbcK0bCE1DSrBbWgvF9r2bpI7upNUncvLr0jkRz9KpkZ10i/kVvvA7dkHKZ8wKNYii+7/SK0scMoH/ooZr0jHuIK1cowKkPbYhbvy8X2pgiPPYcUuJY/TtuHynRP1Dzc39y1NO4n0RBVncrRT2Gb8WfMS3qij5+MteSKLBjWvETMB2ZhWzcQy8L3sU35I/axP8M6rDO2Qa1l60F8UE2Kxt0AqDe6oNakd/HiYhcvUrp6kdRd4vQ7EldXTybjeh45OfXrKSxGFRXDnkYdG+32i9CeXEmJyKLcOOl2jjp+GtV9JEw33c+pR4OU76CtF5AC1/DitH3IuZuG8+Uyd3nBEadxvdWKwdJ8obHU6dh1h8Zia3JOvfkmI1pz860YtcmK3vr1XsMVOosNo9URo2oOdpMOm/YONoMSq0mN1VyF3Vr/uC3VuRhLUjEZqlzu16IpxVSajaH4KobiVExlN7C4mdscbIYqjLfT0d9IwZh7GbPi3oVHtbdWNBznQnNEw2bXYlIWYCxKQ59/GV1xGqbybGwWdaPPczzXhM2gw2ZUYTNW13xO9deasWqqMd65jkVZUm/caWffhMy8fFI+eQv75OewiUxJ7DDM2SdBXYKlKA3j3nlY1w3Etvh9rNNfxjruaWwjHsAW0QZLqDcWuVCrQXq11j2pqQQV5eRyYDTIC3NIS7J7eMtWxsVu3iR38SLpPYnT/R4m4/wprmTcoLS8wumDU60KojzqV9iMrpf/0187gqKHhOH4cpfbBYaTa1B0ldBfaGZzHEjbL1zDf+URImJP8cLUXbQcspnHx8YTsuEsgzefZcjmswxYf4ZP915CK59f9557POs2ExIu8fa8A/xx6h5+P+0Ar84+SOSGk8QlZaOxNi4iB67k0mvlYSbsOIVO7/hRpBRVMWNvEm/N/oKXJ8Vzpajs7j5Sb1cQsuYYQzZ8yS2F48eXVljJlD2JvD7/AC9M2cvvp+yj69IDrDyTRpXRWUAu3iplUsJFXp+zm99NTeDFabvov+wwMacyKdc5z3dFkVrPpnMZhKw7zl8/3c3/TE3gpek7eX/RfqbuT+JCYXWj+1FfSKBi+FOoPnoW9Zg/oBj+LFWJu+Tn6M9upGrmO2iG/oTykM6o63yXZkU+2i8Xy1XK1SN/jTryUbQDOqMe8ACaiEdRjXqGylXB6NKb7lmqxZJ3FcXGEShHP4tmwENUhHVEEd4BzZCfUrU0EGPuJZQHHO6JsDSsQV6YursXDXPueVQ7J1M99XW0Q3+KOvwBFGEd0YQ9gDriCUo/+Ruq+E+wlGa5fL7AUHqNivGvoBn9K1Rjf0tV1DMoNo1xfD43L6BcHowq6hnKgx+geuPIevtx2tnXJa9aw98XHCfw0zVkLA3HGBOAJWknqIqxlaZjODAf28ow7Ivew/bpX7CPexZ71CNyQ5o1rIWjqlOIRgMrw9FrUlP5KWdURDbFB3tIS/J6e3PpA4mULl4kdvUiWRR1vSlxef5AsrJvkZpxHaPR+Sqr/XKFnJ415Z5z2iYQH3KVfytUW0a53C4wXD0oZ1A0X2PV8rD1J5DemY3UeyneERtpP3o3bYbtQOqzAqn3MgddFvD0qFjUNVfl87llvDd/L94DY5H6rnIQsAbJfwVSwHo5LuITtoa/z9xN+m33V79pB1KQeizmsaj13NGbWHjsKp2GbEQKinHsp/8izuQU3H3+wcxCJP9VtA6LIaW0isXH0nhw8CZ5TCZwJVLgeqTAGKSQ9fxp6m6SChy3t6zQGYnceALfiPVI/dYg9V+NFCCOWzw3BiloHf/z8VbO3rrt9ngVBiOzDl3maZFhCl6J1G8FUr+1SAHrat77aqSgtfgN3sz4+HOY7K6tGN2Jpei6SNBbgl4SRiH0ceNQrBmIuqeEtbtjmzg5DWfXYzHpURxciHL4L9D3kjD3lLD1c3RY4y9hE0s59HXsy9BDQtm3BYq1w7GbGl/HRXlgLoqQBzF1k7D1kbD3cyxhKbD1daRXNeGdUY97Aau/j/y7NwV7y+O6+E/q7dtQlIpyZQCqoPYYRWq2j+OY7GJfogPc3/GeDH0c77dy0E9QnYpxeXzmwhR0/i2hh4S9j4Shi4Rxwbtov5hPVZCv/LmIcVMXCd3q+m0WTjv7OmjMFvqtOsUvPjvLazFZDF11mOwzB6EiG8ozMB5divnzvtgXvY1txqvYJjyHPfonMNgP24AWDutBCIOo/qxbJi7HLITlIbpcawKf4kMJ9aKon48c8EzqKnGphzeJwtJ4W+J8yK/JTjpDYuZ18vOLXX5QpswjVPaU0Jxe53K7TVdB5dCfULncfY+JNf8SFf290cRPczunIXuu5DFy6wUm7U3mzzMP0iJyGz8bu4PouEQm7Epm/K4kouPPsfxoirzPMzcL6TxoNZL/GlpFrOGN+bv5KO4Ci46nsfJYIpPjzvDaZ/toGb4RKXQLz07YRl6V6x/vrCNXkILW8OsZhxi9P5U2A9YhBcfy7MR4+q07yUdxX5JXee+qfSy7mDYRm/jJ2ATCN57DJ3wDUvgGXv00gfHbU1h2KJFJu8/xt7m75QyQNGAzv5m4jbMFVfT8/LDjpA5fwz9n7WN8QiKLDiUxeV8iby06QlshgAM28YvoDVy741rowtYcQ+q3Thaln46JI2zNKeYdTGbFqQxmH75M8Pqv+OmoHUjhm5CC1zFhd6LL/ei/WoVRCEaAhCVEktdgMYU/jKGvhFXEDYK9oZ+ESQjHxW0YteWUDvqRLArWUMfqcHI3dY1oyL8/4UIHejsaJftLaLtKqNa5D64r4z6mSuxP3kdN5k90Z9cKkHxsXtj8HSeoyAjKv/lASXZVtLvqp1wrD85H/Z8aoZDPCa+7y0bIxyiON8CxpIS4GAsBqertjfKr1U7HaCm6gj6so7wCniyI/XwwDeqINqANFrFPsW8hbt0kjDHh355ojNmdxOMTD/PK8hTeXnWWiUdukaOyoVMrMX21GRb1xjz/bUyf/QXLxGexjvoRtiEd5MCn+CJrXRKhrvL/9URDfLEO5ZU/jBBvqgJayGIhsiVJwsLoLpH6nsTZD1qRvjuGazfyuJKWiU7vOithvZ2Jsn8LlDtcF83Y7EaqPvkDlXPcZ1CsldmUhvmij3VvjdzFRQl79PbzSAEbeGnaXrcxjVylhqfGxPL7STv4IuOeFVAXrcXKqLjzeA/chBSyjpFbXVe+zjp6BSl0HZ1Hx+M3bAOtwtcQFXeJEpXrz+h4djHtIzfRLmonPoM30TFiPbOOpaJrEMfQWa2MTDhHi4EbaTkkjkdG76LVoFg6D9vCsq9SEfGXhvv+7GAyrSI2IYVuJHDNMaftgrXnsmkZuIIB645xs8K1ECYXVfOHyduRBm2m45BYLhU6L/do+Gq1fMV1uLxeWANbOa7uAQ6xsImTubuE+kMJ/amN8vO1G4ajFy6CWNhaxBT6eKEL80UR2QF9gJe8uLVVjjn4yCe2JUhC1bcFhisHnF8/eReqPj6YAyXMgd7Y/Vtg8/eSLRghXGJ/upoFs+nvhSXIR26JEIIkTlhtHwnNrvruiU1dhmbks9h6S1iFRSEW2/ZvgSryIXSRD6ENbCXvX4iINbCFvKSEeJ8VQ5/CrKzfyV0rGuK9WsW5JmpDxPNqrZZ+jmPTvCehWRlc77lOX0hz+fzMDR786AAvzL/A35ZeZND2JJIqTFQZrSSkl7NoZQyKBe/CtOexj39KtjBsQztgE5mSUC+H+oeIlndH23vDmIYQChEglQUj1AdlUCu5HuNSF28udxUpVi8ufyiCn95cWTaMrJs3uHw5g/Li+kGbulirC6kK86OqwYdQl8rP/kHltL+73W5RFnB74ENo1w50O6cxBm8RgdAN/GnKLpQGZ1GpJflmCYXKxgNa4tlvzNkrLs88PX4bd7TOQjD7cKosGm1HiOrTtYzdneQ0py7HrxfTLmIjLUbswGtgLPOOXKkz33n//5h7gBbC5RqyjRYD1rP45E2nOXXpsuwY0oBYfhwVy40y59iSwazncEbTmamj2bdpP2QTUtBqJiacdZpvPLUavbgiy1d3b2yB7eT4mVjAWpyQqol/QLfoXZSzP8SQ5ghqG3MSKevfEtWgB9HERKJL3o6x5CrG0iyMN46gWhuJJqCl48osXIkgbwziar6oe73XFwHF6smvYa0p1hILYpsDhMD4oJzfFXXKVgz5SajPb6Z6zpvoenthlbu3xT7Fye6NpbuEvoF7IqiO/xjlOxKacS+gTJiC7vpXmMqzMFVmo888QeWirmiEWyW/by/59Q3dJBRH6i84JYtGqJ9saTjSvN5YxXITfSV0vSSUw3+Odu5bVM38N8qDi+s91+nLaA4Hs27z6JgEnpx+gv9ZcI4PVl3g6C0l5Qb4Mk9Nt/UpvPp5IqPmrSBr6lsw8iEY3AbbwNZyhaccIZbFQlgSNaJR229S446Ix+KDFMFQc1ALromUaheJ5C4tSermQ1oXibNvS5yb3oucrEzZwriR0/g9UayqAqoHPELVkj5u54kPqWryX91utyiLuB3xKMq1gW7nNIZDNFbxx2l7qDbeu43DN2XGF2lIYeKk3cDpXOdYwdxDGbJY+ERs5C/T9qBuIltyIsshGlLEJl6Zvge9zXUmp5YlpzNpOWAtPpHbeeWzfZhcWBh12Zych1d4LD4DN7AzpX5a/OugNBj57cQ4pOBN9FrlHJQ0frVWvhLXugBCOEQ8QTXwQdQnV2J1EYuw2fUoj6/FkHfJaVst1RuGOfYrrA3xWxUCNPpXWLX3gsn6zGOoA3wcboNskfig6iuh3P6R035FBkQRO1IWHyEWtTE+YekY4qc4zbdU5KM+uAiLm7IAO0oq53TH1EeSEwzC5bH0kFAs7V9vvhANnRANYXXJbldLWdw0QjQ3Dsdc5drCFTgNNEVWmYJnJuzkgbH7eGbWSf4670vWJ9+hWGsjuVRP2JYUXl2axCuLk3luzgXenLKWI9FvQISPnAkRa3vKi+nU9JcI4RBvzCEeIoZRNxAqulhbktvDh0sfSiR2FzEMHy4LF0UIxoiXybmayJWsW2Rm3cBYp5jLFVZVPqrQB6he7t4PrfjsDSqn/sPtdrO6kJJBD6NZ634fjTFkyzk5kPeH6ftROtVpuLc83BFz7rp85W4bGcuRLOdYzrwjaUghG/AaEEvMmaYrUI9fL6RNxAak0Fim7XF/8tRy8noR7SM3Ig3YyPT9jphMY2SVVfNI1Bak0PWsPJNeb7787l08xx1/mvGFbLW9t9RZNPSnY2pEo+biEygsjBZoTrqv+K2Lu2MxFSWjDPOTxUhuZegnoY18BEvZPQtLt2eaHEyVL4TBkmzdqCa9it2qc7lPm0WD4pOXMfe7Z2WbREwjYbLL+U2hv7oPjX9Lx/KYQV6yK6Ob/U69fZmLLqMN63AvFiLONWFhrAxp8jWdBhqj0mDitZn78Bq+h59MOcazk/cy9Ug2WSrIrDASvSeDV5ac4+XFF/ndvDM8PeMkD31ykqdGrmNl5PuYB7RzFK+EeDvUv7Y2o46IyOXhtS5KqA+3e3vLzWhJ3by4IsSiuzeXRBwj6OdknzlGanYBVzOy0OpcfyF1sZbfQBnYFsVWZ8WXsZuomvQnKj/9t+vtcm7/JiUDOqHdPMLtnMYYWiMaf5y+D42TaDhTrjNw6tYddqYWsf1yAdsv5xKXcosdV/LZl1ZAxI6LeEdsol1kLEcznS2NOUfT5cBnx2HbOF/knIZuiBCN1pEbZCHakdK4qyFIKiij07DNSGGxxJxtum+mQKnlZx8JC2Etn3+V2uj8rHIFX2TeZvuVW+xIuUVccgFbL+cRf8XBbz7ZK7te7y1xFg3jVzGOQGhNAFNkLpQiQ2FyHYCtRSyPoL92HEP8DHTLg6hY8iGV87tRPe9DquZ1RTv1VYxhrRxuj7iwiYDooE5Y7txrUVB93l+OB8gXvyBJznRodzYuAJqtI+XjrQ1wOuo07gVCjdyzSk26CvSnY9HFjqB6cU/K5n1Ixdz/UDn3TSrnvINyyl8xhYqV7WrEoLeEdua/6r1+rWiIzIuIoYi/mqDWmLIONXqcAqeBxugX86XcN/HA+MM8OO4gIZuSSCkzkFVtYurBbP40/wy/X5zMC7NP8cvpR/jxJ8d5aOw+2ozeQ6ehWxkbEUJl2AM1Qc4a60IWC7GquFiFqyaGURPHKO/nQ0oXiUsiQ9JNFHH5kPSBxKkevmTu30jmzSKupKZTWaVo8o0KzLkXqe7ljeaE6zoMu1GBIuopJx+1LtaiZEoD2qDe42w6NgdZNALX8uKM/Y2KRqnOyCc7z/Ls+G20HrBW9t1FmlUKEinMZUiBIguyUs4itI3aSfvBsRzLciUaGbJoPBq9jdQS54BhQ04I0YiIxTt8PfvT3Dfv1ZJSWMGDoks3bCPrzjctGnkKNU+M3S5nPpZ/5bpb+GLuHbqvOMiPhq3GJ1ikhh3ZFDnl6i8+hzVIQctoM3Q7XuHb+GDxcaf9mE45RMNRPeww9xWrApzm1cV4+xrKue+j6t9aviGXnHbtLWER+6kJPor/EcHUYEdWRmRGtIMewFJ6Td63CKarP33dkV6tqT8SMRTlV45gqztUBxfJgVv5gikqn0UqeKdzw5o+ZQ/VY55H10PC1lXC3tNxB0IR8BT/i2yQRcRyRJamZmU7cdyazxoXDZH+rY56CqPW2VptiNOAOz7el4QUuhbfUXvpEBXP3xd+xbF8HekKK3NO5fP8Z1/yu7ln+e3M4/xy6lEen3iUTuP24zcqgYeG76HV6AP4RCfQbfA4roX/2mFl1Ky65WhGq0lpiQ8tzBulfwtSa4q3LnX3JrmrF1c+kDjzvkR67BRu3iwg5UoGJXfu+ZJNoUvcTGkfX4w3Xa8sbq3KpSK0I4qNUS63C8xZRyjv442qkca2xnCIxhpZNNRuRKNErePVz3Yi9V8p11I8Niaedxbtp8eyg3RdfoSeyw7SbdkJei8/xN9mH6DNsG2ypeFKNOYKSyNkA49GbSL9dvMsjVaDNuATvpYvUpsnGg8MF6IRy4ZzTYtGvkLNT2XRWMtyF5bGrvQ8HhomhHE9XmGb+NP0fXRZeoSey4/SZ/lReqw4RteVJ+i66iiPfxSH14CNvL/YORNjPBUjn4QO18RRLFW10dFoaHcR0DWXZVE98hlZXGRrWMTSRB2FqO8QaVmR9egloRcnaECN2yEC+f61ouFw/aw2I8ppr2OXrQYv+YTUCNFo4qbi6oPzHZZRTdrVUadR3zrRpexGEdAOi3C7alK34n9xbDIieCqOUwhcQ9GY+Wa9fd0VjdrsST8J5ZjnMRubvrA4Dbgi9mI2LQato83wnbQavpufTzzAjrRS0qtsrEwu5zfTDvPz6ad4asYJnpp8gEfHH6PjR1/gNzqOtqN30ylakED7UXvwGrmbFyNnczz8JTmYdG9V8RplDvNBF9KCDFGH8aEQC0cMQ5SKn39b4vLcYLKzc7h8NZPcvOatBVqLems0pVG/xmZy/cEYb12goq83+qNLXG4XGC5toUqYjkk73M5pjOaIxvAtZ5D819EmYj0j4i+Qp3R/K8k96fl4DdogxzRE9WjD7Qtk0VjLj6K3ktZIEVgtsmhEbMBnwFoONEs0yuksi8YGNpx330VcS55Cw0/H7EAKXsPy03VFw0Sp1shz4x0C9NTorWxOykVlcx9Y/efsA3INiiv3xCCyJzVXe7EItVinQhXrvjtZsXaQLBC1jZIWcRJ98kdUcVNQfzET9cF5KI8sQ3NgJroRjznu9BfcQo4JaCIfqndDLeXCPnLmRD5pAyQ5vqHe7ZwJqYt2yzCMQgxqapJkl6ZOTMNqUlL58Z+wdxcpUS+sAV6o/VuimfMuyr2zUR5eiOrIXNTHl6GJG496oJ8jEHvXPXEWDd0AP/n45fOvj0TVR7/HbHL+DTXEaaAhJ3PK6TRiAy2H7KTd8J34DYtjxqlC0sv1bMtQ8rsZR/jxhC/46eRjPPbxFzw87gCdR++j46h4fEftoOPIeDqMisdPCEfUHtqN2oX3yJ38MmI1Kwe9hyncEeeQ4xmhXpjCWpDTVayP4SUHPa908Sa9i8T5dyTOTniLWxmXSbx2k6wbTafl6mKzaikf+yKqle6zHtpLO7jTrzXmLOcrVy3Gg3NQ9/TCnHPe7ZzGGLrlrGxqvzhjH2oXgds7Si1PjtwmV1v2+LzpBXl2JN9ACl9Pm4iNLi2NBUdSkULW8HD0tmaLhnBPfMLXsb+ZouGIaTRTNKrVPD5mmywaKxpYGhuTb+ITsppW4ZvZltT09/uXWUI01vPeEmf3RH9ypWwhOKwGb9nVUG1wfUMtm64S9ehfYRE1CiIYL9Kjw5/EXO5wOerNRYNi7K8cWYdgR5GXPvIBLGX3REMbN16uGnWke71kd6F62qtO+6rFqiyhevSzWOQCMMcxm7uJlOs9F9hw85xcwem4/48Pth4SVfPew25zjuWZK66hCet0N8jpUjSKL6MXolEjLCLVWjn+BczGO077a4jTQF1yK1X8etwOpMjNtIuKp9XAWMK2X+VMqY1DOWpemXsUv+gEHplwkIfH7eeBMXvpNGo3HUcm4OcCWUCid9N2pBCgfXQYupmxkQFUhXV2fLmh3tzq7UXi+y1J6eqIYyR3bUGKyJREPEfupROkZ+ZwJTMHg8HZxHRJTdOW8dZpioI7Y0xzLsSpRSx6Ujz4CSwa55OvFtXGSCpDOmKpajy9645hQjQCVvPi9L1oXIhGUn4lHQdvlE/0aYfqZxdcMf/YVbm4q23EJjeicVU+QR+O2kr6bdcWVl0c2ZNYWoSv50CzYhoiECoqU4VouO91qCW3WsXjY7bK7snKBjGN6XscgvrQyB1kV9WsmeqiQE5wR2vkadkqcS0ahi8douHw7R0rYinWuxYNY3UhmsjHHOXiIs7WV6Jq2msu5+pTD6IKbnP3xl3iToHqIQ9jrbNWiz7tC9m9ljMs4gQP8kIn0r2bR2Kz1f/dWtRFKOY7UqRypkO8vhCabsI9uScauuRdaOX3I1web9kSUce5vr2o6tA8tH3FPMf7F+Xmmln1RcNSdBmDyJ4IERLWWH+JqnHPYzE03tMjcBqoRWOx8vrcA0hhW2kXvRtpUCxvLT7NoXw9J3M1vLv8HK2GbqPz6L10HrOXjqN24zdy1z2ihXUhROIeHaPi6TQijjYjE2g7ajuto3bSduh2ekeOJCficVR9vbjyvg9J3bxJ7SrJ2ZJEkSnp92NuHE/gelYBV1JzULipZnRF7S0WFasHUvrxS4g7yDecU0vVrH+jnl0/YNQQxew3KZn0EljduwyN0ZRoXC1V0Gn4Nrlqcsj2xq2ZKpOZP07fj1fEVrm2wpVoLDx6Ve4zeehrikbLgRs4kNb01T6lsPSeaFxoWjTyGhGNJccS5f6UNoM3c+xW4wG5lReuy8foHb6J9125J1+ukt0TR5uCI6jpTjSsmgrUo37uKMkWN+QKkFAO6Iz20qZ68/VpB1BF/UL2/+2hIhgqKj0l1IN/fDemIe/PbKD80zdkoXJY0aJgywutcHlmvoPuxEJMF7ah2f8plRN/68i0hDhKEsRcW2BLWRR0CfdcGmP2KVT+rR11HAIRpxj1AsbCe8V6VqsW3akYVGEPOUrla2KFIlDqSjT0LkWjaWvUaaCWYTvOIg1YQ9uoPfgMiuM3n+xm2zU1XxbZCN54iZaDttJu5F58R9URChei4Re1kw41+I6Ip330djqP2IpvVALto+LxHZGAz4jd/Dl8Aut6/ZrsrhJpsmB4k/6+xLmubbgW/zlZN4pJTL1GSUXTP/yGWMuucCf8xxgSt7t9rrXyFkVhD6I7ONftHLtZgXrokyhXD3I7pymGbT0rN369OGOvS/dEb7HyyowE2dx/bOQWjt9wFgLBbaWOrsu+kLMpbYbHuQ2EyqIRuLr5opFdSJtIh2h8kd60aCTXWhphscRebNo9yZXdk61yLKKhaCQVVdBeNNMN3MJ7C/dQZXT+fAQJKbk8ELURKTIOr8hNvLf0sNM8YWnI2Qhx4ohbeArRcOOeCFTLuslFUKIcQE6livqLoDZyxaZ6ZSCaz15DFdxazpbIK+WHOhaIEiedLvJRLGX1XRlT5nGqA9vLbow9sAXm4DZ3XQXRVyIETQQshVVDYAv5OOV+FxFkDfCWO171dcrIrVoFijG/wS4EpiaBYBTWS+TjKJe8j3a5v3zDMZXI7IhgrZyhrCMaDd2TwnuiIWds/lvRiE2+JZunHYZtxWf4Jh4dHs/ic3c4WWJh5J4cWg/ZRrvhQhSEQMTXEYsEOkQnyC6LbGXUEYwOUXH4CkbsxS9qGx1H7KTj8J2O+cO2yP0GT/SfwKd9XyS1RyvZ0jj3H2+urh7HzZwcUq5mkFf89VyC2gKdyhXBVCzt2ehz9V/FcCfsQczl7qsU9TmnqOzdEvPxNW7nNIUsGgFCNFzHNAQJyTfxDl2DFLZFLrces/UMmy5kciAtnx1JuUzclcwvx8c5xOezA/hF75ALslyJxqJjqbKlIWIaGc0QjWPC0ojcSMuBsc0SjXvuiRCN5lgaNTENF6IhCIo5LIucFLaZlz/dz+KjGRy5VsDh6yWsOnOTXiuOIgWt4EfR23huykG8wkSdhvM9awwnVso9HnKtgghsNiEahtzTVIY/KBdiyTGF4Fay5WEWmRMRnxAl4f4SZtGXEtJSzpwIy0AERPWDH8Rcx9KoRfXlGhSi56Q22yEyhQE+cgm6fIUPECLRUhYik7iLYIjDIpGrWEUmZFf9tL762FK03RwFZY7KaS85FiEsFZHZEYIi4jKa4BZYQ9vddc2EaDSMaTgsDV9H3KOOaJi/iWgUq/T8YsI2WkRuod2IPbQespEx+zM4eQc+PVnIg8M20WZoAr7RCXSMjpNdDiEQjjhGjXVR65I0EI2OI3bgNyIeX2F1RCXQblQcHUZspX3ocjoELqFl8FI69p/N4N7vcPS9NqTO6MOtrGyS066Rfcv9ydwYupQE8if8DZuy8UxLxWfvUjWv8dXI9QfmUNLHB2O+687K5jBw/Umkrot5dsJ2FG5EQ7D0RDoPihXLA0VNgqigXI1XyBpHW3rPz5GCP+ejXZc4caMMKSQGqd9SvshwFtXZB0Vr/BJaD1xDarGjhb0xDl7Ld9RD9FvOnqvNKO7KK8ErZDVSr89ZfSajyfk5VUo6RsYgdVvMouN1+1oclGkNdF16GO8QkW4Wrfgr8AregHeoWA5gBVKvRTw5dgPHbpTQe9khpA8X8/qcfU770R5ZgvZ9CZtYCLqnhPFdicrVjVc76s9voTr8IfQiQyGCqEJARIdqX0cptkqkTlf3RjXlRSwfOk5SUSuhF5bEHWfRkI/jwlbKo3+FRgiP2K+ooRC9ISI+Iao+u0tUfvwi2rVh8utaezgsEcPbEtrtzo2Vyu0jUfZtLQuZqAURDWa1Lfsi5aoK74z24Ax0o5/B2sVxjKYPJBRyjOZefMhckISmr4Stm8P6EXPLon7e6Kp1tTgNfLzrknzV6BC1Fa+IWN5bdp5jBUZiLlfz5LgE2gzeQseoXXJA864LIhCi4VYw6rgoMvH4CUtjxHbaDlxJh8B5dA6aR9vQhbQJWorUdTLDx47lVkYyVzJyyc7IxOjGVG0MS1k2eTM/xJDd+P0jxKImJQEPYbwS1+g89bz3qJ74IrYGK0B9HbZcuIH/qpN8tucs2kZEQ3C5oJyPdl7g77P28uvxW/jlmM288MlOwtad4niGY2WywmoNkRtPE7X5FBl3nINYR9IL6BtzUt5+u7rxBjiByLBErDtJ6LqTJBc1LTJ5FQoGx54mNOY4p3OcLZ2GlGn1suUUvPIYJ7Jc9zeIfMCOxCyCVx7lDx9v44nR23hqzGb+MTOeGfuSKax29I3EHL9M4KoTLDrmLD66rFOoVwShXxuOZl0Y6uX+KM5vdZrXEGNhCsodY+VAaGX00yiiHqcq+ldUzuuB5sw6bHYD6pOr0Yp9rxuALiYMbewQjCr3J5tJUYjq0EJU8/5DxdhfUxX1JNXRv6L603dQ7vsUs7YIQ1EyipgB8vGq10WgWe6PLsmxaFBDtGlHUK8diGLiiyiinkQx4nHKxr+Eck04pluOGiTl7uloVwVjXDMAzcoQFAcXIe7dU7sPQ3UuqrXD0a0JRbNuILpVgVTGT8Jidm4ibEi9ByWiCWjcJtpGbKPNsK10HLmTlYmV7MvR8srMI7QauBG/qAQ6RCXIfztG7aRj9E6HleEihtEQvxHCRYmXYxmdouPoMGg1bQMX0yloNn4hM/ELWkqr3rN4cvAS9ifdIO1GDikZ11Fpm/6xN8SiqaZg00doMxyRdSPu8/2alaFUf/xn7Hbn9NXd/SkLuT3wp+gOzHA757ukXG+hRKNH05Rguck2fG98y68vgsUlKh1lGr3jOulizl2+xcWULXYdZk0BBtUNzM2okhSvbHUsduC0rS5WbTVmZTFGXTE23P/e7s5vZMlGs1mNWVmAVZGPxdi8qmjBf7vodL0Hm5Oz8Q5fS8fhu/CJ2My/Pz/DiWILA7cn0yJ8kxy0FCe9QIiAcDc6joiTRaNWOBoKhSvREFaJ7+AN+AYuoFPgPHyDF9A+eAFt+y7kgcDPiD2WTM7NfNKuXEFR2fTVriFmrYo7ZxPQNNKtWIvldiJlgR0xXXK+Chm51xGq+3I5JcH3yoXvP/67H9p3h+vjsn7ftzG0GTHRuOX4TbC5eX9fF7EmaMOxb0q9B8O2npF7GdqP2E3bIVuZcvgGWzLUPDYuntaDd9Dhrmg4RECOUUTF1ROLuy6KC9EQdIreSaehm2gXvAS/wPl0DJpPu5AFdPBfQqte0/l0x1EKbuWScjWdopKmC00aYrOYqLqdg1HZ9NVBULW4FxXT32hybsX0f6JY3KPJeR5+eHzdE0/M/yHdO/X7Rn7nLsZrqfeg69KjeA/cTOth2/nRyO2svlzNkLgMvCI20CFKBDFrYxIOHNbDTtkluftXiEmNJdIQOXg6bCu+QjAC5tEhcD6+QYKF+HSfxIClO8m6dZurV9PJz6u/0tDXoTbm0FTswZC2l/zIpzAVNN7Sbcw6RnH/Dhgy9jc6z4OH+4F6D16fc5gWgzbQeuh2fjEugZirKv46+ygtB29xEoC7jHBQKxh3YxojRHxDWCLbHelWYX2M2Ebb0FX49V9Ah6A5+AbNo1PgArx6zOStSetJz8onIz2TzOtNp/r+W+z6cgomvYZYbLjhtoYoFvaj+pO/YG/Ev/Tg4X7h7j8mG7w265CcMWkzdAe/nLCX+efL+OWEXXLVpijMchKMJqmpzRDiER2Hb/gK2gcskC2MzgFz8QtaiNRnLi8MXsKJKzlkXb9JRvp1dPrv/uQsXRdFaSPdrLVYcs9T2t8X0zdsUPPg4f8a9R68Of8QUuQm2g6L44lxexh3OI/HR22n/XARz2i+aMhxjqg42stVnwlyHMM3Yi3tAhyBzw5B8/ALWkDrfvN4KGgu205cJe/mDVJSr6Go1nznJ6fyxBqKlwVjtzQd7a5a3JfKKa9SW47uwcP9Tr0HAauOIQ2Mpd2wOB4eGU9oXCaPjo6n/QjhYtyLYzRFrZsiZ0pEanZwLO0CF9E2aD4d5YzJYnyC59O+12QWbD9NTl4Rl6+kc8dFncG3jerKfgqWDcGmdb8AcS2mG6coCP8JpmzX62948HA/Uu/BZ/sS5a5B2aoYuo0PYxJ5fMIB2g/b5lIwGsuSCMEQdRydh2yifdASfEXgM2g+foEL5MfePaYw+PMEbuYUc/VqBrn5ztWM3zbqG5fI3zIJi7IZWRm7kTsz3kW1fWLTcz14uI+o9+Bsbim+kRtpOzyetkO38Nzk/Tzx8WHaD9tO+2hnYXBQXzjkLIooFY9OoNPwzfgGLaGD/3w6BC6QU6wiWyL1mMb7U2NJvVFEakYG17O/WYn410GRk0Lx0U2IGyI13OYK1aEF3JnxBphrWrQ9ePAgU++ByWbltak7kQZuxnd4HH7Dt9NZFGLVxClE2tVBfZEQBV4O68IhGJ2iduE3fAvtQhfj5z+HTgHz6RC0gI7BC/DqNZPfD1vCmav5XM/KISMjC33NPUa/K5S5qZSlfYnN0ryWemPOKW59/BrmkqvNmu/Bw/2E08CKwxeRes3Bd1g8baN20GbkdnxFY5pYtUuu6NyBb41IyIiUqywojjG5w3XIFjoELcIvYBadAufIQc8OwQtp3W82jwbMYsepNPJu5JN6NQul6uuXiH8ddJVFaMqan8K1a8rJmdUdlZu6fw8e7necBkQT1V8+WoXUa75cFeqo+IyjbbToGXGsgSFu2dcuWlggu2gfvYv28voZcXQetpEOA1fSXhaMeXQOnCuLhW/QYtoFzKdVr2nM3Hmc/LxCuYCrvKx5rsI3RpT2NrLojitux46gct+ir/UcDx7uJ5wGBOduFfNo30/w7jmLdmGr6Ri5Ft8RW/AbsZ2ONTUXYg0HUUbeYfg2fIduwndgDL5Bi/ANEJaFCHouoGPAfNoFLaRt4AJad/mYAUt3cz2viLTUNPKKmxGM/J65cziGop3f7NYEHjzcLzgN1BJ/IQ2/nhOQ+nxK28D5dAhYSPvgpbQP+5z2okhrwArah6ygfdBifEXMwn8+fv6iNHyeHOwUWZLO/gtoGzAf764T6DFrK2k3CkhLv0lOTuNrW/z/oPzcVgp3L/zBHZcHDz80nAbqsivxGj8K/hSpxyx8A+bSvoYO/nPo4D8P38CFtA9aIKdTOwYIy2KB3LnqWyMyrfrOp0WPKfgv2MqV7CKuZVwn43oOhm/hHqbfJmVJB7h9POYHdUwePPxQcRpoSGpRJW98shbv7hNo0WemXNXZPkjEKRbQMWguHQPn4isj0qpCLObRru8svHtO5cdhnzEuZh9JKdlcOH+Fc5cuc6ugmLLyKkrLKigvr6CiooqqKgUKhRKlUo1Go0Wn02EwGDGZvvsqzPLU45ReavpWdB48eHDgNFCLyW5GrTdh0aopul3O+PXHeG7wYvz6zMCnx0x8+syjVf+5skC06TuTFn1m4d3rM9r0nMnPBywmcPZWdhxP4kJSBl+euci55GRu5hdSVFxKQWEJRcV3KL5dSklJOXdKKyktq5LFpKKyWr7NYlW1EoVSjVKlQaPRodUZMBi/PSGxmo2U30pDkee86pMHDx7c4zQgKCkuITP9Jkmp2SRezSA1PZMbOYWcSExj3rYv6DtjLX8dtZznh33Os0OW89zQlfx55Aq6Tolh6oYDxJ24xOmkq5w9d4WvziVx+do18gtuU1h0h4KiEvmvEI/bJeWU3KkVjGrKKxRUVqmoqlahUKpkwVBrdGi0ermJTdzrxPgtCYe2LA9D9Q8vGOvBww8dpwGBKLi6lJjGxZRMkq5mcTk1k7S0bLKu3SIrK5ekK9c4cTaZ/cfOk3D4HLuOXeDgqUROnUvh3PlEzp47z5lLyVxOuy7fc7W4oIT8gjvkF94TjOLbZTWiUdFANOpbGd+FaNgtJqxNrLXhwYMH1zgN1FKlVlNQWMzNm/lkZuaQlnaD1LRM2epIz7xO2rXrXE7LIvlyGklJl0lMukpicjqX07LJuJ7PjZxicvKLyCko5lb+bfIKbsvWRkHhHQqLSikqFqJRIVsawj0RoiGoqFTKlka1QoVCpUapdgiHcE9E5agQjYbH6sGDh+8PpwF36PVGFGoN5VUKSsoqKL5TRmGxw3rILbgtcyu/mFt5xXLXak5eATl5hdzKLyK3oJi8Qodo3HNNyrhTWiHHMcorRBxDSaXslmhRCetCp0Wn16M3GjA2sWq3Bw8evj+cBr4tTGYLRpMZk9mMqcHfhnM9ePDwvwenAQ8ePHhoDKcBDx48eGiM/wf3Rn8BNtgcqQAAAABJRU5ErkJggg==" alt="Farma Radar" width="135" height="36" class="h-8 sm:h-9 w-auto object-contain select-none shrink-0" />
                </div>

                <div class="h-5 w-px bg-slate-200 hidden sm:block"></div>

                <!-- Birleştirilmiş Ana Sekmeler -->
                <nav class="flex items-center space-x-1 bg-slate-100/80 p-1 rounded-xl border border-slate-200/70 shrink-0">
                    <button id="mainTabDepo" onclick="switchMainView('depo')" class="py-1.5 px-3 rounded-lg bg-white text-indigo-700 shadow-2xs font-bold text-xs flex items-center space-x-1.5 transition cursor-pointer shrink-0 whitespace-nowrap">
                        <i class="fa-solid fa-magnifying-glass-dollar text-indigo-600 text-[11px]"></i>
                        <span>Depo Sorgu</span>
                    </button>
                    <button id="mainTabSmartOrder" onclick="switchMainView('smart_order')" class="py-1.5 px-3 rounded-lg text-slate-600 hover:text-slate-900 font-semibold text-xs flex items-center space-x-1.5 transition cursor-pointer shrink-0 whitespace-nowrap">
                        <i class="fa-solid fa-layer-group text-slate-500 text-[11px]"></i>
                        <span id="mainTabSmartOrderLabel">Toplu Sipariş</span>
                        <span id="smartOrderTabBadge" class="hidden text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700">0</span>
                    </button>
                    <button id="mainTabMarket" onclick="switchMainView('market')" class="py-1.5 px-3 rounded-lg text-slate-600 hover:text-slate-900 font-semibold text-xs flex items-center space-x-1.5 transition cursor-pointer shrink-0 whitespace-nowrap">
                        <i class="fa-solid fa-store text-slate-500 text-[11px]"></i>
                        <span>Pazaryeri</span>
                    </button>
                </nav>

                <!-- Gün Sonu & Sabit Yok Listesi -->
                <button type="button" onclick="openEndOfDaySummaryModal('summary')" class="hidden lg:inline-flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl font-bold text-xs bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer whitespace-nowrap shrink-0" title="Gün Sonu Depo Sipariş Özeti, Sipariş Verilmeyecekler ve Yok Listesi">
                    <i class="fa-solid fa-clipboard-check text-slate-500 text-[11px]"></i>
                    <span>Gün Sonu Özeti</span>
                    <span id="eodHeaderSummaryBadge" class="px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-800 text-[10px] font-extrabold leading-tight">0</span>
                </button>
                <button type="button" id="headerYokListBtn" onclick="togglePersistentYokBar(true)" class="inline-flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl font-extrabold text-xs bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 transition cursor-pointer whitespace-nowrap shrink-0" title="Sabit Yok Listesi Panelini Aç / Göster">
                    <i class="fa-solid fa-thumbtack text-rose-600 text-[10px]"></i>
                    <span>Yok Listesi</span>
                    <span id="headerYokCountBadge" class="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-black leading-tight">0</span>
                </button>
            </div>
            
            <!-- Sağ: Otomasyon Durumu, Tekil Sepet Merkezi, Sürüm & Ayarlar -->
            <div class="flex items-center space-x-1.5 text-[11px] shrink-0 whitespace-nowrap">
                <!-- Aktif Eczane Otomasyonu Durum Butonu (Sakin yeşil durum noktası ile) -->
                <button type="button" onclick="openCurrentOtomasyonSettings()" id="headerActiveOtomasyonBtn" class="inline-flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl font-semibold bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer whitespace-nowrap shrink-0" title="Eczane Otomasyonu Bağlantı & Ayarları">
                    <span id="headerOtomasyonDot" class="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                    <i id="headerOtomasyonIcon" class="fa-solid fa-leaf text-emerald-600 text-[11px]"></i>
                    <span id="headerOtomasyonText">Botanik EOS</span>
                </button>

                <!-- Aktif Depolar Rozeti -->
                <button type="button" onclick="openSettingsModal('depolar')" id="headerDepoBadgeBtn" class="hidden xl:inline-flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl font-semibold bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer whitespace-nowrap shrink-0" title="Ecza depoları giriş şifrelerini ve aktiflik durumunu aç">
                    <span id="headerDepoDot" class="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span id="headerDepoText">6 Depo</span>
                </button>

                <!-- Tek ve Şık Sepet Butonu (Tüm sepet özetini burada toplar) -->
                <button type="button" onclick="openMultiDepotCartModal()" id="headerCartBtn" class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 transition cursor-pointer whitespace-nowrap shrink-0" title="Depo Sepetlerim: Sepetteki ürünleri depolara göre inceleyin ve sepete gidin">
                    <i class="fa-solid fa-cart-shopping text-indigo-600 text-xs"></i>
                    <span>Sepetlerim</span>
                    <span id="headerCartCountBadge" class="px-1.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-extrabold leading-none">0</span>
                    <span id="headerCartDepotPills" class="hidden sm:inline-flex items-center gap-1 ml-0.5"></span>
                </button>

                <!-- Sürüm Rozeti -->
                <button type="button" onclick="openUpdateModal()" id="headerVersionBtn" class="inline-flex items-center space-x-1 px-2.5 py-1.5 rounded-xl font-semibold bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 transition cursor-pointer whitespace-nowrap shrink-0" title="Program Sürümü ve Güncellemeleri Denetle">
                    <i class="fa-solid fa-cloud-arrow-down text-slate-400 text-[11px]" id="headerVersionIcon"></i>
                    <span id="headerVersionText">v1.5.0</span>
                    <span id="headerUpdateDot" class="hidden w-2 h-2 rounded-full bg-amber-500"></span>
                </button>

                <!-- Ayarlar Butonu -->
                <button type="button" onclick="openSettingsModal()" id="headerSettingsBtn" class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl font-bold bg-slate-900 hover:bg-slate-800 text-white transition cursor-pointer whitespace-nowrap shrink-0" title="Eczane Otomasyonu, Depolar ve Sistem Ayarlarını Aç">
                    <i class="fa-solid fa-sliders text-slate-300 text-[11px]"></i>
                    <span>Ayarlar</span>
                </button>
            </div>
        </div>
    </header>

    <!-- Geriye dönük JS uyumluluğu için gizli durum tutucu -->
    <div id="botanikDataStatusPill" class="hidden">
        <span id="dataStatusIcon"></span>
        <span id="dataStatusText"></span>
    </div>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <!-- SABİT (KALICI) YOK LİSTESİ & STOĞA GİRENLER TAKİP PANELİ -->
        <div id="persistentYokTopPanel" class="hidden mb-4 rounded-2xl border-2 border-rose-200 bg-gradient-to-r from-white via-rose-50/40 to-white shadow-sm overflow-hidden transition-all">
            <div class="px-4 py-2.5 bg-gradient-to-r from-rose-900 via-slate-900 to-indigo-950 text-white flex flex-wrap items-center justify-between gap-2">
                <div class="flex items-center space-x-2.5">
                    <span class="w-7 h-7 rounded-lg bg-rose-500/25 border border-rose-400/40 flex items-center justify-center text-rose-300 text-xs font-black">
                        <i class="fa-solid fa-thumbtack"></i>
                    </span>
                    <div>
                        <div class="flex items-center space-x-2">
                            <span class="text-xs font-black tracking-wide text-white">📌 SABİT YOK LİSTESİ & EKSİK İLAÇ TAKİP PANELİ</span>
                            <span id="persistentYokCountPill" class="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black">0 Kalem</span>
                            <span id="persistentVarCountPill" class="hidden px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black animate-pulse">0 Stoğa Girdi!</span>
                        </div>
                    </div>
                </div>
                <div class="flex flex-wrap items-center gap-1.5">
                    <div class="flex items-center bg-white/10 rounded-lg border border-white/20 px-2 py-0.5">
                        <input type="text" id="quickPinYokInput" onkeydown="if(event.key==='Enter') addQuickItemToYokListFromBar()" placeholder="Hızlı Yok ekle (İlaç adı / barkod)..." class="bg-transparent text-white placeholder-slate-300 text-[11px] font-semibold focus:outline-none w-44 sm:w-56" />
                        <button type="button" onclick="addQuickItemToYokListFromBar()" class="ml-1 px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-black cursor-pointer">+ Ekle</button>
                    </div>
                    <button type="button" id="btnScanYokInDepotsTop" onclick="scanYokListItemsInDepots()" class="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-black transition cursor-pointer flex items-center space-x-1" title="Yok listesindeki ilaçları tüm aktif depolarda tekrar sorgula">
                        <i class="fa-solid fa-radar text-[9px]"></i>
                        <span>Depolarda Sorgula</span>
                    </button>
                    <button type="button" onclick="openEndOfDaySummaryModal('yok')" class="px-2.5 py-1 rounded-lg bg-white/15 hover:bg-white/25 text-white text-[10px] font-bold transition cursor-pointer">
                        Detaylı Liste ↗
                    </button>
                    <button type="button" onclick="togglePersistentYokBar(false)" class="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 flex items-center justify-center cursor-pointer" title="Daralt / Gizle">
                        <i class="fa-solid fa-chevron-up text-[10px]"></i>
                    </button>
                </div>
            </div>
            <div id="persistentYokBody" class="p-3 space-y-2">
                <!-- JS tarafından doldurulur -->
            </div>
        </div>

        <!-- VIEW 1: DEPO & MF KARŞILAŞTIRMA (Depo Modülü) -->
        <div id="viewDepo" class="space-y-5 relative">
        <!-- Search Box Container -->
        <div class="max-w-3xl mx-auto">
            <div class="relative">
                <div class="bg-white p-2 rounded-2xl shadow-sm border border-slate-200/90 focus-within:border-indigo-500 focus-within:ring-4 focus-within:ring-indigo-500/10 flex items-center space-x-2.5 relative z-30 transition">
                    <div class="pl-3 text-slate-400">
                        <i class="fa-solid fa-magnifying-glass text-base"></i>
                    </div>
                    <input 
                        type="text" 
                        id="searchInput" 
                        placeholder="İlaç adı, barkod (869...) veya OTC ürün ara..."
                        class="w-full py-2 text-sm sm:text-base font-medium text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
                        autocomplete="off"
                        autofocus
                    >
                    <button 
                        id="searchBtn" 
                        onclick="handleSearchSubmit()"
                        class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-sm transition flex items-center space-x-1.5 shrink-0 cursor-pointer shadow-2xs"
                    >
                        <span>Sorgula</span>
                    </button>
                </div>

                <!-- Auto-Suggest Dropdown -->
                <div id="suggestBox" class="hidden absolute left-0 right-0 top-full mt-1.5 bg-white rounded-2xl border border-slate-200 shadow-xl z-50 overflow-hidden divide-y divide-slate-100 max-h-96 overflow-y-auto">
                </div>
            </div>
            
            <!-- Sadece Aktif Takas / Ortak Alım Kısayolları (Demo örnek ilaçlar kaldırıldı) -->
            <div class="mt-2 flex flex-wrap items-center justify-end gap-2 text-xs">
                <button id="etQuickOffersChipBtn" onclick="openEczaneTakasOffersModal()" class="hidden px-2.5 py-1 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 text-slate-700 font-semibold transition items-center space-x-1.5 cursor-pointer shadow-2xs" title="EczaneTakas üzerindeki aktif teklifleri gör"><i class="fa-solid fa-arrow-right-arrow-left text-[10px] text-indigo-600"></i><span>EczaneTakas Teklifleri</span></button>
                <button id="eczatrendQuickOffersChipBtn" onclick="openEczatrendOffersModal()" class="hidden px-2.5 py-1 bg-white hover:bg-slate-50 rounded-lg border border-slate-200 text-slate-700 font-semibold transition items-center space-x-1.5 cursor-pointer shadow-2xs" title="Eczatrend ortak alım grubundaki aktif teklifleri gör"><i class="fa-solid fa-users-rectangle text-[10px] text-amber-600"></i><span>Eczatrend Teklifleri</span></button>
            </div>
        </div>

        <!-- Loading Spinner -->
        <div id="loading" class="hidden text-center py-12">
            <div class="inline-block animate-spin rounded-full h-10 w-10 border-3 border-indigo-600 border-t-transparent"></div>
            <p class="mt-3 text-sm font-semibold text-slate-700" id="loadingText">Depo şartları taranıyor...</p>
            <p class="text-xs text-slate-400 mt-0.5">Aktif depolar eşzamanlı sorgulanıyor...</p>
        </div>

        <!-- Product Selection Grid -->
        <div id="productSelection" class="hidden mb-6 space-y-3">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-base font-bold text-slate-900" id="selectionTitle">Eşleşen Ürünler</h2>
                    <p class="text-xs text-slate-500">Karşılaştırmak istediğiniz ürünü seçin:</p>
                </div>
                <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-600" id="selectionCount">0 Ürün</span>
            </div>
            <div id="selectionGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3"></div>
        </div>

        <!-- Result Container (CLEAN BENTO DESIGN + İLK BAKIŞTA DEPO TABLOSU) -->
        <div id="results" class="hidden space-y-4">
            <!-- Bugün Sipariş Verildi / Sepette Uyarısı -->
            <div id="resTodayOrderedBanner" class="hidden"></div>

            <!-- ÜST BENTO GRID: SOLDA ÜRÜN & FİYAT ÖZETİ | SAĞDA ECZANE STOK & 6 AYLIK ÇIKIŞ ÖZETİ -->
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
                <!-- SOL KART: Ürün Bilgisi, PSF/KSF/Kâr ve En Avantajlı Depo -->
                <div class="lg:col-span-6 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between space-y-3.5">
                    <div>
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <div class="flex flex-wrap items-center gap-1.5">
                                <span class="text-xs font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-mono border border-slate-200" id="resBarcode">8699717010109</span>
                                <span class="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200" id="resStockCount">3 Depoda Stokta</span>
                                <span id="resColdChainBadge" class="hidden text-xs font-semibold text-sky-800 bg-sky-50 px-2 py-0.5 rounded-md border border-sky-200 items-center">
                                    <i class="fa-solid fa-snowflake text-sky-500 mr-1"></i>Soğuk Zincir
                                </span>
                            </div>
                            <button type="button" id="resEquivalentsBtn" onclick="scrollToMuadillerTab()" class="hidden text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded-lg border border-indigo-200 transition items-center space-x-1 cursor-pointer">
                                <i class="fa-solid fa-arrows-split-up-and-left text-[11px] text-indigo-600"></i>
                                <span id="resEquivalentsBtnText">Muadiller</span>
                            </button>
                        </div>

                        <h2 class="text-lg font-extrabold text-slate-900 mt-2 leading-snug" id="resTitle">PAROL 500 MG 20 TB.</h2>

                        <!-- 4'lü Kompakt Fiyat & Kâr Izgarası -->
                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-3">
                            <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
                                <div class="text-[10px] font-semibold text-slate-400 uppercase">Elden (PSF)</div>
                                <div class="text-sm font-extrabold text-slate-900 mt-0.5 font-mono" id="resPsf">0.00 ₺</div>
                                <div class="text-[10px] text-slate-500 mt-0.5 truncate" id="resVatInfo">KDV: <strong>%10</strong></div>
                            </div>
                            <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
                                <div class="text-[10px] font-semibold text-slate-400 uppercase">Kamu (KSF)</div>
                                <div class="text-sm font-extrabold text-indigo-900 mt-0.5 font-mono" id="resKsf">0.00 ₺</div>
                                <div class="text-[10px] text-slate-500 mt-0.5" id="resSgkInfo">Kamu İsk: <strong id="resKamuIsk" class="text-slate-700">%0.0</strong></div>
                            </div>
                            <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
                                <div class="text-[10px] font-semibold text-slate-400 uppercase">SGK Kutu Kârı</div>
                                <div class="text-sm font-extrabold text-indigo-700 mt-0.5 font-mono" id="resKamuProfit">+0.00 ₺</div>
                                <div class="text-[10px] text-slate-500 mt-0.5" id="resKarInfo">Yasal Kâr: <strong id="resEczaciKari" class="text-slate-700">%0.0</strong></div>
                            </div>
                            <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
                                <div class="text-[10px] font-semibold text-slate-400 uppercase">Elden Kutu Kârı</div>
                                <div class="text-sm font-extrabold text-emerald-700 mt-0.5 font-mono" id="resPerakendeProfit">+0.00 ₺</div>
                                <div class="text-[10px] text-slate-500 mt-0.5">Perakende Net</div>
                            </div>
                        </div>
                    </div>

                    <!-- Alt Kısım: Seçili / En Avantajlı Depo & Muadil Fırsatı -->
                    <div class="space-y-2 pt-1" id="resProfitBadges">
                        <div id="bestDealBanner" class="hidden bg-gradient-to-r from-emerald-50 via-teal-50/70 to-emerald-50/50 border border-emerald-200 rounded-xl p-3 flex items-center justify-between gap-3">
                            <div class="flex items-center space-x-3">
                                <div id="bestDealIconBox" class="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-sm shrink-0 shadow-2xs">
                                    <i id="bestDealIcon" class="fa-solid fa-trophy"></i>
                                </div>
                                <div>
                                    <div class="flex items-center gap-1.5">
                                        <span id="bestDealBannerTitle" class="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">En Avantajlı Depo</span>
                                        <button type="button" id="btnResetToBestDeal" onclick="resetSimToBestDeal()" class="hidden px-1.5 py-0.2 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold transition cursor-pointer" title="En avantajlı depoya geri dön">↺ En Uygununa Dön</button>
                                    </div>
                                    <div class="text-sm font-extrabold text-emerald-950" id="bestDepoName">NEVZAT ECZA</div>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="text-sm font-extrabold text-emerald-800 font-mono" id="bestCost">52.31 ₺ <span class="text-[10px] font-normal">(KDV H.)</span></div>
                                <div class="text-[11px] text-emerald-700 font-medium">KDV Dahil: <strong class="font-mono" id="bestCostKdvli">57.54 ₺</strong></div>
                            </div>
                        </div>

                        <div id="resMuadilProfitOpportunity" onclick="scrollToMuadillerTab()" class="hidden cursor-pointer items-center justify-between px-3 py-2 rounded-xl bg-gradient-to-r from-amber-50 via-orange-50/60 to-amber-50 border border-amber-300 text-xs text-amber-950 font-semibold hover:from-amber-100 hover:to-orange-100/70 transition shadow-2xs">
                            <div class="flex items-center space-x-2 truncate">
                                <i class="fa-solid fa-wand-magic-sparkles text-amber-600"></i>
                                <span class="truncate">Kârlı Muadil: <strong id="resBestMuadilName" class="font-extrabold">--</strong> (<strong id="resBestMuadilGain" class="text-emerald-700 font-black">+0.00 ₺</strong>/kutu)</span>
                            </div>
                            <span class="text-indigo-700 font-extrabold ml-2 shrink-0">İncele &rarr;</span>
                        </div>
                    </div>
                </div>

                <!-- SAĞ KART: Eczane Raf Stoğu & 6 Aylık Çıkış / Alışlar / Muadiller Özeti (Renklendirilmiş Bento Kart) -->
                <div class="lg:col-span-6 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between space-y-3">
                    <!-- Üst Başlık & Renkli Görünüm Sekmeleri -->
                    <div class="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-100">
                        <div class="flex items-center space-x-2">
                            <span id="otoBrandBadge" class="inline-flex items-center px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase bg-emerald-50 text-emerald-800 border border-emerald-200">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5"></span>
                                <span id="otoBrandText">ECZANE OTOMASYONU</span>
                            </span>
                            <span id="triaHostSubBadge" class="text-[11px] text-slate-400 font-mono hidden sm:inline">Canlı</span>
                        </div>

                        <!-- Renklendirilmiş Sekmeler (6 Ay Çıkış / Alışlar / Muadiller) -->
                        <div class="flex items-center gap-1.5 bg-slate-100/90 p-1 rounded-xl border border-slate-200/70">
                            <button type="button" id="tabBtnCikislar" onclick="switchOtomasyonMovementsTab('cikis')" class="px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-indigo-600 text-white shadow-2xs transition flex items-center space-x-1 cursor-pointer">
                                <i class="fa-solid fa-chart-column text-[10px]"></i>
                                <span>6 Ay Çıkış</span>
                            </button>
                            <button type="button" id="tabBtnGirisler" onclick="switchOtomasyonMovementsTab('giris')" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-50/90 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 transition flex items-center space-x-1 cursor-pointer">
                                <i class="fa-solid fa-file-invoice-dollar text-[10px] text-emerald-600"></i>
                                <span>Alışlar</span>
                                <span id="badgeGirisCount" class="px-1.5 py-0.2 rounded-full text-[9px] font-extrabold bg-emerald-200/80 text-emerald-900">0</span>
                            </button>
                            <button type="button" id="tabBtnMuadiller" onclick="switchOtomasyonMovementsTab('muadil')" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-50/90 hover:bg-amber-100 text-amber-900 border border-amber-200/80 transition flex items-center space-x-1 cursor-pointer">
                                <i class="fa-solid fa-pills text-[10px] text-amber-600"></i>
                                <span>Muadiller</span>
                                <span id="badgeMuadilCount" class="px-1.5 py-0.2 rounded-full text-[9px] font-extrabold bg-amber-200 text-amber-950">0</span>
                            </button>
                            <button type="button" id="tabBtnBoth" onclick="switchOtomasyonMovementsTab('both')" class="hidden"></button>
                        </div>
                    </div>

                    <!-- 4'lü Renklendirilmiş Otomasyon Özet Metrikleri (Raf Stoğu, Aylık Ort, Stok Süresi, 30G Öneri) -->
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                        <div id="triaStockMetricBox" class="bg-gradient-to-br from-emerald-50 via-teal-50/60 to-white rounded-xl p-2.5 border border-emerald-200/90 shadow-2xs transition">
                            <div class="text-[10px] font-extrabold text-emerald-700 uppercase flex items-center justify-center gap-1">
                                <i class="fa-solid fa-boxes-stacked text-[9px]"></i>
                                <span>Raf Stoğu</span>
                            </div>
                            <div class="flex items-center justify-center space-x-1.5 mt-0.5">
                                <span class="text-base font-black text-slate-900 font-mono" id="triaStockQty">--</span>
                                <span id="triaStockStatusBadge" class="px-1.5 py-0.2 rounded text-[9px] font-black bg-emerald-100 text-emerald-800">--</span>
                            </div>
                        </div>
                        <div class="bg-gradient-to-br from-sky-50 via-blue-50/60 to-white rounded-xl p-2.5 border border-sky-200/90 shadow-2xs">
                            <div class="text-[10px] font-extrabold text-sky-700 uppercase flex items-center justify-center gap-1">
                                <i class="fa-solid fa-chart-line text-[9px]"></i>
                                <span>Aylık Ort.</span>
                            </div>
                            <div class="text-sm font-black text-sky-950 mt-0.5 font-mono" id="triaAvgMonthly">--</div>
                            <div class="text-[9px] font-bold text-sky-600" id="triaAvgDaily">-- / Gün</div>
                        </div>
                        <div class="bg-gradient-to-br from-violet-50 via-purple-50/60 to-white rounded-xl p-2.5 border border-violet-200/90 shadow-2xs">
                            <div class="text-[10px] font-extrabold text-violet-700 uppercase flex items-center justify-center gap-1">
                                <i class="fa-solid fa-hourglass-half text-[9px]"></i>
                                <span>Stok Süresi</span>
                            </div>
                            <div class="text-sm font-black text-violet-950 mt-0.5 font-mono" id="triaDaysLeft">--</div>
                            <div class="text-[9px] font-bold text-violet-600">Yeterlilik</div>
                        </div>
                        <div class="bg-gradient-to-br from-indigo-50 via-amber-50/40 to-white rounded-xl p-2.5 border border-indigo-200/90 hover:border-indigo-400 cursor-pointer shadow-2xs transition" onclick="setSuggestedQty()" title="Tıklayarak önerilen adedi simülatöre uygula">
                            <div class="text-[10px] font-extrabold text-indigo-700 uppercase flex items-center justify-center gap-1">
                                <i class="fa-solid fa-wand-magic-sparkles text-[9px] text-amber-500"></i>
                                <span>30G İhtiyaç</span>
                            </div>
                            <div class="text-sm font-black text-indigo-950 mt-0.5 font-mono" id="triaOrderSuggested">--</div>
                            <div class="text-[9px] text-indigo-600 font-bold">Önerilen Sipariş</div>
                        </div>
                    </div>

                    <!-- Dinamik Görünüm Alanı (6 Ay Çıkış / Son Alışlar / Muadiller) -->
                    <div class="flex-1 flex flex-col justify-center">
                        <!-- Legend (Kompakt & Renkli) -->
                        <div id="cikisLegend" class="hidden"></div>
                        <div id="girisLegend" class="hidden"></div>
                        <div id="muadilLegend" class="hidden mb-1.5 px-2.5 py-1 rounded-lg bg-amber-50/80 border border-amber-200/80 text-[11px] text-amber-900 flex items-center justify-between">
                            <span><i class="fa-solid fa-layer-group text-amber-600 mr-1"></i>SGK Eşdeğer Grubu: <strong id="darkEsdegerKodu" class="font-mono font-black text-amber-950">--</strong></span>
                            <button type="button" onclick="openEsdegerModal()" class="px-2 py-0.5 rounded bg-white hover:bg-amber-500 hover:text-white text-amber-900 border border-amber-300 text-[10px] font-extrabold transition cursor-pointer flex items-center gap-1">
                                <i class="fa-solid fa-expand text-[9px]"></i>
                                <span>Geniş Ekran</span>
                            </button>
                        </div>

                        <!-- 1. Çıkışlar Görünümü -->
                        <div id="boxCikislarView">
                            <div id="triaMonthlyGrid" class="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                                <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center col-span-full text-xs text-slate-400">
                                    <i class="fa-solid fa-spinner animate-spin mr-1.5"></i>Aylık hareketler alınıyor...
                                </div>
                            </div>
                        </div>

                        <!-- 2. Girişler Görünümü -->
                        <div id="boxGirislerView" class="hidden">
                            <div id="otomasyonGirislerGrid" class="grid grid-cols-1 sm:grid-cols-3 gap-2 max-h-44 overflow-y-auto pr-0.5">
                                <div class="bg-emerald-50/50 border border-emerald-200 rounded-xl p-3 text-center col-span-full text-xs text-emerald-700">
                                    Depo alış faturaları taranıyor...
                                </div>
                            </div>
                        </div>

                        <!-- 3. Muadiller Görünümü (Kompakt & Renkli Satır Yapısı) -->
                        <div id="boxMuadillerView" class="hidden space-y-1.5">
                            <div id="boxMuadilHighlightBanner" class="hidden"></div>
                            <div id="otomasyonMuadillerGrid" class="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                                <div class="bg-amber-50/50 border border-amber-200 rounded-xl p-3 text-center text-xs text-amber-800">
                                    Eşdeğer ilaçlar taranıyor...
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- İLK BAKIŞ HİZASINDA DEPO KARŞILAŞTIRMA TABLOSU + DEPO SEÇİMLİ KOMPAKT SİMÜLATÖR -->
            <div class="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
                <!-- Tablo Üst Barı + Depo Seçimli Simülatör -->
                <div class="px-5 py-3.5 border-b border-slate-200 bg-slate-50/60 flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <h3 class="font-extrabold text-slate-900 text-sm">Depo Ticari Şartları ve Net Maliyet Karşılaştırması</h3>
                        <p class="text-[11px] text-slate-500">En avantajlı depo dışında diğer depoların yanındaki <strong class="text-indigo-700">"Seç & Hesapla"</strong> butonuna tıklayarak istediğiniz depoyu seçebilirsiniz</p>
                    </div>

                    <!-- Sağ: Depo Seçimli Kompakt Maliyet/MF Simülatör Barı -->
                    <div class="flex flex-wrap items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                        <div class="flex items-center gap-1.5">
                            <span class="text-[11px] font-bold text-slate-600"><i class="fa-solid fa-building-Wheat fa-truck-medical text-indigo-600 mr-1"></i>Depo:</span>
                            <select id="simDepoSelect" onchange="selectDepoForSimulation(parseInt(this.value))" class="bg-indigo-50/80 hover:bg-indigo-50 border border-indigo-200 text-indigo-950 font-extrabold text-xs rounded-lg px-2 py-1 focus:outline-none focus:border-indigo-500 cursor-pointer" title="Simüle edilecek ve sepete eklenecek depoyu seçin">
                                <option value="0">En Avantajlı Depo</option>
                            </select>
                        </div>
                        <div class="h-4 w-px bg-slate-200 mx-0.5 hidden sm:block"></div>
                        <span class="text-[11px] font-bold text-slate-600">Adet:</span>
                        <input 
                            type="number" 
                            id="simQtyInput" 
                            value="10" 
                            min="1" 
                            max="5000"
                            oninput="onSimulatorChange()"
                            class="w-16 bg-slate-50 border border-slate-300 text-slate-900 font-extrabold px-2 py-1 rounded-lg text-center text-xs focus:outline-none focus:border-indigo-500"
                            title="Simüle edilecek sipariş kutu adedi"
                        >
                        <div class="flex items-center gap-1">
                            <button type="button" onclick="setSimulatorQty(10)" class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer">10</button>
                            <button type="button" onclick="setSimulatorQty(25)" class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer">25</button>
                            <button type="button" id="btnQuickSuggested" onclick="setSuggestedQty()" class="px-2 py-0.5 text-[10px] font-bold rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition cursor-pointer" title="30 günlük ihtiyaca göre önerilen miktarı seç">Önerilen</button>
                        </div>
                        <div class="h-4 w-px bg-slate-200 mx-0.5 hidden sm:block"></div>
                        <div class="text-right text-xs hidden sm:block">
                            <span class="text-[10px] text-slate-400 font-medium block leading-none truncate max-w-[140px]" id="simDepoNote">En Avantajlı</span>
                            <strong class="text-emerald-700 font-mono text-xs" id="simTotalInvoice">0.00 ₺</strong>
                            <span class="hidden" id="simInvoiceKdvli"></span>
                        </div>
                        <button type="button" onclick="toggleMfDetails()" class="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold transition inline-flex items-center space-x-1 cursor-pointer" title="MF Baremleri ve Birim Maliyet Hesaplama Detayını Göster/Gizle">
                            <i class="fa-solid fa-circle-chevron-down text-[10px]" id="mfToggleIcon"></i>
                            <span>Detay</span>
                        </button>
                        <button id="simAddToCartBtn" onclick="addSimulatedToCart(this)" class="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[11px] font-bold transition flex items-center space-x-1 cursor-pointer shrink-0">
                            <i class="fa-solid fa-cart-plus text-[10px]"></i>
                            <span id="simAddToCartText">Sepete Ekle</span>
                        </button>
                    </div>
                </div>

                <!-- İhtiyaç Halinde Açılan Simülatör Detay Çekmecesi -->
                <div id="simResultsBox" class="hidden px-5 py-3 bg-indigo-50/40 border-b border-indigo-100 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-center">
                    <div class="bg-white rounded-xl p-2 border border-slate-200">
                        <div class="text-[10px] text-slate-400 font-semibold">Faturalanan Kutu</div>
                        <div class="text-sm font-extrabold text-slate-900 mt-0.5 font-mono" id="simPaidBoxes">--</div>
                    </div>
                    <div class="bg-white rounded-xl p-2 border border-slate-200">
                        <div class="text-[10px] text-amber-600 font-bold">Bedelsiz MF</div>
                        <div class="text-sm font-extrabold text-amber-600 mt-0.5 font-mono" id="simFreeBoxes">--</div>
                    </div>
                    <div class="bg-white rounded-xl p-2 border border-slate-200">
                        <div class="text-[10px] text-slate-400 font-semibold">Teslim Alınan</div>
                        <div class="text-sm font-extrabold text-slate-900 mt-0.5 font-mono" id="simTotalBoxes">--</div>
                    </div>
                    <div class="bg-white rounded-xl p-2 border border-slate-200">
                        <div class="text-[10px] text-slate-400 font-semibold">Birim Net (KDV Hariç)</div>
                        <div class="text-sm font-extrabold text-emerald-700 mt-0.5 font-mono" id="simUnitNet">0.00 ₺</div>
                    </div>
                    <div class="bg-white rounded-xl p-2 border border-slate-200">
                        <div class="text-[10px] text-slate-400 font-semibold">Birim Net (KDV Dahil)</div>
                        <div class="text-sm font-extrabold text-indigo-700 mt-0.5 font-mono" id="simUnitKdvli">0.00 ₺</div>
                    </div>
                    <div class="bg-white rounded-xl p-2 border border-slate-200">
                        <div class="text-[10px] text-slate-400 font-semibold">Uygulanan Şart</div>
                        <div class="text-xs font-bold text-slate-800 mt-1 truncate" id="simMfText">--</div>
                    </div>
                </div>

                <!-- Depo Karşılaştırma Tablosu -->
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-sm">
                        <thead>
                            <tr class="bg-slate-50 border-b border-slate-200 text-slate-500 text-[11px] uppercase tracking-wider font-bold">
                                <th class="py-3 px-5">Depo / Platform</th>
                                <th class="py-3 px-5">Stok Durumu</th>
                                <th class="py-3 px-5">DSF (KDV Hariç)</th>
                                <th class="py-3 px-5">MF Kademeleri</th>
                                <th class="py-3 px-5">Vade & İskonto</th>
                                <th class="py-3 px-5">Net Kutu (KDV Hariç)</th>
                                <th class="py-3 px-5 text-right">Net Kutu (KDV Dahil)</th>
                                <th class="py-3 px-5 text-right">Sepet İşlemi</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody" class="divide-y divide-slate-100">
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- End of results -->

        <!-- ============================================================== -->
        <!-- SAĞ TARAFTA KOMPAKT GÜNLÜK ÇIKIŞ & AZALAN STOK ÇEKMECESİ      -->
        <!-- ============================================================== -->
        <button 
            id="criticalMiniBadgeBtn" 
            onclick="toggleSideWidget(true)" 
            class="fixed right-0 top-32 z-40 bg-slate-900 hover:bg-slate-800 text-white py-2.5 px-3 rounded-l-xl shadow-lg flex items-center space-x-2 border-l-2 border-amber-400 cursor-pointer transition" 
            title="Günün Çıkışları ve Azalan Stok Listesini Aç"
        >
            <i class="fa-solid fa-fire text-amber-400 text-xs"></i>
            <span class="text-xs font-bold tracking-tight">Günün Çıkışları</span>
            <span id="miniSideCriticalCount" class="bg-amber-400 text-slate-950 font-black text-[10px] px-1.5 py-0.5 rounded-full font-mono">0</span>
        </button>

        <!-- 2. Açılabilir Kompakt Sağ Panel (2 İnce Kontrol Satırı + Tam İsimli Kompakt İlaç Satırları) -->
        <div 
            id="criticalSideWidget" 
            class="hidden fixed right-4 top-16 z-40 w-[95vw] sm:w-[500px] bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col transition-all duration-200"
            style="max-height: calc(100vh - 80px);"
        >
            <!-- İnce Başlık Çubuğu -->
            <div class="px-3.5 py-2 bg-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-2 min-w-0">
                    <i class="fa-solid fa-fire text-amber-400 text-xs"></i>
                    <h4 class="font-extrabold text-xs text-white truncate">Günün Çıkışları</h4>
                    <span id="sideCriticalCountBadge" class="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-400 text-slate-950 font-mono">0</span>
                    <span id="orderedTodayCountBadge" class="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[9px] font-bold">0 İşlem</span>
                </div>
                <div class="flex items-center space-x-1 shrink-0">
                    <button type="button" id="btnToggleHideOrdered" onclick="toggleHideOrderedItems()" class="px-2 py-0.5 rounded text-[9px] font-bold bg-white/10 hover:bg-white/20 text-slate-200 transition cursor-pointer flex items-center space-x-1" title="Sipariş verilenleri gizle/göster">
                        <i class="fa-solid fa-eye-slash text-[8px]" id="btnToggleHideOrderedIcon"></i>
                        <span id="btnToggleHideOrderedText">Gizle</span>
                    </button>
                    <button onclick="loadCriticalStockList(true)" class="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white flex items-center justify-center transition cursor-pointer" title="Listeyi Yenile">
                        <i class="fa-solid fa-arrows-rotate text-[10px]" id="criticalRefreshIcon"></i>
                    </button>
                    <button onclick="toggleSideWidget(false)" class="w-6 h-6 rounded-lg bg-white/10 hover:bg-rose-500/30 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer" title="Kapat">
                        <i class="fa-solid fa-xmark text-xs"></i>
                    </button>
                </div>
            </div>

            <!-- 1. SATIR: Arama + Tek Satırda Sayı Rozetli Filtre Hapları -->
            <div class="p-2 bg-slate-50 border-b border-slate-200 space-y-1.5">
                <!-- Gizli geri uyumluluk sayaçları -->
                <div class="hidden">
                    <span id="critZeroSubText"></span>
                    <span id="critNegativeSubText"></span>
                </div>
                <div class="flex items-center gap-1.5">
                    <div class="relative flex-1">
                        <i class="fa-solid fa-magnifying-glass absolute left-2.5 top-1.5 text-[10px] text-slate-400"></i>
                        <input 
                            type="text" 
                            id="criticalFilterInput" 
                            placeholder="İlaç veya barkod ara..." 
                            oninput="filterCriticalList()"
                            class="w-full pl-7 pr-2 py-1 text-[11px] bg-white border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                        />
                    </div>
                    <button type="button" id="btnToggleMfBadges" onclick="toggleMfBadgesView()" class="px-2 py-1 rounded-lg font-bold text-[10px] transition cursor-pointer flex items-center space-x-1 bg-amber-500 text-white shrink-0" title="MF rozetlerini göster / gizle">
                        <i class="fa-solid fa-gift text-[9px]"></i>
                        <span id="btnToggleMfBadgesText">MF</span>
                    </button>
                </div>
                <div class="flex items-center justify-between gap-1 overflow-x-auto no-scrollbar">
                    <div class="flex items-center gap-1 text-[10px] whitespace-nowrap">
                        <button type="button" onclick="setCriticalFilterMode('days_21')" id="btnCritFilter21" class="px-2 py-0.5 rounded-md font-bold bg-slate-900 text-white transition text-[10px] cursor-pointer">≤21G</button>
                        <button type="button" onclick="setCriticalFilterMode('zero')" id="btnCritFilterZero" class="px-2 py-0.5 rounded-md font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 transition text-[10px] cursor-pointer inline-flex items-center gap-1">
                            <span>Tükenen (0)</span>
                            <span id="critZeroCountBadge" class="px-1 py-0.1 rounded bg-white/80 text-rose-700 font-black font-mono text-[9.5px]">0</span>
                        </button>
                        <button type="button" onclick="setCriticalFilterMode('negative')" id="btnCritFilterNegative" class="px-2 py-0.5 rounded-md font-bold bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 transition text-[10px] cursor-pointer inline-flex items-center gap-1">
                            <span>Eksi (&lt;0)</span>
                            <span id="critNegativeCountBadge" class="px-1 py-0.1 rounded bg-rose-600 text-white font-black font-mono text-[9.5px]">0</span>
                        </button>
                        <button type="button" onclick="setCriticalFilterMode('mf_only')" id="btnCritFilterMf" class="px-2 py-0.5 rounded-md font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 transition text-[10px] cursor-pointer flex items-center space-x-1">
                            <i class="fa-solid fa-gift text-amber-600 text-[8px]"></i>
                            <span>MF'li</span>
                        </button>
                        <button type="button" onclick="setCriticalFilterMode('all')" id="btnCritFilterAll" class="px-2 py-0.5 rounded-md font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 transition text-[10px] cursor-pointer">Tümü</button>
                    </div>
                </div>
            </div>

            <!-- 2. SATIR: Seçim (Varsayılan Seçimsiz) ve Tek Satırda Depoya Aktar Barı -->
            <div class="px-2.5 py-1.5 bg-white border-b border-slate-200 flex items-center justify-between gap-1.5 flex-wrap">
                <div class="flex items-center space-x-1.5">
                    <label class="inline-flex items-center space-x-1 cursor-pointer select-none group" onclick="handleMasterSelectClick(event)">
                        <input type="checkbox" id="bulkSelectAllCheck" class="sr-only">
                        <span id="bulkSelectAllVisualBox" class="w-4 h-4 rounded border-2 border-slate-300 bg-white text-transparent flex items-center justify-center transition-all">
                            <i id="bulkSelectAllVisualIcon" class="fa-solid fa-check text-[10px] leading-none opacity-0"></i>
                        </span>
                        <span class="font-bold text-[11px] text-slate-700">Tümünü Seç</span>
                    </label>
                    <span id="bulkSelectedBadge" class="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 font-mono">0 Seçili</span>
                    <button type="button" onclick="markSelectedCriticalItemsSkipped()" class="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-[10px] font-bold transition cursor-pointer" title="Seçili ilaçları bugün sipariş verilmeyecek olarak işaretle">🚫 Yoksay</button>
                    <button type="button" onclick="markSelectedCriticalItemsYok()" class="px-1.5 py-0.5 rounded bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 text-[10px] font-bold transition cursor-pointer" title="Seçili ilaçları doğrudan Yok Listesine ekle">🚨 Yok'a At</button>
                    <button type="button" onclick="clearBulkSelection()" class="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-600 text-[10px] font-semibold transition cursor-pointer" title="Seçimi temizle">Temizle</button>
                </div>

                <!-- Tek Satırda Depoya Aktar Butonları -->
                <div class="flex items-center gap-1 flex-wrap">
                    <button type="button" id="btnDistributeCriticalByCardDepo" onclick="distributeSelectedCriticalToCardDepos()" class="px-2 py-1 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-extrabold text-[10px] rounded-lg transition cursor-pointer flex items-center space-x-1 shadow-2xs" title="Seçili ilaçları kartların üzerinde seçili olan kendi depolarına (Alliance / Selçuk / İSKOOP / Nevzat) ayrı ayrı dağıtır ve sipariş sepetlerini oluşturur">
                        <i class="fa-solid fa-arrows-split-up-and-left text-[9px]"></i>
                        <span id="btnDistributeCriticalText">Seçili Depolara Dağıt</span>
                    </button>
                    <button type="button" id="btnSendToAlliance" data-depo-btn="ALLIANCE" onclick="triggerBulkOrder('ALLIANCE')" class="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[10px] rounded-lg transition cursor-pointer" title="Seçilileri Alliance sepetine aktar"><span id="btnSendToAllianceText">Alliance</span></button>
                    <button type="button" id="btnSendToSelcuk" data-depo-btn="SELCUK" onclick="triggerBulkOrder('SELCUK')" class="px-2 py-1 bg-slate-800 hover:bg-slate-900 text-white font-bold text-[10px] rounded-lg transition cursor-pointer" title="Seçilileri Selçuk sepetine aktar"><span id="btnSendToSelcukText">Selçuk</span></button>
                    <button type="button" id="btnSendToIskoop" data-depo-btn="ISKOOP" onclick="triggerBulkOrder('ISKOOP')" class="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] rounded-lg transition cursor-pointer" title="Seçilileri İSKOOP sepetine aktar"><span id="btnSendToIskoopText">İSKOOP</span></button>
                    <button type="button" id="btnSendToNevzat" data-depo-btn="NEVZAT" onclick="triggerBulkOrder('NEVZAT')" class="px-2 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10px] rounded-lg transition cursor-pointer" title="Seçilileri Nevzat sepetine aktar"><span id="btnSendToNevzatText">Nevzat</span></button>
                </div>

                <!-- Gizli geri uyumluluk sepet barı -->
                <div id="drawerMiniBulkResumeBar" class="hidden">
                    <span id="drawerMiniBulkResumeLabel"></span>
                    <button id="drawerMissingBulkBtn"></button>
                    <span id="drawerMiniBulkResumeBadge"></span>
                    <div id="drawerDepotCartPills"></div>
                </div>
            </div>

            <!-- Çekmece İçi Sabit Yok Listesi Şeridi -->
            <div id="drawerPinnedYokSection" class="hidden px-2.5 py-1.5 bg-rose-50/90 border-b border-rose-200">
                <div class="flex items-center justify-between gap-1.5">
                    <div class="flex items-center space-x-1.5 min-w-0 cursor-pointer" onclick="togglePersistentYokBar(true)">
                        <i class="fa-solid fa-thumbtack text-rose-600 text-[10px]"></i>
                        <span class="text-[10px] font-black text-rose-900">📌 Sabit Yok Listesi:</span>
                        <span id="drawerPinnedYokCount" class="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[9px] font-black">0</span>
                    </div>
                    <div class="flex items-center gap-1 shrink-0">
                        <button type="button" onclick="scanYokListItemsInDepots()" class="px-2 py-0.5 rounded bg-indigo-600 hover:bg-indigo-700 text-white text-[9px] font-extrabold cursor-pointer">🔍 Yokları Sorgula</button>
                        <button type="button" onclick="openEndOfDaySummaryModal('yok')" class="px-2 py-0.5 rounded bg-white hover:bg-rose-100 text-rose-800 border border-rose-300 text-[9px] font-bold cursor-pointer">Aç</button>
                    </div>
                </div>
                <div id="drawerPinnedYokPills" class="flex flex-wrap items-center gap-1 mt-1 max-h-16 overflow-y-auto"></div>
            </div>

            <!-- Kompakt İlaç Satırları Listesi (Aynı anda 7-8 ilaç görünür) -->
            <div id="criticalStockListContainer" class="p-1.5 overflow-y-auto space-y-1 flex-1 bg-slate-50/50">
                <div class="p-4 text-center text-slate-400 text-xs">
                    <i class="fa-solid fa-spinner fa-spin text-indigo-500 mr-1.5"></i>Yükleniyor...
                </div>
            </div>
        </div>
        </div> <!-- End of viewDepo -->

        <!-- ======================================================================= -->
        <!-- VIEW 1.5: TOPLU SİPARİŞ (2 Şeritli, Sekmeli Tek Araç Çubuklu Tasarım)   -->
        <!-- ======================================================================= -->
        <div id="viewSmartOrder" class="hidden space-y-3">
            <!-- 1. ŞERİT: Başlık + Kapsam & Stok + Durum Hapları + Arama -->
            <div class="bg-white rounded-2xl border border-slate-200 shadow-2xs px-4 py-3 flex flex-wrap items-center justify-between gap-2.5">
                <!-- Sol: Başlık + Kapsam + Stok Günü -->
                <div class="flex flex-wrap items-center gap-1.5">
                    <div class="flex items-center space-x-2 mr-1">
                        <span class="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                            <i class="fa-solid fa-layer-group"></i>
                        </span>
                        <h2 class="text-sm font-extrabold text-slate-900">Toplu Sipariş</h2>
                        <span id="smartOrderSourceBadge" class="hidden"></span>
                    </div>

                    <div class="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200/80 text-[11px]">
                        <button type="button" id="btnSmartScopeToday" onclick="changeSmartOrderScope('today')" class="px-2.5 py-1 rounded-md text-[11px] font-bold bg-indigo-600 text-white transition cursor-pointer">Bugün Çıkan</button>
                        <button type="button" id="btnSmartScopeWeek" onclick="changeSmartOrderScope('week')" class="px-2.5 py-1 rounded-md text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer">Son 7 Gün</button>
                        <button type="button" id="btnSmartScopeTop6m" onclick="changeSmartOrderScope('top6m')" class="px-2.5 py-1 rounded-md text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer">6 Ay En Çok</button>
                    </div>

                    <div class="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200/80 text-[11px]">
                        <button type="button" id="btnSmartStock_21" onclick="setSmartStockMaxDays(21)" class="px-2 py-1 rounded-md text-[11px] font-bold bg-slate-900 text-white transition cursor-pointer" title="Stoğu 21 gün ve altı kalanlar">≤21G</button>
                        <button type="button" id="btnSmartStock_14" onclick="setSmartStockMaxDays(14)" class="px-2 py-1 rounded-md text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer">≤14G</button>
                        <button type="button" id="btnSmartStock_0" onclick="setSmartStockMaxDays(0)" class="px-2 py-1 rounded-md text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer">Stok 0</button>
                        <button type="button" id="btnSmartStock_999" onclick="setSmartStockMaxDays(999)" class="px-2 py-1 rounded-md text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer">Tümü</button>
                    </div>
                </div>

                <!-- Orta: Durum / Trend Filtre Hapları -->
                <div class="flex flex-wrap items-center gap-1">
                    <button type="button" onclick="setSmartTrendFilter('ALL')" id="smartKpiAll" class="px-2.5 py-1 rounded-lg bg-slate-900 text-white text-[11px] font-bold cursor-pointer transition flex items-center gap-1">
                        <span>Tümü</span>
                        <span class="px-1.5 py-0.2 rounded bg-white/20 font-mono text-[10px]" id="smartStatTotal">0</span>
                    </button>
                    <button type="button" onclick="setSmartTrendFilter('STABIL')" id="smartKpiStabil" class="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1">
                        <span>Stabil</span>
                        <span class="px-1 py-0.2 rounded bg-white font-mono text-[10px]" id="smartStatStabil">0</span>
                    </button>
                    <button type="button" onclick="setSmartTrendFilter('AZALAN')" id="smartKpiAzalan" class="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1">
                        <span>Azalan</span>
                        <span class="px-1 py-0.2 rounded bg-white font-mono text-[10px]" id="smartStatAzalan">0</span>
                    </button>
                    <button type="button" onclick="setSmartTrendFilter('ARTAN')" id="smartKpiArtan" class="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1">
                        <span>Artan</span>
                        <span class="px-1 py-0.2 rounded bg-white font-mono text-[10px]" id="smartStatArtan">0</span>
                    </button>
                    <button type="button" onclick="setSmartTrendFilter('MF_ONLY')" id="smartKpiMf" class="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-[11px] font-bold cursor-pointer transition flex items-center gap-1">
                        <span>🎁 MF'li</span>
                        <span class="px-1 py-0.2 rounded bg-white font-mono text-[10px]" id="smartStatMf">0</span>
                    </button>
                    <button type="button" onclick="setSmartTrendFilter('ORDERED')" id="smartKpiOrdered" class="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold cursor-pointer transition flex items-center gap-1">
                        <span>Siparişli</span>
                        <span class="px-1 py-0.2 rounded bg-white font-mono text-[10px]" id="smartStatOrdered">0</span>
                    </button>
                </div>

                <!-- Sağ: Arama + Gizle + MF Tara + Yenile -->
                <div class="flex items-center gap-1.5">
                    <div class="relative w-44 sm:w-52">
                        <i class="fa-solid fa-magnifying-glass absolute left-2.5 top-2 text-slate-400 text-[11px]"></i>
                        <input 
                            type="text" 
                            id="smartOrderSearchInput" 
                            placeholder="İlaç / barkod ara..." 
                            oninput="renderSmartOrderTable()"
                            onkeydown="if(event.key === 'Enter') searchBotanikInSmartOrder()"
                            class="w-full pl-7 pr-2 py-1 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-indigo-500"
                        />
                    </div>
                    <label class="inline-flex items-center space-x-1 cursor-pointer select-none text-[11px] font-semibold text-slate-600 bg-slate-50 px-2 py-1 rounded-lg border border-slate-200 hover:bg-slate-100 transition shrink-0" title="Sipariş verilenleri gizle">
                        <input type="checkbox" id="smartHideOrderedCheck" onchange="renderSmartOrderTable()" class="rounded text-indigo-600 w-3.5 h-3.5 cursor-pointer">
                        <span>Gizle</span>
                    </label>
                    <button type="button" onclick="resolveAllSmartOrderMfs(true)" id="btnSmartResolveMf" class="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-[11px] transition flex items-center gap-1 cursor-pointer shrink-0" title="Listedeki ilaçlar için canlı depo MF'lerini tara">
                        <i class="fa-solid fa-gift text-[10px]" id="smartResolveMfIcon"></i>
                        <span id="smartResolveMfText">MF Tara</span>
                    </button>
                    <button type="button" onclick="loadSmartOrderList(true)" class="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer shrink-0" title="Listeyi Yenile">
                        <i class="fa-solid fa-arrows-rotate text-xs" id="smartOrderRefreshIcon"></i>
                    </button>
                </div>
            </div>

            <!-- 2. ŞERİT (YAPIŞKAN TEK ARAÇ ÇUBUĞU): Sekmeli Mod Seçici (Akıllı Gün Yazma vs Sabit Adet) + Seçim & Depoya Dağıt -->
            <div class="bg-white/95 border border-slate-200 rounded-2xl px-3.5 py-2 shadow-xs flex flex-wrap items-center justify-between gap-2 sticky top-14 z-30 backdrop-blur-md">
                <!-- Sol: Sekmeli (Segmented) Mod Seçici ve Aktif Modun Kontrolleri -->
                <div class="flex flex-wrap items-center gap-2">
                    <!-- Segmented Switcher -->
                    <div class="inline-flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
                        <button type="button" id="btnSmartModeAuto" onclick="setSmartOrderQtyMode('auto')" class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-indigo-600 text-white shadow-2xs transition cursor-pointer">
                            🤖 Akıllı Öneri (Gün)
                        </button>
                        <button type="button" id="btnSmartModeManual" onclick="setSmartOrderQtyMode('manual')" class="px-2.5 py-1 rounded-lg text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer">
                            ✍️ Sabit Adet
                        </button>
                    </div>

                    <!-- MOD 1: Akıllı Öneri (Kullanıcının istediği gün sayısını yazabileceği kutu + hızlı kısayollar) -->
                    <div id="smartModeCardAuto" class="flex flex-wrap items-center gap-1.5">
                        <div class="inline-flex items-center bg-indigo-50/70 rounded-xl border border-indigo-200 px-2 py-0.5">
                            <span class="text-[11px] font-semibold text-indigo-900 mr-1">Hedef:</span>
                            <input 
                                type="number" 
                                id="smartCustomDaysInput" 
                                value="15" 
                                min="1" 
                                max="180" 
                                onkeydown="if(event.key==='Enter') setSmartTargetDays(this.value)" 
                                class="w-12 bg-white border border-indigo-300 rounded-md py-0.5 text-center font-extrabold text-xs text-indigo-950 focus:outline-none focus:ring-2 focus:ring-indigo-500" 
                                title="İstediğiniz gün sayısını yazıp Enter'a basın veya Uygula'ya tıklayın"
                            />
                            <span class="text-[11px] font-bold text-indigo-800 mx-1">Gün</span>
                            <button type="button" onclick="setSmartTargetDays(document.getElementById('smartCustomDaysInput').value)" class="px-2 py-0.5 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold cursor-pointer transition">
                                Hesapla
                            </button>
                        </div>
                        <span id="smartTargetDaysLabel" class="hidden">15G</span>
                        <div class="flex items-center gap-1">
                            <button type="button" onclick="setSmartTargetDays(7)" id="btnSmartDays_7" class="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer">7G</button>
                            <button type="button" onclick="setSmartTargetDays(15)" id="btnSmartDays_15" class="px-2 py-0.5 rounded-md text-[11px] font-bold bg-indigo-600 text-white cursor-pointer">15G</button>
                            <button type="button" onclick="setSmartTargetDays(30)" id="btnSmartDays_30" class="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer">30G</button>
                            <button type="button" onclick="setSmartTargetDays(60)" id="btnSmartDays_60" class="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer">60G</button>
                            <button type="button" id="btnSmartDays_1" onclick="setSmartTargetDays(1)" class="hidden"></button>
                            <button type="button" id="btnSmartDays_10" onclick="setSmartTargetDays(10)" class="hidden"></button>
                            <button type="button" id="btnSmartDays_21" onclick="setSmartTargetDays(21)" class="hidden"></button>
                            <button type="button" id="btnSmartDays_45" onclick="setSmartTargetDays(45)" class="hidden"></button>
                        </div>
                        <label class="inline-flex items-center space-x-1 cursor-pointer select-none text-[11px] font-semibold text-slate-700 ml-1" title="İhtiyaç MF baremine yakınsa otomatik MF kademesine tamamlar">
                            <input type="checkbox" id="smartAutoRoundMfCheck" checked onchange="recalculateSmartOrderClientSide(false); renderSmartOrderTable();" class="rounded text-indigo-600 w-3.5 h-3.5 cursor-pointer">
                            <span>🎁 MF Tamamla</span>
                        </label>
                    </div>

                    <!-- MOD 2: Sabit Adet (Sadece Sabit Adet sekmesi seçildiğinde görünür) -->
                    <div id="smartModeCardManual" class="hidden flex-wrap items-center gap-1.5">
                        <div class="inline-flex items-center bg-slate-100 rounded-xl border border-slate-200 px-2 py-0.5">
                            <span class="text-[11px] font-semibold text-slate-700 mr-1">Adet:</span>
                            <input type="number" id="smartBulkFixedQtyInput" value="1" min="1" max="999" onkeydown="if(event.key==='Enter') applyBulkCustomQtyToSmartOrder(this.value)" class="w-12 bg-white border border-slate-300 rounded-md py-0.5 text-center font-extrabold text-xs text-slate-900 focus:outline-none" />
                            <button type="button" onclick="applyBulkCustomQtyToSmartOrder(document.getElementById('smartBulkFixedQtyInput').value)" class="ml-1.5 px-2 py-0.5 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold cursor-pointer">Uygula</button>
                        </div>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(1)" class="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-indigo-600 hover:text-white text-slate-700 font-bold text-[11px] cursor-pointer">1</button>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(2)" class="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-indigo-600 hover:text-white text-slate-700 font-bold text-[11px] cursor-pointer">2</button>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(3)" class="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-indigo-600 hover:text-white text-slate-700 font-bold text-[11px] cursor-pointer">3</button>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(5)" class="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-indigo-600 hover:text-white text-slate-700 font-bold text-[11px] cursor-pointer">5</button>
                        <button type="button" onclick="applyBulkCustomQtyToSmartOrder(10)" class="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-indigo-600 hover:text-white text-slate-700 font-bold text-[11px] cursor-pointer">10</button>
                        <button type="button" onclick="startCleanManualSmartOrder()" class="px-2 py-0.5 rounded-md bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-bold transition cursor-pointer" title="Tüm otomatik seçimleri kaldırır">Sıfırla</button>
                    </div>
                </div>

                <!-- Sağ: Seçim Özeti & Depolara Aktarım -->
                <div class="flex flex-wrap items-center gap-1.5">
                    <div id="smartMasterLabel" onclick="handleSmartMasterCheckClick(event)" class="inline-flex items-center space-x-1.5 cursor-pointer select-none bg-slate-50 hover:bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200 transition shrink-0">
                        <input type="checkbox" id="smartMasterCheck" checked class="sr-only">
                        <span id="smartMasterVisualBox" class="w-3.5 h-3.5 rounded flex items-center justify-center border border-indigo-600 bg-indigo-600 text-white transition-all">
                            <i id="smartMasterVisualIcon" class="fa-solid fa-check text-[9px] font-black"></i>
                        </span>
                        <span class="font-bold text-[11px] text-slate-800" id="smartMasterText">Tümünü Seç</span>
                    </div>
                    <div class="flex items-center space-x-1 bg-slate-50 px-2 py-1 rounded-lg border border-slate-200 text-[11px] shrink-0">
                        <span class="font-bold text-slate-800" id="smartSelectedCountBadge">0 Seçili</span>
                        <span class="text-slate-300">•</span>
                        <span class="font-bold text-indigo-700" id="smartSelectedBoxesBadge">0 Kutu</span>
                    </div>
                    <button type="button" onclick="markSelectedSmartItemsOrdered()" class="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold cursor-pointer shrink-0" title="Seçilileri sipariş verildi olarak işaretle">✓ Verildi</button>
                    <button type="button" onclick="markSelectedSmartItemsSkipped()" class="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-[11px] font-semibold cursor-pointer shrink-0" title="Seçilileri bugün sipariş verilmeyecek olarak işaretle">🚫 Yoksay</button>
                    <button type="button" onclick="markSelectedSmartItemsYok()" class="px-2 py-1 rounded-lg bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 text-[11px] font-bold transition cursor-pointer shrink-0" title="Seçili ilaçları doğrudan Yok Listesine ekle">🚨 Yok'a At</button>
                    <span id="smartMfScanProgressBadge" class="hidden text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 shrink-0">
                        <i class="fa-solid fa-spinner fa-spin mr-1"></i>MF...
                    </span>

                    <div class="h-4 w-px bg-slate-200 mx-0.5 hidden sm:block"></div>

                    <button type="button" data-depo-btn="ALLIANCE" onclick="triggerSmartBulkOrder('ALLIANCE')" class="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] rounded-lg transition cursor-pointer shrink-0">Alliance</button>
                    <button type="button" data-depo-btn="SELCUK" onclick="triggerSmartBulkOrder('SELCUK')" class="px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-white font-bold text-[11px] rounded-lg transition cursor-pointer shrink-0">Selçuk</button>
                    <button type="button" data-depo-btn="ISKOOP" onclick="triggerSmartBulkOrder('ISKOOP')" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded-lg transition cursor-pointer shrink-0">İSKOOP</button>
                    <button type="button" data-depo-btn="NEVZAT" onclick="triggerSmartBulkOrder('NEVZAT')" class="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-[11px] rounded-lg transition cursor-pointer shrink-0">Nevzat</button>
                    <button type="button" onclick="triggerSmartBulkOrderByRowDepo()" class="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-white font-bold text-[11px] rounded-lg transition cursor-pointer shrink-0" title="Her ürünü kendi satırında seçili olan depoya gönderir">
                        ✨ Dağıt
                    </button>
                </div>
            </div>

            <!-- SAĞA TAŞMAYAN, TAM HİZALI 7 SÜTUNLU SADE TABLO -->
            <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <table class="w-full table-fixed text-left border-collapse text-xs">
                    <thead>
                        <tr class="bg-slate-100 border-b border-slate-200 text-slate-600 text-[10px] uppercase font-extrabold" id="smartOrderTableHeadRow">
                            <th class="py-2.5 px-2 w-[4%] text-center">Seç</th>
                            <th class="py-2.5 px-2.5 w-[25%]">İlaç Adı / Barkod</th>
                            <th class="py-2.5 px-2 w-[11%] text-center">Stok & Bugün</th>
                            <th class="py-2.5 px-2 w-[23%] text-center">Son 6 Aylık Çıkış (Ay-Ay)</th>
                            <th class="py-2.5 px-2 w-[8%] text-center bg-slate-200/50 text-slate-900">6 Ay Top</th>
                            <th class="py-2.5 px-2 w-[11%]">Trend & MF</th>
                            <th class="py-2.5 px-3 w-[18%] text-right bg-indigo-50/50 text-indigo-950">Sipariş Adedi & Depo</th>
                        </tr>
                    </thead>
                    <tbody id="smartOrderTableBody" class="divide-y divide-slate-100">
                        <tr>
                            <td colspan="7" class="py-12 text-center text-slate-400 text-sm">
                                <i class="fa-solid fa-spinner fa-spin text-amber-500 mr-2 text-lg"></i>Eczane otomasyonu 6 aylık çıkış ve stok verileri analiz ediliyor...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ========================================== -->
        <!-- VIEW 2: E-TİCARET & PİYASA FİYAT KIYASLAMA -->
        <!-- ========================================== -->
        <div id="viewMarket" class="hidden space-y-8">
            <!-- Market Search Box -->
            <div class="max-w-3xl mx-auto mb-8 relative">
                <div class="bg-white p-3 rounded-2xl shadow-lg shadow-indigo-100/60 border border-indigo-200 flex items-center space-x-3 relative z-30">
                    <div class="pl-3 text-indigo-500">
                        <i class="fa-solid fa-basket-shopping text-xl"></i>
                    </div>
                    <input 
                        type="text" 
                        id="marketSearchInput" 
                        placeholder="E-Ticaret İçin Barkod (869...) veya Ürün Adı (Ocean, Solgar, Bioderma, CeraVe)..."
                        class="w-full py-2.5 text-base text-slate-800 placeholder-slate-400 focus:outline-none bg-transparent"
                        autocomplete="off"
                        onkeydown="if(event.key === 'Enter') handleMarketSearchSubmit()"
                    >
                    <button 
                        id="marketSearchBtn" 
                        onclick="handleMarketSearchSubmit()"
                        class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl text-sm transition-all shadow-md shadow-indigo-200 flex items-center space-x-2 shrink-0 cursor-pointer"
                    >
                        <i class="fa-solid fa-bolt"></i>
                        <span>Piyasayı Tara</span>
                    </button>
                </div>

                <!-- Auto-Suggest Dropdown for Market -->
                <div id="marketSuggestBox" class="hidden absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl border border-slate-200 shadow-2xl z-40 overflow-hidden divide-y divide-slate-100 max-h-96 overflow-y-auto">
                    <!-- Suggestions will be injected here -->
                </div>

                <!-- Market Quick Chips -->
                <div class="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-500">
                    <span class="font-medium">Popüler Ürünler:</span>
                    <button onclick="quickMarketSearch('8697595872413', 'Ocean Alfa Lipoik 200mg')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Ocean Alfa Lipoik 200mg</button>
                    <button onclick="quickMarketSearch('8697595872451', 'Ocean Alfa Lipoik 600mg')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Ocean Alfa Lipoik 600mg</button>
                    <button onclick="quickMarketSearch('8697595870020', 'Ocean Plus 1200mg 50 Kapsül')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Ocean Plus 1200mg</button>
                    <button onclick="quickMarketSearch('Bioderma Sebium', 'Bioderma Sebium')" class="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 rounded-lg border border-indigo-200 text-indigo-700 font-medium transition cursor-pointer">Bioderma Sebium</button>
                    <button onclick="quickMarketSearch('Solgar Alfa Lipoik', 'Solgar Alfa Lipoik')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">Solgar Alfa Lipoik</button>
                    <button onclick="quickMarketSearch('CeraVe Nemlendirici Krem', 'CeraVe')" class="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 rounded-lg border border-slate-200 text-slate-600 transition cursor-pointer">CeraVe</button>
                </div>
            </div>

            <!-- Loading Spinner State -->
            <div id="marketLoading" class="hidden bg-white p-12 rounded-3xl border border-slate-200 shadow-sm text-center max-w-2xl mx-auto">
                <div class="relative w-16 h-16 mx-auto mb-4">
                    <div class="w-16 h-16 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin"></div>
                    <div class="absolute inset-0 flex items-center justify-center text-indigo-600">
                        <i class="fa-solid fa-shop text-xl"></i>
                    </div>
                </div>
                <h3 class="text-base font-bold text-slate-900 mb-1" id="marketLoadingTitle">9 E-Ticaret Platformu ve Depolar Eşzamanlı Taranıyor...</h3>
                <p class="text-xs text-slate-500 max-w-md mx-auto">Trendyol, Hepsiburada, Sachane, Dermoeczanem, Dermokozmetika, Kırmızıbeyaz, Dermojet, Kozvit ve Daffne canlı fiyatları toplanıyor...</p>
                <div class="flex items-center justify-center gap-2 mt-4 text-[11px] text-slate-400">
                    <span class="w-2 h-2 rounded-full bg-indigo-500 animate-ping"></span>
                    <span>Anti-bot güvenlik bypass aktif</span>
                </div>
            </div>

            <!-- Initial Empty State -->
            <div id="marketEmptyState" class="bg-white p-10 rounded-3xl border border-slate-200 shadow-sm text-center max-w-3xl mx-auto">
                <div class="w-16 h-16 mx-auto mb-4 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-2xl">
                    <i class="fa-solid fa-scale-balanced"></i>
                </div>
                <h3 class="text-lg font-bold text-slate-900 mb-2">E-Ticaret & Perakende Piyasa Fiyat Analizi</h3>
                <p class="text-sm text-slate-500 max-w-xl mx-auto mb-6">
                    Barkod veya ürün adı aratarak 9 büyük perakende e-ticaret platformunun anlık fiyatlarını görün, ecza depolarındaki net alış maliyetiniz ve kâr marjınızla karşılaştırın.
                </p>
                <div class="grid grid-cols-2 sm:grid-cols-5 gap-3 max-w-2xl mx-auto text-xs font-semibold text-slate-700">
                    <div class="p-2.5 rounded-xl bg-orange-50 border border-orange-200 text-orange-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-orange-600"></i> Trendyol</div>
                    <div class="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-amber-600"></i> Hepsiburada</div>
                    <div class="p-2.5 rounded-xl bg-pink-50 border border-pink-200 text-pink-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-pink-600"></i> Sachane</div>
                    <div class="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-emerald-600"></i> Dermoeczanem</div>
                    <div class="p-2.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-indigo-600"></i> Dermokozmetika</div>
                    <div class="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-rose-600"></i> Kırmızıbeyaz</div>
                    <div class="p-2.5 rounded-xl bg-cyan-50 border border-cyan-200 text-cyan-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-cyan-600"></i> Dermojet</div>
                    <div class="p-2.5 rounded-xl bg-purple-50 border border-purple-200 text-purple-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-purple-600"></i> Kozvit</div>
                    <div class="p-2.5 rounded-xl bg-teal-50 border border-teal-200 text-teal-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-tag text-teal-600"></i> Daffne</div>
                    <div class="p-2.5 rounded-xl bg-slate-100 border border-slate-300 text-slate-800 flex items-center justify-center gap-1.5"><i class="fa-solid fa-truck-ramp-box text-slate-600"></i> 6 Ecza Deposu</div>
                </div>
            </div>

            <!-- Market Results Container -->
            <div id="marketResults" class="hidden space-y-6">
                <!-- Header Title & Info -->
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <div class="flex items-center gap-2 mb-1">
                            <span class="px-2.5 py-0.5 rounded-md text-xs font-bold bg-indigo-100 text-indigo-800" id="marketResBadge">PİYASA RAPORU</span>
                            <span class="text-xs font-mono text-slate-500 font-semibold" id="marketResBarcode"></span>
                        </div>
                        <h2 class="text-xl font-extrabold text-slate-900" id="marketResTitle">Ürün Adı</h2>
                    </div>
                    <div class="flex items-center gap-3">
                        <button onclick="handleMarketSearchSubmit()" class="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1.5 cursor-pointer">
                            <i class="fa-solid fa-rotate-right"></i>
                            <span>Fiyatları Yenile</span>
                        </button>
                    </div>
                </div>

                <!-- Cheaper than Warehouse Warning Alert Banner -->
                <div id="marketCheaperWarning" class="hidden bg-gradient-to-r from-red-600 to-rose-700 text-white p-5 rounded-2xl shadow-lg shadow-red-200 flex items-start gap-4">
                    <div class="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-2xl shrink-0">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                    </div>
                    <div class="flex-1">
                        <h4 class="text-base font-black tracking-wide uppercase">KRİTİK UYARI: İnternet Satış Fiyatı Depo Maliyetinden Daha Düşük!</h4>
                        <p class="text-xs text-red-100 mt-1 leading-relaxed" id="marketCheaperText">
                            Bu ürünün internetteki en ucuz perakende satış fiyatı, eczane ecza deposu net alış maliyetinin altındadır. Piyasada damping veya serbest fiyat rekabeti bulunmaktadır.
                        </p>
                    </div>
                </div>

                <!-- KPI Stat Cards -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <!-- 1. En Ucuz Depo Alışı -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">En Ucuz Depo Alış</span>
                            <span class="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center"><i class="fa-solid fa-truck-ramp-box"></i></span>
                        </div>
                        <div>
                            <div class="text-2xl font-black text-slate-900" id="kpiDepoFiyat">- ₺</div>
                            <div class="text-xs text-slate-500 mt-1 truncate font-medium" id="kpiDepoAdi">-</div>
                        </div>
                    </div>

                    <!-- 2. En Ucuz İnternet Satışı -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">En Ucuz İnternet Satışı</span>
                            <span class="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center"><i class="fa-solid fa-cart-shopping"></i></span>
                        </div>
                        <div>
                            <div class="text-2xl font-black text-indigo-600" id="kpiInternetFiyat">- ₺</div>
                            <div class="text-xs text-slate-500 mt-1 truncate font-medium" id="kpiInternetPlatform">-</div>
                        </div>
                    </div>

                    <!-- 3. Kâr / Marj Analizi -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between" id="kpiKarCard">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">Potansiyel Brüt Kâr</span>
                            <span class="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center"><i class="fa-solid fa-chart-line"></i></span>
                        </div>
                        <div>
                            <div class="text-2xl font-black text-slate-900" id="kpiKarFark">- ₺</div>
                            <div class="text-xs text-slate-500 mt-1 font-medium" id="kpiKarYuzde">Marj: -%</div>
                        </div>
                    </div>

                    <!-- 4. Piyasa Derinliği -->
                    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                        <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                            <span class="font-medium">Piyasa Fiyat Dağılımı</span>
                            <span class="w-7 h-7 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center"><i class="fa-solid fa-scale-balanced"></i></span>
                        </div>
                        <div>
                            <div class="text-xs font-bold text-slate-700 flex justify-between">
                                <span>Ortalama:</span>
                                <span id="kpiOrtalamaFiyat">- ₺</span>
                            </div>
                            <div class="text-xs font-bold text-slate-700 flex justify-between mt-1">
                                <span>En Yüksek:</span>
                                <span id="kpiYuksekFiyat">- ₺</span>
                            </div>
                            <div class="text-[11px] text-slate-400 mt-1 font-medium" id="kpiToplamTeklif">- Teklif</div>
                        </div>
                    </div>
                </div>

                <!-- Main Content Split: Wholesale (Left) vs Retail Offers (Right) -->
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    <!-- LEFT COLUMN: Depo & Pazaryeri Alış Fiyatları (4/12) -->
                    <div class="lg:col-span-4 space-y-4">
                        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                            <div class="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                                <h3 class="font-bold text-sm text-slate-900 flex items-center gap-2">
                                    <i class="fa-solid fa-truck-ramp-box text-emerald-600"></i>
                                    <span>Depo Alış Fiyatları</span>
                                </h3>
                                <span class="text-xs text-slate-500 font-medium" id="depoOzetCount">6 Depo</span>
                            </div>
                            <div class="p-3 divide-y divide-slate-100" id="depoFiyatlariList">
                                <!-- Injected dynamically -->
                            </div>
                        </div>
                    </div>

                    <!-- RIGHT COLUMN: E-Ticaret Perakende Teklifleri (8/12) -->
                    <div class="lg:col-span-8 space-y-4">
                        <!-- Platform Filter Bar -->
                        <div class="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-2 overflow-x-auto" id="platformFilterBar">
                            <!-- Platform chips injected dynamically -->
                        </div>

                        <!-- Retail Offers Grid -->
                        <div class="space-y-3" id="retailOffersList">
                            <!-- Injected dynamically -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>

    <!-- Settings Modal -->
    <div id="settingsModal" style="display: none;" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div class="px-6 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div id="settingsModalIcon" class="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
                        <i class="fa-solid fa-database text-lg"></i>
                    </div>
                    <div>
                        <h3 id="settingsModalTitle" class="text-base font-bold text-white leading-snug">TRIA Eczane Veritabanı (Oracle) Bağlantı & Şifre Ayarları</h3>
                        <p id="settingsModalDesc" class="text-xs text-slate-300">Oracle sunucu IP, port, şema adı ve şifresini buradan girip canlı test edebilirsiniz.</p>
                    </div>
                </div>
                <button onclick="closeSettingsModal()" class="text-slate-400 hover:text-white transition p-1.5 rounded-lg hover:bg-white/10 cursor-pointer">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <!-- Modal Tabs Navigation -->
            <div class="flex border-b border-slate-200 px-6 pt-3 bg-slate-50 gap-2 overflow-x-auto">
                <button type="button" id="tabBtnBotanik" onclick="switchSettingsTab('botanik')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-emerald-600 text-emerald-900 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-leaf text-emerald-600"></i>
                    <span>🌿 Botanik Eczane (MS SQL)</span>
                    <span id="tabBotanikBadge" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">Canlı</span>
                </button>
                <button type="button" id="tabBtnTria" onclick="switchSettingsTab('tria')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-database text-amber-600"></i>
                    <span>⚡ TRIA Eczane (Oracle)</span>
                    <span id="tabTriaBadge" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-600 font-bold">Hazır</span>
                </button>
                <button type="button" id="tabBtnTebeos" onclick="switchSettingsTab('tebeos')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-mortar-pestle text-sky-600"></i>
                    <span>🔷 TEBEOS Eczane (PostgreSQL)</span>
                    <span id="tabTebeosBadge" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-sky-100 text-sky-800 font-bold">Canlı</span>
                </button>
                <button type="button" id="tabBtnDepolar" onclick="switchSettingsTab('depolar')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-truck-ramp-box text-slate-600"></i>
                    <span>🏢 Ecza Depoları & Pazaryeri</span>
                </button>
                <button type="button" id="tabBtnKatalog" onclick="switchSettingsTab('katalog')" class="hidden pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-barcode text-indigo-600"></i>
                    <span>📊 Ürün & Çoklu Barkod Kataloğu</span>
                </button>
                <button type="button" id="tabBtnDermo" onclick="switchSettingsTab('dermo')" class="hidden pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-wand-magic-sparkles text-pink-600"></i>
                    <span>✨ Dermo Barkod Eşleme</span>
                    <span class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-pink-100 text-pink-800 font-bold">Sihirbaz</span>
                </button>
                <button type="button" id="tabBtnGuncelleme" onclick="switchSettingsTab('guncelleme')" class="pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-500 hover:text-slate-800 flex items-center space-x-2 transition cursor-pointer shrink-0">
                    <i class="fa-solid fa-cloud-arrow-down text-cyan-600"></i>
                    <span>🔄 Sürüm & Lisans</span>
                    <span id="tabUpdateBadge" class="hidden ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold">Yeni</span>
                </button>
                <button type="button" id="tabBtnYonetici" onclick="switchSettingsTab('yonetici')" class="ml-auto pb-2.5 px-3.5 text-xs font-bold border-b-2 border-transparent text-slate-400 hover:text-slate-800 flex items-center space-x-1.5 transition cursor-pointer shrink-0" title="Yönetici Paneli (Şifre Korumalı)">
                    <i class="fa-solid fa-user-shield text-rose-600"></i>
                    <span>🔒 Yönetici Paneli</span>
                </button>
            </div>

            <!-- Modal Body (Form Grid) -->
            <div class="p-6 max-h-[75vh] overflow-y-auto space-y-6">
                <!-- Eczane Otomasyon Yazılımı Tercihi (Kurulu Eczane Otomasyonu & Değiştirme) -->
                <div class="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-2xl p-4 shadow-sm space-y-3">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div class="flex items-center space-x-2.5">
                            <i class="fa-solid fa-hospital text-emerald-400 text-base"></i>
                            <div>
                                <span class="text-xs font-bold text-white uppercase tracking-wider">Aktif Eczane Otomasyon Sistemi:</span>
                                <span id="activeOtoBannerLabel" class="ml-1.5 text-xs font-black px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">Botanik Eczane (MS SQL)</span>
                            </div>
                        </div>
                        <button type="button" onclick="toggleOtomasyonSelector()" id="btnToggleOtoSelector" class="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white text-[11px] font-bold border border-white/15 transition flex items-center space-x-1.5 cursor-pointer self-start sm:self-auto">
                            <i class="fa-solid fa-sliders text-amber-400 text-[10px]"></i>
                            <span>Otomasyon Sistemini Değiştir</span>
                        </button>
                    </div>
                    <div id="otoSelectorCardsGrid" class="hidden grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-white/10">
                        <!-- Botanik Seçim Kartı -->
                        <div id="otoChoiceCardBotanik" onclick="selectActiveOtomasyon('BOTANIK')" class="p-3.5 rounded-xl border border-white/10 bg-white/5 cursor-pointer transition flex items-center justify-between group hover:bg-white/10">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-lg shadow-sm">
                                    <i class="fa-solid fa-leaf"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-white group-hover:text-emerald-300 transition">🌿 Botanik Eczane</div>
                                    <div class="text-[10px] text-slate-300 font-mono">MS SQL Server</div>
                                </div>
                            </div>
                            <span id="otoChoiceBadgeBotanik" class="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/10 text-slate-400">SEÇ</span>
                        </div>

                        <!-- TRIA Seçim Kartı -->
                        <div id="otoChoiceCardTria" onclick="selectActiveOtomasyon('TRIA')" class="p-3.5 rounded-xl border-2 border-amber-500 bg-amber-500/20 cursor-pointer transition flex items-center justify-between group hover:bg-amber-500/30 shadow-sm">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center text-lg shadow-sm">
                                    <i class="fa-solid fa-database"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-white group-hover:text-amber-300 transition">⚡ TRIA Eczane</div>
                                    <div class="text-[10px] text-slate-300 font-mono">Oracle Database</div>
                                </div>
                            </div>
                            <span id="otoChoiceBadgeTria" class="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-400 text-slate-950">✓ AKTİF SEÇİM</span>
                        </div>

                        <!-- TEBEOS Seçim Kartı -->
                        <div id="otoChoiceCardTebeos" onclick="selectActiveOtomasyon('TEBEOS')" class="p-3.5 rounded-xl border border-white/10 bg-white/5 cursor-pointer transition flex items-center justify-between group hover:bg-white/10">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-lg bg-sky-500 text-white flex items-center justify-center text-lg shadow-sm">
                                    <i class="fa-solid fa-mortar-pestle"></i>
                                </div>
                                <div>
                                    <div class="text-xs font-black text-white group-hover:text-sky-300 transition">🔷 TEBEOS Eczane</div>
                                    <div class="text-[10px] text-slate-300 font-mono">PostgreSQL (5454)</div>
                                </div>
                            </div>
                            <span id="otoChoiceBadgeTebeos" class="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/10 text-slate-400">SEÇ</span>
                        </div>
                    </div>
                    <input type="hidden" id="cfg_active_otomasyon" value="TRIA">
                </div>

                <!-- Tab: Botanik Eczane Veritabanı (MS SQL Server) -->
                <div id="tabContentBotanik" class="space-y-5">
                    <!-- Botanik Header Alert -->
                    <div class="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4 flex items-start space-x-3.5">
                        <div class="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-emerald-200">
                            <i class="fa-solid fa-leaf"></i>
                        </div>
                        <div class="text-xs text-emerald-950 leading-relaxed">
                            <div class="font-bold text-sm text-emerald-900 mb-0.5">Botanik Eczane Otomasyonu (MS SQL Server) Veri Bağlantısı</div>
                            Eczanenizin ana bilgisayarında veya yerel ağında çalışan Botanik MS SQL Server veritabanı bağlantı bilgilerini buradan yapılandırabilirsiniz.
                            Sorgulanan her ilacın güncel raf stoğu, son 6 aylık Nakit/Reçete satışları ve depolardan gelen son alış faturaları (girişleri) anında analiz edilir.
                        </div>
                    </div>

                    <!-- Hızlı Profil & Config'den Otomatik Oku -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                        <div class="text-xs font-bold text-slate-700 flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-bolt text-amber-500"></i><span>Otomatik Algılama & Hızlı Kurulum:</span></span>
                            <span class="text-[11px] text-slate-400 font-normal">Botanik ayarlarını otomatik bulur veya elle girebilirsiniz</span>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button type="button" onclick="autoReadBotanikConfigFile()" class="px-3.5 py-2 rounded-xl bg-white border border-emerald-400 hover:border-emerald-600 hover:bg-emerald-50 text-emerald-800 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-wand-magic-sparkles text-emerald-600"></i>
                                <span>🔍 Botanik Bağlantısını Otomatik Bul (Config Oku)</span>
                            </button>
                            <button type="button" onclick="setBotanikProfile('yerel')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>💻 Bu Bilgisayar / Yerel (.\\\\BOTANIKSQL)</span>
                            </button>
                        </div>
                    </div>

                    <!-- Botanik Bağlantı Parametreleri Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                        <!-- Sunucu / Server / Instance -->
                        <div class="md:col-span-2">
                            <label class="text-xs font-bold text-slate-700 flex items-center space-x-1 mb-1">
                                <i class="fa-solid fa-server text-emerald-600"></i>
                                <span>SQL Server Adı / Instance (Host):</span>
                            </label>
                            <input type="text" id="cfg_botanik_server" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="Örn: .\\\\BOTANIKSQL veya 192.168.1.10\\\\BOTANIKSQL">
                        </div>

                        <!-- Veritabanı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Veritabanı Adı (Database):</label>
                            <input type="text" id="cfg_botanik_db" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="eczane">
                        </div>

                        <!-- Kullanıcı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">SQL Kullanıcı Adı (UID):</label>
                            <input type="text" id="cfg_botanik_user" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="sa">
                        </div>

                        <!-- Şifre -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">SQL Şifresi (PWD):</label>
                            <div class="relative">
                                <input type="password" id="cfg_botanik_pwd" class="w-full text-xs px-3.5 py-2.5 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="••••••••">
                                <button type="button" onclick="togglePasswordVisibility('cfg_botanik_pwd', this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Windows Authentication Checkbox -->
                        <div class="flex items-center space-x-2 pt-6">
                            <input type="checkbox" id="cfg_botanik_trusted" class="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer">
                            <label for="cfg_botanik_trusted" class="text-xs font-bold text-slate-700 cursor-pointer">Windows Kimlik Doğrulama (Trusted Connection)</label>
                        </div>
                    </div>

                    <!-- Canlı Ping & Test Alanı -->
                    <div class="flex items-center justify-between pt-1">
                        <button type="button" id="btnPingBotanik" onclick="pingBotanikConnection()" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-200 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-bolt"></i>
                            <span>🔍 Botanik Bağlantısını Test Et & Ping</span>
                        </button>
                        <span class="text-[11px] text-slate-400">Canlı ping süresini, SQL Server sürümünü ve kayıtlı veri adetlerini doğrular.</span>
                    </div>
                    <div id="botanikPingResult" class="hidden mt-3 p-3.5 rounded-2xl text-xs"></div>
                </div>
                <!-- Tab 1: Depolar & Pazaryerleri -->
                <div id="tabContentDepolar" class="hidden space-y-6">
                    <!-- Info Alert with Active / Passive summary -->
                    <div class="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div class="flex items-start space-x-3">
                            <i class="fa-solid fa-shield-halved text-blue-600 text-lg mt-0.5"></i>
                            <div class="text-xs text-blue-900 leading-relaxed">
                                <strong>Depo Yönetimi & Otomatik Pasiflik:</strong> Çalışmadığınız depoları anahtarından <strong>Pasif</strong> yapabilirsiniz. <u>Kullanıcı adı veya şifresi girilmeyen depolar otomatik olarak devre dışı bırakılır</u> ve karşılaştırmada taranmaz.
                            </div>
                        </div>
                        <div id="depoTabSummaryBadge" class="shrink-0 px-3 py-1.5 rounded-xl bg-blue-100 text-blue-900 text-xs font-bold border border-blue-300">
                            Yükleniyor...
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <!-- 1. Alliance Healthcare Card -->
                        <div id="card_alliance" class="p-4 rounded-2xl border border-sky-100 bg-sky-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-sky-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-sky-800 font-bold text-sm">
                                    <i class="fa-solid fa-truck-medical text-sky-600"></i>
                                    <span>Alliance Healthcare</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Alliance Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_alliance_active" onchange="onDepoActiveToggle('alliance')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-600"></div>
                                    </label>
                                    <span id="badge_alliance_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Eczane Kodu (GLN / Şube)</label>
                                    <input type="text" id="cfg_alliance_pcode" oninput="onDepoCredInput('alliance')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="Eczane / Şube Kodu">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı</label>
                                    <input type="text" id="cfg_alliance_user" oninput="onDepoCredInput('alliance')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_alliance_pwd" oninput="onDepoCredInput('alliance')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_alliance_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 2. Selçuk Ecza Deposu Card -->
                        <div id="card_selcuk" class="p-4 rounded-2xl border border-emerald-100 bg-emerald-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-emerald-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-emerald-800 font-bold text-sm">
                                    <i class="fa-solid fa-building-columns text-emerald-600"></i>
                                    <span>Selçuk Ecza Deposu</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Selçuk Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_selcuk_active" onchange="onDepoActiveToggle('selcuk')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-emerald-600"></div>
                                    </label>
                                    <span id="badge_selcuk_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı (SEL...)</label>
                                    <input type="text" id="cfg_selcuk_user" oninput="onDepoCredInput('selcuk')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono" placeholder="Selçuk WebDepo Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_selcuk_pwd" oninput="onDepoCredInput('selcuk')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_selcuk_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 3. Nevzat Ecza Deposu Card -->
                        <div id="card_nevzat" class="p-4 rounded-2xl border border-orange-100 bg-orange-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-orange-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-orange-800 font-bold text-sm">
                                    <i class="fa-solid fa-truck-ramp-box text-orange-600"></i>
                                    <span>Nevzat Ecza Deposu</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Nevzat Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_nevzat_active" onchange="onDepoActiveToggle('nevzat')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-orange-600"></div>
                                    </label>
                                    <span id="badge_nevzat_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Hesap Kodu</label>
                                    <input type="text" id="cfg_nevzat_account" oninput="onDepoCredInput('nevzat')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="Nevzat Hesap Kodu">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı</label>
                                    <input type="text" id="cfg_nevzat_user" oninput="onDepoCredInput('nevzat')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_nevzat_pwd" oninput="onDepoCredInput('nevzat')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_nevzat_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 4. İSKOOP Card -->
                        <div id="card_iskoop" class="p-4 rounded-2xl border border-red-100 bg-red-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-red-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-red-800 font-bold text-sm">
                                    <i class="fa-solid fa-handshake-angle text-red-600"></i>
                                    <span>İSKOOP (İstanbul Ecza Koop)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="İSKOOP Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_iskoop_active" onchange="onDepoActiveToggle('iskoop')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-red-600"></div>
                                    </label>
                                    <span id="badge_iskoop_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı (i...)</label>
                                    <input type="text" id="cfg_iskoop_user" oninput="onDepoCredInput('iskoop')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-red-500 focus:outline-none bg-white font-mono" placeholder="İSKOOP E-Şube Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_iskoop_pwd" oninput="onDepoCredInput('iskoop')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-red-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_iskoop_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 5. BEK (Bursa Ecza Koop) Card -->
                        <div id="card_bek" class="p-4 rounded-2xl border border-teal-100 bg-teal-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-teal-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-teal-800 font-bold text-sm">
                                    <i class="fa-solid fa-handshake-simple text-teal-600"></i>
                                    <span>BEK (Bursa Eczacılar Kooperatifi)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="BEK Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_bek_active" onchange="onDepoActiveToggle('bek')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-teal-600"></div>
                                    </label>
                                    <span id="badge_bek_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı (b...)</label>
                                    <input type="text" id="cfg_bek_user" oninput="onDepoCredInput('bek')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white font-mono" placeholder="BEK Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_bek_pwd" oninput="onDepoCredInput('bek')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_bek_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 6. Ecza1 Pazaryeri Card -->
                        <div id="card_ecza1" class="p-4 rounded-2xl border border-purple-100 bg-purple-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-purple-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-purple-800 font-bold text-sm">
                                    <i class="fa-solid fa-cart-shopping text-purple-600"></i>
                                    <span>Ecza1 Pazaryeri</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Ecza1 Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_ecza1_active" onchange="onDepoActiveToggle('ecza1')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-purple-600"></div>
                                    </label>
                                    <span id="badge_ecza1_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / E-Posta</label>
                                    <input type="text" id="cfg_ecza1_user" oninput="onDepoCredInput('ecza1')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı veya E-Posta">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_ecza1_pwd" oninput="onDepoCredInput('ecza1')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_ecza1_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 7. Farmazon Pazaryeri Card -->
                        <div id="card_farmazon" class="p-4 rounded-2xl border border-amber-100 bg-amber-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-amber-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-amber-800 font-bold text-sm">
                                    <i class="fa-solid fa-store text-amber-600"></i>
                                    <span>Farmazon Pazaryeri</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Farmazon Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_farmazon_active" onchange="onDepoActiveToggle('farmazon')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-amber-600"></div>
                                    </label>
                                    <span id="badge_farmazon_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / Telefon / E-Posta</label>
                                    <input type="text" id="cfg_farmazon_user" oninput="onDepoCredInput('farmazon')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white" placeholder="Kullanıcı Adı veya E-Posta">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_farmazon_pwd" oninput="onDepoCredInput('farmazon')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_farmazon_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 8. DNA Ecza Deposu Card -->
                        <div id="card_dna" class="p-4 rounded-2xl border border-cyan-100 bg-cyan-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-cyan-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-cyan-800 font-bold text-sm">
                                    <i class="fa-solid fa-dna text-cyan-600"></i>
                                    <span>DNA Ecza Deposu</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="DNA Ecza Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_dna_active" onchange="onDepoActiveToggle('dna')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-cyan-600"></div>
                                    </label>
                                    <span id="badge_dna_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / E-Posta</label>
                                    <input type="text" id="cfg_dna_user" oninput="onDepoCredInput('dna')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-cyan-500 focus:outline-none bg-white font-mono" placeholder="DNA Ecza Kullanıcı Adı / E-Posta">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_dna_pwd" oninput="onDepoCredInput('dna')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-cyan-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_dna_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 9. Eczatrend Ortak Alım Grubu Card -->
                        <div id="card_eczatrend" class="p-4 rounded-2xl border border-orange-100 bg-orange-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-orange-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-orange-900 font-bold text-sm">
                                    <i class="fa-solid fa-people-group text-orange-600"></i>
                                    <span>Eczatrend (Alım Grubu)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="Eczatrend Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_eczatrend_active" onchange="onDepoActiveToggle('eczatrend')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-orange-600"></div>
                                    </label>
                                    <span id="badge_eczatrend_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Kullanıcı Adı / E-Posta</label>
                                    <input type="text" id="cfg_eczatrend_user" oninput="onDepoCredInput('eczatrend')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="Eczatrend E-Posta / Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_eczatrend_pwd" oninput="onDepoCredInput('eczatrend')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_eczatrend_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 10. EczaneTakas Pazaryeri Card -->
                        <div id="card_eczanetakas" class="p-4 rounded-2xl border border-sky-100 bg-sky-50/40 space-y-3 transition">
                            <div class="flex items-center justify-between border-b border-sky-200/60 pb-2">
                                <div class="flex items-center space-x-2 text-sky-900 font-bold text-sm">
                                    <i class="fa-solid fa-arrow-right-arrow-left text-sky-600"></i>
                                    <span>EczaneTakas (Pazaryeri)</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="relative inline-flex items-center cursor-pointer select-none" title="EczaneTakas Aktif / Pasif Yap">
                                        <input type="checkbox" id="cfg_eczanetakas_active" onchange="onDepoActiveToggle('eczanetakas')" class="sr-only peer">
                                        <div class="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-600"></div>
                                    </label>
                                    <span id="badge_eczanetakas_status" class="hidden text-[11px] font-bold"></span>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">E-Posta / Kullanıcı Adı</label>
                                    <input type="text" id="cfg_eczanetakas_user" oninput="onDepoCredInput('eczanetakas')" class="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="EczaneTakas E-Posta / Kullanıcı Adı">
                                </div>
                                <div>
                                    <label class="text-[11px] font-semibold text-slate-600 block mb-0.5">Şifre</label>
                                    <div class="relative">
                                        <input type="password" id="cfg_eczanetakas_pwd" oninput="onDepoCredInput('eczanetakas')" class="w-full text-xs px-3 py-2 pr-9 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-white font-mono" placeholder="••••••••">
                                        <button type="button" onclick="togglePasswordVisibility('cfg_eczanetakas_pwd', this)" class="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"><i class="fa-solid fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 2: Tria Eczane Veritabanı (Oracle) -->
                <div id="tabContentTria" class="space-y-5">
                    <div class="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-4 flex items-start space-x-3.5">
                        <div class="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-amber-200">
                            <i class="fa-solid fa-database"></i>
                        </div>
                        <div class="text-xs text-amber-950 leading-relaxed">
                            <div class="font-bold text-sm text-amber-900 mb-0.5">TRIA Eczane Otomasyonu (Oracle) Veri Bağlantısı</div>
                            Eczanenizin ana bilgisayarında veya yerel ağında çalışan TRIA Oracle bağlantı bilgilerini otomatik bulabilir veya elle girebilirsiniz.
                            Bu sayede sorgulanan her ilacın gerçek raf stoğu ve son 6 aylık Nakit/Reçete satış hızı anında analiz edilir.
                        </div>
                    </div>

                    <!-- Otomatik Algılama & Hızlı Kurulum -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                        <div class="text-xs font-bold text-slate-700 flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-bolt text-amber-500"></i><span>Otomatik Algılama & Hızlı Bağlantı:</span></span>
                            <span class="text-[11px] text-slate-400 font-normal">Ağdaki TRIA sunucusunu ve eczane şemasını otomatik bulur</span>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button type="button" onclick="discoverTriaHost()" class="px-3.5 py-2 rounded-xl bg-white border border-amber-400 hover:border-amber-600 hover:bg-amber-50 text-amber-900 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-wand-magic-sparkles text-amber-600"></i>
                                <span>🌐 Ağda TRIA Sunucusunu & Şemasını Otomatik Bul</span>
                            </button>
                            <button type="button" onclick="loadAvailableSchemas()" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-amber-500 hover:text-amber-800 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-list-check text-amber-600"></i>
                                <span>📋 Sunucudaki Eczane Şemalarını Listele</span>
                            </button>
                            <button type="button" onclick="setTriaProfile('yerel')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 hover:text-emerald-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>💻 Bu Bilgisayar / Yerel (127.0.0.1)</span>
                            </button>
                        </div>
                    </div>

                    <!-- Tria Bağlantı Parametreleri Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                        <!-- Host + Otomatik Bul Butonu -->
                        <div class="md:col-span-2">
                            <div class="flex items-center justify-between mb-1">
                                <label class="text-xs font-bold text-slate-700 flex items-center space-x-1">
                                    <i class="fa-solid fa-network-wired text-indigo-600"></i>
                                    <span>TRIA Sunucu IP (Host):</span>
                                </label>
                                <button type="button" onclick="discoverTriaHost()" id="btnDiscoverHost" class="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 transition flex items-center space-x-1 cursor-pointer">
                                    <i class="fa-solid fa-globe"></i>
                                    <span>🌐 Ağda Otomatik Bul</span>
                                </button>
                            </div>
                            <input type="text" id="cfg_tria_host" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="Örn: 127.0.0.1 veya Ana Bilgisayar IP Adresi">
                            <div id="discoverResult" class="hidden text-[11px] mt-1 text-indigo-600 font-medium"></div>
                        </div>

                        <!-- Port -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Oracle Port:</label>
                            <input type="text" id="cfg_tria_port" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="1521">
                        </div>

                        <!-- SID / Servis -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Oracle SID / Servis:</label>
                            <input type="text" id="cfg_tria_sid" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="ORCL">
                        </div>

                        <!-- Şema / Kullanıcı Adı + Şemaları Listele Butonu -->
                        <div class="md:col-span-2">
                            <div class="flex items-center justify-between mb-1">
                                <label class="text-xs font-bold text-slate-700 flex items-center space-x-1">
                                    <i class="fa-solid fa-user-gear text-amber-600"></i>
                                    <span>TRIA Kullanıcı Adı (Eczane Şeması):</span>
                                </label>
                                <button type="button" onclick="loadAvailableSchemas()" id="btnListSchemas" class="text-[11px] font-bold text-amber-700 hover:text-amber-900 transition flex items-center space-x-1 cursor-pointer">
                                    <i class="fa-solid fa-list-check"></i>
                                    <span>📋 Eczane Şemalarını Listele</span>
                                </button>
                            </div>
                            <input type="text" id="cfg_tria_user" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-slate-50 font-mono font-bold uppercase" placeholder="Örn: ECZANE ŞEMA ADI">
                            <!-- Dinamik Şema Rozetleri Listesi -->
                            <div id="schemaListContainer" class="hidden mt-2 p-2.5 bg-amber-50/70 border border-amber-200 rounded-xl text-xs">
                                <div class="text-[11px] font-bold text-amber-900 mb-1.5 flex items-center space-x-1">
                                    <i class="fa-solid fa-server"></i>
                                    <span>Veritabanında Bulunan Eczane Şemaları (Tıklayarak Seçin):</span>
                                </div>
                                <div id="schemaPills" class="flex flex-wrap gap-1.5"></div>
                            </div>
                        </div>

                        <!-- Şifre -->
                        <div class="md:col-span-2">
                            <label class="text-xs font-bold text-slate-700 block mb-1">TRIA Oracle Şifresi:</label>
                            <div class="relative">
                                <input type="password" id="cfg_tria_pwd" class="w-full text-xs px-3.5 py-2.5 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="••••••••">
                                <button type="button" onclick="togglePasswordVisibility('cfg_tria_pwd', this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Bilgilendirme Kartı -->
                    <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-start space-x-3">
                        <i class="fa-solid fa-lightbulb text-emerald-600 text-lg mt-0.5"></i>
                        <div class="text-xs text-emerald-900 leading-relaxed">
                            <strong>💡 Otomatik Şema & Sunucu Bulma:</strong><br>
                            <strong>'Ağda TRIA Sunucusunu & Şemasını Otomatik Bul'</strong> veya <strong>'Eczane Şemalarını Listele'</strong> butonuna basarak Oracle sunucunuzdaki aktif eczane şemasını tek tıkla tespit edebilir ya da kendi TRIA kullanıcı adı/şifrenizi elle girebilirsiniz.
                        </div>
                    </div>

                    <!-- Canlı Ping & Test Alanı -->
                    <div class="flex items-center justify-between pt-1">
                        <button type="button" id="btnPingTria" onclick="pingTriaConnection()" class="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-xs font-bold shadow-md shadow-amber-200 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-bolt"></i>
                            <span>🔍 Bağlantıyı Test Et & Ping</span>
                        </button>
                        <span class="text-[11px] text-slate-400">Canlı ping süresini, Oracle sürümünü ve kayıtlı veri adetlerini doğrular.</span>
                    </div>
                    <div id="triaPingResult" class="hidden mt-3 p-3.5 rounded-2xl text-xs"></div>
                </div>

                <!-- Tab: TEBEOS Eczane Veritabanı (PostgreSQL - Port 5454) -->
                <div id="tabContentTebeos" class="hidden space-y-5">
                    <!-- TEBEOS Header Alert -->
                    <div class="bg-gradient-to-r from-sky-50 to-cyan-50 border border-sky-200 rounded-2xl p-4 flex items-start space-x-3.5">
                        <div class="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-sky-200">
                            <i class="fa-solid fa-mortar-pestle"></i>
                        </div>
                        <div class="text-xs text-sky-950 leading-relaxed">
                            <div class="font-bold text-sm text-sky-900 mb-0.5">TEBEOS Eczane Otomasyonu (PostgreSQL) Veri Bağlantısı</div>
                            Türk Eczacıları Birliği TEBEOS otomasyonunun PostgreSQL veritabanına (varsayılan port: <strong>5454</strong>) doğrudan bağlanır.
                            Sorgulanan her ilacın gerçek raf stoğu, son 6 aylık Reçeteli/Elden çıkışları, son depo alış faturaları ve muadil stokları anında analiz edilir.
                        </div>
                    </div>

                    <!-- Hızlı Profil & Otomatik Bul -->
                    <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                        <div class="text-xs font-bold text-slate-700 flex items-center justify-between">
                            <span class="flex items-center space-x-1.5"><i class="fa-solid fa-bolt text-sky-500"></i><span>Otomatik Algılama & Hızlı Bağlantı:</span></span>
                            <span class="text-[11px] text-slate-400 font-normal">Ağdaki TEBEOS sunucusunu otomatik bulur veya elle girebilirsiniz</span>
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button type="button" onclick="discoverTebeosHost()" id="btnDiscoverTebeos" class="px-3.5 py-2 rounded-xl bg-white border border-sky-400 hover:border-sky-600 hover:bg-sky-50 text-sky-800 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <i class="fa-solid fa-radar text-sky-600"></i>
                                <span>🌐 Ağda TEBEOS Sunucusunu Otomatik Bul (Port 5454)</span>
                            </button>
                            <button type="button" onclick="setTebeosProfile('yerel')" class="px-3.5 py-2 rounded-xl bg-white border border-slate-300 hover:border-sky-500 hover:text-sky-700 text-slate-700 text-xs font-bold shadow-2xs transition cursor-pointer flex items-center space-x-1.5">
                                <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>💻 Bu Bilgisayar / Yerel (127.0.0.1:5454)</span>
                            </button>
                        </div>
                        <div id="tebeosDiscoverResult" class="hidden text-[11px] mt-1 text-sky-700 font-medium"></div>
                    </div>

                    <!-- TEBEOS Bağlantı Parametreleri Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                        <!-- Host -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 flex items-center space-x-1 mb-1">
                                <i class="fa-solid fa-server text-sky-600"></i>
                                <span>TEBEOS Sunucu IP (Host):</span>
                            </label>
                            <input type="text" id="cfg_tebeos_host" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="Örn: 127.0.0.1 veya Ana Bilgisayar IP Adresi">
                        </div>

                        <!-- Port -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">PostgreSQL Port:</label>
                            <input type="text" id="cfg_tebeos_port" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="5454">
                        </div>

                        <!-- Veritabanı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">Veritabanı Adı (Database):</label>
                            <input type="text" id="cfg_tebeos_db" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="tebeos_db">
                        </div>

                        <!-- Kullanıcı Adı -->
                        <div>
                            <label class="text-xs font-bold text-slate-700 block mb-1">PostgreSQL Kullanıcı Adı:</label>
                            <input type="text" id="cfg_tebeos_user" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="tebeos">
                        </div>

                        <!-- Şifre -->
                        <div class="md:col-span-2">
                            <label class="text-xs font-bold text-slate-700 block mb-1">PostgreSQL Şifresi:</label>
                            <div class="relative">
                                <input type="password" id="cfg_tebeos_pwd" class="w-full text-xs px-3.5 py-2.5 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:outline-none bg-slate-50 font-mono font-bold" placeholder="••••••••">
                                <button type="button" onclick="togglePasswordVisibility('cfg_tebeos_pwd', this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Canlı Ping & Test Alanı -->
                    <div class="flex items-center justify-between pt-1">
                        <button type="button" id="btnPingTebeos" onclick="pingTebeosConnection()" class="px-5 py-2.5 bg-gradient-to-r from-sky-600 to-cyan-600 hover:from-sky-700 hover:to-cyan-700 text-white rounded-xl text-xs font-bold shadow-md shadow-sky-200 transition flex items-center space-x-2 cursor-pointer">
                            <i class="fa-solid fa-bolt"></i>
                            <span>🔍 TEBEOS Bağlantısını Test Et & Ping</span>
                        </button>
                        <span class="text-[11px] text-slate-400">Canlı ping süresini, PostgreSQL sürümünü ve kayıtlı veri adetlerini doğrular.</span>
                    </div>
                    <div id="tebeosPingResult" class="hidden mt-3 p-3.5 rounded-2xl text-xs"></div>
                </div>

                <!-- Tab: Otomatik Güncelleme & Sürüm / Lisans Yönetimi (Kullanıcı Görünümü) -->
                <div id="tabContentGuncelleme" class="hidden space-y-6">
                    <!-- Sürüm Bilgi Kartı -->
                    <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/60 rounded-2xl p-6 text-white shadow-md">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div class="flex items-center space-x-4">
                                <div class="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-2xl text-cyan-300 shadow-md">
                                    <i class="fa-solid fa-cloud-arrow-down"></i>
                                </div>
                                <div>
                                    <div class="flex items-center space-x-2">
                                        <h4 class="text-lg font-black text-white" id="updateLocalVersionTitle">Farma Radar v1.3.5</h4>
                                        <span class="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">Kararlı Sürüm</span>
                                    </div>
                                    <p class="text-xs text-slate-300 mt-1">Farma Radar Eczane Otomatik Güncelleme & Dağıtım Ağı</p>
                                    <p class="text-[11px] text-slate-400 font-mono mt-0.5" id="updateBuildDateText">Son Derleme: 2026-10-24</p>
                                </div>
                            </div>

                            <div class="flex flex-wrap items-center gap-2">
                                <button type="button" onclick="checkAppUpdate(true)" id="btnCheckUpdateNow" class="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold rounded-xl transition shadow-md shadow-cyan-900/40 flex items-center gap-2 cursor-pointer">
                                    <i class="fa-solid fa-arrows-rotate" id="checkUpdateIcon"></i>
                                    <span>Güncellemeleri Denetle</span>
                                </button>
                                <button type="button" onclick="restartAppServer()" class="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-bold rounded-xl transition border border-white/15 flex items-center gap-1.5 cursor-pointer" title="Sunucuyu yeniden başlatır">
                                    <i class="fa-solid fa-power-off text-amber-400"></i>
                                    <span>Yeniden Başlat</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Güncelleme Durum & Sonuç Kartı -->
                    <div id="updateStatusCard" class="hidden p-5 rounded-2xl border transition-all">
                        <!-- JS ile güncellenecek -->
                    </div>

                    <!-- Kurumsal Lisans & Abonelik Yönetimi -->
                    <div class="bg-white border-2 border-indigo-100 rounded-2xl p-5 space-y-4 shadow-xs">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600 text-lg">
                                    <i class="fa-solid fa-key"></i>
                                </div>
                                <div>
                                    <div class="flex items-center gap-2">
                                        <h5 class="text-sm font-black text-slate-900" id="licPharmacyTitle">Eczane Kurumsal Lisansı</h5>
                                        <span id="licStatusBadge" class="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">AKTİF</span>
                                    </div>
                                    <p class="text-[11px] text-slate-500 mt-0.5">Bu Bilgisayar Donanım Kimliği (HWID): <strong id="licMyHwid" class="font-mono text-indigo-700 select-all">----</strong></p>
                                </div>
                            </div>
                            <div class="text-right text-xs">
                                <div class="text-slate-500">Bitiş Tarihi: <strong id="licExpiresAt" class="text-slate-800 font-mono">--</strong></div>
                                <div class="text-[11px] text-emerald-700 font-bold" id="licDaysLeftText">-- gün kaldı</div>
                            </div>
                        </div>

                        <div class="space-y-2">
                            <div class="flex items-center justify-between">
                                <label class="block text-xs font-bold text-slate-700">Lisans Anahtarı (FR-... / EDP-...)</label>
                                <span id="licRemoteCheckedAt" class="text-[10px] text-slate-400 font-mono"></span>
                            </div>
                            <div class="flex flex-col sm:flex-row gap-2">
                                <input type="text" id="licKeyInput" placeholder="FR-... veya EDP-..." class="flex-1 text-xs font-mono p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white focus:outline-none focus:border-indigo-500">
                                <button type="button" onclick="activateNewLicense()" id="btnActivateLic" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition shadow-xs cursor-pointer shrink-0 flex items-center justify-center gap-1.5">
                                    <i class="fa-solid fa-shield-check"></i>
                                    <span>Lisansı Doğrula & Kaydet</span>
                                </button>
                                <button type="button" onclick="syncLicenseWithCloud(true)" id="btnSyncLicCloud" class="px-3.5 py-2.5 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold rounded-xl transition cursor-pointer shrink-0 flex items-center justify-center gap-1.5" title="Yönetici panelinden süreniz uzatıldıysa yeni anahtar girmeden online güncelleyin">
                                    <i class="fa-solid fa-cloud-arrow-down" id="syncLicCloudIcon"></i>
                                    <span>Online Kontrol Et</span>
                                </button>
                            </div>
                            <div id="licFeedbackMsg" class="hidden text-xs font-semibold p-2.5 rounded-xl"></div>
                        </div>
                    </div>
                </div>

                <!-- Tab: Şifre Korumalı Yönetici Paneli (GitHub Adresi, Kart Birleştirme, Katalog & Canlı Dağıtım) -->
                <div id="tabContentYonetici" class="hidden space-y-6">
                    <!-- Kilit Ekranı (Şifre Girişi) -->
                    <div id="adminSettingsLockBox" class="max-w-lg mx-auto my-6 bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 text-white rounded-3xl p-7 border border-rose-500/30 shadow-xl space-y-5">
                        <div class="flex items-center space-x-4">
                            <div class="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-400/40 flex items-center justify-center text-2xl text-rose-400 shrink-0 shadow-md">
                                <i class="fa-solid fa-user-shield"></i>
                            </div>
                            <div>
                                <span class="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-400/30">YETKİLİ ERİŞİMİ</span>
                                <h4 class="text-base font-black text-white mt-1">Sistem Yönetici Paneli</h4>
                                <p class="text-xs text-slate-300 mt-0.5">Bu bölümdeki gelişmiş sistem araçları son kullanıcıya kapalıdır.</p>
                            </div>
                        </div>

                        <div class="bg-white/5 border border-white/10 rounded-2xl p-3.5 text-[11px] text-slate-300 space-y-1.5 leading-relaxed">
                            <div class="font-bold text-amber-300 flex items-center gap-1.5">
                                <i class="fa-solid fa-screwdriver-wrench text-xs"></i>
                                <span>Bu Panelde Yer Alan Yönetici Araçları:</span>
                            </div>
                            <div>• <strong>Botanik Kart Birleştirme & Dermo/OTC Barkod Onarım Sihirbazı</strong></div>
                            <div>• <strong>Ürün Kataloğu & Botanik / TRIA / Excel Toplu Aktarım Merkezi</strong></div>
                            <div>• <strong>GitHub Manifest Adresi & Canlı Sürüm Yayınlama Portalı</strong></div>
                        </div>

                        <div class="space-y-2">
                            <label class="block text-xs font-bold text-slate-200">Yönetici Şifresi:</label>
                            <div class="flex gap-2">
                                <div class="relative flex-1">
                                    <input type="password" id="adminSettingsPwdInput" onkeydown="if(event.key==='Enter'){event.preventDefault();unlockAdminSettingsPanel();}" placeholder="Yönetici şifresini giriniz..." class="w-full text-xs font-mono px-3.5 py-2.5 pr-10 rounded-xl bg-slate-950/90 border border-slate-700 text-white focus:outline-none focus:border-rose-400">
                                    <button type="button" onclick="togglePasswordVisibility('adminSettingsPwdInput', this)" class="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200 text-xs cursor-pointer">
                                        <i class="fa-solid fa-eye"></i>
                                    </button>
                                </div>
                                <button type="button" onclick="unlockAdminSettingsPanel()" class="px-5 py-2.5 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white text-xs font-black rounded-xl shadow-lg shadow-rose-900/40 transition flex items-center gap-2 cursor-pointer shrink-0">
                                    <i class="fa-solid fa-unlock-keyhole"></i>
                                    <span>Paneli Aç</span>
                                </button>
                            </div>
                            <div id="adminSettingsLockError" class="hidden text-xs font-bold text-rose-400 pt-1"></div>
                        </div>
                    </div>

                    <!-- Kilidi Açılmış Yönetici İçeriği -->
                    <div id="adminSettingsUnlockedArea" class="hidden space-y-6">
                        <!-- Yönetici Alt Sekme & Kısayol Barı -->
                        <div class="bg-slate-900 text-white p-3.5 rounded-2xl border border-slate-700 flex flex-wrap items-center justify-between gap-3">
                            <div class="flex flex-wrap items-center gap-2">
                                <button type="button" id="adminSubBtnDermo" onclick="switchAdminSubTab('dermo')" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-pink-600 text-white shadow-sm transition flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-wand-magic-sparkles"></i>
                                    <span>✨ Botanik Kart Birleştirme & Barkod Eşleme</span>
                                </button>
                                <button type="button" id="adminSubBtnKatalog" onclick="switchAdminSubTab('katalog')" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 transition flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-solid fa-barcode"></i>
                                    <span>📊 Katalog & Otomasyon Aktarımı</span>
                                </button>
                                <button type="button" id="adminSubBtnGithub" onclick="switchAdminSubTab('github')" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 transition flex items-center gap-1.5 cursor-pointer">
                                    <i class="fa-brands fa-github"></i>
                                    <span>🌐 GitHub Adresi & Canlı Yayınlama</span>
                                </button>
                            </div>
                            <div class="flex items-center gap-2">
                                <a href="http://127.0.0.1:8095" target="_blank" class="px-3 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition flex items-center gap-1.5 shadow-sm">
                                    <i class="fa-solid fa-key"></i>
                                    <span>Lisans CRM Paneli (:8095)</span>
                                </a>
                                <button type="button" onclick="lockAdminSettingsPanel()" class="px-3 py-2 rounded-xl text-xs font-bold bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition flex items-center gap-1.5 cursor-pointer" title="Yönetici panelini tekrar şifrele">
                                    <i class="fa-solid fa-lock"></i>
                                    <span>Kilitle</span>
                                </button>
                            </div>
                        </div>

                        <!-- Alt Sekme 1: Dermo Barkod Onarım & Kart Birleştirme Sihirbazı -->
                        <div id="tabContentDermo" class="space-y-6">
                            <!-- Üst Bilgi Kutusu -->
                            <div class="bg-gradient-to-r from-pink-50 via-rose-50 to-amber-50 border border-pink-200 rounded-2xl p-5 shadow-xs">
                                <div class="flex items-start space-x-3.5">
                                    <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-600 to-rose-500 text-white flex items-center justify-center text-lg shrink-0 shadow-md shadow-pink-200">
                                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                                    </div>
                                    <div class="space-y-1">
                                        <h4 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                                            <span>🌿 Botanik Dermo & OTC Kart Birleştirme / Barkod Onarım Sihirbazı</span>
                                            <span class="text-[10px] bg-pink-100 text-pink-800 font-extrabold px-2 py-0.5 rounded-full border border-pink-200">Sıfır Riskli</span>
                                        </h4>
                                        <p class="text-xs text-slate-600 leading-relaxed">
                                            Botanik veritabanınızda elden sahte barkodla (<code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">869922...</code>, <code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">869000...</code>), harfli veya distribütörün geçici promosyon etiketleriyle (<code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">VTR...</code>, <code class="bg-white/80 px-1 py-0.5 rounded text-pink-700 font-mono">ÖZEL FİYAT</code>) açılmış kartları tarar ve gerçek barkodlarıyla birleştirir.
                                        </p>
                                        <p class="text-[11px] text-emerald-800 font-medium pt-1 flex items-center gap-1.5">
                                            <i class="fa-solid fa-shield-check text-emerald-600 text-sm"></i>
                                            <span><strong>Güvenlik Garantisi:</strong> Bu işlem Botanik'teki mevcut hiçbir barkodunuzu veya ürününüzü <strong>silmez</strong>. Orijinal üretici EAN barkodunu Botanik'e <strong>ikincil barkod olarak</strong> ekler.</span>
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <!-- Filtreler ve Tarama Barı -->
                            <div class="p-5 rounded-2xl border border-slate-200 bg-white space-y-4 shadow-2xs">
                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-700 mb-1">Marka Filtresi:</label>
                                        <select id="dermoBrandSelect" class="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:outline-none focus:border-pink-500">
                                            <option value="">Tüm Popüler Markalar (La Roche, Bioderma, CeraVe...)</option>
                                            <option value="LA ROCHE">La Roche-Posay</option>
                                            <option value="BIODERMA">Bioderma (Naos)</option>
                                            <option value="CERAVE">CeraVe</option>
                                            <option value="AVENE">Avene (Pierre Fabre)</option>
                                            <option value="VICHY">Vichy</option>
                                            <option value="SOLGAR">Solgar (OTC)</option>
                                            <option value="OCEAN">Ocean (Orzax)</option>
                                            <option value="BEPANTHOL">Bepanthol</option>
                                            <option value="DUCRAY">Ducray</option>
                                            <option value="CAUDALIE">Caudalie</option>
                                            <option value="MUSTELA">Mustela</option>
                                            <option value="ISDIN">ISDIN</option>
                                            <option value="SVR">SVR</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-700 mb-1">İnceleme Limiti:</label>
                                        <select id="dermoLimitSelect" class="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:outline-none focus:border-pink-500">
                                            <option value="30">İlk 30 Hatalı Kart</option>
                                            <option value="50" selected>İlk 50 Hatalı Kart</option>
                                            <option value="100">İlk 100 Hatalı Kart</option>
                                            <option value="150">İlk 150 Hatalı Kart</option>
                                        </select>
                                    </div>
                                    <div class="flex items-end">
                                        <button type="button" onclick="runDermoAudit()" id="btnRunDermoAudit" class="w-full py-2.5 px-4 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white text-xs font-bold rounded-xl transition shadow-md shadow-pink-200 flex items-center justify-center gap-2 cursor-pointer">
                                            <i class="fa-solid fa-magnifying-glass-arrow-right"></i>
                                            <span>Hatalı Barkodları Tara & Eşleştir</span>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Yükleniyor Göstergesi -->
                            <div id="dermoLoading" class="hidden text-center py-10 bg-white rounded-2xl border border-slate-200">
                                <div class="inline-block animate-spin rounded-full h-8 w-8 border-3 border-pink-500 border-t-transparent"></div>
                                <p class="mt-3 text-xs font-bold text-slate-700">Botanik veritabanı taranıyor ve uluslararası barkodlar eşleştiriliyor...</p>
                                <p class="text-[11px] text-slate-400 mt-0.5">Uluslararası katalog havuzuyla karşılaştırılıyor</p>
                            </div>

                            <!-- Sonuçlar ve Eşleme Tablosu -->
                            <div id="dermoResultsContainer" class="hidden space-y-4">
                                <!-- Özet Metrikler ve Toplu Aksiyon Barı -->
                                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-xl bg-slate-900 text-white shadow-sm">
                                    <div class="flex items-center space-x-4 text-xs">
                                        <div>
                                            <span class="text-slate-400">Taranan Kart:</span>
                                            <span class="font-black text-white ml-1" id="dermoStatScanned">0</span>
                                        </div>
                                        <div class="w-px h-4 bg-slate-700"></div>
                                        <div>
                                            <span class="text-slate-400">Eşleşen Gerçek EAN:</span>
                                            <span class="font-black text-emerald-400 ml-1" id="dermoStatMatched">0</span>
                                        </div>
                                        <div class="w-px h-4 bg-slate-700"></div>
                                        <div>
                                            <span class="text-slate-400">Süre:</span>
                                            <span class="font-mono text-slate-300 ml-1" id="dermoStatElapsed">0s</span>
                                        </div>
                                    </div>
                                    <div class="flex items-center space-x-3 w-full sm:w-auto justify-end">
                                        <label class="inline-flex items-center space-x-1.5 text-xs text-slate-300 cursor-pointer select-none">
                                            <input type="checkbox" id="dermoMasterCheck" onchange="toggleAllDermoCheckboxes(this)" checked class="rounded text-pink-600 focus:ring-0 w-4 h-4 cursor-pointer">
                                            <span>Tümünü Seç</span>
                                        </label>
                                        <button type="button" onclick="applyDermoSync()" id="btnApplyDermoSync" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition shadow-md shadow-emerald-900/40 flex items-center gap-1.5 cursor-pointer">
                                            <i class="fa-solid fa-floppy-disk"></i>
                                            <span>Seçilenleri Botanik'e Ekle</span>
                                        </button>
                                    </div>
                                </div>

                                <!-- Önizleme Tablosu -->
                                <div class="border border-slate-200 rounded-2xl bg-white overflow-hidden shadow-2xs">
                                    <div class="max-h-96 overflow-y-auto">
                                        <table class="w-full text-left text-xs divide-y divide-slate-100">
                                            <thead class="bg-slate-50 text-slate-600 font-bold sticky top-0 z-10 text-[11px] uppercase tracking-wider">
                                                <tr>
                                                    <th class="py-2.5 px-3 w-10 text-center">Seç</th>
                                                    <th class="py-2.5 px-3">Botanik Ürün Kartı</th>
                                                    <th class="py-2.5 px-3">Mevcut Kod (Hatalı/Geçici)</th>
                                                    <th class="py-2.5 px-3">Bulunan Gerçek EAN (Eklenecek)</th>
                                                    <th class="py-2.5 px-3">Katalog Eşleşmesi</th>
                                                    <th class="py-2.5 px-3 text-center">Durum</th>
                                                </tr>
                                            </thead>
                                            <tbody id="dermoAuditTableBody" class="divide-y divide-slate-100">
                                                <!-- Dinamik satırlar -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- Geri Bildirim Alanı -->
                            <div id="dermoSyncFeedback" class="hidden p-3.5 rounded-xl text-xs font-semibold"></div>
                        </div>

                        <!-- Alt Sekme 2: Ürün Kataloğu & Excel / Otomasyon Aktarımı -->
                        <div id="tabContentKatalog" class="hidden space-y-6">
                            <div class="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-2xl p-5">
                                <div class="flex items-center justify-between mb-3">
                                    <h4 class="font-bold text-sm text-indigo-900 flex items-center gap-2">
                                        <i class="fa-solid fa-layer-group text-indigo-600"></i>
                                        <span>Katalog ve Barkod İstatistikleri</span>
                                    </h4>
                                    <span class="text-xs bg-indigo-100 text-indigo-800 px-2.5 py-1 rounded-full font-bold">1-to-N Çoklu Barkod</span>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
                                    <div class="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                                        <div class="text-[11px] text-slate-500">Tekil Ürün Sayısı</div>
                                        <div class="text-xl font-black text-slate-800 mt-1" id="catStatProducts">--</div>
                                        <div class="text-[10px] text-slate-400">Katalog & Otomasyon & OTC</div>
                                    </div>
                                    <div class="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                                        <div class="text-[11px] text-slate-500">Toplam Kayıtlı Barkod</div>
                                        <div class="text-xl font-black text-indigo-700 mt-1" id="catStatBarcodes">--</div>
                                        <div class="text-[10px] text-indigo-500 font-medium">EAN-13 & Orijinal Barkodlar</div>
                                    </div>
                                    <div class="bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                                        <div class="text-[11px] text-slate-500">Alternatif / Çoklu Barkod</div>
                                        <div class="text-xl font-black text-purple-700 mt-1" id="catStatSecondary">--</div>
                                        <div class="text-[10px] text-purple-500 font-medium">Bir ürüne bağlı ikincil kodlar</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Aksiyon 1: Botanik Senkronizasyon -->
                            <div id="syncCardBotanik" class="p-5 rounded-2xl border border-emerald-200 bg-emerald-50/30 space-y-3">
                                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h5 class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                                            <i class="fa-solid fa-leaf text-emerald-600"></i>
                                            <span>Botanik MS SQL Otomatik Senkronizasyonu</span>
                                        </h5>
                                        <p class="text-xs text-slate-500">Eczanenizin Botanik programındaki tüm kayıtlı ürünleri ve barkodlarını kataloğa anında aktarır.</p>
                                    </div>
                                    <button type="button" onclick="syncBotanikCatalog()" id="btnSyncBotanikCat" class="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0">
                                        <i class="fa-solid fa-rotate"></i>
                                        <span>Botanik'ten Şimdi Güncelle</span>
                                    </button>
                                </div>
                                <div id="botanikSyncStatus" class="hidden text-xs font-semibold p-3 rounded-xl"></div>
                            </div>

                            <!-- Aksiyon 2: TRIA Senkronizasyon -->
                            <div id="syncCardTria" class="p-5 rounded-2xl border border-slate-200 bg-white space-y-3">
                                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                    <div>
                                        <h5 class="text-sm font-bold text-slate-900">TRIA Oracle Otomatik Senkronizasyonu</h5>
                                        <p class="text-xs text-slate-500">Eczanenizin TRIA otomasyonundaki tüm aktif ürünleri ve çoklu barkodlarını kataloğa günceller.</p>
                                    </div>
                                    <button type="button" onclick="syncTriaCatalog()" id="btnSyncTriaCat" class="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0">
                                        <i class="fa-solid fa-rotate"></i>
                                        <span>TRIA'dan Şimdi Güncelle</span>
                                    </button>
                                </div>
                                <div id="triaSyncStatus" class="hidden text-xs font-semibold p-3 rounded-xl"></div>
                            </div>

                            <!-- Aksiyon 3: Excel Dosyası Yükleme -->
                            <div class="p-5 rounded-2xl border border-slate-200 bg-white space-y-3">
                                <div>
                                    <h5 class="text-sm font-bold text-slate-900">Özel Dermokozmetik / OTC Excel Listesi Yükle</h5>
                                    <p class="text-xs text-slate-500">Elinizdeki temiz bir Excel (.xlsx) dosyasını (Barkod, Ürün Adı, Fiyat, KDV vb.) doğrudan kataloğa ekleyebilirsiniz.</p>
                                </div>
                                <div class="flex flex-col sm:flex-row items-center gap-3 pt-1">
                                    <input type="file" id="excelCatalogFile" accept=".xlsx,.xls" class="text-xs text-slate-600 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer w-full sm:w-auto" />
                                    <button type="button" onclick="uploadCatalogExcel()" id="btnUploadCatExcel" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0">
                                        <i class="fa-solid fa-file-excel"></i>
                                        <span>Excel'i Kataloğa Aktar</span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Alt Sekme 3: GitHub Manifest URL & Canlı Güncelleme Yayınlama Portalı -->
                        <div id="adminSubContentGithub" class="hidden space-y-6">
                            <!-- Dağıtım & Manifest Bilgisi -->
                            <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center space-x-2">
                                        <i class="fa-solid fa-network-wired text-cyan-600 text-xs"></i>
                                        <span class="text-xs font-bold text-slate-800">Merkezi Canlı Dağıtım Sunucusu (GitHub Manifest URL)</span>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <a href="/portal" target="_blank" class="text-[11px] font-bold text-cyan-700 hover:text-cyan-900 underline flex items-center gap-1">
                                            <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>Canlı Portal Sayfası
                                        </a>
                                        <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">Canlı Otomatik Güncelleme Aktif</span>
                                    </div>
                                </div>
                                <p class="text-[11px] text-slate-500">Program her açılışta ve arka planda 5 dakikada bir bu GitHub adresini kontrol ederek yeni sürümleri otomatik kurar. Eczane şifreleriniz (.env), lisansınız ve yerel verileriniz asla ezilmez.</p>
                                <div class="flex flex-col sm:flex-row gap-2">
                                    <input type="text" id="cfg_update_manifest_url" class="flex-1 text-xs font-mono p-2.5 rounded-xl border border-slate-300 bg-white text-slate-700 focus:outline-none focus:border-cyan-600 select-all" value="https://raw.githubusercontent.com/depomxxx/depo-updates/main/version.json">
                                    <button type="button" onclick="saveManifestUrlConfig()" class="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl transition cursor-pointer shrink-0">
                                        <i class="fa-solid fa-floppy-disk mr-1"></i>Adresi Kaydet
                                    </button>
                                </div>
                            </div>

                            <!-- GitHub Canlı Güncelleme & Yayınlama Portalı (Admin) -->
                            <div id="githubAdminPortalBox" class="bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-cyan-500/30 rounded-2xl p-5 space-y-4 shadow-md">
                                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700/80 pb-3">
                                    <div class="flex items-center space-x-3">
                                        <div class="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-300 text-lg">
                                            <i class="fa-brands fa-github"></i>
                                        </div>
                                        <div>
                                            <h5 class="text-sm font-black text-white">GitHub Canlı Güncelleme & Yayınlama Portalı (Merkez)</h5>
                                            <p class="text-[11px] text-slate-300">Git kurulumu gerekmeden doğrudan GitHub bulutuna ve ağdaki tüm bilgisayarlara canlı sürüm gönderin.</p>
                                        </div>
                                    </div>
                                    <span id="ghPortalStatusBadge" class="text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">HAZIR</span>
                                </div>

                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">GitHub Token (ghp_...)</label>
                                        <input type="password" id="ghPortalToken" placeholder="ghp_... (Kayıtlıysa boş bırakın)" class="w-full font-mono text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-emerald-300 focus:outline-none focus:border-cyan-400">
                                    </div>
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">GitHub Kullanıcı Adı</label>
                                        <input type="text" id="ghPortalOwner" placeholder="depomxxx" value="depomxxx" class="w-full font-mono text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-white focus:outline-none focus:border-cyan-400">
                                    </div>
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">GitHub Depo (Repo) Adı</label>
                                        <div class="flex gap-1.5">
                                            <input type="text" id="ghPortalRepo" placeholder="depo-updates" value="depo-updates" class="w-full font-mono text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-white focus:outline-none focus:border-cyan-400">
                                            <button type="button" onclick="verifyAndSetupGithubPortal()" id="btnVerifyGhPortal" class="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[11px] rounded-xl transition cursor-pointer shrink-0" title="GitHub'da depoyu otomatik oluşturur ve bağlar">
                                                Bağla
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs pt-1">
                                    <div>
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">Yayınlanacak Sürüm</label>
                                        <input type="text" id="ghPortalNewVersion" value="1.5.1" class="w-full font-mono font-bold text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-amber-300 focus:outline-none focus:border-cyan-400">
                                    </div>
                                    <div class="sm:col-span-3">
                                        <label class="block text-[11px] font-bold text-slate-300 mb-1">Sürüm Notları (Changelog)</label>
                                        <input type="text" id="ghPortalChangelog" value="Yönetici paneli şifre koruması ve kurumsal lisans senkronizasyonu iyileştirmesi." class="w-full text-xs p-2 rounded-xl bg-slate-950/80 border border-slate-700 text-slate-200 focus:outline-none focus:border-cyan-400">
                                    </div>
                                </div>

                                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
                                    <div id="ghPortalResultText" class="text-[11px] text-slate-300 font-mono truncate max-w-md">
                                        Tek tıkla tüm eczane bilgisayarlarını ve GitHub portalını güncelleyebilirsiniz.
                                    </div>
                                    <button type="button" onclick="publishLiveReleaseFromPortal()" id="btnPublishGhPortal" class="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-900/40 transition flex items-center justify-center gap-2 cursor-pointer shrink-0">
                                        <i class="fa-solid fa-rocket"></i>
                                        <span>GitHub + Tüm Bilgisayarlara Canlı Yayınla</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="settingsFeedback" class="hidden p-3 rounded-xl text-xs font-semibold"></div>
            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span class="text-[11px] text-slate-500 text-center sm:text-left">Değişiklik yapmadığınız ayarlar mevcut halleriyle çalışmaya devam eder.</span>
                <div class="flex items-center space-x-2">
                    <button type="button" onclick="closeSettingsModal()" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200 transition cursor-pointer">Vazgeç</button>
                    <button type="button" id="saveSettingsBtn" onclick="saveSettings()" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-200 transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-check"></i>
                        <span>Tüm Ayarları Kaydet</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Eşdeğer / Muadil İlaçlar Kompakt Modalı -->
    <div id="esdegerModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-3 hidden">
        <div class="bg-white rounded-2xl max-w-4xl w-full max-h-[86vh] shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Kompakt Modal Başlık -->
            <div class="px-5 py-3 bg-gradient-to-r from-amber-600 via-indigo-900 to-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-2.5">
                    <div class="w-8 h-8 rounded-xl bg-white/15 border border-white/25 flex items-center justify-center text-amber-300">
                        <i class="fa-solid fa-pills text-sm"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-black text-white flex items-center space-x-2">
                            <span>SGK Eşdeğer & Muadil İlaçlar Karşılaştırması</span>
                            <span id="modalEsdegerKodu" class="text-[11px] font-mono bg-white/15 text-amber-200 px-2 py-0.5 rounded-full border border-white/20"></span>
                        </h3>
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-[11px] bg-white/10 px-2.5 py-0.5 rounded-full text-white font-bold"><strong id="modalEsdegerCount">0</strong> Muadil</span>
                    <button type="button" onclick="closeEsdegerModal()" class="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                        <i class="fa-solid fa-xmark text-sm"></i>
                    </button>
                </div>
            </div>

            <!-- Modal Content (Kompakt Satırlar) -->
            <div class="p-3.5 overflow-y-auto space-y-1.5 flex-1 bg-slate-50/70">
                <div id="modalEsdegerList" class="space-y-1.5">
                    <!-- Dynamic Compact Rows -->
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="px-5 py-2.5 bg-white border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                <span><i class="fa-solid fa-circle-info text-indigo-600 mr-1"></i>Herhangi bir muadilin sağındaki <b>"Kıyasla"</b> butonuna tıklayarak tüm depolarda canlı fiyatlarını görebilirsiniz.</span>
                <button type="button" onclick="closeEsdegerModal()" class="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-extrabold transition cursor-pointer">Kapat</button>
            </div>
        </div>
    </div>

    <!-- ========================================== -->
    <!-- TEKLİ HIZLI SİPARİŞİ SONLANDIRMA MODALI    -->
    <!-- ========================================== -->
    <div id="quickFinalizeModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div id="quickFinHeader" class="px-6 py-5 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center text-yellow-200 text-lg">
                        <i class="fa-solid fa-bolt-lightning animate-pulse"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-black text-white flex items-center space-x-2">
                            <span>Tekli Siparişi Tamamla & Sonlandır</span>
                            <span id="quickFinDepoBadge" class="text-[10px] bg-white/20 text-white font-extrabold px-2.5 py-0.5 rounded-full border border-white/30">Selçuk Ecza</span>
                        </h3>
                        <p class="text-xs text-amber-100 font-medium">Doğrudan depoya iletim ve tek tıkla sipariş tamamlama</p>
                    </div>
                </div>
                <button type="button" onclick="closeQuickFinalizeModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Body -->
            <div id="quickFinBody" class="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
                <!-- Dynamic Content injected via JS -->
            </div>

            <!-- Modal Footer -->
            <div id="quickFinFooter" class="px-6 py-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
                <!-- Dynamic Buttons injected via JS -->
            </div>
        </div>
    </div>


    <!-- ========================================== -->
    <!-- TOPLU SİPARİŞ GÖNDERİCİ MODAL (ALLIANCE)   -->
    <!-- ========================================== -->
    <div id="bulkOrderModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div id="bulkModalHeader" class="px-6 py-5 bg-gradient-to-r from-sky-900 via-slate-900 to-indigo-950 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div id="bulkModalIconBox" class="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-300 text-lg">
                        <i id="bulkModalIcon" class="fa-solid fa-truck-ramp-box"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-white flex items-center space-x-2">
                            <span id="bulkModalTitle">🚀 Alliance Healthcare Toplu Sipariş Gönderici</span>
                            <span id="bulkModalBadge" class="text-[10px] bg-sky-500/30 text-sky-200 font-extrabold px-2.5 py-0.5 rounded-full border border-sky-400/40">B2B Canlı Sepet</span>
                        </h3>
                        <p id="bulkModalDesc" class="text-xs text-sky-200/80">Günün çıkışlarından seçilen ilaçlar otomatik taranarak sepetinize taslak sipariş olarak aktarılır.</p>
                    </div>
                </div>
                <button type="button" onclick="closeBulkOrderModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Content -->
            <div class="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
                <!-- Status & Progress Banner -->
                <div id="bulkProgressArea" class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2.5">
                    <div class="flex items-center justify-between text-xs font-bold text-slate-800">
                        <span id="bulkProgressStatus" class="flex items-center gap-2">
                            <i class="fa-solid fa-spinner fa-spin text-sky-600" id="bulkProgressSpinner"></i>
                            <span id="bulkProgressText">Alliance sepetine ürünler aktarılıyor...</span>
                        </span>
                        <span id="bulkProgressPercent" class="font-mono text-sky-700 font-extrabold">%0</span>
                    </div>
                    <!-- Progress Bar -->
                    <div class="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                        <div id="bulkProgressBar" class="bg-gradient-to-r from-sky-500 to-blue-600 h-2.5 rounded-full transition-all duration-300" style="width: 0%"></div>
                    </div>
                </div>

                <!-- 4 KPI Stat Boxes -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                        <div class="text-[11px] text-slate-500">Gönderilen Kalem</div>
                        <div class="text-lg font-black text-slate-900 mt-0.5" id="bulkStatTotal">0</div>
                    </div>
                    <div class="bg-white p-3 rounded-xl border border-emerald-100 shadow-2xs">
                        <div class="text-[11px] text-emerald-700">Başarıyla Eklenen</div>
                        <div class="text-lg font-black text-emerald-600 mt-0.5" id="bulkStatSuccess">0</div>
                    </div>
                    <div class="bg-white p-3 rounded-xl border border-rose-100 shadow-2xs">
                        <div class="text-[11px] text-rose-700" id="bulkStatFailedLabel">Depoda Bulunamayan</div>
                        <div class="text-lg font-black text-rose-600 mt-0.5" id="bulkStatFailed">0</div>
                    </div>
                    <div class="bg-white p-3 rounded-xl border border-sky-100 shadow-2xs">
                        <div class="text-[11px] text-sky-700">Taslak Sepet Tutarı</div>
                        <div class="text-lg font-black text-sky-800 mt-0.5 font-mono" id="bulkStatAmount">0.00 ₺</div>
                    </div>
                </div>

                <!-- Eksik Kalemleri Başka Depoya Aktarma Paneli (Hızlı ve Kontrollü) -->
                <div id="bulkTransferMissingBar" class="hidden p-3.5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl flex flex-col md:flex-row items-center justify-between gap-3 shadow-md border border-indigo-700/50">
                    <div class="flex items-center space-x-2.5 min-w-0">
                        <span class="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center font-bold text-sm shrink-0">
                            <i class="fa-solid fa-layer-group"></i>
                        </span>
                        <div class="min-w-0">
                            <div class="text-xs font-bold text-white flex items-center gap-1.5">
                                <span>Bu depoda olmayan <strong class="text-amber-300 font-extrabold" id="bulkMissingCount">0</strong> kalem toplandı!</span>
                            </div>
                            <div class="text-[11px] text-indigo-200/80">Bu eksik ürünleri istediğiniz depoya tek tıkla aktarın:</div>
                        </div>
                    </div>
                    <div class="flex flex-wrap items-center gap-1.5 shrink-0" id="bulkTransferButtonsContainer">
                        <!-- Dinamik doldurulacak: Alliance, Selçuk, İSKOOP, Nevzat -->
                    </div>
                </div>

                <!-- Depo Dağılım Hapları -->
                <div id="bulkModalDepoBreakdown" class="hidden grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <!-- Dinamik doldurulacak -->
                </div>

                <!-- Item Results Table with Tabs & Yok Listesi Export -->
                <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
                    <div class="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-slate-700">
                        <div class="flex items-center space-x-1.5" id="bulkResultTabsContainer">
                            <button type="button" id="bulkTabBtnAll" onclick="switchBulkResultTab('ALL')" class="px-2.5 py-1 rounded-lg text-xs font-black bg-white text-slate-900 shadow-2xs border border-slate-200 cursor-pointer">
                                Tüm Kalemler (<span id="bulkTabCountAll">0</span>)
                            </button>
                            <button type="button" id="bulkTabBtnYok" onclick="switchBulkResultTab('YOK')" class="px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 hover:bg-rose-50 border border-transparent cursor-pointer flex items-center space-x-1">
                                <i class="fa-solid fa-triangle-exclamation text-rose-500"></i>
                                <span>Bulunamayanlar (<span id="bulkTabCountYok">0</span>)</span>
                            </button>
                        </div>
                        <div class="flex items-center space-x-2">
                            <button type="button" id="btnCopyYokList" onclick="copyMissingItemsToClipboard()" class="hidden px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[11px] font-bold shadow-2xs transition flex items-center space-x-1.5 cursor-pointer active:scale-98" title="Bulunamayan ilaçları kopyala">
                                <i class="fa-solid fa-copy text-[10px]"></i>
                                <span>Eksikleri Kopyala</span>
                            </button>
                            <span id="bulkModalTargetDepo" class="text-[11px] text-slate-400 font-medium">B2B Canlı Sepet</span>
                        </div>
                    </div>
                    <div class="max-h-72 overflow-y-auto divide-y divide-slate-100 text-xs" id="bulkOrderItemsList">
                        <div class="p-6 text-center text-slate-400">İşlem başlatılıyor...</div>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div class="flex flex-wrap items-center gap-2" id="bulkModalFooterLinks">
                    <a 
                        id="bulkModalCartLink"
                        href="https://esiparisv2.alliance-healthcare.com.tr/Sales/Cart" 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        class="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-md shadow-sky-200 transition flex items-center space-x-1.5 cursor-pointer"
                    >
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        <span id="bulkModalCartBtnText">Alliance eSipariş Sepetini Aç ↗</span>
                    </a>
                </div>
                <div class="flex items-center space-x-2">
                    <button type="button" id="btnBulkFinalize" onclick="openBulkFinalizeFlow()" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-500/20 transition flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-paper-plane text-xs"></i>
                        <span>Siparişi Sonlandır & Depoya Gönder</span>
                    </button>
                    <button type="button" onclick="closeBulkOrderModal()" class="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">Kapat</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ========================================== -->
    <!-- GÜNLÜK TOPLU SİPARİŞİ SONLANDIRMA MODALI   -->
    <!-- ========================================== -->
    <div id="bulkFinalizeModal" style="display: none;" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <!-- Modal Header -->
            <div id="bulkFinHeader" class="px-6 py-5 bg-gradient-to-r from-emerald-700 via-teal-700 to-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center text-emerald-200 text-lg">
                        <i class="fa-solid fa-clipboard-check"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-black text-white flex items-center space-x-2">
                            <span>Günlük Siparişi Sonlandır & Depoya Gönder</span>
                            <span id="bulkFinDepoBadge" class="text-[10px] bg-white/20 text-white font-extrabold px-2.5 py-0.5 rounded-full border border-white/30">Alliance</span>
                        </h3>
                        <p class="text-xs text-emerald-100 font-medium">Sepet kontrolü, farklı ürün analizi ve tek tıkla depoya gönderim</p>
                    </div>
                </div>
                <button type="button" onclick="closeBulkFinalizeModal()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>

            <!-- Modal Body -->
            <div id="bulkFinBody" class="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">
                <!-- Dynamic Content injected via JS -->
            </div>

            <!-- Modal Footer -->
            <div id="bulkFinFooter" class="px-6 py-4 bg-slate-100 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2">
                <!-- Dynamic Buttons injected via JS -->
            </div>
        </div>
    </div>

    <!-- YÜZEN KÜÇÜK SEPET WIDGET'I (Sol Alt Mavi Çoklu-PC & Depo Sepet Bildirim Çubuğu) -->
    <div id="floatingMiniBulkCart" class="hidden fixed bottom-5 left-5 z-40 max-w-md w-auto">
        <div class="flex flex-col gap-2 px-4 py-3 rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-sky-950 text-white shadow-2xl shadow-blue-950/60 border-2 border-sky-400/80 hover:border-amber-300 transition-all duration-200">
            <div onclick="openMultiDepotCartModal()" class="group flex items-center justify-between space-x-3.5 cursor-pointer">
                <div class="flex items-center space-x-3">
                    <div class="relative w-11 h-11 rounded-xl bg-gradient-to-br from-sky-400 to-blue-600 text-white flex items-center justify-center text-lg font-black shadow-md shrink-0">
                        <i class="fa-solid fa-cart-shopping"></i>
                        <span id="floatingMiniBulkBadgeCount" class="absolute -top-2 -right-2 px-1.5 py-0.5 min-w-[22px] text-center rounded-full bg-amber-400 text-slate-950 text-[10px] font-black border-2 border-blue-950 shadow">0</span>
                    </div>
                    <div class="pr-1">
                        <div class="flex items-center space-x-1.5">
                            <span class="w-2 h-2 rounded-full bg-sky-300 animate-ping"></span>
                            <span class="text-[10px] font-black uppercase tracking-wider text-sky-200">Ortak Eczane Sepeti Aktif</span>
                        </div>
                        <div id="floatingMiniBulkTitle" class="text-xs font-black text-white mt-0.5 leading-snug">Sepette Bekleyen Ürünleriniz Var</div>
                        <div id="floatingMiniBulkSub" class="text-[10px] text-sky-200 font-semibold mt-0.5">Depolara göre ürünleri görmek ve onaylamak için tıklayın</div>
                    </div>
                </div>
                <div class="w-8 h-8 rounded-xl bg-white/15 group-hover:bg-sky-400 group-hover:text-slate-950 flex items-center justify-center transition shrink-0" title="Depo Sepetlerini Aç">
                    <i class="fa-solid fa-basket-shopping text-xs"></i>
                </div>
            </div>
            <!-- Depo Bazlı Hızlı Sepet Rozetleri (Alliance, Selçuk, İSKOOP, Nevzat ayrı ayrı tıklanabilir) -->
            <div id="floatingDepotCartPills" class="flex flex-wrap items-center gap-1.5 pt-1.5 border-t border-white/15"></div>
        </div>
    </div>

    <!-- ÇOKLU DEPO SEPETLERİM & SEPET DETAY MODALI (Farklı Depoları Ayrı Ayrı Gösteren Sepet Merkezi) -->
    <div id="multiDepotCartModal" class="hidden fixed inset-0 bg-slate-950/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-5xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <!-- Üst Başlık -->
            <div class="px-6 py-4 bg-gradient-to-r from-indigo-950 via-violet-900 to-slate-900 text-white flex items-center justify-between">
                <div class="flex items-center space-x-3.5">
                    <div class="w-11 h-11 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-300 text-lg font-black">
                        <i class="fa-solid fa-cart-shopping"></i>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="text-base font-black text-white">🛒 Depo Sepetlerim & Sipariş Kontrol Merkezi</h3>
                            <span id="multiCartTotalSummaryBadge" class="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[11px] font-black">0 Depo • 0 Kalem</span>
                        </div>
                        <p class="text-xs text-indigo-200 mt-0.5">Aramadan veya günlük/6 aylık siparişlerden eklediğiniz ürünleri depolara göre ayrı ayrı inceleyin ve ilgili deponun sepetine gidin.</p>
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <button type="button" id="multiCartMissingBulkBtn" onclick="closeMultiDepotCartModal(); reopenBulkOrderModal();" class="hidden px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/40 text-rose-200 text-xs font-extrabold cursor-pointer">
                        <i class="fa-solid fa-triangle-exclamation mr-1"></i>Eksik Ürünler Raporu
                    </button>
                    <button type="button" onclick="syncTodayOrdersAcrossPCs()" class="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition cursor-pointer" title="Sepetleri Yenile">
                        <i class="fa-solid fa-rotate mr-1"></i>Yenile
                    </button>
                    <button type="button" onclick="closeMultiDepotCartModal()" class="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition cursor-pointer">
                        <i class="fa-solid fa-xmark text-base"></i>
                    </button>
                </div>
            </div>

            <!-- Depo Sekmeleri (Tüm Depolar + Her Depo İçin Ayrı Sekme) -->
            <div id="multiDepotCartTabs" class="px-6 py-3 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center gap-2">
                <!-- JS tarafından doldurulur -->
            </div>

            <!-- Gövde: Depo Sepet Kartları ve Ürün Listeleri -->
            <div id="multiDepotCartBody" class="p-6 overflow-y-auto space-y-5 flex-1 bg-slate-50/70">
                <!-- JS tarafından doldurulur -->
            </div>

            <!-- Alt Bilgi ve Aksiyon Çubuğu -->
            <div class="px-6 py-3.5 bg-white border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
                <div class="text-slate-500 font-semibold flex items-center gap-2">
                    <i class="fa-solid fa-circle-info text-indigo-500"></i>
                    <span>Her deponun sepetindeki ürünleri kontrol ettikten sonra <b>"Depo Sepetine Git (Portal Aç)"</b> veya <b>"Siparişi Sonlandır & Gönder"</b> butonunu kullanabilirsiniz.</span>
                </div>
                <button type="button" onclick="closeMultiDepotCartModal()" class="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold transition cursor-pointer shrink-0">
                    Kapat & Aramaya Devam Et
                </button>
            </div>
        </div>
    </div>

    <!-- TAM EKRAN LİSANS KİLİDİ / UZAKTAN ASKIYA ALMA & SÜRE DOLUMU MODALI -->
    <div id="licenseLockOverlayModal" style="display: none;" class="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[9999] flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-3xl max-w-lg w-full shadow-2xl border-2 border-rose-500/40 overflow-hidden animate-in fade-in zoom-in duration-200">
            <div class="px-6 py-5 bg-gradient-to-r from-rose-900 via-slate-900 to-indigo-950 text-white flex items-center space-x-3.5">
                <div class="w-12 h-12 rounded-2xl bg-rose-500/25 border border-rose-400/40 flex items-center justify-center text-rose-300 text-xl shrink-0">
                    <i class="fa-solid fa-lock"></i>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <h3 class="text-base font-black text-white">Kurumsal Lisans Doğrulaması Gerekli</h3>
                        <span id="lockModalStatusBadge" class="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-rose-500 text-white">ASKIDA / SÜRESİ DOLDU</span>
                    </div>
                    <p class="text-xs text-rose-200 mt-0.5" id="lockModalPharmacyName">Farma Radar Eczane Sistemi</p>
                </div>
            </div>

            <div class="p-6 space-y-4">
                <div id="lockModalReasonBox" class="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-bold leading-relaxed">
                    Lisans süreniz dolmuş veya yönetici tarafından askıya alınmıştır. Lütfen yöneticinizle iletişime geçin.
                </div>

                <div class="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                    <div>
                        <div class="text-[10px] font-bold text-slate-400 uppercase">Bu Bilgisayarın Donanım Kimliği (HWID)</div>
                        <div id="lockModalHwid" class="font-mono font-black text-sm text-indigo-700 mt-0.5 select-all">----</div>
                    </div>
                    <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('lockModalHwid').innerText); showToast('Kopyalandı', 'HWID panoya kopyalandı.', 'success');" class="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs border border-indigo-200 cursor-pointer">
                        <i class="fa-solid fa-copy mr-1"></i>Kopyala
                    </button>
                </div>

                <div class="space-y-2">
                    <label class="block text-xs font-extrabold text-slate-700">Yeni Lisans Anahtarınız Varsa Yapıştırın (FR-... / EDP-...):</label>
                    <div class="flex gap-2">
                        <input type="text" id="lockModalKeyInput" placeholder="FR-... veya EDP-..." class="flex-1 text-xs font-mono p-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white focus:outline-none focus:border-indigo-500">
                        <button type="button" onclick="activateLicenseFromLockModal()" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl transition cursor-pointer shrink-0">
                            <i class="fa-solid fa-key mr-1"></i>Etkinleştir
                        </button>
                    </div>
                </div>

                <div class="pt-2 border-t border-slate-100">
                    <button type="button" onclick="syncLicenseWithCloud(true)" class="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs shadow-lg shadow-emerald-600/20 transition flex items-center justify-center gap-2 cursor-pointer">
                        <i class="fa-solid fa-cloud-arrow-down"></i>
                        <span>Sürem Uzatıldı / Kilidim Açıldı — Online Kontrol Et & Yenile</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- GÜN SONU DEPO SİPARİŞ ÖZETİ & VERİLMEYECEKLERDEN YOK LİSTESİ MERKEZİ (v1.4.2) -->
    <!-- ========================================================================= -->
    <div id="endOfDaySummaryModal" class="hidden fixed inset-0 bg-slate-950/75 backdrop-blur-sm z-50 flex items-center justify-center p-3">
        <div class="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[88vh]">
            <!-- Kompakt Üst Başlık + KPI Hapları -->
            <div class="px-4 py-2.5 bg-gradient-to-r from-slate-900 via-indigo-950 to-emerald-950 text-white flex items-center justify-between gap-3">
                <div class="flex items-center space-x-2.5 min-w-0">
                    <div class="w-8 h-8 rounded-xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-300 text-sm font-black shrink-0">
                        <i class="fa-solid fa-clipboard-list"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="flex items-center gap-2">
                            <h3 class="text-xs sm:text-sm font-black text-white">📋 Gün Sonu Depo Sipariş Özeti & Yok Listesi</h3>
                            <span id="eodModalDateBadge" class="px-2 py-0.5 rounded-full bg-white/15 text-amber-300 text-[10px] font-mono font-bold">--</span>
                        </div>
                    </div>
                </div>
                <div class="flex items-center gap-1.5 shrink-0">
                    <button type="button" onclick="loadEndOfDaySummary()" class="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[11px] font-bold transition cursor-pointer">
                        <i class="fa-solid fa-rotate mr-1"></i>Yenile
                    </button>
                    <button type="button" onclick="closeEndOfDaySummaryModal()" class="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition cursor-pointer">
                        <i class="fa-solid fa-xmark text-sm"></i>
                    </button>
                </div>
            </div>

            <!-- Kompakt KPI Şeridi (4'lü Tek Satır) -->
            <div class="px-4 py-2 bg-slate-50 border-b border-slate-200 grid grid-cols-4 gap-2 text-[11px]">
                <div onclick="switchEndOfDayTab('summary')" class="px-2.5 py-1.5 rounded-xl bg-white border border-emerald-200 flex items-center justify-between cursor-pointer hover:border-emerald-400 transition">
                    <div>
                        <div class="text-[9px] font-extrabold uppercase text-emerald-700">✅ Sipariş Verilen</div>
                        <div class="font-black text-slate-900"><span id="eodKpiOrderedCount">0</span> Kalem • <span id="eodKpiOrderedBoxes" class="text-emerald-700">0</span> Kt</div>
                    </div>
                    <i class="fa-solid fa-circle-check text-emerald-600 text-sm"></i>
                </div>
                <div onclick="switchEndOfDayTab('summary')" class="px-2.5 py-1.5 rounded-xl bg-white border border-amber-200 flex items-center justify-between cursor-pointer hover:border-amber-400 transition">
                    <div>
                        <div class="text-[9px] font-extrabold uppercase text-amber-700">🛒 Sepette Bekleyen</div>
                        <div class="font-black text-slate-900"><span id="eodKpiCartCount">0</span> Kalem • <span id="eodKpiCartBoxes" class="text-amber-700">0</span> Kt</div>
                    </div>
                    <i class="fa-solid fa-cart-shopping text-amber-600 text-sm"></i>
                </div>
                <div onclick="switchEndOfDayTab('skipped')" class="px-2.5 py-1.5 rounded-xl bg-white border border-slate-300 flex items-center justify-between cursor-pointer hover:border-slate-500 transition">
                    <div>
                        <div class="text-[9px] font-extrabold uppercase text-slate-600">🚫 Verilmeyecekler</div>
                        <div class="font-black text-slate-900"><span id="eodKpiSkippedCount">0</span> Kalem</div>
                    </div>
                    <i class="fa-solid fa-ban text-slate-500 text-sm"></i>
                </div>
                <div onclick="switchEndOfDayTab('yok')" class="px-2.5 py-1.5 rounded-xl bg-white border border-rose-200 flex items-center justify-between cursor-pointer hover:border-rose-400 transition">
                    <div>
                        <div class="text-[9px] font-extrabold uppercase text-rose-700">🚨 Yok Listesi</div>
                        <div class="font-black text-rose-700"><span id="eodKpiYokCount">0</span> Kalem <span id="eodKpiYokScanTime" class="text-[9px] font-normal text-rose-500"></span></div>
                    </div>
                    <i class="fa-solid fa-triangle-exclamation text-rose-600 text-sm"></i>
                </div>
            </div>

            <!-- Kompakt Alt Sekmeler (Tek Satır - Kaydırma Çubuğu Yok) -->
            <div class="px-4 bg-white border-b border-slate-200 flex items-center justify-between gap-2 whitespace-nowrap flex-nowrap">
                <div class="flex items-center space-x-1">
                    <button type="button" id="eodTabBtnSummary" onclick="switchEndOfDayTab('summary')" class="py-2 px-3 border-b-2 border-emerald-600 text-emerald-800 font-extrabold text-[11px] flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-boxes-packing"></i>
                        <span>📦 Depo Sipariş Özeti</span>
                    </button>
                    <button type="button" id="eodTabBtnSkipped" onclick="switchEndOfDayTab('skipped')" class="py-2 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 font-bold text-[11px] flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-ban text-slate-500"></i>
                        <span>🚫 Sipariş Verilmeyecekler</span>
                    </button>
                    <button type="button" id="eodTabBtnYok" onclick="switchEndOfDayTab('yok')" class="py-2 px-3 border-b-2 border-transparent text-slate-600 hover:text-slate-900 font-bold text-[11px] flex items-center space-x-1.5 cursor-pointer">
                        <i class="fa-solid fa-file-circle-exclamation text-rose-600"></i>
                        <span>🚨 Yok Listesi</span>
                    </button>
                </div>
                <div class="flex items-center gap-1.5 py-1">
                    <button type="button" onclick="scanYokListItemsInDepots()" id="btnScanYokListInDepots" class="px-2.5 py-1 rounded-lg bg-gradient-to-r from-rose-600 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white font-black text-[11px] shadow-2xs transition flex items-center space-x-1 cursor-pointer" title="Yok Listesindeki ürünleri aktif depolarda tekrar sorgula (Stoğa giren var mı kontrol et)">
                        <i class="fa-solid fa-magnifying-glass-arrow-right text-[10px]"></i>
                        <span>🔍 Yok Listesini Depolarda Sorgula</span>
                    </button>
                </div>
            </div>

            <!-- Sekme İçerikleri -->
            <div class="p-4 overflow-y-auto flex-1 bg-slate-50/60 space-y-3">
                <div id="eodTabContentSummary" class="space-y-3"></div>
                <div id="eodTabContentSkipped" class="hidden space-y-3"></div>
                <div id="eodTabContentYok" class="hidden space-y-3"></div>
            </div>

            <!-- Modal Alt Çubuk -->
            <div class="px-4 py-2.5 bg-white border-t border-slate-200 flex items-center justify-between gap-2 text-[11px]">
                <div class="flex items-center gap-2">
                    <button type="button" onclick="copyEndOfDaySummaryReport()" class="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-extrabold transition cursor-pointer flex items-center gap-1.5">
                        <i class="fa-solid fa-copy"></i>
                        <span>📋 Gün Sonu Özetini Kopyala</span>
                    </button>
                    <button type="button" onclick="copyCompiledYokList()" class="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 font-extrabold transition cursor-pointer flex items-center gap-1.5">
                        <i class="fa-solid fa-clipboard-check"></i>
                        <span>🚨 Yok Listesini Kopyala</span>
                    </button>
                </div>
                <button type="button" onclick="closeEndOfDaySummaryModal()" class="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold transition cursor-pointer">
                    Kapat
                </button>
            </div>
        </div>
    </div>

    <script>
"""
