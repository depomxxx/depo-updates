# -*- coding: utf-8 -*-
"""
backend/order_tracker.py
------------------------
Eczane İçi Tüm Bilgisayarlar Arası Ortak Günlük Sipariş & Sepet Takip Modülü.

Mimari:
- Eczanedeki tüm bilgisayarlar aynı Tria Oracle (veya Botanik MS SQL) veritabanına bağlandığı için,
  sipariş/sepet durumlarını doğrudan merkezi veritabanındaki yardımcı tabloda (`TBL_EDA_GUNLUK_SIPARIS` / `EdaGunlukSiparis`)
  ve eşzamanlı olarak yerel SQLite yedeğinde tutar.
- Böylece Masa 1'de bir ürün toplu veya tekil olarak sipariş verilip sonlandırıldığında (veya sepete eklendiğinde),
  Masa 2 ve Masa 3'teki ekranlarda da anında "SİPARİŞ VERİLDİ" / "SEPETTE" olarak görünür ve mükerrer sipariş önlenir.
"""

import os
import time
import socket
import sqlite3
import datetime
import threading
from pathlib import Path
from typing import Dict, Any, List, Optional


class SharedOrderTracker:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = Path(base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.data_dir = self.base_dir / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.sqlite_path = self.data_dir / "shared_orders_local.db"
        self.hostname = socket.gethostname()
        self.pc_name = self.hostname
        self._lock = threading.Lock()
        self._tria_table_ready = False
        self._botanik_table_ready = False
        self._tebeos_table_ready = False
        self._eczanem_table_ready = False
        self._last_cart_add_ts: Dict[str, float] = {}
        self._init_local_sqlite()

    def get_last_cart_add_time(self, depo: str) -> float:
        return self._last_cart_add_ts.get(str(depo or "").strip().upper(), 0.0)

    def _today_str(self) -> str:
        return datetime.date.today().strftime("%Y-%m-%d")

    def _now_time_str(self) -> str:
        return datetime.datetime.now().strftime("%H:%M")

    def _init_local_sqlite(self):
        try:
            with sqlite3.connect(self.sqlite_path, timeout=5) as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS daily_orders (
                        tarih TEXT NOT NULL,
                        barkod TEXT NOT NULL,
                        urun_adi TEXT,
                        durum TEXT NOT NULL,
                        depo TEXT,
                        miktar INTEGER DEFAULT 1,
                        masa_adi TEXT,
                        saat TEXT,
                        updated_at REAL,
                        PRIMARY KEY (tarih, barkod)
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS daily_joined_offers (
                        tarih TEXT NOT NULL,
                        offer_key TEXT NOT NULL,
                        depo TEXT NOT NULL,
                        offer_id TEXT NOT NULL,
                        barkod TEXT,
                        urun_adi TEXT,
                        miktar INTEGER DEFAULT 1,
                        fiyat_kdvli REAL DEFAULT 0,
                        fiyat_kdvsiz REAL DEFAULT 0,
                        depo_fiyati REAL DEFAULT 0,
                        mf TEXT,
                        satici TEXT,
                        group_name TEXT,
                        miad TEXT,
                        katil_url TEXT,
                        not_metni TEXT,
                        masa_adi TEXT,
                        saat TEXT,
                        updated_at REAL,
                        PRIMARY KEY (tarih, offer_key)
                    )
                """)
                conn.commit()
        except Exception as e:
            print(f"[OrderTracker] Yerel SQLite başlatma uyarısı: {e}")

    def _ensure_tria_table(self, conn) -> bool:
        if self._tria_table_ready:
            return True
        try:
            cur = conn.cursor()
            cur.execute("""
                SELECT COUNT(*) FROM USER_TABLES WHERE TABLE_NAME = 'TBL_EDA_GUNLUK_SIPARIS'
            """)
            exists = cur.fetchone()[0] > 0
            if not exists:
                cur.execute("""
                    CREATE TABLE TBL_EDA_GUNLUK_SIPARIS (
                        TARIH VARCHAR2(16) NOT NULL,
                        BARKOD VARCHAR2(32) NOT NULL,
                        URUN_ADI VARCHAR2(255),
                        DURUM VARCHAR2(32) NOT NULL,
                        DEPO VARCHAR2(64),
                        MIKTAR NUMBER(10) DEFAULT 1,
                        MASA_ADI VARCHAR2(128),
                        SAAT VARCHAR2(16),
                        GUNCELLEME_ZAMANI DATE DEFAULT SYSDATE,
                        CONSTRAINT PK_EDA_GUNLUK_SIP PRIMARY KEY (TARIH, BARKOD)
                    )
                """)
                conn.commit()
            self._tria_table_ready = True
            return True
        except Exception as e:
            if "ORA-00955" in str(e):
                self._tria_table_ready = True
                return True
            print(f"[OrderTracker] Tria tablo hazırlama uyarısı: {e}")
            return False

    def _ensure_botanik_table(self, conn) -> bool:
        if self._botanik_table_ready:
            return True
        try:
            cur = conn.cursor()
            cur.execute("""
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EdaGunlukSiparis' AND xtype='U')
                CREATE TABLE EdaGunlukSiparis (
                    Tarih VARCHAR(16) NOT NULL,
                    Barkod VARCHAR(32) NOT NULL,
                    UrunAdi NVARCHAR(255),
                    Durum VARCHAR(32) NOT NULL,
                    Depo VARCHAR(64),
                    Miktar INT DEFAULT 1,
                    MasaAdi NVARCHAR(128),
                    Saat VARCHAR(16),
                    GuncellemeZamani DATETIME DEFAULT GETDATE(),
                    CONSTRAINT PK_EdaGunlukSiparis PRIMARY KEY (Tarih, Barkod)
                )
            """)
            conn.commit()
            self._botanik_table_ready = True
            return True
        except Exception as e:
            print(f"[OrderTracker] Botanik tablo hazırlama uyarısı: {e}")
            return False

    def _ensure_tebeos_table(self, conn) -> bool:
        if self._tebeos_table_ready:
            return True
        try:
            conn.query("""
                CREATE TABLE IF NOT EXISTS public.eda_gunluk_siparis (
                    tarih VARCHAR(16) NOT NULL,
                    barkod VARCHAR(32) NOT NULL,
                    urun_adi VARCHAR(255),
                    durum VARCHAR(32) NOT NULL,
                    depo VARCHAR(64),
                    miktar INTEGER DEFAULT 1,
                    masa_adi VARCHAR(128),
                    saat VARCHAR(16),
                    guncelleme_zamani TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (tarih, barkod)
                )
            """)
            self._tebeos_table_ready = True
            return True
        except Exception as e:
            print(f"[OrderTracker] TEBEOS tablo hazırlama uyarısı: {e}")
            return False

    def _ensure_eczanem_table(self, conn) -> bool:
        if self._eczanem_table_ready:
            return True
        try:
            cur = conn.cursor()
            cur.execute("""
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EdaGunlukSiparis' AND xtype='U')
                CREATE TABLE EdaGunlukSiparis (
                    Tarih VARCHAR(16) NOT NULL,
                    Barkod VARCHAR(32) NOT NULL,
                    UrunAdi NVARCHAR(255),
                    Durum VARCHAR(32) NOT NULL,
                    Depo VARCHAR(64),
                    Miktar INT DEFAULT 1,
                    MasaAdi NVARCHAR(128),
                    Saat VARCHAR(16),
                    GuncellemeZamani DATETIME DEFAULT GETDATE(),
                    CONSTRAINT PK_EdaGunlukSiparis PRIMARY KEY (Tarih, Barkod)
                )
            """)
            conn.commit()
            self._eczanem_table_ready = True
            return True
        except Exception as e:
            print(f"[OrderTracker] Eczanem tablo hazırlama uyarısı: {e}")
            return False

    def _normalize_barcode(self, barcode: str, urun_adi: str = "") -> str:
        bc = str(barcode or "").strip()
        if len(bc) == 14 and bc.startswith("0"):
            bc = bc[1:]
        if bc:
            try:
                from backend.catalog import catalog
                can = catalog.resolve_canonical_barcode(bc)
                if can:
                    return can
            except Exception:
                pass
            return bc
        if urun_adi:
            try:
                from backend.catalog import catalog
                suggs = catalog.search_suggestions(urun_adi, limit=1)
                if suggs and suggs[0].get("barcode"):
                    return str(suggs[0]["barcode"]).strip()
            except Exception:
                pass
        return bc

    def mark_ordered(
        self,
        items: List[Dict[str, Any]],
        default_depo: str = "",
        masa_adi: Optional[str] = None
    ) -> int:
        return self.mark_items(items=items, durum="SIPARIS_VERILDI", default_depo=default_depo, masa_adi=masa_adi)

    def mark_items(
        self,
        items: List[Dict[str, Any]],
        durum: str = "SIPARIS_VERILDI",
        default_depo: str = "",
        masa_adi: Optional[str] = None
    ) -> int:
        """
        Verilen ürün listesini ('SIPARIS_VERILDI' veya 'SEPETTE') olarak hem merkezi veritabanına
        (Tria Oracle / Botanik MS SQL / TEBEOS / Eczanem) hem de yerel önbelleğe kaydeder.
        Eğer ürün zaten 'SIPARIS_VERILDI' ise ve yeni gelen durum 'SEPETTE' ise,
        'SIPARIS_VERILDI' statüsünü korur (düşürmez).
        """
        if not items:
            return 0

        tarih = self._today_str()
        saat = self._now_time_str()
        masa = (masa_adi or self.hostname or "Eczane-PC").strip()

        normalized_records = []
        for it in items:
            raw_bc = str(it.get("barkod") or it.get("barcode") or it.get("urun_id") or it.get("kod") or "").strip()
            raw_name = str(it.get("urun_adi") or it.get("name") or it.get("ad") or "").strip()
            offer_key = str(it.get("offer_key") or "").strip()[:32]
            bc = self._normalize_barcode(raw_bc, raw_name)
            if not bc and not raw_name and not offer_key:
                continue
            key_bc = bc or offer_key or raw_name[:30].upper()
            depo = str(it.get("depo") or it.get("assigned_depo") or default_depo or "DEPO").strip().upper()
            try:
                miktar = max(1, int(it.get("miktar") or it.get("adet") or 1))
            except Exception:
                miktar = 1

            if durum == "SEPETTE" and depo:
                self._last_cart_add_ts[depo] = time.time()

            normalized_records.append({
                "tarih": tarih,
                "barkod": key_bc[:32],
                "raw_barkod": raw_bc[:32] if raw_bc else key_bc[:32],
                "offer_key": offer_key,
                "name_key": f"NAME:{raw_name.upper()[:26]}" if raw_name else "",
                "urun_adi": (raw_name or key_bc)[:250],
                "durum": durum,
                "depo": depo[:60],
                "miktar": miktar,
                "masa_adi": masa[:120],
                "saat": saat
            })

        if not normalized_records:
            return 0

        def _record_keys(rec: Dict[str, Any]):
            keys = {rec.get("barkod", ""), rec.get("raw_barkod", ""), rec.get("name_key", ""), rec.get("offer_key", "")}
            for k_c in list(keys):
                if len(k_c) == 14 and k_c.startswith("0"):
                    keys.add(k_c[1:])
                elif len(k_c) == 13 and k_c.isdigit():
                    keys.add("0" + k_c)
            return [k[:32] for k in keys if k]

        # 1. Yerel SQLite'a kaydet
        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    for rec in normalized_records:
                        for b_key in _record_keys(rec):
                            s_cur.execute(
                                "SELECT durum, miktar, depo FROM daily_orders WHERE tarih = ? AND barkod = ?",
                                (tarih, b_key)
                            )
                            existing = s_cur.fetchone()
                            if existing and existing[0] in ("SIPARIS_VERILDI", "SIPARIS_VERILMEYECEK") and rec["durum"] == "SEPETTE":
                                continue
                            s_cur.execute("""
                                INSERT OR REPLACE INTO daily_orders
                                (tarih, barkod, urun_adi, durum, depo, miktar, masa_adi, saat, updated_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, strftime('%s','now'))
                            """, (
                                tarih, b_key, rec["urun_adi"], rec["durum"],
                                rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"]
                            ))
                        if rec["durum"] in ("SIPARIS_VERILDI", "SIPARIS_VERILMEYECEK") and rec["urun_adi"]:
                            s_cur.execute("""
                                UPDATE daily_orders
                                SET durum = ?, depo = ?, miktar = ?, masa_adi = ?, saat = ?, updated_at = strftime('%s','now')
                                WHERE tarih = ? AND UPPER(urun_adi) = ? AND durum = 'SEPETTE'
                            """, (
                                rec["durum"], rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"],
                                tarih, rec["urun_adi"].strip().upper()
                            ))
                    s_conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Yerel SQLite yazma uyarısı: {e}")

        # 2. Merkezi Veritabanına (Tria Oracle, Botanik MS SQL veya TEBEOS PostgreSQL) kaydet
        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            if not self._write_to_tria(normalized_records):
                self._write_to_botanik(normalized_records)
        elif active_oto == "BOTANIK":
            self._write_to_botanik(normalized_records)
        elif active_oto == "TEBEOS":
            self._write_to_tebeos(normalized_records)
        elif active_oto == "ECZANEM":
            self._write_to_eczanem(normalized_records)

        return len(normalized_records)

    def _write_to_tria(self, records: List[Dict[str, Any]]) -> bool:
        try:
            from backend.tria_client import tria_client
            with tria_client.get_connection() as conn:
                if not self._ensure_tria_table(conn):
                    return False
                cur = conn.cursor()
                for rec in records:
                    keys = {rec["barkod"], rec["raw_barkod"], rec.get("name_key", ""), rec.get("offer_key", "")}
                    for b_key in [k for k in keys if k]:
                        cur.execute("""
                            SELECT DURUM FROM TBL_EDA_GUNLUK_SIPARIS
                            WHERE TARIH = :t AND BARKOD = :b
                        """, {"t": rec["tarih"], "b": b_key})
                        row = cur.fetchone()
                        if row:
                            if row[0] in ("SIPARIS_VERILDI", "SIPARIS_VERILMEYECEK") and rec["durum"] == "SEPETTE":
                                continue
                            cur.execute("""
                                UPDATE TBL_EDA_GUNLUK_SIPARIS
                                SET URUN_ADI = :u, DURUM = :d, DEPO = :dp, MIKTAR = :m,
                                    MASA_ADI = :ms, SAAT = :s, GUNCELLEME_ZAMANI = SYSDATE
                                WHERE TARIH = :t AND BARKOD = :b
                            """, {
                                "u": rec["urun_adi"], "d": rec["durum"], "dp": rec["depo"],
                                "m": rec["miktar"], "ms": rec["masa_adi"], "s": rec["saat"],
                                "t": rec["tarih"], "b": b_key
                            })
                        else:
                            cur.execute("""
                                INSERT INTO TBL_EDA_GUNLUK_SIPARIS
                                (TARIH, BARKOD, URUN_ADI, DURUM, DEPO, MIKTAR, MASA_ADI, SAAT, GUNCELLEME_ZAMANI)
                                VALUES (:t, :b, :u, :d, :dp, :m, :ms, :s, SYSDATE)
                            """, {
                                "t": rec["tarih"], "b": b_key, "u": rec["urun_adi"],
                                "d": rec["durum"], "dp": rec["depo"], "m": rec["miktar"],
                                "ms": rec["masa_adi"], "s": rec["saat"]
                            })
                conn.commit()
                return True
        except Exception as e:
            print(f"[OrderTracker] Tria merkezi sipariş kayıt uyarısı: {e}")
            return False

    def _write_to_botanik(self, records: List[Dict[str, Any]]) -> bool:
        try:
            from backend.botanik_client import botanik_client
            with botanik_client.get_connection() as conn:
                if not self._ensure_botanik_table(conn):
                    return False
                cur = conn.cursor()
                for rec in records:
                    keys = {rec["barkod"], rec["raw_barkod"], rec.get("name_key", ""), rec.get("offer_key", "")}
                    bc_val = rec.get("barkod", "")
                    if len(bc_val) == 14 and bc_val.startswith("0"):
                        keys.add(bc_val[1:])
                    elif len(bc_val) == 13 and bc_val.isdigit():
                        keys.add("0" + bc_val)
                    for b_key in [k for k in keys if k]:
                        cur.execute("""
                            SELECT Durum FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?
                        """, (rec["tarih"], b_key))
                        row = cur.fetchone()
                        if row:
                            if row[0] in ("SIPARIS_VERILDI", "SIPARIS_VERILMEYECEK") and rec["durum"] == "SEPETTE":
                                continue
                            cur.execute("""
                                UPDATE EdaGunlukSiparis
                                SET UrunAdi = ?, Durum = ?, Depo = ?, Miktar = ?,
                                    MasaAdi = ?, Saat = ?, GuncellemeZamani = GETDATE()
                                WHERE Tarih = ? AND Barkod = ?
                            """, (
                                rec["urun_adi"], rec["durum"], rec["depo"], rec["miktar"],
                                rec["masa_adi"], rec["saat"], rec["tarih"], b_key
                            ))
                        else:
                            cur.execute("""
                                INSERT INTO EdaGunlukSiparis
                                (Tarih, Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat, GuncellemeZamani)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, GETDATE())
                            """, (
                                rec["tarih"], b_key, rec["urun_adi"], rec["durum"],
                                rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"]
                            ))
                conn.commit()
                return True
        except Exception as e:
            print(f"[OrderTracker] Botanik merkezi sipariş kayıt uyarısı: {e}")
            return False

    def _write_to_tebeos(self, records: List[Dict[str, Any]]) -> bool:
        try:
            from backend.tebeos_client import tebeos_client, _sql_lit
            with tebeos_client.get_connection() as conn:
                if not self._ensure_tebeos_table(conn):
                    return False
                for rec in records:
                    keys = {rec["barkod"], rec["raw_barkod"], rec.get("name_key", ""), rec.get("offer_key", "")}
                    for b_key in [k for k in keys if k]:
                        t_lit = _sql_lit(rec["tarih"])
                        b_lit = _sql_lit(b_key)
                        u_lit = _sql_lit(rec["urun_adi"])
                        d_lit = _sql_lit(rec["durum"])
                        dp_lit = _sql_lit(rec["depo"])
                        m_lit = int(rec["miktar"] or 1)
                        ms_lit = _sql_lit(rec["masa_adi"])
                        s_lit = _sql_lit(rec["saat"])
                        _, rows = conn.query(f"SELECT durum FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND barkod = {b_lit}")
                        if rows:
                            if rows[0][0] in ("SIPARIS_VERILDI", "SIPARIS_VERILMEYECEK") and rec["durum"] == "SEPETTE":
                                continue
                            conn.query(f"""
                                UPDATE public.eda_gunluk_siparis
                                SET urun_adi = {u_lit}, durum = {d_lit}, depo = {dp_lit}, miktar = {m_lit},
                                    masa_adi = {ms_lit}, saat = {s_lit}, guncelleme_zamani = CURRENT_TIMESTAMP
                                WHERE tarih = {t_lit} AND barkod = {b_lit}
                            """)
                        else:
                            conn.query(f"""
                                INSERT INTO public.eda_gunluk_siparis
                                (tarih, barkod, urun_adi, durum, depo, miktar, masa_adi, saat, guncelleme_zamani)
                                VALUES ({t_lit}, {b_lit}, {u_lit}, {d_lit}, {dp_lit}, {m_lit}, {ms_lit}, {s_lit}, CURRENT_TIMESTAMP)
                            """)
                return True
        except Exception as e:
            print(f"[OrderTracker] TEBEOS merkezi sipariş kayıt uyarısı: {e}")
            return False

    def _write_to_eczanem(self, records: List[Dict[str, Any]]) -> bool:
        try:
            from backend.eczanem_client import eczanem_client
            with eczanem_client.get_connection() as conn:
                if not self._ensure_eczanem_table(conn):
                    return False
                cur = conn.cursor()
                for rec in records:
                    keys = {rec["barkod"], rec["raw_barkod"], rec.get("name_key", ""), rec.get("offer_key", "")}
                    bc_val = rec.get("barkod", "")
                    if len(bc_val) == 14 and bc_val.startswith("0"):
                        keys.add(bc_val[1:])
                    elif len(bc_val) == 13 and bc_val.isdigit():
                        keys.add("0" + bc_val)
                    for b_key in [k for k in keys if k]:
                        cur.execute("""
                            SELECT Durum FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?
                        """, (rec["tarih"], b_key))
                        row = cur.fetchone()
                        if row:
                            if row[0] in ("SIPARIS_VERILDI", "SIPARIS_VERILMEYECEK") and rec["durum"] == "SEPETTE":
                                continue
                            cur.execute("""
                                UPDATE EdaGunlukSiparis
                                SET UrunAdi = ?, Durum = ?, Depo = ?, Miktar = ?,
                                    MasaAdi = ?, Saat = ?, GuncellemeZamani = GETDATE()
                                WHERE Tarih = ? AND Barkod = ?
                            """, (
                                rec["urun_adi"], rec["durum"], rec["depo"], rec["miktar"],
                                rec["masa_adi"], rec["saat"], rec["tarih"], b_key
                            ))
                        else:
                            cur.execute("""
                                INSERT INTO EdaGunlukSiparis
                                (Tarih, Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat, GuncellemeZamani)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, GETDATE())
                            """, (
                                rec["tarih"], b_key, rec["urun_adi"], rec["durum"],
                                rec["depo"], rec["miktar"], rec["masa_adi"], rec["saat"]
                            ))
                conn.commit()
                return True
        except Exception as e:
            print(f"[OrderTracker] Eczanem merkezi sipariş kayıt uyarısı: {e}")
            return False

    def record_joined_offer(
        self,
        depo: str,
        offer_id: str,
        barkod: str,
        urun_adi: str,
        miktar: int = 1,
        offer_meta: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        EczaneTakas veya Eczatrend üzerinden katılınan ortak alım / takas teklifini
        hem günlük ortak sipariş takibine (daily_orders + merkezi SQL) hem de
        daily_joined_offers tablosuna kalıcı olarak kaydeder.
        """
        tarih = self._today_str()
        saat = self._now_time_str()
        masa = (self.hostname or "Eczane-PC").strip()[:120]
        clean_depo = str(depo or "ECZANETAKAS").strip().upper()
        clean_oid = str(offer_id or "").strip()
        prefix = "ET_" if clean_depo == "ECZANETAKAS" else "ETR_"
        offer_key = f"{prefix}{clean_oid[:24]}"
        norm_bc = self._normalize_barcode(barkod, urun_adi)
        clean_name = str(urun_adi or "").strip() or f"{clean_depo} #{clean_oid[:8]}"
        qty = max(1, int(miktar or 1))
        meta = offer_meta or {}

        total_qty = qty
        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    s_cur.execute(
                        "SELECT miktar FROM daily_joined_offers WHERE tarih = ? AND offer_key = ?",
                        (tarih, offer_key)
                    )
                    row = s_cur.fetchone()
                    if row and row[0]:
                        total_qty = int(row[0]) + qty

                    s_cur.execute("""
                        INSERT OR REPLACE INTO daily_joined_offers (
                            tarih, offer_key, depo, offer_id, barkod, urun_adi, miktar,
                            fiyat_kdvli, fiyat_kdvsiz, depo_fiyati, mf, satici, group_name,
                            miad, katil_url, not_metni, masa_adi, saat, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, strftime('%s','now'))
                    """, (
                        tarih,
                        offer_key,
                        clean_depo,
                        clean_oid,
                        norm_bc,
                        clean_name[:250],
                        total_qty,
                        float(meta.get("fiyat_kdvli") or meta.get("satis_fiyati") or meta.get("fiyat") or 0.0),
                        float(meta.get("fiyat_kdvsiz") or 0.0),
                        float(meta.get("depo_fiyati") or meta.get("depocu_fiyat") or 0.0),
                        str(meta.get("mf") or "YOK")[:64],
                        str(meta.get("satici") or meta.get("ekleyen") or "")[:120],
                        str(meta.get("groupName") or meta.get("group_name") or "")[:120],
                        str(meta.get("miad") or meta.get("kalan_sure") or "")[:64],
                        str(meta.get("katil_url") or "")[:255],
                        str(meta.get("not") or meta.get("not_metni") or "")[:255],
                        masa,
                        saat
                    ))
                    s_conn.commit()
            except Exception as e:
                print(f"[OrderTracker] daily_joined_offers yazma uyarısı: {e}")

        self.mark_items(
            items=[{
                "barkod": norm_bc or offer_key,
                "offer_key": offer_key,
                "urun_adi": clean_name,
                "miktar": total_qty,
                "depo": clean_depo
            }],
            durum="SIPARIS_VERILDI",
            default_depo=clean_depo,
            masa_adi=masa
        )

        return {
            "offer_key": offer_key,
            "offer_id": clean_oid,
            "barkod": norm_bc,
            "urun_adi": clean_name,
            "depo": clean_depo,
            "durum": "SIPARIS_VERILDI",
            "miktar": total_qty,
            "masa_adi": masa,
            "saat": saat
        }

    def get_today_joined_offers(self, depo: str = "") -> Dict[str, Dict[str, Any]]:
        """
        Bugün EczaneTakas veya Eczatrend üzerinden katılınan teklifleri
        {offer_key: {...}} sözlüğü olarak döndürür.
        """
        tarih = self._today_str()
        clean_depo = str(depo or "").strip().upper()
        result: Dict[str, Dict[str, Any]] = {}
        try:
            with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                s_cur = s_conn.cursor()
                if clean_depo:
                    s_cur.execute("""
                        SELECT offer_key, depo, offer_id, barkod, urun_adi, miktar,
                               fiyat_kdvli, fiyat_kdvsiz, depo_fiyati, mf, satici, group_name,
                               miad, katil_url, not_metni, masa_adi, saat
                        FROM daily_joined_offers
                        WHERE tarih = ? AND UPPER(depo) = ?
                        ORDER BY updated_at DESC
                    """, (tarih, clean_depo))
                else:
                    s_cur.execute("""
                        SELECT offer_key, depo, offer_id, barkod, urun_adi, miktar,
                               fiyat_kdvli, fiyat_kdvsiz, depo_fiyati, mf, satici, group_name,
                               miad, katil_url, not_metni, masa_adi, saat
                        FROM daily_joined_offers
                        WHERE tarih = ?
                        ORDER BY updated_at DESC
                    """, (tarih,))
                for r in s_cur.fetchall():
                    okey = str(r[0] or "").strip()
                    if not okey:
                        continue
                    result[okey] = {
                        "offer_key": okey,
                        "depo": str(r[1] or ""),
                        "offer_id": str(r[2] or ""),
                        "barkod": str(r[3] or ""),
                        "urun_adi": str(r[4] or ""),
                        "miktar": int(r[5] or 1),
                        "fiyat_kdvli": float(r[6] or 0.0),
                        "fiyat_kdvsiz": float(r[7] or 0.0),
                        "depo_fiyati": float(r[8] or 0.0),
                        "mf": str(r[9] or "YOK"),
                        "satici": str(r[10] or ""),
                        "group_name": str(r[11] or ""),
                        "miad": str(r[12] or ""),
                        "katil_url": str(r[13] or ""),
                        "not_metni": str(r[14] or ""),
                        "masa_adi": str(r[15] or ""),
                        "saat": str(r[16] or ""),
                        "durum": "SIPARIS_VERILDI"
                    }
        except Exception as e:
            print(f"[OrderTracker] daily_joined_offers okuma uyarısı: {e}")
        return result

    def unmark_item(self, barcode: str, urun_adi: str = "") -> bool:
        """Ürünün 'Sipariş Verildi / Sepette / Verilmeyecek' işaretini tüm bilgisayarlar için kaldırır."""
        tarih = self._today_str()
        bc = self._normalize_barcode(barcode, urun_adi)
        clean_name = str(urun_adi or "").strip().upper()
        keys = {str(barcode or "").strip(), bc}
        if bc:
            try:
                from backend.catalog import catalog
                for rel_b in catalog.get_all_related_barcodes(bc):
                    if rel_b and len(rel_b) <= 32:
                        keys.add(rel_b)
            except Exception:
                pass
        if clean_name:
            keys.add(clean_name[:30])
            keys.add(f"NAME:{clean_name[:26]}")
        for k_cand in list(keys):
            if len(k_cand) == 14 and k_cand.startswith("0"):
                keys.add(k_cand[1:])
            elif len(k_cand) == 13 and k_cand.isdigit():
                keys.add("0" + k_cand)
        keys = {k for k in keys if k}
        if not keys and not clean_name:
            return False

        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    # Ayrıca bu ürüne ait joined_offers anahtarlarını da bulup keys setine ekle
                    for k in list(keys):
                        s_cur.execute("SELECT offer_key FROM daily_joined_offers WHERE tarih = ? AND (barkod = ? OR offer_key = ? OR offer_id = ?)", (tarih, k, k, k))
                        for r_ok in s_cur.fetchall():
                            if r_ok and r_ok[0]:
                                keys.add(str(r_ok[0]))
                    if clean_name:
                        s_cur.execute("SELECT offer_key FROM daily_joined_offers WHERE tarih = ? AND UPPER(urun_adi) = ?", (tarih, clean_name))
                        for r_ok in s_cur.fetchall():
                            if r_ok and r_ok[0]:
                                keys.add(str(r_ok[0]))
                    for k in keys:
                        s_cur.execute("DELETE FROM daily_orders WHERE tarih = ? AND barkod = ?", (tarih, k))
                        s_cur.execute("DELETE FROM daily_joined_offers WHERE tarih = ? AND (barkod = ? OR offer_key = ? OR offer_id = ?)", (tarih, k, k, k))
                    if clean_name:
                        s_cur.execute("DELETE FROM daily_orders WHERE tarih = ? AND UPPER(urun_adi) = ?", (tarih, clean_name))
                        s_cur.execute("DELETE FROM daily_joined_offers WHERE tarih = ? AND UPPER(urun_adi) = ?", (tarih, clean_name))
                    s_conn.commit()
            except Exception:
                pass

        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        for k in keys:
                            cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND BARKOD = :b", {"t": tarih, "b": k})
                        if clean_name:
                            cur.execute("DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND UPPER(URUN_ADI) = :u", {"t": tarih, "u": clean_name})
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Tria silme uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        for k in keys:
                            cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?", (tarih, k))
                        if clean_name:
                            cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(UrunAdi) = ?", (tarih, clean_name))
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Botanik silme uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        t_lit = _sql_lit(tarih)
                        for k in keys:
                            conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND barkod = {_sql_lit(k)}")
                        if clean_name:
                            conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND UPPER(urun_adi) = {_sql_lit(clean_name)}")
            except Exception as e:
                print(f"[OrderTracker] TEBEOS silme uyarısı: {e}")
        elif active_oto == "ECZANEM":
            try:
                from backend.eczanem_client import eczanem_client
                with eczanem_client.get_connection() as conn:
                    if self._ensure_eczanem_table(conn):
                        cur = conn.cursor()
                        for k in keys:
                            cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND Barkod = ?", (tarih, k))
                        if clean_name:
                            cur.execute("DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(UrunAdi) = ?", (tarih, clean_name))
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Eczanem silme uyarısı: {e}")
        return True

    def clear_cart_items_for_depo(self, depo: str) -> bool:
        """İlgili deponun sepeti boşaltıldığında ('SEPETTE' durumundaki) kayıtları tüm bilgisayarlar için temizler."""
        tarih = self._today_str()
        clean_depo = str(depo or "").strip().upper()
        if not clean_depo:
            return False

        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    s_cur.execute(
                        "DELETE FROM daily_orders WHERE tarih = ? AND UPPER(depo) = ? AND durum = 'SEPETTE'",
                        (tarih, clean_depo)
                    )
                    s_conn.commit()
            except Exception:
                pass

        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "DELETE FROM TBL_EDA_GUNLUK_SIPARIS WHERE TARIH = :t AND UPPER(DEPO) = :d AND DURUM = 'SEPETTE'",
                            {"t": tarih, "d": clean_depo}
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Tria sepet temizleme uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(Depo) = ? AND Durum = 'SEPETTE'",
                            (tarih, clean_depo)
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Botanik sepet temizleme uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        t_lit = _sql_lit(tarih)
                        d_lit = _sql_lit(clean_depo)
                        conn.query(f"DELETE FROM public.eda_gunluk_siparis WHERE tarih = {t_lit} AND UPPER(depo) = {d_lit} AND durum = 'SEPETTE'")
            except Exception as e:
                print(f"[OrderTracker] TEBEOS sepet temizleme uyarısı: {e}")
        elif active_oto == "ECZANEM":
            try:
                from backend.eczanem_client import eczanem_client
                with eczanem_client.get_connection() as conn:
                    if self._ensure_eczanem_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "DELETE FROM EdaGunlukSiparis WHERE Tarih = ? AND UPPER(Depo) = ? AND Durum = 'SEPETTE'",
                            (tarih, clean_depo)
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Eczanem sepet temizleme uyarısı: {e}")
        return True

    def promote_cart_items_to_ordered_for_depo(self, depo: str) -> int:
        """
        İlgili deponun sepetindeki ('SEPETTE' durumundaki) tüm kayıtları yerinde 'SIPARIS_VERILDI' olarak günceller.
        Böylece barkod veya ürün kodu farklılığı olsa dahi o depoya ait hiçbir ürün 'SEPETTE' olarak asılı kalmaz.
        """
        tarih = self._today_str()
        saat = self._now_time_str()
        clean_depo = str(depo or "").strip().upper()
        if not clean_depo:
            return 0

        updated_count = 0
        with self._lock:
            try:
                with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                    s_cur = s_conn.cursor()
                    s_cur.execute(
                        "UPDATE daily_orders SET durum = 'SIPARIS_VERILDI', saat = ?, updated_at = strftime('%s','now') WHERE tarih = ? AND UPPER(depo) = ? AND durum = 'SEPETTE'",
                        (saat, tarih, clean_depo)
                    )
                    updated_count = s_cur.rowcount or 0
                    s_conn.commit()
            except Exception as e:
                print(f"[OrderTracker] SQLite sepet->sipariş terfi uyarısı: {e}")

        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "UPDATE TBL_EDA_GUNLUK_SIPARIS SET DURUM = 'SIPARIS_VERILDI', SAAT = :s, GUNCELLEME_ZAMANI = SYSDATE WHERE TARIH = :t AND UPPER(DEPO) = :d AND DURUM = 'SEPETTE'",
                            {"s": saat, "t": tarih, "d": clean_depo}
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Tria sepet->sipariş terfi uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "UPDATE EdaGunlukSiparis SET Durum = 'SIPARIS_VERILDI', Saat = ?, GuncellemeZamani = GETDATE() WHERE Tarih = ? AND UPPER(Depo) = ? AND Durum = 'SEPETTE'",
                            (saat, tarih, clean_depo)
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Botanik sepet->sipariş terfi uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        t_lit = _sql_lit(tarih)
                        d_lit = _sql_lit(clean_depo)
                        s_lit = _sql_lit(saat)
                        conn.query(
                            f"UPDATE public.eda_gunluk_siparis SET durum = 'SIPARIS_VERILDI', saat = {s_lit}, guncelleme_zamani = CURRENT_TIMESTAMP WHERE tarih = {t_lit} AND UPPER(depo) = {d_lit} AND durum = 'SEPETTE'"
                        )
            except Exception as e:
                print(f"[OrderTracker] TEBEOS sepet->sipariş terfi uyarısı: {e}")
        elif active_oto == "ECZANEM":
            try:
                from backend.eczanem_client import eczanem_client
                with eczanem_client.get_connection() as conn:
                    if self._ensure_eczanem_table(conn):
                        cur = conn.cursor()
                        cur.execute(
                            "UPDATE EdaGunlukSiparis SET Durum = 'SIPARIS_VERILDI', Saat = ?, GuncellemeZamani = GETDATE() WHERE Tarih = ? AND UPPER(Depo) = ? AND Durum = 'SEPETTE'",
                            (saat, tarih, clean_depo)
                        )
                        conn.commit()
            except Exception as e:
                print(f"[OrderTracker] Eczanem sepet->sipariş terfi uyarısı: {e}")

        return updated_count

    def get_today_orders_map(self) -> Dict[str, Dict[str, Any]]:
        """
        Bugün sipariş verilen veya sepete eklenen tüm ürünleri {barkod: {...}} sözlüğü olarak döner.
        Merkezi veritabanından (Tria / Botanik / TEBEOS) okur, böylece tüm bilgisayarlar aynı ekranı görür.
        """
        tarih = self._today_str()
        result: Dict[str, Dict[str, Any]] = {}
        status_priority = {
            "SIPARIS_VERILDI": 3,
            "SIPARIS_VERILMEYECEK": 2,
            "SEPETTE": 1
        }

        def _set_with_priority(k: str, entry: Dict[str, Any]):
            if not k:
                return
            existing = result.get(k)
            if not existing:
                result[k] = entry
                return
            new_prio = status_priority.get(str(entry.get("durum") or ""), 0)
            old_prio = status_priority.get(str(existing.get("durum") or ""), 0)
            if new_prio >= old_prio:
                result[k] = entry

        def _put_entry(bc_key: str, u_name: str, entry: Dict[str, Any]):
            clean_nm = u_name.strip().upper() if u_name else ""
            raw_b = str(entry.get("barkod") or bc_key or "").strip()
            if raw_b.startswith(("NAME:", "ET_", "ETR_")):
                canon_b = ""
            elif len(raw_b) == 14 and raw_b.startswith("0"):
                canon_b = raw_b[1:]
            else:
                canon_b = raw_b
            if canon_b and canon_b.isdigit():
                try:
                    from backend.catalog import catalog
                    resolved_b = catalog.resolve_canonical_barcode(canon_b)
                    if resolved_b and resolved_b.isdigit():
                        canon_b = resolved_b
                except Exception:
                    pass
            if clean_nm and clean_nm in result:
                prev_b = str(result[clean_nm].get("barkod") or "").strip()
                if len(prev_b) == 14 and prev_b.startswith("0"):
                    prev_b = prev_b[1:]
                if prev_b and prev_b.isdigit():
                    canon_b = prev_b
            if canon_b and canon_b.isdigit():
                entry["barkod"] = canon_b

            if bc_key:
                _set_with_priority(bc_key, entry)
                if len(bc_key) == 14 and bc_key.startswith("0"):
                    _set_with_priority(bc_key[1:], entry)
                elif len(bc_key) == 13 and bc_key.isdigit():
                    _set_with_priority("0" + bc_key, entry)
                try:
                    from backend.catalog import catalog
                    for rel_b in catalog.get_all_related_barcodes(bc_key):
                        if rel_b:
                            _set_with_priority(rel_b, entry)
                except Exception:
                    pass
            if canon_b and canon_b.isdigit():
                _set_with_priority(canon_b, entry)
                if len(canon_b) == 13:
                    _set_with_priority("0" + canon_b, entry)
            if clean_nm:
                _set_with_priority(clean_nm, entry)
                _set_with_priority(f"NAME:{clean_nm[:26]}", entry)

        # 1. Önce yerel SQLite'tan oku
        try:
            with sqlite3.connect(self.sqlite_path, timeout=5) as s_conn:
                s_cur = s_conn.cursor()
                s_cur.execute("""
                    SELECT barkod, urun_adi, durum, depo, miktar, masa_adi, saat
                    FROM daily_orders WHERE tarih = ?
                """, (tarih,))
                for r in s_cur.fetchall():
                    bc = str(r[0] or "").strip()
                    unm = str(r[1] or "")
                    entry = {
                        "barkod": bc,
                        "urun_adi": unm,
                        "durum": str(r[2] or "SIPARIS_VERILDI"),
                        "depo": str(r[3] or "DEPO"),
                        "miktar": int(r[4] or 1),
                        "masa_adi": str(r[5] or ""),
                        "saat": str(r[6] or "")
                    }
                    _put_entry(bc, unm, entry)
        except Exception:
            pass

        # 2. Merkezi veritabanından (Tria Oracle / Botanik MS SQL / TEBEOS PostgreSQL) oku
        from backend.config_manager import get_active_otomasyon
        active_oto = get_active_otomasyon()
        if active_oto == "TRIA":
            try:
                from backend.tria_client import tria_client
                with tria_client.get_connection() as conn:
                    if self._ensure_tria_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT BARKOD, URUN_ADI, DURUM, DEPO, MIKTAR, MASA_ADI, SAAT
                            FROM TBL_EDA_GUNLUK_SIPARIS
                            WHERE TARIH = :t
                        """, {"t": tarih})
                        for r in cur.fetchall():
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            unm = str(r[1] or "")
                            entry = {
                                "barkod": bc,
                                "urun_adi": unm,
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
                            _put_entry(bc, unm, entry)
            except Exception as e:
                print(f"[OrderTracker] Tria okuma uyarısı: {e}")
        elif active_oto == "BOTANIK":
            try:
                from backend.botanik_client import botanik_client
                with botanik_client.get_connection() as conn:
                    if self._ensure_botanik_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat
                            FROM EdaGunlukSiparis
                            WHERE Tarih = ?
                        """, (tarih,))
                        for r in cur.fetchall():
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            unm = str(r[1] or "")
                            entry = {
                                "barkod": bc,
                                "urun_adi": unm,
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
                            _put_entry(bc, unm, entry)
            except Exception as e:
                print(f"[OrderTracker] Botanik okuma uyarısı: {e}")
        elif active_oto == "TEBEOS":
            try:
                from backend.tebeos_client import tebeos_client, _sql_lit
                with tebeos_client.get_connection() as conn:
                    if self._ensure_tebeos_table(conn):
                        _, rows = conn.query(f"""
                            SELECT barkod, urun_adi, durum, depo, miktar, masa_adi, saat
                            FROM public.eda_gunluk_siparis
                            WHERE tarih = {_sql_lit(tarih)}
                        """)
                        for r in rows:
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            unm = str(r[1] or "")
                            entry = {
                                "barkod": bc,
                                "urun_adi": unm,
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
                            _put_entry(bc, unm, entry)
            except Exception as e:
                print(f"[OrderTracker] TEBEOS okuma uyarısı: {e}")
        elif active_oto == "ECZANEM":
            try:
                from backend.eczanem_client import eczanem_client
                with eczanem_client.get_connection() as conn:
                    if self._ensure_eczanem_table(conn):
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT Barkod, UrunAdi, Durum, Depo, Miktar, MasaAdi, Saat
                            FROM EdaGunlukSiparis WITH (NOLOCK)
                            WHERE Tarih = ?
                        """, (tarih,))
                        for r in cur.fetchall():
                            bc = str(r[0] or "").strip()
                            if not bc:
                                continue
                            unm = str(r[1] or "")
                            entry = {
                                "barkod": bc,
                                "urun_adi": unm,
                                "durum": str(r[2] or "SIPARIS_VERILDI"),
                                "depo": str(r[3] or "DEPO"),
                                "miktar": int(r[4] or 1),
                                "masa_adi": str(r[5] or ""),
                                "saat": str(r[6] or "")
                            }
                            _put_entry(bc, unm, entry)
            except Exception as e:
                print(f"[OrderTracker] Eczanem okuma uyarısı: {e}")

        return result


order_tracker = SharedOrderTracker()
